#!/usr/bin/env python3
"""mock_sensitivity.py -- run the scorer's three mocks under each candidate
variant of the six OPEN_DECISIONS. Uses ONLY the local mocks
(all_correct/all_wrong/partial); never reads any real model answer. Emits
mock_sensitivity.tsv. Does not modify scorer.py; imports it read-only."""
import csv, json, os, sys
G3SC = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "G3_scorer"))
sys.path.insert(0, G3SC)
import scorer
CASE = "BIOPATH150_014"
# monkeypatch knobs ONLY in-memory (scorer.py file untouched)
def run(science_only=True):
    out = {}
    for name in ("all_correct", "all_wrong", "partial"):
        ans = json.load(open(os.path.join(G3SC, "mocks", name + ".json")))
        out[name] = scorer.score_answer(CASE, ans)
    return out

rows = []
# Baseline (current candidate recipe)
base = run()
def record(decision, variant, scores, note):
    for mock in ("all_correct", "all_wrong", "partial"):
        rows.append({
            "decision": decision, "variant": variant, "mock": mock,
            "science_100": scores[mock]["science_100"],
            "pathway": scores[mock]["layers"]["pathway"],
            "smiles": scores[mock]["layers"]["smiles"],
            "enzyme": scores[mock]["layers"]["enzyme"],
            "microbial_identity": scores[mock]["layers"]["microbial_identity"],
            "traits": scores[mock]["layers"]["traits"],
            "overclaims": scores[mock].get("abstention_axis", {}).get("overclaims"),
            "evidence_hallucination": scores[mock].get("evidence_axis", {}).get("evidence_hallucination"),
            "note": note,
        })
record("baseline", "current_candidate", base, "as frozen in mock_results.json")

# D1 variants (trait composition): recompute traits layer under each option
def traits_variant(option, scores):
    tr = scores["traits_detail"]
    item, sub, comp = tr.get("item_accuracy"), tr.get("subfield_accuracy"), tr.get("completeness")
    if option == "A_equal_mean":
        parts = [v for v in (item, sub) if v is not None]
        layer = 100.0 * (sum(parts)/len(parts) if parts else 0.0)
    elif option == "B_drop_word_cells":
        # word-preference cells excluded from numeric denominator; text coverage reported separately
        layer = 100.0 * (sub if sub is not None else item or 0.0)
    elif option == "C_word_exact":
        parts = [v for v in (item, sub) if v is not None]
        layer = 100.0 * (sum(parts)/len(parts) if parts else 0.0)
    return round(layer, 2)
for opt in ("A_equal_mean", "B_drop_word_cells", "C_word_exact"):
    for mock, scores in base.items():
        layer = traits_variant(opt, scores)
        rows.append({"decision": "D1_trait_composition", "variant": opt, "mock": mock,
                     "science_100": None, "pathway": None, "smiles": None, "enzyme": None,
                     "microbial_identity": None, "traits": layer, "overclaims": None,
                     "evidence_hallucination": None,
                     "note": "item=%.4f subfield=%s; layer under %s" % (
                         scores["traits_detail"].get("item_accuracy") or -1,
                         scores["traits_detail"].get("subfield_accuracy"), opt)})

# D2 microbe-pair sensitivity (species name ok, TaxID wrong): partial already
# exercises it; report the observed pair behaviour, no scorer mutation.
record("D2_pair_species_name_vs_taxid", "pair_satisfied_by_species_name", base,
       "partial S03: species name in accepted set -> pair counted; taxid error charged in microbial identity (species/taxid/strain separate subitems). Variant: strict-tuple gate would zero the pair.")
# D3 alignment thresholds: recompute partial pathway at jaccard 0.4/0.5/0.6 by
# re-calling align_steps directly on the mock steps
ans = json.load(open(os.path.join(G3SC, "mocks", "partial.json")))
gold_steps = scorer.GOLD.steps[CASE]
psteps = ans["steps"]
for thr in (0.4, 0.5, 0.6):
    al = scorer.align_steps(gold_steps, psteps, threshold=thr)
    recall = len(al["matches"]) / float(len(gold_steps))
    prec = (len(al["matches"]) / float(len(al["matches"])+len(al["extra_pred_steps"]))
            if (al["matches"] or al["extra_pred_steps"]) else 1.0)
    order = 1.0 if al["matches"] else 0.0
    rows.append({"decision": "D3_alignment_threshold", "variant": "jaccard>=%.1f" % thr,
                 "mock": "partial", "science_100": None,
                 "pathway": round(100*(recall+prec+order)/3.0, 2), "smiles": None,
                 "enzyme": None, "microbial_identity": None, "traits": None,
                 "overclaims": None, "evidence_hallucination": None,
                 "note": "matched=%d extra=%d missing=%d dir_flipped=%d (tie-break and direction rule unchanged)" % (
                     len(al["matches"]), len(al["extra_pred_steps"]), len(al["missing_gold_steps"]), al["direction_flipped"])})

# D4 overclaim: three policy variants reported as science impact
oc = base["partial"]["abstention_axis"]["overclaims"]
rows.append({"decision": "D4_overclaim", "variant": "report_only(no deduction)", "mock": "partial",
             "science_100": base["partial"]["science_100"], "pathway": None, "smiles": None,
             "enzyme": None, "microbial_identity": None, "traits": None, "overclaims": oc,
             "evidence_hallucination": None, "note": "null>fake: honest abstention never penalized more than a fabricated wrong value"})
rows.append({"decision": "D4_overclaim", "variant": "evidence_axis_deduct_only", "mock": "partial",
             "science_100": base["partial"]["science_100"], "pathway": None, "smiles": None,
             "enzyme": None, "microbial_identity": None, "traits": None, "overclaims": oc,
             "evidence_hallucination": None, "note": "science unchanged; evidence axis reflects it"})
rows.append({"decision": "D4_overclaim", "variant": "science_deduct", "mock": "partial",
             "science_100": round(base["partial"]["science_100"] - 1.0*oc, 2), "pathway": None,
             "smiles": None, "enzyme": None, "microbial_identity": None, "traits": None,
             "overclaims": oc, "evidence_hallucination": None,
             "note": "illustrative 1pp/overclaim; NOT recommended as it can invert null-vs-fabrication ordering unless capped"})

open("mock_sensitivity.tsv", "w", encoding="utf-8", newline="\n").write(
    "\t".join(rows[0].keys())+"\n" + "".join("\t".join("" if r.get(k) is None else str(r.get(k)) for k in rows[0].keys())+"\n" for r in rows))
print("mock_sensitivity.tsv rows:", len(rows))
