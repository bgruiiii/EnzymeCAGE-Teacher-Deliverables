# G3 六项开放口径 决策卡（老师勾选，均为 PROPOSAL_NOT_FROZEN）

只用 all_correct/all_wrong/partial 三个本地mock做敏感性；未读任何真实模型答案。
`real_model_answers_consulted=0`。科学五层权重45/10/20/15/10固定，本卡不动权重。

| 决策 | 候选方案（见mock_sensitivity.tsv） | 建议 | 需老师定 |
|---|---|---|---|
| D1 性状10%组合 | A item/subfield等权均值(all_correct traits=97.73) / B word-preference格剔出数值分母另报文本覆盖(all_correct=100) / C word格有accepted文本时独立精确匹配 | **B**：以"重定义可评分格"实现all_correct=100，非调权 | 认可B的剔除范围，或C |
| D2 层内子指标/菌配对 | 物种名对但TaxID错：pair按物种名计对(现) vs 须TaxID一致；species/strain/TaxID/genome独立子项；酶名/EC/pair独立 | 独立子项、等权为候选；pair规则请二选一 | pair规则+是否不等权 |
| D3 步骤对齐 | Jaccard 0.4/0.5/0.6 敏感性（partial pathway随阈值变），方向A→B≠B→A与tie-break不变 | 阈值0.5；split/merge固定处置 | 阈值+split/merge罚幅 |
| D4 overclaim | 仅报告 / 证据轴扣不扣科学 / 科学分扣（示意1pp/条） | 仅报告或证据轴；**禁止**会让honest null劣于编造的扣分 | 选一并给封顶 |
| D5 F14字段路径 | 只从traits.F14读genome；profile级为兼容读且须一致否则CONFLICT | 单源=traits.F14 | 批准单源规则 |
| D6 achiral参考 | 仅附表 / SMILES层次指标 / 敏感性分析；主SMILES恒为isomeric canonical | 附表+敏感性，主分不变 | 呈现位置 |

关键不变式（任何方案都不得破坏）：null=recall miss且不增overclaim；范围/multi值1161格本期不进准确率分母；predicted不升observed；F2/F3/F4精确匹配无容差、不取中点、不用区间重叠；extra字段仅warning原文保留；syntax/object/schema三率分列。

`recommended_defaults.json` 标 PROPOSAL_NOT_FROZEN，**不自动写回scorer**；老师回签后由正式G3冻结套用。
