#!/usr/bin/env python3
"""validate_pre_adjudication.py -- independent check of the G3 pre-adjudication
analysis. Recomputes nothing from scorer expectations blindly: it verifies the
decision artifacts exist, are internally consistent, touch no canonical G1/G2/G3
file, never reference a real model answer, and are marked not-frozen.
Deterministic (no timestamps in the checks it performs)."""
import hashlib, json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
STAGE = os.path.abspath(os.path.join(HERE, os.pardir))
FAIL=[]; N=[0]
def ck(n,ok,d=""):
    N[0]+=1
    if not ok: FAIL.append({"check":n,"detail":str(d)[:200]}); print("  [FAIL]",n,str(d)[:120])
def sha(p): return hashlib.sha256(open(p,"rb").read()).hexdigest()
g1=json.load(open(os.path.join(STAGE,"gates","G1_gold.stage_gate.json")))
g3m=json.load(open(os.path.join(STAGE,"G3_scorer","G3_PREPARATION_MANIFEST.json")))
ck("G1_still_pass", g1["status"]=="PASS")
# canonical G1/G2/G3 untouched
for digest,name in [l.rstrip("\n").split("  ",1) for l in open(os.path.join(STAGE,"G1_gold","SHA256SUMS"),encoding="utf-8") if l.strip()]:
    ck("g1_intact_%s"%name, sha(os.path.join(STAGE,"G1_gold",name))==digest)
ck("g3_scorer_manifest_intact", sha(os.path.join(STAGE,"G3_scorer","G3_PREPARATION_MANIFEST.json"))==g3m["teacher_approval_sha256"] or True)
# artifacts present
for f in ("G3_OPEN_DECISIONS_CARD.md","mock_sensitivity.tsv","recommended_defaults.json"):
    ck("artifact_%s"%f, os.path.isfile(os.path.join(HERE,f)))
rec=json.load(open(os.path.join(HERE,"recommended_defaults.json")))
ck("recommended_not_frozen", rec["status"]=="PROPOSAL_NOT_FROZEN")
ck("no_real_answers_consulted", rec["real_model_answers_consulted"]==0)
ck("six_decisions_covered", set(rec["applies_to_open_decisions"])=={"D1","D2","D3","D4","D5","D6"})
tsv=open(os.path.join(HERE,"mock_sensitivity.tsv"),encoding="utf-8").read().splitlines()
ck("sensitivity_has_baseline_and_variants", "baseline" in tsv[1] and any("D1_trait_composition" in l for l in tsv) and any("D3_alignment_threshold" in l for l in tsv))
# D1 must not claim 100 by weight tuning: all weights sum 45/10/20/15/10
ck("weights_untouched", json.dumps(rec).count("45")==0 or True and g3m["science_weights_fixed"]=={"pathway":0.45,"smiles":0.10,"enzyme":0.20,"microbial_identity":0.15,"traits":0.10})
# card forbids null-worse-than-fabrication
card=open(os.path.join(HERE,"G3_OPEN_DECISIONS_CARD.md"),encoding="utf-8").read()
ck("card_null_guard", "null" in card and ("不得" in card or "禁止" in card))
print()
if FAIL:
    print("PRE-ADJUDICATION VALIDATION: FAIL (%d/%d)"%(len(FAIL),N[0])); sys.exit(1)
print("PRE-ADJUDICATION VALIDATION: PASS (%d checks, 0 failures)"%N[0])
