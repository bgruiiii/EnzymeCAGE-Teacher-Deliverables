#!/usr/bin/env python3
"""dryrun.py -- offline mock-transport readiness dry-run (zero real network/key).
Drives the collector's REAL dispatch / idempotency / phase-cap / gate / resume
logic against SYNTHETIC_OFFLINE_FIXTURE payloads covering five paths:
Schema VALID object, Schema INVALID object, EMPTY/NON_OBJECT, finish_reason=
length truncation, and an extra-field warning-only object. Writes
offline_readiness/dryrun_results.json. Never reads env/key; never creates real
attempts; no model answer is real."""
import importlib.util, json, os, sys, tempfile
from collections import Counter
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
ROOT=os.path.abspath(os.path.join(STAGE,os.pardir))
COLLECTOR=os.path.join(ROOT,"24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")
spec=importlib.util.spec_from_file_location("cv2",os.path.join(COLLECTOR,"scripts","run_collection_v2.py"))
cv2=importlib.util.module_from_spec(spec); sys.modules["cv2"]=cv2; spec.loader.exec_module(cv2)
FIX="SYNTHETIC_OFFLINE_FIXTURE"
SCHEMA=cv2.load_json_file(os.path.join(COLLECTOR,"schemas","biodegradation_answer_v2.schema.json"))

def _trait(v): return {"value":v,"raw_text":None,"evidence_id":"EVID_001","confidence":"medium"}
TRAITS={"F1_oxygen_tolerance":_trait(None),
 "F2_temperature":_trait({"minimum_c":None,"optimum_c":28,"maximum_c":None,"preference":"mesophilic"}),
 "F3_pH":_trait({"minimum":None,"optimum":7.0,"maximum":None}),
 "F4_salinity":_trait({"minimum":None,"optimum":None,"maximum":None,"unit":"% NaCl (w/v)","category":None}),
 "F5_culture_collection":_trait({"collection":"DSM","accession":"1111"}),
 "F6_respiration_electron_acceptor":_trait({"respiration_mode":None,"terminal_electron_acceptor":None}),
 "F7_carbon_substrate_utilization":_trait(None),"F8_degradation_capacity_broad":_trait(None),
 "F9_enzyme_activity":_trait(None),"F10_motility":_trait(None),"F11_cell_morphology":_trait(None),
 "F12_gram_cell_envelope":_trait(None),"F13_sporulation":_trait(None),
 "F14_genome_basic":_trait({"genome_accession":"GCA_000000000.1","genome_size_bp":None,"gc_percent":None}),
 "F15_habitat_generalism":_trait(None)}
def valid_answer(case_id, extra=False):
    a={"schema_version":"biodegradation_answer_v2","case_id":case_id,"pollutant_name_zh":"合成测试",
     "pollutant_name_en":"SYNTHETIC_TEST","route_scope":{"oxygen_condition":"aerobic",
     "chosen_route_name":"synthetic route","is_single_continuous_route":True,"notes":None},"route_summary":None,
     "steps":[{"step_id":"S1","order":1,"predecessor_step_ids":[],"branch_id":None,
       "substrates":[{"name":"synth-substrate","smiles":"CCO","role":"main"}],
       "products":[{"name":"synth-product","smiles":"CC=O","role":"main"}],
       "reaction_type":None,
       "enzyme":{"name":"synth-enzyme","ec_number":"1.1.1.1","gene_or_protein":None,"evidence_id":"EVID_001","confidence":"medium"},
       "microorganism":{"organism_name":"Syntheticus testus","strain":"T1","ncbi_taxid":"999999999","organism_profile_id":"ORG_001","evidence_id":"EVID_001","confidence":"medium"},
       "reaction_evidence_id":"EVID_001","trait_evidence_id":None,"uncertainty":None}],
     "organism_profiles":[{"organism_profile_id":"ORG_001","organism_name":"Syntheticus testus","strain":"T1","ncbi_taxid":"999999999","traits":TRAITS}],
     "complete_pathway_organism_profile_id":None,"central_metabolism_entry":{"products":[],"explanation":None},
     "downstream_continuation":[],"alternative_branches":[],
     "evidence_registry":[{"evidence_id":"EVID_001","source_type":"DATABASE_DIRECT","database":"SYNTHETIC","record_id":"BSY-r00000","locator":"synthetic","claim_scope":["S1.enzyme"],"confidence":"medium"}],
     "uncertainties":[]}
    if extra:
        a["steps"][0][FIX+"_extra_field"]="warning-only; original text preserved"
    return a
INVALID_ANSWER={"schema_version":"biodegradation_answer_v2","case_id":"NOPE"}  # required missing
NON_OBJECT="[1,2,3]"

class MockStream:
    def __init__(self,l): self._l=l; self.status_code=200; self.headers={}
    def iter_lines(self):
        for x in self._l: yield x.encode() if isinstance(x,str) else x
    def read_text(self,limit=2000): return ""
    def close(self): pass
def _chunks(content): return ["data: "+json.dumps({"choices":[{"delta":{"content":content},"index":0}],"object":"chat.completion.chunk"}),
                              "data: "+json.dumps({"choices":[{"delta":{},"finish_reason":"stop","index":0}],"object":"chat.completion.chunk"}),"data: [DONE]"]
class MT(cv2.Transport):
    name="mock"
    def __init__(self): self.calls=0; self.bodies=[]
    def open_stream(self,endpoint,body,timeout,headers):
        self.calls+=1; self.bodies.append(json.dumps(body,sort_keys=True))
        cid=next((m.get("content","") for m in body.get("messages",[])),"")[:0]
        case_id=body["_fixture_case"] if "_fixture_case" in body else "BIOPATH150_001"
        model=body["model"]
        if model=="qwen3.8-flash":     # Schema VALID object
            return MockStream(_chunks(json.dumps(valid_answer("BIOPATH150_001"),ensure_ascii=False)))
        if model=="qwen3.8-max":       # extra-field warning-only, still schema VALID
            return MockStream(_chunks(json.dumps(valid_answer("BIOPATH150_001",extra=True),ensure_ascii=False)))
        if model=="deepseek-v4-pro-0813":  # Schema INVALID object
            return MockStream(_chunks(json.dumps(INVALID_ANSWER)))
        if model=="deepseek-v4.1-flash":   # finish_reason=length + empty visible
            return MockStream(["data: "+json.dumps({"choices":[{"delta":{"reasoning_content":"thinking"},"index":0}],"object":"chat.completion.chunk"}),
                               "data: "+json.dumps({"choices":[{"delta":{},"finish_reason":"length","index":0}],"object":"chat.completion.chunk"}),"data: [DONE]"])
        # ZHIPU/GLM-5.3: NON_OBJECT (json array) -> schema not an object
        return MockStream(_chunks(NON_OBJECT))

def _run(phase, case_model_map):
    tmp=tempfile.mkdtemp(); cpath=os.path.join(tmp,"c.jsonl")
    with open(cpath,"w",encoding="utf-8") as fh:
        for cid in case_model_map: fh.write(json.dumps({"case_id":cid,"pollutant_name_zh":"x","pollutant_name_en":"SYNTHETIC_TEST","oxygen_condition":"aerobic","route_scope":"synthetic route"})+"\n")
    lpath=os.path.join(tmp,"l.json"); json.dump({"live_disabled":False,"authorized_new_api_requests":15,"phase_api_request_caps":{"G5_smoke":15,"G6_pilot":50},"phase_api_total_cap":80},open(lpath,"w"))
    mt=MT()
    ctx=cv2.RunContext(root=COLLECTOR,run_id="dry_"+phase,output_root=os.path.join(tmp,"run"),cases_path=cpath,limits_path=lpath,
        transport=mt,api_key="SYNTHETIC_FIXTURE_NOT_A_KEY",dry_run=False,phase=phase,experiment_version="dryrun",
        max_new_requests=100,search_decision={"decision":"ALL_PASS"})
    res=cv2.run_all(ctx); tasks=cv2.build_tasks(ctx); wr=cv2.write_results_and_normalized(ctx,tasks,res)
    return mt, wr
mt,wr=_run("smoke",{"BIOPATH150_001":None})
sel=wr["selected"]
def form(r): return "OBJECT" if isinstance(r["parsed_answer"],dict) else "NON_OBJECT"
schema=Counter(r["schema_status"] for r in sel)
jsonr=Counter(r["json_parse_status"] for r in sel); formr=Counter(form(r) for r in sel)
trunc=sum(1 for r in sel if r.get("finish_reason")=="length")
# extra-field warning preserved (qwen3.8-max)
mx=[r for r in sel if r["model_id"]=="qwen3.8-max"][0]
extra_preserved = FIX+"_extra_field" in json.dumps(mx.get("parsed_answer")) and mx["validation_errors_total"]>=0 and mx.get("validation_warnings_total",0)>=1
resume_mt=None
# resume: second run same run_id must not re-bill
tmp=mt and None
R={"dispatch_calls":mt.calls,"json_rate":dict(jsonr),"form_rate":dict(formr),"schema_rate":dict(schema),
   "truncated_count":trunc,"extra_field_warning_preserved":bool(extra_preserved),
   "schema_valid_count":schema.get("VALID",0),"schema_invalid_count":schema.get("INVALID",0),
   "not_checked_or_non_object_count":schema.get("NOT_CHECKED",0)+formr.get("NON_OBJECT",0)}
# resume check reuses the same output tree
mt2=MT()
cpath=next(p for p in [os.path.join(os.path.dirname(os.path.abspath(__file__)),"__nope__")])
# re-run by pointing ctx at the SAME run_root
def _resume(phase):
    tmpd=tempfile.mkdtemp()
    return tmpd
# rebuild resume against the existing run_root
rr=wr
# We already have run_root via ctx (lost); reconstruct by running again with resume on same output
# capture run_root: rerun deterministic
mt3=MT()
tmp3=tempfile.mkdtemp(); cpath3=os.path.join(tmp3,"c.jsonl")
open(cpath3,"w",encoding="utf-8").write(json.dumps({"case_id":"BIOPATH150_001","pollutant_name_zh":"x","pollutant_name_en":"SYNTHETIC_TEST","oxygen_condition":"aerobic","route_scope":"synthetic route"})+"\n")
lpath3=os.path.join(tmp3,"l.json"); json.dump({"live_disabled":False,"authorized_new_api_requests":15,"phase_api_request_caps":{"G5_smoke":15,"G6_pilot":50},"phase_api_total_cap":80},open(lpath3,"w"))
runout=os.path.join(tmp3,"run")
ctxA=cv2.RunContext(root=COLLECTOR,run_id="rs",output_root=runout,cases_path=cpath3,limits_path=lpath3,transport=mt3,api_key="SYNTHETIC_FIXTURE_NOT_A_KEY",dry_run=False,phase="smoke",experiment_version="dryrun",max_new_requests=100,search_decision={"decision":"ALL_PASS"})
cv2.run_all(ctxA)
mt4=MT()
ctxB=cv2.RunContext(root=COLLECTOR,run_id="rs",output_root=runout,cases_path=cpath3,limits_path=lpath3,transport=mt4,api_key="SYNTHETIC_FIXTURE_NOT_A_KEY",dry_run=False,phase="smoke",experiment_version="dryrun",max_new_requests=100,resume=True,search_decision={"decision":"ALL_PASS"})
cv2.run_all(ctxB)
R["resume_rebill_calls"]=mt4.calls
# caps + gate
def capctx(phase,auth,search="pass"):
    lt=os.path.join(tmp3,"lc_%s_%d_%s.json"%(phase,auth,search)); json.dump({"live_disabled":False,"authorized_new_api_requests":auth,"phase_api_request_caps":{"G5_smoke":15,"G6_pilot":50},"phase_api_total_cap":80},open(lt,"w"))
    return cv2.evaluate_live_authorization(cv2.RunContext(root=COLLECTOR,run_id="c",output_root=tmp3,cases_path=cpath3,limits_path=lt,api_key="X",dry_run=False,phase=phase,experiment_version="d",search_decision={"decision":"ALL_PASS"} if search=="pass" else {"decision":"UNDECIDED"}))
R["cap_smoke_20_refused"]= any(x["code"]=="AUTHORIZED_EXCEEDS_PHASE_CAP" for x in capctx("smoke",20)["refusals"])
R["cap_total_100_refused"]= any(x["code"]=="AUTHORIZED_EXCEEDS_TOTAL_ENVELOPE" for x in capctx("pilot",100)["refusals"])
R["search_undecided_refused"]= any(x["code"]=="SEARCH_DECISION_UNDECIDED" for x in capctx("smoke",15,"undecided")["refusals"])
b={"model":"m","messages":[{"role":"user","content":"x"}],"max_tokens":16384,"temperature":0,"stream":True,"enable_search":True}
bs=cv2.request_body_sha256(b)
R["idempotency_phase_differs"]=cv2.idempotency_key("smoke","v1","BIOPATH150_001","m",bs)!=cv2.idempotency_key("pilot","v1","BIOPATH150_001","m",bs)
R["idempotency_case_differs"]=cv2.idempotency_key("smoke","v1","BIOPATH150_001","m",bs)!=cv2.idempotency_key("smoke","v1","BIOPATH150_002","m",bs)
R["idempotency_stable"]=cv2.idempotency_key("smoke","v1","BIOPATH150_001","m",bs)==cv2.idempotency_key("smoke","v1","BIOPATH150_001","m",bs)
R["schema_valid_success_path"]= R["schema_valid_count"]>=1
R["assertions"]={
  "schema_valid_count>=1": R["schema_valid_count"]>=1,
  "schema_invalid_count>=1": R["schema_invalid_count"]>=1,
  "not_checked_or_non_object_count>=1": R["not_checked_or_non_object_count"]>=1,
  "truncated_count>=1": R["truncated_count"]>=1}
R["all_assertions_pass"]= all(R["assertions"].values())
R["api_calls"]=0
json.dump(R,open(os.path.join(HERE,"dryrun_results.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True)
open(os.path.join(HERE,"dryrun_results.json"),"a",encoding="utf-8").write("\n")
print("dryrun all_assertions_pass:",R["all_assertions_pass"],"| schema:",R["schema_rate"])
sys.exit(0 if R["all_assertions_pass"] else 1)
