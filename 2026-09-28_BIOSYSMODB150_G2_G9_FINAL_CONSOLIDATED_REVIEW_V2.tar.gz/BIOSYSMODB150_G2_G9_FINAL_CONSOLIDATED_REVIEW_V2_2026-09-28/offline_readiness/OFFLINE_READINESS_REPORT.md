# Offline readiness report (PREPARED_NOT_AUTHORIZED_TO_RUN / no dispatch)

Statuses: G1=PASS; G2=READY_FOR_REVIEW; G3=PREPARED_PENDING_G2_SIGNOFF; G4/G5/G6=PREPARED_NOT_AUTHORIZED_TO_RUN; G7=TEMPLATE_ONLY_NOT_APPROVED.

Artifacts:
- G3_pre_adjudication_analysis: 6 OPEN-DECISION cards + mock_sensitivity.tsv (only local mocks) + recommended_defaults.json (PROPOSAL_NOT_FROZEN).
- G4_search_preflight: probe spec + 3 probes + metadata success criteria + symmetry decision template + 15 slots NOT_DISPATCHED.
- G5_smoke_preflight: 3 deterministic cases + 15 slots NOT_DISPATCHED + artifact layout.
- G6_pilot_preflight: 10 stratified cases + 50 slots NOT_DISPATCHED + shape/timing templates + two G5-in-G6 options (B recommended).
- G7_budget_template: per-model usage (empty), formula, hash-binding (5x121=605, smoke/pilot not deducted).

Offline dry-run (mock transport; no env/key; SYNTHETIC_OFFLINE_FIXTURE):
- dispatch calls: 5; three rates: json {'EMPTY': 1, 'VALID': 4}, form {'NON_OBJECT': 1, 'OBJECT': 4}, schema {'INVALID': 4, 'NOT_CHECKED': 1}; truncated 1
- resume re-bill calls: 0 (0 = terminal attempts never re-sent)
- idempotency: phase/case differ & stable: True/True/True
- caps: smoke>15 refused True; total>80 refused True; search-undecided refused True
- missing G2/G3 gate: real dispatch stays blocked (stage_gate absent + live gate)

api_calls=0; real_dispatch_attempts=0. Nothing here authorizes a run; all post-G2 stages blocked by stage_blockers.tsv.
