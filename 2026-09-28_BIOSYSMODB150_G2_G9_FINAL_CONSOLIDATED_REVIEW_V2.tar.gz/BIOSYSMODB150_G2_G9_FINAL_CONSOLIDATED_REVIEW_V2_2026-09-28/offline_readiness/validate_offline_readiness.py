#!/usr/bin/env python3
"""validate_offline_readiness.py -- independent check of all preflight dirs.
Confirms status, NOT_DISPATCHED/TEMPLATE everywhere, api=0, no dispatch dirs,
SHA256SUMS completeness, and that canonical G1/G2/G3 hashes are intact.
Deterministic; run with PYTHONDONTWRITEBYTECODE=1."""
import hashlib, json, os, sys
def sha(p): return hashlib.sha256(open(p,"rb").read()).hexdigest()
os.environ.setdefault("PYTHONDONTWRITEBYTECODE","1")
FAIL=[];N=[0]
def ck(n,ok,d=""):
    N[0]+=1
    if not ok: FAIL.append({"check":n,"detail":str(d)[:200]}); print("  [FAIL]",n,str(d)[:150])
S=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),os.pardir))
# gates
for g,st in [("G4_search_probe.stage_gate.json","PREPARED_NOT_AUTHORIZED_TO_RUN"),
             ("G5_smoke.stage_gate.json","PREPARED_NOT_AUTHORIZED_TO_RUN"),
             ("G6_pilot.stage_gate.json","PREPARED_NOT_AUTHORIZED_TO_RUN"),
             ("G7_budget.stage_gate.json","TEMPLATE_ONLY_NOT_APPROVED")]:
    d=json.load(open(os.path.join(S,"gates",g))); ck("gate_%s"%g, d["status"]==st and d["next_stage_allowed"] is False and d["api_calls"]==0)
# canonical intact
for dg,name in [l.rstrip("\n").split("  ",1) for l in open(os.path.join(S,"G1_gold","SHA256SUMS"),encoding="utf-8") if l.strip()]:
    ck("g1_intact_%s"%name, sha(os.path.join(S,"G1_gold",name))==dg)
for dg,name in [l.rstrip("\n").split("  ",1) for l in open(os.path.join(S,"G2_questions","SHA256SUMS"),encoding="utf-8") if l.strip()]:
    ck("g2_intact_%s"%name, sha(os.path.join(S,"G2_questions",name))==dg)
# per-dir SHA completeness + no pycache listed
for d in ["G3_pre_adjudication_analysis","G4_search_preflight","G5_smoke_preflight","G6_pilot_preflight","G7_budget_template","offline_readiness"]:
    base=os.path.join(S,d)
    listed={}
    for line in open(os.path.join(base,"SHA256SUMS"),encoding="utf-8"):
        if line.strip():
            dg,rel=line.rstrip("\n").split("  ",1); listed[rel]=dg
    ck("no_pycache_listed_%s"%d, not any("pycache" in rel or rel.endswith(".pyc") for rel in listed))
    for rel,dg in listed.items():
        ck("digest_%s_%s"%(d,rel), sha(os.path.join(base,rel))==dg, rel)
    actual=set()
    for dp,dn,fns in os.walk(base):
        dn[:]=[x for x in dn if x!="__pycache__"]
        for fn in fns:
            if fn=="SHA256SUMS" or fn.endswith(".pyc"): continue
            actual.add(os.path.relpath(os.path.join(dp,fn),base))
    ck("covers_all_%s"%d, sorted(actual)==sorted(listed))
dr=json.load(open(os.path.join(S,"offline_readiness","dryrun_results.json")))
ck("dryrun_four_assertions", all(dr["assertions"].values()) and dr["all_assertions_pass"] is True)
ck("dryrun_schema_valid_success", dr.get("schema_valid_success_path") is True and dr.get("schema_valid_count",0)>=1)
ck("dryrun_invalid_present", dr.get("schema_invalid_count",0)>=1)
ck("dryrun_notchecked_nonobject_present", dr.get("not_checked_or_non_object_count",0)>=1)
ck("dryrun_truncation_present", dr.get("truncated_count",0)>=1)
ck("dryrun_extra_field_preserved", dr.get("extra_field_warning_preserved") is True)
ck("dryrun_resume_rebill_zero", dr.get("resume_rebill_calls")==0)
g4s=json.load(open(os.path.join(S,"G4_search_preflight","search_probe_spec.json")))
ck("g4_anchor_not_invented", g4s.get("anchor_utc") is None)
# offline manifest api=0
m=json.load(open(os.path.join(S,"offline_readiness","OFFLINE_READINESS_MANIFEST.json")))
ck("manifest_api0", m["api_calls"]==0 and m["real_dispatch_attempts"]==0)
# no run/ or dispatched artifacts outside synthetic mock_runs
ck("no_real_runs_dir", not os.path.isdir(os.path.join(S,"G5_smoke_preflight","runs")) and not os.path.isdir(os.path.join(S,"G6_pilot_preflight","runs")))
print()
if FAIL: print("OFFLINE READINESS VALIDATION: FAIL %d/%d"%(len(FAIL),N[0])); sys.exit(1)
print("OFFLINE READINESS VALIDATION: PASS (%d checks, 0 failures)"%N[0])
