#!/usr/bin/env python3
"""build_g9_preflight.py -- G9 reporting preflight: three-axis templates,
report schema, ±5pp sensitivity spec, and a PURE-SYNTHETIC results corpus
(deterministic hash-derived scores; no real model answer, no real scoring).
G3 is unfrozen, so every scorer binding stays PENDING_*; nothing here is a
real result and the renderer labels the report SYNTHETIC. Zero API."""
import hashlib, json, os
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
G2=os.path.join(STAGE,"G2_questions")
FIX="SYNTHETIC_OFFLINE_FIXTURE"
MODELS=["qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"]
AXES=[("pathway",45.0),("smiles",10.0),("enzyme",20.0),("microbial_identity",15.0),("traits",10.0)]
cases=[json.loads(l)["case_id"] for l in open(os.path.join(G2,"main_cases.jsonl"),encoding="utf-8")]
assert len(cases)==121==len(set(cases)); cases.sort()
def u(case,model,key):  # deterministic uniform [0,1)
    return int.from_bytes(hashlib.sha256(("|".join([case,model,key])).encode()).digest()[:8],"big")/2.0**64
# ---- templates (header-only; empty templates parse as zero data rows) ----
def tmpl(name,cols):
    open(os.path.join(HERE,name),"w",encoding="utf-8").write("\t".join(cols)+"\n")
tmpl("per_case_result.template.tsv",["case_id","model_exact_id"]+[a for a,_ in AXES]+
     ["weighted_total","json_valid","schema_valid","truncated","evidence_verified_n","evidence_unverified_n",
      "overclaim_flags","recall_macro","completeness","abstention_status","fixture_label"])
tmpl("per_model_summary.template.tsv",["model_exact_id","n_cases"]+["macro_"+a for a,_ in AXES]+
     ["macro_weighted_total","micro_weighted_count_note","json_valid_rate","schema_valid_rate","truncation_rate",
      "main_report_axis","aux_report_axis","fixture_label"])
tmpl("evidence_axis.template.tsv",["model_exact_id","citations_verified_n","citations_unverified_n",
     "overclaim_n","f5_accession_illegal_n","f5_local_lookup_absent_n","evidence_chain_complete_rate",
     "separate_from_science_score","fixture_label"])
tmpl("engineering_axis.template.tsv",["model_exact_id","tokens_mean","tokens_median","tokens_p90","tokens_max",
     "latency_s_p90","http_429_n","http_5xx_n","timeout_n","stream_truncation_n","retry_total",
     "separate_from_science_score","fixture_label"])
# ---- report schema ----
json.dump({"schema_version":"bsysmodb150_report_v1_preflight","status":"OFFLINE_ONLY_NOT_AUTHORIZED",
 "fixture_label":FIX,"scorer_binding":"PENDING_G3_FREEZE_AND_G7_SIGNOFF","api_calls":0,
 "axes":{"science_layers":{"keys":[a for a,_ in AXES],"fixed_weights_pp":dict((a,w) for a,w in AXES),
    "note":"teacher-immutable 45/10/20/15/10; sub-indicator composition inside layers is PENDING_TEACHER (G3)"},
   "evidence_axis":"independent reporting axis; never folded into science total",
   "engineering_axis":"independent reporting axis (tokens/latency/retries/truncation)",
   "abstention_axis":"separate; null=recall miss, never overclaim"},
 "reporting_rules":["macro-case average is the main axis; micro counts auxiliary only",
   "recall / completeness / overclaim / verified / unverified reported separately",
   "denominator = G1 formal 121 only; quarantine(29), G4 probes, G5/G6 slots, historical toluene NEVER mixed",
   "no ranking equivalence claim between bare LLM scores and EnzymeCrew/EnzymeCAGE (different task formulations)",
   "every synthetic artifact carries fixture_label="+FIX+" and must not be published as a real result"]},
 open(os.path.join(HERE,"report_schema.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True); open(os.path.join(HERE,"report_schema.json"),"a").write("\n")
# ---- sensitivity spec ----
def variant(i,delta):
    w=dict(AXES); base=w[AXES[i][0]]; s={a:(base+delta if a==AXES[i][0] else None) for a,_ in AXES}
    others_sum=100.0-base; target=100.0-(base+delta)
    f=target/others_sum
    for a,_ in AXES:
        if a!=AXES[i][0]: s[a]=w[a]*f
    assert abs(sum(s.values())-100.0)<1e-9
    return s
variants={}
for i,(a,_) in enumerate(AXES):
    for d in (5.0,-5.0):
        variants["%s%+dpp"%(a,int(d))]=variant(i,d)
json.dump({"rule":"primary weight w_i +/-5 percentage points; remaining four weights scaled proportionally to (100-w_i-/+5); sum renormalized to exactly 100",
 "base_weights_pp":dict((a,w) for a,w in AXES),"variants":variants,
 "renorm":"sum==100.0 verified programmatically for all 10 variants","status":"OFFLINE_ONLY_NOT_AUTHORIZED","fixture_label":FIX,
 "scorer_binding":"PENDING (G3 unfrozen)"},
 open(os.path.join(HERE,"sensitivity_spec.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True); open(os.path.join(HERE,"sensitivity_spec.json"),"a").write("\n")
# ---- synthetic corpus ----
os.makedirs(os.path.join(HERE,"synthetic_results"),exist_ok=True)
scen=[]
for c in cases:
    for m in MODELS:
        r={"case_id":c,"model_exact_id":m,"fixture_label":FIX}
        for a,_ in AXES: r[a]=round(u(c,m,a),4)
        r["weighted_total"]=round(sum(r[a]*w/100.0 for a,w in AXES),4)
        r["json_valid"]="Y"; r["schema_valid"]="Y"; r["truncated"]="N"
        r["evidence_verified_n"]=int(u(c,m,"evv")*12); r["evidence_unverified_n"]=int(u(c,m,"evu")*5)
        r["overclaim_flags"]=int(u(c,m,"oc")*3); r["recall_macro"]=round(u(c,m,"rec"),4)
        r["completeness"]=round(u(c,m,"comp"),4); r["abstention_status"]="synthetic"
        scen.append(r)
cols=list(scen[0].keys())
with open(os.path.join(HERE,"synthetic_results","synthetic_per_case_scores.tsv"),"w",encoding="utf-8") as fh:
    fh.write("\t".join(cols)+"\n")
    for r in scen: fh.write("\t".join(str(r[k]) for k in cols)+"\n")
eng=[]
for m in MODELS:
    tk=[int(u("tok",m,str(i))*3000+500) for i in range(4)]
    eng.append({"model_exact_id":m,"tokens_mean":sum(tk)//4,"tokens_median":(tk[1]+tk[2])//2,"tokens_p90":max(tk),
      "tokens_max":max(tk),"latency_s_p90":round(u("lat",m,"x")*120,1),"http_429_n":int(u("429",m,"x")*4),
      "http_5xx_n":int(u("5xx",m,"x")*2),"timeout_n":int(u("to",m,"x")*2),
      "stream_truncation_n":int(u("st",m,"x")*3),"retry_total":int(u("rt",m,"x")*8),
      "fixture_label":FIX})
ec=list(eng[0].keys())
with open(os.path.join(HERE,"synthetic_results","synthetic_engineering.tsv"),"w",encoding="utf-8") as fh:
    fh.write("\t".join(ec)+"\n")
    for r in eng: fh.write("\t".join(str(r[k]) for k in ec)+"\n")
json.dump({"fixture_label":FIX,"generator":"build_g9_preflight.py deterministic sha256-derived",
 "provenance":"NOT real model output; NOT real scorer output; scorer_binding=PENDING_G3_FREEZE",
 "rows":len(scen),"cases":len(cases),"models":MODELS,"api_calls":0,"status":"OFFLINE_ONLY_NOT_AUTHORIZED"},
 open(os.path.join(HERE,"synthetic_results","synthetic_metadata.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True); open(os.path.join(HERE,"synthetic_results","synthetic_metadata.json"),"a").write("\n")
print("G9 preflight built: %d synthetic rows (%d cases x %d models), %d sensitivity variants"%(len(scen),len(cases),len(MODELS),len(variants)))
