# BIOSYSMOdb150 G9 reporting-pipeline test -- SYNTHETIC_OFFLINE_FIXTURE

**SYNTHETIC OFFLINE FIXTURE REPORT. This is NOT a model evaluation result. Do not publish, quote, or rank from it.**

Scorer binding: PENDING (G3 not frozen); science weights teacher-fixed 45/10/20/15/10; corpus = 121 formal cases x 5 models = 605 synthetic rows.
Denominator policy: G1 formal 121 only; quarantine/probe/smoke/pilot/historical toluene excluded. Bare-LLM scores are NOT ranked against EnzymeCrew/EnzymeCAGE (different task).

## 1. Science layers (macro over cases)

| model | pathway | smiles | enzyme | microbial_identity | traits | weighted_total | rank |
|---|---|---|---|---|---|---|---|
| ZHIPU/GLM-5.3 | 0.5490 | 0.5273 | 0.4680 | 0.4709 | 0.4985 | 0.5139 | 1 |
| qwen3.8-flash | 0.4993 | 0.5240 | 0.5127 | 0.4922 | 0.5400 | 0.5075 | 2 |
| deepseek-v4.1-flash | 0.4887 | 0.5047 | 0.4919 | 0.5323 | 0.5078 | 0.4994 | 3 |
| deepseek-v4-pro-0813 | 0.4862 | 0.5155 | 0.4888 | 0.5118 | 0.5371 | 0.4986 | 4 |
| qwen3.8-max | 0.4844 | 0.4940 | 0.4768 | 0.5459 | 0.4995 | 0.4946 | 5 |

## 2. Evidence axis (separate; never folded into science total)

| model | citations_verified | citations_unverified | overclaim_n | evidence_complete_rate |
|---|---|---|---|---|
| ZHIPU/GLM-5.3 | 652 | 222 | 116 | 0.746 |
| deepseek-v4-pro-0813 | 680 | 253 | 107 | 0.729 |
| deepseek-v4.1-flash | 657 | 233 | 128 | 0.738 |
| qwen3.8-flash | 657 | 225 | 126 | 0.745 |
| qwen3.8-max | 661 | 248 | 123 | 0.727 |

## 3. Engineering axis (separate)

| model | tokens_mean | tokens_p90 | latency_s_p90 | 429_n | 5xx_n | timeout_n | truncation_n |
|---|---|---|---|---|---|---|---|
| qwen3.8-flash | 1673 | 2858 | 82.1 | 1 | 0 | 0 | 2 |
| qwen3.8-max | 2187 | 3449 | 108.6 | 3 | 0 | 1 | 0 |
| deepseek-v4-pro-0813 | 1393 | 2321 | 48.0 | 0 | 1 | 0 | 1 |
| deepseek-v4.1-flash | 2965 | 3480 | 9.2 | 0 | 0 | 0 | 2 |
| ZHIPU/GLM-5.3 | 2682 | 3228 | 114.5 | 2 | 0 | 0 | 2 |

## 4. Sensitivity: each main weight +/-5pp, others renormalized to sum 100 (base ranking: ZHIPU/GLM-5.3 > qwen3.8-flash > deepseek-v4.1-flash > deepseek-v4-pro-0813 > qwen3.8-max)

| variant | weights (pp) | per-model total (rank) | max rank shift vs base |
|---|---|---|---|
| enzyme+5pp | pathway:42.19,smiles:9.38,enzyme:25.00,microbial_identity:14.06,traits:9.38 | ZHIPU/GLM-5.3 0.5110(#1); deepseek-v4-pro-0813 0.4980(#4); deepseek-v4.1-flash 0.4989(#3); qwen3.8-flash 0.5078(#2); qwen3.8-max 0.4935(#5) | 0 |
| enzyme-5pp | pathway:47.81,smiles:10.62,enzyme:15.00,microbial_identity:15.94,traits:10.62 | ZHIPU/GLM-5.3 0.5167(#1); deepseek-v4-pro-0813 0.4992(#4); deepseek-v4.1-flash 0.4999(#3); qwen3.8-flash 0.5071(#2); qwen3.8-max 0.4957(#5) | 0 |
| microbial_identity+5pp | pathway:42.35,smiles:9.41,enzyme:18.82,microbial_identity:20.00,traits:9.41 | ZHIPU/GLM-5.3 0.5113(#1); deepseek-v4-pro-0813 0.4993(#4); deepseek-v4.1-flash 0.5013(#3); qwen3.8-flash 0.5066(#2); qwen3.8-max 0.4976(#5) | 0 |
| microbial_identity-5pp | pathway:47.65,smiles:10.59,enzyme:21.18,microbial_identity:10.00,traits:10.59 | ZHIPU/GLM-5.3 0.5164(#1); deepseek-v4-pro-0813 0.4978(#3); deepseek-v4.1-flash 0.4975(#4); qwen3.8-flash 0.5083(#2); qwen3.8-max 0.4916(#5) | 1 |
| pathway+5pp | pathway:50.00,smiles:9.09,enzyme:18.18,microbial_identity:13.64,traits:9.09 | ZHIPU/GLM-5.3 0.5170(#1); deepseek-v4-pro-0813 0.4974(#4); deepseek-v4.1-flash 0.4984(#3); qwen3.8-flash 0.5067(#2); qwen3.8-max 0.4936(#5) | 0 |
| pathway-5pp | pathway:40.00,smiles:10.91,enzyme:21.82,microbial_identity:16.36,traits:10.91 | ZHIPU/GLM-5.3 0.5107(#1); deepseek-v4-pro-0813 0.4997(#4); deepseek-v4.1-flash 0.5004(#3); qwen3.8-flash 0.5082(#2); qwen3.8-max 0.4955(#5) | 0 |
| smiles+5pp | pathway:42.50,smiles:15.00,enzyme:18.89,microbial_identity:14.17,traits:9.44 | ZHIPU/GLM-5.3 0.5146(#1); deepseek-v4-pro-0813 0.4995(#4); deepseek-v4.1-flash 0.4997(#3); qwen3.8-flash 0.5084(#2); qwen3.8-max 0.4945(#5) | 0 |
| smiles-5pp | pathway:47.50,smiles:5.00,enzyme:21.11,microbial_identity:15.83,traits:10.56 | ZHIPU/GLM-5.3 0.5131(#1); deepseek-v4-pro-0813 0.4976(#4); deepseek-v4.1-flash 0.4991(#3); qwen3.8-flash 0.5065(#2); qwen3.8-max 0.4946(#5) | 0 |
| traits+5pp | pathway:42.50,smiles:9.44,enzyme:18.89,microbial_identity:14.17,traits:15.00 | ZHIPU/GLM-5.3 0.5130(#1); deepseek-v4-pro-0813 0.5007(#3); deepseek-v4.1-flash 0.4999(#4); qwen3.8-flash 0.5093(#2); qwen3.8-max 0.4948(#5) | 1 |
| traits-5pp | pathway:47.50,smiles:10.56,enzyme:21.11,microbial_identity:15.83,traits:5.00 | ZHIPU/GLM-5.3 0.5147(#1); deepseek-v4-pro-0813 0.4964(#4); deepseek-v4.1-flash 0.4989(#3); qwen3.8-flash 0.5056(#2); qwen3.8-max 0.4943(#5) | 0 |

**Reminder: every number above is deterministic synthetic fixture data (sha256-derived). api_calls=0.**
