# G9_reporting_preflight

Reporting pipeline preflight: science layers 45/10/20/15/10 (teacher-immutable) kept separate from evidence and engineering axes; per-axis templates are header-only; sensitivity_spec defines ±5pp shifts with proportional renormalization to exactly 100 (10 variants, programmatically verified); synthetic_results/ holds 605 deterministic sha256-derived SYNTHETIC rows over the G1 formal 121 only. SYNTHETIC_G9_REPORT.md renders macro/micro, evidence, engineering and sensitivity tables under a loud do-not-publish banner. G3 unfrozen => scorer binding PENDING, no real scorer hash tied.

Status: OFFLINE_ONLY_NOT_AUTHORIZED | next_stage_allowed=false | api_calls=0
