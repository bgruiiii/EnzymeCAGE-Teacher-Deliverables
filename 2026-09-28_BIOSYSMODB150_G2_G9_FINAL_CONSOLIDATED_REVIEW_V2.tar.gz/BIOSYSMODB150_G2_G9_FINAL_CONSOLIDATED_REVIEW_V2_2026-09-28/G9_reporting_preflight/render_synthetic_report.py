#!/usr/bin/env python3
"""render_synthetic_report.py -- render the SYNTHETIC_OFFLINE_FIXTURE pipeline
test report from G9_reporting_preflight/synthetic_results/ only. Never reads a
real model answer, never calls the scorer on real data. Output is heavily
labelled and must not be published as a result. Zero API."""
import json, os
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
G2=os.path.join(STAGE,"G2_questions")
FIX="SYNTHETIC_OFFLINE_FIXTURE"
AXES=[("pathway",45.0),("smiles",10.0),("enzyme",20.0),("microbial_identity",15.0),("traits",10.0)]
def rows(p):
    lines=open(p,encoding="utf-8").read().rstrip("\n").split("\n"); hdr=lines[0].split("\t")
    return [dict(zip(hdr,l.split("\t"))) for l in lines[1:]]
data=rows(os.path.join(HERE,"synthetic_results","synthetic_per_case_scores.tsv"))
eng=rows(os.path.join(HERE,"synthetic_results","synthetic_engineering.tsv"))
meta=json.load(open(os.path.join(HERE,"synthetic_results","synthetic_metadata.json"),encoding="utf-8"))
sens=json.load(open(os.path.join(HERE,"sensitivity_spec.json"),encoding="utf-8"))
cases=sorted(json.loads(l)["case_id"] for l in open(os.path.join(G2,"main_cases.jsonl"),encoding="utf-8"))
assert {r["case_id"] for r in data}==set(cases), "synthetic corpus must be exactly the G1 formal 121"
assert meta["fixture_label"]==FIX
MODELS=sorted({r["model_exact_id"] for r in data})
def macro(axis):
    return {m:sum(float(r[axis]) for r in data if r["model_exact_id"]==m)/len(cases) for m in MODELS}
M={a:macro(a) for a,_ in AXES}
def weighted(weights): return {m:sum(M[a][m]*weights[a]/100.0 for a,_ in AXES) for m in MODELS}
base=weighted(dict(AXES))
rank=lambda sc:[m for m,_ in sorted(sc.items(),key=lambda kv:(-kv[1],kv[0]))]
brank=rank(base)
L=["# BIOSYSMOdb150 G9 reporting-pipeline test -- "+FIX,"",
"**SYNTHETIC OFFLINE FIXTURE REPORT. This is NOT a model evaluation result. Do not publish, quote, or rank from it.**","",
"Scorer binding: PENDING (G3 not frozen); science weights teacher-fixed 45/10/20/15/10; corpus = 121 formal cases x 5 models = %d synthetic rows."%len(data),
"Denominator policy: G1 formal 121 only; quarantine/probe/smoke/pilot/historical toluene excluded. Bare-LLM scores are NOT ranked against EnzymeCrew/EnzymeCAGE (different task).","",
"## 1. Science layers (macro over cases)","",
"| model | "+" | ".join(a for a,_ in AXES)+" | weighted_total | rank |",
"|"+"---|"*(len(AXES)+3)]
for m in brank:
    L.append("| %s | "%m+" | ".join("%.4f"%M[a][m] for a,_ in AXES)+" | %.4f | %d |"%(base[m],brank.index(m)+1))
L+=["","## 2. Evidence axis (separate; never folded into science total)","",
"| model | citations_verified | citations_unverified | overclaim_n | evidence_complete_rate |","|---|---|---|---|---|"]
for m in MODELS:
    vv=sum(int(r["evidence_verified_n"]) for r in data if r["model_exact_id"]==m)
    uu=sum(int(r["evidence_unverified_n"]) for r in data if r["model_exact_id"]==m)
    oc=sum(int(r["overclaim_flags"]) for r in data if r["model_exact_id"]==m)
    L.append("| %s | %d | %d | %d | %.3f |"%(m,vv,uu,oc,vv/(vv+uu)))
L+=["","## 3. Engineering axis (separate)","",
"| model | tokens_mean | tokens_p90 | latency_s_p90 | 429_n | 5xx_n | timeout_n | truncation_n |","|---|---|---|---|---|---|---|---|"]
for e in eng:
    L.append("| %s | %s | %s | %s | %s | %s | %s | %s |"%(e["model_exact_id"],e["tokens_mean"],e["tokens_p90"],
        e["latency_s_p90"],e["http_429_n"],e["http_5xx_n"],e["timeout_n"],e["stream_truncation_n"]))
L+=["","## 4. Sensitivity: each main weight +/-5pp, others renormalized to sum 100 (base ranking: %s)"%(" > ".join(brank)),"",
"| variant | weights (pp) | per-model total (rank) | max rank shift vs base |","|---|---|---|---|"]
for name,ws in sens["variants"].items():
    sc=weighted(ws); rk=rank(sc)
    L.append("| %s | %s | %s | %d |"%(name,",".join("%s:%.2f"%(a,ws[a]) for a,_ in AXES),
        "; ".join("%s %.4f(#%d)"%(m,sc[m],rk.index(m)+1) for m in MODELS),
        max(abs(brank.index(m)-rk.index(m)) for m in MODELS)))
L+=["","**Reminder: every number above is deterministic synthetic fixture data (sha256-derived). api_calls=0.**",""]
open(os.path.join(HERE,"SYNTHETIC_G9_REPORT.md"),"w",encoding="utf-8").write("\n".join(L))
print("rendered SYNTHETIC_G9_REPORT.md: %d rows, %d sensitivity variants, api_calls=0"%(len(data),len(sens["variants"])))
