#!/usr/bin/env python3
"""validate_g9_preflight.py -- independent validation of the G9 reporting
preflight: recomputes the ±5pp sensitivity math, the synthetic weighted totals
and the macro report from raw rows; enforces denominator hygiene (formal 121, no
quarantine ids), synthetic labelling, and PENDING scorer binding.
--selftest-mutations proves it is not PASS-hardcoded. Read-only, zero API."""
import hashlib, json, os, shutil, sys, tempfile
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
G2=os.path.join(STAGE,"G2_questions"); QT=os.path.join(STAGE,"quarantine")
FIX="SYNTHETIC_OFFLINE_FIXTURE"
AXES=[("pathway",45.0),("smiles",10.0),("enzyme",20.0),("microbial_identity",15.0),("traits",10.0)]
BASE=dict(AXES)
def rows(p):
    lines=open(p,encoding="utf-8").read().rstrip("\n").split("\n"); hdr=lines[0].split("\t")
    return [dict(zip(hdr,l.split("\t"))) for l in lines[1:]]
def expected_variant(i,d):
    bi=BASE[AXES[i][0]]; f=(100.0-(bi+d))/(100.0-bi)
    return {a:(bi+d if a==AXES[i][0] else BASE[a]*f) for a,_ in AXES}
def validate(d):
    errs=[];oks=[]
    def ck(c,m): (oks if c else errs).append(m)
    sens=json.load(open(os.path.join(d,"sensitivity_spec.json"),encoding="utf-8"))
    ck(sens["base_weights_pp"]==BASE,"base_weights_45_10_20_15_10")
    ck(len(sens["variants"])==10,"ten_variants")
    for i,(a,_) in enumerate(AXES):
        for sgn in (5,-5):
            name="%s%+dpp"%(a,sgn); got=sens["variants"][name]; exp=expected_variant(i,float(sgn))
            ck(abs(sum(got.values())-100.0)<1e-9 and all(abs(got[k]-exp[k])<1e-9 for k in got),"variant_ok:"+name)
    data=rows(os.path.join(d,"synthetic_results","synthetic_per_case_scores.tsv"))
    ck(len(data)==605,"synthetic_605_rows")
    ck(all(r["fixture_label"]==FIX for r in data),"all_rows_synthetic_labelled")
    cases=sorted(json.loads(l)["case_id"] for l in open(os.path.join(G2,"main_cases.jsonl"),encoding="utf-8"))
    ck(sorted({r["case_id"] for r in data})==cases and len(cases)==121,"denominator_is_formal_121")
    qf=os.path.join(QT,"cases.tsv")
    qlines=rows(qf) if os.path.exists(qf) else []
    qids={r.get("case_id") or r.get("original_case_id") for r in qlines}
    ck(bool(qids) and not (qids & {r["case_id"] for r in data}),"no_quarantine_in_corpus(%d quarantined)"%len(qids))
    ck({r["model_exact_id"] for r in data}=={"qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"},"five_exact_model_ids")
    bad=0
    for r in data:
        t=sum(float(r[a])*BASE[a]/100.0 for a,_ in AXES)
        if abs(t-float(r["weighted_total"]))>5e-4: bad+=1
    ck(bad==0,"weighted_totals_recompute(bad=%d)"%bad)
    rep=open(os.path.join(d,"SYNTHETIC_G9_REPORT.md"),encoding="utf-8").read()
    ck(FIX in rep.splitlines()[0],"banner_in_title")
    ck("NOT a model evaluation result" in rep and "Do not publish" in rep,"not_publishable_wording")
    ck("EnzymeCrew" in rep and "different task" in rep,"no_false_comparability_claim")
    ck("121" in rep,"formal_121_disclosed")
    # independent macro recompute vs §1 table
    models=sorted({r["model_exact_id"] for r in data})
    mac={a:{m:sum(float(r[a]) for r in data if r["model_exact_id"]==m)/121.0 for m in models} for a,_ in AXES}
    tw={m:sum(mac[a][m]*BASE[a]/100.0 for a,_ in AXES) for m in models}
    tabok=True
    for line in rep.splitlines():
        if line.startswith("| ") and line.count("|")>=9 and "macro" not in line and line.split("|")[1].strip() in models:
            cells=[c.strip() for c in line.strip("|").split("|")]
            m=cells[0]
            if len(cells)>=7 and cells[6].count(".")>0 and cells[6]!="model":
                try:
                    if abs(float(cells[6])-tw[m])>5e-4: tabok=False
                except ValueError: pass
    ck(tabok,"report_macro_table_matches_recompute")
    for f,need in (("per_case_result.template.tsv","case_id"),("per_model_summary.template.tsv","model_exact_id"),
                   ("evidence_axis.template.tsv","citations_verified_n"),("engineering_axis.template.tsv","tokens_p90")):
        ls=open(os.path.join(d,f),encoding="utf-8").read().rstrip("\n").split("\n")
        ck(len(ls)==1 and need in ls[0],"template_header_only:%s"%f)
    sch=json.load(open(os.path.join(d,"report_schema.json"),encoding="utf-8"))
    ck("PENDING" in sch["scorer_binding"],"scorer_binding_pending")
    ck(sch["axes"]["evidence_axis"]!="science" and "independent" in sch["axes"]["evidence_axis"],"axes_independent")
    meta=json.load(open(os.path.join(d,"synthetic_results","synthetic_metadata.json"),encoding="utf-8"))
    ck(meta["api_calls"]==0 and meta["fixture_label"]==FIX and "PENDING" in meta["provenance"],"meta_api0_pending")
    return errs,oks
def _mut(d,which):
    if which=="variant_sum":
        j=json.load(open(os.path.join(d,"sensitivity_spec.json"),encoding="utf-8"))
        j["variants"]["pathway+5pp"]["enzyme"]+=10.0
        json.dump(j,open(os.path.join(d,"sensitivity_spec.json"),"w"),ensure_ascii=False,sort_keys=True)
    elif which=="relabel_row":
        p=os.path.join(d,"synthetic_results","synthetic_per_case_scores.tsv")
        ls=open(p,encoding="utf-8").read().split("\n"); ls[1]=ls[1].replace(FIX,"REAL_RESULT"); open(p,"w",encoding="utf-8").write("\n".join(ls))
    elif which=="inject_quarantine":
        # BIOPATH150_040 is teacher-confirmed quarantined (approval 2026-09-27 section 一.1), not in formal 121
        p=os.path.join(d,"synthetic_results","synthetic_per_case_scores.tsv")
        ls=open(p,encoding="utf-8").read().rstrip("\n").split("\n")
        ls[1]=ls[1].replace("BIOPATH150_","BIOPATH150_",1)  # keep row count; swap this row's case to a quarantined id
        cells=ls[1].split("\t"); cells[0]="BIOPATH150_040"; ls[1]="\t".join(cells)
        open(p,"w",encoding="utf-8").write("\n".join(ls)+"\n")
    elif which=="banner_removed":
        p=os.path.join(d,"SYNTHETIC_G9_REPORT.md"); s=open(p,encoding="utf-8").read().replace("SYNTHETIC OFFLINE FIXTURE REPORT. This is NOT a model evaluation result. Do not publish, quote, or rank from it.","Model evaluation results."); open(p,"w",encoding="utf-8").write(s)
    elif which=="base_weight":
        j=json.load(open(os.path.join(d,"sensitivity_spec.json"),encoding="utf-8")); j["base_weights_pp"]["pathway"]=46.0
        json.dump(j,open(os.path.join(d,"sensitivity_spec.json"),"w"),ensure_ascii=False,sort_keys=True)
MUTS=["variant_sum","relabel_row","inject_quarantine","banner_removed","base_weight"]
def selftest():
    ok=True
    for mu in MUTS:
        tmp=tempfile.mkdtemp(prefix="g9mut_"); dst=os.path.join(tmp,"g9")
        shutil.copytree(HERE,dst,ignore=shutil.ignore_patterns("__pycache__"))
        _mut(dst,mu); errs,_=validate(dst); det=bool(errs); ok=ok and det
        print(("OK  " if det else "FAIL ")+"mutation %s detected: %s"%(mu,errs[0] if errs else "NOT-DETECTED"))
        shutil.rmtree(tmp,ignore_errors=True)
    return ok
def main():
    if "--selftest-mutations" in sys.argv: sys.exit(0 if selftest() else 1)
    errs,oks=validate(HERE)
    print("g9_preflight validator: %d ok, %d errors"%(len(oks),len(errs)))
    for e in errs: print("ERR "+e)
    sys.exit(0 if not errs else 1)
if __name__=="__main__": main()
