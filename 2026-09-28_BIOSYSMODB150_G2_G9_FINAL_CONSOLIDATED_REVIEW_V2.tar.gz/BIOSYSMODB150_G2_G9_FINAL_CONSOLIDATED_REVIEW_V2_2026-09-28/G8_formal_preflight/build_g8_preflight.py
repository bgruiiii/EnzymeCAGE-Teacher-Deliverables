#!/usr/bin/env python3
"""build_g8_preflight.py -- deterministic G8 formal 121x5=605 task matrix +
run/storage/resume/archive preflight. SYNTHETIC_OFFLINE_PREFLIGHT: zero dispatch,
zero key read. All rows NOT_DISPATCHED. Bindings awaiting teacher G7 signoff are
recorded as PENDING_* -- never filled with invented defaults."""
import hashlib, json, os
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
ROOT=os.path.abspath(os.path.join(STAGE,os.pardir))
COLLECTOR=os.path.join(ROOT,"24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")
MODELS=["qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"]
G2=os.path.join(STAGE,"G2_questions"); G1=os.path.join(STAGE,"G1_gold")
def sha(p): return hashlib.sha256(open(p,"rb").read()).hexdigest()
def sha_file_dirname(p): return os.path.basename(p)
# ---- inputs (read-only) ----
ph={}
for l in open(os.path.join(G2,"prompt_hashes.tsv"),encoding="utf-8"):
    c=l.rstrip("\n").split("\t")
    if c[0]=="case_id": hdr=c; continue
    ph[c[0]]=dict(zip(hdr,c))
g1counts=json.load(open(os.path.join(G1,"counts.json"),encoding="utf-8"))
cases=[json.loads(l) for l in open(os.path.join(G2,"main_cases.jsonl"),encoding="utf-8")]
assert len(cases)==121 and len(ph)==121, "input state drift: %d cases, %d hash rows"%(len(cases),len(ph))
formal_n=g1counts.get("final_n")
assert str(formal_n)=="121", "G1 formal_n drift: %r"%formal_n
cases.sort(key=lambda c:c["case_id"])
g2man=sha(os.path.join(G2,"G2_questions.manifest.json"))
g2manifest=json.load(open(os.path.join(G2,"G2_questions.manifest.json"),encoding="utf-8"))
PROMPT_SHA=g2manifest["collector_prompt_sha256"]
g1man=sha(os.path.join(G1,"G1_gold.manifest.json"))
# ---- matrix ----
HDR=["case_id","model_exact_id","phase","status","experiment_version_slot","idempotency_key_template",
     "messages_sha256","rendered_prompt_sha256","prompt_sha256","prompt_template_sha256",
     "blank_template_sha256","answer_schema_sha256","search_policy_sha256","scorer_sha256",
     "param_contract_sha256","dispatch_api_calls","fixture_label"]
rows=[]
for c in cases:
    cid=c["case_id"]; h=ph[cid]
    for m in MODELS:
        rows.append([cid,m,"formal","NOT_DISPATCHED","PENDING_G7_SIGNED_EXPERIMENT_VERSION",
          "sha256(phase|experiment_version|%s|%s|request_body_sha252:bound_at_dispatch)"%(cid,m),
          h["messages_sha256"],h["rendered_prompt_sha256"],PROMPT_SHA,
          h["prompt_template_sha256"],h["blank_template_sha256"],h["answer_schema_sha256"],
          "PENDING_G4_SEARCH_DECISION_AND_G7_BIND","PENDING_G3_FREEZE_AND_G7_BIND","PENDING_PARAM_DOC_VERIFICATION_AND_G7_BIND",
          "0","SYNTHETIC_OFFLINE_PREFLIGHT"])
assert len(rows)==605
with open(os.path.join(HERE,"formal_task_matrix.tsv"),"w",encoding="utf-8") as fh:
    fh.write("\t".join(HDR)+"\n")
    for r in rows: fh.write("\t".join(str(x) for x in r)+"\n")
# ---- completion matrix template ----
CH=["case_id","n_models_target","attempts_total","responses_captured","json_valid","schema_valid",
    "truncated_length","transport_retry_total","completion_status"]
with open(os.path.join(HERE,"completion_matrix.template.tsv"),"w",encoding="utf-8") as fh:
    fh.write("\t".join(CH)+"\n")
    for c in cases:
        fh.write("\t".join([c["case_id"],"5","0","0","0","0","0","0","NOT_STARTED"])+"\n")
# ---- policy / layout / spec (fixed text; deterministic) ----
json.dump({
 "stage":"G8_formal_preflight","status":"OFFLINE_ONLY_NOT_AUTHORIZED","next_stage_allowed":False,
 "fixture_label":"SYNTHETIC_OFFLINE_PREFLIGHT","api_calls":0,"dispatch_rows":0,
 "matrix_rows":605,"formal_n":121,"models":MODELS,
 "authorization":"G8 requires teacher G7 budget signoff binding dataset/prompt/schema/scorer/params/search-policy hashes; not granted 2026-09-28",
 "phase_isolation":{"formal_experiment_version_slot":"PENDING_G7","note":"formal idempotency keys embed phase=formal and a signed experiment_version; G4/G5/G6 keys (phase=G4_search/G5_smoke/G6_pilot) can never collide with formal keys; smoke/pilot/search results do NOT count toward or deduct from formal 605"},
 "retry_policy":{"transport_errors_only":["HTTP_429","HTTP_5xx","connect/read timeout","TLS/transport failure"],
   "max_transport_retries_per_request":2,"backoff":"respect Retry-After, else frozen exponential schedule",
   "content_errors_never_retried":["schema INVALID","non-JSON","empty visible body","finish_reason=length"],
   "no_second_round_authorization":"failed slots produce reports, not automatic new paid retries"},
 "concurrency":"TEMPLATE_UNSET_BY_TEACHER (prompt: 正式并发只留模板,不凭空决定)","concurrency_placeholder":"MAX_CONCURRENCY=TBD_IN_G7",
 "budget":{"expected_api_calls":605,"counted_against_teacher_80_cap":False,
   "teacher_80_cap_scope":"G4(<=15)+G5(15)+G6(50) preflight phases only; G8 formal requires separate approval (teacher reply section 三)"},
 "bindings_pending_G7":["search_policy_sha256","scorer_sha256 (G3 not frozen)","param_contract_sha256 (UNKNOWN fields must be doc-verified, never defaulted)"],
 "upstream_gate_bindings":{"g1_manifest_sha256":g1man,"g2_manifest_sha256":g2man,"g2_status":"READY_FOR_REVIEW","g3_frozen":False}},
 open(os.path.join(HERE,"formal_run_policy.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True); open(os.path.join(HERE,"formal_run_policy.json"),"a").write("\n")
open(os.path.join(HERE,"storage_layout.txt"),"w",encoding="utf-8").write("""G8 formal run storage layout (template; mirrors collector v2 archive, nothing is written here now)
runs/<run_id>/
  cases.jsonl                      frozen G2 121-case input copy
  limits.json                      signed budget+phase caps (from G7)
  manifest.json                    run manifest binding dataset/prompt/schema/scorer/params hashes
  attempts/<case_id>__<model_exact_id>/attempt_NNN/
    request_body.json              exact body (model fixed exact ID; never altered afterwards)
    request_body_sha256.txt        -> component of idempotency key
    raw_stream.sse                 raw SSE bytes, verbatim (duplicate chunks kept)
    http_headers.json              status + Retry-After etc, verbatim
    error.txt                      transport error text if any, verbatim
    visible_answer.txt             final visible content only (no rewrite)
    reasoning.txt                  reasoning channel if present (kept separate, never merged into answer)
    timing.json                    start/end ms, per-chunk cadence
    usage.json                     provider usage object, verbatim
    validation.json                json_parse_status / schema_status / errors / warnings
  normalized/<case_id>__<model_exact_id>.json   selected attempt + full lineage (attempt ids, idempotency key)
  summary/completion_matrix.tsv    121-row completion matrix (filled version of completion_matrix.template.tsv)
  summary/task_status.tsv          per-slot final state (terminal states immutable)
SHA256SUMS                         covers all of the above except this file; excludes __pycache__/.py
""")
open(os.path.join(HERE,"resume_and_idempotency_spec.md"),"w",encoding="utf-8").write("""# G8 resume & idempotency spec (preflight, unexecuted)

- idempotency key = sha256(phase | experiment_version | case_id | model_exact_id | request_body_sha256).
  phase='formal' and the G7-signed experiment_version make formal keys disjoint from G4_search/G5_smoke/G6_pilot keys,
  so preflight results can never be reused as, or deducted from, formal slots (and vice versa).
- A slot with a terminal attempt (COMPLETE captured, or content-saved INVALID/EMPTY/length) is never re-dispatched on resume.
  Content errors are terminal states; only transport failures (429/5xx/timeout) retry, max 2 extra attempts, identical body.
- Crash between raw-attempt write and summary write: on resume, summary is rebuilt from saved attempts;
  no new transport calls occur (proven offline in failure_rehearsal scenarios 12/13/14).
- Retries reuse the same idempotency key and request_body_sha256; attempts keep distinct attempt ids.
- Resume never creates a second paid authorization round (teacher: G5-style failure repair needs re-approval; same rule inherited).
- Budget accounting: api_calls increments only on actual dispatch; refused dispatches (cap/envelope/gate) never consume budget.
""")
json.dump({"archive_format":"tar.zst","include":["runs/<run_id>/**","SHA256SUMS","manifest.json"],
 "exclude":["**/__pycache__/**","**.pyc","**/.env","**/*api*key*","G1_gold/**","G3_scorer/**gold*","**/hidden*"],
 "integrity":"per-file SHA256SUMS inside archive + top-level manifest sha recorded in gate file",
 "privacy":"no absolute local paths inside archive records; endpoint referenced by env-var name only (DASHSCOPE_API_KEY), value never stored",
 "upload_status":"CHENYU_UPLOAD_REQUIRED=false for this preflight","status":"OFFLINE_ONLY_NOT_AUTHORIZED"},
 open(os.path.join(HERE,"archive_spec.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True); open(os.path.join(HERE,"archive_spec.json"),"a").write("\n")
# ---- self check ----
rows2=[l.rstrip("\n").split("\t") for l in open(os.path.join(HERE,"formal_task_matrix.tsv"),encoding="utf-8")][1:]
per_case={}
for r in rows2: per_case.setdefault(r[0],set()).add(r[6])
assert all(len(v)==1 for v in per_case.values())
print("G8 preflight built: matrix=%d rows, cases=%d, per-case hash uniform=%s, api_calls=0"%(len(rows2),len(per_case),all(len(v)==1 for v in per_case.values())))
