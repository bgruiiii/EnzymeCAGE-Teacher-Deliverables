#!/usr/bin/env python3
"""validate_g8_preflight.py -- independent validator for the G8 formal preflight.
Re-derives every fact from the frozen G2 artifacts on disk; never imports the
builder. Mutation self-test proves it is not PASS-hardcoded. Zero API, read-only."""
import hashlib, json, os, shutil, sys, tempfile
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
G2=os.path.join(STAGE,"G2_questions")
MODELS={"qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"}
def sha(p): return hashlib.sha256(open(p,"rb").read()).hexdigest()
def load(d,f): return json.load(open(os.path.join(d,f),encoding="utf-8"))
def rows(d,f):
    lines=open(os.path.join(d,f),encoding="utf-8").read().rstrip("\n").split("\n")
    hdr=lines[0].split("\t")
    return [dict(zip(hdr,l.split("\t"))) for l in lines[1:] if l]
def validate(d):
    errs=[];oks=[]
    def ck(c,msg): (oks if c else errs).append(msg)
    ck(sha(os.path.join(G2,"G2_questions.manifest.json"))==load(d,"formal_run_policy.json")["upstream_gate_bindings"]["g2_manifest_sha256"],"g2_manifest_hash_bound")
    ck(sha(os.path.join(STAGE,"G1_gold","G1_gold.manifest.json"))==load(d,"formal_run_policy.json")["upstream_gate_bindings"]["g1_manifest_sha256"],"g1_manifest_hash_bound")
    ck(load(d,"formal_run_policy.json")["status"]=="OFFLINE_ONLY_NOT_AUTHORIZED","policy_offline_status")
    ck(load(d,"formal_run_policy.json")["api_calls"]==0 and load(d,"formal_run_policy.json")["dispatch_rows"]==0,"policy_api_zero")
    ck(load(d,"formal_run_policy.json")["expected_api_calls"]==605 if "expected_api_calls" in load(d,"formal_run_policy.json") else load(d,"formal_run_policy.json")["budget"]["expected_api_calls"]==605,"budget_605")
    mx=rows(d,"formal_task_matrix.tsv")
    ck(len(mx)==605,"matrix_605_rows(got %d)"%len(mx))
    ck(all(r["status"]=="NOT_DISPATCHED" for r in mx),"all_NOT_DISPATCHED")
    ck(all(r["dispatch_api_calls"]=="0" for r in mx),"dispatch_calls_zero")
    ck(all(r["phase"]=="formal" for r in mx),"phase_formal")
    keys=[(r["case_id"],r["model_exact_id"]) for r in mx]
    ck(len(set(keys))==605,"no_duplicate_case_model_slots")
    cases=sorted({r["case_id"] for r in mx}); models=set(r["model_exact_id"] for r in mx)
    ck(len(cases)==121,"121_cases")
    ck(models==MODELS,"exact_5_model_ids")
    per={}
    for r in mx: per.setdefault(r["case_id"],set()).add(r["messages_sha256"])
    ck(all(len(v)==1 for v in per.values()),"per_case_messages_hash_uniform")
    # independent 3-way: G2 prompt_hashes.tsv == embedded rendered messages_sha256 == matrix
    g2rows={r["case_id"]:r for r in rows(G2,"prompt_hashes.tsv")}
    rmcases=sorted(json.loads(l)["case_id"] for l in open(os.path.join(G2,"main_cases.jsonl"),encoding="utf-8"))
    ck(rmcases==cases,"case_list_matches_G2")
    bad=[]
    for c in cases:
        emb=load(G2,os.path.join("rendered_messages",c+".json"))["messages_sha256"]
        if not (per[c]=={emb} and g2rows[c]["messages_sha256"]==emb): bad.append(c)
    ck(not bad,"messages_hash_3way_consistent(bad=%s)"%bad[:3])
    ck(all(r["scorer_sha256"].startswith("PENDING") for r in mx),"scorer_pending_G3_unfrozen")
    ck(all(r["search_policy_sha256"].startswith("PENDING") for r in mx),"search_policy_pending")
    ck(all(r["param_contract_sha256"].startswith("PENDING") for r in mx),"param_contract_pending_no_defaults")
    tsv=open(os.path.join(d,"formal_task_matrix.tsv"),encoding="utf-8").read()
    ck("/home/" not in tsv and "DASHSCOPE_API_KEY=" not in tsv,"matrix_no_privacy_or_key")
    cm=rows(d,"completion_matrix.template.tsv")
    ck(len(cm)==121 and all(r["completion_status"]=="NOT_STARTED" and r["n_models_target"]=="5" for r in cm),"completion_template_121_NOT_STARTED")
    for f in ("storage_layout.txt","resume_and_idempotency_spec.md","archive_spec.json"):
        ck(os.path.exists(os.path.join(d,f)),"exists:%s"%f)
    ar=load(d,"archive_spec.json")
    ck(any("G1_gold" in x for x in ar["exclude"]) and any("G3_scorer" in x for x in ar["exclude"]),"archive_excludes_gold_scorer")
    ck(ar["upload_status"].startswith("CHENYU_UPLOAD_REQUIRED=false"),"archive_no_upload")
    pol=load(d,"formal_run_policy.json")
    ck("TBD" in pol["concurrency_placeholder"] or "UNSET" in pol["concurrency"],"concurrency_left_as_template")
    ck(pol["retry_policy"]["content_errors_never_retried"] and pol["retry_policy"]["transport_errors_only"],"retry_split_content_vs_transport")
    return errs,oks
def _mutate(d,which):
    p=os.path.join(d,"formal_task_matrix.tsv"); lines=open(p,encoding="utf-8").read().split("\n")
    if which=="status_to_dispatched":
        for i,l in enumerate(lines):
            if l.startswith("BIOPATH150_001\tqwen3.8-max"): lines[i]=l.replace("\tNOT_DISPATCHED\t","\tDISPATCHED\t"); break
    elif which=="hash_swap":
        for i,l in enumerate(lines):
            if l.startswith("BIOPATH150_002\tqwen3.8-max"):
                c=l.split("\t"); c[6]="0"*64; lines[i]="\t".join(c); break
    elif which=="drop_row": del lines[1]  # first data row
    open(p,"w",encoding="utf-8").write("\n".join(lines))
    if which=="budget_edit":
        j=load(d,"formal_run_policy.json"); j["budget"]["expected_api_calls"]=606
        json.dump(j,open(os.path.join(d,"formal_run_policy.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True)
    if which=="completion_done":
        p2=os.path.join(d,"completion_matrix.template.tsv"); l2=open(p2,encoding="utf-8").read().split("\n")
        l2[1]=l2[1].replace("NOT_STARTED","DONE"); open(p2,"w",encoding="utf-8").write("\n".join(l2))
MUTS=["status_to_dispatched","hash_swap","drop_row","budget_edit","completion_done"]
def selftest():
    ok=True
    for mu in MUTS:
        tmp=tempfile.mkdtemp(prefix="g8mut_"); dst=os.path.join(tmp,"g8")
        shutil.copytree(HERE,dst,ignore=shutil.ignore_patterns("__pycache__"))
        _mutate(dst,mu)
        errs,_=validate(dst)
        det=bool(errs); ok=ok and det
        print(("OK  " if det else "FAIL ")+"mutation %s detected: %s"%(mu,errs[0] if errs else "NOT-DETECTED"))
        shutil.rmtree(tmp,ignore_errors=True)
    return ok
def main():
    if "--selftest-mutations" in sys.argv: sys.exit(0 if selftest() else 1)
    errs,oks=validate(HERE)
    print("g8_preflight validator: %d ok, %d errors"%(len(oks),len(errs)))
    for e in errs: print("ERR "+e)
    sys.exit(0 if not errs else 1)
if __name__=="__main__": main()
