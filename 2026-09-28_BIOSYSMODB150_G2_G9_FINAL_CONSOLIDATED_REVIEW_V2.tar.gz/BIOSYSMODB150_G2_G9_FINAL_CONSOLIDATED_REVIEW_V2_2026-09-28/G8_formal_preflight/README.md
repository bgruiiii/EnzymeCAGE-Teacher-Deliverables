# G8_formal_preflight

Formal 121x5=605 task matrix (all NOT_DISPATCHED, dispatch_api_calls=0), run policy, storage layout, resume/idempotency spec, completion template, archive spec. Per-case messages_sha256 identical across the five model rows and cross-checked three-way against G2 prompt_hashes.tsv and the embedded rendered-message records. search_policy/scorer/param bindings are PENDING_* (G4 decision / G3 freeze / G7 signoff) -- never defaulted. Concurrency deliberately left as a template placeholder.

Status: OFFLINE_ONLY_NOT_AUTHORIZED | next_stage_allowed=false | api_calls=0
