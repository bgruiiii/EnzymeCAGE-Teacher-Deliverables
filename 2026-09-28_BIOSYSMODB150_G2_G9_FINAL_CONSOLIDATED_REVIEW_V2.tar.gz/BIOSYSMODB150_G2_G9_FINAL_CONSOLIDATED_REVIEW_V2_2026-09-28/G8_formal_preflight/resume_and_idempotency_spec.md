# G8 resume & idempotency spec (preflight, unexecuted)

- idempotency key = sha256(phase | experiment_version | case_id | model_exact_id | request_body_sha256).
  phase='formal' and the G7-signed experiment_version make formal keys disjoint from G4_search/G5_smoke/G6_pilot keys,
  so preflight results can never be reused as, or deducted from, formal slots (and vice versa).
- A slot with a terminal attempt (COMPLETE captured, or content-saved INVALID/EMPTY/length) is never re-dispatched on resume.
  Content errors are terminal states; only transport failures (429/5xx/timeout) retry, max 2 extra attempts, identical body.
- Crash between raw-attempt write and summary write: on resume, summary is rebuilt from saved attempts;
  no new transport calls occur (proven offline in failure_rehearsal scenarios 12/13/14).
- Retries reuse the same idempotency key and request_body_sha256; attempts keep distinct attempt ids.
- Resume never creates a second paid authorization round (teacher: G5-style failure repair needs re-approval; same rule inherited).
- Budget accounting: api_calls increments only on actual dispatch; refused dispatches (cap/envelope/gate) never consume budget.
