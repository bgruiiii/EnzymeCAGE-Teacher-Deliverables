# G5 smoke preflight (PREPARED_NOT_AUTHORIZED_TO_RUN)
3 cases short/mid/long selected deterministically (no model-performance), 15 slots (5x3) NOT_DISPATCHED. Gate: 15/15 usable JSON object; syntax/object/schema three rates separate; null/array never an answer. No dispatch this round.
