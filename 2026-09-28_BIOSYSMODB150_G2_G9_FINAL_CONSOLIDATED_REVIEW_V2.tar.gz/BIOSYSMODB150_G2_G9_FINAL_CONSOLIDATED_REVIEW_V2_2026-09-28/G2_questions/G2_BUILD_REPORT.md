# G2 question rendering and leakage audit (READY_FOR_REVIEW)

- formal cases: **121** (G1 PASS, teacher approval bound); every case rendered with the FROZEN collector prompt/template/schema -- the messages are byte-identical to the future five-model dispatch (single user message, no system message, per the frozen contract design).

- prompt/template/schema SHAs: `8d843c393c18912a` / `3f55c0de8e9fa5c9` / `ebf2d47fd4737d7b` (collector files, read-only copies)


## 1. Unexplained leakage: **0**

- the scan covers the COMPLETE final user message of every case: case metadata block + full blank JSON template (one empty step / profile / evidence member format, 15 trait fields) + compact v2 schema + all enums and rules. The forbidden set per case comes only from that case's own G1 gold (names/aliases, terminals, enzymes, ECs, organisms, TaxIDs, record ids, SMILES, step labels).

- hit classifications: `{"SCAN_TOKEN_GATED": 901, "POLLUTANT_NAME_ALLOWED": 144, "ROUTE_GOLD_COLLISION": 20}`


## 2. ROUTE_GOLD_COLLISION (teacher review)

- BIOPATH150_009: perillate(MAIN_PRODUCT_NAME)

- BIOPATH150_016: p-cumate(MAIN_PRODUCT_NAME)

- BIOPATH150_019: methylcatechol(MAIN_PRODUCT_NAME); 4-methylcatechol(MAIN_PRODUCT_NAME)

- BIOPATH150_020: benzoate(MAIN_PRODUCT_NAME); benzoate(MAIN_PRODUCT_NAME)

- BIOPATH150_041: propanoyl(MAIN_PRODUCT_NAME)

- BIOPATH150_054: methylglyoxal(MAIN_PRODUCT_NAME); methylglyoxal(MAIN_PRODUCT_NAME)

- BIOPATH150_068: chlorocatechol(MAIN_PRODUCT_NAME)

- BIOPATH150_079: vanillate(MAIN_PRODUCT_NAME)

- BIOPATH150_082: acrylate(MAIN_PRODUCT_NAME); acrylate(MAIN_PRODUCT_NAME)

- BIOPATH150_094: testosterone(MAIN_PRODUCT_NAME); testosterone(MAIN_PRODUCT_NAME)

- BIOPATH150_106: myrcene(MAIN_PRODUCT_NAME); myrcene(MAIN_PRODUCT_NAME)

- BIOPATH150_141: methylhexan(MAIN_SUBSTRATE_NAME)

- BIOPATH150_143: butyrobetaine(MAIN_PRODUCT_NAME)

- BIOPATH150_144: butyrobetaine(MAIN_PRODUCT_NAME)

- these route-qualifier tokens are also gold endpoints/intermediates of their own case: kept in the message (the route qualifier is the frozen pathway name), flagged, never silently auto-allowed.


## 3. Pending oxygen review

- 93 / 121 cases render 氧条件 = null（未指定）: the frozen source says 'No data'; no Aerobic/Anaerobic was guessed. The 28 cases with source values use them verbatim (aerobic/anaerobic/mixed).


## 4. Teacher sample (seed 20260927, n=13)

- coverage: oxygen buckets ['aerobic', 'null']; graph shapes ['BRANCHED_DAG', 'LINEAR_UNIQUE']; step terciles ['long', 'mid', 'short']; broad categories 7 of 11

- cases: BIOPATH150_009, BIOPATH150_016, BIOPATH150_019, BIOPATH150_020, BIOPATH150_041, BIOPATH150_054, BIOPATH150_068, BIOPATH150_079, BIOPATH150_082, BIOPATH150_094, BIOPATH150_106, BIOPATH150_141, BIOPATH150_143

- each sample row carries the prompt hash and the pending checks (name uniqueness, route qualifier adequacy) for the teacher.


## 5. Gate

- G2 = READY_FOR_REVIEW, next_stage_allowed=false; G3/G4/G5/G6 not started; zero API calls. PASS requires the teacher's 13-case manual review sign-off.
