#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_g2_questions.py -- independent G2 validator (G1-R4 era).

Does NOT import the builder's decision functions: it re-derives the formal
case set from G1, re-verifies every rendered message against the frozen
collector files, re-runs the leakage scan as a subprocess, recomputes the
teacher sample with the documented seeded algorithm, and checks all
manifest/gate bindings. Deterministic report (timestamp-free, sorted keys):
repeated runs are byte-identical.
"""

import argparse
import collections
import csv
import hashlib
import json
import math
import os
import random
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
G2 = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(G2, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")
COLLECTOR_ROOT = os.path.join(TASK_ROOT,
                              "24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")
PROMPT_FILE = os.path.join(COLLECTOR_ROOT, "prompts", "unified_collection_v2.txt")
TEMPLATE_FILE = os.path.join(COLLECTOR_ROOT, "templates",
                             "biodegradation_answer_v2.blank.template.json")
SCHEMA_FILE = os.path.join(COLLECTOR_ROOT, "schemas",
                           "biodegradation_answer_v2.schema.json")
TEACHER_APPROVAL = os.path.join(TASK_ROOT, "00_Authority_Teacher_Plan",
                                "TEACHER_REPLY_BIOSYSMODB150_G1_APPROVAL_2026-09-27.md")
TEACHER_APPROVAL_SHA = ("39e08c219aa155d21e687db0976b1fd4df06d"
                        "1c3d2b8c738ca847bafa47657dd")
SCAN_SCRIPT = os.path.join(HERE, "scan_g2_leakage.py")
SAMPLE_SEED = 20260927
SAMPLE_N = 13

FAILURES = []
CHECKS = 0


def check(name, ok, detail=""):
    global CHECKS
    CHECKS += 1
    if not ok:
        FAILURES.append({"check": name, "detail": str(detail)[:400]})
        print("  [FAIL] %s %s" % (name, str(detail)[:200]))
    return ok


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def norm(text):
    return re.sub(r"\s+", " ", (text or "").strip()).lower()


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", default=None)
    args = parser.parse_args(argv)

    print("[1] formal set: exactly 121, zero quarantine")
    formal_expected = {r["case_id"] for r in read_tsv(os.path.join(G1, "formal_cases.tsv"))}
    quarantined = {r["original_case_id"] for r in read_tsv(
        os.path.join(STAGE, "quarantine", "cases.tsv"))}
    cases = [json.loads(line) for line in open(os.path.join(G2, "main_cases.jsonl"),
                                               encoding="utf-8") if line.strip()]
    case_ids = [c["case_id"] for c in cases]
    check("formal_count_121", len(cases) == 121 and len(formal_expected) == 121,
          "%d/%d" % (len(cases), len(formal_expected)))
    check("formal_set_equals_G1", set(case_ids) == formal_expected)
    check("no_quarantine_in_cases", not (set(case_ids) & quarantined))
    check("case_ids_unique", len(set(case_ids)) == len(case_ids))

    print("[2] one canonical rendered message per case")
    rendered_dir = os.path.join(G2, "rendered_messages")
    files = sorted(f for f in os.listdir(rendered_dir) if f.endswith(".json"))
    check("rendered_files_121", len(files) == 121, len(files))
    docs = {}
    for fname in files:
        doc = json.load(open(os.path.join(rendered_dir, fname), encoding="utf-8"))
        docs[doc["case_id"]] = doc
    check("rendered_case_set_matches", set(docs) == set(case_ids))
    sha_by_case = {cid: doc["messages_sha256"] for cid, doc in docs.items()}
    check("unique_prompt_hash_per_case",
          len(set(sha_by_case.values())) == len(sha_by_case))

    print("[3] metadata consistency against G1")
    roots = {r["case_id"]: r for r in read_tsv(
        os.path.join(G1, "case_root_identity.tsv"))}
    formal_rows = {r["case_id"]: r for r in read_tsv(
        os.path.join(G1, "formal_cases.tsv"))}
    reaction_rows = read_tsv(os.path.join(G1, "reaction_gold.tsv"))
    main_names_by_case = collections.defaultdict(set)
    compound_names = {}
    for r in reaction_rows:
        if r["role_label"] in ("MAIN_SUBSTRATE", "MAIN_PRODUCT", "BYPRODUCT"):
            main_names_by_case[r["case_id"]].add(norm(r["identity_name"]))
        compound_names.setdefault(r["compound_id"], r["identity_name"])
    oxygen_map = {"Aerobic": "aerobic", "Anaerobic": "anaerobic",
                  "An/Aerobic": "mixed", "No data": None}
    bad_meta = []
    for case in cases:
        cid = case["case_id"]
        root = roots.get(cid, {})
        if case.get("pathway_name") != formal_rows[cid]["pathway_name"]:
            bad_meta.append((cid, "pathway_name"))
        if case.get("route_qualifier") != formal_rows[cid]["pathway_name"]:
            bad_meta.append((cid, "route_qualifier"))
        poll_names = [n.strip() for n in (case.get("pollutant_name_en") or "").split(" / ")]
        for name in poll_names:
            if norm(name) not in main_names_by_case[cid]:
                bad_meta.append((cid, "pollutant not a gold main name: %s" % name))
        expected_oxy = oxygen_map.get(formal_rows[cid].get("aerobic_or_anaerobic"))
        got_oxy = case.get("oxygen_condition")
        if (got_oxy or None) != expected_oxy:
            bad_meta.append((cid, "oxygen %r != %r" % (got_oxy, expected_oxy)))
        status = formal_rows[cid].get("aerobic_or_anaerobic")
        if status == "No data" and "PENDING_OXYGEN_REVIEW" not in case.get(
                "oxygen_source_status", ""):
            bad_meta.append((cid, "no-data oxygen not marked pending"))
    check("metadata_consistent_with_G1", not bad_meta, bad_meta[:6])

    print("[4] hash bookkeeping against the frozen collector files")
    prompt_hash_rows = read_tsv(os.path.join(G2, "prompt_hashes.tsv"))
    prompt_sha = sha256_file(PROMPT_FILE)
    template_sha = sha256_file(TEMPLATE_FILE)
    schema_sha = sha256_file(SCHEMA_FILE)
    check("prompt_hashes_121", len(prompt_hash_rows) == 121)
    ok_hashes = True
    for row in prompt_hash_rows:
        doc = docs.get(row["case_id"])
        if doc is None or row["messages_sha256"] != doc["messages_sha256"] \
                or row["rendered_prompt_sha256"] != doc["rendered_prompt_sha256"]:
            ok_hashes = False
        if row["prompt_template_sha256"] != prompt_sha \
                or row["blank_template_sha256"] != template_sha \
                or row["answer_schema_sha256"] != schema_sha:
            ok_hashes = False
    check("all_hashes_bound", ok_hashes)
    with open(os.path.join(G2, "prompt.template.txt"), encoding="utf-8") as fh:
        check("prompt_copy_byte_identical", norm(fh.read()) is not None
              and sha256_file(os.path.join(G2, "prompt.template.txt")) == prompt_sha)

    print("[5] every message carries the required content")
    blank_template_text = open(TEMPLATE_FILE, encoding="utf-8").read()
    schema_text = json.dumps(json.load(open(SCHEMA_FILE)), ensure_ascii=False)
    bad_content = []
    for cid, doc in docs.items():
        messages = doc["messages"]
        if len(messages) != 1 or messages[0].get("role") != "user":
            bad_content.append((cid, "not the single-user-message design"))
            continue
        if doc.get("system_message") is not None:
            bad_content.append((cid, "system message present"))
        text = messages[0]["content"]
        lowered = norm(text)
        for probe, label in (
                ("题目：", "chinese question"),
                ("15项性状", "15-trait section"),
                ("完整空白填写格式", "blank template section"),
                ("机器校验 Schema", "schema section"),
                ("一律填 null", "null rule"),
                ("记录一条 warning", "extra-field warning rule"),
                ("路线范围已由题面指定", "specified-route rule"),
                ("schema_version", "template member format")):
            if probe not in text:
                bad_content.append((cid, "missing %s (%s)" % (label, probe)))
        if "不限定路线" in text:
            bad_content.append((cid, "free-route fallback present"))
        # the rendered blank template must be present and valid JSON
        case = next(c for c in cases if c["case_id"] == cid)
        try:
            rendered_template = blank_template_text
            for token, value in (
                    ("{{CASE_ID}}", case["case_id"]),
                    ("{{POLLUTANT_NAME_ZH}}", case["pollutant_name_zh"]),
                    ("{{POLLUTANT_NAME_EN}}", case["pollutant_name_en"]),
                    ("{{OXYGEN_CONDITION}}", case["oxygen_condition"] or "null"),
                    ("{{ROUTE_SCOPE}}", case["route_qualifier"])):
                rendered_template = rendered_template.replace(token, str(value))
            json.loads(rendered_template)
        except Exception as exc:
            bad_content.append((cid, "template invalid: %s" % exc))
    check("messages_content_required", not bad_content, bad_content[:6])

    print("[6] leakage: re-run scan independently, unexplained must be 0")
    proc = subprocess.run([sys.executable, SCAN_SCRIPT, "--g2-root", G2,
                           "--output", "/tmp/g2_scan_recheck.tsv"],
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    check("scan_rerun_exit0", proc.returncode == 0,
          proc.stdout.decode("utf-8", "replace")[-300:])
    hits = read_tsv("/tmp/g2_scan_recheck.tsv")
    check("unexplained_hits_zero",
          sum(1 for r in hits if r["classification"] == "UNEXPLAINED") == 0)
    allowed = read_tsv(os.path.join(G2, "allowed_input_atoms.tsv"))
    check("allowed_atoms_have_position_and_reason",
          all((r["field_position"] or "").strip() and (r["allow_reason"] or "").strip()
              for r in allowed), "%d rows" % len(allowed))
    collision_rows = [r for r in hits
                      if r["classification"] == "ROUTE_GOLD_COLLISION"]
    collision_cases = sorted(set(r["case_id"] for r in collision_rows))
    check("collisions_flagged_not_dropped", len(collision_cases) > 0)
    for cid in collision_cases:
        row = [r for r in collision_rows if r["case_id"] == cid][0]
        check("collision_has_note_%s" % cid, "teacher review" in row["note"])

    print("[7] pollutant identity and route uniqueness")
    bad_pollutant = []
    for case in cases:
        names = [n.strip() for n in (case["pollutant_name_en"] or "").split(" / ")]
        if not names or any(not n for n in names):
            bad_pollutant.append((case["case_id"], "empty"))
        if len(set(map(norm, names))) != len(names):
            bad_pollutant.append((case["case_id"], "duplicate joined names"))
        if not (case.get("route_qualifier") or "").strip():
            bad_pollutant.append((case["case_id"], "missing route"))
    check("pollutant_and_route_unique", not bad_pollutant, bad_pollutant[:5])

    print("[8] teacher sample: 13, seeded, recomputable, collisions included")
    sample = read_tsv(os.path.join(G2, "teacher_sample_review.tsv"))
    check("sample_n_13", len(sample) == 13, len(sample))
    manifest = json.load(open(os.path.join(G2, "G2_questions.manifest.json"),
                              encoding="utf-8"))
    check("sample_seed_recorded", manifest.get("sample_seed") == SAMPLE_SEED)
    # recompute the documented algorithm independently
    ordered = sorted(cases, key=lambda c: c["case_id"])
    force = [c for c in ordered if c["case_id"] in collision_cases][:SAMPLE_N]
    rng = random.Random(SAMPLE_SEED)
    rest = [c for c in ordered if c not in force]
    rng.shuffle(rest)
    steps_sorted = sorted(int(c["ordered_step_count"]) for c in cases)
    third1 = steps_sorted[len(steps_sorted) // 3]
    third2 = steps_sorted[2 * len(steps_sorted) // 3]
    buckets = {"oxygen": set(), "graph": set(), "tercile": set(), "category": set()}

    def tercile(c):
        n = int(c["ordered_step_count"])
        return "short" if n <= third1 else ("mid" if n <= third2 else "long")

    def register(c):
        buckets["oxygen"].add(c["oxygen_condition"] or "null")
        buckets["graph"].add(c["graph_status"])
        buckets["tercile"].add(tercile(c))
        buckets["category"].add(c["broad_category"])

    picked = []
    for c in force:
        picked.append(c)
        register(c)
    remaining = list(rest)
    while remaining and len(picked) < SAMPLE_N:
        index = next((i for i, c in enumerate(remaining)
                      if (c["oxygen_condition"] or "null") not in buckets["oxygen"]
                      or c["graph_status"] not in buckets["graph"]
                      or tercile(c) not in buckets["tercile"]
                      or c["broad_category"] not in buckets["category"]), 0)
        c = remaining.pop(index)
        picked.append(c)
        register(c)
    check("sample_recomputable",
          [c["case_id"] for c in picked] == [r["case_id"] for r in sample],
          "%s vs %s" % ([c["case_id"] for c in picked][:5],
                        [r["case_id"] for r in sample][:5]))
    check("sample_all_collisions_first",
          all(cid in {r["case_id"] for r in sample} for cid in collision_cases[:13]))

    print("[9] manifest bindings")
    check("manifest_g1_gold_manifest_sha",
          manifest["g1_gold_manifest_sha256"] == sha256_file(
              os.path.join(G1, "G1_gold.manifest.json")))
    check("manifest_teacher_sha",
          manifest["teacher_approval_sha256"] == TEACHER_APPROVAL_SHA
          and sha256_file(TEACHER_APPROVAL) == TEACHER_APPROVAL_SHA)
    check("manifest_collector_hashes",
          manifest["collector_prompt_sha256"] == prompt_sha
          and manifest["collector_blank_template_sha256"] == template_sha
          and manifest["collector_answer_schema_sha256"] == schema_sha)
    check("manifest_zh_map_sha",
          manifest["pollutant_zh_map_sha256"] == sha256_file(
              os.path.join(G2, "pollutant_name_zh_map.tsv")))
    check("manifest_counts",
          manifest["formal_cases"] == 121 and manifest["rendered_messages"] == 121
          and manifest["sample_n"] == 13)

    print("[10] G1 canonical + teacher files untouched (hashes vs G1 manifest)")
    with open(os.path.join(G1, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, name = line.rstrip("\n").split("  ", 1)
                check("g1_gold_intact_%s" % name,
                      sha256_file(os.path.join(G1, name)) == digest)
    gate1 = json.load(open(os.path.join(STAGE, "gates", "G1_gold.stage_gate.json"),
                           encoding="utf-8"))
    check("g1_gate_still_pass", gate1["status"] == "PASS")

    print("[11] G2 gate and later stages")
    gate2 = json.load(open(os.path.join(STAGE, "gates", "G2_questions.stage_gate.json"),
                           encoding="utf-8"))
    check("g2_gate_ready_for_review", gate2["status"] == "READY_FOR_REVIEW")
    check("g2_gate_next_false", gate2["next_stage_allowed"] is False)
    check("g2_gate_binds_manifest",
          gate2["input_manifest"]["sha256"] == sha256_file(
              os.path.join(G2, "G2_questions.manifest.json")))
    check("g2_gate_binds_g1_gate",
          gate2["upstream_gate"]["sha256"] == sha256_file(
              os.path.join(STAGE, "gates", "G1_gold.stage_gate.json")))
    for later in ("G3_scorer", "G4_search", "G5_smoke", "G6_pilot"):
        check("later_stage_absent_%s" % later,
              not os.path.isdir(os.path.join(STAGE, later)))

    print("[12] SHA256SUMS coverage of G2")
    listed = {}
    with open(os.path.join(G2, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, rel = line.rstrip("\n").split("  ", 1)
                listed[rel] = digest
    actual = {}
    for dirpath, dirnames, filenames in os.walk(G2):
        for name in filenames:
            if name == "SHA256SUMS":
                continue
            path = os.path.join(dirpath, name)
            actual[os.path.relpath(path, G2)] = sha256_file(path)
    check("sha256sums_covers_all", sorted(listed) == sorted(actual),
          "missing=%s extra=%s" % (sorted(set(actual) - set(listed))[:3],
                                   sorted(set(listed) - set(actual))[:3]))
    for rel, digest in sorted(listed.items()):
        check("digest_%s" % rel, actual.get(rel) == digest, rel)

    print()
    report = {
        "overall": "FAIL" if FAILURES else "PASS",
        "checks": CHECKS,
        "failures": FAILURES,
        "counts": {
            "formal_cases": 121,
            "rendered_messages": len(docs),
            "teacher_sample": len(sample),
            "unexplained_hits": 0,
            "route_gold_collision_cases": collision_cases,
            "pending_oxygen_cases": sum(
                1 for c in cases if "PENDING" in (c.get("oxygen_source_status") or "")),
        },
    }
    if args.report:
        path = os.path.abspath(args.report)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(report, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")
    if FAILURES:
        print("G2 VALIDATION: FAIL (%d failures of %d checks)"
              % (len(FAILURES), CHECKS))
        return 1
    print("G2 VALIDATION: PASS (%d checks, 0 failures)" % CHECKS)
    return 0


if __name__ == "__main__":
    sys.exit(main())
