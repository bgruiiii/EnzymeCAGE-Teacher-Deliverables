#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
scan_g2_leakage.py -- G2 per-case leakage scan over the FINAL rendered messages.

Scans what the model will actually receive: the complete user message
(rendered prompt + case metadata block + full blank JSON template + compact
schema + all enums and rules). The frozen D0/contract message design is a
single user message with NO system message (execution plan section 7: one
plain user message, proven byte-for-byte by the 2026-09-24 smoke), so
"system message" is scanned as null-by-design and the full user content is
covered end to end.

Per case, the FORBIDDEN set is built ONLY from that case's own G1 gold:
main substrate/product compound names (identity_name + db_cmpdname) and
aliases, terminal product names, enzyme names, EC numbers, organism names /
strains / TaxIDs / genome ids, database record ids (BSY-r/c/e), gold
SMILES (length-gated), and ordered step labels. Registered allowed inputs
(case_id, the pollutant root names, the oxygen value, the route qualifier
tokens) never cross cases.

Hit classification:
  POLLUTANT_NAME_ALLOWED      -- inside a registered pollutant-name atom
  ROUTE_QUALIFIER_ALLOWED     -- inside the route qualifier text, not gold
  ROUTE_GOLD_COLLISION        -- route qualifier token that IS a gold
                                 terminal/intermediate: kept in the message,
                                 flagged for teacher review (never silently
                                 auto-allowed)
  UNEXPLAINED                 -- anything else: exits non-zero and blocks G2
"""

import argparse
import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
G2 = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(G2, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")

OXYGEN_VALUES = {"aerobic", "anaerobic", "mixed"}
# gold SMILES shorter than this are skipped as scan tokens: short generic
# SMILES would substring-match unrelated text (the message contains no
# SMILES by construction; this is belt-and-braces only).
MIN_SMILES_TOKEN_LEN = 6


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def norm(text):
    return re.sub(r"\s+", " ", (text or "").strip()).lower()


STEREO_PREFIX_RE = re.compile(
    r"^(?:\([+-]?(?:[rze],?)+\)|\((?:[res]|and|or|\d[srz]?)\)-|\(\d[srz]?\)-|d-|l-)+",
    re.IGNORECASE)
CHARGE_SUFFIX_RE = re.compile(r"\((?:\d*[+-]+|\d+\-)\)$")


def stripped_core(name):
    """Remove stereo/charge decorations: '(+)-Perillate' -> 'perillate'."""
    text = (name or "").strip()
    text = CHARGE_SUFFIX_RE.sub("", text)
    text = STEREO_PREFIX_RE.sub("", text)
    text = text.strip(" -")
    return text


ROUTE_STOPWORDS = {"degradation", "pathway", "aerobic", "anaerobic", "and",
                   "to", "via", "ii", "iii", "iv", "the", "i", "an", "or"}


def collect_forbidden(case_id, reaction_rows, enzyme_rows, organism_rows, root_row):
    """This case's OWN gold forbidden atoms (never cross-case)."""
    forbidden = {}  # norm token -> (category, original)
    gated = []      # degenerate tokens excluded from substring scanning

    def add(token, category):
        token = norm(token)
        if not token or token in forbidden:
            return
        # token sanity gate: purely numeric tokens (< 5 digits) and tokens
        # shorter than 4 chars are not discriminative leak detectors -- e.g.
        # the source placeholder organism_name_raw "0", or the 3-letter
        # gene-style enzyme name "Ord" which is a substring of the blank
        # template's own "order" field name. Record ids ("bsy-...") and EC
        # numbers keep full scanning at any length.
        is_id = "bsy-" in token
        is_ec = re.match(r"^\d+\.\d+", token)
        if not is_id and not is_ec:
            if token.isdigit() and len(token) < 5:
                gated.append((token, category, "numeric-short"))
                return
            if len(token) < 4:
                gated.append((token, category, "short-token"))
                return
        forbidden[token] = (category, token)
        # scan the decoration-stripped core too (synonym-level matching):
        # a route phrase 'to perillate' must still trip the gold name
        # '(+)-Perillate'
        if category.endswith("_NAME") or category == "TERMINAL_NAME":
            core = norm(stripped_core(token))
            if core and core != token and len(core) >= 4 and core not in forbidden:
                forbidden[core] = (category, core)

    for r in reaction_rows:
        if r["case_id"] != case_id:
            continue
        if r["role_label"] in ("MAIN_SUBSTRATE", "MAIN_PRODUCT", "BYPRODUCT"):
            for name_col in ("identity_name", "db_cmpdname"):
                add(r.get(name_col), "%s_NAME" % r["role_label"])
            add(r.get("compound_id"), "COMPOUND_RECORD_ID")
            for smiles_col in ("isosmiles", "canonicalsmiles"):
                value = (r.get(smiles_col) or "").strip()
                if len(value) >= MIN_SMILES_TOKEN_LEN:
                    add(value, "GOLD_%s" % smiles_col.upper())
        add(r.get("reaction_id"), "REACTION_RECORD_ID")
        add(r.get("step_occurrence_id"), "STEP_LABEL")
    for name in (root_row.get("terminal_compound_names") or "").split("|"):
        add(name, "TERMINAL_NAME")
    for r in enzyme_rows:
        if r["case_id"] != case_id:
            continue
        add(r.get("enzyme_name"), "ENZYME_NAME")
        add(r.get("ec_number_raw"), "EC_NUMBER")
        add(r.get("ec_number_normalized"), "EC_NUMBER")
        add(r.get("enzyme_id"), "ENZYME_RECORD_ID")
    for r in organism_rows:
        if r["case_id"] != case_id:
            continue
        add(r.get("matched_organism_name"), "ORGANISM_NAME")
        add(r.get("organism_name_raw"), "ORGANISM_NAME")
        add(r.get("taxid"), "ORGANISM_TAXID")
        add(r.get("genome_id"), "ORGANISM_GENOME_ID")
    forbidden.pop(norm(case_id), None)  # case_id is routing, not an answer id
    return forbidden, gated


def tokens_of(name):
    return set(w for w in re.split(r"[^a-z0-9-]+", norm(name)) if w)


def occurrences(text, token):
    out = []
    start = 0
    while True:
        index = text.find(token, start)
        if index < 0:
            return out
        out.append((index, index + len(token)))
        start = index + 1


def covered_by(hits, allowed_ranges):
    for start, end in hits:
        if not any(a_start <= start and end <= a_end
                   for a_start, a_end in allowed_ranges):
            return False
    return True


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--g2-root", default=G2)
    parser.add_argument("--output", default=None)
    args = parser.parse_args(argv)
    g2 = os.path.abspath(args.g2_root)
    out_path = args.output or os.path.join(g2, "leakage_hits.tsv")

    cases = [json.loads(line) for line in open(
        os.path.join(g2, "main_cases.jsonl"), encoding="utf-8") if line.strip()]
    rendered_dir = os.path.join(g2, "rendered_messages")
    reaction_rows = read_tsv(os.path.join(G1, "reaction_gold.tsv"))
    enzyme_rows = read_tsv(os.path.join(G1, "enzyme_gold.tsv"))
    organism_rows = read_tsv(os.path.join(G1, "organism_gold.tsv"))
    roots = {r["case_id"]: r for r in read_tsv(
        os.path.join(G1, "case_root_identity.tsv"))}

    hit_rows = []
    allowed_atom_rows = []
    unexplained = []
    collision_rows = []

    for case in cases:
        case_id = case["case_id"]
        message_path = os.path.join(rendered_dir, "%s.json" % case_id)
        doc = json.load(open(message_path, encoding="utf-8"))
        messages = doc["messages"]
        # the frozen design is exactly one user message; assert and scan it all
        if len(messages) != 1 or messages[0].get("role") != "user":
            unexplained.append((case_id, "message structure is not the frozen "
                                          "single-user-message design"))
            continue
        text = norm(messages[0].get("content") or "")

        def compress(value):
            return re.sub(r"[^a-z0-9]", "", norm(value))

        pollutant_compressed = set()
        for _pname in (case.get("pollutant_name_en") or "").split(" / "):
            for _form in (_pname, stripped_core(_pname)):
                _c = compress(_form)
                if _c:
                    pollutant_compressed.add(_c)

        # registered allowed atoms (never cross-case)
        allowed_atoms = []
        for name in (case.get("pollutant_name_en") or "").split(" / "):
            allowed_atoms.append((norm(name), "POLLUTANT_NAME"))
        for name in (case.get("pollutant_name_zh") or "").split(" / "):
            allowed_atoms.append((norm(name), "POLLUTANT_NAME"))
        allowed_atoms.append((norm(case_id), "CASE_ID"))
        oxygen = norm(case.get("oxygen_condition"))
        if oxygen and oxygen != "null":
            allowed_atoms.append((oxygen, "OXYGEN_CONDITION"))
        route = norm(case.get("route_qualifier"))
        route_ranges = []
        if route:
            for start, end in occurrences(text, route):
                route_ranges.append((start, end))
        allowed_ranges = []
        for token, _kind in allowed_atoms:
            allowed_ranges.extend(occurrences(text, token))
        for atom, kind in allowed_atoms:
            for start, end in occurrences(text, atom):
                allowed_atom_rows.append({
                    "case_id": case_id, "atom": atom, "atom_kind": kind,
                    "field_position": "user message char %d-%d" % (start, end),
                    "allow_reason": {
                        "POLLUTANT_NAME": "question subject identity (the "
                                          "pollutant the case is about)",
                        "CASE_ID": "routing identifier; not a BIOSYSMO "
                                   "pathway/reaction answer id",
                        "OXYGEN_CONDITION": "controlled condition input "
                                            "(frozen source value)",
                    }[kind],
                })

        forbidden, gated = collect_forbidden(case_id, reaction_rows, enzyme_rows,
                                             organism_rows, roots.get(case_id, {}))
        # reverse disclosure check: a content word of the route qualifier that
        # is CONTAINED IN a gold name (e.g. 'via chlorocatechol' vs gold
        # '3-Chlorocatechol') also flags a route/gold collision
        if route:
            # compression: drop every non-alphanumeric character (position
            # markers, hyphens, apostrophes, greek letters are not a-z). A
            # route word is NOT a disclosure when it is a substring of any
            # compressed pollutant-name form (e.g. route word
            # '2-dichloroethane' vs pollutant '1,2-Dichloroethane',
            # 'tert-butyl' vs 'Methyl tert-butyl ether', 'vanillate' vs
            # "5,5'-dehydrodivanillate"): the word comes from the pollutant
            # itself, not from another gold compound.
            def compress(value):
                return re.sub(r"[^a-z0-9]", "", norm(value))

            pollutant_compressed = set()
            for name in (case.get("pollutant_name_en") or "").split(" / "):
                for form in (name, stripped_core(name)):
                    compressed = compress(form)
                    if compressed:
                        pollutant_compressed.add(compressed)
            route_words = [w for w in (compress(part) for part in
                                       re.split(r"[^a-z0-9]+", route))
                           if len(w) >= 7 and w not in ROUTE_STOPWORDS
                           and not any(w in pc or pc in w
                                       for pc in pollutant_compressed)]
            for word in route_words:
                for ftoken, (category, _original) in forbidden.items():
                    # only gold COMPOUND names: an enzyme/organism name that
                    # merely CONTAINS the route word is not in the message,
                    # so it is not a disclosure of that enzyme/organism
                    if (category.startswith("MAIN_") and category.endswith("_NAME")) \
                            or category == "TERMINAL_NAME":
                        if word in compress(ftoken):
                            already = any(h["token"] == word
                                          and h["case_id"] == case_id
                                          for h in hit_rows)
                            if not already:
                                hit_rows.append({
                                    "case_id": case_id, "token": word,
                                    "gold_category": category,
                                    "occurrence_count": 1,
                                    "first_position": "route qualifier",
                                    "classification": "ROUTE_GOLD_COLLISION",
                                    "note": "route qualifier word is contained in "
                                            "a gold %s: kept in the message, "
                                            "flagged for teacher review" % category,
                                })
                                collision_rows.append((case_id, word, category))
                            break
        for token, category, gate_reason in gated:
            hit_rows.append({
                "case_id": case_id, "token": token, "gold_category": category,
                "occurrence_count": 0, "first_position": "",
                "classification": "SCAN_TOKEN_GATED",
                "note": "degenerate token excluded from substring scanning "
                        "(%s); not a message hit" % gate_reason,
            })
        for token, (category, _original) in sorted(forbidden.items()):
            hits = occurrences(text, token)
            if not hits:
                continue
            if covered_by(hits, allowed_ranges):
                classification = "POLLUTANT_NAME_ALLOWED"
                note = "hit covered by a registered pollutant/case-id atom"
            elif route_ranges and any(
                    any(r_start <= start and end <= r_end
                        for r_start, r_end in route_ranges)
                    for start, end in hits):
                compressed_token = compress(token)
                if any(compressed_token in pc or pc in compressed_token
                       for pc in pollutant_compressed):
                    classification = "POLLUTANT_NAME_ALLOWED"
                    note = ("hit inside the route qualifier, but the token is a "
                            "form of the pollutant name")
                elif category in ("TERMINAL_NAME",) or category.startswith("MAIN_"):
                    classification = "ROUTE_GOLD_COLLISION"
                    note = ("route qualifier token is ALSO a gold %s: kept in "
                            "the message, flagged for teacher review" % category)
                    collision_rows.append((case_id, token, category))
                else:
                    classification = "ROUTE_QUALIFIER_ALLOWED"
                    note = "hit inside the route qualifier text, not gold"
            else:
                classification = "UNEXPLAINED"
                note = "unexplained gold atom in the final message"
                unexplained.append((case_id, token, category))
            hit_rows.append({
                "case_id": case_id, "token": token, "gold_category": category,
                "occurrence_count": len(hits),
                "first_position": "user message char %d" % hits[0][0],
                "classification": classification,
                "note": note,
            })

    columns = ["case_id", "token", "gold_category", "occurrence_count",
               "first_position", "classification", "note"]
    with open(out_path, "w", encoding="utf-8", newline="\n") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()
        for row in hit_rows:
            writer.writerow(row)
    allowed_path = os.path.join(g2, "allowed_input_atoms.tsv")
    with open(allowed_path, "w", encoding="utf-8", newline="\n") as fh:
        writer = csv.DictWriter(
            fh, fieldnames=["case_id", "atom", "atom_kind", "field_position",
                            "allow_reason"], delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for row in allowed_atom_rows:
            writer.writerow(row)

    counts = {}
    for row in hit_rows:
        counts[row["classification"]] = counts.get(row["classification"], 0) + 1
    print("leakage scan: %d cases | hits=%s | allowed atoms registered=%d"
          % (len(cases), counts, len(allowed_atom_rows)))
    if collision_rows:
        print("ROUTE_GOLD_COLLISION cases (teacher review required): %s"
              % sorted(set(c for c, _t, _k in collision_rows)))
    if unexplained:
        print("UNEXPLAINED hits (G2 blocked): %s" % unexplained[:10])
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
