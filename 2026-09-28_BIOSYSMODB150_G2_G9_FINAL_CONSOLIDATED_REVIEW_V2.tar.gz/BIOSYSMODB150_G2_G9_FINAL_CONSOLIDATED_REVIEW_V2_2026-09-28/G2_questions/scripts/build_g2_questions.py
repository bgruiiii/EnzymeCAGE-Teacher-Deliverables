#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_g2_questions.py -- G2: render the 121 main-experiment questions.

Hard gate first: G1 gate PASS, next_stage_allowed, formal_n=121,
quarantine=29, teacher approval SHA. Rendering reuses the FROZEN D0
collector prompt / blank template / answer schema and the collector's own
rendering functions, so the rendered messages are byte-identical to what
run_collection_v2.py would dispatch to all five models (one user message,
no system message -- the frozen contract design).

Pollutant selection (deterministic, documented):
  1. drop carrier-pattern roots (reduced/oxidized FADH2/FMN/NAD/electron
     carrier/cluster/dioxygen dianions);
  2. drop central cosubstrate roots (alpha-ketoglutarate, bicarbonate) when
     another root remains;
  3. prefer the root with more gold MAIN_SUBSTRATE occurrences;
  4. tie -> prefer roots whose normalized tokens intersect the frozen
     pathway name;
  5. tie persists -> join the remaining roots with " / ".
Oxygen: only frozen Aerobic/Anaerobic/An-Aerobic values are used;
'No data' renders null (PENDING_OXYGEN_REVIEW) -- never guessed.

Outputs live only in G2_questions/; G1, quarantine, teacher files and the
collector are read-only. Zero API calls.
"""

import argparse
import collections
import csv
import hashlib
import importlib.util
import json
import math
import os
import random
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
G2 = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(G2, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")
COLLECTOR_ROOT = os.path.join(TASK_ROOT,
                              "24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")
COLLECTOR_SCRIPT = os.path.join(COLLECTOR_ROOT, "scripts", "run_collection_v2.py")
PROMPT_FILE = os.path.join(COLLECTOR_ROOT, "prompts", "unified_collection_v2.txt")
TEMPLATE_FILE = os.path.join(COLLECTOR_ROOT, "templates",
                             "biodegradation_answer_v2.blank.template.json")
SCHEMA_FILE = os.path.join(COLLECTOR_ROOT, "schemas",
                           "biodegradation_answer_v2.schema.json")
TEACHER_APPROVAL = os.path.join(TASK_ROOT, "00_Authority_Teacher_Plan",
                                "TEACHER_REPLY_BIOSYSMODB150_G1_APPROVAL_2026-09-27.md")
TEACHER_APPROVAL_SHA = ("39e08c219aa155d21e687db0976b1fd4df06d"
                        "1c3d2b8c738ca847bafa47657dd")

SAMPLE_SEED = 20260927
SAMPLE_N = 13  # ceil(0.10 * 121)

CARRIER_PATTERNS = ("reduced ", "oxidized ", "fadh2", "fmn dianion", "nad(",
                    "nadp", "electron", "carrier", "cluster", "dioxygen",
                    "cytochrome", "ferredoxin", "putidaredoxin", "flavoprotein")
CENTRAL_COSUBSTRATES = {"alpha-ketoglutarate", "bicarbonate", "glutamate"}
OXYGEN_MAP = {"Aerobic": "aerobic", "Anaerobic": "anaerobic",
              "An/Aerobic": "mixed", "No data": None}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def load_collector():
    spec = importlib.util.spec_from_file_location("_g2_collector", COLLECTOR_SCRIPT)
    module = importlib.util.module_from_spec(spec)
    sys.modules["_g2_collector"] = module
    spec.loader.exec_module(module)
    return module


def norm(text):
    return re.sub(r"\s+", " ", (text or "").strip()).lower()


def tokens(text):
    return set(t for t in re.split(r"[^a-z0-9]+", norm(text)) if len(t) > 3)


def is_carrier_root(name):
    lowered = norm(name)
    return any(pattern in lowered for pattern in CARRIER_PATTERNS)


def select_pollutant(case_id, roots, main_counts, pathway_name, name_by_compound):
    """Deterministic multi-root resolution (see module docstring)."""
    entries = [(cid, main_counts.get(cid, 0)) for cid in roots]
    non_carrier = [e for e in entries if not is_carrier_root(name_by_compound.get(e[0], e[0]))]
    if non_carrier:
        entries = non_carrier
    non_cosub = [e for e in entries
                 if norm(name_by_compound.get(e[0], e[0])) not in CENTRAL_COSUBSTRATES]
    if non_cosub and len(non_cosub) < len(entries):
        entries = non_cosub
    if not entries:
        entries = [(cid, main_counts.get(cid, 0)) for cid in roots]
    top = max(count for _cid, count in entries)
    candidates = [cid for cid, count in entries if count == top]
    if len(candidates) > 1:
        # prefer the root whose compressed full name is CONTAINED IN the
        # frozen pathway name (the pathway names its subject); token overlap
        # is only a fallback
        def compress(value):
            return re.sub(r"[^a-z0-9]", "", norm(value))

        compressed_pathway = compress(pathway_name)
        contained = [cid for cid in candidates
                     if compress(name_by_compound.get(cid, cid))
                     and compress(name_by_compound.get(cid, cid)) in compressed_pathway]
        if len(contained) == 1:
            candidates = contained
        elif not contained:
            pw_tokens = tokens(pathway_name)
            overlapping = [cid for cid in candidates
                           if tokens(name_by_compound.get(cid, cid)) & pw_tokens]
            if len(overlapping) == 1:
                candidates = overlapping
    chosen = [name_by_compound.get(cid, cid) for cid in sorted(candidates)]
    pollutant_ids = sorted(candidates)
    return " / ".join(chosen), pollutant_ids, [cid for cid in roots
                                               if cid not in pollutant_ids]


def pick_teacher_sample(case_rows, force_case_ids=()):
    """Seeded sample: true ROUTE_GOLD_COLLISION cases first (mandatory
    teacher review per section 4.9), then coverage-first fill to SAMPLE_N."""
    rng = random.Random(SAMPLE_SEED)
    ordered = sorted(case_rows, key=lambda r: r["case_id"])
    force = [r for r in ordered if r["case_id"] in set(force_case_ids)][:SAMPLE_N]
    shuffled = [r for r in ordered if r not in force]
    rng.shuffle(shuffled)
    steps_sorted = sorted(int(r["ordered_step_count"]) for r in case_rows)
    third1 = steps_sorted[len(steps_sorted) // 3]
    third2 = steps_sorted[2 * len(steps_sorted) // 3]

    def tercile(row):
        n = int(row["ordered_step_count"])
        if n <= third1:
            return "short"
        if n <= third2:
            return "mid"
        return "long"

    buckets = {"oxygen": set(), "graph": set(), "tercile": set(), "category": set()}
    picked = []
    coverage_key = lambda r: (
        r["oxygen_condition"] or "null", r["graph_status"], tercile(r),
        r["broad_category"])

    def uncovered_dimensions(row):
        out = []
        if (row["oxygen_condition"] or "null") not in buckets["oxygen"]:
            out.append("oxygen")
        if row["graph_status"] not in buckets["graph"]:
            out.append("graph")
        if tercile(row) not in buckets["tercile"]:
            out.append("tercile")
        if row["broad_category"] not in buckets["category"]:
            out.append("category")
        return out

    def register(row):
        buckets["oxygen"].add(row["oxygen_condition"] or "null")
        buckets["graph"].add(row["graph_status"])
        buckets["tercile"].add(tercile(row))
        buckets["category"].add(row["broad_category"])

    picked = list(force)
    for row in force:
        register(row)
    remaining = list(shuffled)
    while remaining and len(picked) < SAMPLE_N:
        chosen_index = None
        for index, row in enumerate(remaining):
            if uncovered_dimensions(row):
                chosen_index = index
                break
        if chosen_index is None:
            chosen_index = 0
        row = remaining.pop(chosen_index)
        picked.append(row)
        register(row)
    return picked, buckets, {"tercile_bounds": [third1, third2],
                             "forced_collisions": [r["case_id"] for r in force]}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage-root", default=STAGE)
    args = parser.parse_args(argv)

    print("[0] hard gate: G1 PASS + teacher approval")
    gate = json.load(open(os.path.join(STAGE, "gates", "G1_gold.stage_gate.json"),
                          encoding="utf-8"))
    counts = json.load(open(os.path.join(G1, "counts.json"), encoding="utf-8"))
    approval_sha = sha256_file(TEACHER_APPROVAL)
    if not (gate.get("status") == "PASS" and gate.get("next_stage_allowed") is True
            and counts.get("final_n") == 121
            and counts.get("quarantine_case_count") == 29
            and approval_sha == TEACHER_APPROVAL_SHA):
        raise SystemExit("G2 hard gate failed: gate=%s formal=%s quar=%s approval=%s"
                         % (gate.get("status"), counts.get("final_n"),
                            counts.get("quarantine_case_count"), approval_sha[:12]))

    collector = load_collector()
    prompt_text = collector.read_text(PROMPT_FILE)
    blank_template_text = collector.read_text(TEMPLATE_FILE)
    answer_schema = collector.load_json_file(SCHEMA_FILE)
    compact_schema_text = collector.compact_json(answer_schema)
    prompt_sha = sha256_file(PROMPT_FILE)
    template_sha = sha256_file(TEMPLATE_FILE)
    schema_sha = sha256_file(SCHEMA_FILE)

    print("[1] assembling case metadata from G1")
    formal_rows = read_tsv(os.path.join(G1, "formal_cases.tsv"))
    root_rows = {r["case_id"]: r for r in read_tsv(
        os.path.join(G1, "case_root_identity.tsv"))}
    reaction_rows = read_tsv(os.path.join(G1, "reaction_gold.tsv"))
    main_sub_counts = collections.defaultdict(collections.Counter)
    name_by_compound = {}
    for r in reaction_rows:
        if r["role_label"] == "MAIN_SUBSTRATE":
            main_sub_counts[r["case_id"]][r["compound_id"]] += 1
        name_by_compound.setdefault(r["compound_id"], r["identity_name"])
    zh_map = {r["pollutant_name_en"]: r["pollutant_name_zh"] for r in read_tsv(
        os.path.join(G2, "pollutant_name_zh_map.tsv"))}

    rendered_dir = os.path.join(G2, "rendered_messages")
    os.makedirs(rendered_dir, exist_ok=True)
    case_rows = []
    prompt_hash_rows = []
    oxygen_pending = []

    for formal in sorted(formal_rows, key=lambda r: r["case_id"]):
        case_id = formal["case_id"]
        root = root_rows[case_id]
        roots = [c for c in (root["root_compound_ids"] or "").split("|") if c]
        pathway_name = formal["pathway_name"]
        pollutant_en, pollutant_ids, secondary = select_pollutant(
            case_id, roots, main_sub_counts[case_id], pathway_name,
            name_by_compound)
        pollutant_zh = " / ".join(zh_map.get(name, name)
                                  for name in pollutant_en.split(" / "))
        missing_zh = [name for name in pollutant_en.split(" / ")
                      if name not in zh_map]
        oxygen_raw = formal.get("aerobic_or_anaerobic") or "No data"
        oxygen = OXYGEN_MAP.get(oxygen_raw)
        if oxygen is None:
            oxygen_pending.append(case_id)
        case = {
            "case_id": case_id,
            "pathway_id": formal["pathway_id"],
            "pathway_name": pathway_name,
            "pollutant_name_zh": pollutant_zh,
            "pollutant_name_en": pollutant_en,
            "pollutant_compound_ids": "|".join(pollutant_ids),
            "secondary_root_compound_ids": "|".join(secondary),
            "oxygen_condition": oxygen,
            "oxygen_source_status": ("FROZEN_SOURCE:%s" % oxygen_raw
                                     if oxygen else "PENDING_OXYGEN_REVIEW"),
            "route_qualifier": pathway_name,
            # the collector template substitutes {{ROUTE_SCOPE}} from this key
            "route_scope": pathway_name,
            "broad_category": formal["broad_category"],
            "graph_status": formal["final_graph_status"],
            "ordered_step_count": int(formal["ordered_step_count"] or 0),
            "zh_name_status": "EN_FALLBACK" if missing_zh else "CURATED_ZH",
        }
        case_rows.append(case)

        rendered_template = collector.render_blank_template(blank_template_text, case)
        prompt_rendered = collector.render_prompt(
            prompt_text, case, rendered_template, compact_schema_text,
            route_mode="main")
        messages = collector.build_messages(prompt_rendered)
        message_doc = {
            "case_id": case_id,
            "case_metadata": case,
            "messages": messages,
            "system_message": None,
            "system_message_note": ("frozen contract design (execution plan "
                                    "section 7): exactly one plain user message, "
                                    "no system message; all five models receive "
                                    "this identical canonical message"),
            "messages_sha256": collector.messages_sha256(messages),
            "rendered_prompt_sha256": collector.sha256_text(prompt_rendered),
            "prompt_template_sha256": prompt_sha,
            "blank_template_sha256": template_sha,
            "answer_schema_sha256": schema_sha,
        }
        with open(os.path.join(rendered_dir, "%s.json" % case_id), "w",
                  encoding="utf-8", newline="\n") as fh:
            json.dump(message_doc, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
        prompt_hash_rows.append({
            "case_id": case_id,
            "rendered_prompt_sha256": message_doc["rendered_prompt_sha256"],
            "messages_sha256": message_doc["messages_sha256"],
            "prompt_template_sha256": prompt_sha,
            "blank_template_sha256": template_sha,
            "answer_schema_sha256": schema_sha,
        })

    print("[2] writing main_cases.jsonl / prompt copies / hashes")
    with open(os.path.join(G2, "main_cases.jsonl"), "w",
              encoding="utf-8", newline="\n") as fh:
        for case in case_rows:
            fh.write(json.dumps(case, ensure_ascii=False) + "\n")
    shutil.copyfile(PROMPT_FILE, os.path.join(G2, "prompt.template.txt"))
    with open(os.path.join(G2, "prompt_hashes.tsv"), "w",
              encoding="utf-8", newline="\n") as fh:
        writer = csv.DictWriter(fh, fieldnames=[
            "case_id", "rendered_prompt_sha256", "messages_sha256",
            "prompt_template_sha256", "blank_template_sha256",
            "answer_schema_sha256"], delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for row in prompt_hash_rows:
            writer.writerow(row)

    print("[3] leakage scan (final rendered messages)")
    scan = os.path.join(HERE, "scan_g2_leakage.py")
    proc = __import__("subprocess").run(
        [sys.executable, scan, "--g2-root", G2],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(proc.stdout.decode("utf-8", "replace")[-1500:])
    if proc.returncode != 0:
        raise SystemExit("leakage scan reported unexplained hits: G2 blocked")

    hits_for_sample = read_tsv(os.path.join(G2, "leakage_hits.tsv"))
    collision_cases = sorted(set(r["case_id"] for r in hits_for_sample
                                 if r["classification"] == "ROUTE_GOLD_COLLISION"))
    print("[4] teacher sample (seed %d, n %d, forced collisions %d)"
          % (SAMPLE_SEED, SAMPLE_N, len(collision_cases)))
    sample_rows, buckets, extra = pick_teacher_sample(case_rows, collision_cases)
    with open(os.path.join(G2, "teacher_sample_review.tsv"), "w",
              encoding="utf-8", newline="\n") as fh:
        writer = csv.DictWriter(fh, fieldnames=[
            "sample_id", "case_id", "pollutant_name_zh", "pollutant_name_en",
            "broad_category", "route_shape", "oxygen_condition", "prompt_hash",
            "leakage_status", "name_unique_check", "route_qualifier_check",
            "teacher_decision", "teacher_notes"], delimiter="\t",
            lineterminator="\n")
        writer.writeheader()
        for index, case in enumerate(sample_rows, start=1):
            writer.writerow({
                "sample_id": "G2-S%02d" % index,
                "case_id": case["case_id"],
                "pollutant_name_zh": case["pollutant_name_zh"],
                "pollutant_name_en": case["pollutant_name_en"],
                "broad_category": case["broad_category"],
                "route_shape": case["graph_status"],
                "oxygen_condition": case["oxygen_condition"] or "null",
                "prompt_hash": next(
                    r["messages_sha256"] for r in prompt_hash_rows
                    if r["case_id"] == case["case_id"]),
                "leakage_status": "PENDING_TEACHER_REVIEW",
                "name_unique_check": "PENDING_TEACHER_REVIEW",
                "route_qualifier_check": "PENDING_TEACHER_REVIEW",
                "teacher_decision": "",
                "teacher_notes": "",
            })

    print("[5] report / manifest / SHA256SUMS / gate")
    hits = read_tsv(os.path.join(G2, "leakage_hits.tsv"))
    collision_cases = sorted(set(r["case_id"] for r in hits
                                 if r["classification"] == "ROUTE_GOLD_COLLISION"))
    report = build_report(case_rows, hits, collision_cases, oxygen_pending,
                          sample_rows, buckets, extra, prompt_sha, template_sha,
                          schema_sha)
    with open(os.path.join(G2, "G2_BUILD_REPORT.md"), "w",
              encoding="utf-8", newline="\n") as fh:
        fh.write(report)

    manifest = {
        "manifest_version": "G2_questions_manifest_v1",
        "g2_status": "READY_FOR_REVIEW",
        "formal_cases": len(case_rows),
        "rendered_messages": len(case_rows),
        "g1_gold_manifest_sha256": sha256_file(os.path.join(
            G1, "G1_gold.manifest.json")),
        "g1_counts_sha256": sha256_file(os.path.join(G1, "counts.json")),
        "teacher_approval_source_path": ("00_Authority_Teacher_Plan/"
                                         "TEACHER_REPLY_BIOSYSMODB150_G1_"
                                         "APPROVAL_2026-09-27.md"),
        "teacher_approval_sha256": approval_sha,
        "collector_prompt_sha256": prompt_sha,
        "collector_blank_template_sha256": template_sha,
        "collector_answer_schema_sha256": schema_sha,
        "pollutant_zh_map_sha256": sha256_file(os.path.join(
            G2, "pollutant_name_zh_map.tsv")),
        "sample_seed": SAMPLE_SEED,
        "sample_n": len(sample_rows),
        "unexplained_leakage_hits": sum(
            1 for r in hits if r["classification"] == "UNEXPLAINED"),
        "route_gold_collision_cases": collision_cases,
        "pending_oxygen_review_cases": oxygen_pending,
        "note": ("G2 renders the frozen collector prompt/template/schema; the "
                 "rendered messages are byte-identical to what the collector "
                 "would dispatch to all five models (single user message, no "
                 "system message, per the frozen contract design)"),
    }
    with open(os.path.join(G2, "G2_questions.manifest.json"), "w",
              encoding="utf-8", newline="\n") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")

    gates_dir = os.path.join(STAGE, "gates")
    gate_doc = {
        "stage": "G2_questions",
        "status": "READY_FOR_REVIEW",
        "generated_utc": __import__("datetime").datetime.utcnow()
        .strftime("%Y-%m-%dT%H:%M:%SZ"),
        "input_manifest": {
            "path": os.path.join(G2, "G2_questions.manifest.json"),
            "sha256": sha256_file(os.path.join(G2, "G2_questions.manifest.json")),
        },
        "upstream_gate": {
            "path": "gates/G1_gold.stage_gate.json",
            "sha256": sha256_file(os.path.join(STAGE, "gates",
                                               "G1_gold.stage_gate.json")),
            "status": "PASS",
        },
        "teacher_approval": {
            "path": manifest["teacher_approval_source_path"],
            "sha256": approval_sha,
        },
        "tests": {
            "builder": "build_g2_questions.py exit 0",
            "leakage_scan": "scan_g2_leakage.py exit 0 (unexplained hits = 0)",
            "independent_validator": "validate_g2_questions.py (run separately)",
        },
        "counts": {
            "formal_cases": len(case_rows),
            "rendered_messages": len(case_rows),
            "teacher_sample_n": len(sample_rows),
            "unexplained_leakage_hits": manifest["unexplained_leakage_hits"],
        },
        "reviewer": None,
        "approval_source": None,
        "review_due": ("teacher 13-case manual sample review "
                       "(teacher_sample_review.tsv) incl. ROUTE_GOLD_COLLISION "
                       "and pending-oxygen items"),
        "next_stage_allowed": False,
        "next_stage": "G3_scorer (blocked until teacher G2 sign-off)",
    }
    with open(os.path.join(gates_dir, "G2_questions.stage_gate.json"), "w",
              encoding="utf-8", newline="\n") as fh:
        json.dump(gate_doc, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    sums = []
    for dirpath, dirnames, filenames in os.walk(G2):
        dirnames[:] = sorted(dirnames)
        for name in sorted(filenames):
            if name == "SHA256SUMS":
                continue
            path = os.path.join(dirpath, name)
            sums.append((sha256_file(path), os.path.relpath(path, G2)))
    with open(os.path.join(G2, "SHA256SUMS"), "w", encoding="utf-8",
              newline="\n") as fh:
        for digest, rel in sorted(sums, key=lambda x: x[1]):
            fh.write("%s  %s\n" % (digest, rel))
    print("G2 build complete: %d cases, %d rendered messages, sample=%d, "
          "collisions=%s, pending oxygen=%d"
          % (len(case_rows), len(case_rows), len(sample_rows),
             collision_cases or "NONE", len(oxygen_pending)))
    return 0


def build_report(case_rows, hits, collision_cases, oxygen_pending, sample_rows,
                 buckets, extra, prompt_sha, template_sha, schema_sha):
    lines = []
    add = lines.append
    add("# G2 question rendering and leakage audit (READY_FOR_REVIEW)\n")
    add("- formal cases: **%d** (G1 PASS, teacher approval bound); every case "
        "rendered with the FROZEN collector prompt/template/schema -- the "
        "messages are byte-identical to the future five-model dispatch "
        "(single user message, no system message, per the frozen contract "
        "design).\n" % len(case_rows))
    add("- prompt/template/schema SHAs: `%s` / `%s` / `%s` (collector files, "
        "read-only copies)\n" % (prompt_sha[:16], template_sha[:16], schema_sha[:16]))
    add("\n## 1. Unexplained leakage: **0**\n")
    add("- the scan covers the COMPLETE final user message of every case: "
        "case metadata block + full blank JSON template (one empty step / "
        "profile / evidence member format, 15 trait fields) + compact v2 "
        "schema + all enums and rules. The forbidden set per case comes only "
        "from that case's own G1 gold (names/aliases, terminals, enzymes, "
        "ECs, organisms, TaxIDs, record ids, SMILES, step labels).\n")
    classifications = collections.Counter(r["classification"] for r in hits)
    add("- hit classifications: `%s`\n" % json.dumps(dict(classifications)))
    add("\n## 2. ROUTE_GOLD_COLLISION (teacher review)\n")
    if collision_cases:
        for case_id in collision_cases:
            rows = [r for r in hits if r["case_id"] == case_id
                    and r["classification"] == "ROUTE_GOLD_COLLISION"]
            add("- %s: %s\n" % (case_id, "; ".join(
                "%s(%s)" % (r["token"], r["gold_category"]) for r in rows)))
        add("- these route-qualifier tokens are also gold endpoints/"
            "intermediates of their own case: kept in the message (the route "
            "qualifier is the frozen pathway name), flagged, never silently "
            "auto-allowed.\n")
    else:
        add("- none.\n")
    add("\n## 3. Pending oxygen review\n")
    add("- %d / %d cases render 氧条件 = null（未指定）: the frozen source "
        "says 'No data'; no Aerobic/Anaerobic was guessed. The %d cases with "
        "source values use them verbatim (aerobic/anaerobic/mixed).\n"
        % (len(oxygen_pending), len(case_rows),
           len(case_rows) - len(oxygen_pending)))
    add("\n## 4. Teacher sample (seed %d, n=%d)\n" % (SAMPLE_SEED, len(sample_rows)))
    add("- coverage: oxygen buckets %s; graph shapes %s; step terciles %s; "
        "broad categories %s of 11\n"
        % (sorted(buckets["oxygen"]), sorted(buckets["graph"]),
           sorted(buckets["tercile"]), len(buckets["category"])))
    add("- cases: %s\n" % ", ".join(r["case_id"] for r in sample_rows))
    add("- each sample row carries the prompt hash and the pending checks "
        "(name uniqueness, route qualifier adequacy) for the teacher.\n")
    add("\n## 5. Gate\n")
    add("- G2 = READY_FOR_REVIEW, next_stage_allowed=false; G3/G4/G5/G6 not "
        "started; zero API calls. PASS requires the teacher's 13-case manual "
        "review sign-off.\n")
    return "\n".join(lines)


import subprocess  # noqa: E402  (used in the leakage-scan invocation above)

if __name__ == "__main__":
    sys.exit(main())
