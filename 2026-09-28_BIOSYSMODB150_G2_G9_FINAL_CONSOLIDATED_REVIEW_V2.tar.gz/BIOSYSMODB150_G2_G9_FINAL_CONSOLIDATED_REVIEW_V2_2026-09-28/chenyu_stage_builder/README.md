# chenyu_stage_builder

Deterministic, key-free builder for Chenyu stage packages (G4/G5/G6) + receive-side validator + package_spec + offline example packages.

Example packages: live_disabled=true, authorized_new_api_requests=0, forbidden-content scan clean. Live-enabled packages refuse generation unless upstream gates are PASS and G4 JIT anchor/authority snapshots are frozen. Tool only; using it later does not authorize this round.

Status: OFFLINE_ONLY_NOT_AUTHORIZED | next_stage_allowed=false | api_calls=0
