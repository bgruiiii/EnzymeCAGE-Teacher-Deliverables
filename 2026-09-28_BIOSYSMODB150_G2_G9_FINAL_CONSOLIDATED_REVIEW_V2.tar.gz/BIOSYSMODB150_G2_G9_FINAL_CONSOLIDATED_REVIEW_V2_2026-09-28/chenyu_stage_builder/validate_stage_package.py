#!/usr/bin/env python3
"""validate_stage_package.py -- receiving-side validator (Chenyu or local).
Refuses a package that (a) lacks live_disabled when it is an offline example,
(b) contains a key/gold/scorer/answer pattern, (c) has non-NOT_DISPATCHED slots,
(d) mis-binds frozen hashes. Deterministic, no network."""
import argparse, hashlib, json, os, sys
def sha(p): return hashlib.sha256(open(p,"rb").read()).hexdigest()
FORB=["DASHSCOPE_API_KEY=","Bearer ","sk-","/G1_gold/","hidden gold","evidence_lookup_index_manifest.json"]
F=[];N=[0]
def ck(n,ok,d=""):
    N[0]+=1
    if not ok: F.append({"check":n,"detail":str(d)[:200]}); print("  [FAIL]",n,str(d)[:120])
def validate(pkg_dir, offline_example=True):
    body=open(os.path.join(pkg_dir,"package.json"),encoding="utf-8").read()
    for p in FORB: ck("no_forbidden_%s"%p.replace("=",""), p not in body, p)
    pk=json.loads(body)
    ck("slots_not_dispatched", all(s["dispatch_status"]=="NOT_DISPATCHED" for s in pk["task_matrix"]))
    ck("api_zero", pk["api_calls"]==0 and pk["authorized_new_api_requests"]==0)
    if offline_example:
        ck("offline_live_disabled", pk["live_disabled"] is True)
    return pk
if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--package-dir",default="chenyu_stage_builder/offline_example_packages/G4")
    ap.add_argument("--all",action="store_true")
    a=ap.parse_args()
    dirs=(["chenyu_stage_builder/offline_example_packages/"+s for s in ("G4","G5","G6")] if a.all else [a.package_dir])
    for d in dirs:
        print("== validate",d); validate(d)
    print()
    if F: print("STAGE PACKAGE VALIDATION: FAIL %d/%d"%(len(F),N[0])); sys.exit(1)
    print("STAGE PACKAGE VALIDATION: PASS (%d checks, 0 failures)"%N[0])
