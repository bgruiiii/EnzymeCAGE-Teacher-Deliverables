# Chenyu G4 stage package (live_disabled=True)
authorized_new_api_requests=0; api_calls=0; status=OFFLINE_ONLY_NOT_AUTHORIZED.
Endpoint key read from env at runtime, never bundled. No gold/scorer/answers/keys inside.
