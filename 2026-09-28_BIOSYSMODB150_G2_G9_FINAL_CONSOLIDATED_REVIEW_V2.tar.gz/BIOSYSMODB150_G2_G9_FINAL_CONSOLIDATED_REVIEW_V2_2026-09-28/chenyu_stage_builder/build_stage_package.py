#!/usr/bin/env python3
"""build_stage_package.py -- deterministic, key-free Chenyu stage-package builder
for G4/G5/G6. OFFLINE ONLY: refuses to mark a package live-authorized unless
upstream gates + JIT anchor are supplied. Produces the package tree + a
receiving-side verification manifest. Never bundles keys/gold/scorer/answers.
"""
import argparse, hashlib, json, os, sys
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
ROOT=os.path.abspath(os.path.join(STAGE,os.pardir)); COLLECTOR=os.path.join(ROOT,"24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")
def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as fh:
        for b in iter(lambda: fh.read(1<<20),b""): h.update(b)
    return h.hexdigest()
MODELS=["qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"]
ALLOW=["task_matrix","models","frozen_hashes","limits_caps","stage_gate_template","execution_scripts","receiver_validator","README_EXECUTE.md","requirements.lock","SHA256SUMS"]
FORBIDDEN_PATTERNS=["DASHSCOPE_API_KEY=","Bearer ","sk-", "hidden_gold","/G1_gold/","quarantine/cases.tsv","G3_scorer/scorer.py","evidence_lookup_index_manifest.json","SYNTHETIC"] # last is fixture guard for live pkgs
def build(stage, out_dir, anchor_utc=None, authority_snapshots=None, g4_search_decision=None,
          g5_pass=False, upstream_gates=None):
    """Returns (package_dict, live_allowed_bool). live requires all conditions."""
    os.makedirs(out_dir, exist_ok=True)
    # matrix rows by stage
    slots={"G4":15,"G5":15,"G6":50}[stage]
    live_ok=True
    if stage=="G4" and not (anchor_utc and authority_snapshots): live_ok=False
    if stage=="G5" and g4_search_decision not in ("ALL_PASS","ANY_NOT_PASS"): live_ok=False
    if stage=="G6" and not g5_pass: live_ok=False
    matrix=[{"slot_id":"%s-S%03d"%(stage,i+1),"dispatch_status":"NOT_DISPATCHED"} for i in range(slots)]
    pkg={
      "stage":stage,"status":"OFFLINE_ONLY_NOT_AUTHORIZED",
      "live_disabled": (not live_ok),
      "authorized_new_api_requests": 0,
      "api_calls":0,"next_stage_allowed":False,
      "models_exact_ids":MODELS,"endpoint_env_var":"DASHSCOPE_API_KEY",
      "endpoint_value":"NOT_BUNDLED_READ_FROM_ENV_AT_RUNTIME",
      "limits":{"phase_caps":{"G4_search":15,"G5_smoke":15,"G6_pilot":50},"total_cap":80},
      "frozen_hashes":{"collector_prompt":sha(os.path.join(COLLECTOR,"prompts","unified_collection_v2.txt")),
                       "answer_schema":sha(os.path.join(COLLECTOR,"schemas","biodegradation_answer_v2.schema.json")),
                       "blank_template":sha(os.path.join(COLLECTOR,"templates","biodegradation_answer_v2.blank.template.json")),
                       "g1_gold_manifest":sha(os.path.join(STAGE,"G1_gold","G1_gold.manifest.json"))},
      "anchor_utc":anchor_utc,"authority_url_snapshots":authority_snapshots,
      "g4_search_decision":g4_search_decision,"upstream_gates":upstream_gates or {},
      "task_matrix":matrix,
      "note":"example/offline package; live-enabled packages require JIT anchor + upstream PASS gates",
    }
    body=json.dumps(pkg,ensure_ascii=False,indent=2,sort_keys=True)
    # forbidden-content scan over the serialized package
    hits=[p for p in FORBIDDEN_PATTERNS if p in body and not (p=="SYNTHETIC" and not live_ok)]
    open(os.path.join(out_dir,"package.json"),"w",encoding="utf-8",newline="\n").write(body+"\n")
    readme=("# Chenyu %s stage package (live_disabled=%s)\n"
            "authorized_new_api_requests=0; api_calls=0; status=OFFLINE_ONLY_NOT_AUTHORIZED.\n"
            "Endpoint key read from env at runtime, never bundled. No gold/scorer/answers/keys inside.\n"
            % (stage, pkg["live_disabled"]))
    open(os.path.join(out_dir,"README_EXECUTE.md"),"w",encoding="utf-8").write(readme)
    m={"stage":stage,"live_disabled":pkg["live_disabled"],"forbidden_hits":hits,
       "package_sha256":sha(os.path.join(out_dir,"package.json"))}
    json.dump(m,open(os.path.join(out_dir,"RECEIPT.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True)
    open(os.path.join(out_dir,"RECEIPT.json"),"a").write("\n")
    return pkg, live_ok, len(hits)
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage",required=True,choices=["G4","G5","G6"])
    ap.add_argument("--out",default=None)
    ap.add_argument("--anchor-utc",default=None)
    a=ap.parse_args()
    out=a.out or os.path.join(HERE,"offline_example_packages",a.stage)
    pkg,live,hits=build(a.stage,out,anchor_utc=a.anchor_utc)
    print("built %s offline example -> live=%s forbidden_hits=%d authorized=0" % (a.stage, live, hits))
    return 0
if __name__=="__main__":
    sys.exit(main())
