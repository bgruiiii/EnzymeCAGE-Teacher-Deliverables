#!/usr/bin/env python3
"""run_operational_rehearsal.py -- full-chain gate rehearsal on PURE SYNTHETIC
gate states: G4 mock decision -> G5 mock gate -> G6 mock gate -> G7 empty budget
blocks G8, plus the 8 mandated rejection paths. The gate machine mirrors the
chenyu_stage_builder live_rules and the teacher approval (80-cap, G5 15/15,
G6 >=49/50 & truncation<=5/50, G7 hash-bound budget signoff, G8->G9 hash match).
Additionally one REAL builder call proves current on-disk state refuses live G4.
Zero API, zero dispatch; every state is SYNTHETIC_OFFLINE_FIXTURE."""
import json, os, shutil, sys, tempfile
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
sys.path.insert(0,os.path.join(STAGE,"chenyu_stage_builder"))
import build_stage_package as bsp
FIX="SYNTHETIC_OFFLINE_FIXTURE"
def g2(s="PASS"): return {"status":s}
def g3(s="PASS",frozen=True): return {"status":s,"frozen":frozen}
def ok_state(**kw):
    st={"fixture":FIX,"G2":g2(),"G3":g3(),
        "G4":{"decision":"ALL_PASS","anchor_utc":"JIT_FROZEN","authority_snapshots_hashed":True},
        "G5":{"json_valid":"15/15"},
        "G6":{"json_valid":"50/50","truncated":"0/50","morphology_review":"DONE","budget_estimate":"DONE"},
        "G7":{"teacher_budget_signed":True,"bound_hashes_match":True},
        "G8":{"result_manifest_sha_match":True}}
    for k,v in kw.items():
        if isinstance(v,tuple): st[v[0]].update({v[1]:v[2]})
        else: st[k]=v
    return st
def evaluate(st):
    """returns dict stage->(decision, blocker_code)"""
    d={}
    g4ok = st["G2"]["status"]=="PASS" and st["G3"]["status"]=="PASS" and st["G3"]["frozen"] is True \
           and st["G4"].get("anchor_utc") and st["G4"].get("authority_snapshots_hashed")
    d["G4_live"]=("ALLOW","") if g4ok else ("REFUSE",
        "G2_NOT_PASS" if st["G2"]["status"]!="PASS" else
        ("G3_NOT_PASS_OR_UNFROZEN" if st["G3"]["status"]!="PASS" or not st["G3"]["frozen"] else "G4_JIT_ANCHOR_MISSING"))
    if not g4ok: d.update({k:("REFUSE","UPSTREAM_G4_NOT_LIVE") for k in ("G5","G6","G7_signoff","G8","G9")}); return d
    d["G5"]=("ALLOW","") if st["G4"]["decision"] in ("ALL_PASS","SELECTED") else ("REFUSE","G4_SEARCH_STATE_MIXED")
    if d["G5"][0]!="ALLOW": d.update({k:("REFUSE","UPSTREAM_G5_NOT_PASS") for k in ("G6","G7_signoff","G8","G9")}); return d
    nv=int(st["G5"]["json_valid"].split("/")[0])
    d["G6"]=("ALLOW","") if nv==15 else ("REFUSE","G5_JSON_NOT_15_OF_15(%s)"%st["G5"]["json_valid"])
    if d["G6"][0]!="ALLOW": d.update({k:("REFUSE","UPSTREAM_G6_NOT_PASS") for k in ("G7_signoff","G8","G9")}); return d
    j6=int(st["G6"]["json_valid"].split("/")[0]); tr=int(st["G6"]["truncated"].split("/")[0])
    blockers=[]
    if j6<49: blockers.append("G6_JSON_BELOW_49_OF_50(%d/50)"%j6)
    if tr>5: blockers.append("G6_TRUNCATION_ABOVE_5_OF_50(%d/50)"%tr)
    if st["G6"].get("morphology_review")!="DONE": blockers.append("G6_MORPHOLOGY_REVIEW_MISSING")
    if st["G6"].get("budget_estimate")!="DONE": blockers.append("G6_BUDGET_ESTIMATE_MISSING")
    d["G7_signoff"]=("ALLOW","") if not blockers else ("REFUSE",";".join(blockers))
    if d["G7_signoff"][0]!="ALLOW": d.update({"G8":("REFUSE","UPSTREAM_G7_UNSIGNED"),"G9":("REFUSE","UPSTREAM_G8_INCOMPLETE")}); return d
    d["G8"]=("ALLOW","") if st["G7"].get("teacher_budget_signed") and st["G7"].get("bound_hashes_match") \
           else ("REFUSE","G7_TEACHER_BUDGET_SIGNOFF_MISSING")
    if d["G8"][0]!="ALLOW": d["G9"]=("REFUSE","UPSTREAM_G8_INCOMPLETE"); return d
    d["G9"]=("ALLOW","") if st["G8"].get("result_manifest_sha_match") else ("REFUSE","G8_RESULT_HASH_MISMATCH")
    return d
out={}
rows=[]
def add(cid,stage,inject,expect,frag):
    st=ok_state()
    if inject is not None: st[inject[0]][inject[1]]=inject[2]
    r=evaluate(st); dec,blk=r[stage]
    ok=dec==expect and (frag in blk if frag else dec=="ALLOW")
    out[cid]=ok
    rows.append((cid,stage,json.dumps(inject,ensure_ascii=False) if not isinstance(inject,str) else inject,expect,frag,dec,blk,ok))
# happy chain: synthetic all-pass through G6/G7 then G7-EMPTY blocks G8
add("chain_happy_G4toG7","G7_signoff",None,"ALLOW","")
add("chain_G7empty_blocks_G8","G8",("G7","teacher_budget_signed",False),"REFUSE","G7_TEACHER_BUDGET_SIGNOFF_MISSING")
# 8 mandated rejection paths
add("reject1_G2_not_pass","G4_live",("G2","status","READY_FOR_REVIEW"),"REFUSE","G2_NOT_PASS")
add("reject2_G3_unfrozen","G4_live",("G3","frozen",False),"REFUSE","G3_NOT_PASS_OR_UNFROZEN")
add("reject3_mixed_search","G5",("G4","decision","MIXED_UNDECIDED"),"REFUSE","G4_SEARCH_STATE_MIXED")
add("reject4_G5_14_of_15","G6",("G5","json_valid","14/15"),"REFUSE","G5_JSON_NOT_15_OF_15")
add("reject5_G6_48_of_50","G7_signoff",("G6","json_valid","48/50"),"REFUSE","G6_JSON_BELOW_49_OF_50")
add("reject6_G6_truncation_6","G7_signoff",("G6","truncated","6/50"),"REFUSE","G6_TRUNCATION_ABOVE_5_OF_50")
add("reject7_no_G7_budget","G8",("G7","teacher_budget_signed",False),"REFUSE","G7_TEACHER_BUDGET_SIGNOFF_MISSING")
add("reject8_G8_hash_mismatch","G9",("G8","result_manifest_sha_match",False),"REFUSE","G8_RESULT_HASH_MISMATCH")
# rejection must cascade: G2-not-pass blocks even G9 downstream
st=ok_state(); st["G2"]["status"]="READY_FOR_REVIEW"; r=evaluate(st)
out["cascade_blocks_all_downstream"]=all(r[k][0]=="REFUSE" for k in ("G5","G6","G7_signoff","G8","G9"))
# evidence: the real chenyu builder on CURRENT on-disk state refuses live G4 (G2 not PASS)
tmp=tempfile.mkdtemp(prefix="opreh_")
try:
    pkg,live_ok,hits=bsp.build("G4",os.path.join(tmp,"g4"))
    out["real_builder_refuses_current_state"]= (live_ok is False and pkg.get("live_disabled") is True
        and pkg.get("authorized_new_api_requests")==0)
except TypeError:
    pkg,live_ok=bsp.build("G4",os.path.join(tmp,"g4"))[:2]
    out["real_builder_refuses_current_state"]=bool(not live_ok)
finally: shutil.rmtree(tmp,ignore_errors=True)
passed=sum(1 for v in out.values() if v)
json.dump({"fixture_label":FIX,"api_calls":0,"real_dispatch_attempts":0,"checks_passed":passed,
 "checks_total":len(out),"results":out,
 "cases":[{"case_id":c,"gate":g,"injected_state":i,"expected":e,"expected_blocker":f,"actual":d,"actual_blocker":b,"pass":o}
          for c,g,i,e,f,d,b,o in rows]},
 open(os.path.join(HERE,"rehearsal_results.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True); open(os.path.join(HERE,"rehearsal_results.json"),"a").write("\n")
with open(os.path.join(HERE,"rehearsal_cases.tsv"),"w",encoding="utf-8") as fh:
    fh.write("case_id\tgate\tinjected_state\texpected_decision\texpected_blocker\tactual_decision\tactual_blocker\tverdict\tfixture_label\n")
    for c,g,i,e,f,d,b,o in rows: fh.write("\t".join([c,g,str(i),e,f,d,b,"PASS" if o else "FAIL",FIX])+"\n")
print("operational rehearsal checks %d/%d"%(passed,len(out)))
for k,v in out.items(): print(("OK  " if v else "FAIL ")+k)
sys.exit(0 if passed==len(out) else 1)
