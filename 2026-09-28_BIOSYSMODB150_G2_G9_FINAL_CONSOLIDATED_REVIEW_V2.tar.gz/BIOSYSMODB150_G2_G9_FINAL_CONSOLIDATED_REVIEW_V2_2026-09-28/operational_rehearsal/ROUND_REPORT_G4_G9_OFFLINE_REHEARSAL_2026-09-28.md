# G4-G9 离线运行编排与故障演练 — 轮次报告（2026-09-28）

提示词：LOCAL_AI_BIOSYSMODB150_G4_G9_OFFLINE_OPERATIONAL_REHEARSAL_EXECUTOR_ONLY_20260928.md
提示词 SHA256：887508ec3ff4a6b859894abf15bf496686d9f1c488e7bf370d1a0555d41e2f40
FINAL_STATUS=OFFLINE_OPERATIONAL_REHEARSAL_PASS
API_CALLS=0 | REAL_DISPATCH_ATTEMPTS=0 | CHENYU_UPLOAD_REQUIRED=false

## 结果概览
| 工作流 | 状态 | 证据 |
|---|---|---|
| chenyu_stage_builder | 27/27 validator通过；4个示例包 live_disabled=true, authorized_new_api_requests=0；G4缺anchor时 live 拒绝 | validate_stage_package.py --all |
| failure_rehearsal | 17/17 检查通过（16场景，含429/503/timeout/半截SSE/length/schema INVALID/非JSON/空正文/重复chunk/同键重启/终态恢复/写盘中断恢复/阶段帽/80封套/无密钥落盘）；validator 39 ok 0 err；mutation 5/5 | recovery_report.json, failure_matrix.tsv, synthetic_runs/ |
| G8_formal_preflight | 矩阵恰好 121×5=605 行，全部 NOT_DISPATCHED、dispatch_api_calls=0；同case五模型 messages_sha256 一致且与G2双源交叉核对；scorer/search/param 均 PENDING_* 未擅自补值；validator 27 ok；mutation 5/5 | formal_task_matrix.tsv 等 |
| G9_reporting_preflight | 三轴分离模板仅表头；±5pp敏感性10变体重归一严格=100（程序复核）；合成605行仅formal 121；报告显著SYNTHETIC标识+不可发布声明；scorer绑定PENDING；validator 30 ok；mutation 5/5 | SYNTHETIC_G9_REPORT.md, sensitivity_spec.json |
| operational_rehearsal | 8/8 拒绝路径 + happy chain + G7空预算阻断G8 + 级联拒绝 + 真实builder对当前盘面状态拒绝live G4 = 12/12；validator 23 ok；mutation 5/5 | rehearsal_results.json, OPERATIONAL_REHEARSAL_REPORT.md |

## 输入状态硬门（§1）与完整性
- G1=PASS(formal_n=121)、G2=READY_FOR_REVIEW、G3=PREPARED_PENDING_G2_SIGNOFF(frozen=false)、G4-G6=PREPARED_NOT_AUTHORIZED_TO_RUN、G7=TEMPLATE_ONLY_NOT_APPROVED；D0 143/143；offline readiness 218/218（stage_blockers.tsv 按§8更新后已同步其SHA256SUMS）。
- canonical 快照复核：/tmp/canon_before_rehearsal.json 三个 manifest SHA 与当前一致（validate_g4g9_assembly.py "canonical_unchanged"）。
- 真实采集 runs/ 目录 0 个新增/修改文件（2026-09-28 以来）。
- 五目录双跑字节一致（SHA256SUMS cmp 通过）；无 __pycache__/.pyc 入包；快照仅做文档化归一（路径取基名、测量型wall-clock移除；answer 文本逐字节保留）。

## 未授权阶段状态
全部 OFFLINE_ONLY_NOT_AUTHORIZED / next_stage_allowed=false / api_calls=0；执行器未自签任何阶段 PASS。
