# operational_rehearsal

Full-chain gate rehearsal on synthetic gate states: happy chain G4 mock decision -> G5 -> G6 -> G7, plus G7-empty-blocks-G8 and the 8 mandated rejection paths (G2 not PASS; G3 unfrozen; mixed search; 14/15; 48/50; truncation 6/50; no G7 budget; G8 hash mismatch), cascade refusal, and one REAL chenyu-builder call proving the current on-disk state (G2=READY_FOR_REVIEW) refuses a live-enabled G4 package.

Status: OFFLINE_ONLY_NOT_AUTHORIZED | next_stage_allowed=false | api_calls=0
