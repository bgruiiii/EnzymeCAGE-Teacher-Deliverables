# Operational Rehearsal Report -- SYNTHETIC_OFFLINE_FIXTURE

Status: OFFLINE_ONLY_NOT_AUTHORIZED | next_stage_allowed=false | api_calls=0 | real_dispatch_attempts=0
Gate machine mirrors chenyu_stage_builder live_rules + teacher approval 2026-09-27 (G5 15/15, G6 >=49/50 & trunc<=5/50, G7 hash-bound signoff, G8->G9 hash match). All states are synthetic.

## Happy chain

| gate | case | decision | blocker |
|---|---|---|---|
| G7_signoff | chain_happy_G4toG7 | ALLOW | - |
| G8 | chain_G7empty_blocks_G8 | REFUSE | G7_TEACHER_BUDGET_SIGNOFF_MISSING |

## Mandated rejection paths (8/8 refused)

| # | case | gate | injected state | expected blocker | actual | verdict |
|---|---|---|---|---|---|---|
| 1 | reject1_G2_not_pass | G4_live | ["G2", "status", "READY_FOR_REVIEW"] | G2_NOT_PASS | REFUSE(G2_NOT_PASS) | PASS |
| 2 | reject2_G3_unfrozen | G4_live | ["G3", "frozen", false] | G3_NOT_PASS_OR_UNFROZEN | REFUSE(G3_NOT_PASS_OR_UNFROZEN) | PASS |
| 3 | reject3_mixed_search | G5 | ["G4", "decision", "MIXED_UNDECIDED"] | G4_SEARCH_STATE_MIXED | REFUSE(G4_SEARCH_STATE_MIXED) | PASS |
| 4 | reject4_G5_14_of_15 | G6 | ["G5", "json_valid", "14/15"] | G5_JSON_NOT_15_OF_15 | REFUSE(G5_JSON_NOT_15_OF_15(14/15)) | PASS |
| 5 | reject5_G6_48_of_50 | G7_signoff | ["G6", "json_valid", "48/50"] | G6_JSON_BELOW_49_OF_50 | REFUSE(G6_JSON_BELOW_49_OF_50(48/50)) | PASS |
| 6 | reject6_G6_truncation_6 | G7_signoff | ["G6", "truncated", "6/50"] | G6_TRUNCATION_ABOVE_5_OF_50 | REFUSE(G6_TRUNCATION_ABOVE_5_OF_50(6/50)) | PASS |
| 7 | reject7_no_G7_budget | G8 | ["G7", "teacher_budget_signed", false] | G7_TEACHER_BUDGET_SIGNOFF_MISSING | REFUSE(G7_TEACHER_BUDGET_SIGNOFF_MISSING) | PASS |
| 8 | reject8_G8_hash_mismatch | G9 | ["G8", "result_manifest_sha_match", false] | G8_RESULT_HASH_MISMATCH | REFUSE(G8_RESULT_HASH_MISMATCH) | PASS |

## Extra integrity checks

- cascade: refusing G4 blocks G5..G9 downstream: True
- real chenyu builder on current on-disk state (G2=READY_FOR_REVIEW) refuses live G4 package: True

**No stage was authorized or executed. Rehearsal only. Do not publish as a result.**
