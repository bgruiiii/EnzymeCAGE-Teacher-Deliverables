#!/usr/bin/env python3
"""validate_operational_rehearsal.py -- independent check of the 8 rejection
paths + happy chain artifacts. Mutation self-test included. Read-only, zero API."""
import json, os, re, shutil, sys, tempfile
HERE=os.path.dirname(os.path.abspath(__file__))
FIX="SYNTHETIC_OFFLINE_FIXTURE"
REQ=["reject1_G2_not_pass","reject2_G3_unfrozen","reject3_mixed_search","reject4_G5_14_of_15",
     "reject5_G6_48_of_50","reject6_G6_truncation_6","reject7_no_G7_budget","reject8_G8_hash_mismatch"]
def validate(d):
    errs=[];oks=[]
    def ck(c,m): (oks if c else errs).append(m)
    R=json.load(open(os.path.join(d,"rehearsal_results.json"),encoding="utf-8"))
    ck(R["fixture_label"]==FIX,"results_label")
    ck(R["api_calls"]==0 and R["real_dispatch_attempts"]==0,"results_api0")
    ck(R["checks_passed"]==R["checks_total"]==len(R["results"]) and all(R["results"].values()),"all_checks_true")
    ck(all(R["results"][k] for k in REQ),"eight_rejections_present")
    ck(R["results"].get("cascade_blocks_all_downstream") is True,"cascade_check")
    ck(R["results"].get("real_builder_refuses_current_state") is True,"real_builder_evidence")
    lines=[l.split("\t") for l in open(os.path.join(d,"rehearsal_cases.tsv"),encoding="utf-8").read().rstrip("\n").split("\n")]
    hdr,data=lines[0],lines[1:]
    ck(len(data)==10,"tsv_10_rows")
    byid={r[0]:r for r in data}
    ck(all(cid in byid for cid in REQ),"tsv_rejection_rows")
    for cid in REQ:
        if cid not in byid: errs.append("tsv_missing_row:"+cid); continue
        r=byid[cid]
        ck(r[3]=="REFUSE" and r[5]=="REFUSE" and r[7]=="PASS" and r[4] and r[4] in r[6],"path_consistent:"+cid)
    for cid in ("chain_happy_G4toG7","chain_G7empty_blocks_G8"):
        ck(cid in byid,"chain_row:"+cid)
    ck(byid["chain_happy_G4toG7"][5]=="ALLOW" and byid["chain_G7empty_blocks_G8"][5]=="REFUSE","chain_semantics")
    rep=open(os.path.join(d,"OPERATIONAL_REHEARSAL_REPORT.md"),encoding="utf-8").read()
    ck(FIX in rep.splitlines()[0],"report_banner")
    ck(all(k in rep for k in REQ),"report_lists_all_8")
    ck("OFFLINE_ONLY_NOT_AUTHORIZED" in rep,"report_offline_status")
    ck(rep.count("PASS")>=8,"report_verdicts")
    return errs,oks
MUTS=["flip_verdict","drop_reject_row","api_nonzero","banner_gone","fake_allow"]
def _mut(d,w):
    if w=="flip_verdict":
        p=os.path.join(d,"rehearsal_results.json"); j=json.load(open(p,encoding="utf-8"))
        j["results"]["reject5_G6_48_of_50"]=False
        j["checks_passed"]-=1; json.dump(j,open(p,"w"),ensure_ascii=False,indent=2,sort_keys=True)
    elif w=="drop_reject_row":
        p=os.path.join(d,"rehearsal_cases.tsv"); ls=open(p,encoding="utf-8").read().rstrip("\n").split("\n")
        ls=[l for l in ls if not l.startswith("reject6_")]; open(p,"w",encoding="utf-8").write("\n".join(ls)+"\n")
    elif w=="api_nonzero":
        p=os.path.join(d,"rehearsal_results.json"); j=json.load(open(p,encoding="utf-8")); j["api_calls"]=3
        json.dump(j,open(p,"w"),ensure_ascii=False,indent=2,sort_keys=True)
    elif w=="banner_gone":
        p=os.path.join(d,"OPERATIONAL_REHEARSAL_REPORT.md")
        s=open(p,encoding="utf-8").read()
        open(p,"w",encoding="utf-8").write(s.replace("SYNTHETIC_OFFLINE_FIXTURE","",1))
    elif w=="fake_allow":
        p=os.path.join(d,"rehearsal_cases.tsv"); ls=open(p,encoding="utf-8").read().rstrip("\n").split("\n")
        for i,l in enumerate(ls):
            if l.startswith("reject4_"):
                c=l.split("\t"); c[3]=c[5]="ALLOW"; ls[i]="\t".join(c)
        open(p,"w",encoding="utf-8").write("\n".join(ls)+"\n")
def selftest():
    ok=True
    for w in MUTS:
        tmp=tempfile.mkdtemp(prefix="opmut_"); dst=os.path.join(tmp,"o"); shutil.copytree(HERE,dst,ignore=shutil.ignore_patterns("__pycache__"))
        _mut(dst,w); errs,_=validate(dst); det=bool(errs); ok=ok and det
        print(("OK  " if det else "FAIL ")+"mutation %s detected: %s"%(w,errs[0] if errs else "NOT-DETECTED")); shutil.rmtree(tmp,ignore_errors=True)
    return ok
def main():
    if "--selftest-mutations" in sys.argv: sys.exit(0 if selftest() else 1)
    errs,oks=validate(HERE)
    print("operational_rehearsal validator: %d ok, %d errors"%(len(oks),len(errs)))
    for e in errs: print("ERR "+e)
    sys.exit(0 if not errs else 1)
if __name__=="__main__": main()
