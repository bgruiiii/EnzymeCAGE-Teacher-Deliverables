#!/usr/bin/env python3
"""write_rehearsal_report.py -- deterministic report from rehearsal_results.json."""
import json, os
HERE=os.path.dirname(os.path.abspath(__file__))
R=json.load(open(os.path.join(HERE,"rehearsal_results.json"),encoding="utf-8"))
rows=R["cases"]
L=["# Operational Rehearsal Report -- SYNTHETIC_OFFLINE_FIXTURE","",
"Status: OFFLINE_ONLY_NOT_AUTHORIZED | next_stage_allowed=false | api_calls=%d | real_dispatch_attempts=%d"%(R["api_calls"],R["real_dispatch_attempts"]),
"Gate machine mirrors chenyu_stage_builder live_rules + teacher approval 2026-09-27 (G5 15/15, G6 >=49/50 & trunc<=5/50, G7 hash-bound signoff, G8->G9 hash match). All states are synthetic.","",
"## Happy chain","","| gate | case | decision | blocker |","|---|---|---|---|"]
for c in rows[:2]: L.append("| %s | %s | %s | %s |"%(c["gate"],c["case_id"],c["actual"],c["actual_blocker"] or "-"))
L+=["","## Mandated rejection paths (8/8 refused)","",
"| # | case | gate | injected state | expected blocker | actual | verdict |","|---|---|---|---|---|---|---|"]
for i,c in enumerate([x for x in rows if x["case_id"].startswith("reject")],1):
    L.append("| %d | %s | %s | %s | %s | %s(%s) | %s |"%(i,c["case_id"],c["gate"],c["injected_state"],
      c["expected_blocker"],c["actual"],c["actual_blocker"],"PASS" if c["pass"] else "FAIL"))
L+=["","## Extra integrity checks","",
"- cascade: refusing G4 blocks G5..G9 downstream: %s"%R["results"]["cascade_blocks_all_downstream"],
"- real chenyu builder on current on-disk state (G2=READY_FOR_REVIEW) refuses live G4 package: %s"%R["results"]["real_builder_refuses_current_state"],
"","**No stage was authorized or executed. Rehearsal only. Do not publish as a result.**",""]
open(os.path.join(HERE,"OPERATIONAL_REHEARSAL_REPORT.md"),"w",encoding="utf-8").write("\n".join(L))
print("report rewritten deterministically")
