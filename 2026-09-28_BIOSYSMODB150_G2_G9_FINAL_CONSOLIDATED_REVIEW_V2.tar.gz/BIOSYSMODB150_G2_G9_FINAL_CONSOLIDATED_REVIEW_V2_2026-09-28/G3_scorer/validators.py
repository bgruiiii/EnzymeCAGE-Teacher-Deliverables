#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validators.py -- answer validation helpers for the G3 scorer candidate.

Three independent axes, never merged:
  * syntax    : json.loads / single full-text fence strip only (same rules as
                the frozen D0 collector);
  * form      : top-level business object (dict) vs array/null/text;
  * schema    : REQUIRED strict (every required key must be present), types,
                enums -- extra fields at ANY nesting level are WARNINGS only,
                preserved verbatim, never a hard failure.
"""

import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
STAGE = os.path.abspath(os.path.join(HERE, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
SCHEMA_PATH = os.path.join(
    TASK_ROOT, "24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24",
    "schemas", "biodegradation_answer_v2.schema.json")

SINGLE_FENCE_RE = re.compile(r"^```[^\n]*\n(.*?)\n?```$", re.DOTALL)
SCHEMA = json.load(open(SCHEMA_PATH, encoding="utf-8"))


def parse_answer(text):
    """(parsed, syntax_status, transform). json.loads or one fence strip."""
    if text is None:
        return None, "EMPTY", "NONE"
    stripped = text.strip()
    if not stripped:
        return None, "EMPTY", "NONE"
    try:
        return json.loads(stripped), "VALID", "NONE"
    except ValueError:
        pass
    fence = SINGLE_FENCE_RE.match(stripped)
    if fence:
        try:
            return json.loads(fence.group(1)), "VALID", "STRIP_SINGLE_FENCE"
        except ValueError:
            return None, "INVALID", "STRIP_SINGLE_FENCE"
    return None, "INVALID", "NONE"


def answer_form(parsed):
    return "OBJECT" if isinstance(parsed, dict) else "NON_OBJECT"


def _resolve(node):
    if isinstance(node, dict) and "$ref" in node:
        ref = node["$ref"]
        if ref.startswith("#/"):
            target = SCHEMA
            for part in ref[2:].split("/"):
                target = target.get(part, {})
            return target
    return node


def schema_validate(parsed):
    """Required-strict + type checks (own implementation, no jsonschema
    dependency); extra keys are collected as warnings, not errors."""
    errors = []
    warnings = []

    def check_type(value, spec, path):
        spec = _resolve(spec)
        types = spec.get("type")
        if types is None:
            return
        types = [types] if isinstance(types, str) else types
        ok = (("object" in types and isinstance(value, dict))
              or ("array" in types and isinstance(value, list))
              or ("string" in types and isinstance(value, str))
              or ("boolean" in types and isinstance(value, bool))
              or ("integer" in types and isinstance(value, int) and not isinstance(value, bool))
              or ("number" in types and isinstance(value, (int, float)))
              or any(t == "null" for t in types) and value is None)
        if not ok:
            errors.append({"path": path, "error": "type",
                           "message": "expected %s, got %s" % (types, type(value).__name__)})

    def walk(value, spec, path):
        spec = _resolve(spec)
        if not isinstance(spec, dict):
            return
        check_type(value, spec, path)
        if isinstance(value, dict):
            props = spec.get("properties") or {}
            for req in spec.get("required") or []:
                if req not in value:
                    errors.append({"path": path, "error": "required",
                                   "message": "missing required field %r" % req})
            for key in value:
                if props and key not in props:
                    warnings.append({"path": path, "unexpected_key": key})
                elif key in props:
                    walk(value[key], props[key], "%s/%s" % (path, key))
        elif isinstance(value, list):
            items = spec.get("items")
            if items:
                for i, item in enumerate(value):
                    walk(item, items, "%s/%d" % (path, i))

    walk(parsed, SCHEMA, "$")
    return errors, warnings


def engineering_status(raw_text, parsed=None, errors=None, warnings=None):
    """The three separately-reported axes (never merged):"""
    parsed, syntax, transform = (parsed, None, None) if False else parse_answer(raw_text)
    errors = errors or []
    warnings = warnings or []
    if parsed is not None and isinstance(parsed, dict):
        errors, warnings = schema_validate(parsed)
    return {
        "json_syntax": syntax,
        "parser_transform": transform,
        "answer_form": answer_form(parsed),
        "schema_required_errors": len(errors),
        "schema_valid": (len(errors) == 0),
        "extra_field_warnings": len(warnings),
        "extra_field_warning_paths": [
            {"path": w["path"], "unexpected_key": w["unexpected_key"]}
            for w in warnings[:50]],
    }
