#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_g3_mocks.py -- construct the three G3 mock answers for case
BIOPATH150_014 (2-nitrobenzoate degradation II) from the frozen G1 gold.

all_correct : every scorable pathway step, SMILES, enzyme/EC, organism
              identity and observed trait answered exactly as gold.
all_wrong   : same shape, wrong route compounds, wrong enzyme, wrong
              microbe/taxid, fake DATABASE_DIRECT record ids, high
              confidence -> recall 0, overclaim > 0, hallucinations > 0.
partial     : mixed correct / null / wrong / high-confidence-no-evidence /
              downstream_continuation / synonym / pending subfield /
              invalid DATABASE_DIRECT / extra JSON field -- every item is
              hand-derived in mock_expected.json.

Mocks are local self-test material only: never sent to any model, never part
of the formal results directory.
"""

import csv
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
G3 = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(G3, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")
CASE = "BIOPATH150_014"
POLLUTANT_ZH = "2-硝基苯甲酸根"
POLLUTANT_EN = "2-Nitrobenzoate"
ROUTE = "2-nitrobenzoate degradation II"
MOCKS = os.path.join(G3, "mocks")


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def load_gold():
    steps = {}
    for r in read_tsv(os.path.join(G1, "reaction_gold.tsv")):
        if r["case_id"] != CASE:
            continue
        sid = r["step_occurrence_id"]
        step = steps.setdefault(sid, {"order": int(r["linear_display_order"]),
                                      "branch": r["branch_id"],
                                      "preds": [p for p in (r["predecessor_step_ids"] or "").split("|") if p],
                                      "subs": [], "prods": [],
                                      "reaction_id": r["reaction_id"]})
        if r["role_label"] == "MAIN_SUBSTRATE":
            step["subs"].append(r)
        elif r["role_label"] == "MAIN_PRODUCT":
            step["prods"].append(r)
    enzymes = [r for r in read_tsv(os.path.join(G1, "enzyme_gold.tsv"))
               if r["case_id"] == CASE]
    organisms = [r for r in read_tsv(os.path.join(G1, "organism_gold.tsv"))
                 if r["case_id"] == CASE and r["scope"] == "STEP"]
    submask = [r for r in read_tsv(os.path.join(G1, "trait_subfield_scoreability_mask.tsv"))
               if r["case_id"] == CASE and r["scoreable"] == "TRUE"]
    return steps, enzymes, organisms, submask


def trait_answer_for(taxid, submask):
    """Observed trait cell values for a profile (gold observed values only)."""
    traits = {}
    for r in read_tsv(os.path.join(G1, "trait_gold.tsv")):
        if r["case_id"] != CASE or r["ncbi_taxid"] != taxid:
            continue
        if r["value_status"] != "OBSERVED":
            continue
        trait = r["trait_id"]
        v = (r.get("value") or "").strip()
        if trait in ("F2", "F3", "F4") and v.lower() in ("", "na", "n/a",
                                                          "no robust majority"):
            field = (r.get("source_field") or "").lower()
            if "minimum" in field:
                v = (r.get("minimum") or "").strip() or v
            elif "maximum" in field:
                v = (r.get("maximum") or "").strip() or v
        if trait not in traits:
            traits[trait] = None
        if v.lower() in ("", "na", "n/a", "no robust majority"):
            continue
        obj_traits = {"F2": {"minimum_c": None, "optimum_c": None, "maximum_c": None,
                             "preference": None},
                      "F3": {"minimum": None, "optimum": None, "maximum": None},
                      "F4": {"minimum": None, "optimum": None, "maximum": None,
                            "unit": None, "category": None},
                      "F14": {"genome_accession": None, "genome_size_bp": None,
                              "gc_percent": None}}
        field = r["source_field"]
        if trait in obj_traits:
            slot = None
            m = re.search(r"minimum|maximum|genome|gc|coding|count", field)
            if trait == "F14" and "OrganismTaxID" not in field and "genome" in field.lower():
                slot = "genome_accession"
            elif trait == "F14" and "GC percentage" in field:
                slot = "gc_percent"
            elif "minimum" in field.lower():
                slot = "minimum_c" if trait == "F2" else "minimum"
            elif "maximum" in field.lower():
                slot = "maximum_c" if trait == "F2" else "maximum"
            elif "unit" in field.lower():
                slot = "unit"
            elif "preference" in field.lower():
                slot = "preference" if trait == "F2" else "category"
            if slot:
                if traits[trait] is None:
                    traits[trait] = dict(obj_traits[trait])
                if traits[trait].get(slot) in (None, ""):
                    try:
                        traits[trait][slot] = float(v) if re.match(r"^-?\d+(\.\d+)?$", v) else v
                    except ValueError:
                        traits[trait][slot] = v
        else:
            if traits[trait] in (None, ""):
                traits[trait] = v.lower() if v.lower() in ("true", "false") else v
    # F5 collection: first accepted number
    for r in read_tsv(os.path.join(G1, "trait_gold.tsv")):
        if (r["case_id"] == CASE and r["ncbi_taxid"] == taxid
                and r["trait_id"] == "F5" and r["value_status"] == "OBSERVED"):
            first = (r.get("value") or "").split("|")[0].strip()
            if first:
                traits["F5"] = {"collection": None, "accession": first}
    for t in ("F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10",
              "F11", "F12", "F13", "F14", "F15"):
        if t not in traits:
            traits[t] = None
    out = {}
    for t, v in traits.items():
        out[t] = {"value": v, "raw_text": None,
                  "evidence_id": ("EVID_%s_%s" % (taxid or "X", t)),
                  "confidence": "high" if v is not None else "unknown"}
    return out, [k for k, v in traits.items() if v is not None]


def main():
    os.makedirs(MOCKS, exist_ok=True)
    steps, enzymes, organisms, submask = load_gold()
    ordered = sorted(steps, key=lambda s: steps[s]["order"])
    # chosen accepted enzyme per step (name+ec) and organism (name+taxid+genome)
    step_enzyme = {}
    for sid in ordered:
        cands = [e for e in enzymes if e["step_occurrence_id"] == sid]
        # prefer one with an EC, else first accepted
        with_ec = [e for e in cands if e["ec_number_normalized"] not in ("", "NOT_OBSERVED")]
        pick = (with_ec or cands)[0]
        step_enzyme[sid] = pick
    step_org = {}
    for sid in ordered:
        pairs = [o for o in organisms if o["step_occurrence_id"] == sid
                 and o["enzyme_id"] == step_enzyme[sid]["enzyme_id"]]
        pairs = pairs or [o for o in organisms if o["step_occurrence_id"] == sid]
        step_org[sid] = pairs[0]
    profiles = {}
    gold_genome = {}
    for o in organisms:
        if o.get("genome_id"):
            gold_genome[o["taxid"] or o["matched_organism_name"]] = o["genome_id"]
    for sid, o in step_org.items():
        key = o["taxid"] or o["matched_organism_name"]
        profiles[key] = o
    evidence = []
    steps_json = []
    for i, sid in enumerate(ordered):
        g = steps[sid]
        enz = step_enzyme[sid]
        org = step_org[sid]
        prof_key = org["taxid"] or org["matched_organism_name"]
        evid_r = "EVID_R_%02d" % (i + 1)
        evid_e = "EVID_E_%02d" % (i + 1)
        evid_o = "EVID_O_%02d" % (i + 1)
        evidence.append({"evidence_id": evid_r, "source_type": "DATABASE_DIRECT",
                         "database": "BIOSYSMOdb", "record_id": g["reaction_id"],
                         "locator": "Reactions_v1.0.csv",
                         "claim_scope": ["step:%s.reaction" % sid], "confidence": "high"})
        evidence.append({"evidence_id": evid_e, "source_type": "DATABASE_DIRECT",
                         "database": "BIOSYSMOdb", "record_id": enz["enzyme_id"],
                         "locator": "Enzymes_v1.0.csv",
                         "claim_scope": ["step:%s.enzyme" % sid], "confidence": "high"})
        evidence.append({"evidence_id": evid_o, "source_type": "DATABASE_DIRECT",
                         "database": "BIOSYSMOdb", "record_id": org["matched_organism_name"],
                         "locator": "Organisms_v1.0.csv",
                         "claim_scope": ["step:%s.microorganism" % sid], "confidence": "high"})
        steps_json.append({
            "step_id": "S%d" % (i + 1), "order": g["order"], "branch_id": g["branch"],
            "predecessor_step_ids": g["preds"],
            "substrates": [{"name": c["identity_name"], "smiles": c["isosmiles"],
                            "role": "main"} for c in g["subs"]],
            "products": [{"name": c["identity_name"], "smiles": c["isosmiles"],
                          "role": "main"} for c in g["prods"]],
            "reaction_type": None,
            "enzyme": {"name": enz["enzyme_name"],
                       "ec_number": (None if enz["ec_number_normalized"] == "NOT_OBSERVED"
                                     else enz["ec_number_normalized"]),
                       "gene_or_protein": None, "confidence": "high",
                       "evidence_id": evid_e},
            "microorganism": {"organism_name": org["matched_organism_name"],
                              "strain": None, "ncbi_taxid": org["taxid"],
                              "organism_profile_id": "ORG_%03d" % (i + 1),
                              "confidence": "high", "evidence_id": evid_o},
            "reaction_evidence_id": evid_r, "trait_evidence_id": None,
            "uncertainty": None,
        })
    profiles_json = []
    used = {}
    for sid, o in step_org.items():
        key = o["taxid"] or o["matched_organism_name"]
        if key in used:
            continue
        used[key] = True
        traits, answered = trait_answer_for(key, submask)
        if gold_genome.get(key):
            f14 = traits.get("F14") or {"value": None}
            if isinstance(f14.get("value"), dict):
                f14["value"]["genome_accession"] = gold_genome[key]
            else:
                traits["F14"] = {"value": {"genome_accession": gold_genome[key],
                                           "genome_size_bp": None, "gc_percent": None},
                                 "raw_text": None, "evidence_id": None,
                                 "confidence": "high"}
        for t in traits:
            if t not in ("F14",):
                pass
        strain_value = None
        for cand in organisms:
            if cand["taxid"] == key and cand["organism_name_raw"] != o["matched_organism_name"]:
                extra = cand["organism_name_raw"][len(o["matched_organism_name"]):].strip()
                if extra:
                    strain_value = extra
                    break
        profiles_json.append({
            "organism_profile_id": next(s["microorganism"]["organism_profile_id"]
                                        for s in steps_json
                                        if s["microorganism"]["ncbi_taxid"] == key),
            "organism_name": o["matched_organism_name"],
            "strain": strain_value, "ncbi_taxid": key, "traits": traits,
        })
    def base():
        return {
            "schema_version": "biodegradation_answer_v2", "case_id": CASE,
            "pollutant_name_zh": POLLUTANT_ZH, "pollutant_name_en": POLLUTANT_EN,
            "route_scope": {"oxygen_condition": "aerobic",
                            "chosen_route_name": ROUTE,
                            "is_single_continuous_route": True, "notes": None},
            "route_summary": None,
        }
    # ---- all_correct
    all_correct = base()
    all_correct.update({
        "steps": steps_json, "organism_profiles": profiles_json,
        "complete_pathway_organism_profile_id": None,
        "central_metabolism_entry": {"products": [], "explanation": None},
        "downstream_continuation": [], "alternative_branches": [],
        "evidence_registry": evidence, "uncertainties": [],
    })

    # ---- all_wrong: same shape, everything from other pathways / fake ids
    all_wrong = base()
    wrong_steps = []
    fake_evidence = []
    for i, sid in enumerate(ordered):
        fake_evidence.append({"evidence_id": "EVID_F_%02d" % (i + 1),
                              "source_type": "DATABASE_DIRECT",
                              "database": "BIOSYSMOdb", "record_id": "BSY-r99999",
                              "locator": "Reactions_v1.0.csv",
                              "claim_scope": ["step:%s.reaction" % sid],
                              "confidence": "high"})
        wrong_steps.append({
            "step_id": "S%d" % (i + 1), "order": steps[sid]["order"],
            "branch_id": None, "predecessor_step_ids": [],
            "substrates": [{"name": "4-Chlorobenzoate", "smiles": "C1=CC(=C(C=C1)C(=O)O)Cl",
                            "role": "main"}],
            "products": [{"name": "4-Hydroxybenzoate", "smiles": "C1=CC(=O)C=CC1=O",
                          "role": "main"}],
            "reaction_type": None,
            "enzyme": {"name": "laccase", "ec_number": "1.10.3.2",
                       "gene_or_protein": None, "confidence": "high",
                       "evidence_id": "EVID_F_%02d" % (i + 1)},
            "microorganism": {"organism_name": "Escherichia coli", "strain": "K-12",
                              "ncbi_taxid": "562",
                              "organism_profile_id": "ORG_%03d" % (i + 1),
                              "confidence": "high", "evidence_id": "EVID_F_%02d" % (i + 1)},
            "reaction_evidence_id": "EVID_F_%02d" % (i + 1), "trait_evidence_id": None,
            "uncertainty": None,
        })
    wrong_profiles = []
    for i, p in enumerate(profiles_json):
        wrong_profiles.append({
            "organism_profile_id": "ORG_%03d" % (i + 1),
            "organism_name": "Escherichia coli", "strain": "K-12", "ncbi_taxid": "562",
            "traits": {t: {"value": ("yes" if t in ("F1", "F9") else None),
                           "raw_text": None, "evidence_id": None,
                           "confidence": "high"} for t in
                       ["F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9",
                        "F10", "F11", "F12", "F13", "F14", "F15"]},
        })
    all_wrong.update({
        "steps": wrong_steps, "organism_profiles": wrong_profiles,
        "complete_pathway_organism_profile_id": None,
        "central_metabolism_entry": {"products": [], "explanation": None},
        "downstream_continuation": [], "alternative_branches": [],
        "evidence_registry": fake_evidence, "uncertainties": [],
    })

    # ---- partial
    partial = base()
    p_steps = []
    # step 1: correct (same as all_correct step 1) + valid evidence
    p_steps.append(json.loads(json.dumps(steps_json[0])))
    # step 2: compounds + enzyme correct; microorganism species right, taxid WRONG;
    # invalid DATABASE_DIRECT organism record; synonym substrate name; extra field
    s2 = json.loads(json.dumps(steps_json[1]))
    s2["substrates"][0]["name"] = s2["substrates"][0]["name"].replace(" acid", "")  # synonym
    s2["microorganism"]["ncbi_taxid"] = "562"
    s2["microorganism"]["organism_name"] = step_org[ordered[1]]["matched_organism_name"]
    s2["extra_note"] = "model added a field: warning only, text preserved"
    s2["reaction_evidence_id"] = "EVID_P_BAD"
    p_steps.append(s2)
    # step 3 (gold step order 3): left UNANSWERED in steps, moved to
    # downstream_continuation -> not extra, but still a recall miss
    gold_missing = ordered[2]
    # one extra wrong main step
    p_steps.append({
        "step_id": "SX", "order": 9, "branch_id": None, "predecessor_step_ids": [],
        "substrates": [{"name": "Benzoate", "smiles": "C1=CC=C(C=C1)C(=O)[O-]", "role": "main"}],
        "products": [{"name": "Benzene-1,2-diol", "smiles": "C1=CC=C(C=C1)O", "role": "main"}],
        "reaction_type": None,
        "enzyme": {"name": "benzoate 1,2-dioxygenase", "ec_number": "1.14.12.3",
                   "gene_or_protein": None, "confidence": "high", "evidence_id": None},
        "microorganism": {"organism_name": None, "strain": None, "ncbi_taxid": None,
                          "organism_profile_id": None, "confidence": "unknown",
                          "evidence_id": None},
        "reaction_evidence_id": None, "trait_evidence_id": None, "uncertainty": None,
    })
    partial_profiles = []
    key0 = step_org[ordered[0]]["taxid"]
    traits0, _ = trait_answer_for(key0, submask)
    partial_profiles.append({"organism_profile_id": "ORG_001",
                             "organism_name": step_org[ordered[0]]["matched_organism_name"],
                             "strain": None, "ncbi_taxid": key0, "traits": traits0})
    # profile for step 2 species-right/taxid-wrong: traits answered null (abstain)
    partial_profiles.append({"organism_profile_id": "ORG_002",
                             "organism_name": "Escherichia coli", "strain": None,
                             "ncbi_taxid": "562",
                             "traits": {t: {"value": None, "raw_text": None,
                                            "evidence_id": None,
                                            "confidence": "unknown"}
                                        for t in ["F1", "F2", "F3", "F4", "F5", "F6",
                                                  "F7", "F8", "F9", "F10", "F11",
                                                  "F12", "F13", "F14", "F15"]}})
    partial.update({
        "steps": p_steps, "organism_profiles": partial_profiles,
        "complete_pathway_organism_profile_id": None,
        "central_metabolism_entry": {"products": [], "explanation": None},
        "downstream_continuation": [{
            "step_id": "D1", "order": None, "branch_id": None,
            "predecessor_step_ids": [],
            "substrates": [{"name": "Anthranilate",
                            "smiles": steps[gold_missing]["subs"][0]["isosmiles"],
                            "role": "main"}],
            "products": [{"name": "Catechol",
                          "smiles": steps[gold_missing]["prods"][0]["isosmiles"],
                          "role": "main"}],
            "reaction_type": None,
            "enzyme": {"name": step_enzyme[gold_missing]["enzyme_name"], "ec_number": None,
                       "gene_or_protein": None, "confidence": "medium", "evidence_id": None},
            "microorganism": {"organism_name": None, "strain": None, "ncbi_taxid": None,
                              "organism_profile_id": None, "confidence": "unknown",
                              "evidence_id": None},
            "reaction_evidence_id": None, "trait_evidence_id": None, "uncertainty": None}],
        "alternative_branches": [],
        "evidence_registry": [
            {"evidence_id": "EVID_R_01", "source_type": "DATABASE_DIRECT",
             "database": "BIOSYSMOdb", "record_id": steps[ordered[0]]["reaction_id"],
             "locator": "Reactions_v1.0.csv",
             "claim_scope": ["step:%s.reaction" % ordered[0]], "confidence": "high"},
            {"evidence_id": "EVID_E_01", "source_type": "DATABASE_DIRECT",
             "database": "BIOSYSMOdb", "record_id": step_enzyme[ordered[0]]["enzyme_id"],
             "locator": "Enzymes_v1.0.csv",
             "claim_scope": ["step:%s.enzyme" % ordered[0]], "confidence": "high"},
            {"evidence_id": "EVID_O_01", "source_type": "DATABASE_DIRECT",
             "database": "BIOSYSMOdb",
             "record_id": step_org[ordered[0]]["matched_organism_name"],
             "locator": "Organisms_v1.0.csv",
             "claim_scope": ["step:%s.microorganism" % ordered[0]], "confidence": "high"},
            {"evidence_id": "EVID_P_BAD", "source_type": "DATABASE_DIRECT",
             "database": "BIOSYSMOdb", "record_id": "BSY-e99999",
             "locator": "Enzymes_v1.0.csv",
             "claim_scope": ["step:%s.microorganism" % ordered[1]], "confidence": "high"},
        ],
        "uncertainties": ["step order 3 moved to downstream_continuation"],
    })

    for name, doc in (("all_correct", all_correct), ("all_wrong", all_wrong),
                      ("partial", partial)):
        with open(os.path.join(MOCKS, "%s.json" % name), "w",
                  encoding="utf-8", newline="\n") as fh:
            json.dump(doc, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")
        print("wrote mocks/%s.json" % name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
