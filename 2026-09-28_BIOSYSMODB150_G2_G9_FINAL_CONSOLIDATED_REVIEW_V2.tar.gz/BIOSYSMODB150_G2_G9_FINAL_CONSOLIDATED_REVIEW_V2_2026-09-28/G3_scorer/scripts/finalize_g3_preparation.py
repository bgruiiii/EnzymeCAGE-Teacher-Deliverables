#!/usr/bin/env python3
"""finalize_g3_preparation.py -- writes G3 manifest, report, gate, SHA256SUMS."""
import hashlib, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
G3 = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(G3, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
G1, G2 = os.path.join(STAGE, "G1_gold"), os.path.join(STAGE, "G2_questions")
CR = os.path.join(TASK_ROOT, "24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")

def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(1<<20), b""): h.update(b)
    return h.hexdigest()

results = json.load(open(os.path.join(G3, "mock_results.json")))
manifest = {
  "manifest_version": "G3_preparation_manifest_v1",
  "status": "PREPARED_PENDING_G2_SIGNOFF",
  "frozen": False,
  "teacher_approval_sha256": "39e08c219aa155d21e687db0976b1fd4df06d1c3d2b8c738ca847bafa47657dd",
  "teacher_approval_path": "00_Authority_Teacher_Plan/TEACHER_REPLY_BIOSYSMODB150_G1_APPROVAL_2026-09-27.md",
  "g1_gold_manifest_sha256": sha(os.path.join(G1, "G1_gold.manifest.json")),
  "g1_inputs_content_manifest_sha256": sha(os.path.join(STAGE, "G1_inputs.content_manifest.json")),
  "g2_questions_manifest_sha256": sha(os.path.join(G2, "G2_questions.manifest.json")),
  "g2_gate_sha256": sha(os.path.join(STAGE, "gates", "G2_questions.stage_gate.json")),
  "collector_bindings": {
      "answer_schema_sha256": sha(os.path.join(CR, "schemas", "biodegradation_answer_v2.schema.json")),
      "blank_template_sha256": sha(os.path.join(CR, "templates", "biodegradation_answer_v2.blank.template.json")),
      "prompt_sha256": sha(os.path.join(CR, "prompts", "unified_collection_v2.txt"))},
  "mock_case_id": "BIOPATH150_014",
  "science_weights_fixed": {"pathway": 0.45, "smiles": 0.10, "enzyme": 0.20,
                            "microbial_identity": 0.15, "traits": 0.10},
  "mock_science_scores": {k: results[k]["science_100"] for k in results},
  "rdkit_version_note": "canonicalization uses rdkit when importable; the frozen G1 version of record is 2026.03.5",
  "real_answers_scored": 0,
  "api_calls": 0,
}
with open(os.path.join(G3, "G3_PREPARATION_MANIFEST.json"), "w", encoding="utf-8") as _fh:
    json.dump(manifest, _fh, ensure_ascii=False, indent=2, sort_keys=True)
open(os.path.join(G3, "G3_PREPARATION_MANIFEST.json"), "a", encoding="utf-8").write("\n")

gate = {"stage": "G3_scorer", "status": "PREPARED_PENDING_G2_SIGNOFF",
        "next_stage_allowed": False, "g2_teacher_review_required": True,
        "input_manifest": {"path": os.path.join(G3, "G3_PREPARATION_MANIFEST.json"),
                           "sha256": sha(os.path.join(G3, "G3_PREPARATION_MANIFEST.json"))},
        "upstream_gate": {"path": "gates/G2_questions.stage_gate.json",
                          "sha256": sha(os.path.join(STAGE, "gates", "G2_questions.stage_gate.json")),
                          "status": "READY_FOR_REVIEW"},
        "teacher_approval": {"path": manifest["teacher_approval_path"],
                             "sha256": manifest["teacher_approval_sha256"]},
        "tests": {"mocks_scored": 3, "expectations_match": "see validate_g3_preparation.py"},
        "frozen": False,
        "note": "PASS is written by no script this round; G3 may be frozen only after the teacher signs the G2 13-case review and, if G2 changed, after re-verifying all hashes and mocks."}
json.dump(gate, open(os.path.join(STAGE, "gates", "G3_scorer.stage_gate.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
open(os.path.join(STAGE, "gates", "G3_scorer.stage_gate.json"), "a", encoding="utf-8").write("\n")

report = """# G3 scorer preparation report (PREPARED_PENDING_G2_SIGNOFF)

Inputs bound: G1 gold manifest, G1 content manifest, G2 questions manifest, G2
gate (READY_FOR_REVIEW), teacher approval `39e08c21...`, collector
prompt/template/schema hashes. `real_answers_scored=0`, `api_calls=0`.

## What was built (candidate, NOT frozen)
- score_recipe.md: five fixed layers 45/10/20/15/10; evidence/engineering/abstention
  axes independent; null=recall-miss not overclaim; extra JSON fields warning-only;
  syntax/object/schema reported separately; smoke/pilot excluded from formal.
- alignment_spec_v1.json: per-side compound identity sets (RDKit canonical
  isomeric, same version for gold and prediction), one-to-one greedy max-Jaccard,
  direction A->B != B->A, recall/extra/order rules, downstream_continuation not
  penalized, split/merge and tie-break handling.
- evidence_scoring_spec_v1.json: reference resolution -> record lookup -> claim
  scope; DATABASE_DIRECT must resolve against the frozen G1 lookup;
  MODEL_INFERENCE / INTERNAL_KNOWLEDGE reported as honesty statistics.
- scorer.py + validators.py: offline implementation; the frozen D0 collector is
  imported read-only for rendering-parity only.
- mocks/all_correct, all_wrong, partial for BIOPATH150_014, each with a hand
  derivation in mock_expected.json; mock_results.json records the scorer output.

## Mock outcomes (science / key axes)
- all_correct: %.2f -- pathway/enzyme/identity/SMILES 100; traits %.2f: the
  residual cells are the F2/F3/F4 word-preference items whose observed gold is a
  category word; numeric-consistent answers under the candidate composition are
  counted there as unmatched. Reported, not hidden: the trait 10%% composition
  is an OPEN DECISION (below). All 9 DATABASE_DIRECT evidences verified, 0
  hallucination, 0 null, 0 overclaim.
- all_wrong: 0.0 in every layer; evidence_hallucination>=3; overclaims>=6;
  recall-missed 3; shape complete but never read as correctness.
- partial: 79.13; 2/3 gold matched (step S01 in downstream only -> recall miss,
  not an extra), 1 extra step, synonym substrate accepted, high-confidence
  wrong enzyme with no evidence -> overclaim 1, null organism -> recall miss,
  invalid BSY-e99999 -> hallucination 1, dangling EVID refs -> 2 ref_missing,
  extra_note -> 1 warning with text preserved; isomeric primary vs achiral
  reference reported separately.

## OPEN DECISIONS (teacher; none silently chosen)
1. Trait 10%% composition: candidate = mean(item accuracy, subfield accuracy),
   completeness reported separately; all_correct lands at 97.73 because a few
   scoreable cells' observed gold is a category word (mesophilic /
   non-halophilic) rather than a scalar. Options: treat word-preference cells as
   satisfied by numeric-consistent answers, exclude them from the accuracy
   denominator, or another frozen rule.
2. Within-layer subindicator weights (currently equal); microbe pair may be
   satisfied by species NAME while the model's TaxID is wrong (partial S03):
   whether a name-only pair passes.
3. Split/merge penalty magnitudes; alignment jaccard threshold 0.5 (candidate).
4. overclaim reporting vs any score deduction (currently report-only, no
   science deduction).
5. F14 genome via traits-F14 vs a profile-level genome field.
6. achiral reference reporting placement (kept out of the primary SMILES number).

## State
- G3 gate = PREPARED_PENDING_G2_SIGNOFF; this round freezes nothing and scores
  no real answer. After the teacher signs the G2 13-case review with no question
  change, the SAME preparation is upgraded to the frozen G3 scorer; if G2 or the
  schema changes, hashes and mocks must be re-verified first. G4/G5/G6 untouched;
  zero API calls.
""" % (results["all_correct"]["science_100"], results["all_correct"]["layers"]["traits"])
open(os.path.join(G3, "G3_PREPARATION_REPORT.md"), "w", encoding="utf-8").write(report)

sums = []
for dp, _dn, fns in os.walk(G3):
    for fn in sorted(fns):
        if fn == "SHA256SUMS": continue
        p = os.path.join(dp, fn)
        sums.append((sha(p), os.path.relpath(p, G3)))
with open(os.path.join(G3, "SHA256SUMS"), "w", encoding="utf-8", newline="\n") as fh:
    for d, r in sorted(sums, key=lambda x: x[1]):
        fh.write("%s  %s\n" % (d, r))
print("finalize done:", len(sums), "files hashed")
