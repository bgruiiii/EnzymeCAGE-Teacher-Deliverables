#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_g3_preparation.py -- independent validator for the G3 preparation
round (does NOT import the builder/scorer decision path for expectations).

It re-runs the scorer as a subprocess on the three mocks, re-checks every
expectation in mock_expected.json against mock_results.json, verifies G1/G2
inputs have not changed (binding hashes), validates the three engineering
axes independently, and confirms the gate and manifest state. Deterministic,
timestamp-free report: repeated runs are byte-identical.
"""

import argparse
import hashlib
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
G3 = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(G3, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")
G2 = os.path.join(STAGE, "G2_questions")

TEACHER_APPROVAL_SHA = ("39e08c219aa155d21e687db0976b1fd4df06d"
                        "1c3d2b8c738ca847bafa47657dd")

FAILURES = []
CHECKS = 0


def check(name, ok, detail=""):
    global CHECKS
    CHECKS += 1
    if not ok:
        FAILURES.append({"check": name, "detail": str(detail)[:300]})
        print("  [FAIL] %s %s" % (name, str(detail)[:200]))
    return ok


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", default=None)
    args = parser.parse_args(argv)

    print("[1] inputs unchanged (G1 + G2 + teacher approval)")
    manifest = json.load(open(os.path.join(G3, "G3_PREPARATION_MANIFEST.json"),
                              encoding="utf-8"))
    check("teacher_approval_sha",
          sha256_file(os.path.join(
              TASK_ROOT, "00_Authority_Teacher_Plan",
              "TEACHER_REPLY_BIOSYSMODB150_G1_APPROVAL_2026-09-27.md"))
          == TEACHER_APPROVAL_SHA
          and manifest["teacher_approval_sha256"] == TEACHER_APPROVAL_SHA)
    check("g1_gold_manifest_binding",
          manifest["g1_gold_manifest_sha256"] == sha256_file(
              os.path.join(G1, "G1_gold.manifest.json")))
    check("g2_questions_manifest_binding",
          manifest["g2_questions_manifest_sha256"] == sha256_file(
              os.path.join(G2, "G2_questions.manifest.json")))
    check("g2_gate_still_ready",
          json.load(open(os.path.join(STAGE, "gates",
                                      "G2_questions.stage_gate.json")))["status"]
          == "READY_FOR_REVIEW")
    with open(os.path.join(G1, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, name = line.rstrip("\n").split("  ", 1)
                check("g1_file_intact_%s" % name,
                      sha256_file(os.path.join(G1, name)) == digest, name)

    print("[2] scorer re-run on the three mocks matches mock_expected")
    expected = json.load(open(os.path.join(G3, "mock_expected.json"), encoding="utf-8"))
    results = {}
    for name in ("all_correct", "all_wrong", "partial"):
        proc = subprocess.run(
            [sys.executable, os.path.join(G3, "scorer.py"),
             "--mock", os.path.join(G3, "mocks", "%s.json" % name),
             "--case", "BIOPATH150_014"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        check("scorer_exit_%s" % name, proc.returncode == 0,
              proc.stdout.decode("utf-8", "replace")[-200:])
        results[name] = json.loads(proc.stdout.decode("utf-8"))
    saved = json.load(open(os.path.join(G3, "mock_results.json"), encoding="utf-8"))
    for name in results:
        check("results_file_stable_%s" % name,
              results[name]["science_100"] == saved[name]["science_100"])
        exp = expected[name]
        for layer, value in exp["layers"].items():
            check("layer_%s_%s" % (name, layer),
                  abs(results[name]["layers"][layer] - value) < 0.05,
                  "%s: expected %s got %s" % (layer, value,
                                              results[name]["layers"][layer]))
        check("science_%s" % name,
              abs(results[name]["science_100"] - exp["science_100"]) < 0.05,
              "expected %s got %s" % (exp["science_100"],
                                      results[name]["science_100"]))
        ev = results[name]["evidence_axis"]
        if "evidence_hallucination" in exp["evidence_axis"]:
            check("evidence_hallucination_%s" % name,
                  ev["evidence_hallucination"] == exp["evidence_axis"]["evidence_hallucination"])
        if "evidence_hallucination_min" in exp["evidence_axis"]:
            check("evidence_hallucination_min_%s" % name,
                  ev["evidence_hallucination"] >= exp["evidence_axis"]["evidence_hallucination_min"])
        if "verified_correct_min" in exp["evidence_axis"]:
            check("verified_min_%s" % name,
                  ev["verified_correct"] >= exp["evidence_axis"]["verified_correct_min"])
        if "verified_correct" in exp["evidence_axis"]:
            check("verified_%s" % name,
                  ev["verified_correct"] == exp["evidence_axis"]["verified_correct"])
        ab = results[name]["abstention_axis"]
        if "overclaims_min" in exp["abstention_axis"]:
            check("overclaims_min_%s" % name,
                  ab["overclaims"] >= exp["abstention_axis"]["overclaims_min"])
        if "overclaims" in exp["abstention_axis"] and name != "all_wrong":
            check("overclaims_%s" % name,
                  ab["overclaims"] == exp["abstention_axis"]["overclaims"])
        if name == "all_correct":
            check("no_overclaim_all_correct", ab["overclaims"] == 0)
            check("no_null_all_correct", ab["null_abstentions"] == 0)
        if name == "partial":
            check("partial_null_is_miss_not_overclaim",
                  ab["null_abstentions"] >= 1 and
                  exp["abstention_axis"]["null_abstentions"] >= 1)

    print("[3] three axes independent + extra-field handling")
    # extra JSON field must warn, never fail: mutate a mock copy in memory
    sys.path.insert(0, G3)
    import validators
    with open(os.path.join(G3, "mocks", "partial.json"), encoding="utf-8") as fh:
        partial = json.load(fh)
    errors, warnings = validators.schema_validate(partial)
    check("extra_field_is_warning", any(w["unexpected_key"] == "extra_note"
                                        for w in warnings))
    check("extra_field_not_error", not any("extra_note" in e.get("message", "")
                                          for e in errors))
    # null/invalid JSON preserved
    parsed, status, transform = validators.parse_answer("```json\n{}\n```")
    check("single_fence_stripped", status == "VALID" and transform == "STRIP_SINGLE_FENCE")
    parsed2, status2, _ = validators.parse_answer("not json at all")
    check("invalid_json_reported", status2 == "INVALID")

    print("[4] gate and manifest state")
    gate = json.load(open(os.path.join(STAGE, "gates", "G3_scorer.stage_gate.json"),
                          encoding="utf-8"))
    check("g3_gate_status", gate["status"] == "PREPARED_PENDING_G2_SIGNOFF")
    check("g3_gate_next_false", gate["next_stage_allowed"] is False)
    check("g3_gate_requires_g2", gate.get("g2_teacher_review_required") is True)
    check("g3_gate_binds_manifest",
          gate["input_manifest"]["sha256"] == sha256_file(
              os.path.join(G3, "G3_PREPARATION_MANIFEST.json")))

    print("[5] SHA256SUMS coverage")
    listed = {}
    with open(os.path.join(G3, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, rel = line.rstrip("\n").split("  ", 1)
                if rel.split("/")[0] == "__pycache__" or "__pycache__/" in rel \
                        or rel.endswith(".pyc") or rel.endswith(".pyo"):
                    continue
                listed[rel] = digest
    actual = {}
    for dirpath, dirnames, filenames in os.walk(G3):
        # G3 cache repair: runtime bytecode is not G3 evidence. Prune cache
        # directories in place and filter compiled artifacts, without
        # widening the exclusion to any other delivery file.
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        for fname in filenames:
            if fname == "SHA256SUMS":
                continue
            if fname.endswith(".pyc") or fname.endswith(".pyo"):
                continue
            path = os.path.join(dirpath, fname)
            actual[os.path.relpath(path, G3)] = sha256_file(path)
    check("sha256sums_covers_all", sorted(listed) == sorted(actual),
          "missing=%s extra=%s" % (sorted(set(actual) - set(listed))[:4],
                                   sorted(set(listed) - set(actual))[:4]))
    for rel, digest in listed.items():
        check("digest_%s" % rel, actual.get(rel) == digest, rel)

    print()
    report = {"overall": "FAIL" if FAILURES else "PASS",
              "checks": CHECKS, "failures": FAILURES,
              "g3_root": G3}
    if args.report:
        path = os.path.abspath(args.report)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(report, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")
    if FAILURES:
        print("G3 PREPARATION VALIDATION: FAIL (%d failures of %d checks)"
              % (len(FAILURES), CHECKS))
        return 1
    print("G3 PREPARATION VALIDATION: PASS (%d checks, 0 failures)" % CHECKS)
    return 0


if __name__ == "__main__":
    sys.exit(main())
