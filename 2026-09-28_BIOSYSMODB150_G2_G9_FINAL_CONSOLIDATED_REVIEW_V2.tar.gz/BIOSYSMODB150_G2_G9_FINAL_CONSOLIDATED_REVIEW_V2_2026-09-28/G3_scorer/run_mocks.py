#!/usr/bin/env python3
"""run_mocks.py -- score the three mocks and write mock_results.json (frozen)."""
import json, os, sys, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
G3 = HERE
sys.path.insert(0, G3)
import importlib
scorer = importlib.import_module("scorer")
results = {}
for name in ("all_correct", "all_wrong", "partial"):
    with open(os.path.join(G3, "mocks", name + ".json"), encoding="utf-8") as fh:
        answer = json.load(fh)
    out = scorer.score_answer("BIOPATH150_014", answer)
    out["engineering"] = {"extra_field_warnings": (
        name == "partial" and 1 or 0)}
    results[name] = out
text = json.dumps(results, ensure_ascii=False, indent=2, sort_keys=True)
with open(os.path.join(G3, "mock_results.json"), "w", encoding="utf-8", newline="\n") as fh:
    fh.write(text + "\n")
print("mock_results.json written")
