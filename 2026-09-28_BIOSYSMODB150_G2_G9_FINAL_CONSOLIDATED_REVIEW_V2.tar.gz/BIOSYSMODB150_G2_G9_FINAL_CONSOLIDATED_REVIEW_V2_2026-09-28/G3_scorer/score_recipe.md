# G3 score recipe (CANDIDATE -- pending G2 sign-off and teacher confirmation)

Not frozen. Status: PREPARED_PENDING_G2_SIGNOFF. No real model answer has been
scored by this code; it has only ever seen local mocks (mocks/).

## 1. Teacher-fixed (immutable)

- Science = 0.45*Pathway + 0.10*SMILES + 0.20*Enzyme/EC/pair + 0.15*Microbial
  identity + 0.10*Traits; every layer normalized 0..100. Weights may not change.
- Evidence verifiability is an INDEPENDENT axis (verified_correct /
  unverified_correct / evidence_hallucination); it never mixes into science.
- Engineering is independent: JSON syntax, business-object form and schema
  validity are reported separately (three rates, never merged).
- null is a recall miss and never an overclaim; a wrong non-null answered with
  high confidence and without resolvable evidence is counted in overclaim.
- extra JSON fields: warnings only, original text preserved, never a hard
  failure; required fields stay strict.
- smoke/pilot data never enter formal scores; the formal phase re-runs all 121
  cases with frozen parameters (5 x 121); smoke/pilot results may not be
  reused to offset formal requests.
- case_id is the gold join key: branches of one parent pollutant never share
  gold; no root-pollutant merging.

## 2. Layer definitions (implemented in scorer.py)

- Pathway: from the alignment spec (greedy max-Jaccard one-to-one on
  substrate-union-product identity sets; direction checked per side, A->B vs
  B->A never equal). Layer = mean(step recall, main-step precision,
  matched-order concordance) * 100. Missing gold steps = recall misses;
  unmatched prediction main steps = extra-step errors; steps after the main
  endpoint placed in downstream_continuation are not penalized.
- SMILES: main compounds of matched steps; primary = canonical ISOMERIC
  equality with RDKit 2026.03.5 applied identically to gold and prediction;
  achiral-canonical reported as a separate reference number. Cases whose
  gold structure is not uniquely available are out of the SMILES denominator
  (the 5 STRUCTURALLY_INDETERMINATE cases are already excluded from formal by
  G1; auxiliary carrier gaps never affect the main-chain denominator).
- Enzyme: per gold step: accepted-name membership (G1 keeps ALL accepted
  enzymes; the model returns one preferred), EC equality against the accepted
  EC set (a gold step whose only EC is NOT_OBSERVED accepts null), and the
  enzyme-microbe pair membership in the step's accepted organism set.
- Microbial identity: per gold profile: species name, strain, exact TaxID,
  genome accession (only where gold has one), culture collection handled in
  the trait/F5 axis -- each sub-score over its available denominator, never
  padded.
- Traits: two raw rates kept separate -- observed-gold ACCURACY over G1
  scoreable cells (item mask for text/boolean traits; F2/F3/F4 exact-scalar
  sub-field mask, min==max consensus scalars only, no tolerance, optimum
  columns have an EMPTY denominator and are reported as such), and
  COMPLETENESS over all profile x 15 cells. The 1161 pending range/multi-value
  cells stay out of the accuracy denominator this phase; predicted background
  is never promoted.

## 3. PENDING teacher decisions (marked, not silently chosen)

See G3_PREPARATION_REPORT.md OPEN DECISIONS: within-layer subindicator
weights (currently equal weights as the contract 9.5 recommended baseline),
the trait 10% composition (currently item/subfield accuracy mean; completeness
reported separately), the overclaim penalty shape (currently report-only, no
layer deduction -- deduction would double-count with the accuracy terms),
alignment thresholds and split/merge magnitudes, and the isomeric-vs-achiral
report presentation. Every one of these is flagged in code and in the mock
expectations; none is claimed as teacher-set.
