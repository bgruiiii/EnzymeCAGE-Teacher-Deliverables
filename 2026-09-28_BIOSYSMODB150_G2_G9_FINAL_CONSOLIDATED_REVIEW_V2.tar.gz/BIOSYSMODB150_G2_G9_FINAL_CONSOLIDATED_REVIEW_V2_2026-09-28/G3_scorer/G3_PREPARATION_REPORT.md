# G3 scorer preparation report (PREPARED_PENDING_G2_SIGNOFF)

Inputs bound: G1 gold manifest, G1 content manifest, G2 questions manifest, G2
gate (READY_FOR_REVIEW), teacher approval `39e08c21...`, collector
prompt/template/schema hashes. `real_answers_scored=0`, `api_calls=0`.

## What was built (candidate, NOT frozen)
- score_recipe.md: five fixed layers 45/10/20/15/10; evidence/engineering/abstention
  axes independent; null=recall-miss not overclaim; extra JSON fields warning-only;
  syntax/object/schema reported separately; smoke/pilot excluded from formal.
- alignment_spec_v1.json: per-side compound identity sets (RDKit canonical
  isomeric, same version for gold and prediction), one-to-one greedy max-Jaccard,
  direction A->B != B->A, recall/extra/order rules, downstream_continuation not
  penalized, split/merge and tie-break handling.
- evidence_scoring_spec_v1.json: reference resolution -> record lookup -> claim
  scope; DATABASE_DIRECT must resolve against the frozen G1 lookup;
  MODEL_INFERENCE / INTERNAL_KNOWLEDGE reported as honesty statistics.
- scorer.py + validators.py: offline implementation; the frozen D0 collector is
  imported read-only for rendering-parity only.
- mocks/all_correct, all_wrong, partial for BIOPATH150_014, each with a hand
  derivation in mock_expected.json; mock_results.json records the scorer output.

## Mock outcomes (science / key axes)
- all_correct: 99.77 -- pathway/enzyme/identity/SMILES 100; traits 97.73: the
  residual cells are the F2/F3/F4 word-preference items whose observed gold is a
  category word; numeric-consistent answers under the candidate composition are
  counted there as unmatched. Reported, not hidden: the trait 10% composition
  is an OPEN DECISION (below). All 9 DATABASE_DIRECT evidences verified, 0
  hallucination, 0 null, 0 overclaim.
- all_wrong: 0.0 in every layer; evidence_hallucination>=3; overclaims>=6;
  recall-missed 3; shape complete but never read as correctness.
- partial: 79.13; 2/3 gold matched (step S01 in downstream only -> recall miss,
  not an extra), 1 extra step, synonym substrate accepted, high-confidence
  wrong enzyme with no evidence -> overclaim 1, null organism -> recall miss,
  invalid BSY-e99999 -> hallucination 1, dangling EVID refs -> 2 ref_missing,
  extra_note -> 1 warning with text preserved; isomeric primary vs achiral
  reference reported separately.

## OPEN DECISIONS (teacher; none silently chosen)
1. Trait 10% composition: candidate = mean(item accuracy, subfield accuracy),
   completeness reported separately; all_correct lands at 97.73 because a few
   scoreable cells' observed gold is a category word (mesophilic /
   non-halophilic) rather than a scalar. Options: treat word-preference cells as
   satisfied by numeric-consistent answers, exclude them from the accuracy
   denominator, or another frozen rule.
2. Within-layer subindicator weights (currently equal); microbe pair may be
   satisfied by species NAME while the model's TaxID is wrong (partial S03):
   whether a name-only pair passes.
3. Split/merge penalty magnitudes; alignment jaccard threshold 0.5 (candidate).
4. overclaim reporting vs any score deduction (currently report-only, no
   science deduction).
5. F14 genome via traits-F14 vs a profile-level genome field.
6. achiral reference reporting placement (kept out of the primary SMILES number).

## State
- G3 gate = PREPARED_PENDING_G2_SIGNOFF; this round freezes nothing and scores
  no real answer. After the teacher signs the G2 13-case review with no question
  change, the SAME preparation is upgraded to the frozen G3 scorer; if G2 or the
  schema changes, hashes and mocks must be re-verified first. G4/G5/G6 untouched;
  zero API calls.

## Validation cache-exclusion repair (2026-09-27)

The independent validator previously counted runtime bytecode
(`__pycache__/*.pyc`) as G3 delivery files, producing false SHA failures and
inflating the check count. Runtime caches are now pruned from the SHA256SUMS
walk (directories named `__pycache__` removed in place; `.pyc`/`.pyo`
filtered), SHA256SUMS lists only the 16 canonical G3 files, and the validator
is run with `PYTHONDONTWRITEBYTECODE=1`. This is an engineering-evidence
repair only: scorer, validators, alignment/evidence specs, mocks,
mock_expected, G1, G2 and all six OPEN_DECISIONS are unchanged, and the gate
stays `PREPARED_PENDING_G2_SIGNOFF` / `next_stage_allowed=false`. Real API
calls: 0. G3 still cannot be marked PASS until the teacher signs the G2
13-case review (and the route/oxygen adjudications); only then may this same
preparation be frozen, re-verified if G2 or the schema changed.
