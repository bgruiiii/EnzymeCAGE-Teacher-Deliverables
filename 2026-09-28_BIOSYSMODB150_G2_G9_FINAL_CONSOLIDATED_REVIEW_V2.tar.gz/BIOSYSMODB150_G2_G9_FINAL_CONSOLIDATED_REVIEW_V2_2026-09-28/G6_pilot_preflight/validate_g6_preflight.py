#!/usr/bin/env python3
"""validate_G6_preflight.py -- independent structural check for G6 preflight.
Confirms slot count, NOT_DISPATCHED everywhere, deterministic selection (where
applicable), PREPARED/TEMPLATE status, no dispatch. No network, no key."""
import json, csv, os, sys
HERE=os.path.dirname(os.path.abspath(__file__)); F=[];N=[0]
def ck(n,ok,d=""):
    N[0]+=1
    if not ok: F.append({"check":n,"detail":str(d)[:200]}); print("  [FAIL]",n,str(d)[:120])
tm=os.path.join(HERE,"task_matrix.tsv")
if os.path.isfile(tm):
    rows=list(csv.DictReader(open(tm,encoding="utf-8"),delimiter="\t"))
    ck("slots_present",len(rows)>0)
    ck("all_not_dispatched",all(r["dispatch_status"]=="NOT_DISPATCHED" for r in rows))
ck("g6_slots_50", len([r for r in csv.DictReader(open(tm,encoding="utf-8"),delimiter="\t")])==50)
sel=list(csv.DictReader(open(os.path.join(HERE,"selected_cases.tsv"),encoding="utf-8"),delimiter="\t")); ck("g6_ten_cases",len(sel)==10)
pol=json.load(open(os.path.join(HERE,"selection_policy.json"))); ck("g6_two_options", "g5_in_g6_options" in pol and pol["g5_in_g6_options"]["recommended"]=="option_B_superset")
print()
if F: print('VALIDATION FAIL',len(F),'/',N[0]); sys.exit(1)
print('VALIDATION PASS',N[0],'checks, 0 failures')
