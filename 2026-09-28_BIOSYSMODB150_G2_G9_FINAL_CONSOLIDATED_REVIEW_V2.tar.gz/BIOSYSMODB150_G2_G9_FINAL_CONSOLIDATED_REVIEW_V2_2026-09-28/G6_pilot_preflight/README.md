# G6 pilot preflight (PREPARED_NOT_AUTHORIZED_TO_RUN)
10 stratified cases, 50 slots (5x10) NOT_DISPATCHED. Two options for G5-in-G6 (recommend superset). Gate template: >=49/50 usable JSON, <=5/50 truncated, 2/model human shape review. Failure re-run NOT authorized. No dispatch.
