#!/usr/bin/env python3
"""validate_G7_preflight.py -- independent structural check for G7 preflight.
Confirms slot count, NOT_DISPATCHED everywhere, deterministic selection (where
applicable), PREPARED/TEMPLATE status, no dispatch. No network, no key."""
import json, csv, os, sys
HERE=os.path.dirname(os.path.abspath(__file__)); F=[];N=[0]
def ck(n,ok,d=""):
    N[0]+=1
    if not ok: F.append({"check":n,"detail":str(d)[:200]}); print("  [FAIL]",n,str(d)[:120])
tm=os.path.join(HERE,"task_matrix.tsv")
if os.path.isfile(tm):
    rows=list(csv.DictReader(open(tm,encoding="utf-8"),delimiter="\t"))
    ck("slots_present",len(rows)>0)
    ck("all_not_dispatched",all(r["dispatch_status"]=="NOT_DISPATCHED" for r in rows))
u=[r for r in csv.DictReader(open(os.path.join(HERE,"per_model_usage_template.tsv"),encoding="utf-8"),delimiter="\t") if (r.get("model") or "").strip() and not r["model"].startswith("#")]
MODELS={"qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"}
ck("g7_five_models",sorted(r["model"] for r in u)==sorted(MODELS)); ck("g7_no_fabricated", all((val in ("",None) or val==[]) for r in u for k,val in r.items() if k!="model"))
h=json.load(open(os.path.join(HERE,"hash_binding_template.json"))); ck("g7_binds", h["formal_n"]==121 and h["expected_formal_first_requests"]==605 and h["smoke_pilot_offset_forbidden"] is True)
ck("g7_status", h["status"]=="TEMPLATE_ONLY_NOT_APPROVED")
print()
if F: print('VALIDATION FAIL',len(F),'/',N[0]); sys.exit(1)
print('VALIDATION PASS',N[0],'checks, 0 failures')
