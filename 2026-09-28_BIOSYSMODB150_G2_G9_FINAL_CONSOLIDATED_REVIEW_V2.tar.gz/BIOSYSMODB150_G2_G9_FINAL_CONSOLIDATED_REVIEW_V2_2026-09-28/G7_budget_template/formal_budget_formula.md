# G7 formal budget formula (TEMPLATE ONLY, not approved)

Inputs bound (hashes pinned at freeze): dataset(G1 gold manifest), prompt(collector prompt), schema(biodegradation_answer_v2), scorer(G3 manifest), parameters(parameter_contract + model IDs), search policy(G4 decision), formal_n=121, five exact model IDs.

Formula:
- expected_formal_first_requests = 5 models x formal_n(121) = 605 (subject to G6-measured n; report actual n on front page).
- per-model cost estimate = mean(tokens_per_case) x n x unit_price[region,currency,date] from the frozen parameter contract (UNKNOWN prices stay UNKNOWN, never 0).
- conservative budget = P90(token) x n x unit_price, plus retry headroom = transport_retry_max x observed_retry_rate.
- smoke/pilot extra 65 requests are NOT deducted from the 605 formal (no offset).
- G7 requires a separate teacher sign-off; this template authorizes nothing.
