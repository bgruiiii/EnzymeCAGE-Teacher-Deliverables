# G7 budget template (TEMPLATE_ONLY_NOT_APPROVED)
Per-model usage columns present but EMPTY (no fabricated tokens/prices). Formula binds dataset/prompt/schema/scorer/parameters/search policy/model IDs/formal_n=121 hashes; 5x121=605 formal first-requests, smoke/pilot 65 not deducted. G7 needs separate teacher sign-off.
