# 老师侧批复：BIOSYSMOdb150 G1 内容裁决 + G2–G6 条件批准

- 日期：2026-09-27
- 收件：评测实施学生（陈浩然侧）
- 性质：**G1 内容裁决 + G2–G6 条件批准**（对 `BIOSYSMODB150_G1_REVIEW_AND_G2_G6_CONDITIONAL_BATCH_APPROVAL_REQUEST_2026-09-27.md` 的签署回复）
- 审阅材料：`2026-09-27_BIOSYSMODB150_G1_GOLD_AND_API_CONTRACT_REVIEW` 包（主申请、gold review、quarantine、SMILES R3/R3-R1 回溯、gate JSON、两份合同），已对包内程序证据做抽查复核
- 本文件经确认后由学生侧计算 SHA256 并作为 G1 裁决与 G2–G6 授权的唯一 approval_source

---

## 一、G1 六项裁决（逐条）

### 1. 正式题目数量 —— ✅ 同意 121

原 150 − 既有 quarantine 24 − 主链结构不可判定 5 = **formal_n = 121**，新增 5 题（BIOPATH150_040 / 115 / 116 / 117 / 118）转入 quarantine。

理由：主实验含 10% SMILES 结构分，nylon-6 聚合物、4 个 Meisenheimer 中间体、heparin、dermatan sulfate、heparan sulfate 在源库无唯一可核验结构，gold 不可复算；不采用「名称答对、结构免判」例外——例外规则会激励模型在结构层投机。

**附加要求**：这 5 条的 quarantine reason 须与「断链/cycle/矛盾」分类标注区分（建议 `STRUCTURALLY_INDETERMINATE_IN_SOURCE`）。heparin/dermatan sulfate 是天然多分散聚合物，「无唯一 SMILES」是物质属性不是数据缺陷，避免后续复审把它们当数据质量问题返修。

### 2. BSY-c14673 —— ✅ 同意程序结论

125 case / 290 participant occurrence、0 次位于计分主底物/主产物，相关 case 保留在 formal。

**附加要求**：把该 compound 的 mask 判定规则与 occurrence 计数（290/0）写进 G1 gold manifest 注释；后续任何 gold 重建必须复算这两个数字，漂移即触发 invalidation。

### 3. MetaTraits 与 C7_1 —— ✅ 同意

`no_predictions` 作为 observed 来源；MetaTraits all 中预测记录只作背景不进 observed 分母；C7_1 rerun2 冻结为 G3 映射输入。

### 4. F2/F3/F4 范围值 —— ✅ 同意，含一处对我裁决的合理修正

批准：min==max 且来源一致的标量进精确分母；min≠max 或多值记录保留审计但不进分母；不取中点、不用区间重叠；optimum 无 observed 时分母为空、完整率分母不变。

确认现实修正：子字段审计显示 F2/F3/F4 的 optimum 子字段 **0 scoreable**（834 profiles 全部无 observed optimum），我 9-26 裁决中「optimum 为主口径」在数据不可及处让位——主报告列改为 minimum/maximum 共识标量，optimum 列如实标注「本地无 observed 来源」。「精确匹配、不设容差」维持不变。pending 的 1161 cells 本期不进分母，报告披露覆盖率限制。

### 5. F5 保藏编号 —— ✅ 同意

模型返回一个首选，gold 保留同菌株全部本地可信编号、匹配任一即对；gold 无号不进分母；非法编号/本地查无/错绑菌株计幻觉。「本地查无」标 `LOCAL_LOOKUP_ABSENT`、不宣称全球不存在的措辞正确，保持。

### 6. quarantine 探索实验 —— ✅ 本阶段不跑

先完成主实验；quarantine 子实验后续另立预算另申请，不进主排名。

---

## 二、G2–G6 条件批准 —— ✅ 批准，商业 API 硬上限 80 次

```
G2 题面+泄漏检查（离线，0 次）
G3 评分器冻结+三 mock 自验（离线，0 次）
G4 搜索对称性探针（≤15 次）
G5 三题 smoke（15 次，JSON 必须 15/15）
G6 十题 pilot（50 次，JSON ≥49/50、截断 ≤5/50、形态抽审、预算估算）
─────────────────────────
合计 ≤ 80 次商业 API 调用
```

批准依据（已抽查核实）：

- 实施合同（TEACHER_ALIGNED_R1）§1 逐条映射表完整覆盖我 9-26 裁决全部条款，且诚实区分「老师已定」与「实现建议待签」（§18 待签表）；§9 披露旧甲苯 smoke 接触史是防确认偏误的正确做法；
- quarantine/cases.tsv 24 条均带程序出处与 `release_condition: teacher case-level content audit only`；
- gate JSON 状态诚实（READY_FOR_REVIEW / next_stage_allowed=false / reviewer=null），未自签；
- SMILES 回溯根因分布清晰（27 源缺 / 2 抽取错绑 / 1 名称变体 / 2 适配器一致），2 条 S4R1 错绑确认未污染 G1 canonical，S4R1 冻结只读处理正确；
- mutation 4/4 走语义检测而非 hash 比对，方向正确。

**附加条件（批准前提，G2 启动前落实）**：

1. 实施合同 §2.3 自列的 v2 采集器三处待对齐（`run_limits.json` 旧 15 次规则、`route_scope=null` 自由选路残留、「不得增加任何字段」旧约束）先改后验，验收看 diff 不看自述；
2. G2 泄漏检查按合同 §7 扫描最终 messages（含 system 与空模板），不只扫 case 表；
3. G6 预算估算须按合同 §14 给出 per-model token mean/median/P90/max 与硬总预算，**G7 回签绑定 dataset/prompt/schema/scorer/参数/search policy 的哈希**。

**硬停止条件 8 条（主申请 §六）原文生效。** G5 失败后修复重跑不在本次授权内，须重新报批。

## 三、本次明确不授权

G7 预算回签（另行单独确认）、G8 正式全量（若 formal_n=121 预计 605 次，以 G6 实测为准）、G9 评分发布、quarantine 子实验、自由路线探索实验。

---
