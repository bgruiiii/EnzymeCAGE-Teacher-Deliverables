# BIOSYSMOdb 五模型指定路线评测：黄老师裁决实施主合同

日期：2026-09-26  
版本：TEACHER_ALIGNED_R1  
状态：DESIGN_AUTHORITY_RECEIVED / PREPARATION_ONLY / LIVE_RUN_GATES_NOT_PASSED  
适用对象：本地实施AI、Chenyu执行AI、本地审计AI、后续接班窗口

## 0. 合同目的、效力与当前立即动作

本合同将黄老师的设计裁决转成逐步可执行的工作安排。当前窗口只负责分析和写合同，不实现程序、不调用API、不替老师验收gold。后续模型依据本合同分阶段实施。

唯一老师原件：
00_Authority_Teacher_Plan/TEACHER_ADJUDICATION_BIOSYSMODB150_FIVE_LLM_DESIGN_2026-09-26.md

老师原件SHA256：
b7d4e7eecd47e4c7a88ba56474a190d69e8ab877549b8fa73487a7050a6ded54

优先级：
用户明确要求按老师裁决执行 > 老师原件 > 本实施合同 > 通过审计的版本化实物 > 阶段执行提示词 > 执行器自述。

本合同替换同路径旧计划。旧内容保留在：
00_Authority_Teacher_Plan/BIOSYSMODB150_API_ANSWER_COLLECTION_EXECUTION_PLAN_PRE_TEACHER_ARCHIVE_2026-09-26.md

旧计划的P0/P1/P2/P3不再是主流程阶段号，不能按旧P3直接开始新的甲苯调用。
旧“无需等gold即可跑新smoke”“搜索一律开且不检查实际生效”“smoke/pilot成功答案可抵正式150题”均不再生效。

**当前允许推进：**
- 本地只读检查已有S4-R2、旧API实物。
- 本地构建quarantine、正式题库候选、trait gold和评分规则草案。
- 本地实现或调整v2采集器、完整空模板、Schema、mock测试。
- 文档级API参数核验、旧远端raw离线重放。
- 这些都是准备工作，不产生新的被测模型请求。

**当前不得启动：**
新的单甲苯真实调用、search-efficacy真实探针、3题smoke、10题pilot、正式5×n调用。真实调用必须按第5节硬门顺序解锁。教师裁决不是gold已经通过，也不是全量预算已经批准。

## 1. 老师裁决到实施动作的逐条映射

| 老师原件 | 已裁定规则 | 本合同落点/产物 |
|---|---|---|
| §一 | 指定路线唯一主排名；自由路线单独探索、确定性白名单判定 | G2题面、主/探索分包、route policy |
| §二 | 科学层45/10/20/15/10，不再讨论五层权重 | G3评分规则及公式 |
| §二 | 证据独立成轴，verified/unverified分层 | evidence_lookup、claim_verdicts |
| §二 | 工程指标独立，权重±5pp敏感性 | G8工程报告、G9敏感性 |
| §三 | 真实cycle/矛盾不计分，quarantine；不足150补选或降n | G1 exclusion ledger、final_n |
| §四 | 每模型2–3道时效性探针，真实metadata对称性 | G4，任一失败主实验搜索全关 |
| §五 | observed准确率与全字段完整率分别报告 | trait masks与逐字段分母 |
| §五 | 保藏编号本地查无/格式非法计幻觉，gold无值也适用 | F5判定表 |
| §五 | 温度/pH/盐度逐子字段精确匹配，无容差，optimum主口径 | numeric_rules，raw_text不计分 |
| §六 | 5×3 JSON15/15才能pilot | G5 |
| §六 | 5×10 JSON≥49/50、截断≤10%、预算确认、每模型2题形态抽审 | G6/G7 |
| §六 | smoke/pilot不进正式分，全量全部重跑 | phase隔离、5×n正式任务矩阵 |
| §七.1 | 对齐算法先冻结；建议compound集合二分图匹配 | G3 alignment code与测试 |
| §七.2 | 延伸进downstream不罚，混入steps计多步 | extra-step metric |
| §七.3 | DATABASE_DIRECT本地lookup；推断/内部知识不算可核验证据 | evidence registry resolver |
| §七.4 | RDKit同版本；isomeric主、去立体参考 | molecule_normalization manifest |
| §七末 | null为recall miss但非overclaim | abstention/overclaim分列 |
| §八.1 | 请求hash去重、仅传输重试、attempt全记录 | collector与幂等状态机 |
| §八.2 | 评分器先冻结，三mock自验后才能跑真实分 | G3哈希门 |
| §八.3 | 题面泄漏程序检查、老师10%中文名唯一性抽审 | G2泄漏检查与回签 |
| §八.4 | 模型版本/有效参数/忽略参数/时间窗记录 | model_runtime_manifest |
| §八.5 | pilot后预算老师确认才启动全量 | G7书面回签 |
| §八.6 | 不同分支按case_id隔离gold | case gold exact join |
| §八.7 | 只剥一层围栏；required严格、额外字段warning | parser/schema validator |
| §九 | gold到报告的门顺序不可跳，gold变更数据作废 | phase gates、invalidation ledger |
| §十 | 裸LLM API基线；不把它冒充EnzymeCrew同一种系统分值 | 最终引言与分报告 |

## 2. 路径与当前事实

下文相对路径全部相对于TASK_ROOT，变量写法仅作为路径约定，不可复制成带换行的shell赋值。

TASK_ROOT：
/home/a/EnzymeCAGE/custom/docs/enzyme_feature_expansion/ENZYMECAGE_LUCAPCYCLE_MODEL_TRAINING_RUN_2026-07-01

题库根BENCHMARK_ROOT：
23_BIOSYSMODB_150_PATHWAY_FIVE_LLM_API_BENCHMARK_2026-09-24/

采集器根COLLECTOR_ROOT：
24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24/

建议本合同的阶段账本和审批文件集中写：
25_BIOSYSMODB_TEACHER_ALIGNED_EXECUTION_2026-09-26/

上述25目录是规划目录，本轮不创建科学实物。已有23/24中的数据和代码可复用，逐项审计后纳入新版本manifest，不因目录旧就重算或推翻。

### 2.1 题库现状（不是正式验收数量）

- S3候选150个pathway case，676个pathway-step occurrence。
- 150是路径数，不是150种独立污染物。
- S4-R2文件报告graph pass=127、remaining review=26，仍为PARTIAL_REVIEW_REQUIRED。
- 26是问题记录数，不是26条路径；17断裂/6循环、个别compound身份及全局ALL记录会交叉影响case。
- 全局BSY-c14673问题必须映射影响case，不能仅因为写成ALL就从每case门中消失。
- 109/109程序门不代表老师已验收gold化学内容，也不代表126或127可以直接进入主实验。

重要输入：
BENCHMARK_ROOT/S3_selected_150/selected_150.tsv
BENCHMARK_ROOT/S4R2_reviewed_gold/S4R2_case_review_status.tsv
BENCHMARK_ROOT/S4R2_reviewed_gold/S4R2_manual_review_queue_remaining.tsv
BENCHMARK_ROOT/S4R2_reviewed_gold/S4R2_compound_role_by_occurrence.tsv
BENCHMARK_ROOT/S4R2_reviewed_gold/S4R2_step_gold_overlay.tsv
BENCHMARK_ROOT/S4R2_reviewed_gold/S4R2_order_edges_overlay.tsv

审计参考：
04_Local_Review_Audits/BIOSYSMODB150_S4R2_RETURN_LOCAL_AUDIT_2026-09-24.md

### 2.2 历史API已知事实

短探针：190请求，已观察短请求单模型并发5、共享25可运行。它不能替代老师要求的search-efficacy或3题smoke。

甲苯旧smoke：
03_HPC_Returned_Result_Summaries/biosysmodb150_smoke_toluene_return_20260926.tar.gz
SHA256=cf9bcb13a7aab5a10fc983b4060eb5bbff770b975f00f69149d686bca4eabe51

本地只读审计：
04_Local_Review_Audits/BAILIAN_TOLUENE_COLLECTION_SMOKE_LOCAL_AUDIT_2026-09-26.md
04_Local_Review_Audits/BAILIAN_TOLUENE_COLLECTION_SMOKE_EVIDENCE_2026-09-26.json

已复算：五body除model完全一致、两份Qwen有完整JSON但格式不符；另三份length。实际仅发空数组骨架，完整Schema没有进入messages。旧TTFT包含推理片段。
保留旧结果作为工程历史；不把其科学文本用于调权重、选择题或优化评分器。

### 2.3 v2程序现状

截至本次只读清点，COLLECTOR_ROOT已出现run_collection_v2.py、summarize/validate脚本、v2模板/Schema和tests。这是其他窗口新增工作，不能继续声称“所有v2尚未实现”，也不能未经审计称“可按老师新裁决运行”。

已知待对齐处：
- config/run_limits.json还有旧single-case最多15次新请求的规则。
- prompts/unified_collection_v2.txt仍允许主请求route_scope为null后自由选路。
- 仍有“不得增加任何字段”的旧约束，应调整为必填严格、额外字段warning。
- 不保证已有程序实现search对称性、老师预算门和正式阶段全覆盖重跑。

本轮只写合同，不修改正在开发的脚本、配置、Schema或模板。后续实施者逐项按本合同验收。

## 3. 科学边界与三套报告

最终科学分的五层权重是老师硬裁决：

| 层 | 权重 | 核心范围 |
|---|---:|---|
| 路径 | 45% | 主底物/产物身份，步骤匹配、漏步、多步、顺序、断链 |
| SMILES | 10% | 合法性、与gold isomeric canonical结构匹配 |
| 酶 | 20% | 名称/功能、EC、酶-微生物配对 |
| 微生物身份 | 15% | 物种/菌株/TaxID/genome accession/保藏编号 |
| 性状 | 10% | 15项完整率及observed-gold准确率，必须分开列示 |

设各层0–100分为P、S、E、M、T：
Science = 0.45P + 0.10S + 0.20E + 0.15M + 0.10T。

证据轴独立：覆盖、lookup、支持正确性、直接证据、模型推断与内部知识占比，不加进科学分。
工程轴独立：JSON语法率、Schema状态、截断、可见正文、耗时、tokens、成本、重试、失败。

不能沿用旧“科学正确但无证据再从科学总分扣分”的规则：
- 正确且可核验证据支持：verified_correct，老师允许的可对外引用事实口径。
- 正确但缺少可核验证据：unverified_correct，科学分保留，独立分层呈现。
- 记录ID不存在或claim_scope不支持：证据幻觉，按模型统计。
- null：recall计miss，不计overclaim；缺失证据不自动等于编造文献。
- 事实错误、无支持证据、高置信错误分别保存，不把每个unknown直接写成幻觉。

采集程序永远原样保存回答。执行阶段的工程验收和后续的科学评分由不同程序完成，不准边采集边修改模型事实。

## 4. 阶段责任与权限

| 角色 | 工作 | 不拥有的裁决权 |
|---|---|---|
| 本地实施AI | gold候选整理、quarantine、题面生成、Schema/采集器/评分器编写与mock | 不能凭guess裁定数据库矛盾、权重或老师预算 |
| 本地独立审计AI | 只读复算，检查源证据、输入泄漏、程序是否真实验证 | 不能把测试全PASS替代老师gold审计 |
| Chenyu执行AI | 按已解锁stage部署、运行、保存、打包 | 不能加题、替换模型、自动调到答案正确 |
| 老师/授权人工审阅者 | gold内容验收、10%题面唯一性抽审、未定义评分细节、全量预算确认 | 不能由执行器报告伪造回签 |
| 学生 | 传送阶段包、组织人工审阅、回传结果 | 不必手动改模型JSON |

教师原件只读。所有状态回签必须有路径、日期、审批主体、对应manifest SHA。
“设计批准”只解锁按序准备，不等于真实调用各门都已通过。

## 5. 主流程硬门（新的G编号）

离线准备D0可以并行开发；真实流程按下列顺序执行，不再使用旧P3单甲苯预算轮。

| 阶段 | 输入 | 关键输出 | 解锁条件 |
|---|---|---|---|
| D0离线基础 | 老师裁决、旧包、已有v2 | diff checklist、mock、离线raw replay | 只允许准备，不解锁API |
| G1 gold | S4-R2+trait source | formal/quarantine、gold hashes、老师gold审计 | final_n、case内容和矛盾处置验收 |
| G2题面 | G1正式case | main questions、泄漏检查、10%老师抽审 | 输入唯一性及无未授权gold泄漏 |
| G3评分器 | G1/G2、规则确认 | 三mock、评分代码/规则/lookup/RDKit hashes | 未看新真实答案前冻结 |
| G4搜索 | G1–G3全部通过 | 每模型3道时效性探针、对称性决议 | 全开或全关主参数锁定 |
| G5 smoke | G4决议、冻结模板 | 5×3=15份记录 | JSON有效15/15，按预先冻结口径计数；运行记录齐全 |
| G6 pilot | G5通过 | 5×10=50份记录、形态抽审 | JSON≥49/50、截断≤5/50、每模型2题形态正常 |
| G7预算 | G6实测和正式n | 成本/时间估算及老师确认 | 预算、并发、参数、n回签 |
| G8正式全量 | 全部前门通过 | 5×n全覆盖、原始记录和JSONL | 终态矩阵完整并冻结 |
| G9评分报告 | G8冻结返回+G3评分器 | 科学/证据/工程轴、±5pp敏感性 | 本地复算及老师审阅 |

若n最终为150，首次完整通过一轮的数量：
搜索15 + smoke15 + pilot50 + formal750 = 830次；不含历史请求、网络重试和失败工程轮。
老师明确接受smoke/pilot额外65次成本，不得偷偷抵扣正式750次。
若n降额：正式次数=5n，报告首页写n及原因；smoke/pilot固定3/10题需要足够正式题供抽样，否则另请老师决定，不自行改门。

每阶段生成stage_gate.json，至少包括：
stage、status、input_manifest_sha、output_manifest_sha、tests、counts、reviewer、approval_source、timestamp、next_stage_allowed。
status只用PREPARING / READY_FOR_REVIEW / PASS / FAIL / INVALIDATED。
每个README在入口检查上游PASS及哈希；没有门文件不得live请求。

## 6. G1：隔离争议、补选或降额、冻结gold

### 6.1 先把问题记录还原到case

从S4-R2 remaining queue、case status、participant role、orientation adapters及raw来源联合生成：
quarantine/cases.tsv
quarantine/global_issue_impact.tsv
quarantine/reasons_summary.json

cases.tsv至少：
original_case_id、pathway_id、root_entity、issue_ids、reason、source_locator、affected_step_ids、excluded_at、operator。

BSY-c14673的ALL矛盾必须枚举实际受影响case和participant。不得把全局矛盾视为“只有一条记录、不影响127个PASS”。
如果认为某个案例已通过来源适配消除矛盾，必须有case级审计和老师内容验收；代码不能把water-like改名就当无矛盾。
本轮合同不裁定应剔除多少，当前final_n=UNSET；不是强制127、126或150。

真正cycle、数据矛盾一律进quarantine。缺连接、无法确定主链身份的case也不能以未闭合gold评分。
quarantine可后续单独测试同管线，不进主排名，额外请求需独立任务授权和预算。

### 6.2 补选

在旧267条结构候选和可复核库中优先补选，沿用同一科学流程：
范围判定 → 主物质身份 → 微生物来源 → 反应方向/图闭合 → 全步骤酶菌证据 → 争议审计。
不因某模型旧回答易答或分高选题；不把植物路径仅凭有enzyme/organism关联就称微生物路径。
新增case用新ID；不要把新路线写进被剔除旧case_id，保留supersedes/replacement映射。
相同根物质不同分支分别计case，但不允许复制同一路径凑数。
不足150时如实冻结较小n，首页披露，无需为数量一直返修。

### 6.3 最终gold要交付什么

建议25目录下：
G1_gold/formal_cases.tsv
G1_gold/case_root_identity.tsv
G1_gold/reaction_gold.tsv
G1_gold/enzyme_gold.tsv
G1_gold/organism_gold.tsv
G1_gold/trait_gold.tsv
G1_gold/trait_scoreability_mask.tsv
G1_gold/evidence_lookup_index_manifest.json
G1_gold/counts.json
G1_gold/teacher_gold_review.md
G1_gold/SHA256SUMS

必须分别报：
最终路径n、独立根物质数、分支数、step occurrence总数、unique directed reactions、
enzyme记录数/unique enzyme IDs/名称/EC数、
step-organism链接数/unique species/strain/TaxID数、
15项有值覆盖、observed/predicted/unknown数量、
quarantine case数与剔除率及原因、补选数。

unknown身份不强行去重；计数的键、同义词规则和未决项写入counts。
采用所有证据合格的酶菌替代答案；被测模型只报首选，gold不能也裁成一个首选。
Step菌必须与具体酶/反应绑定；全路径菌关联不能代替逐步证据。
不同分支严格以case_id取gold，不把同母体所有分支酶都混入一个gold。

hidden reaction/enzyme/organism gold、trait gold分别计算hash，再由总manifest连接。
老师gold内容审计通过后G1=PASS。现有S4-R2程序109/109只作为材料，不是回签。

## 7. G2：题面生成与泄漏检查

主实验只用指定路线；自由路线另建exploratory_cases和prompt hash，另报不进主排名。
主case元数据包含：
case_id、pollutant_name_zh、pollutant_name_en、oxygen_condition、route_qualifier。
只发有可靠依据的氧条件；无记录不猜。
给模型中文问题，实体名/SMILES/EC/菌名字段用标准英文。
不发gold步数、终产物、酶、菌、EC、数据库答案ID、SMILES。
同一模板派发全部题，只有题目元数据变化；same case五模型messages完全一致。

泄漏检查必须实际扫描最终messages（含空模板、Schema、system提示），不只扫cases.jsonl：
- 按本case gold建禁发实体与别名表，检查酶名/EC/终产物/SMILES/科学数据库ID/实际步数提示。
- Schema字段名smiles、ec_number本身不是泄漏；空值、字段类型、示范局部标签不是科学答案。
- case_id可用于路由，它不是BIOSYSMO pathway/reaction答案ID。
- 指定路线必需的via中间体或氧条件是受控输入；写入逐case允许表，不以“整个模板都例外”跳过检查。
- 一个名称同时是路线限定和终点时，不静默放行；列明冲突，送老师题面审阅。
- 每个允许匹配必须有字段位置、允许理由；任何未解释hit阻断G2。

产物：
G2_questions/main_cases.jsonl
G2_questions/prompt.template.txt
G2_questions/rendered_messages/<case_id>.json
G2_questions/prompt_hashes.tsv
G2_questions/leakage_hits.tsv
G2_questions/allowed_input_atoms.tsv
G2_questions/teacher_sample_review.tsv

老师侧人工抽审ceil(0.10n)题；固定随机种子、尽量覆盖不同类别/分支，不按模型表现抽样。
每题检查中文名/英文名是否唯一指向本case、路线限定是否充分且未额外给答案。
主物质类别/混合物无法唯一确定时回到G1处置；老师回签后G2=PASS。

## 8. 统一JSON格式与模板的实施要求

老师批准steps、organism_profiles、evidence_registry的基本结构。版本号可用实现v2标识以防与旧字节混淆，manifest中记录它实现的是老师批准的业务结构；不得借换版本增加科学任务。

后续实现者需输出实际JSON Schema和完整空填写模板；本轮仅规定合同，不修改当前v2工作文件。

顶层：
schema_version、case_id、pollutant_name_zh、pollutant_name_en、route_scope、
steps、organism_profiles、evidence_registry。
route_summary、central_metabolism_entry、downstream_continuation、alternative_branches、uncertainties保留在约定格式中。是否required由冻结schema决定，不让远端自定。
不额外强制全题只有一个完整路径代表菌。

每步：
step_id、order、predecessor_step_ids、branch_id、
substrates[{name,smiles}]、products[{name,smiles}]、
enzyme{name,ec_number,gene_or_protein,evidence_id,confidence}、
microorganism{organism_profile_id,evidence_id,confidence}、
reaction_evidence_id、uncertainty。
只填写一组首选酶-EC-菌；不能以3个候选替代，真实多底物/产物允许数组。
只评价主底物/主产物；辅因子和副产物可标role保存，不因漏一分子水直接判主链错。

同一题内profile按物种+菌株去重；不同菌株不得合并。
profile含organism_profile_id、organism_name、strain、ncbi_taxid，以及15项。
genome编号在F14、保藏号在F5存一处；必要时通过引用访问，避免重复身份字段互相矛盾。
TaxID是微生物身份，不是酶记录；酶来源accession只能放enzyme证据里。

15项按以下用户展示顺序排，模型只有一个主要值，未知允许null：

| 顺序 | F项 | value结构 |
|---|---|---|
| 1 | F2 temperature | minimum_c、optimum_c、maximum_c、preference |
| 2 | F1 oxygen | 一个耐氧类型 |
| 3 | F4 salinity | minimum、optimum、maximum、unit、category |
| 4 | F3 pH | minimum、optimum、maximum |
| 5 | F5 collection | collection、accession（一个保藏号） |
| 6 | F6 respiration/electron_acceptor | 一个呼吸方式、一个电子受体 |
| 7 | F7 carbon/substrate | 一个主要利用描述 |
| 8 | F8 degradation_broad | 一个广义降解描述 |
| 9 | F9 enzyme_activity | 一个主要活性 |
| 10 | F10 motility | 一个运动性值 |
| 11 | F11 morphology | 一个细胞形态 |
| 12 | F12 gram/envelope | 一个Gram/包膜值 |
| 13 | F13 sporulation | 一个产孢值 |
| 14 | F14 genome | genome_accession、genome_size_bp、gc_percent |
| 15 | F15 habitat_generalism | 本地字段定义的广适性描述 |

每项性状统一带value、raw_text、evidence_id、confidence。类型必须明确，禁止value:{}任意类型兜底。
实际字段与本地表的可对应性由G1确认；Schema完整展示15项，缺失透明，不凭印象补新的性状字段。

evidence_registry每条：
evidence_id、source_type、database、record_id、locator、claim_scope、confidence。
每个事实引用一个最强evidence_id或null，同一证据可复用。
source_type固定DATABASE_DIRECT / LITERATURE_DIRECT / PREDICTED_BY_TOOL / MODEL_INFERENCE / INTERNAL_KNOWLEDGE_ONLY / UNKNOWN。
record_id为科学来源ID，不是ORG_001等局部引用。
所有数据值可以弃权；Schema required意味着字段必须出现，不意味着模型必须编造非null答案。

**Schema策略：**
- strict required与已定义字段类型检查。
- 额外字段在任意嵌套层只记warning，不作为FAIL；必须原样保留。
- 实现可在Schema允许额外字段，再由独立walker产生warnings；不能额外字段先fail后删原文补救。
- 普通JSON、Schema必填合法性、引用完整性分别报告。
- JSON语法正确但数组/null/{}等不具答案形态时保存原值并标形态问题，不强行改成对象。
- JSON语法率与schema率不能偷换；smoke/pilot的具体计数定义见第14节及第18节未尽细节。

完整空模板必须展开一个空step、一个空profile（全部F项）和一个空evidence，说明它们是可复制的成员格式。
模型看到的messages必须实际包含这些格式规则及枚举；不能只传steps:[]然后事后校验未告知字段。
老师稿里的甲苯已填答案、现有Qwen原文、gold记录均不得作请求示例。
可在本地保留手工虚构格式样例自测，它不进入被测请求。

## 9. G3：先冻结评分器及三例自验

评分器开发只使用正式gold和手工mock，不利用旧真实模型答案的科学好坏调匹配阈值/权重。
接班者已经见过历史甲苯结果不能声称严格从未见输出；在报告披露已知暴露。采用与prompt执行分开的评分开发目录、输入读取清单，冻结在新smoke前。
新smoke/pilot只作工程门和形态审阅，不提前跑科学排名。

三例mock：
1. 完全正确：所有可评分字段和支持证据匹配，预计科学100、verified_correct。
2. 全错：同样字段齐全但身份/反应/证据均错误，核心recall为0、overclaim正值，完整率可高；不能期待“齐全但全错”所有轴都0。
3. 部分正确：混合正确、null、错误、高置信缺证据、额外分支/同义词/不同步号；逐项手算期望并断言。

另外最小变异门：
- 多一个未知JSON字段只warning。
- 删除必填字段Schema error，但原文不变。
- null减少recall但不增加overclaim。
- DATABASE_DIRECT不存在、claim_scope错绑计证据幻觉。
- 同一污染物A/B分支gold不可交叉使用。
- 对映异构体isomeric不同，去立体参考可相同。
- 主链多写后续一步计多步；放downstream不罚。
- 科学正确但无来源，分值保留且unverified。

### 9.1 步骤对齐可执行建议（冻结前确认）

老师建议compound集合二分图匹配。实施者生成versioned alignment_spec：
- gold与预测step各为一侧节点，化合物优先按同版本RDKit结构标识；无SMILES时仅用冻结名称同义词/lookup表。
- 候选相似度基于底物∪产物集合，推荐集合Jaccard；采用最大权重一对一二分图匹配，dummy节点允许不匹配。
- 阈值、集合是否带化学计量、名称与SMILES冲突时的回退、酸碱/盐/互变异构体政策必须先写清。
- 固定tie-break按稳定ID，不能靠set遍历。
- 匹配只定位可比较step；仍分别检查底物、产物和方向。不能把A→B与B→A因union相同判成正确。
- 比较gold前驱边的部分顺序，branch的合法拓扑排序不因线性展示不同被误判。
- unmatched gold=漏步，unmatched predicted main steps=多步；一对多合并/拆分不能临时人工宽免。
- 不把step编号相等当化学身份，不因编号错一位全错。

上述是建议实现，不是老师指定的精确算法参数；G3前提交alignment_spec确认。无需再次讨论老师已固定的45/10/20/15/10。

### 9.2 SMILES

合法性用RDKit；主结构判定为同版本规范化isomeric SMILES精确相等，去立体另列参考。
先对gold使用同一RDKit版本/选项，记录原文与canonical。不能只对预测清洗、gold沿用旧版本。
立体缺失或相反在主口径不能被去立体结果覆盖。
物质名称正确与SMILES错误分开保留；名称/结构冲突写明。
非法gold结构在G1排查，不在看模型输出后静默剔除。

### 9.3 微生物和性状

物种、菌株、TaxID、genome accession、保藏编号分别精确/冻结别名匹配；物种证据不能升成菌株证据。
准确率分母来自G1 scoreability_mask中有可信observed值的字段；预测型gold只作背景，不自称实测。
完整率分母=预定全字段，分别报告15项级覆盖和min/opt/max子字段覆盖；不因gold缺失删完整率分母。
空profile、空string、null、unknown不得因键存在算“有值”。false和数值0可能是有效值，不能按布尔真假判断缺失。
为避免只报一个菌抬高完整率，同时报步骤要求覆盖率和已返回profile的字段完整率；漏菌的分母处理在score_recipe固定。

温度/pH/盐度：
- 每个min/opt/max子字段分别统计miss/正确，optimum单独作为主报告列。
- 同一物理量、同一单位约定下精确比较，不设数值容差、不以区间重叠取代。
- 可预先冻结确定性的单位换算（如确知% w/v与g/L）；单位含义不明不换算、不猜。
- raw_text仅审计，不计分；不可将某组测量值的统计最大值冒充生理最高温度。
- 数据库分类mesophilic不自动推出温度30℃。

F5：
- gold有号：精确匹配该菌株合格编号计分，null=miss。
- gold无号：不进该字段准确率分母；但返回号非法或本地保藏表查无，按老师裁决计幻觉。
- “本地查无”应标LOCAL_LOOKUP_ABSENT，不宣称全球数据库都没有；报告披露本地覆盖限制。
- 存在但属于别菌株也是错绑；正常存在记录不等于支持该酶/菌关系。
- F5不得用预测工具编编号。

### 9.4 证据lookup

本地建立可重放只读索引：数据库名称别名、record_id、版本/快照、payload哈希、支持的字段。
每个evidence_id先做引用解析，再lookup record_id，最后验证claim_scope内容支持。
DATABASE_DIRECT lookup失败计幻觉；只写库名、“来自文献”不算可核验。
LITERATURE_DIRECT需有本地可定位DOI/PMID/文献快照与实际支撑。外部来源若要纳入，应在评分前冻结lookup规则/证据快照；不能某个模型答好后才专门扩充gold。
MODEL_INFERENCE、INTERNAL_KNOWLEDGE_ONLY分别统计，不能算可核验证据。
预测工具来源需工具/版本/input/记录能追踪；预测证据不能写成观测gold。
同一个来源引用不能无条件给所有15性状加证据分，逐claim检查。

### 9.5 score recipe及未尽公式

老师固定五层权重，但层内比例、性状双指标进入10%的组合、overclaim惩罚如何进入层分，未提供唯一公式。
实施者必须在看到新输出前生成score_recipe.json和精确公式，提交针对性确认，不能把自拟等权写成老师裁定。
推荐讨论基线：每层已定义子指标等权、case宏平均；每层和micro计数同时报告。性状完整率/准确率永远单独显示，T的组合待确认。
老师要求null优于编造：只把二者都赋0的accuracy不满足；需明确定义overclaim惩罚或有序评级怎样体现差异，并固定。
这几个细节是G3前阻断总分实现的待签项，不阻断D0或G1/G2准备，也不重新开放五层权重。

G3产物：
scorer/score_recipe.json、alignment_spec.json、normalization.json、evidence_lookup_spec.json、
trait_scoreability_mask引用、three_mock_expected.json、mock_validation.json、
source_read_inventory.tsv、requirements.lock、SCORER_SHA256SUMS、review_signoff。
以后对真实结果跑分只认此哈希；脚本改动使既有分数作废、全套重算并说明原因，不能只改一个模型的分数。

## 10. D0采集器离线实现（允许并行准备）

可以复用现有v2，但必须按老师新规则修改后验收，不能直接继承旧“最多15个甲苯请求”的入口。

接收要求：
- 原始SSE逐事件append并flush，记录event原字符串、顺序与接收时间；捕获[DONE]、finish、EOF、解析错误。
- content与reasoning分别保存；不从reasoning摘答案。
- 每attempt独立目录，重试前不能clear覆盖前一份部分返回。
- HTTP200但无正常terminal的断流记INTERRUPTED，不能因有chunks就COMPLETE。
- 统一记录first_event/first_reasoning/first_visible、UTC和monotonic duration。
- 保留usage_raw，缺失字段null，网关text_tokens含义未知时不自行推导。
- 保存返回model/version/system_fingerprint；不返回时NOT_EXPOSED，不伪造版本。
- 总deadline、read idle和connect timeout分开记录；候选20秒连接/120秒读空闲/1800秒总，按离线与长pilot冻结。
- 任何返回都保存，错误JSON/Schema/拒答/length为独立终态；原文永不修改。
- 宿主状态和接收器重启幂等，不默默重复收费。HTTP超时不能知道服务是否已执行，记录duplicate_possible。
- 只允许网络失败/429/5xx/超时同body传输重试，建议最多2次，Retry-After照办；body不能改。
- 已正常返回但length/字段错/JSON错不触发单题科学重问。

请求幂等键至少包含：
phase + experiment_version + case_id + model_id + request_body_sha。
body SHA覆盖模型、全部messages、参数；header密钥不入哈希或落盘。
正式阶段不能因为smoke同case曾成功就跳过；phase必须进入幂等键。

JSONL每行合法外层对象：
run_id、phase、case_id、模型名、prompt/schema/gold版本引用、attempt、
transport/stream/finish/visible/json/schema状态、answer_text原文、parsed_answer原对象、
validation_errors/warnings、usage_raw、timing、artifact_paths。
内层case_id与外层不一致，保留两者并记录；不改模型原文。
空或非法JSON parsed_answer=null；不是把{}当成功答案。
解析只json.loads或去一层包围全部文本的fence，不修逗号/引号/括号，不LLM修复。
额外字段不删除；即使warning也全部保存在parsed_answer。

输出：
runs/<phase_run_id>/models/<model_alias>/<case_id>/attempt_001/
request.json、raw_events.jsonl、answer_text.txt、reasoning_content.txt、
parsed_answer.json、validation.json、timing.json、status.json。

命名结果：
<case_id>__<safe_pollutant_name>__<safe_model_name>.json
同物质不同分支靠case_id区分，ZHIPU/GLM-5.3路径斜杠安全化。
每模型一个JSONL、all_models.jsonl、all_attempts.jsonl及任务矩阵，原文可回溯。

离线tests必须覆盖正常流、reasoning-only length、断流/坏事件、传输重试、进程中断恢复、
额外字段warning、required缺失error、中文、null/数组/纯文本保留、任务分期去重、
同case五模型正文一致、模板无gold例值、manifest生成可重跑。
这些tests通过仅说明软件可用，不解锁真实API。

## 11. 模型与参数冻结

固定exact model IDs：
qwen3.8-flash
qwen3.8-max
deepseek-v4-pro-0813
deepseek-v4.1-flash
ZHIPU/GLM-5.3

同一百炼北京网关，一个外置DASHSCOPE_API_KEY。旧已验证endpoint可继续使用；无需因为迁移域名拖延。
密钥不进Git/prompt/JSONL/返回包。服务器已有key按0600加载，不在聊天重复提供。

parameter_contract.tsv每模型记录：
exact ID、文档URL/抓取日期/SHA、endpoint、输出预算实际键、
requested/effective temperature、requested/effective reasoning、max total/visible budget语义、
return fields、忽略参数清单、无法确认字段、price timestamp与currency。

- 旧实际字段max_tokens=16384，不能把文档抽象名max_output_tokens直接塞进Chat Completions。
- temperature=0支持时按约定请求；网关忽略/固定值需实测或文档证据，未知=UNKNOWN。
- reasoning可能与正文共享总预算；不能沿用“16k必够”。
- 32768/65536只是可选工程预算候选，须查精确模型支持再冻结，不能写死所有模型都支持。
- DeepSeek文档历史已出现enable_thinking/reasoning_effort与v4较大上限信息，但支持范围/语义要按exact ID和当前SDK核实，保存快照；不能推到GLM/Qwen。
- 不以“参数HTTP200未拒绝”当成“实际生效”。
- 本地参数文档准备允许提前做；新的计费参数探针不绕过G1–G3及G4顺序。缺证据先列阻塞，不盲发。
- 同题messages相同；模型参数兼容差异必须显式列出，原生推理模式不得悄悄关闭只为JSON好看。
- 主实验参数在成功pilot后冻结并交预算签字；全量不能每个case自动切预算或模式。

## 12. G4搜索实际生效对称性探针

老师批准开搜索的前提是所有模型通过。旧“日期回答+HTTP200”不足以证明搜索；190短探针与单甲苯不抵本门。

执行选择：每个模型相同3道非benchmark的时效性题，共15次首请求；每模型并发1、总≤5。
探针题先冻结于search_probes.jsonl，记录时效窗口、权威公开URL/日期/答案锚。不要只问“今天日期”。
选择需要引用近期公开页面的短事实问题；不含环境gold、酶、菌、正式case内容。
输出预算按精确模型预核允许值准备，不能再用128token导致无正文还判断不支持。

程序验证：
- request确实有enable_search=true；
- HTTP与stream完成；
- provider返回的metadata/tool事件有真实可定位检索记录，保存原字段路径、query/URL/record/time；
- 模型自己在content写“我搜索了”或编一个citation，不属于provider metadata；
- metadata与该题的query/所需页面存在关联；只返回空容器不通过；
- 时效答案锚的匹配单独记录；这里判断输入检索条件，不作为科学排名分数。

每题通过条件与每模型聚合在发请求前固定。建议采用严格定义：每模型3/3均有有效检索metadata且无传输/预算未决，model gate才PASS。
任一模型FAIL/UNKNOWN/无metadata/因预算无法验证，主实验统一enable_search=false，不反复试到全部通过。缺metadata表示未证明生效，不断言绝对没有搜索。
metadata正例如何映射、URL可定位规则如官方协议特殊，先入probe_spec，不能收到结果后改标准。

产物：
G4_search/search_probe_spec.json
G4_search/search_probes.jsonl
G4_search/raw per-attempt
G4_search/model_probe_results.tsv
G4_search/search_symmetry_decision.json
G4_search/SHA256SUMS

决议：
ALL_PASS → 主experiment search=true；
ANY_NOT_PASS → 主experiment search=false，整个search-on组若保留只能另建探索实验，不进主排名。

报告披露各模型搜索实际生效状态和metadata返回率，用运行条件术语描述，不宣传“联网能力”。
程序自动把search policy写进后续冻结body；不能某个模型偷偷保留true。

## 13. G5三题smoke

从G1正式已验收cases预先选3条，覆盖短/中/长或线性/分支，并固定选择种子/规则，不按模型表现选题。
五模型每题一次，15个model-case任务。候选每模型并发3、总15，最终以parameter_contract资源条件约束。
一轮所有任务同prompt/schema/搜索政策/参数版本，持久化全部attempt。

老师硬门：
JSON有效15/15才进pilot。

分别报告：
语法解析率（允许单围栏）、顶层对象率、required/schema通过率、额外字段warning率、
可见正文、length、stream完整率。
别把高科学正确性作为smoke条件；也不能为了表面15/15把{}、JSON null或数组冒充完整回答。
关于老师JSON门到底按语法还是可用对象的明确实现口径，见第18节，G5前冻结，不在看到结果后解释。

任一模型失败：修的是统一格式传递、Schema或参数，新建smoke round按5×3重新跑。
不对某个回答指出科学错误、不补字段续写。旧round仍保留且不计正式分。
不得只保留每个模型不同round里最好的一次拼成15/15。
建议最多2轮连续工程smoke，仍失败提交问题表；这项是费用控制建议，不代表已获无限重试授权。
成功轮次作为G5 gate evidence；之后进入pilot。

## 14. G6十题pilot与G7预算回签

十题来自同一正式池，预先冻结；允许包含三题smoke，但phase独立并重新调用。
五模型各10题，50个首请求；一轮同冻结参数。建议逐步确认每模型5、共享25能承载长回答。

四项门同时满足：
1. JSON有效≥49/50。
2. 截断比例≤10%：按(length OR visible content为空)的model-case并集计数，最多5/50；不能把同一条重复计两次。
3. 每模型至少2题人工形态审阅，固定抽样种子；共10份，检查无空JSON、全null占位、题面复读。只审回答形态，不评价酶或路径对错。
4. 单case tokens与时间分布、正式预算估算完成，提交老师确认；预算未回签不能解锁全量。

需注意JSON率与截断率是两个同时要求：空正文也会拉低JSON率，不能因截断允许5份就允许5份JSON失败。
记录每模型结果，不用总体49掩盖某个模型持续失败。若某模型尚无正常形态样本，不能报告形态抽审通过。

失败调整可提高已支持的预算、压缩提示词/重复展示字段；不能随意删除15项等老师批准业务内容。
调整后按同配置完整50题重pilot，不只修那1个失败项；如prompt/schema/模式发生变化使G5成功轮失效，应先重G5。
phase manifest记录新旧版本和为何失效。科学gold变动按第17节更严格重走。

预算文件至少：
final_n、5n正式首请求数、每模型输入/输出/推理token的mean/median/P90/max、
可见/总token语义、耗时分布、单位价/地区/币种/日期/来源、
搜索费用/缓存计费（适用时）、重试额外成本、预留金额、硬总预算、并发建议、预计时间窗。
依据pilot每模型平均token估计期望成本，P90情景估保守预算；长短题分布差异需说明，不将pilot均值当保证上限。
报价缺失或含义未知写UNKNOWN并补证，不能默认为0。
老师回签应绑定dataset/prompt/schema/scorer/parameters/search policy的哈希与预算上限。

## 15. G8正式5×n全量调用与打包

入口检查G1–G7全部PASS，包含老师预算确认。
即使smoke/pilot已有同case好答案，也必须重跑正式阶段全部n题×5模型。
首轮n=150时formal expected=750；每条正式请求只能一次科学回答。
传输失败允许同body重试，不能因length/JSON格式/科学内容错误重问，不能采用pilot旧结果补齐。
同case所有模型的请求messages哈希一致（不是要求模型回答相同）；同模型正式参数一致，版本/fingerprint逐次记录。

为缩短版本漂移时间窗，在已验证资源内并行；固定任务顺序/种子，记录开始结束时刻。
若发现模型版本变化、预算将超上限、持续限流或数据输入哈希改变：暂停派发新任务，保留已完成结果，报明确原因，不静默切模型。
缺返回字段fingerprint=NOT_EXPOSED，不能宣称版本绝对没有变。

交付：
G8_formal/manifest、任务矩阵、每attempt原始响应/正文/推理/parsed/validation/usage、
每模型JSONL、all_models.jsonl、all_attempts.jsonl、
collection_report、actual_effective_parameters、version_drift_report、SHA256SUMS。

任务矩阵可以含失败终态，但不是“750份完整科学答案”；分开报not_sent、no_response、interrupted、length、JSON invalid、schema error/warning。
没有响应的题仍保留在正式分母，处理方法由冻结scorer确定；不能从模型分母移走失败题。

打包明确白名单，SHA只排除自身，不跳过整个目录；原始流与推理可压缩单独大包。
小包说明excluded文件路径/size/SHA/远端位置，可用于摘要审计但不能冒充原始流已本地复算。
本地读流校验后冻结response manifest，方可G9。

## 16. G9评分、敏感性与报告定位

只加载G3冻结scorer、对应case gold与G8正式结果。不能把探索、quarantine、历史甲苯或smoke/pilot混入。
出三份主表：science_by_case/model、evidence_by_claim/model、engineering_by_case/model。
另列quarantine/exclusion、缺失字段分母、F5本地lookup coverage、模型推断/内部知识比率、版本/参数漂移、预算实际值。

权重±5pp敏感性义务：
五层基准固定45/10/20/15/10。
建议预注册为每层从{w-5,w,w+5}取值，仅保留合计100且非负的组合；逐组合复算总分/排名，报告名次区间、第一名频率和模型两两排序保持率。
可另报单层±5pp其余按比例归一；不能报告后只挑“稳定”的扰动方式。
层内score_recipe不随敏感性变化；性状两个原始率和证据轴始终独立列示。
若排名不稳定，如实报告，不修改基准权重使排名稳定。

最终报告引言必须体现老师定位：
“本评测为五个通用大模型API的裸能力基线，一次性端到端回答并记录证据完整性；不测EnzymeCAGE排序模型或编排系统。”
与EnzymeCrew的对照需明确系统条件不同；不直接把二者分值当同一裸模型排行榜。不夸大不同协议下分数差。
可报告裸LLM与编排+检索+冻结模型差距方向与量级，并清楚给出题库、输入、可用工具、评分条件。

verified_correct作为对外引用的事实层；unverified_correct仍在科学分且必须分层，不能删除后重新算一个更好排名。

## 17. 版本变更与作废规则

老师要求任何gold变更则已跑数据作废。实施为：
- 原文件永远保留，打INVALIDATED标签；不删除历史。
- case集合、reaction/trait gold、gold lookup事实改变，dataset_version变更，G2及之后所有依赖门失效；重新生成题面/审计/评分器/search/smoke/pilot/预算/正式流程。
- 不能因为旧响应恰好仍有用就复用为新gold的正式运行；若希望例外，须老师另行裁决。
- 仅scorer代码/规则改动：已出全部分数失效，按新冻结版本对所有正式响应重算；若改动实质涉及gold，按上条处理。
- prompt/schema/参数/search policy变动：既有受影响工程门与正式批准绑定失效，至少重新验证相关上游门及smoke/pilot，不能把不同版本轮次拼接。
- 单纯报告排版不改科学/接口/输入哈希，不触发昂贵重跑，保留差异说明。

invalidation_ledger.tsv记录old/new hash、原因、时间、受影响阶段、执行者和新审批路径。

## 18. 老师裁决尚未唯一指定的实现细节

只对以下细节形成一张待签表，不反复向用户讨论已定事项，不把实现建议伪装成老师原话：

| 细节 | 当前建议 | 何时必须确定 |
|---|---|---|
| 五层内部子指标比例和macro/micro | 层内子指标等权草案、case宏平均主/微观计数辅 | G3总分冻结前 |
| 性状10%如何组合两率 | 两率独立展示，提出组合函数供签；不默默合并成唯一性状率 | G3前 |
| overclaim惩罚函数 | null非overclaim；编造应劣于诚实弃权，冻结权重/扣分 | G3前 |
| 二分图阈值、方向、集合规则、名称/SMILES冲突 | 本合同9.1建议，mock手算验证 | G3前 |
| JSON有效率门按syntax还是业务对象 | syntax/object/schema分别列；建议可用JSON对象主门，数组/null不冒充回答 | G5前 |
| 指定via信息与gold泄漏检查重叠 | 逐case最小允许表，老师10%抽审及未决项回签 | G2前 |
| 温度/pH/盐度单位和多条observed记录 | 冻结exact接受集合、optimum主列，不设容差 | G1/G3前 |
| “全字段完整率”到底15项还是子字段 | 两种同时输出，主15项、子字段细表建议 | G3前 |

这些不是新的五层权重协商。实施者可以先提交确定的程序草案和mock预期，等待对应确认；不因此停止全部D0/G1准备。
如果老师原件后续另有明确解释，直接采用并记录hash，不再问一遍。

## 19. 阶段文件与本地/远端隔离

建议25目录阶段结构：
authority/
G1_gold/
G2_questions/
G3_scorer/
G4_search/
G5_smoke/
G6_pilot/
G7_budget/
G8_formal/
G9_reports/
quarantine/
gates/
invalidation_ledger.tsv

COLLECTOR_ROOT保留代码及模板；BENCHMARK_ROOT保留源构建数据。新阶段用manifest引用，避免复制多份不一致gold。
各阶段独立打包，不做“一条prompt跑完所有阶段”。

交给Chenyu的阶段包：
程序、完整空模板、实际Schema、盲cases、参数、限额、当前stage gate evidence、依赖锁、mock、自检脚本、SHA。
不含hidden gold、trait gold、teacher设计已填示例、评分器lookup内容、密钥。
G3评分器和G1 gold只留本地；外部提供的门回签仅含哈希与PASS，不含标准答案。

阶段README必须写：
stage名称、上游哈希、允许任务数量、endpoint、密钥外置路径、输出绝对目录、进入条件、退出条件、禁止自动推进的下一阶段。

远端目录示意：
/usrdata/EnzymeCAGE_data/workspaces/biosysmodb_teacher_aligned_20260926/<phase_run_id>/

真实执行者只能运行已解锁阶段。D0离线包即使部署到服务器，也不因为有key就发请求。
老师原件和未回签预算不放“可执行授权”一栏。

## 20. 接班AI首次启动指令

> 先完整读取老师原件和本合同。你负责按阶段实施，不代替老师裁决。
> 第一步只做D0/G1准备：列出已有v2与老师裁决的差异，构建quarantine影响表，形成正式gold候选/补选或降额方案；同时离线修采集器required/extra-warning、完整模板和流式持久化，mock通过。
> 不修改老师原文、不触碰其他训练任务；不启动任何新的模型API请求。
> 每项产物完成后交本地独立审计，提交G1 gold材料与G2题面抽审给老师。只有G1–G3通过后才允许G4搜索探针；之后必须按3题smoke、10题pilot、预算老师确认、5n全量的顺序。
> 所有模型回答原样保存，Schema失败也不丢弃；工程不合规能阻断进入下一阶段，但不能诱发单题科学纠错重问。
> 每次回复只给当前stage、已产物路径、验收分子/分母、未决项和下一允许动作，不把计划描述成已经运行成功。

本合同修订本身不代表任何G门已通过。当前最需要推进的是gold/quarantine实物和D0离线实现；暂时没有可授权Chenyu直接发新科学题的阶段包。
