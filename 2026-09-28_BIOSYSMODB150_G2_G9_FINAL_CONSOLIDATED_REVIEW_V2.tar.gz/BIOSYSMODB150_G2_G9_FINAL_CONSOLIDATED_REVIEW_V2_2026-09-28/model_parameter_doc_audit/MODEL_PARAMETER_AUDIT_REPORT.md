# 五模型官方参数与价格证据审计报告（PUBLIC_DOCUMENTATION_AUDIT_ONLY 2026-09-28）

商业模型API调用：0 | API key读取：0 | runtime_config_modified=false | 计费探针：0

来源等级：EXACT_ID_OFFICIAL（快照内出现精确ID+字段）/ FAMILY_OFFICIAL（仅家族级）/ HISTORICAL_OBSERVATION（2026-09-24/26观察，永不升级为官方支持）/ UNKNOWN。所有引文锚点可经 raw_sources 快照+`clean` 规范化程序复核（build_parameter_audit.py 在生成时硬断言）。

## qwen3.8-flash
- 官方列表: **YES** [EXACT_ID_OFFICIAL] src=S01
- 上下文窗口: **1000000** [EXACT_ID_OFFICIAL] src=S22
- 最大输出: **131072 (思考模式同 131072)** [EXACT_ID_OFFICIAL] src=S22
- 思考开关: **YES (系列级)** [FAMILY_OFFICIAL] src=S03
- thinking_budget: **settable (系列级)** [FAMILY_OFFICIAL] src=S03
- reasoning_effort: **UNKNOWN_not_documented_for_this_id** [UNKNOWN] src=
- reasoning与输出上限关系: **UNKNOWN_semantics_unresolved** [UNKNOWN] src=
- enable_search官方支持: **YES** [EXACT_ID_OFFICIAL] src=S22
- 结构化输出: **YES 结构化输出(card; json_schema见S05系列行)** [EXACT_ID_OFFICIAL] src=S22
- 输入价(元/百万tok): **0.8** [EXACT_ID_OFFICIAL] src=S06
- 输出价(含思维链): **2.7** [EXACT_ID_OFFICIAL] src=S06

## qwen3.8-max
- 官方列表: **YES** [EXACT_ID_OFFICIAL] src=S01
- 上下文窗口: **1000000** [EXACT_ID_OFFICIAL] src=S21
- 最大输出: **131072 (思考模式同 131072)** [EXACT_ID_OFFICIAL] src=S21
- 思考开关: **YES via extra_body (非OpenAI标准参数)** [EXACT_ID_OFFICIAL] src=S03
- thinking_budget: **settable (系列级)** [FAMILY_OFFICIAL] src=S03
- reasoning_effort: **UNKNOWN_not_documented_for_this_id** [UNKNOWN] src=
- reasoning与输出上限关系: **UNKNOWN_semantics_unresolved** [UNKNOWN] src=
- enable_search官方支持: **YES** [EXACT_ID_OFFICIAL] src=S21
- 结构化输出: **YES 结构化输出(card; json_schema见S05系列行)** [EXACT_ID_OFFICIAL] src=S21
- 输入价(元/百万tok): **12** [EXACT_ID_OFFICIAL] src=S06
- 输出价(含思维链): **36** [EXACT_ID_OFFICIAL] src=S06

## deepseek-v4-pro-0813
- 官方列表: **YES** [EXACT_ID_OFFICIAL] src=S01
- 上下文窗口: **1000000** [EXACT_ID_OFFICIAL] src=S27
- 最大输出: **393216 (思考模式同 393216; 思维链 393216)** [EXACT_ID_OFFICIAL] src=S27
- 思考开关: **YES** [EXACT_ID_OFFICIAL] src=S15
- thinking_budget: **UNKNOWN_not_in_defaults_table** [UNKNOWN] src=S15
- reasoning_effort: **low/high/max, default high; low supported** [EXACT_ID_OFFICIAL] src=S15
- reasoning与输出上限关系: **YES_shared_cap_393216** [EXACT_ID_OFFICIAL] src=S27
- enable_search官方支持: **YES** [EXACT_ID_OFFICIAL] src=S04
- 结构化输出: **YES** [EXACT_ID_OFFICIAL] src=S27
- 输入价(元/百万tok): **忙9/闲4.5** [EXACT_ID_OFFICIAL] src=S06
- 输出价(含思维链): **忙27/闲13.5** [EXACT_ID_OFFICIAL] src=S06

## deepseek-v4.1-flash
- 官方列表: **YES** [EXACT_ID_OFFICIAL] src=S01
- 上下文窗口: **1000000** [EXACT_ID_OFFICIAL] src=S26
- 最大输出: **393216 (思考模式同 393216; 思维链 393216)** [EXACT_ID_OFFICIAL] src=S26
- 思考开关: **YES** [EXACT_ID_OFFICIAL] src=S15
- thinking_budget: **NOT_SETTABLE** [EXACT_ID_OFFICIAL] src=S15
- reasoning_effort: **low/high/max, default high; low supported** [EXACT_ID_OFFICIAL] src=S15
- reasoning与输出上限关系: **YES_shared_cap_393216** [EXACT_ID_OFFICIAL] src=S26
- enable_search官方支持: **YES** [EXACT_ID_OFFICIAL] src=S26
- 结构化输出: **YES** [EXACT_ID_OFFICIAL] src=S26
- 输入价(元/百万tok): **忙2/闲1** [EXACT_ID_OFFICIAL] src=S06
- 输出价(含思维链): **忙8/闲4** [EXACT_ID_OFFICIAL] src=S06

## ZHIPU/GLM-5.3
- 官方列表: **YES** [EXACT_ID_OFFICIAL] src=S01
- 上下文窗口: **UNKNOWN_exact** [FAMILY_OFFICIAL] src=S16
- 最大输出: **UNKNOWN_exact** [UNKNOWN] src=
- 思考开关: **UNKNOWN_exact** [UNKNOWN] src=
- thinking_budget: **—** [—] src=
- reasoning_effort: **UNKNOWN_exact** [UNKNOWN] src=
- reasoning与输出上限关系: **—** [—] src=
- enable_search官方支持: **UNKNOWN_exact_id_not_listed** [UNKNOWN] src=S23
- 结构化输出: **UNKNOWN_exact_id_not_documented** [UNKNOWN] src=S16
- 输入价(元/百万tok): **8** [EXACT_ID_OFFICIAL] src=S06
- 输出价(含思维链): **28** [EXACT_ID_OFFICIAL] src=S06

## 关键结论
- 五精确ID全部在百炼官方列表（S01）出现；北京网关可用；S06/S07有精确ID价目与限流行。
- deepseek-v4.1-flash：S15默认值表行+26卡片给 393216 上限（thinking_budget 不可设）、reasoning_effort(low/high/max) 默认开启思考；enable_search/结构化输出 卡片级 exact。
- deepseek-v4-pro-0813：S27「快照版本」块给 exact 393216/1M 上下文与能力表；S15 exact enable_thinking 叙述+reasoning_effort low exact；S04 exact 搜索支持；thinking_budget exact 行缺失（家族共393,216注释）→ 该参数保持 UNKNOWN。
- qwen3.8-max/flash：S21/S22 卡片给 exact 上下文 1,000,000、最大输出 131,072、最大思维链 262,144；思考默认状态与 reasoning 是否计入 max_tokens 语义保持 UNKNOWN（历史 smoke completion>max_tokens 仅记 HISTORICAL）。
- ZHIPU/GLM-5.3：仅有 S01 列表、S06 价目（8/28 元、仅思考模式、无免费额度）、S07 限流（200 RPM/3M TPM）为 exact；功能参数与上限全部 UNKNOWN——glm-5.3（阿里云直供）是不同 ID，不得借用其数字；未找到 ZHIPU/GLM-5.3 卡片页（S24/S25 为动态壳页）。
- enable_search 仍必须由 G4 决议全开/全关；「官方支持」不等于「实际生效」，search_support_matrix 的 effectively_verified 全部 UNKNOWN。
- 价格边界（修正 37a34cce）：五个 exact ID 的基础 input/output token 价均有官方 exact 价目（S06 及各卡片页）；但不是所有缓存/搜索附加/批处理价格均确认——ZHIPU/GLM-5.3 的缓存价来自不同 model_id（glm-5.3 阿里云直供, S23），不得借用，已降为 UNKNOWN_exact_ID_not_documented；五模型 search/tool 附加费均 UNKNOWN。G7 基础 token 预算可计算，额外费用与 DeepSeek 忙/闲时段仍需保守边界。

