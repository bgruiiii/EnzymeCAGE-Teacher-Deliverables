import json,os,sys
AUD=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,AUD) if False else None
mx=[l.split("\t") for l in open("exact_model_parameter_matrix.tsv",encoding="utf-8").read().rstrip("\n").split("\n")[1:]]
def get(m,f):
    for r in mx:
        if r[0]==m and r[1]==f: return r[2],r[3],r[4]
    return "—","—",""
L=["# 五模型官方参数与价格证据审计报告（PUBLIC_DOCUMENTATION_AUDIT_ONLY 2026-09-28）","",
"商业模型API调用：0 | API key读取：0 | runtime_config_modified=false | 计费探针：0","",
"来源等级：EXACT_ID_OFFICIAL（快照内出现精确ID+字段）/ FAMILY_OFFICIAL（仅家族级）/ HISTORICAL_OBSERVATION（2026-09-24/26观察，永不升级为官方支持）/ UNKNOWN。所有引文锚点可经 raw_sources 快照+`clean` 规范化程序复核（build_parameter_audit.py 在生成时硬断言）。",""]
for m in ["qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"]:
    L.append("## "+m)
    for f,label in [("listed_official_index","官方列表"),("context_window_tokens","上下文窗口"),("max_output_tokens","最大输出"),
        ("enable_thinking_switch","思考开关"),("thinking_budget","thinking_budget"),("reasoning_effort","reasoning_effort"),
        ("reasoning_included_in_max_tokens","reasoning与输出上限关系"),("enable_search_official","enable_search官方支持"),
        ("structured_output","结构化输出"),("price_input_CNY_per_1M_tokens","输入价(元/百万tok)"),("price_output_CNY_per_1M_tokens","输出价(含思维链)")]:
        v,l,s=get(m,f); L.append("- %s: **%s** [%s] src=%s"%(label,v,l,s))
    L.append("")
L+=["## 关键结论","- 五精确ID全部在百炼官方列表（S01）出现；北京网关可用；S06/S07有精确ID价目与限流行。",
"- deepseek-v4.1-flash：S15默认值表行+26卡片给 393216 上限（thinking_budget 不可设）、reasoning_effort(low/high/max) 默认开启思考；enable_search/结构化输出 卡片级 exact。",
"- deepseek-v4-pro-0813：S27「快照版本」块给 exact 393216/1M 上下文与能力表；S15 exact enable_thinking 叙述+reasoning_effort low exact；S04 exact 搜索支持；thinking_budget exact 行缺失（家族共393,216注释）→ 该参数保持 UNKNOWN。",
"- qwen3.8-max/flash：S21/S22 卡片给 exact 上下文 1,000,000、最大输出 131,072、最大思维链 262,144；思考默认状态与 reasoning 是否计入 max_tokens 语义保持 UNKNOWN（历史 smoke completion>max_tokens 仅记 HISTORICAL）。",
"- ZHIPU/GLM-5.3：仅有 S01 列表、S06 价目（8/28 元、仅思考模式、无免费额度）、S07 限流（200 RPM/3M TPM）为 exact；功能参数与上限全部 UNKNOWN——glm-5.3（阿里云直供）是不同 ID，不得借用其数字；未找到 ZHIPU/GLM-5.3 卡片页（S24/S25 为动态壳页）。",
"- enable_search 仍必须由 G4 决议全开/全关；「官方支持」不等于「实际生效」，search_support_matrix 的 effectively_verified 全部 UNKNOWN。",
"- 价格边界（修正 37a34cce）：五个 exact ID 的基础 input/output token 价均有官方 exact 价目（S06 及各卡片页）；但不是所有缓存/搜索附加/批处理价格均确认——ZHIPU/GLM-5.3 的缓存价来自不同 model_id（glm-5.3 阿里云直供, S23），不得借用，已降为 UNKNOWN_exact_ID_not_documented；五模型 search/tool 附加费均 UNKNOWN。G7 基础 token 预算可计算，额外费用与 DeepSeek 忙/闲时段仍需保守边界。",""]
json.dump({"public_web_requests":27,"commercial_model_api_calls":0,"api_key_reads":0,"runtime_config_modified":False,
 "sources_shell_pages":["S08","S09","S13","S14","S17","S18","S19","S24","S25"],
 "sources_aux_vendor":["S10","S11","S12"],"evidence_items":len(mx)},
 open("audit_summary.json","w"),ensure_ascii=False,indent=2,sort_keys=True); open("audit_summary.json","a").write("\n")
open("MODEL_PARAMETER_AUDIT_REPORT.md","w",encoding="utf-8").write("\n".join(L)+"\n")
print("report+summary written", len(mx), "evidence rows")
