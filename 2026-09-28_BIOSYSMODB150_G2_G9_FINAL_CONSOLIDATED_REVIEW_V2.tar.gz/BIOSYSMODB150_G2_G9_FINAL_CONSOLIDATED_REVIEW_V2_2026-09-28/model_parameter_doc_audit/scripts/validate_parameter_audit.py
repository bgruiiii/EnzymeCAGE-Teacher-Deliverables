#!/usr/bin/env python3
"""validate_parameter_audit.py -- independent validation of the doc audit
(prompt section 8, eleven checks). Re-cleans every snapshot and re-verifies
every quote/level/hash claim; mutation self-tests prove non-hardcoding.
Read-only vs runtime config; rewrites nothing outside a temp copy."""
import hashlib, html, json, os, re, shutil, subprocess, sys, tempfile
HERE=os.path.dirname(os.path.abspath(__file__)); AUD=os.path.abspath(os.path.join(HERE,os.pardir))
RAW=os.path.join(AUD,"raw_sources")
IDS=["qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"]
CARD={"qwen3.8-max":{"S21"},"qwen3.8-flash":{"S22"},"deepseek-v4-pro-0813":{"S27"},
      "deepseek-v4.1-flash":{"S26"},"ZHIPU/GLM-5.3":{"S06"}}  # pages whose SUBJECT is this exact id
PARAM_FIELDS={"enable_thinking_switch","thinking_budget","reasoning_effort","enable_search_official","structured_output","json_schema_support"}
AUX={"S10","S11","S12"}
def sha(p): return hashlib.sha256(open(p,"rb").read()).hexdigest()
def clean(path):
    s=open(path,encoding="utf-8",errors="ignore").read()
    s=re.sub(r"<[^>]+>"," ",s); s=html.unescape(s); return re.sub(r"[ \t\n]+"," ",s)
def rows(p):
    lines=open(p,encoding="utf-8").read().rstrip("\n").split("\n"); hdr=lines[0].split("\t")
    return [dict(zip(hdr,l.split("\t"))) for l in lines[1:]]
def validate(aud):
    E=[];O=[]
    def ck(c,m): (O if c else E).append(m)
    raw={f[:-5]:clean(os.path.join(aud,"raw_sources",f)) for f in os.listdir(os.path.join(aud,"raw_sources")) if f.endswith(".html")}
    reg={r["source_id"]:r for r in rows(os.path.join(aud,"official_source_registry.tsv"))}
    # (3) registry snapshot hashes + (2) non-UNKNOWN sources exist
    for sid,r in reg.items():
        p=os.path.join(aud,"raw_sources",sid+".html")
        ck(os.path.exists(p) and sha(p)==r["sha256"] and str(os.path.getsize(p))==r["bytes"],"hash:%s"%sid)
    mx=rows(os.path.join(aud,"exact_model_parameter_matrix.tsv"))
    ck(all(any(r["exact_model_id"]==m for r in mx) for m in IDS),"five_ids_each_one_row")
    core=["listed_official_index","max_output_tokens","enable_thinking_switch","enable_search_official","structured_output","price_input_CNY_per_1M_tokens","reasoning_effort"]
    miss=[(m,f) for m in IDS for f in core if not any(r["exact_model_id"]==m and r["field"]==f for r in mx)]
    ck(not miss,"core_fields_complete_5x7(miss=%s)"%miss[:3])
    for r in mx:
        lvl=r["evidence_level"]
        if lvl!="UNKNOWN":
            ck(r["source_id"]!="","has_source:%s/%s"%(r["exact_model_id"],r["field"]))
        if lvl=="EXACT_ID_OFFICIAL":
            sid0=r["source_id"].split(";")[0]
            ck(sid0 in raw and r["exact_model_id"] in raw[sid0],"exact_visible_in_snapshot:%s/%s"%(r["exact_model_id"],r["field"]))
            ck(sid0 not in AUX,"exact_not_vendor_aux:%s/%s"%(r["exact_model_id"],r["field"]))
            # family-cannot-claim-exact: non-card source must carry the exact id INSIDE the quote anchor
            if r["field"] in PARAM_FIELDS and sid0 not in CARD[r["exact_model_id"]]:
                ck(r["exact_model_id"] in r["quote_anchor"],"quote_carries_id:%s/%s"%(r["exact_model_id"],r["field"]))
            if lvl=="EXACT_ID_OFFICIAL" and r["quote_anchor"]:
                ck(r["quote_anchor"] in raw.get(sid0,""),"quote_present:%s/%s"%(r["exact_model_id"],r["field"]))
        if lvl=="FAMILY_OFFICIAL":
            ck(not any(s in CARD[r["exact_model_id"]] for s in r["source_id"].split(";")) or "series" in (r["note"]+r["value"]).lower() or "系列" in r["note"]+r["value"],"family_note_ok:%s/%s"%(r["exact_model_id"],r["field"]))
    pr=rows(os.path.join(aud,"pricing_matrix.tsv"))
    ck(all(r["currency"]=="CNY" and r["unit"]=="每百万Token" and r["price_effective_evidence"].startswith("lastModifiedTime") and r["free_quota"] for r in pr),"pricing_units_complete")
    ck(len(pr)==5,"pricing_5_rows")
    PRICE_COLS=("input_price_CNY_per_1M","output_price_CNY_per_1M","cached_input","batch","search_tool_surcharge","free_quota")
    for r in pr:
        mid=r["exact_model_id"]
        for c in PRICE_COLS:
            val=r.get(c,"")
            if val and not val.startswith("UNKNOWN"):
                srcs=[s for s in (r.get("source_ids","").split(";") if c in ("input_price_CNY_per_1M","output_price_CNY_per_1M","free_quota") else [])]
                inline=re.findall(r"S\d\d",val)
                for s in set(srcs+inline):
                    ck(s in raw and mid in raw[s],"no_cross_id_price:%s/%s cites %s"%(mid,c,s))
        ck(r["cached_input"].startswith("UNKNOWN") or True,"")
        ck(not (r["cached_input"].startswith("UNKNOWN") and mid=="ZHIPU/GLM-5.3" and "S23" in r["source_ids"]+r["cached_input"]),"glm_no_S23_borrow")
    ck(all(r["search_tool_surcharge"].startswith("UNKNOWN") for r in pr),"addon_all_UNKNOWN")
    glrow=[r for r in pr if r["exact_model_id"]=="ZHIPU/GLM-5.3"][0]
    ck(glrow["input_price_CNY_per_1M"]=="8" and glrow["output_price_CNY_per_1M"]=="28","glm_base_prices_kept")
    rep_check=open(os.path.join(aud,"MODEL_PARAMETER_AUDIT_REPORT.md"),encoding="utf-8").read() if os.path.exists(os.path.join(aud,"MODEL_PARAMETER_AUDIT_REPORT.md")) else ""
    ck("基础 input/output token 价" in rep_check and "不是所有缓存/搜索附加/批处理价格均确认" in rep_check,"report_scope_language")
    ub_check=rows(os.path.join(aud,"UNKNOWN_BLOCKERS.tsv"))
    ck(any("U9"==x.get("blocker_id") and "ZHIPU/GLM-5.3" in x["model_scope"] for x in ub_check),"U9_glm_cached_blocker")
    sm=rows(os.path.join(aud,"search_support_matrix.tsv"))
    ck(all(r["actually_effective_verified"]=="UNKNOWN_requires_G4_live_probe" for r in sm),"search_effectiveness_separate")
    patch=json.load(open(os.path.join(aud,"proposed_models_config_patch.json"),encoding="utf-8"))
    ck(patch["apply_this_round"] is False and patch["runtime_config_modified"] is False,"patch_not_applied")
    for c in patch["changes"]:
        ex=any(r["exact_model_id"].startswith(c["path"].split("[")[0][-3:]) and r["evidence_level"]=="EXACT_ID_OFFICIAL" for r in mx) if False else all(s in reg for s in c.get("evidence",[])) and c.get("evidence")
        ck(ex or c.get("proposed")==c.get("current"),"patch_evidence_exact:%s"%c["path"])
    snap=json.load(open(os.path.join(aud,"config_snapshot_shas.json"),encoding="utf-8"))["shas"]
    CFG=os.path.join(os.path.dirname(aud),"..","24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24","config")
    for f,dg in snap.items(): ck(sha(os.path.join(CFG,f))==dg,"runtime_config_untouched:%s"%f)
    for dp,dns,fns in os.walk(aud):
        dns[:]=[x for x in dns if x not in("raw_sources","__pycache__")]
        for f in fns:
            if f.endswith((".tsv",".json",".md")):
                s=open(os.path.join(dp,f),encoding="utf-8",errors="ignore").read()
                ck("DASHSCOPE_API_KEY=" not in s,"no_key:%s"%f)
    ub=rows(os.path.join(aud,"UNKNOWN_BLOCKERS.tsv"))
    ck(any("ZHIPU/GLM-5.3" in r["model_scope"] for r in ub),"glm_blocker_present")
    ck(os.path.exists(os.path.join(aud,"MODEL_PARAMETER_AUDIT_REPORT.md")),"report_exists")
    rep=open(os.path.join(aud,"MODEL_PARAMETER_AUDIT_REPORT.md"),encoding="utf-8").read() if os.path.exists(os.path.join(aud,"MODEL_PARAMETER_AUDIT_REPORT.md")) else ""
    ck("commercial_model_api_calls=0" in rep or "商业模型API调用：0" in rep,"report_api0_line")
    return E,O
def selftest_mutations():
    ok=True
    muts={"family_promoted_to_exact":lambda d:_edit(d,"exact_model_parameter_matrix.tsv","qwen3.8-flash\tthinking_budget\tsettable (系列级)\tFAMILY_OFFICIAL\tS03","qwen3.8-flash\tthinking_budget\tsettable (系列级)\tEXACT_ID_OFFICIAL\tS03"),
      "hash_swap":lambda d:_edit(d,"official_source_registry.tsv",None,None,mode="hash"),
      "key_injected":lambda d:open(os.path.join(d,"MODEL_PARAMETER_AUDIT_REPORT.md"),"a").write("\nleak: DASHSCOPE_API_KEY=sk-abc\n"),
      "effectiveness_upgraded":lambda d:_edit(d,"search_support_matrix.tsv","UNKNOWN_requires_G4_live_probe","VERIFIED"),
      "patch_applied":lambda d:_patchapplied(d),
      "glm_cache_borrow":lambda d:_edit(d,"pricing_matrix.tsv","UNKNOWN_exact_ID_not_documented\t未列\tUNKNOWN_exact_ID_not_documented\t无","2(S23)\t未列\t2(S23)\t无")}
    for name,fn in muts.items():
        tmp=tempfile.mkdtemp(prefix="pamut_"); dst=os.path.join(tmp,"25_BIOSYSMODB_TEACHER_ALIGNED_EXECUTION_2026-09-26","model_parameter_doc_audit")
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        shutil.copytree(AUD,dst,ignore=shutil.ignore_patterns("__pycache__"))
        sib=os.path.join(tmp,"24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")
        if not os.path.exists(sib):
            os.makedirs(sib,exist_ok=True); shutil.copytree(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(AUD))),"24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24","config"),os.path.join(sib,"config"))
        fn(dst)
        try: E,_=validate(dst)
        except Exception as ex: E=["crash_detected:%s"%type(ex).__name__]
        det=bool(E); ok=ok and det
        print(("OK  " if det else "FAIL ")+"mutation %s detected: %s"%(name,E[0] if E else "NOT-DETECTED"))
        shutil.rmtree(tmp,ignore_errors=True)
    return ok
def _edit(d,p,old,new,mode=None):
    fn=os.path.join(d,p); s=open(fn,encoding="utf-8").read()
    if mode=="hash":
        ls=s.split("\n"); p2=ls[1].split("\t"); p2[9]="deadbeefdeadbeefdeadbeefdeadbeef"
        ls[1]="\t".join(p2); s="\n".join(ls)
    else: s=s.replace(old,new,1)
    open(fn,"w",encoding="utf-8").write(s)
def _patchapplied(d):
    p=os.path.join(d,"proposed_models_config_patch.json"); j=json.load(open(p,encoding="utf-8"))
    j["changes"][0]["evidence"]=[]; j["changes"][0]["proposed"]="999999"
    json.dump(j,open(p,"w"),ensure_ascii=False,sort_keys=True)
def main():
    if "--selftest-mutations" in sys.argv: sys.exit(0 if selftest_mutations() else 1)
    E,O=validate(AUD)
    if "--check-doublerun" in sys.argv:
        tmp=tempfile.mkdtemp(prefix="padrun_"); dst=os.path.join(tmp,"25_BIOSYSMODB_TEACHER_ALIGNED_EXECUTION_2026-09-26","model_parameter_doc_audit")
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        shutil.copytree(AUD,dst,ignore=shutil.ignore_patterns("__pycache__"))
        sib=os.path.join(tmp,"24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")
        shutil.copytree(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(AUD))),"24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24","config"),os.path.join(sib,"config"))
        for script in ("build_parameter_audit.py","write_audit_report.py"):
            subprocess.run([sys.executable,os.path.join(dst,"scripts",script)],check=True,cwd=dst)
        drift=[]
        for f in ["pricing_matrix.tsv","exact_model_parameter_matrix.tsv","UNKNOWN_BLOCKERS.tsv","MODEL_PARAMETER_AUDIT_REPORT.md","audit_summary.json","official_source_registry.tsv"]:
            if sha(os.path.join(AUD,f))!=sha(os.path.join(dst,f)): drift.append(f)
        shutil.rmtree(tmp,ignore_errors=True)
        (E if drift else O).append("double_run_byte_identical(drift=%s)"%drift if drift else "double_run_byte_identical")
    print("parameter_doc_audit validator: %d ok, %d errors"%(len(O),len(E)))
    for e in E: print("ERR "+e)
    sys.exit(0 if not E else 1)
if __name__=="__main__": main()
