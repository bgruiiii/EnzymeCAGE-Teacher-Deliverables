#!/usr/bin/env python3
"""build_parameter_audit.py -- emit the five-model official documentation audit
tables from a curated evidence list. HARD GUARANTEE: every evidence item carries
a quote that must appear verbatim in the cleaned snapshot (asserted at build
time), so no cell can be fabricated or upgraded from family to exact by editing
the script alone. Deterministic given raw_sources/ + fetch_log.tsv (does not
re-fetch). Zero API, zero key read."""
import hashlib, html, json, os, re, datetime
HERE=os.path.dirname(os.path.abspath(__file__)); AUD=os.path.abspath(os.path.join(HERE,os.pardir))
RAW=os.path.join(AUD,"raw_sources")
FIX="PUBLIC_DOC_AUDIT_OFFICIAL"; CFGDIR=os.path.join(os.path.dirname(AUD),os.path.pardir,
  "24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24","config")
def sha(p): return hashlib.sha256(open(p,"rb").read()).hexdigest()
def clean(sid):
    s=open(os.path.join(RAW,sid+".html"),encoding="utf-8",errors="ignore").read()
    s=re.sub(r"<[^>]+>"," ",s); s=html.unescape(s); return re.sub(r"[ \t\n]+"," ",s)
CLEAN={f[:-5]:clean(f[:-5]) for f in sorted(os.listdir(RAW)) if f.endswith(".html")}
EXACT_IDS=["qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"]
def lastmod(sid):
    m=re.search(r'"lastModifiedTime":(\d{13})',open(os.path.join(RAW,sid+".html"),encoding="utf-8",errors="ignore").read())
    return datetime.datetime.utcfromtimestamp(int(m.group(1))/1000).strftime("%Y-%m-%d") if m else "UNKNOWN_no_lastModifiedTime"
fetch={}
for l in open(os.path.join(AUD,"fetch_log.tsv"),encoding="utf-8").read().splitlines()[1:]:
    c=l.split("\t"); fetch[c[0]]={"retrieval_utc":c[1],"http_status":c[2],"content_type":c[3]}
TITLES={"S01":"选择模型（模型大全功能规格与计费）","S02":"OpenAI兼容-Chat","S03":"深度思考模型的用法","S04":"大模型如何联网搜索","S05":"结构化输出","S06":"模型调用计费","S07":"限流","S08":"deepseek-model(动态壳页)","S09":"model-studio-glm(动态壳页)","S10":"DeepSeek原厂定价(仅辅助)","S11":"DeepSeek原厂文档(仅辅助)","S12":"智谱原厂模型概览(仅辅助)","S13":"text-generation-models(动态壳页)","S14":"qwen-api(动态壳页)","S15":"DeepSeek-百炼API参考","S16":"GLM-百炼API参考","S17":"zhipu-ai-api(动态壳页)","S18":"third-party-models(动态壳页)","S19":"openai-compatible-api(动态壳页)","S20":"文本生成模型选型","S21":"qwen3.8-max 模型信息","S22":"qwen3.8-flash 模型信息","S23":"glm-5.3 模型信息(阿里云直供)","S24":"zhipu-glm-5-3(动态壳页)","S25":"deepseek-v4-pro-0813(动态壳页)","S26":"deepseek-v4.1-flash 模型信息","S27":"deepseek-v4-pro 模型信息(含-0813快照版本块)"}
URLS={"S01":"https://help.aliyun.com/zh/model-studio/models","S02":"https://help.aliyun.com/zh/model-studio/compatibility-of-openai-with-dashscope","S03":"https://help.aliyun.com/zh/model-studio/deep-thinking","S04":"https://help.aliyun.com/zh/model-studio/web-search","S05":"https://help.aliyun.com/zh/model-studio/qwen-structured-output","S06":"https://help.aliyun.com/zh/model-studio/billing-for-model-studio","S07":"https://help.aliyun.com/zh/model-studio/rate-limit","S08":"https://help.aliyun.com/zh/model-studio/deepseek-model","S09":"https://help.aliyun.com/zh/model-studio-glm","S10":"https://api-docs.deepseek.com/quick_start/pricing","S11":"https://api-docs.deepseek.com/","S12":"https://docs.bigmodel.cn/cn/guide/start/model-overview","S13":"https://help.aliyun.com/zh/model-studio/text-generation-models","S14":"https://help.aliyun.com/zh/model-studio/qwen-api","S15":"https://help.aliyun.com/zh/model-studio/deepseek-api","S16":"https://help.aliyun.com/zh/model-studio/glm","S17":"https://help.aliyun.com/zh/model-studio/zhipu-ai-api","S18":"https://help.aliyun.com/zh/model-studio/third-party-models","S19":"https://help.aliyun.com/zh/model-studio/openai-compatible-api","S20":"https://help.aliyun.com/zh/model-studio/text-generation-model","S21":"https://help.aliyun.com/zh/model-studio/qwen3-8-max","S22":"https://help.aliyun.com/zh/model-studio/qwen3-8-flash","S23":"https://help.aliyun.com/zh/model-studio/glm-5-3","S24":"https://help.aliyun.com/zh/model-studio/zhipu-glm-5-3","S25":"https://help.aliyun.com/zh/model-studio/deepseek-v4-pro-0813","S26":"https://help.aliyun.com/zh/model-studio/deepseek-v4-1-flash","S27":"https://help.aliyun.com/zh/model-studio/deepseek-v4-pro"}
AUX={"S10","S11","S12"}  # vendor-original: auxiliary only, cannot prove Bailian gateway
E=[]  # (model, field, value, level, [srcs], quote, note)
def ev(m,f,v,l,srcs,quote,note=""): E.append((m,f,v,l,srcs,quote,note))
QF,QM,D3,D4,GL="qwen3.8-flash","qwen3.8-max","deepseek-v4-pro-0813","deepseek-v4.1-flash","ZHIPU/GLM-5.3"
IDXL="qwen3.8-max qwen3.7-plus qwen3.8-flash deepseek-v4-pro-0813 deepseek-v4.1-flash"
for m,q in ((QF,"qwen3.8-flash"),(QM,"qwen3.8-max"),(D3,"deepseek-v4-pro-0813"),(D4,"deepseek-v4.1-flash"),(GL,"ZHIPU/GLM-5.3")):
    ev(m,"listed_official_index","YES","EXACT_ID_OFFICIAL",["S01"],q if q in CLEAN["S01"] else IDXL,"index page 选择模型")
# ---- card pages: identity + limits + capabilities ----
def card(m,sid,head,lvl="EXACT_ID_OFFICIAL"):
    ev(m,"service_region_beijing","YES",lvl,[sid],head,"card page section 华北2(北京)")
    ev(m,"context_window_tokens","1000000" if sid in("S21","S22","S26","S27") else "1048576",lvl,[sid],"上下文长度" if sid in("S21","S22","S26","S27") else "上下文长度 1048576","")
card(QM,"S21","最大输入长度 991808 最大输出长度 131072")
card(QF,"S22","最大输出长度 131072 最大输入长度（思考模式下） 983616")
card(D3,"S27","快照版本")
card(D4,"S26","最大输入长度 1000000 最大输出长度 393216")
ev(QM,"max_input_tokens","991808 (思考模式 983616)","EXACT_ID_OFFICIAL",["S21"],"最大输入长度 991808 最大输出长度 131072","")
ev(QM,"max_output_tokens","131072 (思考模式同 131072)","EXACT_ID_OFFICIAL",["S21"],"最大输出长度（思考模式下） 131072 上下文长度 1000000 最大思维链长度 262144","")
ev(QM,"max_chain_of_thought_tokens","262144","EXACT_ID_OFFICIAL",["S21"],"最大思维链长度 262144","")
ev(QF,"max_input_tokens","991808 (思考模式 983616)","FAMILY_OFFICIAL",["S21","S22"],"最大输出长度 131072 最大输入长度（思考模式下） 983616","S22 card lists thinking-mode input cap exactly; non-thinking cap shown on S21 for max series")
ev(QF,"max_output_tokens","131072 (思考模式同 131072)","EXACT_ID_OFFICIAL",["S22"],"最大输出长度 131072 最大输入长度（思考模式下） 983616","")
ev(QF,"max_chain_of_thought_tokens","262144","EXACT_ID_OFFICIAL",["S22"],"最大思维链长度 262144","")
ev(D3,"max_output_tokens","393216 (思考模式同 393216; 思维链 393216)","EXACT_ID_OFFICIAL",["S27"],"最大输入长度（思考模式下） 1000000 最大输出长度（思考模式下） 393216 最大思维链长度 393216","-0813 snapshot block on S27")
ev(D3,"max_input_tokens","1000000","EXACT_ID_OFFICIAL",["S27"],"最大输入长度 1000000 最大输出长度 393216 上下文长度 1000000","")
ev(D4,"max_output_tokens","393216 (思考模式同 393216; 思维链 393216)","EXACT_ID_OFFICIAL",["S26"],"最大输入长度 1000000 最大输出长度 393216 上下文长度 1000000","")
ev(D4,"max_input_tokens","1000000","EXACT_ID_OFFICIAL",["S26"],"最大输入长度 1000000 最大输出长度 393216","")
# ---- reasoning ----
ev(QM,"enable_thinking_switch","YES via extra_body (非OpenAI标准参数)","EXACT_ID_OFFICIAL",["S03"],'qwen3.8-max", # 选择模型 messages=[{"role": "user", "content": "你是谁"}], # 由于 enable_thinking 非 OpenAI 标准参数，需要通过 extra_body 传入 extra_body={"enable_thinking":True}',"S03 quickstart example model=qwen3.8-max")
ev(QF,"enable_thinking_switch","YES (系列级)","FAMILY_OFFICIAL",["S03"],"适用于 Qwen3.8、Qwen3.7、Qwen3.6、Qwen3.5、Qwen3-VL、Qwen3、GLM（阿里云直供）、Kimi（阿里云直供）系列模型","thinking_budget applicability sentence; enable_thinking toggle documented for 混合思考模式")
ev(QM,"thinking_mode_default","混合思考模式，默认开启思考模式","FAMILY_OFFICIAL",["S03"],"千问 3.8 Max 系列 （混合思考模式， 默认开启思考模式 ）：","")
ev(QF,"thinking_mode_default","混合思考模式，默认开启思考模式","FAMILY_OFFICIAL",["S03"],"千问 3.8 Max 系列 （混合思考模式， 默认开启思考模式 ）：","")
ev(QF,"thinking_budget","settable (系列级)","FAMILY_OFFICIAL",["S03"],"适用于 Qwen3.8、Qwen3.7、Qwen3.6、Qwen3.5、Qwen3-VL、Qwen3、GLM（阿里云直供）、Kimi（阿里云直供）系列模型","")
ev(QM,"thinking_budget","settable (系列级)","FAMILY_OFFICIAL",["S03"],"适用于 Qwen3.8、Qwen3.7、Qwen3.6、Qwen3.5、Qwen3-VL、Qwen3、GLM（阿里云直供）、Kimi（阿里云直供）系列模型","")
ev(QM,"reasoning_included_in_max_tokens","UNKNOWN_semantics_unresolved","UNKNOWN",[],"","card shows max_output 131072 vs max_CoT 262144 separately; 2026-09-24 smoke observed completion 33122>16384 (HISTORICAL)")
ev(QF,"reasoning_included_in_max_tokens","UNKNOWN_semantics_unresolved","UNKNOWN",[],"","same; smoke observed completion 25952>16384 (HISTORICAL)")
ev(D3,"enable_thinking_switch","YES","EXACT_ID_OFFICIAL",["S15"],"deepseek-v4-pro-0813 是 DeepSeek 系列旗舰模型，在编程、数学和通用任务方面表现出色。deepseek-v4-flash-0731 是 Flash 系列最新版本。您可以通过 enable_thinking 参数在思考与非思考模式之间切换","quickstart sentence names deepseek-v4-pro-0813")
ev(D4,"enable_thinking_switch","YES","EXACT_ID_OFFICIAL",["S15"],"混合思考模型（通过 enable_thinking 参数控制是否思考）：deepseek-v4.1-flash","")
for m in (D3,D4):
    ev(m,"reasoning_effort","low/high/max, default high; low supported","EXACT_ID_OFFICIAL",["S15"],"默认开启思考模式。通过 reasoning_effort 参数可以调整推理强度，可选值为 low(仅 deepseek-v4.1-flash、deepseek-v4-flash-0731 和 deepseek-v4-pro-0813 支持)","also: both default to thinking ON")
    ev(m,"thinking_mode_default","默认开启思考模式","EXACT_ID_OFFICIAL",["S15"],"默认开启思考模式。通过 reasoning_effort","")
ev(D4,"thinking_budget","NOT_SETTABLE","EXACT_ID_OFFICIAL",["S15"],"deepseek-v4.1-flash 1.0 1.0 - - 393,216 -","defaults table: thinking_budget '-' = unsupported")
ev(D3,"thinking_budget","UNKNOWN_not_in_defaults_table","UNKNOWN",["S15"],"共 393,216","family note: v4-series max_tokens+thinking_budget share 393,216 total; -0813 row absent from defaults table")
for m in (D3,D4):
    ev(m,"reasoning_included_in_max_tokens","YES_shared_cap_393216","EXACT_ID_OFFICIAL",[ "S27" if m==D3 else "S26"],"最大思维链长度 393216","card: max output == max CoT == 393216 (S15 note: max_tokens与thinking_budget共用同一上限 for v4 series)")
# ---- search / structured ----
ev(D3,"enable_search_official","YES","EXACT_ID_OFFICIAL",["S04"],"DeepSeek：deepseek-v4-pro、deepseek-v4-pro-0813、deepseek-v4-flash","supported-models list; S27 capability block also 联网搜索 支持")
ev(D4,"enable_search_official","YES","EXACT_ID_OFFICIAL",["S26"],"结构化输出 支持 联网搜索 支持","card Beijing capabilities")
for m in (QF,QM):
    ev(m,"enable_search_official","YES","EXACT_ID_OFFICIAL",["S22" if m==QF else "S21"],"结构化输出 支持 联网搜索 支持","card Beijing capabilities")
ev(GL,"enable_search_official","UNKNOWN_exact_id_not_listed","UNKNOWN",["S23"],"联网搜索 不支持","only glm-5.3 (阿里云直供, different ID) documented 不支持; ZHIPU/GLM-5.3 absent from S04 list and has no card page (S25/S24 shell)")
for m in (QF,QM):
    ev(m,"structured_output","YES 结构化输出(card; json_schema见S05系列行)","EXACT_ID_OFFICIAL",["S21" if m==QM else "S22"],"结构化输出 支持","json_schema support documented for Qwen3.8 series rows on S05 (FAMILY for exact IDs)")
ev(D4,"structured_output","YES","EXACT_ID_OFFICIAL",["S26"],"结构化输出 支持","S15其它功能表(deepseek-v4.1-flash 支持 支持 支持 支持 支持 不支持; 列序含结构化输出)")
ev(D3,"structured_output","YES","EXACT_ID_OFFICIAL",["S27"],"结构化输","snapshot block capabilities table (联网搜索 支持 前缀续写 不支持 上下文缓存 支持)")
ev(GL,"structured_output","UNKNOWN_exact_id_not_documented","UNKNOWN",["S16"],"仅支持 response_format 为 json_object","glm-5.3 (阿里云直供) row is FAMILY for the ZHIPU/GLM-5.3 ID; not in any ZHIPU/ card")
ev(D3,"json_schema_support","UNKNOWN","UNKNOWN",["S05"],"仅支持部分模型","S05 json_schema list: Qwen series only")
ev(D4,"json_schema_support","UNKNOWN","UNKNOWN",["S05"],"仅支持部分模型","")
ev(GL,"reasoning_switch","仅思考模式(billing column); params UNKNOWN","FAMILY_OFFICIAL",["S06"],"ZHIPU/GLM-5.3 仅思考模式 8 元 28 元 无","S06 mode column names the exact ID; S03 thinking_budget row says GLM(阿里云直供)系列 - not ZHIPU/直供; treated FAMILY/UNKNOWN respectively")
ev(QF,"reasoning_effort","UNKNOWN_not_documented_for_this_id","UNKNOWN",[],"","S03 reasoning_effort sentence is qwen3.8-omni context only")
ev(QM,"reasoning_effort","UNKNOWN_not_documented_for_this_id","UNKNOWN",[],"","same")
ev(GL,"context_window_tokens","UNKNOWN_exact","FAMILY_OFFICIAL",["S16"],"上下文长度 1M","glm-5.3 (阿里云直供, 不同ID) 1M; not ZHIPU/GLM-5.3")
ev(GL,"max_input_tokens","UNKNOWN_exact","UNKNOWN",[],"","no ZHIPU/GLM-5.3 card page found (S24/S25 shells)")
ev(GL,"max_output_tokens","UNKNOWN_exact","UNKNOWN",[],"","glm-5.3 card (S23) numbers must NOT be borrowed per prompt section 7")
ev(GL,"max_chain_of_thought_tokens","UNKNOWN_exact","UNKNOWN",[],"","")
ev(GL,"enable_thinking_switch","UNKNOWN_exact","UNKNOWN",[],"","billing S06 column says 仅思考模式 but is not an API-parameter statement")
ev(GL,"reasoning_effort","UNKNOWN_exact","UNKNOWN",[],"","")
# ---- gateway-level (applies to all via compatible-mode) ----
GW=[("max_tokens_field_name","max_tokens (OpenAI-compatible gateway param)","FAMILY_OFFICIAL",["S02"],"max_tokens（可选） integer","collector sends max_tokens"),
    ("stream","YES stream+stream_options.include_usage at gateway","FAMILY_OFFICIAL",["S02"],"stream_options={\"include_usage\": True}","gateway-level; HISTORICAL smoke 2026-09-24 verified per model"),
    ("endpoint","compatible-mode/v1 OpenAI-compatible","FAMILY_OFFICIAL",["S02"],"兼容","gateway-level page")]
for m in EXACT_IDS:
    for f,v,l,srcs,q,n in GW: ev(m,f,v,l,srcs,q,n+" [gateway-level evidence]")
# ---- pricing ----
PR={QF:("0.8","2.7","非思考和思考模式 0<Token≤1M 0.8 元 2.7 元 100 万 Token","输入 0.8 每百万 tokens 输出 2.7 每百万 tokens 输入（缓存命中） 0.1 每百万 tokens","Batch调用: 未列; 上下文缓存折扣YES"),
    QM:("12","36","非思考和思考模式 0<Token≤1M 12 元 36 元 100 万 Token","输入 12 每百万 tokens 输出 36 每百万 tokens 输入（缓存命中） 1.5 每百万 tokens","Batch 半价YES; 缓存YES"),
    D3:("忙9/闲4.5","忙27/闲13.5","忙时 9 元 闲时 4.5 元 忙时 27 元 闲时 13.5 元 100 万 Token","输入（闲时） 4.5 每百万 tokens 输入（忙时） 9 每百万 tokens","缓存YES; 忙=北京时8:00-22:00"),
    D4:("忙2/闲1","忙8/闲4","忙时 2 元 闲时 1 元 忙时 8 元 闲时 4 元 100 万 Token","输入（闲时） 1 每百万 tokens 输入（忙时） 2 每百万 tokens","缓存YES; 忙=北京时8:00-22:00"),
    GL:("8","28","ZHIPU/GLM-5.3 仅思考模式 8 元 28 元 无","仅思考模式","免费额度=无")}
for m,(i,o,q,c,extra) in PR.items():
    sid={"qwen3.8-flash":"S22","qwen3.8-max":"S21","deepseek-v4-pro-0813":"S27","deepseek-v4.1-flash":"S26","ZHIPU/GLM-5.3":"S06"}[m]
    ev(m,"price_input_CNY_per_1M_tokens",i,"EXACT_ID_OFFICIAL",["S06"],q,"card %s: %s | %s"%(sid,c,extra))
    ev(m,"price_output_CNY_per_1M_tokens",o,"EXACT_ID_OFFICIAL",["S06"],q,"输出单价列头: 思维链+回答 (reasoning billed as output); card %s"%sid)
    ev(m,"free_quota",("无" if m==GL else "100万Token/90天"),"EXACT_ID_OFFICIAL",["S06"],q,"")
ev(QM,"billing_reasoning_semantics","思考内容按输出Token计费;思考模式按思考价计费全部输出","FAMILY_OFFICIAL",["S03"],"思考内容按输出 Token 计费。","billing doc column header 思维链+回答 also per-ID on S06")
for m in (QF,D3,D4,GL): ev(m,"billing_reasoning_semantics","思考内容按输出Token计费(系列级说明)","FAMILY_OFFICIAL",["S03"],"思考内容按输出 Token 计费。","")
# ---- UNKNOWN per prompt mandate (kept explicit) ----
for m in EXACT_IDS:
    ev(m,"release_retirement_dates","UNKNOWN_not_found","UNKNOWN",[],"","")
    ev(m,"finish_reason_length_usage_semantics","UNKNOWN_not_documented","UNKNOWN",[],"","collector policy treats length as truncated; G6 counting rule unaffected")
    ev(m,"search_metadata_return_fields","UNKNOWN_pending_G4_probe","UNKNOWN",[],"","S02/S04 document enable_search/search_options but per-ID live metadata shape needs G4")
    ev(m,"temperature_range_per_model","UNKNOWN_exact","FAMILY_OFFICIAL",["S02"],"生成响应的个数","gateway-level only" if False else "not per-ID documented")
# preflight: every cited quote must exist in cited cleaned snapshots
errs=[]
for m,f,v,l,srcs,q,n in E:
    if l in("EXACT_ID_OFFICIAL","FAMILY_OFFICIAL") or q:
        for s in (srcs or ["S01"]):
            if q and q not in CLEAN[s]: errs.append("%s/%s quote not in %s"%(m,f,s))
        if l=="EXACT_ID_OFFICIAL" and m not in CLEAN[srcs[0]]: errs.append("%s/%s EXACT but id not raw-visible in %s"%(m,f,srcs[0]))
        if l=="EXACT_ID_OFFICIAL" and srcs[0] in AUX: errs.append("%s/%s vendor page cannot be exact"%(m,f))
print("preflight %d evidence items, %d failures"%(len(E),len(errs)))
for e in errs: print("  MISS:",e)
assert not errs,"quotes missing from snapshots"
# ---- emit tables ----
def w(path,lines): open(os.path.join(AUD,path),"w",encoding="utf-8").write("\n".join(lines)+"\n")
reg=["source_id\tprovider\ttitle\turl\tretrieval_utc\thttp_status\tcontent_type\tsnapshot_path\tbytes\tsha256\texact_ids_visible\tclaims_supported\tevidence_level_allowed\tnotes"]
claims={}
for m,f,v,l,srcs,q,n in E:
    for s in srcs: claims.setdefault(s,set()).add(l)
for sid in sorted(CLEAN):
    p=os.path.join(RAW,sid+".html"); raw=open(p,encoding="utf-8",errors="ignore")
    ids=[i for i in EXACT_IDS if i in CLEAN[sid]]
    lvl="EXACT_ID_OFFICIAL" if sid.startswith("S") and sid not in AUX and sid not in("S08","S09","S13","S14","S17","S18","S19","S24","S25") else ("AUXILIARY_ONLY" if sid in AUX else "SHELL_PAGE_no_content")
    reg.append("\t".join([sid,"aliyun_bailian" if sid not in AUX else "model_vendor_original",TITLES[sid],URLS[sid],fetch[sid]["retrieval_utc"],fetch[sid]["http_status"],fetch[sid]["content_type"],"raw_sources/%s.html"%sid,str(os.path.getsize(p)),sha(p),";".join(ids) or "-",";".join(sorted(claims.get(sid,[]))) or "none",lvl,"retrieval only; docs pages"]))
w("official_source_registry.tsv",reg)
pmx=["exact_model_id\tfield\tvalue\tevidence_level\tsource_id\tquote_anchor\tnote"]
for m,f,v,l,srcs,q,n in E: pmx.append("\t".join([m,f,v,l,";".join(srcs),q[:120].replace("\t"," "),n]))
w("exact_model_parameter_matrix.tsv",pmx)
pr=["\t".join(["exact_model_id","input_price_CNY_per_1M","output_price_CNY_per_1M","reasoning_price_note","cached_input","batch","search_tool_surcharge","free_quota","currency","unit","price_effective_evidence","busy_idle_windows","region","source_ids"])]
EFF={s:lastmod(s) for s in("S06","S21","S22","S26","S27")}
ROW={"qwen3.8-flash":["0.8","2.7","思考内容按输出Token计费(S03系列说明)","0.1(S22)","未列","UNKNOWN_exact_ID_not_documented","100万Token/90天","CNY","每百万Token","lastModifiedTime "+EFF["S22"],"—","华北2(北京)","S06;S22"],
 "qwen3.8-max":["12","36","同上","1.5(S21)","半价(S06)","UNKNOWN_exact_ID_not_documented","100万Token/90天","CNY","每百万Token","lastModifiedTime "+EFF["S21"],"—","华北2(北京)","S06;S21"],
 "deepseek-v4-pro-0813":["忙9/闲4.5","忙27/闲13.5","列头思维链+回答(S06);v4系列max_tokens与thinking_budget共393216(S15)","闲0.4(S27快照块exact)","未列","UNKNOWN_exact_ID_not_documented","100万Token/90天","CNY","每百万Token","lastModifiedTime "+EFF["S27"],"忙=北京时间8:00-22:00","华北2(北京)","S06;S27;S15"],
 "deepseek-v4.1-flash":["忙2/闲1","忙8/闲4","同上","有(S26卡片;S06忙/闲价exact)","未列","UNKNOWN_exact_ID_not_documented","100万Token/90天","CNY","每百万Token","lastModifiedTime "+EFF["S26"],"忙=北京时间8:00-22:00","华北2(北京)","S06;S26;S15"],
 "ZHIPU/GLM-5.3":["8","28","仅思考模式(S06模式列,exact ID)","UNKNOWN_exact_ID_not_documented","未列","UNKNOWN_exact_ID_not_documented","无","CNY","每百万Token","lastModifiedTime "+EFF["S06"],"—","华北2(北京)","S06"]}
for m in EXACT_IDS: pr.append("\t".join([m]+ROW[m]))
w("pricing_matrix.tsv",pr)
sm=["\t".join(["exact_model_id","official_enable_search","evidence_level","source_ids","actually_effective_verified","note"])]
for m in EXACT_IDS:
    e=[x for x in E if x[0]==m and x[1]=="enable_search_official"][0]
    sm.append("\t".join([m,e[2],e[3],";".join(e[4]),"UNKNOWN_requires_G4_live_probe","支持≠生效;G4对称探针仍必须执行(enable_search由G4决议全开/全关,不写per-model默认)"]))
w("search_support_matrix.tsv",[x if isinstance(x,str) else "\t".join(str(v) for v in x) for x in sm])
so=["\t".join(["exact_model_id","json_object","json_schema","source_ids","note"])]
def g(m,f,ix):
    xs=[x for x in E if x[0]==m and x[1]==f]
    return xs[0] if xs else ("—","—","UNKNOWN","UNKNOWN",[],"","")
for m in EXACT_IDS:
    j=g(m,"structured_output",0); k=g(m,"json_schema_support",0)
    so.append("\t".join([m,(str(j[2]).split(" (")[0] if j[2]!="UNKNOWN_exact_id_not_documented" else "UNKNOWN"),str(k[2]),";".join(j[4]+k[4]),"json_object需提示词含JSON(S05);思考模式下结构化可能失效(S05说明)"]))
w("structured_output_matrix.tsv",[x if isinstance(x,str) else "\t".join(str(v) for v in x) for x in so])
dc=["\t".join(["item","files_compared","finding","status","evidence","resolution_proposed"])]
dc+= [
["deepseek_exact_ids_status_split","parameter_contract.tsv vs models.collection_v2.json","TSV says UNKNOWN for enable_thinking/reasoning_effort while JSON says CONFIRMED_EXACT_ID; S15 now provides exact-ID quotes -> JSON claim substantiated, TSV stale","CONFIG_UNDERSPECIFIED","S15","update TSV via proposed_parameter_contract.tsv"],
["v4_pro_0813_max_tokens","JSON claims FAMILY_ROW_ONLY_393216","S27 snapshot block gives -0813 its OWN exact 393216 limits incl CoT -> upgrade family->exact","DOC_CONFLICT_resolved","S27","proposed: max_supported_output=393216 EXACT; tier2=65536 now EXACT-supported(65536<=393216)"],
["v4.1_flash_max_tokens","JSON claims CONFIRMED_EXACT_ROW_max_tokens_393216","S15 defaults row + S26 card exact","CONFIG_CORRECT","S15;S26","keep; tier2=65536 <= exact cap OK"],
["v4.1_flash_thinking_budget_NOT_SETTABLE","JSON '-'","S15 defaults table row '-' column exact","CONFIG_CORRECT","S15","keep"],
["qwen tier1 16384","actual_request_parameters vs S21/S22 exact max_output 131072","tier1 within cap; but reasoning/CoT counted-into-max_tokens semantics UNKNOWN; 2026-09-24 smoke completion>max_tokens observed (HISTORICAL)","CONFIG_CORRECT_pending_semantics","S21;S22","tier2 candidate 65536/131072 EXACT-supported but teacher/tier-policy decision"],
["qwen tier2=null","JSON null","official exact caps 131072 exist -> null is conservative-legal, not wrong; tier_policy requires doc-confirmed higher cap which NOW exists","CONFIG_UNDERSPECIFIED","S21;S22","proposed patch offers tier2=65536 as candidate (NOT auto-applied)"],
["GLM tier1 16384 / tier2 null","JSON vs ZHIPU/GLM-5.3 evidence","NO exact-ID cap page; only glm-5.3 (different ID) 131072","UNKNOWN_BLOCKER","S23(neg);S24/S25 shells","keep null; G4/G5 observation may upgrade; do not borrow glm-5.3 numbers"],
["tier1_forbidden_parameters","JSON list enable_thinking/reasoning_effort/thinking_budget/response_format","docs prove these params EXIST for our IDs; forbidding them is an experimental-design rule (equal conditions, teacher plan), NOT a doc claim","DESIGN_RULE_NOT_DOC_CLAIM_config_correct","S03;S15","keep rule; label it explicitly as design choice in contract"],
["enable_search source of truth","JSON note vs benchmark_runtime_policy.json web_policy true","runtime_policy sets enable_search_requested=true globally; collector overrides via G4 decision; per-model config keeps null","CONFIG_CORRECT","S04;policy","no change; G4 decides ALL_PASS/ANY_NOT_PASS"],
["price UNKNOWN -> G7","old TSV/JSON had no prices; G7 template placeholders","S06/S21/S22/S26/S27 give exact base input/output CNY/1M for ALL five IDs; cached/search-addon prices are NOT all exact (ZHIPU/GLM-5.3 cached must not borrow glm-5.3 S23)","CONFIG_UNDERSPECIFIED_base_resolved","S06;S21;S22;S26;S27","G7 base token budget computable; addon costs + DeepSeek busy/idle windows need conservative bounds"],
["reasoning eats visible content","actual tier1 32768 for deepseek","v4 series DEFAULT thinking ON + max_tokens/thinking_budget share cap; 2026-09-24 smoke: finish=length completion 16384 all-reasoning 0-visible (HISTORICAL)","UNKNOWN_BLOCKER","S15;historical","G6 truncation threshold must count visible-content empties; engineering fix (thinking off) needs teacher signoff, forbidden in tier1"],
]
w("current_config_discrepancies.tsv",[d if isinstance(d,str) else "\t".join(str(x) for x in d) for d in dc])
pp=["exact_model_id","field","proposed_value","evidence_level","source_ids","changed_vs_current","note"]
def best(m,f):
    xs=[x for x in E if x[0]==m and x[1]==f and x[3]=="EXACT_ID_OFFICIAL"]
    return xs[0] if xs else None
for m in EXACT_IDS:
    cur={"max_supported_output":{"qwen3.8-flash":"UNKNOWN","qwen3.8-max":"UNKNOWN","deepseek-v4-pro-0813":"UNKNOWN_historical_hint_393216","deepseek-v4.1-flash":"UNKNOWN_historical_hint_393216","ZHIPU/GLM-5.3":"UNKNOWN"},
         "reasoning_switch_parameter":{"qwen3.8-flash":"UNKNOWN","qwen3.8-max":"UNKNOWN","deepseek-v4-pro-0813":"UNKNOWN","deepseek-v4.1-flash":"UNKNOWN","ZHIPU/GLM-5.3":"UNKNOWN"},
         "reasoning_budget_parameter":{"qwen3.8-flash":"UNKNOWN","qwen3.8-max":"UNKNOWN","deepseek-v4-pro-0813":"UNKNOWN","deepseek-v4.1-flash":"UNKNOWN","ZHIPU/GLM-5.3":"UNKNOWN"},
         "structured_output_support":{"qwen3.8-flash":"UNKNOWN","qwen3.8-max":"UNKNOWN","deepseek-v4-pro-0813":"UNKNOWN","deepseek-v4.1-flash":"UNKNOWN","ZHIPU/GLM-5.3":"UNKNOWN"}}
    for field,src in (("max_supported_output","max_output_tokens"),("reasoning_switch_parameter","enable_thinking_switch"),("reasoning_budget_parameter","thinking_budget"),("structured_output_support","structured_output")):
        x=best(m,src)
        if x: pp.append("\t".join([m,field,x[2].split(" (")[0],x[3],";".join(x[4]),"YES" if cur[field][m].startswith("UNKNOWN") else "no",""]))
        else: pp.append("\t".join([m,field,cur[field][m],"UNKNOWN","",-1 and "" or "no","kept UNKNOWN - no exact-ID evidence; see UNKNOWN_BLOCKERS"]))
w("proposed_parameter_contract.tsv",pp)
patch={"status":"PROPOSED_NOT_APPLIED","apply_this_round":False,"runtime_config_modified":False,
 "allowed_evidence":"EXACT_ID_OFFICIAL only",
 "changes":[{"file":"config/models.collection_v2.json","path":"models[m3].output_budget_tiers.tier2_max_tokens","current":65536,"proposed":65536,"keep":True,"reason":"S27 exact-ID snapshot limits 393216 (>=65536)","evidence":["S27"]},
  {"file":"config/models.collection_v2.json","path":"models[m4].output_budget_tiers.tier2_max_tokens","current":65536,"proposed":65536,"keep":True,"reason":"S26 exact card 393216","evidence":["S26"]},
  {"file":"config/models.collection_v2.json","path":"models[m3].parameter_contract_evidence_status","current":"...FAMILY_ROW_ONLY...","proposed":"CONFIRMED_EXACT_ID_max_output_393216_S27; enable_thinking+reasoning_effort_low_S15; structured_S27; search_S04","reason":"family claim upgradable to exact via S27","evidence":["S27","S15","S04"]},
  {"file":"config/models.collection_v2.json","path":"models[m4].parameter_contract_evidence_status","current":"CONFIRMED_EXACT_ID...","proposed":"CONFIRMED_EXACT_ID_max_393216_S15/S26; thinking_budget_NOT_SETTABLE_S15; reasoning_effort_low_S15; search_S26","evidence":["S15","S26"]},
  {"file":"config/models.collection_v2.json","path":"models[m1/m2].parameter_contract_evidence_status","current":"UNKNOWN_NO_OFFICIAL_EVIDENCE...","proposed":"EXACT_ID_official_cards: max_out_131072_ctx_1e6_CoT_262144 (S21/S22); search/structured official-YES","evidence":["S21","S22"]},
  {"file":"config/models.collection_v2.json","path":"models[m1/m2].output_budget_tiers.tier2_max_tokens","current":None,"proposed":"CANDIDATE_65536_pending_teacher","reason":"exact cap 131072 permits tier2; enabling changes dispatch budget -> teacher decision, NOT auto-applied","evidence":["S21","S22"]}],
 "NOT_changed":[{"path":"enable_search (all models)","reason":"must remain null -> G4 symmetry decision (prompt section 6 rule)"},
  {"path":"tier1_forbidden_parameters","reason":"design rule, not a doc claim"},
  {"path":"m5 ZHIPU/GLM-5.3 budget/params","reason":"no exact-ID functional evidence; UNKNOWN preserved"}]}
json.dump(patch,open(os.path.join(AUD,"proposed_models_config_patch.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True); open(os.path.join(AUD,"proposed_models_config_patch.json"),"a").write("\n")
ub=["\t".join(["blocker_id","model_scope","field","why_still_UNKNOWN","blocks","unblock_path"])]
ub+= [["U1",GL,"max_input/max_output/context/thinking params/enable_search/structured_output","no card page found for ZHIPU/GLM-5.3 (S24/S25 shell); glm-5.3(阿里云直供) numbers must not be borrowed","G6 truncation sizing, tier2, G7 search-cost estimate","G4 live probe evidence or future official card page; teacher decision"],
 ["U2","qwen3.8-flash/max","whether reasoning/CoT counts against max_tokens","card lists CoT 262144 separately from output 131072; 2026-09-24 smoke completion>max_tokens (HISTORICAL)","G6 truncation semantics","G4/G5 observed usage vs max_tokens"],
 ["U3",D3,"thinking_budget settable value/cap","absent from S15 defaults table; v4-series shared note is family-level","fine truncation control","G5 observation; do not set (tier1 forbids it anyway)"],
 ["U4","all five","finish_reason=length usage semantics (usage.completion_tokens incl reasoning?)","not documented per-ID","G6 counting rule wording","collector treats length=truncated regardless; note kept"],
 ["U5","all five","search metadata return fields / effectiveness","支持≠生效","G4 decision quality","G4 metadata probe (unchanged)"],
 ["U6","all five","release/retirement dates","not on captured pages","risk of mid-run deprecation","re-check at G7 bind time"],
 ["U7","deepseek-v4-*","busy/idle price windows vs run wall-clock","defined 8:00-22:00 but run schedule unknown","G7 cost bound","G7 budget must price worst-case busy-hour or record both"],
 ["U8","all five","json_object prompt-must-contain-JSON caveat in thinking mode","S05 warning; our schema prompt does contain JSON wording but must be verified at G2 signoff","G3/G6 invalid-json rate","verify prompt text includes 'JSON' token"]]
ub.append(["\t".join(x) if isinstance(x,list) else x for x in ["U9",GL,"cached_input_price/search_tool_surcharge","S23 card is glm-5.3 (阿里云直供, different model_id); no ZHIPU/GLM-5.3 cached/addon price documented (correction 37a34cce)"]+["G7 addon-cost bound","G4/G5 receipt usage fields or future official exact-ID pricing"]])
w("UNKNOWN_BLOCKERS.tsv",[x if isinstance(x,str) else "\t".join(str(v) for v in x) for x in ub])
snap={os.path.basename(f):sha(os.path.join(CFGDIR,f)) for f in ("parameter_contract.tsv","models.collection_v2.json","models.template.json","benchmark_runtime_policy.json")}
json.dump({"note":"frozen at audit build; validator proves runtime configs untouched","shas":snap},open(os.path.join(AUD,"config_snapshot_shas.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True); open(os.path.join(AUD,"config_snapshot_shas.json"),"a").write("\n")
print("audit tables emitted: registry=%d evidence=%d blockers=%d"%(len(reg)-1,len(E),len(ub)-1))
