# model_parameter_doc_audit

PUBLIC_DOCUMENTATION_AUDIT_ONLY（2026-09-28）：五精确模型ID的官方参数、搜索支持与价格证据审计。
商业模型API调用=0；API key读取=0；运行配置未修改（见 config_snapshot_shas.json 与 validator runtime_config_untouched）。
证据等级 EXACT_ID_OFFICIAL / FAMILY_OFFICIAL / HISTORICAL_OBSERVATION / UNKNOWN 不可互越；
每条非UNKNOWN结论的引文锚点在生成时与复核时均必须在对应 raw_sources 快照（同规则 clean）中逐字命中。
proposed_* 仅为提案，未应用；UNKNOWN 保持 UNKNOWN（见 UNKNOWN_BLOCKERS.tsv）。
状态：PUBLIC_DOC_AUDIT_COMPLETE | next_stage_allowed=false | api_calls=0
修正记录：37a34cce（2026-09-28）——ZHIPU/GLM-5.3 缓存价由借自 glm-5.3(S23) 降为 UNKNOWN_exact_ID_not_documented；新增 search/tool 附加费列（全 UNKNOWN）与 U9 阻塞项；validator 增加跨ID价格借用拦截与基础价/全字段范围检查（glm_cache_borrow mutation 检出）。
