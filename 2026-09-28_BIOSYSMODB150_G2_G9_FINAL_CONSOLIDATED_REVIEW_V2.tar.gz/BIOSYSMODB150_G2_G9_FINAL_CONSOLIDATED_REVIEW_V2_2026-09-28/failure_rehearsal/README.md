# failure_rehearsal

G4-G6 failure/retry/resume/archive rehearsal driving the collector's REAL logic via a scripted SYNTHETIC transport (16 scenario rows, 17 checks incl. caps and no-key-written). Every artifact under synthetic_runs/ is SYNTHETIC_OFFLINE_FIXTURE. Snapshot normalization: artifact paths basenamed and start/end wall-clock UTC replaced with a marker (durations and answer bytes untouched); raw collector output lived in ephemeral temp dirs. Recovery semantics proven: transport-only retry with stable idempotency key/body hash; content errors (schema INVALID, non-JSON, length truncation, empty body) saved once, never re-questioned; same-key restart and post-write crash resume with zero rebill; phase cap and 80-call envelope refusals.

Status: OFFLINE_ONLY_NOT_AUTHORIZED | next_stage_allowed=false | api_calls=0
