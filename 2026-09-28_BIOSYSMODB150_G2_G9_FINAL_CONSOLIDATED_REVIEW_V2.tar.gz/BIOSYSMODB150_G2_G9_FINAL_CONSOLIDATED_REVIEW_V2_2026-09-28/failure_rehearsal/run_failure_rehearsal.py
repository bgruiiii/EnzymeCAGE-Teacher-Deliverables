#!/usr/bin/env python3
"""run_failure_rehearsal.py -- G4-G6 failure/retry/resume/archive rehearsal on a
scripted SYNTHETIC transport. Drives the collector's REAL dispatch / idempotency /
retry / resume / archive logic (imported read-only; never modified). Every payload
is SYNTHETIC_OFFLINE_FIXTURE. Zero real network, zero API-key read, zero billable
dispatch. The fixture valid_answer/TRAITS below is a standalone synthetic copy
(first structurally validated offline in offline_readiness/dryrun.py) so the
rehearsal never consumes a real model answer."""
import importlib.util, json, os, shutil, sys, tempfile
from collections import Counter
HERE=os.path.dirname(os.path.abspath(__file__)); STAGE=os.path.abspath(os.path.join(HERE,os.pardir))
ROOT=os.path.abspath(os.path.join(STAGE,os.pardir)); COLLECTOR=os.path.join(ROOT,"24_BIOSYSMODB150_FIVE_LLM_API_ORCHESTRATOR_2026-09-24")
spec=importlib.util.spec_from_file_location("cv2",os.path.join(COLLECTOR,"scripts","run_collection_v2.py"))
cv2=importlib.util.module_from_spec(spec); sys.modules["cv2"]=cv2; spec.loader.exec_module(cv2)
FIX="SYNTHETIC_OFFLINE_FIXTURE"; NOT_A_KEY="SYNTHETIC_NOT_A_KEY"

# ---- synthetic fixtures (standalone copy of offline_readiness/dryrun.py fixture) ----
def _trait(v): return {"value":v,"raw_text":None,"evidence_id":"EVID_001","confidence":"medium"}
TRAITS={"F1_oxygen_tolerance":_trait(None),
 "F2_temperature":_trait({"minimum_c":None,"optimum_c":28,"maximum_c":None,"preference":"mesophilic"}),
 "F3_pH":_trait({"minimum":None,"optimum":7.0,"maximum":None}),
 "F4_salinity":_trait({"minimum":None,"optimum":None,"maximum":None,"unit":"% NaCl (w/v)","category":None}),
 "F5_culture_collection":_trait({"collection":"DSM","accession":"1111"}),
 "F6_respiration_electron_acceptor":_trait({"respiration_mode":None,"terminal_electron_acceptor":None}),
 "F7_carbon_substrate_utilization":_trait(None),"F8_degradation_capacity_broad":_trait(None),
 "F9_enzyme_activity":_trait(None),"F10_motility":_trait(None),"F11_cell_morphology":_trait(None),
 "F12_gram_cell_envelope":_trait(None),"F13_sporulation":_trait(None),
 "F14_genome_basic":_trait({"genome_accession":"GCA_000000000.1","genome_size_bp":None,"gc_percent":None}),
 "F15_habitat_generalism":_trait(None)}
def valid_answer(case_id, extra=False):
    a={"schema_version":"biodegradation_answer_v2","case_id":case_id,"pollutant_name_zh":"合成测试",
     "pollutant_name_en":"SYNTHETIC_TEST","route_scope":{"oxygen_condition":"aerobic",
     "chosen_route_name":"synthetic route","is_single_continuous_route":True,"notes":None},"route_summary":None,
     "steps":[{"step_id":"S1","order":1,"predecessor_step_ids":[],"branch_id":None,
       "substrates":[{"name":"synth-substrate","smiles":"CCO","role":"main"}],
       "products":[{"name":"synth-product","smiles":"CC=O","role":"main"}],
       "reaction_type":None,
       "enzyme":{"name":"synth-enzyme","ec_number":"1.1.1.1","gene_or_protein":None,"evidence_id":"EVID_001","confidence":"medium"},
       "microorganism":{"organism_name":"Syntheticus testus","strain":"T1","ncbi_taxid":"999999999","organism_profile_id":"ORG_001","evidence_id":"EVID_001","confidence":"medium"},
       "reaction_evidence_id":"EVID_001","trait_evidence_id":None,"uncertainty":None}],
     "organism_profiles":[{"organism_profile_id":"ORG_001","organism_name":"Syntheticus testus","strain":"T1","ncbi_taxid":"999999999","traits":TRAITS}],
     "complete_pathway_organism_profile_id":None,"central_metabolism_entry":{"products":[],"explanation":None},
     "downstream_continuation":[],"alternative_branches":[],
     "evidence_registry":[{"evidence_id":"EVID_001","source_type":"DATABASE_DIRECT","database":"SYNTHETIC","record_id":"BSY-r00000","locator":"synthetic","claim_scope":["S1.enzyme"],"confidence":"medium"}],
     "uncertainties":[]}
    if extra: a["steps"][0][FIX+"_extra_field"]="warning-only; original text preserved"
    return a
VALID=json.dumps(valid_answer("BIOPATH150_001"),ensure_ascii=False)
VALIDX=json.dumps(valid_answer("BIOPATH150_001",extra=True),ensure_ascii=False)
INVJSON=json.dumps({"schema_version":"biodegradation_answer_v2","case_id":"NOPE"},ensure_ascii=False)  # json-valid, schema-invalid

# ---- scripted transport (list scripts per model; every entry one attempt) ----
def chunk(content=None,reasoning=None,finish=None,usage=None):
    d={}
    if reasoning is not None: d["reasoning_content"]=reasoning
    if content is not None: d["content"]=content
    c={"index":0,"delta":d}
    if finish is not None: c["finish_reason"]=finish
    o={"choices":[c],"object":"chat.completion.chunk"}
    if usage is not None: o["usage"]=usage
    return "data: "+json.dumps(o,ensure_ascii=False)
def ok_sse(payload): return [chunk(content=payload),chunk(finish="stop"),"data: [DONE]"]
class Stream:
    def __init__(self,lines,status=200,headers=None,err=""):
        self._l=lines; self.status_code=status; self.headers=headers or {}; self._err=err
    def iter_lines(self):
        for x in self._l:
            if isinstance(x,tuple) and x[0]=="__RAISE__": raise cv2.TransportError(x[1],x[2] if len(x)>2 else "NETWORK")
            yield x.encode("utf-8")
    def read_text(self,limit=2000): return self._err[:limit]
    def close(self): pass
class T:
    """scripted per-model transport; scripts MUST be lists (one dict per attempt)."""
    def __init__(self,script): self.script=script; self.calls=Counter()
    def open_stream(self,endpoint,body,timeout,headers):
        m=body["model"]; self.calls[m]+=1
        seq=self.script.get(m) or self.script.get("*")
        assert isinstance(seq,list), "scenario script for %s must be a list of attempts" % m
        i=self.calls[m]-1; s=seq[min(i,len(seq)-1)]
        return Stream(s["lines"],status=s.get("status",200),headers=s.get("headers",{}),err=s.get("err",""))

MODEL="qwen3.8-flash"
def new_ctx(name,run_dir,live,phase="smoke",max_new=100,transport=None,resume=False,caps=None):
    cpath=os.path.join(run_dir,"cases.jsonl")
    with open(cpath,"w",encoding="utf-8") as fh:
        fh.write(json.dumps({"case_id":"BIOPATH150_001","pollutant_name_zh":"x","pollutant_name_en":"SYNTHETIC_TEST",
                             "oxygen_condition":"aerobic","route_scope":"synthetic"})+"\n")
    lpath=os.path.join(run_dir,"limits.json")
    caps=caps or {"G4_search":15,"G5_smoke":15,"G6_pilot":50}
    lv=dict(live); lv.update({"authorized_new_api_requests":max_new,"phase_api_request_caps":caps,"phase_api_total_cap":80})
    json.dump(lv,open(lpath,"w"),sort_keys=True)
    return cv2.RunContext(root=COLLECTOR,run_id=name,output_root=os.path.join(run_dir,"run"),cases_path=cpath,
        limits_path=lpath,transport=transport,api_key=NOT_A_KEY,dry_run=False,phase=phase,experiment_version="reh20260928",
        max_new_requests=max_new,resume=resume,search_decision={"decision":"ALL_PASS"})
LIVE={"live_disabled":False,"max_transport_retries":2}
def snapshot(name,mt,wr,run_dir):
    d=os.path.join(HERE,"synthetic_runs",name); shutil.rmtree(d,ignore_errors=True); os.makedirs(d)
    sel=wr["selected"][0] if wr.get("selected") else {}
    srec=dict(sel); srec["artifact_paths"]={k:os.path.basename(str(v)) for k,v in (sel.get("artifact_paths") or {}).items()}
    MEASURED=("start_utc","end_utc","first_event_seconds","first_reasoning_seconds","first_visible_content_seconds","wall_seconds")
    if srec.get("timing"):
        tim=dict(srec["timing"]); removed={k:tim.pop(k) for k in list(tim) if k in MEASURED}
        tim["normalization_note"]="measured wall-clock fields removed (vary per run); config fields kept verbatim: %s"%sorted(tim.keys())
        srec["timing"]=tim; srec["timing_measured_values_at_build"]=None
    srec["snapshot_normalization"]="artifact_paths->basenames; measured timing removed for double-run stability; answer_text and all status fields verbatim"
    json.dump({"fixture_label":FIX,"record":srec},open(os.path.join(d,"selected_record.json"),"w"),ensure_ascii=False,indent=1,sort_keys=True)
    att=[{k:a.get(k) for k in ("attempt_id","model_id","transport_status","http_status","stream_status","finish_reason",
         "json_parse_status","schema_status","error","idempotency_key","request_body_sha256")} for a in wr.get("attempts",[])]
    json.dump({"fixture_label":FIX,"attempts":att},open(os.path.join(d,"attempts_summary.json"),"w"),ensure_ascii=False,indent=1,sort_keys=True)
    idem={a.get("idempotency_key") for a in wr.get("attempts",[])}
    sid=sel.get("idempotency_key")
    if sid: idem.add(sid)
    bsh={a.get("request_body_sha256") for a in wr.get("attempts",[])}
    sb=sel.get("request_body_sha256")
    if sb: bsh.add(sb)
    m=[a for a in att if a.get("idempotency_key")==sid] if sid else att
    facts={"fixture_label":FIX,"calls":mt.calls[MODEL],"n_attempts":len(wr.get("attempts",[])),"model_attempts":len(m),
        "model_idem_keys":sorted({a.get("idempotency_key") for a in m}|({sid} if sid else set())),
        "model_body_shas":sorted({a.get("request_body_sha256") for a in m}|({sb} if sb else set())),
        "model_http_statuses":sorted({str(a.get("transport_status")) for a in m}),
        "json_parse_status":sel.get("json_parse_status"),"schema_status":sel.get("schema_status"),
        "stream_status":sel.get("stream_status"),"finish_reason":sel.get("finish_reason"),
        "transport_status":sel.get("transport_status"),"collection_status":sel.get("collection_status"),
        "visible":sel.get("visible_answer_present"),"reasoning_present":sel.get("reasoning_text_present"),
        "answer_text_len":len(sel.get("answer_text") or ""),"answer_text_sha256":sel.get("answer_text_sha256"),
        "idempotency_keys":sorted(idem),
        "body_shas":sorted(bsh),
        "val_err":sel.get("validation_errors_total"),"val_warn":sel.get("validation_warnings_total"),
        "answer_text_head":(sel.get("answer_text") or "")[:24]}
    json.dump(facts,open(os.path.join(d,"facts.json"),"w"),ensure_ascii=False,indent=1,sort_keys=True)
    return facts
RUNS=[]  # temp dirs kept for key-leak scan, cleaned at end
def run(name,script,**kw):
    tmp=tempfile.mkdtemp(prefix="reh_"); RUNS.append(tmp)
    mt=T(script); ctx=new_ctx(name,tmp,dict(LIVE),transport=mt,**kw)
    res=cv2.run_all(ctx); tasks=cv2.build_tasks(ctx); wr=cv2.write_results_and_normalized(ctx,tasks,res)
    return mt,wr,snapshot(name,mt,wr,tmp),tmp
out={}; F={}
def check(label,cond): out[label]=bool(cond)

# 1. HTTP 200 normal SSE, schema-VALID answer
mt,wr,f,_=run("01_normal_200",{"*":[{"lines":ok_sse(VALID)}]})
F["01_normal_200"]=f
check("normal_200", f["json_parse_status"]=="VALID" and f["schema_status"]=="VALID" and f["stream_status"]=="COMPLETE"
      and f["finish_reason"]=="stop" and f["collection_status"]=="RESPONSE_CAPTURED" and f["calls"]==1 and f["val_err"]==0)
# 2. HTTP 429 then 200: transport retry, same idempotency key, raw error saved
mt,wr,f,_=run("02_429_then_ok",{"*":[{"status":429,"headers":{"Retry-After":"0"},"lines":[],"err":"rate limited"},
                                      {"lines":ok_sse(VALID)}]})
F["02_429_then_ok"]=f
check("429_transport_retry", f["calls"]==2 and f["json_parse_status"]=="VALID" and f["schema_status"]=="VALID"
      and f["model_attempts"]==2 and f["model_http_statuses"]==["HTTP_200","HTTP_ERROR"]
      and len(f["model_idem_keys"])==1 and len(f["model_body_shas"])==1)
# 3. HTTP 503 then 200
mt,wr,f,_=run("03_503_then_ok",{"*":[{"status":503,"lines":[],"err":"unavailable"},{"lines":ok_sse(VALID)}]})
F["03_503_then_ok"]=f
check("5xx_transport_retry", f["calls"]==2 and f["json_parse_status"]=="VALID" and f["model_attempts"]==2 and len(f["model_idem_keys"])==1)
# 4. connect timeout: capped transport retries, no content re-question loop
mt,wr,f,_=run("04_connect_timeout",{"*":[{"lines":[("__RAISE__","connect timeout","CONNECT")]}]})
F["04_connect_timeout"]=f
check("connect_timeout_capped", f["calls"]==3 and f["model_attempts"]==3 and f["collection_status"]=="NO_RESPONSE"
      and f["stream_status"]=="INTERRUPTED" and f["answer_text_len"]==0)  # capped at 1+2 retries; raw raise text kept in attempts_summary
# 5. SSE half-interrupt (no finish/[DONE])
mt,wr,f,_=run("05_half_stream",{"*":[{"lines":[chunk(content=VALID[:10])]}]})
F["05_half_stream"]=f
check("half_stream_not_complete", f["stream_status"]!="COMPLETE" and f["calls"]>=1)
# 6. reasoning exhausted, empty visible content, finish_reason=length -> content truncation saved, NOT retried forever
mt,wr,f,_=run("06_reasoning_length",{"*":[{"lines":[chunk(reasoning="thinking hard"*8),chunk(finish="length"),"data: [DONE]"]}]})
F["06_reasoning_length"]=f
check("reasoning_length_no_requestion", f["finish_reason"]=="length" and f["visible"]==False
      and f["json_parse_status"]=="EMPTY" and f["reasoning_present"]==True and f["calls"]==1)
# 7. legal JSON + Schema VALID with warning-only extra field: original preserved, no error flip
mt,wr,f,_=run("07_schema_valid_with_warning",{"*":[{"lines":ok_sse(VALIDX)}]})
F["07_schema_valid_with_warning"]=f
check("extra_field_warning_only", f["schema_status"]=="VALID" and (f["val_warn"] or 0)>=1 and f["val_err"]==0 and f["calls"]==1)
# 8. legal JSON + Schema INVALID: saved verbatim, NO re-question (content error is not a transport error)
mt,wr,f,_=run("08_schema_invalid",{"*":[{"lines":ok_sse(INVJSON)}]})
F["08_schema_invalid"]=f
check("schema_invalid_saved_no_requestion", f["json_parse_status"]=="VALID" and f["schema_status"]=="INVALID"
      and f["calls"]==1 and f["model_attempts"]==1 and f["answer_text_head"]=='{"schema_version": "biod')  # canonical re-dump; raw bytes preserved in raw_stream artifact
# 9. non-JSON text: saved, schema NOT_CHECKED, no re-question
mt,wr,f,_=run("09_non_json",{"*":[{"lines":ok_sse("I think the pathway goes through acetaldehyde")}]})
F["09_non_json"]=f
check("non_json_saved", f["json_parse_status"]=="INVALID" and f["schema_status"]=="NOT_CHECKED" and f["calls"]==1)
# 10. empty body
mt,wr,f,_=run("10_empty_body",{"*":[{"lines":[chunk(content="   "),chunk(finish="stop"),"data: [DONE]"]}]})
F["10_empty_body"]=f
check("empty_body_saved", f["json_parse_status"]=="EMPTY" and f["schema_status"]=="NOT_CHECKED")
# 11. duplicate chunks: raw concatenated answer kept verbatim (parser must not silently dedupe content)
mt,wr,f,_=run("11_duplicate_chunks",{"*":[{"lines":[chunk(content=VALID),chunk(content=VALID),chunk(finish="stop"),"data: [DONE]"]}]})
F["11_duplicate_chunks"]=f
check("duplicate_chunk_raw_kept", f["answer_text_len"]==2*len(VALID) and f["calls"]==1)
# 12. same idempotency key restart => zero new transport calls, identical archived answer
tmp12=tempfile.mkdtemp(prefix="reh_"); RUNS.append(tmp12)
mt1=T({"*":[{"lines":ok_sse(VALID)}]}); c1=new_ctx("12_idem",tmp12,dict(LIVE),transport=mt1)
r1=cv2.run_all(c1); w1=cv2.write_results_and_normalized(c1,cv2.build_tasks(c1),r1)
mt2=T({"*":[{"lines":ok_sse(VALID)}]}); c2=new_ctx("12_idem",tmp12,dict(LIVE),transport=mt2,resume=True)
r2=cv2.run_all(c2); w2=cv2.write_results_and_normalized(c2,cv2.build_tasks(c2),r2)
f12=snapshot("12_idempotent_restart",mt2,w2,tmp12); F["12_idempotent_restart"]=f12
check("idempotent_restart_no_rebill", mt2.calls[MODEL]==0 and f12["answer_text_sha256"]==w1["selected"][0].get("answer_text_sha256"))
# 13. terminal-then-resume: a finished (terminal) attempt is never re-dispatched
check("terminal_then_resume_no_resend", mt2.calls[MODEL]==0 and f12["json_parse_status"]=="VALID")
# 14. crash after raw-attempt write, before final summary: resume rebuilds summary, no rebill
tmp14=tempfile.mkdtemp(prefix="reh_"); RUNS.append(tmp14)
mt14=T({"*":[{"lines":ok_sse(VALID)}]}); c14=new_ctx("14_after_write",tmp14,dict(LIVE),transport=mt14)
r14=cv2.run_all(c14)   # attempts written; summary intentionally not written (断在写盘后、汇总前)
mt14b=T({"*":[{"lines":ok_sse(VALID)}]}); c14b=new_ctx("14_after_write",tmp14,dict(LIVE),transport=mt14b,resume=True)
r14b=cv2.run_all(c14b); w14b=cv2.write_results_and_normalized(c14b,cv2.build_tasks(c14b),r14b)
f14=snapshot("14_resume_after_write",mt14b,w14b,tmp14); F["14_resume_after_write"]=f14
check("resume_after_write_no_rebill", mt14b.calls[MODEL]==0 and f14["json_parse_status"]=="VALID")
# 15. phase cap: smoke authorized 20 > G5_smoke cap 15 -> refused before any call
c15=new_ctx("15_cap",tempfile.mkdtemp(prefix="rehcap_"),dict(LIVE),phase="smoke",max_new=20,caps={"G4_search":15,"G5_smoke":15,"G6_pilot":50})
av15=cv2.evaluate_live_authorization(c15)
check("phase_cap_enforced", any(x["code"]=="AUTHORIZED_EXCEEDS_PHASE_CAP" for x in av15["refusals"]))
# 16. total 80-call envelope: authorized 90, per-phase ok -> envelope refusal
c16=new_ctx("16_envelope",tempfile.mkdtemp(prefix="rehcap_"),dict(LIVE),phase="pilot",max_new=90,caps={"G6_pilot":100})
av16=cv2.evaluate_live_authorization(c16)
check("total_envelope_enforced", any(x["code"]=="AUTHORIZED_EXCEEDS_TOTAL_ENVELOPE" for x in av16["refusals"]))
# cross-cutting: no key material ever written to disk
leak=0
for d in RUNS:
    for dp,_,fns in os.walk(d):
        for fn in fns:
            try:
                if NOT_A_KEY in open(os.path.join(dp,fn),"rb").read().decode("utf-8","ignore"): leak+=1
            except Exception: pass
check("no_key_written_to_disk", leak==0)

passed=sum(1 for v in out.values() if v)
report={"fixture_label":FIX,"generated_by":"run_failure_rehearsal.py","api_calls":0,
        "real_dispatch_attempts":0,"checks_total":len(out),"checks_passed":passed,
        "results":out,"scenario_facts":F}
json.dump(report,open(os.path.join(HERE,"recovery_report.json"),"w"),ensure_ascii=False,indent=2,sort_keys=True)
open(os.path.join(HERE,"recovery_report.json"),"a").write("\n")
for d in RUNS: shutil.rmtree(d,ignore_errors=True)
print("failure rehearsal checks %d/%d"%(passed,len(out)))
for k,v in out.items(): print(("OK  " if v else "FAIL ")+k)
sys.exit(0 if passed==len(out) else 1)
