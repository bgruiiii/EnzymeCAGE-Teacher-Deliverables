#!/usr/bin/env python3
"""validate_failure_rehearsal.py -- independent validator for the G4-G6 failure
rehearsal. Reads only persisted artifacts (matrix, recovery_report.json,
synthetic_runs/); never imports the rehearsal runner. Includes adversarial
self-test mutations: the validator MUST fail on doctored evidence, so a clean
run cannot be produced by a PASS-hardcoded checker. Zero API access."""
import json, os, shutil, subprocess, sys, tempfile
HERE=os.path.dirname(os.path.abspath(__file__))
SENTINEL="SYNTHETIC_NOT_A_KEY"
CLASSES_14={"HTTP 200 normal SSE","HTTP 429","HTTP 500/503","connect timeout","SSE half interrupt",
 "reasoning exhausted, visible empty, finish=length","legal JSON + Schema VALID","legal JSON + Schema INVALID",
 "non-JSON text","empty body","duplicate chunk","same idempotency-key restart","resume after terminal state",
 "crash after attempt write, before summary"}
def load_matrix(d):
    rows=[l.rstrip("\n").split("\t") for l in open(os.path.join(d,"failure_matrix.tsv"),encoding="utf-8")]
    hdr=rows[0]; return [dict(zip(hdr,r)) for r in rows[1:] if len(r)==len(hdr)]
def validate(d):
    errs=[]; oks=[]
    try: rep=json.load(open(os.path.join(d,"recovery_report.json"),encoding="utf-8"))
    except Exception as e: return ["recovery_report unreadable: %s"%e],[]
    for k in ("api_calls","real_dispatch_attempts"):
        (oks if rep.get(k)==0 else errs).append(k+"_is_0")
    (oks if rep.get("fixture_label")=="SYNTHETIC_OFFLINE_FIXTURE" else errs).append("report_fixture_label")
    res=rep.get("results",{})
    (oks if res and rep.get("checks_passed")==rep.get("checks_total")==len(res) else errs).append("counts_consistent")
    (oks if all(v is True for v in res.values()) else errs).append("all_checks_true")
    mx=load_matrix(d)
    (oks if len(mx)==16 else errs).append("matrix_rows_16")
    covered={r["prompt_4_fault_class"] for r in mx if r["scenario_id"]!="15" and r["scenario_id"]!="16"}
    for c in sorted(CLASSES_14-covered): errs.append("coverage_missing:%s"%c)
    (oks if CLASSES_14<=covered else errs).append("coverage_14_classes")
    for r in mx:
        cn=r["check_name"]
        (oks if res.get(cn) is True else errs).append("check_true:%s"%cn)
        run=r["synthetic_run"]
        if run.startswith("("): continue  # policy-eval rows have no transport artifacts
        dd=os.path.join(d,"synthetic_runs",run)
        if not os.path.isdir(dd): errs.append("missing_run_dir:%s"%run); continue
        try:
            labels={json.load(open(os.path.join(dd,f),encoding="utf-8")).get("fixture_label") for f in os.listdir(dd) if f.endswith(".json")}
            (oks if labels=={"SYNTHETIC_OFFLINE_FIXTURE"} else errs).append("run_label:%s"%run)
        except Exception as e: errs.append("run_unreadable:%s:%s"%(run,e))
    for dp,_,fns in os.walk(d):
        if "/synthetic_runs" in dp or dp.endswith("synthetic_runs"): pass
        for fn in fns:
            if fn.endswith((".json",".tsv")):
                p=os.path.join(dp,fn)
                if SENTINEL in open(p,encoding="utf-8",errors="ignore").read(): errs.append("sentinel_in_data:%s"%os.path.relpath(p,d))
    # semantic evidence from attempts summaries (saved-by-default, not just report flags)
    try:
        a2=json.load(open(os.path.join(d,"synthetic_runs/02_429_then_ok/attempts_summary.json"),encoding="utf-8"))["attempts"]
        sid=rep["scenario_facts"]["02_429_then_ok"]["model_idem_keys"][0]
        mm=[x for x in a2 if x.get("idempotency_key")==sid]
        (oks if len(mm)==2 and any("429" in str(x.get("error")) for x in mm) else errs).append("raw_429_error_preserved")
        a8=json.load(open(os.path.join(d,"synthetic_runs/08_schema_invalid/attempts_summary.json"),encoding="utf-8"))["attempts"]
        s8=rep["scenario_facts"]["08_schema_invalid"]["model_idem_keys"][0]
        (oks if sum(1 for x in a8 if x.get("idempotency_key")==s8)==1 else errs).append("schema_invalid_single_attempt")
    except Exception as e: errs.append("attempt_evidence_unreadable:%s"%e)
    return errs,oks
MUTS=[("flip_check", lambda d: _edit_json(os.path.join(d,"recovery_report.json"), lambda j: j["results"].update({"non_json_saved":False}) or j)),
      ("drop_run_dir", lambda d: shutil.rmtree(os.path.join(d,"synthetic_runs","09_non_json"))),
      ("break_coverage", lambda d: open(os.path.join(d,"failure_matrix.tsv"),"a",encoding="utf-8").close() or _rewrite_row(d,"06","reasoning exhausted, visible empty, finish=length","renamed_class_not_in_required_set")),
      ("relabel_fixture", lambda d: _edit_json(os.path.join(d,"synthetic_runs/10_empty_body/facts.json"), lambda j: j.update({"fixture_label":"REAL"}) or j),
        lambda d: _edit_json(os.path.join(d,"synthetic_runs/10_empty_body/selected_record.json"), lambda j: j.update({"fixture_label":"REAL"}) or j)),
      ("plant_key_sentinel", lambda d: _edit_json(os.path.join(d,"synthetic_runs/01_normal_200/facts.json"), lambda j: j.update({"note":SENTINEL}) or j))]
def _edit_json(p,fn):
    j=json.load(open(p,encoding="utf-8")); fn(j); json.dump(j,open(p,"w",encoding="utf-8"),ensure_ascii=False,sort_keys=True)
def _rewrite_row(d,sid,old,new):
    p=os.path.join(d,"failure_matrix.tsv"); lines=open(p,encoding="utf-8").read().splitlines()
    for i,l in enumerate(lines):
        if l.split("\t")[0]==sid:
            cells=l.split("\t"); cells[2]=new; lines[i]="\t".join(cells)
    open(p,"w",encoding="utf-8").write("\n".join(lines)+"\n")
def selftest_mutations():
    src=HERE; ok=True
    for mut in MUTS:
        tmp=tempfile.mkdtemp(prefix="rehmut_"); dst=os.path.join(tmp,"fr")
        shutil.copytree(src,dst,ignore=shutil.ignore_patterns("__pycache__"))
        for fn in mut[1:]: fn(dst)
        errs,_=validate(dst)
        detected=bool(errs)
        print(("OK  " if detected else "FAIL ")+"mutation %s detected: %s"%(mut[0], (errs[0] if errs else "NOT-DETECTED")))
        ok=ok and detected; shutil.rmtree(tmp,ignore_errors=True)
    return ok
def main():
    if "--selftest-mutations" in sys.argv:
        print("mutation self-test"); sys.exit(0 if selftest_mutations() else 1)
    errs,oks=validate(HERE)
    print("failure_rehearsal validator: %d ok, %d errors"%(len(oks),len(errs)))
    for e in errs: print("ERR "+e)
    sys.exit(0 if not errs else 1)
if __name__=="__main__": main()
