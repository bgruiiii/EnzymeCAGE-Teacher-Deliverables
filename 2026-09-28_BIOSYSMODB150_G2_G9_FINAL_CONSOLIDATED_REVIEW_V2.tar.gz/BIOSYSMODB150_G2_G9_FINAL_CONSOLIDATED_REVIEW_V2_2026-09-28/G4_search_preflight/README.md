# G4 search-efficacy probe preflight (PREPARED_NOT_AUTHORIZED_TO_RUN)
15 synthetic slots (5x3 probes), all NOT_DISPATCHED. Symmetry rule: all five metadata-verified PASS -> main enable_search=true; any not-PASS/unknown -> false; no mixed state. Model text claiming search never counts. No API this round.

Anchor policy: probes use 'as of the anchor date'; the concrete anchor UTC and the three public authority-URL reachability checks are frozen JUST-IN-TIME, after G4 eligibility is granted and before the Chenyu stage package is generated. anchor_utc is null now; no future date is invented. Once frozen, probe text+anchor+URL snapshot/hash enter the G4 manifest, and any change re-computes the G4 prompt/body hash. The just-in-time check is not a commercial-model API call.
