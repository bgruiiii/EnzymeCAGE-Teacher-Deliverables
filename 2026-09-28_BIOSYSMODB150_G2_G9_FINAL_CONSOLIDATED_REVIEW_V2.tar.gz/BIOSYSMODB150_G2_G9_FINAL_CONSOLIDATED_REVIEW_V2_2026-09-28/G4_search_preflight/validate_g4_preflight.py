#!/usr/bin/env python3
"""validate_G4_preflight.py -- independent structural check for G4 preflight.
Confirms slot count, NOT_DISPATCHED everywhere, deterministic selection (where
applicable), PREPARED/TEMPLATE status, no dispatch. No network, no key."""
import json, csv, os, sys
HERE=os.path.dirname(os.path.abspath(__file__)); F=[];N=[0]
def ck(n,ok,d=""):
    N[0]+=1
    if not ok: F.append({"check":n,"detail":str(d)[:200]}); print("  [FAIL]",n,str(d)[:120])
tm=os.path.join(HERE,"task_matrix.tsv")
if os.path.isfile(tm):
    rows=list(csv.DictReader(open(tm,encoding="utf-8"),delimiter="\t"))
    ck("slots_present",len(rows)>0)
    ck("all_not_dispatched",all(r["dispatch_status"]=="NOT_DISPATCHED" for r in rows))
ck("g4_slots_15", len([r for r in csv.DictReader(open(tm,encoding="utf-8"),delimiter="\t")])==15)
spec=json.load(open(os.path.join(HERE,"search_probe_spec.json"))); ck("g4_status", spec["status"]=="PREPARED_NOT_AUTHORIZED_TO_RUN")
crit=json.load(open(os.path.join(HERE,"metadata_success_criteria.json"))); ck("g4_no_text_claim", "metadata" in json.dumps(crit).lower())
sp2=json.load(open(os.path.join(HERE,"search_probe_spec.json")))
ck("g4_anchor_policy", sp2.get("anchor_policy","").startswith("freeze immediately"))
ck("g4_anchor_utc_null", sp2.get("anchor_utc") is None)
ck("g4_url_preflight_pending", sp2.get("authority_url_preflight_status")=="PENDING_JUST_IN_TIME_CHECK")
ck("g4_probe_freeze", sp2.get("probe_content_freeze_status")=="PREPARED_NOT_FROZEN")
probes=[json.loads(l) for l in open(os.path.join(HERE,"search_probes.jsonl"),encoding="utf-8") if l.strip()]
ck("g4_probes_anchor_fields", all(p.get("anchor_utc") is None and p.get("authority_url_check")=="PENDING" for p in probes))
print()
if F: print('VALIDATION FAIL',len(F),'/',N[0]); sys.exit(1)
print('VALIDATION PASS',N[0],'checks, 0 failures')
