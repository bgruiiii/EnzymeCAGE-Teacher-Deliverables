#!/usr/bin/env python3
"""
BBD known-pathway full-route v0.3 v3.1 three-tool blind predictions.
Executor-only: run BioTransformer ENVMICRO, enviPath BBD Rules prediction + database lookup,
and BBD-finetuned ECLIPSE (PREDEC + noEC) on the 93-parent strict blind input.
No local scoring. Restricted answer key is never read.
"""
import os, sys, json, hashlib, csv, subprocess, time, logging, traceback, platform
import shutil
from collections import defaultdict, Counter
from argparse import Namespace
from pathlib import Path
import pandas as pd
import numpy as np
from rdkit import Chem, rdBase
from rdkit.Chem import MolToSmiles, MolFromSmiles, MolToInchiKey

PROJECT_ROOT = "/root/projects/EnzymeCAGE-master"
RETURN_DIR = os.path.join(
    PROJECT_ROOT,
    "HPC_Returned_Result_Summaries/bbd_full_route_v0_3_v3_1_three_tool_blind_predictions_20260821",
)
LOG_DIR = os.path.join(RETURN_DIR, "logs")

# Input identities
ARCHIVE_PATH = os.path.join(
    PROJECT_ROOT,
    "HPC_Inputs/bbd_known_pathway_full_route_v0_3_candidate_v3_1_strict_blind_fix_20260821.tar.gz",
)
ARCHIVE_SHA256 = "ea9bf0497592f686013c789d42259260c2c69ba00d8a073435d6408cf2e02d90"
BLIND_CSV_NAME = "BBD_KNOWN_PATHWAY_FULL_ROUTE_V0_3_V3_1_BLIND_PARENT_INPUTS_FOR_PREDICTION_STRICT.csv"
BLIND_SHA256 = "be11658b0ede11093bb8bb833281994cb2f507629eaf7b3524de74a4e46acb66"
BLIND_BYTES = 20776
EXPECTED_ROWS = 93
EXPECTED_COLUMNS = [
    "full_route_case_id", "scope", "pollutant_name", "pollutant_category",
    "parent_smiles", "parent_canonical_smiles", "input_note",
]

# enviPath constants
ENVIPATH_BASE = "https://envipath.org/api/legacy/"
ENVIPATH_PACKAGE = "https://envipath.org/package/32de3cf4-e3e6-4168-956e-32fa5ddb0ce1"
ENVIPATH_SEARCH = "https://envipath.org/api/legacy/search"
ENVIPATH_UTIL = "https://envipath.org/api/legacy/util"
ENVIPATH_SETTING = "https://envipath.org/setting/a0fbc3d8-ca45-44f1-9c3c-80d8531ffe25"
ENVIPATH_SETTING_NAME = "Global Setting - BBD Rules"

# BioTransformer constants
BT_JAR_PRIMARY = "/tmp/enzymecage_m3_p1_2_1_three_tool_valid_single_parent_biotransformer_envmicro_prediction_rerun1_20260728/Biotransformer/target/biotransformer-3.0.0.jar"
BT_DIR_PRIMARY = "/tmp/enzymecage_m3_p1_2_1_three_tool_valid_single_parent_biotransformer_envmicro_prediction_rerun1_20260728/Biotransformer"

# ECLIPSE model dirs
ECLIPSE_BASE = os.path.join(PROJECT_ROOT, "results/ECLIPSEProdModel")
HIERARCHY_PATH = os.path.join(PROJECT_ROOT, "results/summary/hierarchy.csv")

ENV_FILE = os.path.join(PROJECT_ROOT, "HPC_Inputs/envipath_account_env.local.sh")

# ============================================================
# Utilities
# ============================================================
def canon(smiles):
    if not smiles:
        return ""
    mol = MolFromSmiles(smiles)
    if mol is None:
        return ""
    return MolToSmiles(mol, canonical=True, isomericSmiles=True)

def inchikey_of(smiles):
    mol = MolFromSmiles(smiles)
    if mol is None:
        return ""
    return MolToInchiKey(mol)

def sha256_file(path):
    if not os.path.exists(path):
        return ""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def safe_error(text, limit=1200):
    if text is None:
        return None
    sanitized = str(text)
    password = os.environ.get("ENVIPATH_PASSWORD", "")
    username = os.environ.get("ENVIPATH_USERNAME", "")
    if password:
        sanitized = sanitized.replace(password, "[REDACTED_PASSWORD]")
    if username:
        sanitized = sanitized.replace(username, "[REDACTED_USERNAME]")
    return sanitized[:limit]

def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, sort_keys=True, indent=2)

def write_jsonl(path, records):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        for rec in records:
            f.write(json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n")

def setup_logger(name, log_file):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fh = logging.FileHandler(os.path.join(LOG_DIR, log_file), mode="w")
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(fh)
    sh = logging.StreamHandler()
    sh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(sh)
    return logger

# ============================================================
# Section 1: Input Audit
# ============================================================
def input_audit(logger):
    logger.info("=== Input Audit ===")
    archive_sha = sha256_file(ARCHIVE_PATH)
    archive_ok = archive_sha == ARCHIVE_SHA256
    logger.info(f"Archive SHA256: {archive_sha}, match: {archive_ok}")

    extract_dir = os.path.join(PROJECT_ROOT, "HPC_Inputs/_extract_bbd_v3_1_fix")
    blind_csv = os.path.join(
        extract_dir,
        "bbd_known_pathway_full_route_v0_3_candidate_v3_1_strict_blind_fix_20260821/blind",
        BLIND_CSV_NAME,
    )
    blind_sha = sha256_file(blind_csv)
    blind_size = os.path.getsize(blind_csv)
    blind_ok = (blind_sha == BLIND_SHA256 and blind_size == BLIND_BYTES)
    logger.info(f"Blind CSV SHA256: {blind_sha}, bytes: {blind_size}, match: {blind_ok}")

    df = pd.read_csv(blind_csv)
    cols_ok = list(df.columns) == EXPECTED_COLUMNS
    rows_ok = len(df) == EXPECTED_ROWS
    logger.info(f"Columns match: {cols_ok}, rows={len(df)}")

    if not (archive_ok and blind_ok and cols_ok and rows_ok):
        raise RuntimeError("Input audit FAILED")

    shutil.copy2(blind_csv, os.path.join(RETURN_DIR, "00_INPUT_AUDIT/copied_strict_blind_input.csv"))

    identity = {
        "archive_sha256": archive_sha, "archive_sha256_expected": ARCHIVE_SHA256,
        "archive_sha256_match": archive_ok,
        "blind_csv_sha256": blind_sha, "blind_csv_sha256_expected": BLIND_SHA256,
        "blind_csv_sha256_match": blind_ok,
        "blind_csv_bytes": blind_size, "blind_csv_bytes_expected": BLIND_BYTES,
        "blind_csv_rows": len(df), "blind_csv_rows_expected": EXPECTED_ROWS,
        "blind_csv_rows_match": rows_ok,
        "restricted_answer_key_read": False,
        "input_audit_pass": True,
    }
    write_json(os.path.join(RETURN_DIR, "00_INPUT_AUDIT/strict_blind_identity.json"), identity)
    with open(os.path.join(RETURN_DIR, "00_INPUT_AUDIT/strict_blind_identity.md"), "w") as f:
        f.write(f"# Strict Blind Input Identity\n\n- Archive SHA256 match: **{archive_ok}**\n- Blind CSV SHA256 match: **{blind_ok}**\n- Rows: {len(df)} (expected {EXPECTED_ROWS})\n- Columns match: **{cols_ok}**\n- Restricted answer key read: **false**\n")

    logger.info("Input audit PASSED")
    return df, identity

# ============================================================
# Section 2: Asset Discovery
# ============================================================
def asset_discovery(logger):
    logger.info("=== Asset Discovery ===")
    assets = {}

    # BioTransformer
    bt_jar = BT_JAR_PRIMARY if os.path.exists(BT_JAR_PRIMARY) else None
    bt_dir = BT_DIR_PRIMARY
    java_ver = subprocess.run(["java", "-version"], capture_output=True, text=True, timeout=10)
    assets["biotransformer"] = {
        "jar_path": bt_jar, "jar_sha256": sha256_file(bt_jar) if bt_jar else "",
        "jar_bytes": os.path.getsize(bt_jar) if bt_jar else 0, "bt_dir": bt_dir,
        "database_exists": os.path.exists(os.path.join(bt_dir, "database")),
        "java_version": java_ver.stderr.strip().split("\n")[0] if java_ver.returncode == 0 else "NOT FOUND",
        "repository": "https://github.com/Wishartlab-openscience/Biotransformer.git",
        "commit": "7149f7ec6b2f32f9f789bab53aa4a71db49e59e2",
        "status": "available" if bt_jar and os.path.exists(os.path.join(bt_dir, "database")) else "blocked",
    }
    write_json(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY/biotransformer_asset_identity.json"), assets["biotransformer"])

    # enviPath
    import requests
    env_file_exists = os.path.exists(ENV_FILE)
    assets["envipath"] = {
        "credential_file_exists": env_file_exists, "credentials_filled": False,
        "base_url": ENVIPATH_BASE, "prediction_setting_id": ENVIPATH_SETTING,
        "prediction_setting_name": ENVIPATH_SETTING_NAME, "eawag_bbd_package": ENVIPATH_PACKAGE,
        "envipath_python_version": "0.2.4 (legacy_api via requests)", "requests_version": requests.__version__,
        "status": "available" if env_file_exists else "blocked_missing_credentials",
    }
    if env_file_exists:
        result = subprocess.run(["bash", "-c", f"source {ENV_FILE} && echo ${{#ENVIPATH_USERNAME}} ${{#ENVIPATH_PASSWORD}}"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            parts = result.stdout.strip().split()
            if len(parts) == 2:
                assets["envipath"]["credentials_filled"] = (int(parts[0]) > 0 and int(parts[1]) > 0)
    write_json(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY/envipath_asset_identity.json"), assets["envipath"])

    # ECLIPSE
    eclipse_folds = []
    all_ok = True
    for fold in range(10):
        fold_dir = os.path.join(ECLIPSE_BASE, f"bbd_40_3_{fold}_uspto_rdkit")
        ckpt_dir = os.path.join(fold_dir, "expert/checkpoints")
        model_pkl = os.path.join(fold_dir, "eclipse/model.pkl")
        fi = {
            "fold": fold, "dir": fold_dir,
            "config_exists": os.path.exists(os.path.join(fold_dir, "config.json")),
            "tokens_exists": os.path.exists(os.path.join(fold_dir, "tokens.json")),
            "split_exists": os.path.exists(os.path.join(fold_dir, "split_bbd.json")),
            "checkpoint": "", "checkpoint_sha256": "", "checkpoint_bytes": 0,
            "model_pkl": model_pkl,
            "model_pkl_sha256": sha256_file(model_pkl) if os.path.exists(model_pkl) else "",
            "model_pkl_bytes": os.path.getsize(model_pkl) if os.path.exists(model_pkl) else 0,
        }
        if os.path.isdir(ckpt_dir):
            ckpts = sorted([f for f in os.listdir(ckpt_dir) if f.endswith(".ckpt")])
            if ckpts:
                cp = os.path.join(ckpt_dir, ckpts[0])
                fi["checkpoint"] = cp; fi["checkpoint_sha256"] = sha256_file(cp); fi["checkpoint_bytes"] = os.path.getsize(cp)
        if not all(fi[k] for k in ["config_exists", "tokens_exists", "split_exists"]):
            all_ok = False
        eclipse_folds.append(fi)
    hierarchy_exists = os.path.exists(HIERARCHY_PATH)
    assets["eclipse"] = {
        "folds": eclipse_folds, "fold_count": 10, "all_folds_available": all_ok,
        "hierarchy_path": HIERARCHY_PATH, "hierarchy_exists": hierarchy_exists,
        "hierarchy_sha256": sha256_file(HIERARCHY_PATH) if hierarchy_exists else "",
        "chem_eclipse_src": os.path.join(PROJECT_ROOT, "chem-eclipse/src"),
        "gpu_available": False, "status": "available" if all_ok and hierarchy_exists else "blocked",
    }
    try:
        import torch
        assets["eclipse"]["torch_version"] = torch.__version__
        assets["eclipse"]["cuda_available"] = torch.cuda.is_available()
    except Exception:
        pass
    write_json(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY/eclipse_asset_identity.json"), assets["eclipse"])
    with open(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY/asset_discovery_log.md"), "w") as f:
        f.write("# Asset Discovery Log\n\n")
        f.write(f"- BioTransformer: {assets['biotransformer']['status']}\n- enviPath: {assets['envipath']['status']}\n- ECLIPSE: {assets['eclipse']['status']} (CPU mode)\n- GPU: unavailable (CPU mode used)\n")
    return assets

# ============================================================
# Section 3: BioTransformer ENVMICRO
# ============================================================
def run_biotransformer(df, logger):
    logger.info("=== BioTransformer ENVMICRO ===")
    bt_jar = BT_JAR_PRIMARY; bt_dir = BT_DIR_PRIMARY
    bt_out_dir = "/tmp/bt_bbd_full_route_v0_3_v3_1"
    os.makedirs(bt_out_dir, exist_ok=True)
    raw_dir = os.path.join(RETURN_DIR, "03_PREDICTIONS/biotransformer_envmicro_s1/raw")
    os.makedirs(raw_dir, exist_ok=True)
    normalized_records = []; success_count = 0; error_count = 0

    for idx, row in df.iterrows():
        case_id = row["full_route_case_id"]
        parent_smi = str(row["parent_smiles"]); parent_canon = str(row["parent_canonical_smiles"])
        out_csv = os.path.join(bt_out_dir, f"bt_{case_id}.csv")
        raw_ref = f"03_PREDICTIONS/biotransformer_envmicro_s1/raw/{case_id}.csv"
        try:
            result = subprocess.run(["java", "-jar", bt_jar, "-k", "pred", "-b", "env", "-ismi", parent_smi, "-ocsv", out_csv, "-s", "1"], capture_output=True, text=True, timeout=60, cwd=bt_dir)
            if result.returncode == 0 and os.path.exists(out_csv):
                bt_df = pd.read_csv(out_csv)
                shutil.copy2(out_csv, os.path.join(raw_dir, f"{case_id}.csv")); os.remove(out_csv)
                if "SMILES" in bt_df.columns:
                    seen = set(); rank = 0
                    for smi in bt_df["SMILES"].dropna():
                        c = canon(str(smi))
                        if not c or c in seen: continue
                        seen.add(c); rank += 1
                        if rank > 10: break
                        normalized_records.append({
                            "full_route_case_id": case_id, "scope": row["scope"], "pollutant_name": row["pollutant_name"],
                            "pollutant_category": row["pollutant_category"], "parent_smiles": parent_smi,
                            "parent_canonical_smiles": parent_canon, "tool_id": "biotransformer_envmicro",
                            "route_id": "biotransformer_envmicro_s1", "prediction_depth": 1,
                            "source_predicted_parent_smiles_canonical": parent_canon, "prediction_rank": rank,
                            "predicted_product_smiles_raw": str(smi), "predicted_product_smiles_canonical": c,
                            "predicted_product_inchikey": inchikey_of(c), "score_raw": 0.0, "score_semantics": "no_score",
                            "fold_id": 0, "fold_count": 1, "raw_output_ref": raw_ref, "normalization_status": "ok",
                            "case_status": "ok", "predicted_product_is_parent_copy": (c == parent_canon),
                        })
                    if rank > 0: success_count += 1
                    else: error_count += 1
                else: error_count += 1
            else:
                error_count += 1
                if error_count <= 5: logger.warning(f"BT error {case_id}: {safe_error(result.stderr)}")
        except Exception as e:
            error_count += 1
            if error_count <= 5: logger.warning(f"BT exception {case_id}: {e}")
        if (idx + 1) % 20 == 0: logger.info(f"BT progress: {idx+1}/{len(df)}, success={success_count}, error={error_count}")

    logger.info(f"BioTransformer done: success={success_count}, error={error_count}")
    write_jsonl(os.path.join(RETURN_DIR, "03_PREDICTIONS/biotransformer_envmicro_s1/PREDICTIONS_NORMALIZED.jsonl"), normalized_records)
    return normalized_records, success_count, error_count

# ============================================================
# Section 4: enviPath prediction + database lookup
# ============================================================
def extract_first_gen_predictions(api_json):
    nodes = {node.get("id"): node for node in api_json.get("nodes", []) if isinstance(node, dict)}
    products = []
    for edge in api_json.get("edges", []) or []:
        if edge.get("from") != 0: continue
        rule = edge.get("rule") if isinstance(edge.get("rule"), dict) else {}
        for to_id in edge.get("to", []) or []:
            node = nodes.get(to_id, {})
            smiles = node.get("smiles")
            if smiles:
                products.append({"smiles": smiles, "probability": edge.get("probability"),
                    "multiGenProbability": edge.get("multiGenProbability"), "rule_name": rule.get("name"), "rule_url": rule.get("url")})
    return products

def run_envipath(df, logger):
    logger.info("=== enviPath Prediction + Database Lookup ===")
    import requests
    result = subprocess.run(["bash", "-c", f"source {ENV_FILE} && env"], capture_output=True, text=True, timeout=10)
    for line in result.stdout.strip().split("\n"):
        if line.startswith("ENVIPATH_"): k, v = line.split("=", 1); os.environ[k] = v
    username = os.environ.get("ENVIPATH_USERNAME"); password = os.environ.get("ENVIPATH_PASSWORD")
    if not username or not password:
        logger.error("enviPath credentials missing"); return [], [], "blocked_missing_credentials", "blocked_missing_credentials"
    session = requests.Session()
    try:
        resp = session.post(ENVIPATH_BASE, data={"hiddenMethod": "login", "loginusername": username, "loginpassword": password}, headers={"Accept": "application/json"}, timeout=60)
        if resp.status_code >= 400: logger.error(f"login failed: {resp.status_code}"); return [], [], "blocked_login_failed", "blocked_login_failed"
        logger.info(f"enviPath login OK: HTTP {resp.status_code}")
    except Exception as e:
        logger.error(f"login exception: {safe_error(e)}"); return [], [], "blocked_endpoint_unreachable", "blocked_endpoint_unreachable"

    pred_records = []; lookup_records = []; pred_success = 0; pred_error = 0; lookup_success = 0; lookup_error = 0; delay = 2.0
    pred_raw_dir = os.path.join(RETURN_DIR, "03_PREDICTIONS/envipath_bbd_rules_s1/raw")
    lookup_raw_dir = os.path.join(RETURN_DIR, "05_ENVIPATH_DATABASE_LOOKUP_SEPARATE/raw")
    os.makedirs(pred_raw_dir, exist_ok=True); os.makedirs(lookup_raw_dir, exist_ok=True)

    for idx, row in df.iterrows():
        case_id = row["full_route_case_id"]; parent_smi = str(row["parent_smiles"]); parent_canon = str(row["parent_canonical_smiles"])
        # Database Lookup
        try:
            resp = session.get(ENVIPATH_SEARCH, params={"method": "defaultSmiles", "packages[]": [ENVIPATH_PACKAGE], "search": parent_smi}, headers={"Accept": "application/json"}, timeout=60)
            try: data = resp.json()
            except: data = None
            write_json(os.path.join(lookup_raw_dir, f"{case_id}.json"), {"case_id": case_id, "http_status": resp.status_code, "json": data, "error_message_sanitized": "" if resp.status_code == 200 else safe_error(resp.text)})
            dd = data if isinstance(data, dict) else {}
            lookup_records.append({"full_route_case_id": case_id, "tool_id": "envipath_database_lookup", "layer": "database_lookup",
                "parent_smiles": parent_smi, "lookup_status": "ok" if resp.status_code == 200 else "error",
                "matched_compound_count": len(dd.get("compound", [])), "matched_pathway_count": len(dd.get("pathway", [])),
                "matched_reaction_count": len(dd.get("reaction", [])), "raw_output_ref": f"05_ENVIPATH_DATABASE_LOOKUP_SEPARATE/raw/{case_id}.json"})
            if resp.status_code == 200: lookup_success += 1
            else: lookup_error += 1
        except Exception as e:
            lookup_error += 1
            if lookup_error <= 5: logger.warning(f"Lookup error {case_id}: {safe_error(e)}")
            lookup_records.append({"full_route_case_id": case_id, "tool_id": "envipath_database_lookup", "layer": "database_lookup",
                "parent_smiles": parent_smi, "lookup_status": "client_error", "matched_compound_count": 0, "matched_pathway_count": 0,
                "matched_reaction_count": 0, "raw_output_ref": f"05_ENVIPATH_DATABASE_LOOKUP_SEPARATE/raw/{case_id}.json"})
        time.sleep(delay)
        # Prediction
        try:
            resp = session.post(ENVIPATH_UTIL, data={"hiddenMethod": "predict", "smiles": parent_smi, "settingUri": ENVIPATH_SETTING}, headers={"Accept": "application/json"}, timeout=90)
            try: data = resp.json()
            except: data = None
            write_json(os.path.join(pred_raw_dir, f"{case_id}.json"), {"case_id": case_id, "http_status": resp.status_code, "json": data, "error_message_sanitized": "" if resp.status_code == 200 else safe_error(resp.text)})
            raw_products = extract_first_gen_predictions(data or {}) if resp.status_code == 200 else []
            seen = set(); rank = 0
            for rp in raw_products:
                c = canon(rp.get("smiles", ""))
                if not c or c in seen: continue
                seen.add(c); rank += 1
                if rank > 10: break
                prob = rp.get("probability")
                pred_records.append({"full_route_case_id": case_id, "scope": row["scope"], "pollutant_name": row["pollutant_name"],
                    "pollutant_category": row["pollutant_category"], "parent_smiles": parent_smi, "parent_canonical_smiles": parent_canon,
                    "tool_id": "envipath_prediction", "route_id": "envipath_bbd_rules_s1", "prediction_depth": 1,
                    "source_predicted_parent_smiles_canonical": parent_canon, "prediction_rank": rank,
                    "predicted_product_smiles_raw": rp.get("smiles", ""), "predicted_product_smiles_canonical": c,
                    "predicted_product_inchikey": inchikey_of(c), "score_raw": float(prob) if prob is not None else 0.0,
                    "score_semantics": "probability", "fold_id": 0, "fold_count": 1,
                    "raw_output_ref": f"03_PREDICTIONS/envipath_bbd_rules_s1/raw/{case_id}.json", "normalization_status": "ok",
                    "case_status": "ok", "predicted_product_is_parent_copy": (c == parent_canon)})
            if rank > 0: pred_success += 1
            else: pred_error += 1
        except Exception as e:
            pred_error += 1
            if pred_error <= 5: logger.warning(f"Pred error {case_id}: {safe_error(e)}")
        time.sleep(delay)
        if (idx + 1) % 20 == 0: logger.info(f"enviPath progress: {idx+1}/{len(df)}, pred={pred_success}, lookup={lookup_success}")

    logger.info(f"enviPath done: pred={pred_success}/{pred_error}, lookup={lookup_success}/{lookup_error}")
    write_jsonl(os.path.join(RETURN_DIR, "03_PREDICTIONS/envipath_bbd_rules_s1/PREDICTIONS_NORMALIZED.jsonl"), pred_records)
    write_jsonl(os.path.join(RETURN_DIR, "05_ENVIPATH_DATABASE_LOOKUP_SEPARATE/ENVIPATH_DATABASE_LOOKUP_RESULTS.jsonl"), lookup_records)
    pd.DataFrame(lookup_records).to_csv(os.path.join(RETURN_DIR, "05_ENVIPATH_DATABASE_LOOKUP_SEPARATE/ENVIPATH_DATABASE_LOOKUP_SUMMARY.csv"), index=False)
    with open(os.path.join(RETURN_DIR, "05_ENVIPATH_DATABASE_LOOKUP_SEPARATE/ENVIPATH_DATABASE_LOOKUP_NOTE.md"), "w") as f:
        f.write(f"# enviPath Database Lookup Note\n\nSeparate from prediction. Lookup OK: {lookup_success}, Prediction OK: {pred_success}\n")
    return pred_records, lookup_records, "ok" if pred_success > 0 else "blocked", "ok" if lookup_success > 0 else "blocked"

# ============================================================
# Section 5: ECLIPSE PREDEC + noEC
# ============================================================
def load_fold_model(seed, logger):
    import torch
    sys.path.insert(0, os.path.join(PROJECT_ROOT, ".venv/lib/python3.12/site-packages"))
    sys.path.insert(0, os.path.join(PROJECT_ROOT, "chem-eclipse/src"))
    from chem_eclipse.models.ECLIPSEProdModel import ECLIPSEProdModel

    fold_dir = os.path.join(ECLIPSE_BASE, f"bbd_40_3_{seed}_uspto_rdkit")
    with open(os.path.join(fold_dir, "config.json")) as f: config = json.load(f)
    with open(os.path.join(fold_dir, "tokens.json")) as f: tokens = json.load(f)
    if isinstance(tokens, list) and len(tokens) == 2:
        char_to_i = tokens[0]; i_to_char = {int(k): v for k, v in tokens[1].items()}
    elif "regex" in tokens:
        char_to_i = tokens["regex"]; i_to_char = {i: char for char, i in char_to_i.items()}
    else:
        char_to_i = tokens; i_to_char = {i: char for char, i in char_to_i.items()}
    with open(os.path.join(fold_dir, "split_bbd.json")) as f: split = json.load(f)
    ec_to_i = split["ec_to_i"]; tokenizer = (char_to_i, i_to_char)

    args = Namespace(
        data_name="bbd", eclipse_type="h", split_path="",
        max_len=config.get("max_len", 380), min_len=config.get("min_len", 0),
        debug=False, epochs=config.get("epochs", 500), batch_size=config.get("batch_size", 128),
        weights_dataset="",  # skip pre-trained weights loading for CPU inference
        score_all=config.get("score_all", False), folds=config.get("folds", 10),
        enzymes=config.get("enzymes", False), seed=seed, test="",
        train_many=False, workers=4, gpu=False,
    )
    model = ECLIPSEProdModel(config, vocab=tokenizer, ec_vocab=ec_to_i, p_args=args, train_steps=1000)
    model.eclipse = model.eclipse.load_model()

    ckpt_dir = os.path.join(fold_dir, "expert/checkpoints")
    ckpt_files = sorted([f for f in os.listdir(ckpt_dir) if f.endswith(".ckpt")])
    ckpt_path = os.path.join(ckpt_dir, ckpt_files[0])
    ckpt = torch.load(ckpt_path, map_location=lambda storage, loc: storage, weights_only=False)
    model.experts.load_state_dict(ckpt["state_dict"])
    model.experts = model.experts.to("cpu")
    model.experts.eval()
    logger.info(f"Fold {seed} loaded: {ckpt_files[0]}")
    return model

def run_eclipse(df, logger):
    logger.info("=== ECLIPSE PREDEC + noEC ===")
    import torch
    parents = df["parent_canonical_smiles"].tolist()
    batch_size = 16
    all_preds_noec = defaultdict(list)
    all_preds_predec = defaultdict(list)

    intermediate_dir = os.path.join(RETURN_DIR, "03_PREDICTIONS/_intermediate_eclipse")
    os.makedirs(intermediate_dir, exist_ok=True)
    completed_folds = set()
    for f in os.listdir(intermediate_dir):
        if f.startswith("fold_") and f.endswith(".json"):
            fold_num = int(f.split("_")[1].split(".")[0])
            completed_folds.add(fold_num)
            with open(os.path.join(intermediate_dir, f)) as fh: fold_data = json.load(fh)
            for p, preds in fold_data.get("noec", {}).items(): all_preds_noec[p].extend([(fold_num, r[0], r[1], r[2]) for r in preds])
            for p, preds in fold_data.get("predec", {}).items(): all_preds_predec[p].extend([(fold_num, r[0], r[1], r[2]) for r in preds])
            logger.info(f"Loaded intermediate fold {fold_num}")

    for fold in range(10):
        if fold in completed_folds: logger.info(f"Fold {fold} skipped"); continue
        logger.info(f"=== Fold {fold} ===")
        try: model = load_fold_model(fold, logger)
        except Exception as e:
            logger.error(f"Fold {fold} load failed: {e}"); logger.error(traceback.format_exc()); continue

        for batch_start in range(0, len(parents), batch_size):
            batch = parents[batch_start:batch_start + batch_size]
            # NoEC
            try:
                model.moe_config["use_enzyme"] = False
                with torch.no_grad(): (pred_smiles_noec, pred_proba_noec), _ = model.smiles_to_smiles_inf(batch)
                for i, (smis, probs) in enumerate(zip(pred_smiles_noec, pred_proba_noec)):
                    parent = batch[i]
                    for rank, (s, p) in enumerate(zip(smis[:10], probs[:10])): all_preds_noec[parent].append((fold, rank, str(s), float(p)))
            except Exception as e: logger.error(f"NoEC batch {batch_start} failed: {e}")
            # PREDEC
            try:
                model.moe_config["use_enzyme"] = True
                with torch.no_grad(): (pred_smiles_predec, pred_proba_predec), pred_ec = model.smiles_to_smiles_inf(batch)
                for i, (smis, probs) in enumerate(zip(pred_smiles_predec, pred_proba_predec)):
                    parent = batch[i]
                    for rank, (s, p) in enumerate(zip(smis[:10], probs[:10])): all_preds_predec[parent].append((fold, rank, str(s), float(p)))
            except Exception as e: logger.error(f"PREDEC batch {batch_start} failed: {e}")
            if batch_start % (batch_size * 2) == 0: logger.info(f"  Fold {fold} progress: {batch_start}/{len(parents)}")

        del model
        logger.info(f"Fold {fold} done")
        fold_data = {
            "noec": {p: [[r, s, sc] for (f, r, s, sc) in preds if f == fold] for p, preds in all_preds_noec.items() if any(f == fold for f, r, s, sc in preds)},
            "predec": {p: [[r, s, sc] for (f, r, s, sc) in preds if f == fold] for p, preds in all_preds_predec.items() if any(f == fold for f, r, s, sc in preds)},
        }
        with open(os.path.join(intermediate_dir, f"fold_{fold}.json"), "w") as f: json.dump(fold_data, f)
        logger.info(f"Saved intermediate fold {fold}")

    return all_preds_noec, all_preds_predec

def aggregate_and_write_eclipse(all_preds, df, logger, route_name, route_id, sub_dir):
    logger.info(f"=== Aggregating {route_name} ===")
    parents = df["parent_canonical_smiles"].tolist()
    parent_map = {r["parent_canonical_smiles"]: r for _, r in df.iterrows()}
    foldwise_records = []; normalized_rows = []

    for parent in parents:
        row = parent_map[parent]; case_id = row["full_route_case_id"]; parent_canon = str(row["parent_canonical_smiles"])
        fold_preds = all_preds.get(parent, [])
        for fold, rank, smi, score in fold_preds:
            c_smi = canon(smi)
            foldwise_records.append({"full_route_case_id": case_id, "scope": row["scope"], "pollutant_name": row["pollutant_name"],
                "pollutant_category": row["pollutant_category"], "parent_smiles": str(row["parent_smiles"]), "parent_canonical_smiles": parent_canon,
                "tool_id": route_name, "route_id": route_id, "prediction_depth": 1, "source_predicted_parent_smiles_canonical": parent_canon,
                "fold_id": fold, "fold_count": 10, "fold_local_rank": rank, "predicted_product_smiles_raw": str(smi),
                "predicted_product_smiles_canonical": c_smi, "predicted_product_inchikey": inchikey_of(c_smi),
                "score_raw": score, "score_semantics": "beam_log_likelihood", "raw_output_ref": f"03_PREDICTIONS/_intermediate_eclipse/fold_{fold}.json",
                "normalization_status": "ok"})

        canon_scores = defaultdict(list)
        for fold, rank, smi, score in fold_preds:
            c = canon(smi)
            if c: canon_scores[c].append((fold, score))
        ranked = sorted(canon_scores.items(), key=lambda x: (-len(set(f for f, s in x[1])), -np.mean([s for f, s in x[1]])))

        for rank, (c_smi, fold_score_list) in enumerate(ranked[:10]):
            folds_with_pred = set(f for f, s in fold_score_list)
            normalized_rows.append({"full_route_case_id": case_id, "scope": row["scope"], "pollutant_name": row["pollutant_name"],
                "pollutant_category": row["pollutant_category"], "parent_smiles": str(row["parent_smiles"]), "parent_canonical_smiles": parent_canon,
                "tool_id": route_name, "route_id": route_id, "prediction_depth": 1, "source_predicted_parent_smiles_canonical": parent_canon,
                "prediction_rank": rank, "predicted_product_smiles_raw": c_smi, "predicted_product_smiles_canonical": c_smi,
                "predicted_product_inchikey": inchikey_of(c_smi), "score_raw": float(np.mean([s for f, s in fold_score_list])),
                "score_semantics": "fold_frequency_then_mean_beam_log_likelihood", "fold_id": -1, "fold_count": len(folds_with_pred),
                "raw_output_ref": "03_PREDICTIONS/_intermediate_eclipse/", "normalization_status": "ok", "case_status": "ok",
                "predicted_product_is_parent_copy": (c_smi == parent_canon)})
        if not ranked:
            normalized_rows.append({"full_route_case_id": case_id, "scope": row["scope"], "pollutant_name": row["pollutant_name"],
                "pollutant_category": row["pollutant_category"], "parent_smiles": str(row["parent_smiles"]), "parent_canonical_smiles": parent_canon,
                "tool_id": route_name, "route_id": route_id, "prediction_depth": 1, "source_predicted_parent_smiles_canonical": parent_canon,
                "prediction_rank": 0, "predicted_product_smiles_raw": "", "predicted_product_smiles_canonical": "",
                "predicted_product_inchikey": "", "score_raw": 0.0, "score_semantics": "no_prediction", "fold_id": -1, "fold_count": 0,
                "raw_output_ref": "", "normalization_status": "no_prediction", "case_status": "no_prediction", "predicted_product_is_parent_copy": False})

    pred_dir = os.path.join(RETURN_DIR, "03_PREDICTIONS", sub_dir)
    pd.DataFrame(normalized_rows).to_csv(os.path.join(pred_dir, "PREDICTIONS_NORMALIZED.csv"), index=False)
    write_jsonl(os.path.join(pred_dir, "PREDICTIONS_FOLDWISE.jsonl"), foldwise_records)
    success = len(set(r["full_route_case_id"] for r in normalized_rows if r.get("predicted_product_smiles_canonical")))
    logger.info(f"{route_name}: {len(normalized_rows)} rows, {success} parents with predictions")
    return normalized_rows, success

# ============================================================
# Section 6: Route Status and Blockers
# ============================================================
def build_route_status(df, bt_result, envipath_result, eclipse_predec_result, eclipse_noec_result):
    n = len(df); route_rows = []; blockers = {}
    bt_recs, bt_success, bt_error = bt_result
    route_rows.append({"route_id": "biotransformer_envmicro_s1", "status": "ok" if bt_success > 0 else "blocked",
        "input_parent_count": n, "parents_with_nonempty_predictions": bt_success,
        "normalized_prediction_count": len(bt_recs), "raw_output_count": bt_success,
        "typed_blocker": "" if bt_success > 0 else "biotransformer_status=blocked_jar_runtime_error",
        "notes": f"success={bt_success}, error={bt_error}"})
    if bt_success == 0: blockers["biotransformer"] = "biotransformer_status=blocked_jar_runtime_error"

    ep_recs, _, ep_pred_status, ep_lookup_status = envipath_result
    ep_nonempty = len(set(r["full_route_case_id"] for r in ep_recs if r.get("predicted_product_smiles_canonical")))
    route_rows.append({"route_id": "envipath_bbd_rules_s1", "status": ep_pred_status,
        "input_parent_count": n, "parents_with_nonempty_predictions": ep_nonempty,
        "normalized_prediction_count": len(ep_recs), "raw_output_count": ep_nonempty,
        "typed_blocker": "" if ep_pred_status == "ok" else f"envipath_prediction_status={ep_pred_status}",
        "notes": f"pred={ep_pred_status}, lookup={ep_lookup_status}"})
    if ep_pred_status != "ok": blockers["envipath_prediction"] = f"envipath_prediction_status={ep_pred_status}"

    ep_pre_recs, ep_pre_success = eclipse_predec_result
    route_rows.append({"route_id": "eclipse_predec_bbd_finetuned_10fold_aggregated_s1", "status": "ok" if ep_pre_success > 0 else "blocked",
        "input_parent_count": n, "parents_with_nonempty_predictions": ep_pre_success,
        "normalized_prediction_count": len(ep_pre_recs), "raw_output_count": 10,
        "typed_blocker": "" if ep_pre_success > 0 else "eclipse_status=blocked_inference_failed",
        "notes": f"CPU, 10 folds, success={ep_pre_success}"})
    if ep_pre_success == 0: blockers["eclipse_predec"] = "eclipse_status=blocked_inference_failed"

    ep_no_recs, ep_no_success = eclipse_noec_result
    route_rows.append({"route_id": "eclipse_noec_bbd_finetuned_10fold_aggregated_s1", "status": "ok" if ep_no_success > 0 else "blocked",
        "input_parent_count": n, "parents_with_nonempty_predictions": ep_no_success,
        "normalized_prediction_count": len(ep_no_recs), "raw_output_count": 10,
        "typed_blocker": "" if ep_no_success > 0 else "eclipse_status=blocked_inference_failed",
        "notes": f"CPU, 10 folds, success={ep_no_success}"})
    if ep_no_success == 0: blockers["eclipse_noec"] = "eclipse_status=blocked_inference_failed"

    pd.DataFrame(route_rows).to_csv(os.path.join(RETURN_DIR, "02_ROUTE_STATUS/route_status_summary.csv"), index=False)
    write_json(os.path.join(RETURN_DIR, "02_ROUTE_STATUS/route_blockers.json"), blockers)
    with open(os.path.join(RETURN_DIR, "02_ROUTE_STATUS/route_blockers.md"), "w") as f:
        f.write("# Route Blockers\n\n" + (("\n".join(f"- **{k}**: `{v}`" for k, v in blockers.items()) + "\n") if blockers else "No blockers. All routes completed.\n"))
    return route_rows, blockers

# ============================================================
# Section 7: Metadata and Packaging
# ============================================================
def make_manifest(return_dir):
    manifest = os.path.join(return_dir, "MANIFEST.sha256")
    rows = []
    for path in sorted(p for p in Path(return_dir).rglob("*") if p.is_file() and p.name != "MANIFEST.sha256"):
        rows.append(f"{sha256_file(str(path))}  {path.relative_to(return_dir)}")
    with open(manifest, "w") as f: f.write("\n".join(rows) + "\n")

def generate_metadata(df, identity, assets, route_status, blockers, bt_recs, ep_recs, predec_recs, noec_recs, lookup_recs):
    completed_routes = sum(1 for r in route_status if r["status"] in ("ok", "completed_with_partial_errors"))
    has_blockers = bool(blockers)
    if completed_routes >= 1 and not has_blockers: final_status = "COMPLETE_THREE_TOOL_BLIND_PREDICTIONS_READY_FOR_LOCAL_SCORING"
    elif completed_routes >= 1: final_status = "PARTIAL_COMPLETE_WITH_TYPED_ROUTE_BLOCKERS_READY_FOR_LOCAL_SCORING"
    else: final_status = "BLOCKED_ALL_ROUTES_FAILED"

    with open(os.path.join(RETURN_DIR, "FINAL_STATUS.txt"), "w") as f: f.write(final_status + "\n")

    readme = f"# BBD Full-Route v0.3 v3.1 Three-Tool Blind Predictions\n\nDate: 2026-08-21\nFinal Status: {final_status}\n\n## Input\n- Strict blind CSV: 93 parents\n- Archive SHA256: {identity['archive_sha256']}\n- Restricted answer key read: **false**\n\n## Routes\n"
    for r in route_status:
        readme += f"### {r['route_id']}\n- Status: {r['status']}\n- Parents with predictions: {r['parents_with_nonempty_predictions']}/{r['input_parent_count']}\n- Normalized predictions: {r['normalized_prediction_count']}\n"
        if r["typed_blocker"]: readme += f"- Blocker: `{r['typed_blocker']}`\n"
    readme += f"\n## Assets\n- BioTransformer: {assets['biotransformer']['status']}\n- enviPath: {assets['envipath']['status']}\n- ECLIPSE: {assets['eclipse']['status']} (CPU mode, 10 folds)\n\n## Notes\n- No local scoring performed.\n- enviPath database lookup kept separate from prediction.\n- Parent-copy predictions preserved with boolean flag.\n- ECLIPSE aggregated by fold frequency then mean score.\n"
    with open(os.path.join(RETURN_DIR, "README_BBD_FULL_ROUTE_V0_3_V3_1_THREE_TOOL_BLIND_PREDICTIONS.md"), "w") as f: f.write(readme)

    write_json(os.path.join(RETURN_DIR, "RUN_MANIFEST.json"), {
        "task": "bbd_full_route_v0_3_v3_1_three_tool_blind_predictions_20260821", "created_utc": utc_now(),
        "final_status": final_status, "strict_blind_rows": EXPECTED_ROWS,
        "restricted_answer_key_read": False, "scoring_performed": False,
        "routes": route_status, "blockers": blockers,
        "prediction_counts": {"biotransformer_envmicro_s1": len(bt_recs), "envipath_bbd_rules_s1": len(ep_recs),
            "eclipse_predec_bbd_finetuned_10fold_aggregated_s1": len(predec_recs),
            "eclipse_noec_bbd_finetuned_10fold_aggregated_s1": len(noec_recs), "envipath_database_lookup": len(lookup_recs)},
        "runtime_environment": {"python": sys.version, "platform": platform.platform(), "rdkit": rdBase.rdkitVersion, "gpu_available": False}})

    audit = "# Executor Audit\n\n## Compliance\n- strict blind identity verified: **true**\n- restricted answer key read: **false**\n- scoring performed: **false**\n- enviPath database lookup separate from prediction: **true**\n- no production data modified: **true**\n- no credentials packaged: **true**\n\n## Route Summary\n"
    for r in route_status: audit += f"- {r['route_id']}: {r['status']} ({r['parents_with_nonempty_predictions']}/{r['input_parent_count']})\n"
    with open(os.path.join(RETURN_DIR, "06_EXECUTOR_AUDIT/BBD_FULL_ROUTE_V0_3_V3_1_THREE_TOOL_BLIND_PREDICTIONS_EXECUTOR_AUDIT.md"), "w") as f: f.write(audit)
    return final_status

def package_and_identity(final_status):
    import tarfile
    archive_name = "bbd_full_route_v0_3_v3_1_three_tool_blind_predictions_20260821.tar.gz"
    archive_path = os.path.join(os.path.dirname(RETURN_DIR), archive_name)
    with tarfile.open(archive_path, "w:gz") as tar: tar.add(RETURN_DIR, arcname=os.path.basename(RETURN_DIR))
    archive_sha = sha256_file(archive_path)
    identity_path = archive_path + ".identity.txt"
    with open(identity_path, "w") as f:
        f.write("\n".join([f"archive_name={archive_name}", f"archive_path={archive_path}", f"created_utc={utc_now()}",
            f"final_status={final_status}", "restricted_answer_key_read=false", f"strict_blind_rows={EXPECTED_ROWS}",
            f"archive_sha256={archive_sha}"]) + "\n")
    return archive_path, identity_path

# ============================================================
# Main
# ============================================================
def main():
    os.makedirs(LOG_DIR, exist_ok=True)
    audit_logger = setup_logger("audit", "input_audit.log")
    df, identity = input_audit(audit_logger)
    asset_logger = setup_logger("asset", "asset_discovery.log")
    assets = asset_discovery(asset_logger)
    bt_logger = setup_logger("biotransformer", "biotransformer_envmicro.log")
    bt_recs, bt_success, bt_error = run_biotransformer(df, bt_logger)
    envipath_logger = setup_logger("envipath", "envipath_prediction.log")
    ep_recs, lookup_recs, ep_pred_status, ep_lookup_status = run_envipath(df, envipath_logger)
    eclipse_logger = setup_logger("eclipse", "eclipse_predec.log")
    all_preds_noec, all_preds_predec = run_eclipse(df, eclipse_logger)
    predec_recs, predec_success = aggregate_and_write_eclipse(all_preds_predec, df, eclipse_logger, "eclipse_predec", "eclipse_predec_bbd_finetuned_10fold_aggregated_s1", "eclipse_predec_bbd_finetuned_10fold_aggregated_s1")
    noec_recs, noec_success = aggregate_and_write_eclipse(all_preds_noec, df, eclipse_logger, "eclipse_noec", "eclipse_noec_bbd_finetuned_10fold_aggregated_s1", "eclipse_noec_bbd_finetuned_10fold_aggregated_s1")
    route_status, blockers = build_route_status(df, (bt_recs, bt_success, bt_error), (ep_recs, lookup_recs, ep_pred_status, ep_lookup_status), (predec_recs, predec_success), (noec_recs, noec_success))
    intermediate_dir = os.path.join(RETURN_DIR, "03_PREDICTIONS/_intermediate_eclipse")
    if os.path.exists(intermediate_dir): shutil.rmtree(intermediate_dir)
    final_status = generate_metadata(df, identity, assets, route_status, blockers, bt_recs, ep_recs, predec_recs, noec_recs, lookup_recs)
    make_manifest(RETURN_DIR)
    pkg_logger = setup_logger("pkg", "packaging.log")
    archive_path, identity_path = package_and_identity(final_status)
    pkg_logger.info(f"Archive: {archive_path}"); pkg_logger.info(f"Identity: {identity_path}")
    print(f"\n=== FINAL STATUS: {final_status} ===")
    print(f"Archive: {archive_path}")
    return final_status

if __name__ == "__main__":
    os.chdir(PROJECT_ROOT)
    raise SystemExit(main())
