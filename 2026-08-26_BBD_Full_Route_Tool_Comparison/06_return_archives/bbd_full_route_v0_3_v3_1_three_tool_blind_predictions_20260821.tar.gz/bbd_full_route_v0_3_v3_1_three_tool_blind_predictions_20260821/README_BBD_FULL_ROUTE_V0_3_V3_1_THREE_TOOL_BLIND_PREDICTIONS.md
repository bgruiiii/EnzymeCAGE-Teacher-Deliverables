# BBD Full-Route v0.3 v3.1 Three-Tool Blind Predictions

Date: 2026-08-21
Final Status: COMPLETE_THREE_TOOL_BLIND_PREDICTIONS_READY_FOR_LOCAL_SCORING

## Input
- Strict blind CSV: 93 parents
- Archive SHA256: ea9bf0497592f686013c789d42259260c2c69ba00d8a073435d6408cf2e02d90
- Restricted answer key read: **false**

## Routes
### biotransformer_envmicro_s1
- Status: ok
- Parents with predictions: 85/93
- Normalized predictions: 259
### envipath_bbd_rules_s1
- Status: ok
- Parents with predictions: 89/93
- Normalized predictions: 353
### eclipse_predec_bbd_finetuned_10fold_aggregated_s1
- Status: ok
- Parents with predictions: 93/93
- Normalized predictions: 740
### eclipse_noec_bbd_finetuned_10fold_aggregated_s1
- Status: ok
- Parents with predictions: 93/93
- Normalized predictions: 671

## Assets
- BioTransformer: available
- enviPath: available
- ECLIPSE: available (CPU mode, 10 folds)

## Notes
- No local scoring performed.
- enviPath database lookup kept separate from prediction.
- Parent-copy predictions preserved with boolean flag.
- ECLIPSE aggregated by fold frequency then mean score.
