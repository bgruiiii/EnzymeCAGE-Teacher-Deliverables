# enviPath Database Lookup Note

Separate from prediction. Lookup OK: 93, Prediction OK: 89
