# Asset Discovery Log

- BioTransformer: available
- enviPath: available
- ECLIPSE: available (CPU mode)
- GPU: unavailable (CPU mode used)
