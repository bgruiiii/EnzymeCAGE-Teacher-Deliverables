# Previous simple-path repair package identity (input audit)

- `previous_repair_archive`: `/root/projects/EnzymeCAGE-master/HPC_Returned_Result_Summaries/bbd_full_route_v0_3_v3_1_multistep_simple_path_repair_supplement_20260826.tar.gz`
- `previous_repair_archive_sha256`: `5fa02f1d566ede109a9c6d731f5dd67bfe2021c0592010e6e870b7dbed13dc4d`
- `previous_repair_archive_sha256_match`: `True`
- `previous_repair_archive_name`: `bbd_full_route_v0_3_v3_1_multistep_simple_path_repair_supplement_20260826.tar.gz`
- `extraction_root`: `/root/projects/EnzymeCAGE-master/HPC_Returned_Result_Summaries/.tmp_simple_path_repair_v2_payload`
- `input_audit_utc`: `2026-08-26T03:12:42Z`
- `allowed_input_files_present`: `32`
- `allowed_input_files_total`: `32`
- `restricted_answer_key_read`: `False`
- `scoring_performed`: `False`
