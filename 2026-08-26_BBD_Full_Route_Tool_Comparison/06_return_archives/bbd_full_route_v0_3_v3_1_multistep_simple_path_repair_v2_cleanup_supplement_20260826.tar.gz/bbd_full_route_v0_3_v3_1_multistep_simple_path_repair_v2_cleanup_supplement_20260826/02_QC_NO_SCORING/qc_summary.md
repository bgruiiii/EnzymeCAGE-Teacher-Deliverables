# QC summary — v2 cleanup (no scoring performed)

- return_folder: `/root/projects/EnzymeCAGE-master/HPC_Returned_Result_Summaries/bbd_full_route_v0_3_v3_1_multistep_simple_path_repair_v2_cleanup_supplement_20260826`
- qc_utc: `2026-08-26T03:12:43Z`

| check | result |
|---|---|
| previous_repair_archive_sha256_match | PASS |
| restricted_answer_key_read=false | PASS |
| scoring_performed=false | PASS |
| all four route directories processed | PASS |
| biotransformer_envmicro_multistep/no_zero_edge_rows | PASS |
| envipath_bbd_rules_multistep/no_zero_edge_rows | PASS |
| eclipse_predec_bbd_finetuned_10fold_multistep/no_zero_edge_rows | PASS |
| eclipse_noec_bbd_finetuned_10fold_multistep_optional/no_zero_edge_rows | PASS |
| biotransformer_envmicro_multistep/all_invariants | PASS |
| envipath_bbd_rules_multistep/all_invariants | PASS |
| eclipse_predec_bbd_finetuned_10fold_multistep/all_invariants | PASS |
| eclipse_noec_bbd_finetuned_10fold_multistep_optional/all_invariants | PASS |
| biotransformer_envmicro_multistep/defects_zero | PASS |
| biotransformer_envmicro_multistep/dup_zero_top10_ok | PASS |
| envipath_bbd_rules_multistep/defects_zero | PASS |
| envipath_bbd_rules_multistep/dup_zero_top10_ok | PASS |
| eclipse_predec_bbd_finetuned_10fold_multistep/defects_zero | PASS |
| eclipse_predec_bbd_finetuned_10fold_multistep/dup_zero_top10_ok | PASS |
| eclipse_noec_bbd_finetuned_10fold_multistep_optional/defects_zero | PASS |
| eclipse_noec_bbd_finetuned_10fold_multistep_optional/dup_zero_top10_ok | PASS |

## Counts summary

| route | retained rows | zero-edge removed | non-empty cases |
|---|---:|---:|---:|
| biotransformer_envmicro_multistep | 779 | 8 | 85 |
| envipath_bbd_rules_multistep | 745 | 5 | 88 |
| eclipse_predec_bbd_finetuned_10fold_multistep | 930 | 0 | 93 |
| eclipse_noec_bbd_finetuned_10fold_multistep_optional | 930 | 0 | 93 |
