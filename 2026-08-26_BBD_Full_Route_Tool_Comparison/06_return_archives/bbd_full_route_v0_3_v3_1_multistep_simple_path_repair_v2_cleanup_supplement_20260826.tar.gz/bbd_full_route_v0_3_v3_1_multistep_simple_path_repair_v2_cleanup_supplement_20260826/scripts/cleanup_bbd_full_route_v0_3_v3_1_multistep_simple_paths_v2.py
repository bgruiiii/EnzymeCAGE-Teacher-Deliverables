#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HPC executor-only — BBD full-route v0.3 v3.1 multistep simple-path repair
v2 cleanup supplement.

Tiny cleanup of the previous simple-path repair package:
  1. Remove every path_depth==0 / empty edge_id_path placeholder row.
  2. Recompute coverage summaries with non-empty-path definitions.
  3. Fix archive identity packaging order (no stale in-package archive sha).

Hard rules honored: no prediction tool rerun, no restricted answer read,
no scoring, no production data modification.
"""

import os
import sys
import json
import csv
import hashlib
import subprocess
import time
import logging
import traceback
import tarfile
import shutil
from collections import Counter

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------
RETURN_TOP = "/root/projects/EnzymeCAGE-master/HPC_Returned_Result_Summaries"
RETURN_NAME = "bbd_full_route_v0_3_v3_1_multistep_simple_path_repair_v2_cleanup_supplement_20260826"
RETURN_DIR = os.path.join(RETURN_TOP, RETURN_NAME)
ARCHIVE_NAME = RETURN_NAME + ".tar.gz"
ARCHIVE_PATH = os.path.join(RETURN_TOP, ARCHIVE_NAME)

PREV_TAR = os.path.join(
    RETURN_TOP,
    "bbd_full_route_v0_3_v3_1_multistep_simple_path_repair_supplement_20260826.tar.gz")
PREV_SHA256 = "5fa02f1d566ede109a9c6d731f5dd67bfe2021c0592010e6e870b7dbed13dc4d"
PREV_EXTRACT_ROOT = os.path.join(RETURN_TOP, ".tmp_simple_path_repair_v2_payload")
PREV_EXTRACT = os.path.join(
    PREV_EXTRACT_ROOT,
    "bbd_full_route_v0_3_v3_1_multistep_simple_path_repair_supplement_20260826")

STATUS_COMPLETE = "COMPLETE_MULTISTEP_SIMPLE_PATH_REPAIR_V2_CLEANUP_READY_FOR_LOCAL_AUDIT"
STATUS_PROVENANCE_NOTE = ("COMPLETE_MULTISTEP_SIMPLE_PATH_REPAIR_V2_CLEANUP_"
                          "WITH_PROVENANCE_NOTE_READY_FOR_LOCAL_AUDIT")
STATUS_FAIL = "FAIL_MULTISTEP_SIMPLE_PATH_REPAIR_V2_CLEANUP_NEEDS_REPAIR"

ROUTES = [
    {"dirname": "biotransformer_envmicro_multistep",
     "route_id": "biotransformer_envmicro_multistep",
     "tool_id": "biotransformer", "optional": False},
    {"dirname": "envipath_bbd_rules_multistep",
     "route_id": "envipath_bbd_rules_multistep",
     "tool_id": "envipath", "optional": False},
    {"dirname": "eclipse_predec_bbd_finetuned_10fold_multistep",
     "route_id": "eclipse_predec_bbd_finetuned_10fold_multistep",
     "tool_id": "eclipse_predec", "optional": False},
    {"dirname": "eclipse_noec_bbd_finetuned_10fold_multistep_optional",
     "route_id": "eclipse_noec_bbd_finetuned_10fold_multistep_optional",
     "tool_id": "eclipse_noec", "optional": True},
]


def now_utc():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False, sort_keys=True)


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n")


def load_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_csv(path, rows, fieldnames):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def setup_logger(name, fname):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fh = logging.FileHandler(os.path.join(RETURN_DIR, "logs", fname), mode="a",
                             encoding="utf-8")
    fh.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    logger.addHandler(fh)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(sh)
    return logger


# ----------------------------------------------------------------------------
# Phase: audit
# ----------------------------------------------------------------------------
def phase_audit(logger):
    audit_dir = os.path.join(RETURN_DIR, "00_INPUT_AUDIT")
    os.makedirs(audit_dir, exist_ok=True)

    actual = sha256_file(PREV_TAR)
    match = (actual == PREV_SHA256)
    logger.info("previous repair archive sha256: expected=%s actual=%s match=%s",
                PREV_SHA256, actual, match)
    if not match:
        raise SystemExit("previous repair archive sha256 mismatch (typed blocker)")

    marker = os.path.join(PREV_EXTRACT_ROOT, ".extract_done_sha256")
    need = True
    if os.path.exists(marker):
        with open(marker) as f:
            need = (f.read().strip() != actual)
    if need:
        shutil.rmtree(PREV_EXTRACT_ROOT, ignore_errors=True)
        os.makedirs(PREV_EXTRACT_ROOT, exist_ok=True)
        subprocess.run(["tar", "xzf", PREV_TAR, "-C", PREV_EXTRACT_ROOT], check=True)
        with open(marker, "w") as f:
            f.write(actual)
        logger.info("previous repair archive extracted to %s", PREV_EXTRACT_ROOT)
    else:
        logger.info("previous repair archive already extracted; reuse")

    allowed = []
    for r in ROUTES:
        base = os.path.join(PREV_EXTRACT, "01_REPAIRED_ROUTE_PATHS", r["dirname"])
        allowed += [
            os.path.join(base, "PREDICTED_ROUTE_PATHS_SIMPLE.jsonl"),
            os.path.join(base, "PREDICTED_ROUTE_PATHS_SIMPLE_TOP10_BY_CASE.csv"),
            os.path.join(base, "SIMPLE_PATH_REPAIR_SUMMARY.csv"),
            os.path.join(base, "SIMPLE_PATH_REPAIR_SUMMARY.md"),
        ]
    allowed += [
        os.path.join(PREV_EXTRACT, "README_BBD_FULL_ROUTE_V0_3_V3_1_MULTISTEP_SIMPLE_PATH_REPAIR_SUPPLEMENT.md"),
        os.path.join(PREV_EXTRACT, "RUN_MANIFEST.json"),
        os.path.join(PREV_EXTRACT, "MANIFEST.sha256"),
        os.path.join(PREV_EXTRACT, "00_INPUT_AUDIT", "previous_multistep_package_identity.json"),
        os.path.join(PREV_EXTRACT, "00_INPUT_AUDIT", "allowed_input_files_used.csv"),
        os.path.join(PREV_EXTRACT, "03_EXECUTOR_AUDIT",
                     "BBD_FULL_ROUTE_V0_3_V3_1_MULTISTEP_SIMPLE_PATH_REPAIR_SUPPLEMENT_EXECUTOR_AUDIT.md"),
        os.path.join(PREV_EXTRACT, "scripts",
                     "repair_bbd_full_route_v0_3_v3_1_multistep_simple_paths.py"),
    ]
    for qc_name in ("old_path_defect_counts.csv", "repaired_path_qc_summary.csv",
                    "actual_node_depth_summary_from_nodes_csv.csv",
                    "clean_edge_traversal_summary.csv", "path_duplicate_check.csv",
                    "qc_summary.md"):
        allowed.append(os.path.join(PREV_EXTRACT, "02_QC_NO_SCORING", qc_name))
    for lg in ("input_audit.log", "path_repair.log", "packaging.log"):
        allowed.append(os.path.join(PREV_EXTRACT, "logs", lg))

    rows = []
    for p in allowed:
        rows.append({
            "allowed_input_file": os.path.relpath(p, PREV_EXTRACT),
            "present": "present" if os.path.exists(p) else "MISSING",
            "usage": "read_only_for_v2_cleanup" if os.path.exists(p) else "unused",
        })
    write_csv(os.path.join(audit_dir, "allowed_input_files_used.csv"), rows,
              ["allowed_input_file", "present", "usage"])

    identity = {
        "previous_repair_archive": PREV_TAR,
        "previous_repair_archive_sha256": actual,
        "previous_repair_archive_sha256_match": match,
        "previous_repair_archive_name": os.path.basename(PREV_TAR),
        "extraction_root": PREV_EXTRACT_ROOT,
        "input_audit_utc": now_utc(),
        "allowed_input_files_present": sum(1 for r in rows if r["present"] == "present"),
        "allowed_input_files_total": len(rows),
        "restricted_answer_key_read": False,
        "scoring_performed": False,
    }
    write_json(os.path.join(audit_dir, "previous_repair_package_identity.json"),
               identity)
    with open(os.path.join(audit_dir, "previous_repair_package_identity.md"),
              "w", encoding="utf-8") as f:
        f.write("# Previous simple-path repair package identity (input audit)\n\n")
        for k, v in identity.items():
            f.write(f"- `{k}`: `{v}`\n")
    logger.info("input audit artifacts written (%d allowed files)", len(rows))


# ----------------------------------------------------------------------------
# Phase: cleanup
# ----------------------------------------------------------------------------
def process_route_v2(r, logger):
    base = os.path.join(PREV_EXTRACT, "01_REPAIRED_ROUTE_PATHS", r["dirname"])
    rows = load_jsonl(os.path.join(base, "PREDICTED_ROUTE_PATHS_SIMPLE.jsonl"))
    old_summary = {}
    with open(os.path.join(base, "SIMPLE_PATH_REPAIR_SUMMARY.csv"), newline="",
              encoding="utf-8") as f:
        for row in csv.DictReader(f):
            old_summary = row
            break

    removed = []
    retained = []
    for p in rows:
        depth = p.get("path_depth", 0)
        eids = p.get("edge_id_path") or []
        if depth == 0 or len(eids) == 0:
            removed.append({
                "route_id": r["route_id"], "tool_id": r["tool_id"],
                "full_route_case_id": p.get("full_route_case_id", ""),
                "path_id": p.get("path_id", ""),
                "pollutant_name": p.get("pollutant_name", ""),
                "pollutant_category": p.get("pollutant_category", ""),
                "path_depth": depth,
                "edge_id_path": json.dumps(eids),
                "reason": "root_only_zero_edge_placeholder_removed",
            })
            continue
        retained.append(p)

    removed_cases = {x["full_route_case_id"] for x in removed}
    retained_cases = {p["full_route_case_id"] for p in retained}
    root_only_cases = sorted(removed_cases - retained_cases)

    # re-rank within case (ranks stay contiguous after removal)
    per_case = {}
    for p in retained:
        per_case.setdefault(p["full_route_case_id"], []).append(p)
    for cid, lst in per_case.items():
        lst.sort(key=lambda p: int(p.get("path_rank_within_case", 999)))
        for idx, p in enumerate(lst, 1):
            p["path_rank_within_case"] = idx
            p["path_id"] = f"{cid}__sp{idx:02d}"

    depth_cases = Counter()
    for p in retained:
        depth_cases[p["path_depth"]] = depth_cases.get(p["path_depth"], 0)
    # per-case: does the case have a simple path with exactly depth k?
    case_max_depth = {}
    for p in retained:
        c = p["full_route_case_id"]
        case_max_depth[c] = max(case_max_depth.get(c, 0), p["path_depth"])
    depth_coverage = {k: 0 for k in range(1, 7)}
    for c, dmax in case_max_depth.items():
        for k in range(1, dmax + 1):
            depth_coverage[k] += 1
    max_depth = max((p["path_depth"] for p in retained), default=0)

    # defect recount on retained rows
    rep_n = rep_s = rep_e = 0
    for p in retained:
        nids = p.get("compound_node_id_path") or []
        smis = p.get("compound_smiles_canonical_path") or []
        eids = p.get("edge_id_path") or []
        if len(nids) != len(set(nids)):
            rep_n += 1
        if len(smis) != len(set(smis)):
            rep_s += 1
        if len(eids) != len(set(eids)):
            rep_e += 1
        assert len(nids) == p["path_depth"] + 1
        assert len(smis) == p["path_depth"] + 1
        assert len(eids) == p["path_depth"]

    # write V2 outputs
    out_base = os.path.join(RETURN_DIR, "01_REPAIRED_ROUTE_PATHS_V2", r["dirname"])
    os.makedirs(out_base, exist_ok=True)
    write_jsonl(os.path.join(out_base, "PREDICTED_ROUTE_PATHS_SIMPLE_V2.jsonl"),
                retained)
    csv_rows = []
    for p in retained:
        row = dict(p)
        for k in ("compound_node_id_path", "compound_smiles_canonical_path",
                  "compound_inchikey_path", "edge_id_path", "edge_score_raw_path",
                  "edge_score_semantics_path"):
            row[k] = json.dumps(row[k])
        csv_rows.append(row)
    csv_fields = ["full_route_case_id", "scope", "pollutant_name",
                  "pollutant_category", "tool_id", "route_id", "optional_route",
                  "path_id", "path_rank_within_case", "path_depth",
                  "compound_node_id_path", "compound_smiles_canonical_path",
                  "compound_inchikey_path", "edge_id_path", "edge_score_raw_path",
                  "edge_score_semantics_path", "path_score_raw",
                  "path_score_semantics", "path_status", "stopped_reason",
                  "simple_path_valid", "has_repeated_node_id",
                  "has_repeated_smiles_canonical", "has_repeated_edge_id",
                  "contains_parent_copy_edge", "contains_source_self_loop_edge",
                  "restricted_answer_key_read", "scoring_performed"]
    write_csv(os.path.join(out_base,
                           "PREDICTED_ROUTE_PATHS_SIMPLE_V2_TOP10_BY_CASE.csv"),
              csv_rows, csv_fields)

    metrics = {
        "route_id": r["route_id"], "tool_id": r["tool_id"],
        "optional_route": bool(r["optional"]),
        "simple_path_rows": len(retained),
        "cases_with_any_simple_path": len(retained_cases),
        "cases_with_nonempty_simple_path": len(retained_cases),
        "cases_with_root_only_no_clean_path": len(root_only_cases),
        "cases_with_depth_1_simple_path": depth_coverage[1],
        "cases_with_depth_2_simple_path": depth_coverage[2],
        "cases_with_depth_3_simple_path": depth_coverage[3],
        "cases_with_depth_4_simple_path": depth_coverage[4],
        "cases_with_depth_5_simple_path": depth_coverage[5],
        "cases_with_depth_6_simple_path": depth_coverage[6],
        "max_simple_path_depth": max_depth,
        "repaired_repeated_node_path_count": rep_n,
        "repaired_repeated_smiles_path_count": rep_s,
        "repaired_repeated_edge_path_count": rep_e,
        "all_contains_parent_copy_edge_false": all(
            not p["contains_parent_copy_edge"] for p in retained),
        "all_contains_source_self_loop_edge_false": all(
            not p["contains_source_self_loop_edge"] for p in retained),
    }
    summary_fields = ["route_id", "tool_id", "optional_route",
                      "simple_path_rows", "cases_with_any_simple_path",
                      "cases_with_nonempty_simple_path",
                      "cases_with_root_only_no_clean_path",
                      "cases_with_depth_1_simple_path",
                      "cases_with_depth_2_simple_path",
                      "cases_with_depth_3_simple_path",
                      "cases_with_depth_4_simple_path",
                      "cases_with_depth_5_simple_path",
                      "cases_with_depth_6_simple_path", "max_simple_path_depth",
                      "repaired_repeated_node_path_count",
                      "repaired_repeated_smiles_path_count",
                      "repaired_repeated_edge_path_count",
                      "all_contains_parent_copy_edge_false",
                      "all_contains_source_self_loop_edge_false"]
    write_csv(os.path.join(out_base, "SIMPLE_PATH_REPAIR_V2_SUMMARY.csv"),
              [metrics], summary_fields)
    with open(os.path.join(out_base, "SIMPLE_PATH_REPAIR_V2_SUMMARY.md"), "w",
              encoding="utf-8") as f:
        f.write(f"# Simple-path repair v2 summary — {r['route_id']}\n\n")
        for k in summary_fields:
            f.write(f"- `{k}`: `{metrics[k]}`\n")
    logger.info("%s: old=%d removed=%d retained=%d nonempty_cases=%d root_only_cases=%d "
                "defects(n=%d,s=%d,e=%d)",
                r["route_id"], len(rows), len(removed), len(retained),
                len(retained_cases), len(root_only_cases), rep_n, rep_s, rep_e)
    return {
        "rows_old": len(rows), "removed": removed, "retained": retained,
        "metrics": metrics, "root_only_cases": root_only_cases,
        "old_summary": old_summary,
    }


def phase_cleanup(logger):
    ensure = ["00_INPUT_AUDIT", "01_REPAIRED_ROUTE_PATHS_V2", "02_QC_NO_SCORING",
              "03_EXECUTOR_AUDIT"]
    for s in ensure:
        os.makedirs(os.path.join(RETURN_DIR, s), exist_ok=True)
    results = {}
    for r in ROUTES:
        results[r["route_id"]] = process_route_v2(r, logger)
    return results


# ----------------------------------------------------------------------------
# Phase: qc
# ----------------------------------------------------------------------------
def phase_qc(logger, results):
    qc_dir = os.path.join(RETURN_DIR, "02_QC_NO_SCORING")
    removed_all = []
    for r in ROUTES:
        removed_all.extend(results[r["route_id"]]["removed"])
    write_csv(os.path.join(qc_dir, "zero_edge_rows_removed.csv"), removed_all,
              ["route_id", "tool_id", "full_route_case_id", "path_id",
               "pollutant_name", "pollutant_category", "path_depth",
               "edge_id_path", "reason"])

    coverage_rows = []
    for r in ROUTES:
        res = results[r["route_id"]]
        m = res["metrics"]
        coverage_rows.append({
            "route_id": r["route_id"], "tool_id": r["tool_id"],
            "optional_route": r["optional"],
            "input_parent_count": res["old_summary"].get("input_parent_count", ""),
            "old_simple_path_rows": res["rows_old"],
            "zero_edge_rows_removed": len(res["removed"]),
            "retained_simple_path_rows": len(res["retained"]),
            "old_cases_with_any_path_including_root_only":
                res["old_summary"].get("cases_with_any_simple_path", ""),
            "cases_with_nonempty_simple_path": m["cases_with_nonempty_simple_path"],
            "cases_with_root_only_no_clean_path": m["cases_with_root_only_no_clean_path"],
            "max_simple_path_depth": m["max_simple_path_depth"],
            "restricted_answer_key_read": False,
            "scoring_performed": False,
        })
    write_csv(os.path.join(qc_dir, "corrected_path_coverage_summary.csv"),
              coverage_rows,
              ["route_id", "tool_id", "optional_route", "input_parent_count",
               "old_simple_path_rows", "zero_edge_rows_removed",
               "retained_simple_path_rows",
               "old_cases_with_any_path_including_root_only",
               "cases_with_nonempty_simple_path",
               "cases_with_root_only_no_clean_path", "max_simple_path_depth",
               "restricted_answer_key_read", "scoring_performed"])

    qc_rows = []
    for r in ROUTES:
        res = results[r["route_id"]]
        m = res["metrics"]
        retained = res["retained"]
        qc_rows.append({
            "route_id": r["route_id"],
            "simple_path_rows_v2": len(retained),
            "all_path_depth_ge_1": all(p["path_depth"] >= 1 for p in retained),
            "all_edge_id_path_nonempty": all(len(p["edge_id_path"]) >= 1
                                             for p in retained),
            "all_simple_path_valid": all(p["simple_path_valid"] is True
                                         for p in retained),
            "repaired_repeated_node_path_count":
                m["repaired_repeated_node_path_count"],
            "repaired_repeated_smiles_path_count":
                m["repaired_repeated_smiles_path_count"],
            "repaired_repeated_edge_path_count":
                m["repaired_repeated_edge_path_count"],
            "all_contains_parent_copy_edge_false":
                m["all_contains_parent_copy_edge_false"],
            "all_contains_source_self_loop_edge_false":
                m["all_contains_source_self_loop_edge_false"],
        })
    write_csv(os.path.join(qc_dir, "repaired_path_v2_qc_summary.csv"), qc_rows,
              ["route_id", "simple_path_rows_v2", "all_path_depth_ge_1",
               "all_edge_id_path_nonempty", "all_simple_path_valid",
               "repaired_repeated_node_path_count",
               "repaired_repeated_smiles_path_count",
               "repaired_repeated_edge_path_count",
               "all_contains_parent_copy_edge_false",
               "all_contains_source_self_loop_edge_false"])

    dup_rows = []
    for r in ROUTES:
        res = results[r["route_id"]]
        retained = res["retained"]
        per_case = {}
        for p in retained:
            per_case.setdefault(p["full_route_case_id"], []).append(p)
        exceeding = 0
        seen = set()
        dup = 0
        for cid, lst in per_case.items():
            if len(lst) > 10:
                exceeding += 1
            for p in lst:
                key = (cid, tuple(p["compound_smiles_canonical_path"]))
                if key in seen:
                    dup += 1
                seen.add(key)
        dup_rows.append({
            "route_id": r["route_id"],
            "simple_path_rows_v2": len(retained),
            "unique_case_smiles_path_count": len(seen),
            "duplicate_case_smiles_path_rows": dup,
            "max_paths_per_case": 10,
            "cases_exceeding_top10": exceeding,
        })
    write_csv(os.path.join(qc_dir, "path_duplicate_check_v2.csv"), dup_rows,
              ["route_id", "simple_path_rows_v2", "unique_case_smiles_path_count",
               "duplicate_case_smiles_path_rows", "max_paths_per_case",
               "cases_exceeding_top10"])

    checks = [("previous_repair_archive_sha256_match", True, ""),
              ("restricted_answer_key_read=false", True, ""),
              ("scoring_performed=false", True, ""),
              ("all four route directories processed", True, "")]
    for r in ROUTES:
        res = results[r["route_id"]]
        retained = res["retained"]
        ok_depth = all(p["path_depth"] >= 1 and len(p["edge_id_path"]) >= 1
                       for p in retained)
        checks.append((f"{r['route_id']}/no_zero_edge_rows", ok_depth, ""))
    for r in ROUTES:
        res = results[r["route_id"]]
        retained = res["retained"]
        checks.append((f"{r['route_id']}/all_invariants",
                       all(p["simple_path_valid"] is True
                           and not p["has_repeated_node_id"]
                           and not p["has_repeated_smiles_canonical"]
                           and not p["has_repeated_edge_id"]
                           and not p["contains_parent_copy_edge"]
                           and not p["contains_source_self_loop_edge"]
                           and p["path_depth"] == len(p["edge_id_path"])
                           and len(p["compound_node_id_path"]) == len(p["edge_id_path"]) + 1
                           and len(p["compound_smiles_canonical_path"]) == len(p["edge_id_path"]) + 1
                           for p in retained), ""))
    for i, r in enumerate(ROUTES):
        res = results[r["route_id"]]
        m = res["metrics"]
        checks.append((f"{r['route_id']}/defects_zero",
                       m["repaired_repeated_node_path_count"] == 0
                       and m["repaired_repeated_smiles_path_count"] == 0
                       and m["repaired_repeated_edge_path_count"] == 0, ""))
        checks.append((f"{r['route_id']}/dup_zero_top10_ok",
                       dup_rows[i]["duplicate_case_smiles_path_rows"] == 0
                       and dup_rows[i]["cases_exceeding_top10"] == 0, ""))

    all_pass = all(c[1] for c in checks)
    with open(os.path.join(qc_dir, "qc_summary.md"), "w", encoding="utf-8") as f:
        f.write("# QC summary — v2 cleanup (no scoring performed)\n\n")
        f.write(f"- return_folder: `{RETURN_DIR}`\n")
        f.write(f"- qc_utc: `{now_utc()}`\n")
        f.write("\n| check | result |\n|---|---|\n")
        for name, res, _note in checks:
            f.write(f"| {name} | {'PASS' if res else 'FAIL'} |\n")
        f.write("\n## Counts summary\n\n")
        f.write("| route | retained rows | zero-edge removed | non-empty cases |\n")
        f.write("|---|---:|---:|---:|\n")
        for r in ROUTES:
            res = results[r["route_id"]]
            m = res["metrics"]
            f.write(f"| {r['route_id']} | {len(res['retained'])} "
                    f"| {len(res['removed'])} "
                    f"| {m['cases_with_nonempty_simple_path']} |\n")
    logger.info("QC artifacts written (checks=%d all_pass=%s)",
                len(checks), all_pass)
    return checks, all_pass, dup_rows


# ----------------------------------------------------------------------------
# Phase: docs
# ----------------------------------------------------------------------------
def phase_docs(logger, results, checks, all_pass):
    if all_pass:
        status = STATUS_COMPLETE
    else:
        status = STATUS_FAIL
    with open(os.path.join(RETURN_DIR, "FINAL_STATUS.txt"), "w",
              encoding="utf-8") as f:
        f.write(status + "\n")

    readme = os.path.join(
        RETURN_DIR,
        "README_BBD_FULL_ROUTE_V0_3_V3_1_MULTISTEP_SIMPLE_PATH_REPAIR_V2_CLEANUP_SUPPLEMENT.md")
    with open(readme, "w", encoding="utf-8") as f:
        f.write("# README — BBD full-route v0.3 v3.1 multistep simple-path repair "
                "v2 cleanup supplement 2026-08-26\n\n")
        f.write(f"- return_folder: `{RETURN_DIR}`\n")
        f.write(f"- FINAL_STATUS: `{status}`\n")
        f.write(f"- previous_repair_archive_sha256: `{PREV_SHA256}`\n")
        f.write("- task: remove zero-edge root-only placeholder path rows, recompute "
                "non-empty-path coverage, fix archive identity packaging order\n")
        f.write("- no scoring performed\n")
        f.write("- restricted_answer_key_read=false\n")
        f.write("- archive_sha256 fields inside this package are not reported; "
                "final archive SHA256 is recorded in the identity sidecar only "
                "(`archive_sha256_recorded_in_sidecar_only=true`)\n\n")
        f.write("## Cleanup result\n\n")
        f.write("| route_id | old rows | zero-edge removed | retained rows | "
                "non-empty cases |\n|---|---:|---:|---:|---:|\n")
        for r in ROUTES:
            res = results[r["route_id"]]
            m = res["metrics"]
            f.write(f"| {r['route_id']} | {res['rows_old']} | {len(res['removed'])} "
                    f"| {len(res['retained'])} "
                    f"| {m['cases_with_nonempty_simple_path']} |\n")

    run_manifest = {
        "run_name": RETURN_NAME,
        "run_utc": now_utc(),
        "task_type": "multistep_simple_path_repair_v2_cleanup_supplement",
        "previous_repair_archive_sha256": PREV_SHA256,
        "final_status": status,
        "restricted_answer_key_read": False,
        "scoring_performed": False,
        "archive_sha256_recorded_in_sidecar_only": True,
        "routes": {r["route_id"]: {
            "optional_route": r["optional"],
            "zero_edge_rows_removed": len(results[r["route_id"]]["removed"]),
            "retained_simple_path_rows": len(results[r["route_id"]]["retained"]),
            "cases_with_nonempty_simple_path":
                results[r["route_id"]]["metrics"]["cases_with_nonempty_simple_path"],
        } for r in ROUTES},
        "qc_checks": {c[0]: ("PASS" if c[1] else "FAIL") for c in checks},
    }
    write_json(os.path.join(RETURN_DIR, "RUN_MANIFEST.json"), run_manifest)

    audit_path = os.path.join(
        RETURN_DIR, "03_EXECUTOR_AUDIT",
        "BBD_FULL_ROUTE_V0_3_V3_1_MULTISTEP_SIMPLE_PATH_REPAIR_V2_CLEANUP_SUPPLEMENT_EXECUTOR_AUDIT.md")
    with open(audit_path, "w", encoding="utf-8") as f:
        f.write("# Executor audit — simple-path repair v2 cleanup supplement 2026-08-26\n\n")
        f.write(f"- executor: chenyu / HPC\n- audit_utc: `{now_utc()}`\n")
        f.write(f"- FINAL_STATUS: `{status}`\n")
        f.write("- previous_repair_archive_sha256_match=true\n")
        f.write("- restricted_answer_key_read=false\n")
        f.write("- scoring_performed=false\n")
        f.write("- archive_sha256_recorded_in_sidecar_only=true (no stale "
                "in-package archive SHA256)\n\n")
        f.write("## Acceptance checks\n\n| check | result |\n|---|---|\n")
        for name, res, _note in checks:
            f.write(f"| {name} | {'PASS' if res else 'FAIL'} |\n")
        f.write("\n## Zero-edge rows removed\n\n")
        for r in ROUTES:
            res = results[r["route_id"]]
            for x in res["removed"]:
                f.write(f"- `{x['path_id']}` ({x['route_id']}) "
                        f"depth={x['path_depth']} reason={x['reason']}\n")
        f.write("\n## Packaging order (v2 fixed)\n\n")
        f.write("1. all files written; 2. logs finalized; 3. MANIFEST.sha256; "
                "4. sha256sum -c verified; 5. tar.gz; 6. archive SHA256 into "
                "identity sidecar; 7. no in-package archive SHA256.\n")
    logger.info("docs + FINAL_STATUS written: %s", status)
    return status


# ----------------------------------------------------------------------------
# Phase: package
# ----------------------------------------------------------------------------
def phase_package(logger, status):
    pyc = os.path.join(RETURN_DIR, "scripts", "__pycache__")
    if os.path.isdir(pyc):
        shutil.rmtree(pyc, ignore_errors=True)
    files = []
    for root, dirs, names in os.walk(RETURN_DIR):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for n in names:
            if n == "MANIFEST.sha256" or n.endswith(".pyc"):
                continue
            full = os.path.join(root, n)
            files.append((os.path.relpath(full, RETURN_DIR), full))
    with open(os.path.join(RETURN_DIR, "MANIFEST.sha256"), "w") as f:
        for rel, full in sorted(files):
            f.write(f"{sha256_file(full)}  {rel}\n")
    proc = subprocess.run(["sha256sum", "-c", "MANIFEST.sha256"], cwd=RETURN_DIR,
                          capture_output=True, text=True)
    manifest_ok = (proc.returncode == 0)
    print(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [INFO] MANIFEST entries={len(files)} "
          f"verify={'PASS' if manifest_ok else 'FAIL'}")
    if not manifest_ok:
        print(proc.stdout[-2000:])

    if os.path.exists(ARCHIVE_PATH):
        os.remove(ARCHIVE_PATH)
    tar_cmd = ["tar", "czf", ARCHIVE_PATH, "--exclude=__pycache__",
               "--exclude=*.pyc", "-C", RETURN_TOP, RETURN_NAME]
    try:
        subprocess.run(tar_cmd, check=True)
    except Exception:
        print("system tar failed; fallback tarfile module")
        with tarfile.open(ARCHIVE_PATH, "w:gz") as t:
            def filt(member):
                if "__pycache__" in member.name or member.name.endswith(".pyc"):
                    return None
                return member
            t.add(RETURN_DIR, arcname=RETURN_NAME, filter=filt)
    archive_sha = sha256_file(ARCHIVE_PATH)
    archive_bytes = os.path.getsize(ARCHIVE_PATH)

    sidecar = ARCHIVE_PATH + ".identity.txt"
    with open(sidecar, "w", encoding="utf-8") as f:
        f.write(f"{archive_sha}  {ARCHIVE_NAME}\n")
        f.write(f"archive_name={ARCHIVE_NAME}\n")
        f.write(f"archive_path={ARCHIVE_PATH}\n")
        f.write(f"created_utc={now_utc()}\n")
        f.write(f"final_status={status}\n")
        f.write("restricted_answer_key_read=false\n")
        f.write("scoring_performed=false\n")
        f.write("archive_sha256_recorded_in_sidecar_only=true\n")
    # stdout only from here on; return folder must stay immutable for MANIFEST
    print(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [INFO] archive sha256={archive_sha} "
          f"bytes={archive_bytes}")
    print(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [INFO] identity sidecar: {sidecar}")


def main():
    phase = "all"
    if "--phase" in sys.argv:
        phase = sys.argv[sys.argv.index("--phase") + 1]
    t0 = time.time()
    try:
        cleanup_log = setup_logger("v2_cleanup", "v2_cleanup.log")
        results = checks = dup_rows = None
        status = None
        if phase in ("all", "audit"):
            audit_log = setup_logger("input_audit", "input_audit.log")
            phase_audit(audit_log)
        if phase in ("all", "cleanup"):
            results = phase_cleanup(cleanup_log)
        if phase in ("all", "qc"):
            if results is None:
                raise SystemExit("need --phase cleanup first")
            checks, all_pass, dup_rows = phase_qc(cleanup_log, results)
        elif phase == "qc":
            raise SystemExit("need --phase cleanup first")
        if phase in ("all", "docs"):
            if results is None or checks is None:
                raise SystemExit("need cleanup/qc outputs first")
            status = phase_docs(cleanup_log, results, checks, all_pass)
        if phase == "package":
            with open(os.path.join(RETURN_DIR, "FINAL_STATUS.txt")) as s:
                status = s.read().strip()
            pkg_log = setup_logger("packaging", "packaging.log")
            pkg_log.info("=== packaging (v2 order: logs final -> MANIFEST -> verify -> tar -> sidecar) ===")
            pkg_log.info("return_folder=%s", RETURN_DIR)
            phase_package(pkg_log, status)
        elif phase == "all":
            cleanup_log.info("all compute phases done in %.1fs (packaging follows)",
                             time.time() - t0)
            pkg_log = setup_logger("packaging", "packaging.log")
            pkg_log.info("=== packaging (v2 order: logs final -> MANIFEST -> verify -> tar -> sidecar) ===")
            pkg_log.info("return_folder=%s", RETURN_DIR)
            phase_package(pkg_log, status)
            # no logging after packaging; logs must stay immutable
        if phase not in ("all", "audit", "cleanup", "qc", "docs", "package"):
            raise SystemExit(f"unknown phase: {phase}")
        print(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [INFO] v2 cleanup phase={phase} finished")
    except Exception:
        logging.error("pipeline failed: %s", traceback.format_exc())
        sys.exit(2)


if __name__ == "__main__":
    main()