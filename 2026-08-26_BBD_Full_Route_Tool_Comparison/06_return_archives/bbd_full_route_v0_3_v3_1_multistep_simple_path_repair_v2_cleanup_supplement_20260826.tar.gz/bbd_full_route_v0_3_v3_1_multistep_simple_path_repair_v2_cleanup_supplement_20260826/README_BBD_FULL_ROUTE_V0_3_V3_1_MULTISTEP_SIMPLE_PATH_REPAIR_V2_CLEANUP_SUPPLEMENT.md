# README — BBD full-route v0.3 v3.1 multistep simple-path repair v2 cleanup supplement 2026-08-26

- return_folder: `/root/projects/EnzymeCAGE-master/HPC_Returned_Result_Summaries/bbd_full_route_v0_3_v3_1_multistep_simple_path_repair_v2_cleanup_supplement_20260826`
- FINAL_STATUS: `COMPLETE_MULTISTEP_SIMPLE_PATH_REPAIR_V2_CLEANUP_READY_FOR_LOCAL_AUDIT`
- previous_repair_archive_sha256: `5fa02f1d566ede109a9c6d731f5dd67bfe2021c0592010e6e870b7dbed13dc4d`
- task: remove zero-edge root-only placeholder path rows, recompute non-empty-path coverage, fix archive identity packaging order
- no scoring performed
- restricted_answer_key_read=false
- archive_sha256 fields inside this package are not reported; final archive SHA256 is recorded in the identity sidecar only (`archive_sha256_recorded_in_sidecar_only=true`)

## Cleanup result

| route_id | old rows | zero-edge removed | retained rows | non-empty cases |
|---|---:|---:|---:|---:|
| biotransformer_envmicro_multistep | 787 | 8 | 779 | 85 |
| envipath_bbd_rules_multistep | 750 | 5 | 745 | 88 |
| eclipse_predec_bbd_finetuned_10fold_multistep | 930 | 0 | 930 | 93 |
| eclipse_noec_bbd_finetuned_10fold_multistep_optional | 930 | 0 | 930 | 93 |
