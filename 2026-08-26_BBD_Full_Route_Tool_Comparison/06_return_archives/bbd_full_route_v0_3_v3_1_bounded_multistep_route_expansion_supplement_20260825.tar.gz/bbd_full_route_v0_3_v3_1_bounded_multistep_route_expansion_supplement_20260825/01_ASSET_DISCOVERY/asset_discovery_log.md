# Asset Discovery Log

- BioTransformer: available
- enviPath: available
- ECLIPSE: available (CPU mode, 10 folds)
- Multi-step mode: bounded expansion, max_depth=6, frontier_cap=10, child_cap=10
