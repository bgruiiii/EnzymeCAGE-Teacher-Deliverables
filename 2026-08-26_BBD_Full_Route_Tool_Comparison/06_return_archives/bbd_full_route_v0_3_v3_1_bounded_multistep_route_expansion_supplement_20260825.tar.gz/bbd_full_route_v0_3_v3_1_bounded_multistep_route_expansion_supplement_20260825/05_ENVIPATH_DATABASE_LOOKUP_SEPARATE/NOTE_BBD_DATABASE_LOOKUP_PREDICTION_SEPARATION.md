# enviPath database lookup / prediction separation note

The optional legacy BBD database lookup is intentionally kept separate from prediction and was NOT executed in this supplement. All enviPath work here is prediction-only (multi-generation tree extraction + frontier graft extension through the validated legacy predict endpoint). Restricted answer data was not accessed.
