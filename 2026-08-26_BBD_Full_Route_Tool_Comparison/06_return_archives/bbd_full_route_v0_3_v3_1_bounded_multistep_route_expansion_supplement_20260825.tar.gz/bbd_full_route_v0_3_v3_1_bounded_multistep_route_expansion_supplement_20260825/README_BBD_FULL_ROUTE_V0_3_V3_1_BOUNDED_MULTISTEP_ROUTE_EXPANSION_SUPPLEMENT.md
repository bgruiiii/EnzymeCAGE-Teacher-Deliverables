# BBD full-route v0.3 v3.1 bounded multi-step route-expansion supplement

Final status: **COMPLETE_BOUNDED_MULTISTEP_ROUTE_EXPANSION_READY_FOR_LOCAL_SCORING**

## Input identity
- Strict blind archive: `/root/projects/EnzymeCAGE-master/HPC_Inputs/bbd_known_pathway_full_route_v0_3_candidate_v3_1_strict_blind_fix_20260821.tar.gz` (SHA256 verified: `ea9bf0497592f686013c789d42259260c2c69ba00d8a073435d6408cf2e02d90`)
- Strict blind CSV rows: 93
- Restricted answer key read: **false**
- Scoring performed: **false**

## Expansion policy
- max_depth_requested=6, frontier_cap=10, child_cap=10
- Depth-1 layers reuse the previous compliant s1 package where present; deeper layers are fresh bounded predictions.
- No local scoring: edge and path scores are tool-local only.

## Routes
- `biotransformer_envmicro_multistep`: status=ok, max_depth_reached=6, depth6=80, edges=8069, paths=786
- `envipath_bbd_rules_multistep`: status=ok, max_depth_reached=6, depth6=41, edges=2932, paths=745
- `eclipse_predec_bbd_finetuned_10fold_multistep`: status=ok, max_depth_reached=6, depth6=93, edges=29530, paths=930

## File map
- `00_INPUT_AUDIT/` - strict blind identity + previous s1 package identity
- `01_ASSET_DISCOVERY/` - tool asset identities
- `02_ROUTE_STATUS/` - route status summary + typed blockers
- `03_ROUTE_EXPANSION/<route>/` - PREDICTED_ROUTE_EDGES.jsonl / NODES.csv / PATHS.jsonl / ROUTE_EXPANSION_SUMMARY.* + raw
- `04_QC_ONLY_NO_SCORING/` - depth distribution, frontier sizes, invalid/copy/cycle rows
- `05_ENVIPATH_DATABASE_LOOKUP_SEPARATE/` - lookup/prediction separation note
- `06_EXECUTOR_AUDIT/` - executor audit
- `scripts/` `logs/` - implementation and logs

