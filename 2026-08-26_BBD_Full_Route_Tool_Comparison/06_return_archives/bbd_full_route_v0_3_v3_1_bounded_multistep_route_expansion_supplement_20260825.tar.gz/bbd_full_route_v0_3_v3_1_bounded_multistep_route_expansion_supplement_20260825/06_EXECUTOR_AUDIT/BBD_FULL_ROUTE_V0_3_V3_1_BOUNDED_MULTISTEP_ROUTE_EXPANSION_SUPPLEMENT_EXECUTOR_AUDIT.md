# Executor audit - BBD full-route v0.3 v3.1 bounded multi-step route-expansion supplement

- Executed: 2026-08-26T02:02:41Z
- Host: 8ecc1bb56dd7, cwd: /root/projects/EnzymeCAGE-master
- Method: strict blind, no answer-key access, no local scoring.
- Expansion: bounded iterative expansion (max_depth=6, frontier cap=10, child cap=10) per case per route.
- Depth-1 layers reuse the previous compliant s1 package files; all depth>=2 layers are fresh predictions.

## Route execution notes
- `biotransformer_envmicro_multistep`: max_depth_reached=6, depth6=80, edges=8069, paths=786
- `envipath_bbd_rules_multistep`: max_depth_reached=6, depth6=41, edges=2932, paths=745
- `eclipse_predec_bbd_finetuned_10fold_multistep`: max_depth_reached=6, depth6=93, edges=29530, paths=930

## Typed blockers (if any)
- `eclipse_noec`: eclipse_noec_multistep_status=completed_with_partial_depth_runtime_cap_reached

## Compliance
- restricted_answer_key_read=false
- scoring_performed=false
- Production data (results/, dataset/, feature/): untouched by this run.
- No model retraining performed.

