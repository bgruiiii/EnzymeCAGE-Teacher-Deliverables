#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BBD full-route v0.3 v3.1 bounded multi-step route-expansion supplement (2026-08-25).

Executor-only blind supplement. Builds bounded predicted route graphs by iteratively
expanding predicted products (max_depth=6, frontier cap=10, children cap=10) with:
  1. BioTransformer ENVMICRO: iterative one-step java calls (source node depth d -> children depth d+1)
  2. enviPath BBD Rules: multi-generation tree extraction (Option 1) + frontier graft extension
     over the same validated legacy predict endpoint
  3. BBD-finetuned ECLIPSE 10-fold PREDEC (required) + NoEC (optional diagnostic)

No local scoring. Restricted answer key is never read. Depth-1 layers reuse the previous
compliant first-step package where available and are flagged accordingly.
"""
import os, sys, json, hashlib, csv, subprocess, time, logging, traceback, platform
import math, heapq
import shutil, gc
from collections import defaultdict, Counter
from argparse import Namespace, ArgumentParser
from pathlib import Path
import pandas as pd
import numpy as np
from rdkit import Chem, rdBase
from rdkit.Chem import MolToSmiles, MolFromSmiles, MolToInchiKey

PROJECT_ROOT = "/root/projects/EnzymeCAGE-master"
SUMMARIES = os.path.join(PROJECT_ROOT, "HPC_Returned_Result_Summaries")
RETURN_NAME = "bbd_full_route_v0_3_v3_1_bounded_multistep_route_expansion_supplement_20260825"
RETURN_DIR = os.path.join(SUMMARIES, RETURN_NAME)
STATE_DIR = os.path.join(RETURN_DIR, ".state")
LOG_DIR = os.path.join(RETURN_DIR, "logs")
EXPANSION_DIR = os.path.join(RETURN_DIR, "03_ROUTE_EXPANSION")

PREV_DIR = os.path.join(SUMMARIES, "bbd_full_route_v0_3_v3_1_three_tool_blind_predictions_20260821")
PREV_ARCHIVE = os.path.join(SUMMARIES, "bbd_full_route_v0_3_v3_1_three_tool_blind_predictions_20260821.tar.gz")
PREV_ARCHIVE_SHA256 = "5eee73713a3034c75e44e149874758146f69f3d6ee83f91bfc2536a5170e6f5f"
PREV_BT_JSONL = os.path.join(PREV_DIR, "03_PREDICTIONS/biotransformer_envmicro_s1/PREDICTIONS_NORMALIZED.jsonl")
PREV_BT_RAW = os.path.join(PREV_DIR, "03_PREDICTIONS/biotransformer_envmicro_s1/raw")
PREV_ENV_RAW = os.path.join(PREV_DIR, "03_PREDICTIONS/envipath_bbd_rules_s1/raw")
PREV_ECL_PREDEC_CSV = os.path.join(PREV_DIR, "03_PREDICTIONS/eclipse_predec_bbd_finetuned_10fold_aggregated_s1/PREDICTIONS_NORMALIZED.csv")
PREV_ECL_NOEC_CSV = os.path.join(PREV_DIR, "03_PREDICTIONS/eclipse_noec_bbd_finetuned_10fold_aggregated_s1/PREDICTIONS_NORMALIZED.csv")

ARCHIVE_PATH = os.path.join(PROJECT_ROOT, "HPC_Inputs/bbd_known_pathway_full_route_v0_3_candidate_v3_1_strict_blind_fix_20260821.tar.gz")
ARCHIVE_SHA256 = "ea9bf0497592f686013c789d42259260c2c69ba00d8a073435d6408cf2e02d90"
BLIND_CSV_NAME = "BBD_KNOWN_PATHWAY_FULL_ROUTE_V0_3_V3_1_BLIND_PARENT_INPUTS_FOR_PREDICTION_STRICT.csv"
BLIND_SHA256 = "be11658b0ede11093bb8bb833281994cb2f507629eaf7b3524de74a4e46acb66"
BLIND_BYTES = 20776
EXPECTED_ROWS = 93
EXPECTED_COLUMNS = [
    "full_route_case_id", "scope", "pollutant_name", "pollutant_category",
    "parent_smiles", "parent_canonical_smiles", "input_note",
]

MAX_DEPTH = 6
FRONTIER_CAP = 10
CHILD_CAP = 10
ECLIPSE_FOLDS = 10
ECLIPSE_BATCH = 64
NOEC_WALL_CAP_SEC = 5 * 3600  # a-priori runtime control for the OPTIONAL route only
ENV_SLEEP = 1.0
PATH_SEM = {"bt": "no_score", "env": "path_probability_product",
            "eclipse": "sum_of_edge_mean_beam_log_likelihood_along_best_path"}
EDGE_SEM = {"bt": "no_score", "env": "multi_generation_edge_probability",
            "eclipse": "fold_frequency_then_mean_beam_log_likelihood"}

BT_JAR = "/tmp/enzymecage_m3_p1_2_1_three_tool_valid_single_parent_biotransformer_envmicro_prediction_rerun1_20260728/Biotransformer/target/biotransformer-3.0.0.jar"
BT_DIR = "/tmp/enzymecage_m3_p1_2_1_three_tool_valid_single_parent_biotransformer_envmicro_prediction_rerun1_20260728/Biotransformer"

ENV_BASE = "https://envipath.org/api/legacy/"
ENV_SEARCH = "https://envipath.org/api/legacy/search"
ENV_UTIL = "https://envipath.org/api/legacy/util"
ENV_SETTING = "https://envipath.org/setting/a0fbc3d8-ca45-44f1-9c3c-80d8531ffe25"
ENV_SETTING_NAME = "Global Setting - BBD Rules"
ENV_PACKAGE = "https://envipath.org/package/32de3cf4-e3e6-4168-956e-32fa5ddb0ce1"
ENV_FILE = os.path.join(PROJECT_ROOT, "HPC_Inputs/envipath_account_env.local.sh")

ECLIPSE_BASE = os.path.join(PROJECT_ROOT, "results/ECLIPSEProdModel")
HIERARCHY_PATH = os.path.join(PROJECT_ROOT, "results/summary/hierarchy.csv")

ROUTES = [
    {"key": "biotransformer", "tool_id": "biotransformer_envmicro",
     "route_id": "biotransformer_envmicro_multistep", "dirname": "biotransformer_envmicro_multistep",
     "kind": "bt", "optional": False},
    {"key": "envipath", "tool_id": "envipath_prediction",
     "route_id": "envipath_bbd_rules_multistep", "dirname": "envipath_bbd_rules_multistep",
     "kind": "env", "optional": False},
    {"key": "eclipse_predec", "tool_id": "eclipse_predec",
     "route_id": "eclipse_predec_bbd_finetuned_10fold_multistep", "dirname": "eclipse_predec_bbd_finetuned_10fold_multistep",
     "kind": "eclipse", "use_enzyme": True, "optional": False},
    {"key": "eclipse_noec", "tool_id": "eclipse_noec",
     "route_id": "eclipse_noec_bbd_finetuned_10fold_multistep_optional", "dirname": "eclipse_noec_bbd_finetuned_10fold_multistep_optional",
     "kind": "eclipse", "use_enzyme": False, "optional": True, "wall_cap": NOEC_WALL_CAP_SEC},
]
SPEC_BY_KEY = {r["key"]: r for r in ROUTES}

# ============================================================
# Utilities
# ============================================================
def canon(smiles):
    if not smiles:
        return ""
    mol = MolFromSmiles(str(smiles))
    if mol is None:
        return ""
    return MolToSmiles(mol, canonical=True, isomericSmiles=True)

def inchikey_of(smiles):
    mol = MolFromSmiles(str(smiles)) if smiles else None
    if mol is None:
        return ""
    return MolToInchiKey(mol)

def sha256_file(path):
    if not os.path.exists(path):
        return ""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, sort_keys=True, indent=2)

def write_jsonl(path, records):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        for rec in records:
            f.write(json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n")

def load_json(path):
    with open(path) as f:
        return json.load(f)

def safe_error(text, limit=1600):
    if text is None:
        return ""
    sanitized = str(text)
    for v in os.environ.get("ENVIPATH_PASSWORD", ""), os.environ.get("ENVIPATH_USERNAME", ""):
        if v:
            sanitized = sanitized.replace(v, "[REDACTED_CREDENTIAL]")
    return sanitized[:limit]

def setup_logger(name, fname):
    os.makedirs(LOG_DIR, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fh = logging.FileHandler(os.path.join(LOG_DIR, fname), mode="w")
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(fh)
    sh = logging.StreamHandler()
    sh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(sh)
    return logger

def ensure_table_dirs():
    for sub in ["00_INPUT_AUDIT", "01_ASSET_DISCOVERY", "02_ROUTE_STATUS", "04_QC_ONLY_NO_SCORING",
                "05_ENVIPATH_DATABASE_LOOKUP_SEPARATE", "06_EXECUTOR_AUDIT", "scripts", "logs"]:
        os.makedirs(os.path.join(RETURN_DIR, sub), exist_ok=True)
    for spec in ROUTES:
        os.makedirs(os.path.join(EXPANSION_DIR, spec["dirname"], "raw"), exist_ok=True)
        os.makedirs(os.path.join(EXPANSION_DIR, spec["dirname"], "raw_or_intermediate"), exist_ok=True)

# ============================================================
# Input audit + asset discovery
# ============================================================
def load_blind():
    p = os.path.join(RETURN_DIR, "00_INPUT_AUDIT/copied_strict_blind_input.csv")
    if not os.path.exists(p):
        raise RuntimeError("blind csv copy missing - run audit first")
    df = pd.read_csv(p)
    assert list(df.columns) == EXPECTED_COLUMNS and len(df) == EXPECTED_ROWS
    return df

def phase_audit(logger):
    logger.info("=== Phase: input audit ===")
    os.makedirs(os.path.join(RETURN_DIR, "00_INPUT_AUDIT"), exist_ok=True)
    os.makedirs(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY"), exist_ok=True)
    arch_sha = sha256_file(ARCHIVE_PATH)
    arch_ok = arch_sha == ARCHIVE_SHA256
    logger.info(f"Archive SHA256: {arch_sha} match={arch_ok}")
    if not arch_ok:
        raise RuntimeError("strict blind archive SHA mismatch")

    extract_dir = os.path.join(RETURN_DIR, ".tmp_extract")
    os.makedirs(extract_dir, exist_ok=True)
    result = subprocess.run(["tar", "-xzf", ARCHIVE_PATH, "-C", extract_dir,
                             "--wildcards", f"*/blind/{BLIND_CSV_NAME}"], capture_output=True, text=True, timeout=120)
    blind_csv = None
    for p in Path(extract_dir).rglob(BLIND_CSV_NAME):
        blind_csv = str(p)
        break
    if blind_csv is None:
        raise RuntimeError(f"could not extract {BLIND_CSV_NAME}: {result.stderr[:300]}")
    blind_sha = sha256_file(blind_csv)
    blind_size = os.path.getsize(blind_csv)
    blind_ok = blind_sha == BLIND_SHA256 and blind_size == BLIND_BYTES
    logger.info(f"Blind CSV SHA256: {blind_sha} bytes={blind_size} match={blind_ok}")
    df = pd.read_csv(blind_csv)
    cols_ok = list(df.columns) == EXPECTED_COLUMNS
    rows_ok = len(df) == EXPECTED_ROWS
    if not (blind_ok and cols_ok and rows_ok):
        raise RuntimeError("strict blind CSV identity FAILED")

    shutil.copy2(blind_csv, os.path.join(RETURN_DIR, "00_INPUT_AUDIT/copied_strict_blind_input.csv"))
    identity = {
        "archive_sha256": arch_sha, "archive_sha256_expected": ARCHIVE_SHA256, "archive_sha256_match": arch_ok,
        "blind_csv_sha256": blind_sha, "blind_csv_sha256_expected": BLIND_SHA256, "blind_csv_sha256_match": blind_ok,
        "blind_csv_bytes": blind_size, "blind_csv_bytes_expected": BLIND_BYTES,
        "blind_csv_rows": int(len(df)), "blind_csv_rows_expected": EXPECTED_ROWS, "blind_csv_rows_match": rows_ok,
        "blind_csv_columns_match": cols_ok, "expected_columns": EXPECTED_COLUMNS,
        "restricted_answer_key_read": False, "input_audit_pass": True,
        "input_archive_path": ARCHIVE_PATH,
    }
    write_json(os.path.join(RETURN_DIR, "00_INPUT_AUDIT/strict_blind_identity.json"), identity)
    with open(os.path.join(RETURN_DIR, "00_INPUT_AUDIT/strict_blind_identity.md"), "w") as f:
        f.write("# Strict Blind Input Identity\n\n- Archive SHA256 match: **%s**\n- Blind CSV SHA256 match: **%s**\n"
                "- Rows: %d (expected %d)\n- Columns match: **%s**\n- Restricted answer key read: **false**\n"
                % (arch_ok, blind_ok, len(df), EXPECTED_ROWS, cols_ok))

    prev_sha = sha256_file(PREV_ARCHIVE)
    prev_ok = prev_sha == PREV_ARCHIVE_SHA256
    prev_id = {
        "previous_s1_archive": PREV_ARCHIVE,
        "previous_s1_archive_sha256": prev_sha,
        "previous_s1_archive_sha256_expected": PREV_ARCHIVE_SHA256,
        "previous_s1_archive_sha256_match": prev_ok,
        "previous_s1_extracted_dir_exists": os.path.isdir(PREV_DIR),
        "reused_depth1_files": {
            "biotransformer_envmicro_s1_normalized_jsonl": os.path.exists(PREV_BT_JSONL),
            "envipath_bbd_rules_s1_raw_json_dir": os.path.isdir(PREV_ENV_RAW),
            "eclipse_predec_s1_normalized_csv": os.path.exists(PREV_ECL_PREDEC_CSV),
            "eclipse_noec_s1_normalized_csv": os.path.exists(PREV_ECL_NOEC_CSV),
        },
        "restricted_answer_key_read": False, "treated_as_unscored_prediction_output": True,
    }
    write_json(os.path.join(RETURN_DIR, "00_INPUT_AUDIT/previous_s1_prediction_package_identity.json"), prev_id)
    logger.info(f"Previous s1 package SHA match={prev_ok}")
    shutil.rmtree(extract_dir, ignore_errors=True)
    return df, identity

def phase_assets(logger):
    logger.info("=== Phase: asset discovery ===")
    assets = {}
    bt_ok = os.path.exists(BT_JAR) and os.path.isdir(os.path.join(BT_DIR, "database"))
    java_ver = subprocess.run(["java", "-version"], capture_output=True, text=True, timeout=10)
    assets["biotransformer"] = {
        "jar_path": BT_JAR, "jar_sha256": sha256_file(BT_JAR), "jar_bytes": os.path.getsize(BT_JAR) if os.path.exists(BT_JAR) else 0,
        "bt_dir": BT_DIR, "database_exists": os.path.isdir(os.path.join(BT_DIR, "database")),
        "java_version": (java_ver.stderr.strip().split("\n")[0] if java_ver.returncode == 0 else "NOT FOUND"),
        "repository": "https://github.com/Wishartlab-openscience/Biotransformer.git",
        "commit": "7149f7ec6b2f32f9f789bab53aa4a71db49e59e2",
        "expansion_mode": "iterative_one_step_calls_per_source_node_-s_1",
        "status": "available" if bt_ok else "blocked",
    }
    write_json(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY/biotransformer_asset_identity.json"), assets["biotransformer"])

    env_file_exists = os.path.exists(ENV_FILE)
    assets["envipath"] = {
        "credential_file_exists": env_file_exists, "credentials_filled": False,
        "base_url": ENV_BASE, "prediction_setting_id": ENV_SETTING,
        "prediction_setting_name": ENV_SETTING_NAME, "eawag_bbd_package": ENV_PACKAGE,
        "expansion_mode": "multi_generation_tree_extraction_option_1_plus_frontier_graft_extension",
        "status": "available" if env_file_exists else "blocked_missing_credentials",
    }
    if env_file_exists:
        result = subprocess.run(["bash", "-c", f"source {ENV_FILE} && echo ${{#ENVIPATH_USERNAME}} ${{#ENVIPATH_PASSWORD}}"],
                                capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            parts = result.stdout.strip().split()
            if len(parts) == 2:
                assets["envipath"]["credentials_filled"] = (int(parts[0]) > 0 and int(parts[1]) > 0)
    write_json(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY/envipath_asset_identity.json"), assets["envipath"])

    eclipse_folds = []
    all_ok = True
    for fold in range(ECLIPSE_FOLDS):
        fold_dir = os.path.join(ECLIPSE_BASE, f"bbd_40_3_{fold}_uspto_rdkit")
        ckpt_dir = os.path.join(fold_dir, "expert/checkpoints")
        model_pkl = os.path.join(fold_dir, "eclipse/model.pkl")
        fi = {"fold": fold, "dir": fold_dir,
              "config_exists": os.path.exists(os.path.join(fold_dir, "config.json")),
              "tokens_exists": os.path.exists(os.path.join(fold_dir, "tokens.json")),
              "split_exists": os.path.exists(os.path.join(fold_dir, "split_bbd.json")),
              "checkpoint": "", "checkpoint_bytes": 0,
              "model_pkl_exists": os.path.exists(model_pkl),
              "model_pkl_bytes": os.path.getsize(model_pkl) if os.path.exists(model_pkl) else 0}
        if os.path.isdir(ckpt_dir):
            ckpts = sorted([f for f in os.listdir(ckpt_dir) if f.endswith(".ckpt")])
            if ckpts:
                fi["checkpoint"] = os.path.join(ckpt_dir, ckpts[0])
                fi["checkpoint_bytes"] = os.path.getsize(fi["checkpoint"])
        if not all(fi[k] for k in ["config_exists", "tokens_exists", "split_exists"]):
            all_ok = False
        eclipse_folds.append(fi)
    try:
        import torch
        cuda_ok = torch.cuda.is_available()
        torch_ver = torch.__version__
    except Exception:
        cuda_ok, torch_ver = False, "n/a"
    assets["eclipse"] = {
        "folds": eclipse_folds, "fold_count": ECLIPSE_FOLDS, "all_folds_available": all_ok,
        "hierarchy_path": HIERARCHY_PATH, "hierarchy_exists": os.path.exists(HIERARCHY_PATH),
        "torch_version": torch_ver, "cuda_available": bool(cuda_ok), "inference_device": "cpu",
        "expansion_mode": "10fold_batched_inference_per_depth_frontier", "gpu_available": bool(cuda_ok),
        "status": "available" if all_ok else "blocked",
    }
    write_json(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY/eclipse_asset_identity.json"), assets["eclipse"])
    with open(os.path.join(RETURN_DIR, "01_ASSET_DISCOVERY/asset_discovery_log.md"), "w") as f:
        f.write("# Asset Discovery Log\n\n"
                "- BioTransformer: %s\n- enviPath: %s\n- ECLIPSE: %s (CPU mode, %d folds)\n"
                "- Multi-step mode: bounded expansion, max_depth=%d, frontier_cap=%d, child_cap=%d\n"
                % (assets["biotransformer"]["status"], assets["envipath"]["status"],
                   assets["eclipse"]["status"], ECLIPSE_FOLDS, MAX_DEPTH, FRONTIER_CAP, CHILD_CAP))
    return assets

# ============================================================
# Case graph machinery (shared by all routes)
# ============================================================
def new_graph(row, spec):
    case_id = row["full_route_case_id"]
    parent_node = f"{case_id}__n00000"
    return {
        "case_id": case_id, "scope": row["scope"], "pollutant_name": row["pollutant_name"],
        "pollutant_category": row["pollutant_category"],
        "parent_raw": str(row["parent_smiles"]), "parent_canonical": canon(str(row["parent_canonical_smiles"])),
        "route_id": spec["route_id"], "tool_id": spec["tool_id"], "kind": spec["kind"],
        "nodes": {parent_node: {
            "node_id": parent_node, "depth_first_seen": 0,
            "smiles_raw_first_seen": str(row["parent_smiles"]),
            "smiles_canonical": canon(str(row["parent_canonical_smiles"])),
            "inchikey": inchikey_of(str(row["parent_canonical_smiles"])),
            "is_original_parent": True, "is_frontier_expanded": False,
            "first_source_node_id": "", "best_path_score_raw": 0.0,
            "best_path_score_semantics": PATH_SEM[spec["kind"]],
            "seen_count": 1, "invalid_reason": "", "expansion_outcome": ""}},
        "seen": {canon(str(row["parent_canonical_smiles"])): parent_node},
        "frontier": {"0": [parent_node]},
        "expanded": [], "stop": None, "depth_stats": {},
        "max_depth_seen": 0, "node_seq": 1, "edge_seq": 0, "edges": [],
    }

def sort_key_of(kind, cand):
    if kind == "bt":
        return (cand["rank_from_source"], cand["_seq"])
    if kind == "env":
        return (-(cand["score_raw"] or 0.0), cand["_seq"])
    if kind == "eclipse":
        return (-(cand["fold_count"] or 0), -(cand["score_raw"] or 0.0), cand["_seq"])
    return (cand["_seq"],)

def make_edge(g, spec, src_id, d, cand, target_node_id, grank, canon_t, src_copy, parent_copy, cycle, valid):
    src = g["nodes"][src_id]
    raw_target = cand.get("raw", "")
    canon_c = cand.get("canonical") or ""
    g["edge_seq"] += 1
    eid = f"{g['case_id']}__e{g['edge_seq']:05d}"
    return {
        "full_route_case_id": g["case_id"], "scope": g["scope"],
        "pollutant_name": g["pollutant_name"], "pollutant_category": g["pollutant_category"],
        "tool_id": g["tool_id"], "route_id": g["route_id"],
        "original_parent_smiles": g["parent_raw"], "original_parent_canonical_smiles": g["parent_canonical"],
        "source_node_id": src_id, "target_node_id": target_node_id,
        "source_depth": d, "target_depth": d + 1,
        "source_smiles_raw": src["smiles_raw_first_seen"], "source_smiles_canonical": src["smiles_canonical"],
        "target_smiles_raw": raw_target, "target_smiles_canonical": canon_c,
        "target_inchikey": inchikey_of(canon_c) if canon_c else "",
        "edge_rank_from_source": cand.get("rank_from_source", -1),
        "edge_rank_global_within_case_depth": grank,
        "path_score_raw": 0.0, "path_score_semantics": PATH_SEM[spec["kind"]],
        "local_edge_score_raw": cand.get("score_raw", 0.0),
        "local_edge_score_semantics": cand.get("score_semantics", ""),
        "fold_id": cand.get("fold_id", 0), "fold_count": cand.get("fold_count", 1),
        "predicted_ec_raw": cand.get("predicted_ec_raw", "") or "",
        "ec_source": cand.get("ec_source", "") or "",
        "raw_output_ref": cand.get("raw_output_ref", "") or "",
        "normalization_status": "ok" if valid else "invalid_target_smiles",
        "source_status": "ok",
        "target_is_source_copy": bool(src_copy), "target_is_original_parent_copy": bool(parent_copy),
        "cycle_or_seen_before": bool(cycle), "expanded_to_next_depth": False,
        "edge_id": eid, "discovery_seq": cand.get("_seq", -1),
        "prediction_origin": cand.get("prediction_origin", ""),
        "rule_name": cand.get("rule_name", ""), "rule_url": cand.get("rule_url", ""),
    }

def process_case_depth(g, spec, d, results):
    """Expand frontier at depth d using per-source results; produce edges + depth d+1 frontier."""
    srcs = g["frontier"].get(str(d), [])
    expanded_set = set(g["expanded"])
    pool = {}
    n_blocked = 0
    n_invalid = 0
    blockers = []
    for src_id in srcs:
        node = g["nodes"][src_id]
        if src_id in expanded_set:
            continue
        expanded_set.add(src_id)
        r = results.get(src_id)
        if r is None or r.get("status") == "blocked":
            n_blocked += 1
            node["expansion_outcome"] = "tool_blocked_for_frontier"
            blockers.append({"full_route_case_id": g["case_id"], "route_id": g["route_id"],
                             "source_node_id": src_id, "source_depth": d,
                             "source_smiles_canonical": node["smiles_canonical"],
                             "blocker_type": (r or {}).get("blocker", "missing_result")})
            continue
        node["expansion_outcome"] = "expanded"
        n_valid = 0
        for idx, c in enumerate(r.get("children", [])):
            raw_smi = c.get("raw", "")
            canon_c = c.get("canonical") or ""
            if not canon_c:
                n_invalid += 1
                g["edges"].append(make_edge(g, spec, src_id, d, c, "", idx, "", False, False, False, False))
                continue
            n_valid += 1
            cand = dict(c)
            cand["src_id"] = src_id
            cand["_seq"] = idx
            cand["_sort"] = sort_key_of(spec["kind"], cand)
            existing = pool.get(canon_c)
            if existing is None or cand["_sort"] < existing["_sort"]:
                pool[canon_c] = cand
    g["expanded"] = sorted(expanded_set)
    g["depth_stats"][str(d)] = {"frontier_size": len(srcs), "sources_expanded": len(expanded_set),
                                "sources_blocked": n_blocked, "children_invalid": n_invalid,
                                "children_valid_unique": len(pool)}
    ranked = sorted(pool.values(), key=lambda x: x["_sort"])
    new_node_ids = []
    for grank, cand in enumerate(ranked):
        canon_c = cand["canonical"]
        src_node = g["nodes"][cand["src_id"]]
        src_canon = src_node["smiles_canonical"]
        seen_id = g["seen"].get(canon_c)
        src_copy = (canon_c == src_canon)
        parent_copy = (canon_c == g["parent_canonical"])
        if seen_id is None:
            nid = f"{g['case_id']}__n{g['node_seq']:05d}"
            g["node_seq"] += 1
            g["nodes"][nid] = {
                "node_id": nid, "depth_first_seen": d + 1,
                "smiles_raw_first_seen": cand["raw"], "smiles_canonical": canon_c,
                "inchikey": inchikey_of(canon_c), "is_original_parent": False,
                "is_frontier_expanded": False, "first_source_node_id": cand["src_id"],
                "best_path_score_raw": 0.0, "best_path_score_semantics": PATH_SEM[spec["kind"]],
                "seen_count": 1, "invalid_reason": "", "expansion_outcome": ""}
            g["seen"][canon_c] = nid
            new_node_ids.append(nid)
            cycle = False
            seen_id = nid
        else:
            if seen_id:
                g["nodes"][seen_id]["seen_count"] = g["nodes"][seen_id].get("seen_count", 1) + 1
            cycle = True
        g["edges"].append(make_edge(g, spec, cand["src_id"], d, cand, seen_id or "", grank,
                                    canon_c, src_copy, parent_copy, cycle, valid=True))
    frontier_next = new_node_ids[:FRONTIER_CAP]
    g["frontier"][str(d + 1)] = frontier_next
    frontier_set = set(frontier_next)
    for e in g["edges"]:
        if not e.get("expanded_to_next_depth") and e["target_node_id"] in frontier_set:
            e["expanded_to_next_depth"] = True
    # seen-only sources: children all valid but none new
    for src_id in srcs:
        node = g["nodes"][src_id]
        if node["expansion_outcome"] == "expanded":
            n_valid_src = sum(1 for c in results.get(src_id, {}).get("children", []) if c.get("canonical"))
            n_new_src = sum(1 for e in g["edges"] if e["source_node_id"] == src_id and e["source_depth"] == d
                            and e["target_node_id"].startswith(g["case_id"])
                            and not e["cycle_or_seen_before"])
            if n_valid_src > 0 and n_new_src == 0:
                node["expansion_outcome"] = "all_candidates_seen_before"
    if not frontier_next:
        if n_blocked >= len(srcs):
            reason = "tool_blocked_for_frontier"
        elif n_invalid > 0 and len(pool) == 0:
            reason = "all_candidates_invalid"
        elif len(pool) > 0:
            reason = "all_candidates_seen_before"
        else:
            reason = "frontier_empty"
        g["stop"] = {"depth": d + 1, "reason": reason}
    else:
        g["stop"] = None
    g["max_depth_seen"] = max(g["max_depth_seen"], d + 1)
    g["depth_stats"][str(d)]["next_frontier_size"] = len(frontier_next)
    g["depth_stats"][str(d)]["case_stop_reason"] = (g["stop"] or {}).get("reason", "")
    return blockers

def load_graphs(spec):
    state_f = os.path.join(STATE_DIR, spec["key"], "graphs.json")
    if os.path.exists(state_f):
        return json.load(open(state_f))
    return {}

def save_graphs(spec, graphs):
    state_f = os.path.join(STATE_DIR, spec["key"], "graphs.json")
    os.makedirs(os.path.dirname(state_f), exist_ok=True)
    with open(state_f, "w") as f:
        json.dump(graphs, f, sort_keys=True)

def write_route_files(spec, graphs, logger):
    out_dir = os.path.join(EXPANSION_DIR, spec["dirname"])
    edges = []
    nodes = []
    for g in graphs.values():
        edges.extend(g["edges"])
        nodes.extend(g["nodes"].values())
    write_jsonl(os.path.join(out_dir, "PREDICTED_ROUTE_EDGES.jsonl"), edges)
    node_rows = []
    for n in nodes:
        node_rows.append({
            "full_route_case_id": n["node_id"].split("__n")[0], "tool_id": spec["tool_id"],
            "route_id": spec["route_id"], "node_id": n["node_id"],
            "depth_first_seen": n["depth_first_seen"], "smiles_raw_first_seen": n["smiles_raw_first_seen"],
            "smiles_canonical": n["smiles_canonical"], "inchikey": n["inchikey"],
            "is_original_parent": n["is_original_parent"], "is_frontier_expanded": n["is_frontier_expanded"],
            "first_source_node_id": n["first_source_node_id"],
            "best_path_score_raw": n["best_path_score_raw"], "best_path_score_semantics": n["best_path_score_semantics"],
            "seen_count": n["seen_count"], "invalid_reason": n["invalid_reason"],
            "expansion_outcome": n["expansion_outcome"]})
    pd.DataFrame(node_rows).to_csv(os.path.join(out_dir, "PREDICTED_ROUTE_NODES.csv"), index=False)
    logger.info(f"{spec['route_id']}: {len(edges)} edges, {len(node_rows)} nodes written (path scores finalized later)")

# ============================================================
# Route 1: BioTransformer ENVMICRO
# ============================================================
def parse_bt_csv(path):
    try:
        bdf = pd.read_csv(path)
    except Exception:
        return None, "blocked_csv_parse_error"
    if "SMILES" not in bdf.columns:
        return [], "ok_empty"
    children = []
    seen = set()
    for smi in bdf["SMILES"].dropna():
        raw = str(smi)
        c = canon(raw)
        if not c:
            children.append({"raw": raw, "canonical": "", "score_raw": 0.0, "score_semantics": EDGE_SEM["bt"],
                             "rank_from_source": -1, "fold_id": 0, "fold_count": 1,
                             "predicted_ec_raw": "", "ec_source": "", "raw_output_ref": "", "prediction_origin": ""})
            continue
        if c in seen:
            continue
        seen.add(c)
        children.append({"raw": raw, "canonical": c, "score_raw": 0.0, "score_semantics": EDGE_SEM["bt"],
                         "rank_from_source": len(seen) - 1, "fold_id": 0, "fold_count": 1,
                         "predicted_ec_raw": "", "ec_source": "", "raw_output_ref": "",
                         "prediction_origin": "biotransformer_envmicro_jar_s1_call"})
    return children[:35], "ok"

def run_bt(df, logger):
    spec = SPEC_BY_KEY["biotransformer"]
    out_dir = os.path.join(EXPANSION_DIR, spec["dirname"])
    raw_base = os.path.join(out_dir, "raw")
    state_dir = os.path.join(STATE_DIR, spec["key"])
    cache_f = os.path.join(state_dir, "bt_cache.json")
    os.makedirs(state_dir, exist_ok=True)
    logger.info("=== BioTransformer ENVMICRO multi-step ===")
    graphs = load_graphs(spec)
    cache = load_json(cache_f) if os.path.exists(cache_f) else {}
    if not graphs:
        for _, row in df.iterrows():
            graphs[row["full_route_case_id"]] = new_graph(row, spec)
    prev_by_case = {}
    if os.path.exists(PREV_BT_JSONL):
        for line in open(PREV_BT_JSONL):
            r = json.loads(line)
            prev_by_case.setdefault(r["full_route_case_id"], []).append(r)
    logger.info(f"BT: previous s1 depth-1 rows for {len(prev_by_case)} cases; the rest gets fresh calls")
    blockers_out = []
    for d in range(0, MAX_DEPTH):
        results = {}
        any_source = False
        for case_id, g in graphs.items():
            for src_id in g["frontier"].get(str(d), []):
                if src_id in g["expanded"]:
                    continue
                any_source = True
                node = g["nodes"][src_id]
                src_canon = node["smiles_canonical"]
                raw_dir = os.path.join(raw_base, case_id, f"depth_{d}")
                os.makedirs(raw_dir, exist_ok=True)
                raw_path = os.path.join(raw_dir, f"source_{src_id}.csv")
                rel_raw = f"03_ROUTE_EXPANSION/{spec['dirname']}/raw/{case_id}/depth_{d}/source_{src_id}.csv"
                if d == 0 and case_id in prev_by_case:
                    children = []
                    for r in prev_by_case[case_id]:
                        children.append({"raw": r.get("predicted_product_smiles_raw", ""),
                                         "canonical": r.get("predicted_product_smiles_canonical", ""),
                                         "score_raw": 0.0, "score_semantics": EDGE_SEM["bt"],
                                         "rank_from_source": int(r.get("prediction_rank", 1)) - 1,
                                         "fold_id": 0, "fold_count": 1, "predicted_ec_raw": "", "ec_source": "",
                                         "raw_output_ref": rel_raw,
                                         "prediction_origin": "previous_s1_reuse_depth1"})
                    prev_raw = os.path.join(PREV_BT_RAW, f"{case_id}.csv")
                    if os.path.exists(prev_raw):
                        shutil.copy2(prev_raw, raw_path)
                    results[src_id] = {"status": "ok", "children": children[:CHILD_CAP], "raw_output_ref": rel_raw}
                    continue
                if src_canon in cache:
                    cached = cache[src_canon]
                    src_file = cached.get("raw_path")
                    if src_file and os.path.exists(src_file):
                        shutil.copy2(src_file, raw_path)
                    children = []
                    for ch in cached["children"]:
                        cc = dict(ch)
                        cc["raw_output_ref"] = rel_raw
                        children.append(cc)
                    results[src_id] = {"status": "ok", "children": children[:CHILD_CAP + 15],
                                       "raw_output_ref": rel_raw}
                    continue
                tmp_out = os.path.join(state_dir, f"tmp_{os.getpid()}.csv")
                cmd = ["java", "-jar", BT_JAR, "-k", "pred", "-b", "env", "-ismi", src_canon,
                       "-ocsv", tmp_out, "-s", "1"]
                try:
                    res = subprocess.run(cmd, capture_output=True, text=True, timeout=90, cwd=BT_DIR)
                    if res.returncode == 0 and os.path.exists(tmp_out) and os.path.getsize(tmp_out) > 0:
                        children, status = parse_bt_csv(tmp_out)
                        shutil.copy2(tmp_out, raw_path)
                        if status == "blocked_csv_parse_error":
                            results[src_id] = {"status": "blocked",
                                               "blocker": "biotransformer_status=blocked_csv_parse_error", "children": []}
                        else:
                            for ch in children:
                                ch["raw_output_ref"] = rel_raw
                            cache[src_canon] = {"children": children, "raw_path": raw_path}
                            results[src_id] = {"status": "ok", "children": children[:CHILD_CAP + 15],
                                               "raw_output_ref": rel_raw}
                    else:
                        err = safe_error(res.stderr)
                        results[src_id] = {"status": "blocked",
                                           "blocker": "biotransformer_status=blocked_jar_runtime_error", "children": []}
                        logger.warning(f"BT blocked {case_id} depth {d} {src_canon[:60]}: {err[:200]}")
                except Exception as ex:
                    results[src_id] = {"status": "blocked", "blocker": "biotransformer_status=blocked_jar_exception",
                                       "children": []}
                    logger.warning(f"BT exception {case_id} depth {d}: {ex}")
        if not any_source:
            logger.info(f"BT: no sources at depth {d}; expansion finished")
            break
        for case_id, g in graphs.items():
            if g["frontier"].get(str(d)):
                blockers_out.extend(process_case_depth(g, spec, d, results))
        if blockers_out:
            write_jsonl(os.path.join(out_dir, "_source_blockers.jsonl"), blockers_out)
        save_graphs(spec, graphs)
        write_json(cache_f, cache)
        n_tot = sum(len(g["edges"]) for g in graphs.values())
        logger.info(f"BT depth {d} done: edges={n_tot} cache={len(cache)}")
    # final-depth frontier nodes: max_depth_reached outcome
    for g in graphs.values():
        fd = g["frontier"].get(str(MAX_DEPTH), [])
        for nid in fd:
            g["nodes"][nid]["expansion_outcome"] = g["nodes"][nid]["expansion_outcome"] or "max_depth_reached"
        if not g["stop"] and fd:
            g["stop"] = {"depth": MAX_DEPTH, "reason": "max_depth_reached"}
    write_route_files(spec, graphs, logger)
    write_json(os.path.join(state_dir, "route_meta.json"), {
        "cache_size": len(cache), "depth1_source": "previous_s1_reuse_with_fresh_retries"})
    logger.info(f"BT route done: {len(graphs)} cases")
    return graphs

# ============================================================
# Route 2: enviPath BBD Rules
# ============================================================
def parse_env_api_json(record):
    """Return (children_by_canon(dict canon -> list|None), blocked) for an API prediction record."""
    jj = record.get("json") or {}
    if not isinstance(jj, dict) or record.get("http_status") != 200:
        return None, True
    raw_nodes = jj.get("nodes") or []
    raw_edges = jj.get("edges") or []
    if not isinstance(raw_nodes, list) or not isinstance(raw_edges, list) or not raw_nodes:
        return {}, False  # empty tree: root has no children (known-empty on retry handled by caller)
    nodes = {}
    for n in raw_nodes:
        if isinstance(n, dict) and n.get("id") is not None:
            nodes[n["id"]] = n
    edges = []
    for e in raw_edges:
        if not isinstance(e, dict):
            continue
        fr = e.get("from")
        rule = e.get("rule")
        for to_id in (e.get("to") or []):
            edges.append((fr, to_id, e.get("probability"), rule))
    if 0 not in nodes:
        return {}, False
    adj = defaultdict(list)
    for fr, to_id, prob, rule in edges:
        if fr in nodes:
            adj[fr].append((to_id, prob, rule))
    dist = {0: 0}
    q = [0]
    while q:
        x = q.pop(0)
        for y, _, _ in adj.get(x, []):
            if y not in dist:
                dist[y] = dist[x] + 1
                q.append(y)
    maxd = max(dist.values()) if dist else 0
    children_by_canon = {}
    for nid, n in nodes.items():
        c = canon(n.get("smiles"))
        if not c:
            continue
        out = adj.get(nid, [])
        if not out:
            if dist.get(nid) == maxd:
                children_by_canon[c] = None  # deepest layer: graft-extension eligible
            else:
                children_by_canon.setdefault(c, [])
            continue
        lst = children_by_canon.setdefault(c, [])
        for to_id, prob, rule in out:
            tn = nodes.get(to_id, {})
            tsmiles = tn.get("smiles", "")
            rule_name = rule.get("name") if isinstance(rule, dict) else None
            rule_url = rule.get("url") if isinstance(rule, dict) else None
            lst.append((tsmiles, prob, rule_name, rule_url))
    return children_by_canon, False

def run_envipath(df, logger):
    spec = SPEC_BY_KEY["envipath"]
    out_dir = os.path.join(EXPANSION_DIR, spec["dirname"])
    raw_base = os.path.join(out_dir, "raw")
    state_dir = os.path.join(STATE_DIR, spec["key"])
    children_map_f = os.path.join(state_dir, "children_map.json")
    parsed_f = os.path.join(state_dir, "parsed_cases.json")
    meta_f = os.path.join(state_dir, "route_meta.json")
    os.makedirs(state_dir, exist_ok=True)
    logger.info("=== enviPath BBD Rules multi-step ===")
    graphs = load_graphs(spec)
    if not graphs:
        for _, row in df.iterrows():
            graphs[row["full_route_case_id"]] = new_graph(row, spec)
    if os.path.exists(children_map_f):
        children_map = json.load(open(children_map_f))
        parsed_cases = set(load_json(parsed_f))
    else:
        children_map = {}
        parsed_cases = set()
    for case_id in df["full_route_case_id"]:
        if case_id in parsed_cases:
            continue
        parent_node = f"{case_id}__n00000"
        f = os.path.join(PREV_ENV_RAW, f"{case_id}.json")
        raw_dir = os.path.join(raw_base, case_id, "depth_0")
        os.makedirs(raw_dir, exist_ok=True)
        raw_path = os.path.join(raw_dir, f"source_{parent_node}.json")
        if os.path.exists(f):
            shutil.copy2(f, raw_path)
            record = load_json(f)
        else:
            record = {"json": None, "http_status": 0, "error_message_sanitized": "previous_raw_missing"}
        cbm, _blocked = parse_env_api_json(record)
        if cbm is not None:
            for ck, cv in cbm.items():
                if ck not in children_map or children_map[ck] is None:
                    children_map[ck] = cv
            pc = canon(str(graphs[case_id]["parent_canonical"]))
            if pc not in children_map:
                children_map[pc] = None
        parsed_cases.add(case_id)
    write_json(children_map_f, children_map)
    write_json(parsed_f, sorted(parsed_cases))
    logger.info(f"enviPath: tree graphs parsed for {len(parsed_cases)} cases; unique canonicals: {len(children_map)}")

    online = False
    session = None
    ext_blocked_cache = {}
    try:
        import requests
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        session = requests.Session()
        retry = Retry(total=0, connect=1, backoff_factor=0.5)
        session.mount("https://", HTTPAdapter(max_retries=retry))
        result = subprocess.run(["bash", "-c", f"source {ENV_FILE} && env"], capture_output=True, text=True, timeout=10)
        for line in result.stdout.strip().split("\n"):
            if line.startswith("ENVIPATH_"):
                k, v = line.split("=", 1)
                os.environ[k] = v
        resp = session.post(ENV_BASE, data={"hiddenMethod": "login",
                                            "loginusername": os.environ.get("ENVIPATH_USERNAME", ""),
                                            "loginpassword": os.environ.get("ENVIPATH_PASSWORD", "")},
                            headers={"Accept": "application/json"}, timeout=45)
        online = resp.status_code < 400
        logger.info(f"enviPath online={online} (login HTTP {resp.status_code})")
    except Exception as ex:
        logger.warning(f"enviPath unreachable at run time: {safe_error(ex)}")
    meta = {"online": online, "extension_calls": 0, "extension_success": 0,
            "extension_blocked": 0, "extension_endpoint_unreachable": not online}

    def graft_source(case_id, src_id, d, src_canon, raw_path, rel_raw):
        if src_canon in ext_blocked_cache:
            return {"status": ext_blocked_cache[src_canon]}
        if not online:
            ext_blocked_cache[src_canon] = "blocked"
            children_map[src_canon] = None
            meta["extension_blocked"] += 1
            return {"status": "blocked", "blocker": "envipath_status=blocked_endpoint_unreachable", "children": []}
        meta["extension_calls"] += 1
        time.sleep(ENV_SLEEP)
        children_map[src_canon] = None
        try:
            resp = session.post(ENV_UTIL, data={"hiddenMethod": "predict", "smiles": src_canon,
                                                "settingUri": ENV_SETTING},
                                headers={"Accept": "application/json"}, timeout=90)
            try:
                data = resp.json()
            except Exception:
                data = None
            record = {"source_smiles": src_canon, "http_status": resp.status_code,
                      "json": data if resp.status_code == 200 else None,
                      "error_message_sanitized": "" if resp.status_code == 200 else safe_error(resp.text),
                      "api_url": ENV_UTIL, "hidden_method": "predict", "setting": ENV_SETTING,
                      "setting_name": ENV_SETTING_NAME, "case_id": case_id, "source_node_id": src_id,
                      "source_depth": d}
            write_json(raw_path, record)
            if resp.status_code != 200:
                meta["extension_blocked"] += 1
                ext_blocked_cache[src_canon] = "blocked"
                return {"status": "blocked", "blocker": f"envipath_status=blocked_http_{resp.status_code}", "children": []}
            cbm, _b = parse_env_api_json({"json": data, "http_status": 200})
            if cbm is not None:
                for ck, cv in cbm.items():
                    if (ck not in children_map or children_map[ck] is None) and ck != src_canon:
                        children_map[ck] = cv
                    elif children_map[ck] is None and ck == src_canon:
                        children_map[ck] = cv if cv is not None else []
                if src_canon not in children_map or children_map[src_canon] is None:
                    children_map[src_canon] = []
            meta["extension_success"] += 1
            return {"status": "ok"}
        except Exception as ex:
            meta["extension_blocked"] += 1
            logger.warning(f"envipath graft exception {case_id} d{d} {src_canon[:50]}: {safe_error(ex)}")
            return {"status": "blocked", "blocker": "envipath_status=blocked_endpoint_exception", "children": []}

    blockers_out = []
    for d in range(0, MAX_DEPTH):
        results = {}
        any_source = False
        for case_id, g in graphs.items():
            for src_id in g["frontier"].get(str(d), []):
                if src_id in g["expanded"]:
                    continue
                any_source = True
                node = g["nodes"][src_id]
                src_canon = node["smiles_canonical"]
                raw_dir = os.path.join(raw_base, case_id, f"depth_{d}")
                os.makedirs(raw_dir, exist_ok=True)
                raw_path = os.path.join(raw_dir, f"source_{src_id}.json")
                rel_raw = f"03_ROUTE_EXPANSION/{spec['dirname']}/raw/{case_id}/depth_{d}/source_{src_id}.json"
                cv = children_map.get(src_canon, "MISSING")
                if cv is None:
                    out = graft_source(case_id, src_id, d, src_canon, raw_path, rel_raw)
                    results[src_id] = out
                    children_map[src_canon] = children_map.get(src_canon) if children_map.get(src_canon) is not None and not isinstance(children_map.get(src_canon), list) else children_map.get(src_canon)
                    continue
                if isinstance(cv, str) and cv == "MISSING":
                    children_map[src_canon] = None
                    out = graft_source(case_id, src_id, d, src_canon, raw_path, rel_raw)
                    results[src_id] = out
                    continue
                children = []
                ranked_children = sorted(cv, key=lambda t: (-((t[1] is not None and float(t[1])) or 0.0),)) if isinstance(cv, list) else []
                for t in ranked_children[:CHILD_CAP]:
                    raw_smi, prob = t[0], t[1]
                    c = canon(raw_smi)
                    children.append({"raw": raw_smi, "canonical": c,
                                     "score_raw": float(prob) if prob is not None else 0.0,
                                     "score_semantics": EDGE_SEM["env"],
                                     "rank_from_source": len(children),
                                     "fold_id": 0, "fold_count": 1, "predicted_ec_raw": "", "ec_source": "",
                                     "raw_output_ref": rel_raw,
                                     "prediction_origin": "envipath_bbd_rules_multi_generation_tree",
                                     "rule_name": t[2] if len(t) > 2 else "",
                                     "rule_url": t[3] if len(t) > 3 else ""})
                results[src_id] = {"status": "ok", "children": children, "raw_output_ref": rel_raw}
        if not any_source:
            logger.info(f"enviPath: no sources at depth {d}; expansion finished")
            break
        for case_id, g in graphs.items():
            if g["frontier"].get(str(d)):
                blockers_out.extend(process_case_depth(g, spec, d, results))
        if blockers_out:
            write_jsonl(os.path.join(out_dir, "_source_blockers.jsonl"), blockers_out)
        save_graphs(spec, graphs)
        write_json(children_map_f, children_map)
        write_json(meta_f, meta)
        n_tot = sum(len(g["edges"]) for g in graphs.values())
        logger.info(f"enviPath depth {d} done: edges={n_tot} calls={meta['extension_calls']}")
    for g in graphs.values():
        fd = g["frontier"].get(str(MAX_DEPTH), [])
        for nid in fd:
            g["nodes"][nid]["expansion_outcome"] = g["nodes"][nid]["expansion_outcome"] or "max_depth_reached"
        if not g["stop"] and fd:
            g["stop"] = {"depth": MAX_DEPTH, "reason": "max_depth_reached"}
    write_route_files(spec, graphs, logger)
    write_json(meta_f, meta)
    logger.info(f"enviPath route done: online={online} calls={meta['extension_calls']}")
    return graphs

# ============================================================
# Route 3/4: ECLIPSE PREDEC + NoEC (10-fold batched)
# ============================================================
def load_fold_model(seed, logger):
    import torch
    sys.path.insert(0, os.path.join(PROJECT_ROOT, ".venv/lib/python3.12/site-packages"))
    sys.path.insert(0, os.path.join(PROJECT_ROOT, "chem-eclipse/src"))
    from chem_eclipse.models.ECLIPSEProdModel import ECLIPSEProdModel
    fold_dir = os.path.join(ECLIPSE_BASE, f"bbd_40_3_{seed}_uspto_rdkit")
    with open(os.path.join(fold_dir, "config.json")) as f:
        config = json.load(f)
    with open(os.path.join(fold_dir, "tokens.json")) as f:
        tokens = json.load(f)
    if isinstance(tokens, list) and len(tokens) == 2:
        char_to_i = tokens[0]
        i_to_char = {int(k): v for k, v in tokens[1].items()}
    elif "regex" in tokens:
        char_to_i = tokens["regex"]
        i_to_char = {i: char for char, i in char_to_i.items()}
    else:
        char_to_i = tokens
        i_to_char = {i: char for char, i in char_to_i.items()}
    with open(os.path.join(fold_dir, "split_bbd.json")) as f:
        split = json.load(f)
    ec_to_i = split["ec_to_i"]
    tokenizer = (char_to_i, i_to_char)
    args = Namespace(
        data_name="bbd", eclipse_type="h", split_path="",
        max_len=config.get("max_len", 380), min_len=config.get("min_len", 0),
        debug=False, epochs=config.get("epochs", 500), batch_size=config.get("batch_size", 128),
        weights_dataset="",
        score_all=config.get("score_all", False), folds=config.get("folds", 10),
        enzymes=config.get("enzymes", False), seed=seed, test="",
        train_many=False, workers=4, gpu=False,
    )
    model = ECLIPSEProdModel(config, vocab=tokenizer, ec_vocab=ec_to_i, p_args=args, train_steps=1000)
    model.eclipse = model.eclipse.load_model()
    ckpt_dir = os.path.join(fold_dir, "expert/checkpoints")
    ckpt_files = sorted([f for f in os.listdir(ckpt_dir) if f.endswith(".ckpt")])
    ckpt_path = os.path.join(ckpt_dir, ckpt_files[0])
    ckpt = torch.load(ckpt_path, map_location=lambda storage, loc: storage, weights_only=False)
    model.experts.load_state_dict(ckpt["state_dict"])
    model.experts = model.experts.to("cpu")
    model.experts.eval()
    del ckpt
    return model


def run_eclipse(df, logger, key):
    import torch
    spec = SPEC_BY_KEY[key]
    use_enzyme = spec["use_enzyme"]
    n_threads = 24 if use_enzyme else 16
    torch.set_num_threads(min(n_threads, max(4, (os.cpu_count() or 4) // 4)))
    out_dir = os.path.join(EXPANSION_DIR, spec["dirname"])
    state_dir = os.path.join(STATE_DIR, spec["key"])
    chunk_dir = os.path.join(state_dir, "fold_chunks")
    sources_f = os.path.join(out_dir, "raw_or_intermediate", "sources.jsonl")
    cache_f = os.path.join(state_dir, "sources_cache.jsonl")
    os.makedirs(chunk_dir, exist_ok=True)
    logger.info(f"=== ECLIPSE {spec['route_id']} multi-step (use_enzyme={use_enzyme}) ===")
    graphs = load_graphs(spec)
    if not graphs:
        for _, row in df.iterrows():
            graphs[row["full_route_case_id"]] = new_graph(row, spec)
    prev_csv = PREV_ECL_PREDEC_CSV if use_enzyme else PREV_ECL_NOEC_CSV
    prev_df = pd.read_csv(prev_csv)
    prev_by_case = {}
    for _, r in prev_df.iterrows():
        if r.get("predicted_product_smiles_canonical"):
            prev_by_case.setdefault(r["full_route_case_id"], []).append(r)
    for rows in prev_by_case.values():
        rows.sort(key=lambda r: int(r["prediction_rank"]))
    sources_cache = {}
    if os.path.exists(cache_f):
        for line in open(cache_f):
            rec = json.loads(line)
            sources_cache[rec["source_canonical"]] = rec
    wall_start = time.time()
    runtime_cap_hit = False
    ec_source_fresh = "PREDEC_predicted_by_ECLIPSE_10fold_aggregated" if use_enzyme else "noEC_diagnostic_ec_not_conditioning"
    ec_source_prev = "ec_not_recorded_in_previous_s1_package" if use_enzyme else "noec_mode_ec_not_used"
    for d in range(0, MAX_DEPTH):
        if runtime_cap_hit:
            break
        need = {}
        for case_id, g in graphs.items():
            for src_id in g["frontier"].get(str(d), []):
                if src_id in g["expanded"]:
                    continue
                cs = g["nodes"][src_id]["smiles_canonical"]
                need.setdefault(cs, []).append((case_id, src_id))
        if not need:
            logger.info(f"ECLIPSE {key}: no sources at depth {d}; expansion finished")
            break
        logger.info(f"ECLIPSE {key} depth {d}: {len(need)} unique sources")
        results = {}
        if d == 0:
            for cs, refs in need.items():
                for case_id, src_id in refs:
                    children = []
                    for r in prev_by_case.get(case_id, []):
                        children.append({
                            "raw": r["predicted_product_smiles_raw"],
                            "canonical": r["predicted_product_smiles_canonical"],
                            "score_raw": float(r["score_raw"]),
                            "score_semantics": r["score_semantics"],
                            "rank_from_source": int(r["prediction_rank"]),
                            "fold_id": int(r["fold_id"]), "fold_count": int(r["fold_count"]),
                            "predicted_ec_raw": "", "ec_source": ec_source_prev,
                            "raw_output_ref": (
                                "03_PREDICTIONS/eclipse_predec_bbd_finetuned_10fold_aggregated_s1/PREDICTIONS_NORMALIZED.csv"
                                if use_enzyme
                                else "03_PREDICTIONS/eclipse_noec_bbd_finetuned_10fold_aggregated_s1/PREDICTIONS_NORMALIZED.csv"),
                            "prediction_origin": "previous_s1_reuse_depth1_10fold_aggregated"})
                    results[src_id] = {"status": "ok", "children": children[:CHILD_CAP]}
        else:
            missing = [cs for cs in need if cs not in sources_cache]
            failed_sources = set()
            if missing:
                model = None
                model_fold = None
                for fold in range(ECLIPSE_FOLDS):
                    for ci in range(0, len(missing), ECLIPSE_BATCH):
                        chunk_path = os.path.join(chunk_dir, f"fold{fold}_depth{d}_chunk{ci}.json")
                        if os.path.exists(chunk_path):
                            continue
                        if model is None or model_fold != fold:
                            try:
                                model = load_fold_model(fold, logger)
                            except Exception as ex:
                                logger.error(f"fold {fold} load failed: {ex}")
                                logger.error(traceback.format_exc())
                                model = None
                                continue
                            model_fold = fold
                        batch = missing[ci:ci + ECLIPSE_BATCH]
                        model.moe_config["use_enzyme"] = use_enzyme
                        t0 = time.time()
                        try:
                            with torch.no_grad():
                                (pred_smiles, pred_proba), pred_ec = model.smiles_to_smiles_inf(batch)
                        except Exception as ex:
                            logger.error(f"fold {fold} chunk {ci} failed: {ex}")
                            continue
                        chunk = {"sources": batch, "results": {}}
                        for i, src in enumerate(batch):
                            top = []
                            for s, p in zip(pred_smiles[i][:CHILD_CAP], pred_proba[i][:CHILD_CAP]):
                                top.append([str(s), float(p)])
                            ecs = []
                            ec_i = pred_ec[i] if i < len(pred_ec) else -1
                            if isinstance(ec_i, list):
                                for e, _pp in ec_i:
                                    ecs.append(str(e))
                            elif ec_i != -1 and ec_i is not None:
                                ecs.append(str(ec_i))
                            chunk["results"][src] = {"top10": top, "ec": ecs}
                        with open(chunk_path, "w") as fh:
                            json.dump(chunk, fh)
                        logger.info(f"  {key} fold {fold} chunk {ci} ({len(batch)} srcs) {time.time()-t0:.1f}s")
                    if model is not None:
                        del model
                        model = None
                        model_fold = None
                        gc.collect()
                for cs in missing:
                    canon_scores = defaultdict(list)
                    ec_counter = Counter()
                    first_raw = {}
                    n_chunks_hit = 0
                    for fold in range(ECLIPSE_FOLDS):
                        for ci in range(0, len(missing), ECLIPSE_BATCH):
                            cp = os.path.join(chunk_dir, f"fold{fold}_depth{d}_chunk{ci}.json")
                            if not os.path.exists(cp):
                                continue
                            chunk = load_json(cp)
                            if cs not in chunk.get("results", {}):
                                continue
                            n_chunks_hit += 1
                            r = chunk["results"][cs]
                            for raw_s, p in r.get("top10", []):
                                c = canon(raw_s)
                                if c:
                                    canon_scores[c].append((fold, p))
                                    first_raw.setdefault(c, raw_s)
                            for e in r.get("ec", []):
                                ec_counter[e] += 1
                    if n_chunks_hit == 0:
                        failed_sources.add(cs)
                        logger.warning(f"{key} source {cs[:50]} depth {d}: no fold chunks produced; treated as blocked")
                        continue
                    ranked = sorted(canon_scores.items(),
                                    key=lambda kv: (-len(set(f for f, _ in kv[1])),
                                                    -np.mean([s for _, s in kv[1]]) if kv[1] else 0.0))
                    children = []
                    for rank, (c, fold_scores) in enumerate(ranked[:CHILD_CAP]):
                        folds_here = sorted(set(f for f, _ in fold_scores))
                        children.append({
                            "raw": first_raw.get(c, c), "canonical": c,
                            "score_raw": float(np.mean([s for _, s in fold_scores])),
                            "score_semantics": EDGE_SEM["eclipse"],
                            "rank_from_source": rank, "fold_id": -1, "fold_count": len(folds_here),
                            "predicted_ec_raw": "", "ec_source": ec_source_fresh})
                    rec = {"source_canonical": cs,
                           "ec_agg": "; ".join(f"{e} ({ec_counter[e]})" for e, _n in ec_counter.most_common(5)),
                           "children": children,
                           "first_seen_depth": d,
                           "fold_chunks": [f"fold{f}_depth{d}_chunk{ci}.json" for f in range(ECLIPSE_FOLDS)
                                           for ci in range(0, len(missing), ECLIPSE_BATCH)
                                           if os.path.exists(os.path.join(chunk_dir, f"fold{f}_depth{d}_chunk{ci}.json"))]}
                    for ch in children:
                        ch["predicted_ec_raw"] = rec["ec_agg"]
                    sources_cache[cs] = rec
                    with open(cache_f, "a") as fh:
                        fh.write(json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n")
            for cs, refs in need.items():
                rec = sources_cache.get(cs)
                if cs in failed_sources or not rec:
                    for case_id, src_id in refs:
                        results[src_id] = {"status": "blocked",
                                           "blocker": "eclipse_status=blocked_inference_failed_for_source", "children": []}
                    continue
                for case_id, src_id in refs:
                    children = []
                    for ch in rec["children"]:
                        cc = dict(ch)
                        cc["raw_output_ref"] = f"03_ROUTE_EXPANSION/{spec['dirname']}/raw_or_intermediate/sources.jsonl"
                        cc["prediction_origin"] = "fresh_10fold_batched_inference" if use_enzyme else "fresh_10fold_batched_inference_noec"
                        cc["rank_from_source"] = cc.get("rank_from_source", 0)
                        children.append(cc)
                    results[src_id] = {"status": "ok", "children": children[:CHILD_CAP]}
        for case_id, g in graphs.items():
            if g["frontier"].get(str(d)):
                process_case_depth(g, spec, d, results)
        save_graphs(spec, graphs)
        write_route_files(spec, graphs, logger)
        elapsed = time.time() - wall_start
        logger.info(f"ECLIPSE {key} depth {d} done: elapsed={elapsed/60:.1f}min")
        if spec.get("wall_cap") and elapsed > spec["wall_cap"]:
            logger.warning(f"ECLIPSE {key}: wall cap {spec['wall_cap']/3600:.0f}h reached after depth {d}")
            runtime_cap_hit = True
            for g in graphs.values():
                g["stop"] = {"depth": d + 1, "reason": "runtime_cap_reached"}
                fd = g["frontier"].get(str(d + 1), [])
                for nid in fd:
                    g["nodes"][nid]["expansion_outcome"] = "runtime_cap_reached"
            break
    for g in graphs.values():
        fd = g["frontier"].get(str(MAX_DEPTH), [])
        for nid in fd:
            g["nodes"][nid]["expansion_outcome"] = g["nodes"][nid]["expansion_outcome"] or "max_depth_reached"
        if not g["stop"] and fd:
            g["stop"] = {"depth": MAX_DEPTH, "reason": "max_depth_reached"}
    save_graphs(spec, graphs)
    write_route_files(spec, graphs, logger)
    meta = {"wall_elapsed_sec": time.time() - wall_start, "runtime_cap_hit": bool(runtime_cap_hit),
            "unique_sources_processed": len(sources_cache), "use_enzyme": use_enzyme, "depth1_source": "previous_s1_reuse"}
    write_json(os.path.join(state_dir, "route_meta.json"), meta)
    with open(sources_f, "w") as fh:
        for cs, rec in sorted(sources_cache.items()):
            fh.write(json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n")
    logger.info(f"ECLIPSE {key} done: sources={len(sources_cache)} wall={meta['wall_elapsed_sec']/60:.1f}min")
    return graphs


# ============================================================
# Finalize: path scores, paths, summaries, QC, status, packaging
# ============================================================
def combine_score(kind, best_src, w):
    if kind == "bt":
        return 0.0
    if kind == "env":
        edge_log = math.log(max(float(w), 1e-300))
        total_log = best_src + edge_log
        return math.exp(total_log) if total_log > -700 else 0.0
    if kind == "eclipse":
        return best_src + float(w)
    return 0.0


def compute_best_path_scores(spec, graphs):
    kind = spec["kind"]
    for g in graphs.values():
        best = {}
        parent_id = f"{g['case_id']}__n00000"
        # log-domain DP: best[node] = best-path score in log domain
        # env -> log(prob product), eclipse -> sum of edge means, bt -> 0.0
        best[parent_id] = 0.0
        edges_by_depth = defaultdict(list)
        for e in g["edges"]:
            edges_by_depth[e["source_depth"]].append(e)
        for d in sorted(edges_by_depth.keys()):
            for e in edges_by_depth[d]:
                src_id = e["source_node_id"]
                if src_id not in best:
                    continue
                if e["normalization_status"] != "ok" or not e["target_node_id"]:
                    continue
                w = e["local_edge_score_raw"] or 0.0
                if kind == "env":
                    p = max(min(float(w), 1.0), 1e-300)
                    cand = best[src_id] + math.log(p)
                elif kind == "eclipse":
                    cand = best[src_id] + float(w)
                else:
                    cand = 0.0
                tid = e["target_node_id"]
                if tid not in best or cand > best[tid]:
                    best[tid] = cand
        # edge path scores + node best
        for e in g["edges"]:
            src_id = e["source_node_id"]
            if e["normalization_status"] == "ok" and e["target_node_id"] and src_id in best:
                w = e["local_edge_score_raw"] or 0.0
                if kind == "env":
                    p = max(min(float(w), 1.0), 1e-300)
                    total_log = best[src_id] + math.log(p)
                    e["path_score_raw"] = math.exp(total_log) if -740 < total_log < 700 else 0.0
                elif kind == "eclipse":
                    e["path_score_raw"] = best[src_id] + float(w)
                else:
                    e["path_score_raw"] = 0.0
                e["path_score_semantics"] = PATH_SEM[kind]
        for nid, node in g["nodes"].items():
            if nid in best:
                if kind == "env":
                    v = best[nid]
                    node["best_path_score_raw"] = math.exp(v) if -740 < v < 700 else 0.0
                else:
                    node["best_path_score_raw"] = best[nid]
                node["best_path_score_semantics"] = PATH_SEM[kind]


def build_paths(spec, graphs, df):
    kind = spec["kind"]
    all_paths = []
    for case_id, g in sorted(graphs.items()):
        parent_id = f"{case_id}__n00000"
        adj = defaultdict(list)
        for e in g["edges"]:
            if e["normalization_status"] == "ok" and e["source_node_id"] in g["nodes"] and e["target_node_id"] in g["nodes"]:
                adj[e["source_node_id"]].append(e)
        if not adj.get(parent_id):
            continue
        best = {}
        if kind == "env":
            best[parent_id] = 0.0
        elif kind == "eclipse":
            best[parent_id] = 0.0
        else:
            best[parent_id] = 0.0

        def finalize_path(node_path, edge_list, expansions):
            last_node = node_path[-1]
            node = g["nodes"][last_node]
            if kind == "bt":
                score = 0.0
                key = (0.0,)
            elif kind == "env":
                score = math.exp(best[parent_id]) if last_node == parent_id else (
                    g["nodes"][last_node].get("best_path_score_raw", 0.0))
                key = (-math.log(max(score, 1e-300)),)
            else:
                score = g["nodes"][last_node].get("best_path_score_raw", 0.0)
                key = (-score,)
            outcome = node.get("expansion_outcome", "")
            stopped = ""
            if outcome == "max_depth_reached":
                stopped = "max_depth_reached"
            elif outcome == "frontier_empty":
                stopped = "frontier_empty"
            elif outcome == "all_candidates_invalid":
                stopped = "all_candidates_invalid"
            elif outcome == "all_candidates_seen_before":
                stopped = "all_candidates_seen_before"
            elif outcome == "tool_blocked_for_frontier":
                stopped = "tool_blocked_for_frontier"
            elif outcome == "runtime_cap_reached" or (g.get("stop") or {}).get("reason") == "runtime_cap_reached":
                stopped = "runtime_cap_reached"
            elif len(adj.get(last_node, [])) == 0:
                stopped = "frontier_empty"
            else:
                stopped = "max_depth_reached"
            return {
                "full_route_case_id": case_id, "tool_id": spec["tool_id"], "route_id": spec["route_id"],
                "path_id": f"{case_id}__p{len(all_paths_case):05d}",
                "path_depth": len(edge_list),
                "compound_smiles_canonical_path": [g["nodes"][n]["smiles_canonical"] for n in node_path],
                "compound_node_id_path": node_path,
                "edge_id_path": [e["edge_id"] for e in edge_list],
                "path_score_raw": score,
                "path_score_semantics": PATH_SEM[kind],
                "path_status": "complete" if node_path[-1] and (len(edge_list) >= MAX_DEPTH or not adj.get(last_node)) else "incomplete_frontier_cap_boundary",
                "stopped_reason": stopped,
                "expansions": expansions}

        all_paths_case = []
        heap = []
        seq = 0
        heapq.heappush(heap, ((0.0,) if kind != "bt" else (-0, 0), seq, [parent_id], [], 0))
        limiter = 0
        while heap and limiter < 120000:
            limiter += 1
            key, _seq, node_path, edge_list, _exp = heapq.heappop(heap)
            last_node = node_path[-1]
            if len(edge_list) >= MAX_DEPTH or not adj.get(last_node):
                all_paths_case.append(finalize_path(node_path, edge_list, limiter))
                if not adj.get(last_node) or len(all_paths_case) >= 2000:
                    if len(all_paths_case) >= 10 and (not heap or heap[0][0] >= key):
                        pass
                continue
            for e in adj[last_node]:
                seq += 1
                nid = e["target_node_id"]
                new_nodes = node_path + [nid]
                new_edges = edge_list + [e]
                if kind == "bt":
                    nkey = (-len(new_edges), e.get("discovery_seq", 0))
                elif kind == "env":
                    w = e["local_edge_score_raw"] or 0.0
                    logw = math.log(max(float(w), 1e-300))
                    nkey = (key[0] + logw,)
                else:
                    nkey = (key[0] - (e["local_edge_score_raw"] or 0.0),)
                heapq.heappush(heap, (nkey, seq, new_nodes, new_edges, limiter))
        if kind == "bt":
            all_paths_case.sort(key=lambda p: (-p["path_depth"], p["expansions"]))
        else:
            all_paths_case.sort(key=lambda p: -p["path_score_raw"])
        top = all_paths_case[:10]
        for p in top:
            all_paths.append(p)
    return all_paths


def finalize(logger):
    t0 = time.time()
    df = load_blind()
    ensure_table_dirs()
    route_infos = {}
    for spec in ROUTES:
        graphs = load_graphs(spec)
        route_infos[spec["key"]] = {"spec": spec, "graphs": graphs}
        if not graphs:
            logger.warning(f"{spec['key']}: no graphs found; skipped")
            continue
        out_dir = os.path.join(EXPANSION_DIR, spec["dirname"])
        compute_best_path_scores(spec, graphs)
        paths = build_paths(spec, graphs, df)
        write_jsonl(os.path.join(out_dir, "PREDICTED_ROUTE_PATHS.jsonl"), paths)
        if spec["key"] == "eclipse_predec":
            pd.DataFrame(paths).to_csv(os.path.join(out_dir, "PREDICTED_ROUTE_PATHS_TOP10_BY_CASE.csv"), index=False)
        write_route_files(spec, graphs, logger)
        blockers = []
        bf = os.path.join(out_dir, "_source_blockers.jsonl")
        if os.path.exists(bf):
            for line in open(bf):
                blockers.append(json.loads(line))
        summary = build_route_summary(spec, graphs, paths, blockers)
        write_route_summary_files(spec, summary, logger)
        write_json(os.path.join(STATE_DIR, spec["key"], "summary.json"), {
            "summary": summary, "paths_count": len(paths)})
        route_infos[spec["key"]]["summary"] = summary
        route_infos[spec["key"]]["blockers"] = blockers
        route_infos[spec["key"]]["paths"] = paths
        if os.path.exists(bf):
            os.remove(bf)
        logger.info(f"finalize {spec['key']}: paths={len(paths)} edges={summary['total_predicted_edges']}")
    build_route_status(route_infos, logger)
    build_qc(route_infos, logger)
    build_metadata(route_infos, logger)
    logger.info(f"finalize core done in {time.time()-t0:.1f}s (packaging follows)")


def build_route_summary(spec, graphs, paths, blockers):
    n_cases = len(graphs)
    depth_counts = {k: 0 for k in range(1, MAX_DEPTH + 1)}
    max_reached = 0
    for g in graphs.values():
        md = g["max_depth_seen"]
        max_reached = max(max_reached, md)
        for k in range(1, MAX_DEPTH + 1):
            if md >= k:
                depth_counts[k] += 1
    total_edges = sum(len(g["edges"]) for g in graphs.values())
    total_nodes = sum(len(g["nodes"]) for g in graphs.values())
    n_invalid = sum(1 for g in graphs.values() for e in g["edges"] if e["normalization_status"] == "invalid_target_smiles")
    n_self = sum(1 for g in graphs.values() for e in g["edges"] if e["target_is_source_copy"])
    n_cycle = sum(1 for g in graphs.values() for e in g["edges"] if e["cycle_or_seen_before"])
    raw_dir = os.path.join(EXPANSION_DIR, spec["dirname"], "raw")
    n_raw = sum(1 for _ in Path(raw_dir).rglob("*")) if os.path.isdir(raw_dir) else 0
    return {
        "route_id": spec["route_id"], "tool_id": spec["tool_id"], "optional_route": spec["optional"],
        "input_parent_count": n_cases, "max_depth_requested": MAX_DEPTH, "max_depth_reached": max_reached,
        "parents_with_depth_1": depth_counts[1], "parents_with_depth_2": depth_counts[2],
        "parents_with_depth_3": depth_counts[3], "parents_with_depth_4": depth_counts[4],
        "parents_with_depth_5": depth_counts[5], "parents_with_depth_6": depth_counts[6],
        "total_predicted_nodes": total_nodes, "total_predicted_edges": total_edges,
        "total_predicted_paths": len(paths), "invalid_prediction_count": n_invalid,
        "self_loop_count": n_self, "cycle_or_seen_before_count": n_cycle,
        "source_level_blocker_count": len(blockers), "raw_output_count": n_raw,
        "restricted_answer_key_read": False, "scoring_performed": False,
    }


def build_route_status(route_infos, logger):
    rows = []
    blockers_all = {}
    for key, info in route_infos.items():
        spec = info["spec"]
        s = info.get("summary")
        if not s:
            rows.append({"route_id": spec["route_id"], "tool_id": spec["tool_id"], "optional_route": spec["optional"],
                         "status": "blocked_no_graph_state", "typed_route_blocker": f"{key}_status=blocked_no_graph_state",
                         "input_parent_count": 0, "max_depth_requested": MAX_DEPTH, "max_depth_reached": 0,
                         "parents_with_depth_6": 0, "total_predicted_nodes": 0, "total_predicted_edges": 0,
                         "total_predicted_paths": 0, "invalid_prediction_count": 0, "self_loop_count": 0,
                         "cycle_or_seen_before_count": 0, "source_level_blocker_count": 0, "raw_output_count": 0,
                         "restricted_answer_key_read": False, "scoring_performed": False, "notes": ""})
            blockers_all[key] = f"{key}_status=blocked_no_graph_state"
            continue
        meta_f = os.path.join(STATE_DIR, key, "route_meta.json")
        meta = load_json(meta_f) if os.path.exists(meta_f) else {}
        if key == "envipath" and not meta.get("online", False):
            status = "ok" if s["total_predicted_edges"] > 0 else "blocked"
            typed = "envipath_multistep_status=completed_tree_extraction_only_endpoint_unreachable_for_frontier_graft_extension"
        elif key == "eclipse_noec" and meta.get("runtime_cap_hit"):
            status = "completed_with_partial_depth"
            typed = "eclipse_noec_multistep_status=completed_with_partial_depth_runtime_cap_reached"
        elif s["total_predicted_edges"] > 0:
            status = "ok"
            typed = ""
        else:
            status = "blocked"
            typed = f"{key}_status=blocked_no_expansion_output"
        if typed:
            blockers_all[key] = typed
        rows.append({"route_id": spec["route_id"], "tool_id": spec["tool_id"], "optional_route": spec["optional"],
                     "status": status, "typed_route_blocker": typed,
                     "input_parent_count": s["input_parent_count"], "max_depth_requested": s["max_depth_requested"],
                     "max_depth_reached": s["max_depth_reached"], "parents_with_depth_1": s["parents_with_depth_1"],
                     "parents_with_depth_2": s["parents_with_depth_2"], "parents_with_depth_3": s["parents_with_depth_3"],
                     "parents_with_depth_4": s["parents_with_depth_4"], "parents_with_depth_5": s["parents_with_depth_5"],
                     "parents_with_depth_6": s["parents_with_depth_6"], "total_predicted_nodes": s["total_predicted_nodes"],
                     "total_predicted_edges": s["total_predicted_edges"], "total_predicted_paths": s["total_predicted_paths"],
                     "invalid_prediction_count": s["invalid_prediction_count"], "self_loop_count": s["self_loop_count"],
                     "cycle_or_seen_before_count": s["cycle_or_seen_before_count"],
                     "source_level_blocker_count": s["source_level_blocker_count"], "raw_output_count": s["raw_output_count"],
                     "restricted_answer_key_read": False, "scoring_performed": False,
                     "notes": json.dumps(meta)[:400] if meta else ""})
    pd.DataFrame(rows).to_csv(os.path.join(RETURN_DIR, "02_ROUTE_STATUS/route_status_summary.csv"), index=False)
    src_blockers = []
    for key, info in route_infos.items():
        for blk in (info.get("blockers") or []):
            src_blockers.append(blk)
    pd.DataFrame(src_blockers).to_csv(os.path.join(RETURN_DIR, "02_ROUTE_STATUS/source_level_blockers.csv"), index=False)
    write_json(os.path.join(RETURN_DIR, "02_ROUTE_STATUS/route_blockers.json"), blockers_all)
    with open(os.path.join(RETURN_DIR, "02_ROUTE_STATUS/route_blockers.md"), "w") as f:
        f.write("# Route Blockers\n\n")
        if blockers_all:
            f.write("\n".join(f"- **{k}**: `{v}`" for k, v in sorted(blockers_all.items())) + "\n")
        else:
            f.write("No route-level blockers. All routes completed.\n")
    return rows, blockers_all


def build_qc(route_infos, logger):
    qc_dir = os.path.join(RETURN_DIR, "04_QC_ONLY_NO_SCORING")
    os.makedirs(qc_dir, exist_ok=True)
    depth_rows, frontier_rows, invalid_rows, copy_rows, cycle_rows = [], [], [], [], []
    for key, info in route_infos.items():
        spec = info["spec"]
        for g in (info.get("graphs") or {}).values():
            depth_rows.append({"full_route_case_id": g["case_id"], "route_id": spec["route_id"],
                               "max_depth_reached": g["max_depth_seen"],
                               "case_stop_reason": (g.get("stop") or {}).get("reason", ""),
                               "total_nodes": len(g["nodes"]), "total_edges": len(g["edges"])})
            for d_str, st in sorted(g.get("depth_stats", {}).items(), key=lambda kv: int(kv[0])):
                frontier_rows.append({"full_route_case_id": g["case_id"], "route_id": spec["route_id"],
                                      "depth": int(d_str),
                                      "frontier_size": st.get("frontier_size", 0),
                                      "sources_expanded": st.get("sources_expanded", 0),
                                      "sources_blocked": st.get("sources_blocked", 0),
                                      "children_invalid": st.get("children_invalid", 0),
                                      "children_valid_unique": st.get("children_valid_unique", 0),
                                      "next_frontier_size": st.get("next_frontier_size", 0),
                                      "case_stop_reason": st.get("case_stop_reason", "")})
            for e in g["edges"]:
                base = {"full_route_case_id": g["case_id"], "route_id": spec["route_id"],
                        "edge_id": e["edge_id"], "source_node_id": e["source_node_id"],
                        "target_node_id": e["target_node_id"], "source_depth": e["source_depth"],
                        "target_depth": e["target_depth"],
                        "source_smiles_canonical": e["source_smiles_canonical"],
                        "target_smiles_raw": e["target_smiles_raw"]}
                if e["normalization_status"] == "invalid_target_smiles":
                    invalid_rows.append(base)
                if e["target_is_source_copy"] or e["target_is_original_parent_copy"]:
                    copy_rows.append({**base,
                                      "target_is_source_copy": e["target_is_source_copy"],
                                      "target_is_original_parent_copy": e["target_is_original_parent_copy"]})
                if e["cycle_or_seen_before"]:
                    cycle_rows.append({**base, "target_smiles_canonical": e["target_smiles_canonical"]})
    pd.DataFrame(depth_rows).to_csv(os.path.join(qc_dir, "prediction_depth_distribution.csv"), index=False)
    pd.DataFrame(frontier_rows).to_csv(os.path.join(qc_dir, "per_case_frontier_size_by_depth.csv"), index=False)
    pd.DataFrame(invalid_rows).to_csv(os.path.join(qc_dir, "invalid_or_unparseable_prediction_rows.csv"), index=False)
    pd.DataFrame(copy_rows).to_csv(os.path.join(qc_dir, "parent_copy_or_self_loop_rows.csv"), index=False)
    pd.DataFrame(cycle_rows).to_csv(os.path.join(qc_dir, "cycle_or_seen_before_rows.csv"), index=False)
    with open(os.path.join(qc_dir, "qc_summary.md"), "w") as f:
        f.write("# QC summary (no scoring performed)\n\n")
        f.write(f"- prediction_depth_distribution rows: {len(depth_rows)}\n")
        f.write(f"- per-case frontier rows: {len(frontier_rows)}\n")
        f.write(f"- invalid or unparseable prediction rows: {len(invalid_rows)}\n")
        f.write(f"- parent copy / self loop rows: {len(copy_rows)}\n")
        f.write(f"- cycle or seen-before rows: {len(cycle_rows)}\n")
        f.write("- restricted_answer_key_read: false\n")
        f.write("- scoring_performed: false\n")
    logger.info(f"QC files written: {len(depth_rows)} depth rows, {len(frontier_rows)} frontier rows, "
                f"{len(invalid_rows)} invalid, {len(copy_rows)} copies, {len(cycle_rows)} cycles")
    return depth_rows, frontier_rows, invalid_rows, copy_rows, cycle_rows


def write_route_summary_files(spec, summary, logger):
    out_dir = os.path.join(EXPANSION_DIR, spec["dirname"])
    pd.DataFrame([summary]).to_csv(os.path.join(out_dir, "ROUTE_EXPANSION_SUMMARY.csv"), index=False)
    with open(os.path.join(out_dir, "ROUTE_EXPANSION_SUMMARY.md"), "w") as f:
        f.write(f"# Route expansion summary - {spec['route_id']}\n\n")
        f.write(f"- route_id: {spec['route_id']}\n")
        f.write(f"- tool_id: {spec['tool_id']}\n")
        f.write(f"- optional_route: {spec['optional']}\n")
        f.write(f"- input_parent_count: {summary['input_parent_count']}\n")
        f.write(f"- max_depth_requested: {summary['max_depth_requested']}\n")
        f.write(f"- max_depth_reached: {summary['max_depth_reached']}\n")
        f.write("- parents reaching at least depth k:\n")
        for k in range(1, MAX_DEPTH + 1):
            f.write(f"  - depth {k}: {summary[f'parents_with_depth_{k}']}\n")
        f.write(f"- total_predicted_nodes: {summary['total_predicted_nodes']}\n")
        f.write(f"- total_predicted_edges: {summary['total_predicted_edges']}\n")
        f.write(f"- total_predicted_paths (top-10 per case): {summary['total_predicted_paths']}\n")
        f.write(f"- invalid_prediction_count: {summary['invalid_prediction_count']}\n")
        f.write(f"- self_loop_count (parent copy / self loop): {summary['self_loop_count']}\n")
        f.write(f"- cycle_or_seen_before_count: {summary['cycle_or_seen_before_count']}\n")
        f.write(f"- source_level_blocker_count: {summary['source_level_blocker_count']}\n")
        f.write(f"- raw_output_count: {summary['raw_output_count']}\n")
        f.write("- restricted_answer_key_read: false\n")
        f.write("- scoring_performed: false\n")
    logger.info(f"{spec['key']}: ROUTE_EXPANSION_SUMMARY files written")


def build_metadata(route_infos, logger):
    logger.info("=== metadata build ===")
    required_keys = ["biotransformer", "envipath", "eclipse_predec"]
    required_ok, depth6_ok = True, True
    route_brief = []
    for rk in required_keys:
        info = route_infos.get(rk, {})
        spec = info.get("spec", SPEC_BY_KEY[rk])
        s = info.get("summary")
        if not s or s["total_predicted_edges"] <= 0:
            required_ok = False
        if not s or s["parents_with_depth_6"] <= 0:
            depth6_ok = False
        route_brief.append({"route_id": spec["route_id"],
                            "status": "ok" if s else "blocked_no_graph_state",
                            "max_depth_reached": (s or {}).get("max_depth_reached", 0),
                            "parents_with_depth_6": (s or {}).get("parents_with_depth_6", 0),
                            "total_predicted_edges": (s or {}).get("total_predicted_edges", 0),
                            "total_predicted_paths": (s or {}).get("total_predicted_paths", 0)})
    if required_ok and depth6_ok:
        final_status = "COMPLETE_BOUNDED_MULTISTEP_ROUTE_EXPANSION_READY_FOR_LOCAL_SCORING"
    else:
        final_status = "PARTIAL_BOUNDED_MULTISTEP_ROUTE_EXPANSION_WITH_TYPED_BLOCKERS_READY_FOR_LOCAL_SCORING"
    with open(os.path.join(RETURN_DIR, "FINAL_STATUS.txt"), "w") as f:
        f.write(final_status + "\n")
    logger.info(f"FINAL_STATUS={final_status}")

    status_rows = []
    for key, info in route_infos.items():
        spec = info["spec"]
        s = info.get("summary") or {}
        status_rows.append({"key": key, "route_id": spec["route_id"], "tool_id": spec["tool_id"],
                            "optional_route": spec["optional"],
                            "max_depth_reached": s.get("max_depth_reached", 0),
                            "parents_with_depth_6": s.get("parents_with_depth_6", 0),
                            "total_predicted_edges": s.get("total_predicted_edges", 0),
                            "total_predicted_paths": s.get("total_predicted_paths", 0)})
    manifest = {
        "return_name": RETURN_NAME, "created_utc": utc_now(), "final_status": final_status,
        "input_archive": {"path": ARCHIVE_PATH, "sha256": ARCHIVE_SHA256, "sha256_verified": True},
        "restricted_answer_key_read": False, "scoring_performed": False,
        "strict_blind_rows": EXPECTED_ROWS, "max_depth_requested": MAX_DEPTH,
        "frontier_cap": FRONTIER_CAP, "child_cap": CHILD_CAP,
        "required_routes": ["biotransformer", "envipath", "eclipse_predec"],
        "optional_routes": ["eclipse_noec"],
        "route_status": status_rows,
        "depth1_reuse_notes": "Depth-1 layers reuse the previous compliant s1 package "
                             "bbd_full_route_v0_3_v3_1_three_tool_blind_predictions_20260821",
    }
    write_json(os.path.join(RETURN_DIR, "RUN_MANIFEST.json"), manifest)

    readme_lines = [
        "# BBD full-route v0.3 v3.1 bounded multi-step route-expansion supplement",
        "",
        f"Final status: **{final_status}**",
        "",
        "## Input identity",
        f"- Strict blind archive: `{ARCHIVE_PATH}` (SHA256 verified: `{ARCHIVE_SHA256}`)",
        f"- Strict blind CSV rows: {EXPECTED_ROWS}",
        "- Restricted answer key read: **false**",
        "- Scoring performed: **false**",
        "",
        "## Expansion policy",
        f"- max_depth_requested={MAX_DEPTH}, frontier_cap={FRONTIER_CAP}, child_cap={CHILD_CAP}",
        "- Depth-1 layers reuse the previous compliant s1 package where present; deeper layers are fresh bounded predictions.",
        "- No local scoring: edge and path scores are tool-local only.",
        "",
        "## Routes",
    ]
    for br in route_brief:
        readme_lines.append(f"- `{br['route_id']}`: status={br['status']}, max_depth_reached={br['max_depth_reached']}, "
                            f"depth6={br['parents_with_depth_6']}, edges={br['total_predicted_edges']}, "
                            f"paths={br['total_predicted_paths']}")
    readme_lines += [
        "",
        "## File map",
        "- `00_INPUT_AUDIT/` - strict blind identity + previous s1 package identity",
        "- `01_ASSET_DISCOVERY/` - tool asset identities",
        "- `02_ROUTE_STATUS/` - route status summary + typed blockers",
        "- `03_ROUTE_EXPANSION/<route>/` - PREDICTED_ROUTE_EDGES.jsonl / NODES.csv / PATHS.jsonl / ROUTE_EXPANSION_SUMMARY.* + raw",
        "- `04_QC_ONLY_NO_SCORING/` - depth distribution, frontier sizes, invalid/copy/cycle rows",
        "- `05_ENVIPATH_DATABASE_LOOKUP_SEPARATE/` - lookup/prediction separation note",
        "- `06_EXECUTOR_AUDIT/` - executor audit",
        "- `scripts/` `logs/` - implementation and logs",
        "",
    ]
    with open(os.path.join(RETURN_DIR,
              "README_BBD_FULL_ROUTE_V0_3_V3_1_BOUNDED_MULTISTEP_ROUTE_EXPANSION_SUPPLEMENT.md"), "w") as f:
        f.write("\n".join(readme_lines) + "\n")

    note_path = os.path.join(RETURN_DIR, "05_ENVIPATH_DATABASE_LOOKUP_SEPARATE",
                             "NOTE_BBD_DATABASE_LOOKUP_PREDICTION_SEPARATION.md")
    with open(note_path, "w") as f:
        f.write("# enviPath database lookup / prediction separation note\n\n"
                "The optional legacy BBD database lookup is intentionally kept separate from prediction "
                "and was NOT executed in this supplement. All enviPath work here is prediction-only "
                "(multi-generation tree extraction + frontier graft extension through the validated legacy "
                "predict endpoint). Restricted answer data was not accessed.\n")

    audit_lines = [
        "# Executor audit - BBD full-route v0.3 v3.1 bounded multi-step route-expansion supplement",
        "",
        f"- Executed: {utc_now()}",
        f"- Host: {platform.node()}, cwd: {PROJECT_ROOT}",
        "- Method: strict blind, no answer-key access, no local scoring.",
        "- Expansion: bounded iterative expansion (max_depth=6, frontier cap=10, child cap=10) per case per route.",
        "- Depth-1 layers reuse the previous compliant s1 package files; all depth>=2 layers are fresh predictions.",
        "",
        "## Route execution notes",
    ]
    for br in route_brief:
        audit_lines.append(f"- `{br['route_id']}`: max_depth_reached={br['max_depth_reached']}, "
                           f"depth6={br['parents_with_depth_6']}, edges={br['total_predicted_edges']}, "
                           f"paths={br['total_predicted_paths']}")
    audit_lines += [
        "",
        "## Typed blockers (if any)",
    ]
    blockers_f = os.path.join(RETURN_DIR, "02_ROUTE_STATUS/route_blockers.json")
    if os.path.exists(blockers_f):
        blockers = load_json(blockers_f)
        if blockers:
            for k, v in sorted(blockers.items()):
                audit_lines.append(f"- `{k}`: {v}")
        else:
            audit_lines.append("- None")
    else:
        audit_lines.append("- (route blockers file not yet written)")
    audit_lines += [
        "",
        "## Compliance",
        "- restricted_answer_key_read=false",
        "- scoring_performed=false",
        "- Production data (results/, dataset/, feature/): untouched by this run.",
        "- No model retraining performed.",
        "",
    ]
    with open(os.path.join(RETURN_DIR, "06_EXECUTOR_AUDIT",
              "BBD_FULL_ROUTE_V0_3_V3_1_BOUNDED_MULTISTEP_ROUTE_EXPANSION_SUPPLEMENT_EXECUTOR_AUDIT.md"), "w") as f:
        f.write("\n".join(audit_lines) + "\n")
    logger.info("metadata files written")
    return final_status


def package_and_identity(logger, final_status):
    logger.info("=== packaging & identity ===")
    for sub in [".state", ".tmp_extract"]:
        shutil.rmtree(os.path.join(RETURN_DIR, sub), ignore_errors=True)
    os.makedirs(RETURN_DIR, exist_ok=True)
    manifest_path = os.path.join(RETURN_DIR, "MANIFEST.sha256")
    rows = []
    for p in sorted(Path(RETURN_DIR).rglob("*")):
        if p.is_file() and p.name != "MANIFEST.sha256":
            rows.append(f"{sha256_file(str(p))}  {p.relative_to(RETURN_DIR)}")
    with open(manifest_path, "w") as f:
        f.write("\n".join(rows) + "\n")
    logger.info(f"MANIFEST.sha256 written with {len(rows)} entries")
    archive_path = os.path.join(SUMMARIES, RETURN_NAME + ".tar.gz")
    if os.path.exists(archive_path):
        os.remove(archive_path)
    result = subprocess.run(["tar", "-czf", archive_path, RETURN_NAME], cwd=SUMMARIES,
                            capture_output=True, text=True, timeout=7200)
    if result.returncode != 0:
        logger.warning(f"system tar failed: {result.stderr[:300]}; falling back to tarfile module")
        import tarfile
        with tarfile.open(archive_path, "w:gz") as t:
            t.add(RETURN_DIR, arcname=RETURN_NAME)
    arch_sha = sha256_file(archive_path)
    identity_path = archive_path + ".identity.txt"
    with open(identity_path, "w") as f:
        f.write(f"{arch_sha}  {RETURN_NAME}.tar.gz\n")
        f.write(f"archive_name={RETURN_NAME}.tar.gz\n")
        f.write(f"archive_path={archive_path}\n")
        f.write(f"created_utc={utc_now()}\n")
        f.write(f"final_status={final_status}\n")
        f.write("restricted_answer_key_read=false\n")
        f.write("scoring_performed=false\n")
        f.write("strict_blind_rows=93\n")
        f.write("max_depth_requested=6\n")
    logger.info(f"archive sha256={arch_sha} bytes={os.path.getsize(archive_path)}")
    return archive_path, arch_sha


def main():
    parser = ArgumentParser(description="BBD bounded multi-step route-expansion supplement executor")
    parser.add_argument("--phase", default="all",
                        choices=["audit", "assets", "bt", "envipath", "eclipse_predec",
                                 "eclipse_noec", "finalize", "package", "all"])
    args = parser.parse_args()
    os.makedirs(RETURN_DIR, exist_ok=True)
    os.makedirs(LOG_DIR, exist_ok=True)
    if args.phase in ("audit", "all"):
        phase_audit(setup_logger("audit", "input_audit.log"))
    if args.phase in ("assets", "all"):
        phase_assets(setup_logger("assets", "asset_discovery.log"))
    if args.phase not in ("audit", "assets"):
        df = load_blind()
        ensure_table_dirs()
    if args.phase in ("bt", "all"):
        run_bt(df, setup_logger("bt", "biotransformer_multistep.log"))
    if args.phase in ("envipath", "all"):
        run_envipath(df, setup_logger("envipath", "envipath_multistep.log"))
    if args.phase in ("eclipse_predec", "all"):
        run_eclipse(df, setup_logger("eclipse_predec", "eclipse_predec_multistep.log"), "eclipse_predec")
    if args.phase in ("eclipse_noec", "all"):
        run_eclipse(df, setup_logger("eclipse_noec", "eclipse_noec_multistep_optional.log"), "eclipse_noec")
    if args.phase in ("finalize", "all"):
        finalize(setup_logger("finalize", "packaging.log"))
    if args.phase in ("package", "all"):
        lg = logging.getLogger("finalize")
        if not lg.handlers:
            lg = setup_logger("finalize", "packaging.log")
        with open(os.path.join(RETURN_DIR, "FINAL_STATUS.txt")) as f:
            final_status = f.read().strip()
        package_and_identity(lg, final_status)


if __name__ == "__main__":
    main()

