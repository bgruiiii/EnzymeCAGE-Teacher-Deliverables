# QC summary (no scoring performed)

- prediction_depth_distribution rows: 372
- per-case frontier rows: 1869
- invalid or unparseable prediction rows: 565
- parent copy / self loop rows: 5498
- cycle or seen-before rows: 14104
- restricted_answer_key_read: false
- scoring_performed: false
