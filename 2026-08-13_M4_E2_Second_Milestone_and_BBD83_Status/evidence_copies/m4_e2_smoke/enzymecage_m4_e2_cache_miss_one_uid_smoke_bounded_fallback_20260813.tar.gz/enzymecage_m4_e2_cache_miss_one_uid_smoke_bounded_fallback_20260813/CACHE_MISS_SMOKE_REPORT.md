# Cache-Miss Smoke Report

- **task_id**: `enzymecage_m4_e2_cache_miss_one_uid_smoke_bounded_fallback_20260813`
- **final_status**: `M4_E2_CACHE_MISS_ONE_UID_SMOKE_COMPLETE_WITH_ONE_PASS_AND_ATTEMPT_LOG`
- **attempt_queue**: ['A3CST9', 'B8GGQ9', 'A7I9P9', 'A0A0H2V760', 'P0DXZ0']
- **attempted_uids**: ['A3CST9']
- **skipped_uids**: []
- **blocked_uids**: []
- **pass_uid**: A3CST9
- **n_attempted**: 1
- **n_skipped**: 0
- **n_blocked**: 0
- **n_pass**: 1
- **stop_after_first_pass**: True
- **staged_smoke_assets_generated**: True

## Per-UID Final Status

- `A0A0H2V760`: `NOT_ATTEMPTED_STOP_AFTER_PRIOR_PASS`
- `A3CST9`: `PASS_CACHE_MISS_AFDB_P2RANK_PREDICTED_POCKET_STAGED_D4_LOADER_SMOKE`
- `A7I9P9`: `NOT_ATTEMPTED_STOP_AFTER_PRIOR_PASS`
- `B8GGQ9`: `NOT_ATTEMPTED_STOP_AFTER_PRIOR_PASS`
- `P0DXZ0`: `NOT_ATTEMPTED_STOP_AFTER_PRIOR_PASS`

## Safety Confirmations

- `formal_feature_root_mutated`: False
- `production_pool_mutated`: false
- `full_4681_backfill_run`: false
- `production_d4_mutated`: false
- `staged_smoke_assets_generated`: True
