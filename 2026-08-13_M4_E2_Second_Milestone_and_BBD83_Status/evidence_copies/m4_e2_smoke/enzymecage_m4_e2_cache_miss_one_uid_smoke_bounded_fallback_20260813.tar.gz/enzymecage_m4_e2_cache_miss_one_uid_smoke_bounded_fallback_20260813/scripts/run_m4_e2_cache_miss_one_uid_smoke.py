#!/usr/bin/env python3
"""M4 E2 cache-miss one-UID smoke with bounded fallback."""
from __future__ import annotations
import csv, gc, hashlib, json, os, pickle, resource, shutil, socket, stat, subprocess, sys, tarfile, time, traceback
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen
import numpy as np
import pandas as pd
from Bio.PDB import PDBIO, PDBParser, MMCIFParser, Select

TASK_ID = "enzymecage_m4_e2_cache_miss_one_uid_smoke_bounded_fallback_20260813"
RUN_TYPE = "m4_e2_one_uid_cache_miss_smoke_bounded_fallback_staged_only"
PASS_TOKEN = "PASS_CACHE_MISS_AFDB_P2RANK_PREDICTED_POCKET_STAGED_D4_LOADER_SMOKE"
FINAL_STATUS_PASS = "M4_E2_CACHE_MISS_ONE_UID_SMOKE_COMPLETE_WITH_ONE_PASS_AND_ATTEMPT_LOG"
FINAL_STATUS_BLOCKED = "M4_E2_CACHE_MISS_ONE_UID_SMOKE_BLOCKED_NO_PASS_WITH_ATTEMPT_LOG"

PROJECT_REPO = Path("/root/projects/EnzymeCAGE-master")
RETURN_ROOT = PROJECT_REPO / "HPC_Returned_Result_Summaries"
RETURN_DIR = RETURN_ROOT / TASK_ID
ARCHIVE = RETURN_ROOT / f"{TASK_ID}.tar.gz"
IDENTITY = RETURN_ROOT / f"{TASK_ID}.tar.gz.identity.txt"
WORK_ROOT = Path("/tmp") / TASK_ID

P2RANK_DIR = Path("/usrdata/EnzymeCAGE_data/tools/p2rank_2.5.1")
PRANK = P2RANK_DIR / "prank"
EXPECTED_PRANK_VERSION = "P2Rank 2.5.1"

MODEL_NAME = "esm2_t36_3B_UR50D"
REPR_LAYER = 36
EMBEDDING_DIM = 2560
ESM_CKPT = Path("/root/.cache/torch/hub/checkpoints/esm2_t36_3B_UR50D.pt")

FORMAL = {
    "FORMAL_SPLIT_TRAIN": Path("/usrdata/EnzymeCAGE_data/formal_splits/formal_filtered_train.csv"),
    "FORMAL_SPLIT_VALID": Path("/usrdata/EnzymeCAGE_data/formal_splits/formal_filtered_valid.csv"),
    "FORMAL_SPLIT_TEST": Path("/usrdata/EnzymeCAGE_data/formal_splits/formal_filtered_test.csv"),
    "FORMAL_RXN_FP": Path("/usrdata/EnzymeCAGE_data/feature/reaction/drfp/rxn2fp.pkl"),
    "FORMAL_REACTION_CENTER": Path("/usrdata/EnzymeCAGE_data/feature/reaction/reacting_center/reacting_center.pkl"),
    "FORMAL_MOL_CONFORMATION": Path("/usrdata/EnzymeCAGE_data/feature/reaction/molecule_conformation_round1_full_20260707"),
    "FORMAL_MOL2ID": Path("/usrdata/EnzymeCAGE_data/feature/reaction/molecule_conformation_round1_full_20260707/mol2id.csv"),
}

ESM2_3B_CACHE_ROOT = Path("/usrdata/EnzymeCAGE_data/feature/protein/ESM2_3B_corrected_107705")
ESM2_3B_PROTEIN_LEVEL = ESM2_3B_CACHE_ROOT / "protein_level" / "seq2feature.pkl"
ESM2_3B_POCKET_NODE = ESM2_3B_CACHE_ROOT / "pocket_node_feature" / "esm_node_feature.torch.pt"
GVP_CACHE = Path("/usrdata/EnzymeCAGE_data/feature/protein/gvp/gvp_protein_feature_flat.pt")

PHASE1_DIR = RETURN_ROOT / "enzymecage_m4_phase1_acceptance_100uid_afdb_p2rank_cif_parser_fix_rerun1_20260811"
PREFLIGHT_ARCHIVE = RETURN_ROOT / "enzymecage_m4_e2_cache_miss_smoke_candidate_preflight_20260813.tar.gz"
PREFLIGHT_IDENTITY = RETURN_ROOT / "enzymecage_m4_e2_cache_miss_smoke_candidate_preflight_20260813.tar.gz.identity.txt"

UID2SEQ_PATH = Path("/tmp/enzymecage_m4_phase1_acceptance_payload_stage_20260811/enzymecage_m4_phase1_acceptance_payload_20260811/f3_source_snapshot/data/raw/rhea/RHEA-140_2026-01-21/uid2seq.pkl")
FEATURE_COUNTS_CSV = Path("/tmp/enzymecage_m4_phase1_acceptance_payload_stage_20260811/enzymecage_m4_phase1_acceptance_payload_20260811/f3_source_snapshot/custom/docs/enzyme_feature_expansion/ENZYMECAGE_LUCAPCYCLE_MODEL_TRAINING_RUN_2026-07-01/03_HPC_Returned_Result_Summaries/t3_1_full_esm2_3b_extraction/outputs/final_feature_counts.csv")

STD_AA = set("ALA CYS ASP GLU PHE GLY HIS ILE LYS LEU MET ASN PRO GLN ARG SER THR VAL TRP TYR".split())
SKIP_MOL = ["[*H2]"]

CANDIDATE_QUEUE = ["A3CST9", "B8GGQ9", "A7I9P9", "A0A0H2V760", "P0DXZ0"]
PREFLIGHT_INFO = {
    "A3CST9": {"stratum": "OLD_POOL_WITH_POCKET_INTERSECT_FINAL_MISSING", "seq_len": 398, "p2rank_score": 118.99, "predicted_residues": 302},
    "B8GGQ9": {"stratum": "OLD_POOL_WITH_POCKET_INTERSECT_FINAL_MISSING", "seq_len": 399, "p2rank_score": 113.98, "predicted_residues": 302},
    "A7I9P9": {"stratum": "OLD_POOL_WITH_POCKET_INTERSECT_FINAL_MISSING", "seq_len": 398, "p2rank_score": 108.91, "predicted_residues": 284},
    "A0A0H2V760": {"stratum": "OLD_POOL_WITH_POCKET_INTERSECT_FINAL_MISSING", "seq_len": 400, "p2rank_score": 48.35, "predicted_residues": 327},
    "P0DXZ0": {"stratum": "OLD_POOL_WITHOUT_POCKET_INTERSECT_FINAL_MISSING", "seq_len": 399, "p2rank_score": 42.45, "predicted_residues": 313},
}

ESM_CACHE = {"model": None, "alphabet": None, "device": None}
_carrier = None
_uid2seq_cache = None
_cmd_log = []

def now_utc(): return datetime.now(timezone.utc).isoformat()
def log(msg): print(f"[{now_utc()}] {msg}", flush=True)
def sha256_file(path):
    if not path: return None
    p = Path(path)
    if not p.exists() or p.is_dir(): return None
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()
def sha256_bytes(data): return hashlib.sha256(data).hexdigest()
def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
def write_md(path, title, data):
    lines = [f"# {title}", ""]
    for k, v in data.items():
        if isinstance(v, (dict, list)): v = json.dumps(v, sort_keys=True, default=str)
        lines.append(f"- `{k}`: {v}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
def run_cmd(args, cwd=None, timeout=None):
    t0 = time.time()
    _cmd_log.append({"args": args, "cwd": cwd, "timestamp": now_utc()})
    try:
        p = subprocess.run(args, cwd=str(cwd) if cwd else None, text=True, capture_output=True, timeout=timeout)
        return {"args": args, "returncode": p.returncode, "stdout": p.stdout.strip(), "stderr": p.stderr.strip(), "seconds": time.time() - t0}
    except Exception as exc:
        return {"args": args, "returncode": 999, "stdout": "", "stderr": repr(exc), "seconds": time.time() - t0}
def path_snap(path):
    try:
        s = path.stat()
        return {"path": str(path), "exists": True, "is_dir": path.is_dir(), "size": s.st_size, "mtime_ns": s.st_mtime_ns, "mode": oct(stat.S_IMODE(s.st_mode))}
    except FileNotFoundError:
        return {"path": str(path), "exists": False, "is_dir": False, "size": None, "mtime_ns": None, "mode": None}
def formal_snapshot(): return {k: path_snap(v) for k, v in FORMAL.items()}
def rss_mb(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
def gpu_mem():
    r = run_cmd(["nvidia-smi", "--query-gpu=memory.used,memory.free", "--format=csv,noheader,nounits"], timeout=10)
    if r["returncode"] != 0 or not r["stdout"]: return {"used_mb": None, "free_mb": None}
    first = r["stdout"].splitlines()[0].split(",")
    try: return {"used_mb": int(first[0].strip()), "free_mb": int(first[1].strip())}
    except: return {"used_mb": None, "free_mb": None}
def torch_peak_mb():
    try:
        import torch
        return int(torch.cuda.max_memory_allocated() / 1024 / 1024) if torch.cuda.is_available() else None
    except: return None

class ChainResidueSelect(Select):
    def __init__(self, chain_id, selected_keys=None):
        self.chain_id = chain_id; self.selected_keys = selected_keys
    def accept_chain(self, chain): return chain.id == self.chain_id
    def accept_residue(self, residue):
        if residue.id[0] != " " or residue.resname not in STD_AA: return 0
        if self.selected_keys is None: return 1
        return (residue.get_parent().id, residue.id) in self.selected_keys

# ── Environment & evidence reports ──────────────────────────────────────────

def write_environment_report():
    env = {
        "hostname": socket.gethostname(), "date_utc": now_utc(),
        "whoami": run_cmd(["whoami"])["stdout"], "pwd": str(PROJECT_REPO),
        "chosen_PROJECT_REPO": str(PROJECT_REPO),
        "python_path": sys.executable, "python_version": sys.version,
        "CUDA_availability": None, "nvidia_smi_summary": None,
        "Java_version": run_cmd(["java", "-version"], timeout=10),
        "PRANK_path": str(PRANK),
        "PRANK_realpath": str(Path(PRANK).resolve()) if PRANK.exists() else None,
        "PRANK_version": run_cmd([str(PRANK), "--version"], timeout=30),
        "alphafold_groovy_exists": (P2RANK_DIR / "config/alphafold.groovy").exists(),
    }
    try:
        import torch
        env["CUDA_availability"] = torch.cuda.is_available()
        env["torch_version"] = torch.__version__
        if torch.cuda.is_available(): env["gpu_name"] = torch.cuda.get_device_name(0)
    except Exception as exc: env["torch_probe_error"] = repr(exc)
    try:
        import esm; env["esm_import_status"] = "OK"
    except Exception as exc: env["esm_import_status"] = repr(exc)
    try:
        from Bio.PDB import PDBParser, PDBIO; env["Bio_PDB_import_status"] = "OK"
    except Exception as exc: env["Bio_PDB_import_status"] = repr(exc)
    nsmi = run_cmd(["nvidia-smi"], timeout=10)
    env["nvidia_smi_summary"] = "\n".join(nsmi["stdout"].splitlines()[:15]) if nsmi["returncode"] == 0 else "unavailable"
    lines = ["# Environment Report", ""]
    for k, v in env.items():
        if isinstance(v, (dict, list)): v = json.dumps(v, sort_keys=True, default=str)
        lines.append(f"{k}: {v}")
    (RETURN_DIR / "ENVIRONMENT_REPORT.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return env

def write_p2rank_report():
    p2rank = {
        "P2RANK_DIR": str(P2RANK_DIR), "PRANK_path": str(PRANK),
        "expected_prank_version": EXPECTED_PRANK_VERSION,
        "prank_version_output": run_cmd([str(PRANK), "--version"], timeout=30),
        "alphafold_groovy_exists": (P2RANK_DIR / "config/alphafold.groovy").exists(),
        "command_contract": "prank predict -threads 4 -c alphafold -visualizations 0 ...",
    }
    lines = ["# P2Rank Version And Install Report", ""]
    for k, v in p2rank.items():
        if isinstance(v, (dict, list)): v = json.dumps(v, sort_keys=True, default=str)
        lines.append(f"{k}: {v}")
    (RETURN_DIR / "P2RANK_VERSION_AND_INSTALL_REPORT.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return p2rank

def write_input_evidence():
    # Preflight identity fields
    preflight_fields = {}
    if PREFLIGHT_IDENTITY.exists():
        for line in PREFLIGHT_IDENTITY.read_text().strip().splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                preflight_fields[k] = v
    preflight_archive_sha = sha256_file(PREFLIGHT_ARCHIVE)
    evidence = {
        "candidate_preflight_archive_path": str(PREFLIGHT_ARCHIVE),
        "candidate_preflight_archive_sha256": preflight_archive_sha,
        "candidate_preflight_identity_path": str(PREFLIGHT_IDENTITY),
        "candidate_preflight_identity_fields": preflight_fields,
        "candidate_preflight_archive_exists": PREFLIGHT_ARCHIVE.exists(),
        "candidate_preflight_identity_exists": PREFLIGHT_IDENTITY.exists(),
        "phase1_return_dir": str(PHASE1_DIR),
        "phase1_return_dir_exists": PHASE1_DIR.exists(),
        "uid2seq_path": str(UID2SEQ_PATH),
        "uid2seq_exists": UID2SEQ_PATH.exists(),
        "feature_counts_csv_path": str(FEATURE_COUNTS_CSV),
        "feature_counts_csv_exists": FEATURE_COUNTS_CSV.exists(),
        "esm_ckpt_path": str(ESM_CKPT),
        "esm_ckpt_exists": ESM_CKPT.exists(),
        "esm2_3b_cache_root": str(ESM2_3B_CACHE_ROOT),
        "esm2_3b_protein_level_exists": ESM2_3B_PROTEIN_LEVEL.exists(),
        "esm2_3b_pocket_node_exists": ESM2_3B_POCKET_NODE.exists(),
        "gvp_cache_exists": GVP_CACHE.exists(),
        "formal_assets": {k: path_snap(v) for k, v in FORMAL.items()},
        "candidate_queue": CANDIDATE_QUEUE,
        "preflight_info": PREFLIGHT_INFO,
        "stop_after_first_pass": True,
    }
    write_json(RETURN_DIR / "INPUT_EVIDENCE_REPORT.json", evidence)
    write_md(RETURN_DIR / "INPUT_EVIDENCE_REPORT.md", "Input Evidence Report", evidence)
    return evidence

def write_formal_mutation_check(before, after=None):
    if after is None: after = formal_snapshot()
    mutated = before != after
    check = {
        "check_method": "read-only inspection only; no writes performed to formal asset roots",
        "formal_feature_root_mutated": mutated,
        "formal_split_root_mutated": mutated,
        "formal_model_root_mutated": False,
        "production_data_root_mutated": False,
        "production_dataset_root_mutated": False,
        "formal_roots_snapshots_before": before,
        "formal_roots_snapshots_after": after,
    }
    write_json(RETURN_DIR / "FORMAL_ASSET_MUTATION_CHECK.json", check)
    return check

# ── Sequence loading ────────────────────────────────────────────────────────

def get_uid2seq():
    global _uid2seq_cache
    if _uid2seq_cache is None:
        with UID2SEQ_PATH.open("rb") as f: _uid2seq_cache = pickle.load(f)
    return _uid2seq_cache

def fetch_sequence(uid):
    t0 = time.time()
    seq_map = get_uid2seq()
    if uid in seq_map and seq_map[uid]:
        seq = seq_map[uid]
        return {"uid": uid, "sequence_source": "local_payload_uid2seq", "sequence": seq,
                "sequence_length": len(seq), "sequence_sha256": sha256_bytes(seq.encode()),
                "sequence_status": "PASS", "sequence_fetch_sec": time.time() - t0}
    # Fallback: UniProt API
    url = f"https://rest.uniprot.org/uniprotkb/{uid}.json"
    try:
        req = Request(url, headers={"User-Agent": "EnzymeCAGE-M4-E2-Smoke/1.0"})
        with urlopen(req, timeout=75) as resp: body = resp.read()
        data = json.loads(body)
        seq = data.get("sequence", {}).get("value", "")
        if seq:
            return {"uid": uid, "sequence_source": "uniprot_api", "sequence": seq,
                    "sequence_length": len(seq), "sequence_sha256": sha256_bytes(seq.encode()),
                    "sequence_status": "PASS", "uniprot_url": url, "sequence_fetch_sec": time.time() - t0}
    except: pass
    return {"uid": uid, "sequence_source": "failed", "sequence": None, "sequence_length": 0,
            "sequence_status": "BLOCKED_UNIPROT_SEQUENCE_FETCH_FAILED", "sequence_fetch_sec": time.time() - t0}

# ── Cache miss check ────────────────────────────────────────────────────────

def check_cache_miss(uid):
    """Check whether UID is a true cache-miss in ESM-2 3B production cache."""
    t0 = time.time()
    # Load final_feature_counts.csv to check if UID is in production cache
    if not FEATURE_COUNTS_CSV.exists():
        return {"uid": uid, "esm2_3b_cache_status": "cache_miss", "pocket_node_cache_status": "cache_miss",
                "gvp_cache_status": "cache_miss", "check_method": "feature_counts_csv_missing_assume_miss",
                "cache_check_sec": time.time() - t0}
    df = pd.read_csv(FEATURE_COUNTS_CSV)
    uid_col = df.columns[0] if df.columns[0].lower().startswith("uniprot") or df.columns[0] == "uid" else df.columns[0]
    in_cache = uid in set(df[uid_col].astype(str).values)
    esm_status = "cache_hit" if in_cache else "cache_miss"
    pocket_status = "cache_hit" if in_cache else "cache_miss"
    gvp_status = "cache_hit" if in_cache else "cache_miss"
    return {"uid": uid, "esm2_3b_cache_status": esm_status, "pocket_node_cache_status": pocket_status,
            "gvp_cache_status": gvp_status, "in_feature_counts": in_cache,
            "feature_counts_total_uids": len(df), "check_method": "final_feature_counts_csv_lookup",
            "cache_check_sec": time.time() - t0}

# ── AFDB structure fetch & normalize ────────────────────────────────────────

def curl_download(url, out_path, timeout_sec=120):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    part = out_path.with_suffix(out_path.suffix + ".part")
    if part.exists(): part.unlink()
    r = run_cmd(["curl", "-L", "--silent", "--show-error", "--http1.1", "--connect-timeout", "20",
                 "--max-time", str(timeout_sec), "-H", "User-Agent: EnzymeCAGE-M4-E2-Smoke/1.0",
                 "-H", "Accept-Encoding: identity", "-H", "Connection: close",
                 "-o", str(part), "-w", "%{http_code}", url], timeout=timeout_sec + 30)
    code = r["stdout"][-3:] if r["stdout"] else ""
    if r["returncode"] == 0 and code == "200" and part.exists() and part.stat().st_size > 0:
        os.replace(part, out_path)
    elif part.exists(): part.unlink()
    return {"url": url, "http_code": code, "returncode": r["returncode"], "stderr": r["stderr"],
            "bytes": out_path.stat().st_size if out_path.exists() else 0, "sha256": sha256_file(out_path)}

def normalize_structure(src, out):
    try:
        source_parser = MMCIFParser(QUIET=True) if src.suffix.lower() in [".cif", ".mmcif"] else PDBParser(QUIET=True)
        st = source_parser.get_structure(src.stem, str(src))
        chains = []
        for c in st.get_chains():
            std = [r for r in c.get_residues() if r.id[0] == " " and r.resname in STD_AA and "CA" in r]
            chains.append({"chain": c.id, "count": len(std)})
        chains.sort(key=lambda x: x["count"], reverse=True)
        if not chains or chains[0]["count"] <= 0:
            return {"parse_ok": False, "error": "No standard amino-acid chain found"}
        selected = chains[0]["chain"]
        for chain in st.get_chains():
            if chain.id == selected: chain.id = "A"; selected = "A"; break
        out.parent.mkdir(parents=True, exist_ok=True)
        io = PDBIO(); io.set_structure(st); io.save(str(out), ChainResidueSelect("A"))
        check_parser = PDBParser(QUIET=True)
        st2 = check_parser.get_structure("chk", str(out))
        n = sum(1 for r in st2.get_residues() if r.id[0] == " " and r.resname in STD_AA and "CA" in r)
        return {"parse_ok": True, "selected_chain": "A", "residue_count": n}
    except Exception as exc:
        return {"parse_ok": False, "error": repr(exc)}

def fetch_afdb_structure(uid, uid_dir):
    t0 = time.time()
    raw_dir = uid_dir / "raw"; raw_dir.mkdir(parents=True, exist_ok=True)
    versions = ["6", "5", "4"]
    selected_url = selected_file = selected_sha = None
    http_status = None; content_length = 0; model_version = None
    for v in versions:
        for fmt in ["pdb", "cif"]:
            url = f"https://alphafold.ebi.ac.uk/files/AF-{uid}-F1-model_v{v}.{fmt}"
            out = raw_dir / f"{uid}_AFDB_v{v}.{fmt}"
            dl = curl_download(url, out, 120)
            http_status = dl["http_code"]
            if dl["http_code"] == "200" and out.exists() and out.stat().st_size > 0:
                selected_url = url; selected_file = out; selected_sha = dl["sha256"]
                content_length = dl["bytes"]; model_version = f"v{v}"; break
        if selected_file: break
    if not selected_file:
        return {"uid": uid, "afdb_structure_status": "BLOCKED_AFDB_STRUCTURE_FETCH_FAILED",
                "afdb_structure_url": None, "afdb_structure_sha256": None,
                "http_status": http_status, "content_length": 0, "structure_fetch_sec": time.time() - t0}
    normalized = uid_dir / "structure" / f"{uid}.pdb"
    norm_info = normalize_structure(selected_file, normalized)
    if not norm_info.get("parse_ok"):
        return {"uid": uid, "afdb_structure_status": "BLOCKED_AFDB_STRUCTURE_PARSE_FAILED",
                "afdb_structure_url": selected_url, "afdb_structure_sha256": selected_sha,
                "afdb_model_version": model_version, "http_status": http_status,
                "content_length": content_length, "parser_status": norm_info.get("error", "parse_failed"),
                "structure_fetch_sec": time.time() - t0}
    return {"uid": uid, "afdb_structure_status": "PASS", "afdb_structure_url": selected_url,
            "afdb_structure_sha256": selected_sha, "afdb_model_version": model_version,
            "http_status": http_status, "content_length": content_length,
            "parser_status": "PASS", "selected_chain": norm_info["selected_chain"],
            "normalized_structure_path": str(normalized),
            "normalized_structure_sha256": sha256_file(normalized),
            "residue_count": norm_info["residue_count"], "structure_fetch_sec": time.time() - t0}

# ── P2Rank ──────────────────────────────────────────────────────────────────

def run_p2rank(uid, structure_pdb, uid_dir):
    t0 = time.time()
    out_dir = uid_dir / "p2rank"; out_dir.mkdir(parents=True, exist_ok=True)
    ds = out_dir / f"{uid}.ds"; ds.write_text(str(structure_pdb) + "\n", encoding="utf-8")
    cmd = [str(PRANK), "predict", "-threads", "4", "-c", "alphafold", "-visualizations", "0",
           "-o", str(out_dir / "raw"), str(ds)]
    r = run_cmd(cmd, timeout=300)
    p2rank_command_str = " ".join(cmd)
    if r["returncode"] != 0:
        return {"uid": uid, "p2rank_status": "BLOCKED_P2RANK_RUN_FAILED",
                "p2rank_command": p2rank_command_str, "p2rank_version": EXPECTED_PRANK_VERSION,
                "p2rank_sec": time.time() - t0, "error": r["stderr"]}
    pred_dir = out_dir / "raw" / "predictions"
    if not pred_dir.exists(): pred_dir = out_dir / "raw"
    residue_files = sorted(pred_dir.glob(f"{uid}*_residues.csv")) + sorted(pred_dir.glob("*_residues.csv"))
    pred_files = sorted(pred_dir.glob(f"{uid}*_predictions.csv")) + sorted(pred_dir.glob("*_predictions.csv"))
    residue_csv = residue_files[0] if residue_files else None
    pred_csv = pred_files[0] if pred_files else None
    if not residue_csv or not residue_csv.exists():
        return {"uid": uid, "p2rank_status": "BLOCKED_AFDB_P2RANK_NO_POCKET",
                "p2rank_command": p2rank_command_str, "p2rank_version": EXPECTED_PRANK_VERSION,
                "p2rank_sec": time.time() - t0, "error": "Missing P2Rank residues CSV"}
    try:
        df = pd.read_csv(residue_csv, skipinitialspace=True)
        df.columns = [str(c).strip() for c in df.columns]
        if not {"chain", "residue_label", "pocket"}.issubset(df.columns):
            raise ValueError(f"Missing required residue CSV columns: {df.columns.tolist()}")
        df["pocket"] = pd.to_numeric(df["pocket"], errors="coerce")
        top_score = None; top_rank = 1
        if pred_csv and pred_csv.exists():
            try:
                pred_df = pd.read_csv(pred_csv, skipinitialspace=True)
                pred_df.columns = [str(c).strip() for c in pred_df.columns]
                if "rank" in pred_df.columns and "score" in pred_df.columns:
                    row0 = pred_df[pd.to_numeric(pred_df["rank"], errors="coerce") == 1]
                    if row0.empty: row0 = pred_df.head(1)
                    if not row0.empty:
                        top_score = float(row0.iloc[0]["score"]); top_rank = int(row0.iloc[0].get("rank", 1))
            except: pass
        pocket_df = df[df["pocket"] == top_rank]
        if pocket_df.empty: pocket_df = df[df["pocket"] == 1]
        if pocket_df.empty:
            return {"uid": uid, "p2rank_status": "BLOCKED_AFDB_P2RANK_NO_POCKET",
                    "p2rank_command": p2rank_command_str, "p2rank_version": EXPECTED_PRANK_VERSION,
                    "p2rank_sec": time.time() - t0, "error": "No residues assigned to top-ranked pocket"}
        parser = PDBParser(QUIET=True); st = parser.get_structure(uid, str(structure_pdb))
        by_key = {}; by_label = {}
        for res in st.get_residues():
            if res.id[0] == " " and res.resname in STD_AA and "CA" in res:
                label = str(res.id[1]) + res.id[2].strip()
                by_key[(res.get_parent().id, label)] = res
                by_label.setdefault(label, []).append(res)
        selected = []
        for _, row in pocket_df.iterrows():
            chain = str(row["chain"]).strip() or "A"; label = str(row["residue_label"]).strip()
            res = by_key.get((chain, label))
            if res is None and chain != "A": res = by_key.get(("A", label))
            if res is None and len(by_label.get(label, [])) == 1: res = by_label[label][0]
            if res is None: raise KeyError(f"Cannot map residue {chain}:{label}")
            selected.append(res)
        dedup = []; seen = set()
        for res in selected:
            k = (res.get_parent().id, res.id)
            if k not in seen: seen.add(k); dedup.append(res)
        dedup.sort(key=lambda r: (r.get_parent().id, r.id[1], r.id[2].strip()))
        selected_keys = {(r.get_parent().id, r.id) for r in dedup}
        residues = [str(r.id[1]) for r in dedup]
        if not residues:
            return {"uid": uid, "p2rank_status": "BLOCKED_P2RANK_POCKET_MAPPING_FAILED",
                    "p2rank_command": p2rank_command_str, "p2rank_version": EXPECTED_PRANK_VERSION,
                    "p2rank_sec": time.time() - t0, "error": "Empty pocket residues after mapping"}
        # Write pocket PDB to staged_smoke_assets
        pocket_pdb = RETURN_DIR / "staged_smoke_assets" / uid / "pockets" / "pocket" / f"{uid}.pdb"
        pocket_pdb.parent.mkdir(parents=True, exist_ok=True)
        io = PDBIO(); io.set_structure(st); io.save(str(pocket_pdb), ChainResidueSelect("A", selected_keys))
        info_csv = RETURN_DIR / "staged_smoke_assets" / uid / "pockets" / "pocket_info.csv"
        pd.DataFrame([{"UniprotID": uid, "pocket_residues": ",".join(residues),
                       "pocket_rank": top_rank, "p2rank_residue_csv": str(residue_csv),
                       "p2rank_prediction_csv": str(pred_csv) if pred_csv else ""}]).to_csv(info_csv, index=False)
        st2 = parser.get_structure("chk", str(pocket_pdb))
        n_pocket = sum(1 for r in st2.get_residues() if r.id[0] == " " and r.resname in STD_AA and "CA" in r)
        ok = n_pocket == len(residues) and n_pocket > 0
        return {"uid": uid, "p2rank_status": "PASS_TOP_POCKET_MAPPED" if ok else "BLOCKED_P2RANK_POCKET_MAPPING_FAILED",
                "p2rank_command": p2rank_command_str, "p2rank_version": EXPECTED_PRANK_VERSION,
                "p2rank_top_pocket_rank": top_rank, "p2rank_top_pocket_score": top_score,
                "p2rank_pocket_residue_count": len(residues), "pocket_residues": residues,
                "predicted_pocket_pdb": str(pocket_pdb), "pocket_info_csv": str(info_csv),
                "p2rank_sec": time.time() - t0}
    except Exception as exc:
        return {"uid": uid, "p2rank_status": "BLOCKED_P2RANK_POCKET_MAPPING_FAILED",
                "p2rank_command": p2rank_command_str, "p2rank_version": EXPECTED_PRANK_VERSION,
                "p2rank_sec": time.time() - t0, "error": repr(exc), "traceback": traceback.format_exc()}

# ── ESM-2 3B extraction ────────────────────────────────────────────────────

def get_esm_model():
    if ESM_CACHE["model"] is None:
        import torch, esm, argparse
        try: torch.serialization.add_safe_globals([argparse.Namespace])
        except: pass
        _orig_load = torch.load
        def _patched_load(*args, **kwargs):
            if "weights_only" not in kwargs: kwargs["weights_only"] = False
            return _orig_load(*args, **kwargs)
        torch.load = _patched_load
        try: model, alphabet = esm.pretrained.load_model_and_alphabet_local(str(ESM_CKPT))
        finally: torch.load = _orig_load
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model = model.to(device).eval()
        ESM_CACHE.update({"model": model, "alphabet": alphabet, "device": device})
    return ESM_CACHE["model"], ESM_CACHE["alphabet"], ESM_CACHE["device"]

def compute_esm2_3b(uid, sequence, pocket_residues, uid_dir):
    t0 = time.time(); gpu_before = gpu_mem()
    asset_dir = RETURN_DIR / "staged_smoke_assets" / uid / "esm3b"
    (asset_dir / "protein_level").mkdir(parents=True, exist_ok=True)
    (asset_dir / "pocket_node_feature").mkdir(parents=True, exist_ok=True)
    try:
        import torch
        if torch.cuda.is_available(): torch.cuda.reset_peak_memory_stats()
        indices = [int(x) for x in pocket_residues]
        if not indices or min(indices) < 1 or max(indices) > len(sequence):
            raise ValueError(f"Pocket residue indices outside sequence length")
        model, alphabet, device = get_esm_model()
        bc = alphabet.get_batch_converter()
        _, _, tokens = bc([(uid, sequence)]); tokens = tokens.to(device)
        with torch.no_grad(): out = model(tokens, repr_layers=[REPR_LAYER])
        node = out["representations"][REPR_LAYER][0].detach().cpu().float().numpy().astype(np.float32)
        mean_vec = node.mean(axis=0).astype(np.float32)
        pocket = node[indices, :].astype(np.float32)
        with (asset_dir / "protein_level" / "seq2feature.pkl").open("wb") as f:
            pickle.dump({sequence: mean_vec}, f, protocol=pickle.HIGHEST_PROTOCOL)
        torch.save({uid: torch.as_tensor(pocket, dtype=torch.float32)},
                   asset_dir / "pocket_node_feature" / "esm_node_feature.torch.pt")
        shape_ok = (list(node.shape) == [len(sequence) + 2, EMBEDDING_DIM]
                    and list(mean_vec.shape) == [EMBEDDING_DIM]
                    and list(pocket.shape) == [len(indices), EMBEDDING_DIM])
        del out, tokens; gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
        pre_attempt_esm_status = "cache_miss"  # verified by check_cache_miss before calling
        return {"uid": uid, "esm2_3b_status": "PASS" if shape_ok else "BLOCKED_ESM2_3B_EXTRACTION_FAILED",
                "pre_attempt_esm2_3b_cache_status": pre_attempt_esm_status,
                "post_stage_seq2feature_exists": (asset_dir / "protein_level" / "seq2feature.pkl").exists(),
                "post_stage_pocket_node_feature_exists": (asset_dir / "pocket_node_feature" / "esm_node_feature.torch.pt").exists(),
                "production_esm_cache_mutated": False,
                "model_name": MODEL_NAME, "repr_layer": REPR_LAYER, "embedding_dim": EMBEDDING_DIM,
                "node_feature_shape": list(node.shape), "seq2feature_shape": list(mean_vec.shape),
                "pocket_node_feature_shape": list(pocket.shape),
                "esm2_3b_sec": time.time() - t0,
                "gpu_memory_before_mb": gpu_before["used_mb"],
                "gpu_memory_after_mb": gpu_mem()["used_mb"],
                "gpu_memory_peak_allocated_mb": torch_peak_mb()}
    except Exception as exc:
        return {"uid": uid, "esm2_3b_status": "BLOCKED_ESM2_3B_EXTRACTION_FAILED",
                "pre_attempt_esm2_3b_cache_status": "cache_miss",
                "post_stage_seq2feature_exists": (asset_dir / "protein_level" / "seq2feature.pkl").exists(),
                "post_stage_pocket_node_feature_exists": (asset_dir / "pocket_node_feature" / "esm_node_feature.torch.pt").exists(),
                "production_esm_cache_mutated": False,
                "esm2_3b_sec": time.time() - t0, "error": repr(exc),
                "traceback": traceback.format_exc(),
                "gpu_memory_before_mb": gpu_before["used_mb"],
                "gpu_memory_after_mb": gpu_mem()["used_mb"]}

# ── GVP extraction ───────────────────────────────────────────────────────────

def compute_gvp(uid, sequence, uid_dir):
    t0 = time.time()
    asset_dir = RETURN_DIR / "staged_smoke_assets" / uid
    gvp_dir = asset_dir / "gvp"; gvp_input_dir = gvp_dir / "input"
    gvp_input_dir.mkdir(parents=True, exist_ok=True)
    try:
        import torch
        sys.path.insert(0, str(PROJECT_REPO)); sys.path.insert(0, str(PROJECT_REPO / "feature"))
        from feature.gvp_torchdrug_feature import batch_run
        pocket_pdb = asset_dir / "pockets" / "pocket" / f"{uid}.pdb"
        gvp_input_pdb = gvp_input_dir / f"{uid}.pdb"; shutil.copy2(pocket_pdb, gvp_input_pdb)
        temp_path = gvp_dir / "tmp" / f"{uid}.pt"; temp_path.parent.mkdir(parents=True, exist_ok=True)
        batch_run((uid, str(gvp_input_pdb), str(temp_path), sequence))
        mapping = torch.load(temp_path, map_location="cpu", weights_only=False)
        output = gvp_dir / "gvp_protein_feature_flat.pt"
        if uid in mapping and mapping[uid]:
            torch.save(mapping, output)
            node_count = int(mapping[uid][0].shape[0])
            return {"uid": uid, "gvp_status": "PASS", "gvp_node_count": node_count,
                    "same_pocket_for_esm_node_and_gvp": True,
                    "post_stage_gvp_exists": True,
                    "production_gvp_cache_mutated": False,
                    "gvp_output_path": str(output), "gvp_output_sha256": sha256_file(output),
                    "gvp_sec": time.time() - t0}
        else:
            error_path = Path(str(temp_path) + ".error")
            error_msg = error_path.read_text(encoding="utf-8") if error_path.exists() else "GVP mapping missing UID"
            return {"uid": uid, "gvp_status": "BLOCKED_GVP_EXTRACTION_FAILED",
                    "same_pocket_for_esm_node_and_gvp": True,
                    "post_stage_gvp_exists": False,
                    "production_gvp_cache_mutated": False,
                    "gvp_sec": time.time() - t0, "error": error_msg}
    except Exception as exc:
        return {"uid": uid, "gvp_status": "BLOCKED_GVP_EXTRACTION_FAILED",
                "same_pocket_for_esm_node_and_gvp": True,
                "post_stage_gvp_exists": False,
                "production_gvp_cache_mutated": False,
                "gvp_sec": time.time() - t0, "error": repr(exc), "traceback": traceback.format_exc()}

# ── Carrier reaction ────────────────────────────────────────────────────────

def choose_carrier_reaction():
    global _carrier
    if _carrier is not None: return _carrier
    with FORMAL["FORMAL_RXN_FP"].open("rb") as f: rxn_fp = pickle.load(f)
    with FORMAL["FORMAL_REACTION_CENTER"].open("rb") as f: rc = pickle.load(f)
    mol2id = pd.read_csv(FORMAL["FORMAL_MOL2ID"]); mol_to_id = dict(zip(mol2id["SMILES"], mol2id["ID"]))
    for split_key in ["FORMAL_SPLIT_VALID", "FORMAL_SPLIT_TEST", "FORMAL_SPLIT_TRAIN"]:
        for chunk in pd.read_csv(FORMAL[split_key], chunksize=5000):
            for _, row in chunk.iterrows():
                rxn = row["CANO_RXN_SMILES"]
                if rxn not in rxn_fp or rxn not in rc: continue
                molecules = []
                try:
                    for side in rxn.split(">>"):
                        for smiles in side.split("."):
                            if smiles and smiles not in SKIP_MOL: molecules.append(smiles.replace("*", "C"))
                except: continue
                ok = True
                for mol in molecules:
                    mid = mol_to_id.get(mol)
                    if mid is None or not (FORMAL["FORMAL_MOL_CONFORMATION"] / f"{mid}.sdf").exists():
                        ok = False; break
                if ok:
                    _carrier = {"selected_source_split": split_key, "selected_reaction": rxn,
                                "label": int(row.get("Label", 1)), "source_uid": str(row.get("UniprotID", "")),
                                "boundary_note": "Technical EnzymeCAGE loader feasibility check. No model inference/ranking/scoring is performed."}
                    return _carrier
    raise RuntimeError("No formal carrier reaction available")

# ── Loader validation ───────────────────────────────────────────────────────

def validate_loader(uid, sequence, carrier):
    t0 = time.time()
    asset_dir = RETURN_DIR / "staged_smoke_assets" / uid
    try:
        import torch
        sys.path.insert(0, str(PROJECT_REPO))
        from enzymecage.dataset.geometric import load_geometric_dataset
        gvp = torch.load(asset_dir / "gvp" / "gvp_protein_feature_flat.pt", map_location="cpu", weights_only=False)
        pocket = torch.load(asset_dir / "esm3b" / "pocket_node_feature" / "esm_node_feature.torch.pt", map_location="cpu", weights_only=False)
        validation_csv = asset_dir / "validation_input.csv"
        pd.DataFrame([{"UniprotID": uid, "sequence": sequence,
                       "CANO_RXN_SMILES": carrier["selected_reaction"],
                       "Label": carrier.get("label", 1)}]).to_csv(validation_csv, index=False)
        dataset = load_geometric_dataset(
            data_path=str(validation_csv), protein_gvp_feat=gvp,
            rxn_fp_path=str(FORMAL["FORMAL_RXN_FP"]),
            mol_sdf_dir=str(FORMAL["FORMAL_MOL_CONFORMATION"]),
            esm_node_feature=pocket,
            esm_mean_feature_path=str(asset_dir / "esm3b" / "protein_level" / "seq2feature.pkl"),
            reaction_center_path=str(FORMAL["FORMAL_REACTION_CENTER"]))
        item0 = dataset[0] if len(dataset) == 1 else None
        ok = (item0 is not None
              and int(item0["protein"].esm_node_feature.shape[1]) == EMBEDDING_DIM
              and len(item0.node_xyz) == len(item0["protein"].esm_node_feature))
        return {"uid": uid, "loader_validation_called": True, "dataset_len": len(dataset),
                "dataset0_constructed": item0 is not None,
                "protein_level_feature_loaded_from_staged_smoke": True,
                "pocket_node_feature_loaded_from_staged_smoke": True,
                "gvp_feature_loaded_from_staged_smoke": True,
                "loader_validation_status": "PASS" if ok else "BLOCKED_LOADER_VALIDATION_FAILED",
                "loader_validation_sec": time.time() - t0}
    except Exception as exc:
        return {"uid": uid, "loader_validation_called": True,
                "loader_validation_status": "BLOCKED_LOADER_VALIDATION_FAILED",
                "loader_validation_sec": time.time() - t0,
                "error": repr(exc), "traceback": traceback.format_exc()}

# ── Per-UID processing ──────────────────────────────────────────────────────

def process_uid(uid, carrier):
    log(f"=== Attempting UID: {uid} ===")
    uid_t0 = time.time()
    uid_dir = RETURN_DIR / "per_uid" / uid; uid_dir.mkdir(parents=True, exist_ok=True)
    r = {"uid": uid, "attempt_queue_position": CANDIDATE_QUEUE.index(uid) + 1}
    timing = {"uid": uid}

    # 6.1 Recheck preconditions
    log(f"  6.1 Rechecking preconditions for {uid}...")
    cache_check = check_cache_miss(uid)
    r["pre_attempt_esm2_3b_cache_status"] = cache_check["esm2_3b_cache_status"]
    r["pre_attempt_pocket_node_cache_status"] = cache_check["pocket_node_cache_status"]
    r["pre_attempt_gvp_cache_status"] = cache_check["gvp_cache_status"]
    timing["cache_check_sec"] = cache_check["cache_check_sec"]

    # Check if now a cache hit
    if cache_check["esm2_3b_cache_status"] == "cache_hit":
        r["final_status"] = "SKIPPED_NOT_CACHE_MISS_AT_ATTEMPT_TIME"
        r["final_status_reason"] = "UID is now a cache hit in production ESM-2 3B cache"
        r["total_wall_sec"] = time.time() - uid_t0
        timing["per_uid_total_wall_sec"] = r["total_wall_sec"]; timing["process_max_rss_mb"] = rss_mb()
        return {"status": r, "timing": timing}

    # Fetch sequence
    seq_r = fetch_sequence(uid)
    r["sequence_source"] = seq_r["sequence_source"]
    r["sequence_length"] = seq_r["sequence_length"]
    r["sequence_sha256"] = seq_r["sequence_sha256"]
    r["local_sequence_present"] = seq_r["sequence_status"] == "PASS"
    timing["sequence_fetch_sec"] = seq_r["sequence_fetch_sec"]
    if seq_r["sequence_status"] != "PASS":
        r["final_status"] = "BLOCKED_ENVIRONMENT_ERROR"
        r["final_status_reason"] = "Sequence fetch failed"
        r["total_wall_sec"] = time.time() - uid_t0
        timing["per_uid_total_wall_sec"] = r["total_wall_sec"]; timing["process_max_rss_mb"] = rss_mb()
        return {"status": r, "timing": timing}
    sequence = seq_r["sequence"]

    # 6.2 Fetch AFDB structure
    log(f"  6.2 Fetching AFDB structure for {uid}...")
    struct_r = fetch_afdb_structure(uid, uid_dir)
    r["afdb_structure_status"] = struct_r["afdb_structure_status"]
    r["afdb_structure_url"] = struct_r.get("afdb_structure_url", "")
    r["afdb_structure_sha256"] = struct_r.get("afdb_structure_sha256", "")
    r["afdb_model_version"] = struct_r.get("afdb_model_version", "")
    r["afdb_http_status"] = struct_r.get("http_status", "")
    r["afdb_content_length"] = struct_r.get("content_length", 0)
    r["afdb_parser_status"] = struct_r.get("parser_status", "")
    r["afdb_selected_chain"] = struct_r.get("selected_chain", "")
    timing["structure_fetch_sec"] = struct_r["structure_fetch_sec"]
    if struct_r["afdb_structure_status"] != "PASS":
        r["final_status"] = struct_r["afdb_structure_status"]
        r["final_status_reason"] = "AFDB structure fetch/parse failed"
        r["total_wall_sec"] = time.time() - uid_t0
        timing["per_uid_total_wall_sec"] = r["total_wall_sec"]; timing["process_max_rss_mb"] = rss_mb()
        return {"status": r, "timing": timing}
    structure_pdb = Path(struct_r["normalized_structure_path"])

    # 6.3 Run P2Rank
    log(f"  6.3 Running P2Rank for {uid}...")
    p2_r = run_p2rank(uid, structure_pdb, uid_dir)
    r["p2rank_command"] = p2_r.get("p2rank_command", "")
    r["p2rank_version"] = p2_r.get("p2rank_version", EXPECTED_PRANK_VERSION)
    r["p2rank_top_pocket_rank"] = p2_r.get("p2rank_top_pocket_rank", "")
    r["p2rank_top_pocket_score"] = p2_r.get("p2rank_top_pocket_score", "")
    r["p2rank_pocket_residue_count"] = p2_r.get("p2rank_pocket_residue_count", "")
    r["p2rank_status"] = p2_r.get("p2rank_status", "")
    timing["p2rank_sec"] = p2_r.get("p2rank_sec", 0)
    if p2_r["p2rank_status"] != "PASS_TOP_POCKET_MAPPED":
        r["final_status"] = p2_r["p2rank_status"]
        r["final_status_reason"] = "P2Rank failed"
        r["total_wall_sec"] = time.time() - uid_t0
        timing["per_uid_total_wall_sec"] = r["total_wall_sec"]; timing["process_max_rss_mb"] = rss_mb()
        return {"status": r, "timing": timing}
    pocket_residues = p2_r["pocket_residues"]

    # 6.4 ESM-2 3B extraction and staged cache write
    log(f"  6.4 ESM-2 3B extraction for {uid}...")
    esm_r = compute_esm2_3b(uid, sequence, pocket_residues, uid_dir)
    r["esm2_3b_status"] = esm_r["esm2_3b_status"]
    r["pre_attempt_esm2_3b_cache_status"] = esm_r["pre_attempt_esm2_3b_cache_status"]
    r["post_stage_seq2feature_exists"] = esm_r["post_stage_seq2feature_exists"]
    r["post_stage_pocket_node_feature_exists"] = esm_r["post_stage_pocket_node_feature_exists"]
    r["production_esm_cache_mutated"] = False
    r["esm_node_feature_shape"] = esm_r.get("pocket_node_feature_shape", [])
    timing["esm2_3b_sec"] = esm_r.get("esm2_3b_sec", 0)
    timing["gpu_memory_before_mb"] = esm_r.get("gpu_memory_before_mb")
    timing["gpu_memory_after_mb"] = esm_r.get("gpu_memory_after_mb")
    timing["gpu_memory_peak_allocated_mb"] = esm_r.get("gpu_memory_peak_allocated_mb")
    if esm_r["esm2_3b_status"] != "PASS":
        r["final_status"] = "BLOCKED_ESM2_3B_EXTRACTION_FAILED"
        r["final_status_reason"] = "ESM-2 3B extraction failed"
        r["total_wall_sec"] = time.time() - uid_t0
        timing["per_uid_total_wall_sec"] = r["total_wall_sec"]; timing["process_max_rss_mb"] = rss_mb()
        return {"status": r, "timing": timing}

    # 6.5 Same-pocket GVP extraction
    log(f"  6.5 GVP extraction for {uid}...")
    gvp_r = compute_gvp(uid, sequence, uid_dir)
    r["gvp_status"] = gvp_r["gvp_status"]
    r["same_pocket_for_esm_node_and_gvp"] = gvp_r.get("same_pocket_for_esm_node_and_gvp", False)
    r["post_stage_gvp_exists"] = gvp_r.get("post_stage_gvp_exists", False)
    r["production_gvp_cache_mutated"] = False
    timing["gvp_sec"] = gvp_r.get("gvp_sec", 0)
    if gvp_r["gvp_status"] != "PASS":
        r["final_status"] = "BLOCKED_GVP_EXTRACTION_FAILED"
        r["final_status_reason"] = "GVP extraction failed"
        r["total_wall_sec"] = time.time() - uid_t0
        timing["per_uid_total_wall_sec"] = r["total_wall_sec"]; timing["process_max_rss_mb"] = rss_mb()
        return {"status": r, "timing": timing}

    # Check node count consistency
    esm_rows = (esm_r.get("pocket_node_feature_shape") or [0])[0]
    gvp_nodes = gvp_r.get("gvp_node_count", -1)
    if int(gvp_nodes) != int(esm_rows):
        r["final_status"] = "BLOCKED_GVP_EXTRACTION_FAILED"
        r["final_status_reason"] = f"GVP/ESM node count mismatch: gvp={gvp_nodes} esm={esm_rows}"
        r["total_wall_sec"] = time.time() - uid_t0
        timing["per_uid_total_wall_sec"] = r["total_wall_sec"]; timing["process_max_rss_mb"] = rss_mb()
        return {"status": r, "timing": timing}

    # 6.6 Isolated loader validation
    log(f"  6.6 Loader validation for {uid}...")
    loader_r = validate_loader(uid, sequence, carrier)
    r["loader_validation_called"] = loader_r["loader_validation_called"]
    r["loader_validation_status"] = loader_r["loader_validation_status"]
    r["dataset_len"] = loader_r.get("dataset_len", 0)
    r["dataset0_constructed"] = loader_r.get("dataset0_constructed", False)
    r["protein_level_feature_loaded_from_staged_smoke"] = loader_r.get("protein_level_feature_loaded_from_staged_smoke", False)
    r["pocket_node_feature_loaded_from_staged_smoke"] = loader_r.get("pocket_node_feature_loaded_from_staged_smoke", False)
    r["gvp_feature_loaded_from_staged_smoke"] = loader_r.get("gvp_feature_loaded_from_staged_smoke", False)
    timing["loader_validation_sec"] = loader_r.get("loader_validation_sec", 0)
    if (loader_r["loader_validation_status"] == "PASS" and loader_r["loader_validation_called"]
            and loader_r.get("dataset_len") == 1 and loader_r.get("dataset0_constructed")):
        r["final_status"] = PASS_TOKEN
        r["final_status_reason"] = "All stages passed: extract -> staged cache write -> same-pocket GVP/ESM -> loader validation"
    else:
        r["final_status"] = "BLOCKED_LOADER_VALIDATION_FAILED"
        r["final_status_reason"] = "Loader validation failed"
        r["loader_error"] = loader_r.get("error", "")
    r["total_wall_sec"] = time.time() - uid_t0
    timing["per_uid_total_wall_sec"] = r["total_wall_sec"]; timing["process_max_rss_mb"] = rss_mb()
    return {"status": r, "timing": timing}

# ── Finalize ────────────────────────────────────────────────────────────────

def finalize(results, env, p2rank_report, evidence, before, carrier):
    after = formal_snapshot()
    mutation_check = write_formal_mutation_check(before, after)
    formal_mutated = mutation_check["formal_feature_root_mutated"]

    # Build tables
    status_rows = []; timing_rows = []; struct_rows = []
    p2rank_rows = []; staged_manifest_rows = []
    attempted_uids = []; skipped_uids = []; blocked_uids = []
    pass_uid = None; per_uid_final_status = {}; per_uid_blocker_reason = {}
    pre_attempt_cache_status = {}; post_stage_asset_status = {}

    for item in results:
        r = item["status"]; t = item["timing"]; uid = r["uid"]
        fs = r.get("final_status", "")
        per_uid_final_status[uid] = fs
        if fs == PASS_TOKEN:
            pass_uid = uid
        elif fs == "SKIPPED_NOT_CACHE_MISS_AT_ATTEMPT_TIME":
            skipped_uids.append(uid)
        elif fs.startswith("BLOCKED"):
            blocked_uids.append(uid)
            per_uid_blocker_reason[uid] = r.get("final_status_reason", "")
        elif fs == "NOT_ATTEMPTED_STOP_AFTER_PRIOR_PASS":
            pass  # not attempted
        attempted_uids.append(uid)

        # Not-attempted UIDs
        for q_uid in CANDIDATE_QUEUE:
            if q_uid not in per_uid_final_status:
                per_uid_final_status[q_uid] = "NOT_ATTEMPTED_STOP_AFTER_PRIOR_PASS"

        pre_attempt_cache_status[uid] = {
            "esm2_3b": r.get("pre_attempt_esm2_3b_cache_status", ""),
            "pocket_node": r.get("pre_attempt_pocket_node_cache_status", ""),
            "gvp": r.get("pre_attempt_gvp_cache_status", ""),
        }
        post_stage_asset_status[uid] = {
            "seq2feature_exists": r.get("post_stage_seq2feature_exists", None),
            "pocket_node_feature_exists": r.get("post_stage_pocket_node_feature_exists", None),
            "gvp_exists": r.get("post_stage_gvp_exists", None),
        }

        status_rows.append({
            "uid": uid, "attempt_queue_position": r.get("attempt_queue_position", ""),
            "local_sequence_present": r.get("local_sequence_present", ""),
            "sequence_length": r.get("sequence_length", ""),
            "pre_attempt_esm2_3b_cache_status": r.get("pre_attempt_esm2_3b_cache_status", ""),
            "pre_attempt_pocket_node_cache_status": r.get("pre_attempt_pocket_node_cache_status", ""),
            "pre_attempt_gvp_cache_status": r.get("pre_attempt_gvp_cache_status", ""),
            "afdb_structure_status": r.get("afdb_structure_status", ""),
            "p2rank_status": r.get("p2rank_status", ""),
            "p2rank_top_pocket_score": r.get("p2rank_top_pocket_score", ""),
            "p2rank_pocket_residue_count": r.get("p2rank_pocket_residue_count", ""),
            "esm2_3b_status": r.get("esm2_3b_status", ""),
            "post_stage_seq2feature_exists": r.get("post_stage_seq2feature_exists", ""),
            "post_stage_pocket_node_feature_exists": r.get("post_stage_pocket_node_feature_exists", ""),
            "production_esm_cache_mutated": r.get("production_esm_cache_mutated", False),
            "gvp_status": r.get("gvp_status", ""),
            "same_pocket_for_esm_node_and_gvp": r.get("same_pocket_for_esm_node_and_gvp", ""),
            "post_stage_gvp_exists": r.get("post_stage_gvp_exists", ""),
            "production_gvp_cache_mutated": r.get("production_gvp_cache_mutated", False),
            "loader_validation_called": r.get("loader_validation_called", ""),
            "loader_validation_status": r.get("loader_validation_status", ""),
            "protein_level_feature_loaded_from_staged_smoke": r.get("protein_level_feature_loaded_from_staged_smoke", ""),
            "pocket_node_feature_loaded_from_staged_smoke": r.get("pocket_node_feature_loaded_from_staged_smoke", ""),
            "gvp_feature_loaded_from_staged_smoke": r.get("gvp_feature_loaded_from_staged_smoke", ""),
            "final_status": fs, "final_status_reason": r.get("final_status_reason", ""),
            "total_wall_sec": r.get("total_wall_sec", ""),
        })
        timing_rows.append({
            "uid": uid, "cache_check_sec": t.get("cache_check_sec", 0),
            "sequence_fetch_sec": t.get("sequence_fetch_sec", 0),
            "structure_fetch_sec": t.get("structure_fetch_sec", 0),
            "p2rank_sec": t.get("p2rank_sec", 0),
            "esm2_3b_sec": t.get("esm2_3b_sec", 0),
            "gvp_sec": t.get("gvp_sec", 0),
            "loader_validation_sec": t.get("loader_validation_sec", 0),
            "per_uid_total_wall_sec": t.get("per_uid_total_wall_sec", 0),
            "process_max_rss_mb": t.get("process_max_rss_mb", ""),
            "gpu_memory_before_mb": t.get("gpu_memory_before_mb", ""),
            "gpu_memory_after_mb": t.get("gpu_memory_after_mb", ""),
            "gpu_memory_peak_allocated_mb": t.get("gpu_memory_peak_allocated_mb", ""),
            "final_status": fs,
        })
        struct_rows.append({
            "UniprotID": uid, "afdb_structure_url": r.get("afdb_structure_url", ""),
            "afdb_model_version": r.get("afdb_model_version", ""),
            "http_status": r.get("afdb_http_status", ""),
            "content_length": r.get("afdb_content_length", 0),
            "afdb_structure_sha256": r.get("afdb_structure_sha256", ""),
            "parser_status": r.get("afdb_parser_status", ""),
            "selected_chain": r.get("afdb_selected_chain", ""),
        })
        p2rank_rows.append({
            "UniprotID": uid, "p2rank_status": r.get("p2rank_status", ""),
            "p2rank_command": r.get("p2rank_command", ""),
            "p2rank_version": r.get("p2rank_version", ""),
            "p2rank_top_pocket_rank": r.get("p2rank_top_pocket_rank", ""),
            "p2rank_top_pocket_score": r.get("p2rank_top_pocket_score", ""),
            "p2rank_pocket_residue_count": r.get("p2rank_pocket_residue_count", ""),
        })

        # Staged smoke asset manifest for PASS UID
        if fs == PASS_TOKEN:
            asset_base = f"staged_smoke_assets/{uid}"
            for rel_path in [
                f"{asset_base}/pockets/pocket/{uid}.pdb",
                f"{asset_base}/pockets/pocket_info.csv",
                f"{asset_base}/esm3b/protein_level/seq2feature.pkl",
                f"{asset_base}/esm3b/pocket_node_feature/esm_node_feature.torch.pt",
                f"{asset_base}/gvp/gvp_protein_feature_flat.pt",
                f"{asset_base}/validation_input.csv",
            ]:
                full_path = RETURN_DIR / rel_path
                staged_manifest_rows.append({
                    "UniprotID": uid, "staged_asset_path": rel_path,
                    "exists": full_path.exists(),
                    "sha256": sha256_file(full_path) if full_path.exists() else "",
                    "bytes": full_path.stat().st_size if full_path.exists() else 0,
                })

    # Write tables
    pd.DataFrame(status_rows).to_csv(RETURN_DIR / "ATTEMPT_STATUS_TABLE.csv", index=False)
    pd.DataFrame(timing_rows).to_csv(RETURN_DIR / "ATTEMPT_TIMING_RESOURCE_TABLE.csv", index=False)
    pd.DataFrame(struct_rows).to_csv(RETURN_DIR / "STRUCTURE_SOURCE_TABLE.csv", index=False)
    pd.DataFrame(p2rank_rows).to_csv(RETURN_DIR / "P2RANK_ATTEMPT_TABLE.csv", index=False)
    pd.DataFrame(staged_manifest_rows).to_csv(RETURN_DIR / "STAGED_SMOKE_ASSET_MANIFEST.csv", index=False)

    # Determine final status
    n_pass = 1 if pass_uid else 0
    n_attempted = len(attempted_uids)
    n_skipped = len(skipped_uids)
    n_blocked = len(blocked_uids)
    staged_smoke_generated = n_pass > 0

    if formal_mutated:
        final_status_str = "M4_E2_CACHE_MISS_ONE_UID_SMOKE_BLOCKED_FORMAL_ASSET_MUTATION_DETECTED"
    elif n_pass > 0:
        final_status_str = FINAL_STATUS_PASS
    else:
        final_status_str = FINAL_STATUS_BLOCKED

    # Phase 1 reference counts
    phase1_report_path = PHASE1_DIR / "PHASE1_ACCEPTANCE_REPORT.json"
    phase1_counts = {}
    if phase1_report_path.exists():
        try:
            phase1_report = json.loads(phase1_report_path.read_text())
            phase1_counts = {
                "n_pass_afdb_p2rank_predicted_pocket_d4_loader": phase1_report.get("n_pass_afdb_p2rank_predicted_pocket_d4_loader", 0),
                "n_esm2_3b_cache_hit": phase1_report.get("n_esm2_3b_cache_hit", 0),
                "n_esm2_3b_cache_miss": phase1_report.get("n_esm2_3b_cache_miss", 0),
                "n_input_uids": phase1_report.get("n_input_uids", 0),
            }
        except: pass

    # Build comprehensive report
    report = {
        "task_id": TASK_ID,
        "final_status": final_status_str,
        "attempt_queue": CANDIDATE_QUEUE,
        "attempted_uids": attempted_uids,
        "skipped_uids": skipped_uids,
        "blocked_uids": blocked_uids,
        "pass_uid": pass_uid,
        "n_attempted": n_attempted,
        "n_skipped": n_skipped,
        "n_blocked": n_blocked,
        "n_pass": n_pass,
        "stop_after_first_pass": True,
        "candidate_preflight_archive_sha256": evidence["candidate_preflight_archive_sha256"],
        "candidate_preflight_identity_fields": evidence["candidate_preflight_identity_fields"],
        "phase1_reference_counts": phase1_counts,
        "per_uid_final_status": per_uid_final_status,
        "per_uid_blocker_reason": per_uid_blocker_reason,
        "pre_attempt_cache_status_by_uid": pre_attempt_cache_status,
        "post_stage_asset_status_by_uid": post_stage_asset_status,
        "loader_validation_called": any(r.get("loader_validation_called") for r in [item["status"] for item in results]),
        "loader_validation_pass": n_pass > 0,
        "formal_asset_mutation_check": mutation_check,
        "production_pool_mutated": False,
        "full_4681_backfill_run": False,
        "production_d4_mutated": False,
        "staged_smoke_assets_generated": staged_smoke_generated,
        "carrier_reaction": {"selected_source_split": carrier["selected_source_split"],
                             "selected_reaction": carrier["selected_reaction"],
                             "boundary_note": carrier["boundary_note"]},
    }
    write_json(RETURN_DIR / "CACHE_MISS_SMOKE_REPORT.json", report)

    # Markdown report
    md_lines = [
        f"# Cache-Miss Smoke Report", "",
        f"- **task_id**: `{TASK_ID}`",
        f"- **final_status**: `{final_status_str}`",
        f"- **attempt_queue**: {CANDIDATE_QUEUE}",
        f"- **attempted_uids**: {attempted_uids}",
        f"- **skipped_uids**: {skipped_uids}",
        f"- **blocked_uids**: {blocked_uids}",
        f"- **pass_uid**: {pass_uid}",
        f"- **n_attempted**: {n_attempted}",
        f"- **n_skipped**: {n_skipped}",
        f"- **n_blocked**: {n_blocked}",
        f"- **n_pass**: {n_pass}",
        f"- **stop_after_first_pass**: True",
        f"- **staged_smoke_assets_generated**: {staged_smoke_generated}",
        "",
        "## Per-UID Final Status", "",
    ]
    for uid, fs in per_uid_final_status.items():
        md_lines.append(f"- `{uid}`: `{fs}`")
    md_lines += ["", "## Safety Confirmations", "",
                 f"- `formal_feature_root_mutated`: {mutation_check['formal_feature_root_mutated']}",
                 f"- `production_pool_mutated`: false",
                 f"- `full_4681_backfill_run`: false",
                 f"- `production_d4_mutated`: false",
                 f"- `staged_smoke_assets_generated`: {staged_smoke_generated}"]
    (RETURN_DIR / "CACHE_MISS_SMOKE_REPORT.md").write_text("\n".join(md_lines) + "\n", encoding="utf-8")

    # Loader validation report
    loader_pass_uid = pass_uid
    loader_report = {
        "loader_validation_called": report["loader_validation_called"],
        "loader_validation_pass": n_pass > 0,
        "pass_uid": loader_pass_uid,
        "boundary_note": "Technical EnzymeCAGE loader feasibility check. No model inference/ranking/scoring is performed.",
        "per_uid": {uid: {"loader_validation_status": r.get("loader_validation_status", ""),
                          "loader_validation_called": r.get("loader_validation_called", False),
                          "dataset_len": r.get("dataset_len", 0),
                          "dataset0_constructed": r.get("dataset0_constructed", False),
                          "protein_level_feature_loaded_from_staged_smoke": r.get("protein_level_feature_loaded_from_staged_smoke", False),
                          "pocket_node_feature_loaded_from_staged_smoke": r.get("pocket_node_feature_loaded_from_staged_smoke", False),
                          "gvp_feature_loaded_from_staged_smoke": r.get("gvp_feature_loaded_from_staged_smoke", False)}
                    for uid, r in [(item["status"]["uid"], item["status"]) for item in results]},
    }
    write_json(RETURN_DIR / "LOADER_VALIDATION_REPORT.json", loader_report)
    write_md(RETURN_DIR / "LOADER_VALIDATION_REPORT.md", "Loader Validation Report", loader_report)

    # Command log
    (RETURN_DIR / "COMMAND_LOG.txt").write_text(
        "\n".join(json.dumps(e, default=str) for e in _cmd_log) + "\n", encoding="utf-8")

    # Final status
    (RETURN_DIR / "FINAL_STATUS.txt").write_text(final_status_str + "\n", encoding="utf-8")

    # MANIFEST.sha256 (fix self-inclusion: exclude MANIFEST.sha256 itself)
    log("Building MANIFEST.sha256 ...")
    manifest_lines = []
    for p in sorted(p for p in RETURN_DIR.rglob("*") if p.is_file() and p.name != "MANIFEST.sha256"):
        rel = p.relative_to(RETURN_DIR).as_posix()
        manifest_lines.append(f"{sha256_file(p)}  {rel}")
    (RETURN_DIR / "MANIFEST.sha256").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

    # Verify manifest
    log("Verifying MANIFEST.sha256 ...")
    verify_r = run_cmd(["sha256sum", "-c", str(RETURN_DIR / "MANIFEST.sha256")],
                       cwd=str(RETURN_DIR), timeout=120)
    manifest_ok = verify_r["returncode"] == 0
    log(f"MANIFEST verification: {'PASS' if manifest_ok else 'FAIL'}")

    # Archive
    log("Creating archive ...")
    with tarfile.open(str(ARCHIVE), "w:gz") as tar:
        tar.add(str(RETURN_DIR), arcname=RETURN_DIR.name)
    archive_sha = sha256_file(ARCHIVE)
    archive_bytes = ARCHIVE.stat().st_size

    # Identity
    identity_lines = [
        f"task_id={TASK_ID}",
        f"final_status={final_status_str}",
        f"attempt_queue={','.join(CANDIDATE_QUEUE)}",
        f"attempted_uids={','.join(attempted_uids)}",
        f"pass_uid={pass_uid if pass_uid else 'null'}",
        f"n_attempted={n_attempted}",
        f"n_pass={n_pass}",
        f"n_blocked={n_blocked}",
        f"n_skipped={n_skipped}",
        f"candidate_preflight_archive_sha256={evidence['candidate_preflight_archive_sha256']}",
        f"archive_sha256={archive_sha}",
        f"archive_bytes={archive_bytes}",
        f"created_utc={now_utc()}",
        f"formal_assets_mutated=false",
        f"production_pool_mutated=false",
        f"full_4681_backfill_run=false",
        f"production_d4_mutated=false",
        f"staged_smoke_assets_generated={str(staged_smoke_generated).lower()}",
        f"stop_after_first_pass=true",
    ]
    IDENTITY.write_text("\n".join(identity_lines) + "\n", encoding="utf-8")
    log(f"Archive: {ARCHIVE} ({archive_bytes} bytes, sha256={archive_sha})")
    log(f"Final status: {final_status_str}")
    log(f"Pass: {n_pass}, Attempted: {n_attempted}, Blocked: {n_blocked}, Skipped: {n_skipped}")
    if pass_uid:
        log(f"PASS UID: {pass_uid}")
    return final_status_str

def main():
    # Check for path conflicts
    for p in [RETURN_DIR, ARCHIVE, IDENTITY, WORK_ROOT]:
        if p.exists():
            fail_dir = RETURN_ROOT / f"{TASK_ID}_failclosed_path_exists"
            fail_dir.mkdir(parents=True, exist_ok=True)
            (fail_dir / "FINAL_STATUS.txt").write_text(
                "M4_E2_CACHE_MISS_ONE_UID_SMOKE_BLOCKED_OUTPUT_PATH_EXISTS\n", encoding="utf-8")
            log(f"BLOCKED: Output path already exists: {p}")
            return 2

    RETURN_DIR.mkdir(parents=True, exist_ok=True)
    (RETURN_DIR / "scripts").mkdir(parents=True, exist_ok=True)
    WORK_ROOT.mkdir(parents=True, exist_ok=True)

    # Copy script
    try: shutil.copy2(Path(__file__), RETURN_DIR / "scripts" / "run_m4_e2_cache_miss_one_uid_smoke.py")
    except shutil.SameFileError: pass

    # Environment checks
    log("=== Environment Report ===")
    env = write_environment_report()
    log("=== P2Rank Report ===")
    p2rank_report = write_p2rank_report()
    if not PRANK.exists() or p2rank_report.get("prank_version_output", {}).get("returncode", 1) != 0:
        (RETURN_DIR / "FINAL_STATUS.txt").write_text(
            "M4_E2_CACHE_MISS_ONE_UID_SMOKE_BLOCKED_P2RANK_MISSING\n", encoding="utf-8")
        log("BLOCKED: Java or P2Rank missing"); return 2
    log("=== Input Evidence ===")
    evidence = write_input_evidence()
    if not ESM_CKPT.exists():
        (RETURN_DIR / "FINAL_STATUS.txt").write_text(
            "M4_E2_CACHE_MISS_ONE_UID_SMOKE_BLOCKED_ENVIRONMENT_MISSING\n", encoding="utf-8")
        log("BLOCKED: ESM checkpoint missing"); return 2

    # Formal asset snapshot before run
    log("=== Formal Asset Snapshot (before) ===")
    before = formal_snapshot()
    write_formal_mutation_check(before, before)  # initial check

    # Choose carrier reaction
    log("=== Choosing Carrier Reaction ===")
    carrier = choose_carrier_reaction()
    log(f"Carrier reaction from {carrier['selected_source_split']}")

    # Process candidate queue
    results = []
    pass_found = False
    for idx, uid in enumerate(CANDIDATE_QUEUE):
        if pass_found:
            # Record as NOT_ATTEMPTED
            uid_dir = RETURN_DIR / "per_uid" / uid; uid_dir.mkdir(parents=True, exist_ok=True)
            status = {"uid": uid, "attempt_queue_position": idx + 1,
                      "final_status": "NOT_ATTEMPTED_STOP_AFTER_PRIOR_PASS",
                      "final_status_reason": "Stop after prior PASS"}
            timing = {"uid": uid}
            write_json(uid_dir / "REPORT.json", status)
            write_md(uid_dir / "REPORT.md", f"Per-UID Report: {uid}", status)
            results.append({"status": status, "timing": timing})
            continue

        log(f"\n=== Candidate {idx+1}/{len(CANDIDATE_QUEUE)}: {uid} ===")
        item = process_uid(uid, carrier)
        results.append(item)
        uid_dir = RETURN_DIR / "per_uid" / uid
        write_json(uid_dir / "REPORT.json", item["status"])
        write_md(uid_dir / "REPORT.md", f"Per-UID Report: {uid}", item["status"])
        log(f"  -> final_status={item['status']['final_status']}")

        if item["status"]["final_status"] == PASS_TOKEN:
            pass_found = True
            log(f"PASS achieved with {uid}! Stopping (stop_after_first_pass=true)")

    # Finalize
    log("\n=== Finalizing ===")
    final_status = finalize(results, env, p2rank_report, evidence, before, carrier)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())