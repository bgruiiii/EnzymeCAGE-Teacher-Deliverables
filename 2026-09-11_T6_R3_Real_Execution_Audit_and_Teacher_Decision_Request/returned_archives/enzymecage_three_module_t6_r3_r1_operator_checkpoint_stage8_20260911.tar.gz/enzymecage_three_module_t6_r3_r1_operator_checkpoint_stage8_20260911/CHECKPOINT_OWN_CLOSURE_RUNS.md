# 本检查点自身运行了几次（与科学结果无关，仅为可审计性）

| # | 时间(UTC) | 脚本/动作 | 结果 | 产物去向 |
|---|---|---|---|---|
| 1 | 05:47 | c1 run1 | 首采集，但若干文件名凭记忆写成上一轮的 | 移存 CW/cd_stash_pre_final_1 |
| 2 | 06:04 | c1 run2 | 改成本轮实物名 + basename 兜底；61 条引用全部可解析 | 移存 CW/cd_stash_pre_final_1 |
| 3 | 06:09 | c1 run3/run4 | §7 stage 行修正为 6 字段；157 项改用实物字段名；新增 36/80 两视图变更对账 | 移存 CW/cd_stash_pre_final_2 |
| 4 | 06:10:31 | c2 run1（**部分失败**） | 5 项机械检查 0 problem、manifest、archive、fresh unpack、identity、validation 均已写成功；末尾 §9 打印行引用不存在的键 `recheck["all_pass"]` → KeyError 退出 | 三外置文件 + recheck JSON 移存 CW/run1_partial_closure/（含 SHA256SUMS.txt），未删除 |
| 5 | 06:12 | c1 run5 | 刷新采集（使脚本重试计数含 run1 修订）；此后 CD 内容即最终内容 | 本目录 |
| 6 | 06:11:59 | c2 run2 → 交付 attempt 1（**已撤回**） | 三文件产出且互相一致，但独立复核发现 **CHECKPOINT_PACKAGE_VALIDATION=FAIL**：identity `regular_files=366` 用的是写 manifest 之前的快照，而 tar 实际含 368 个文件；MANIFEST.sha256 也未覆盖 MANIFEST.files/MANIFEST.sha256 自身 | 移存 CW/run2_partial_closure/（未删除、未覆盖交付路径） |
| 7 | 之后 | c2 run3（**正式交付**） | 修正枚举：打包集合 = 封口时磁盘集合 ∪ 封口自身将写的 3 个文件；manifest/identity/unpack 全部用同一集合 | `enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911.tar.gz` + `.identity.txt` + `.validation.txt` |

事实说明：

- 缺陷 6 是打包工具自身的计数缺陷，不是科学结果问题；它恰好证明 §8 机械验证有效（FAIL 被真实捕获并阻止，而不是被掩盖）。
- 第 4、6 步产物全部保留在 CHECKPOINT_WORK 内并可复核（SHA256SUMS.txt），没有删除或覆盖任何交付路径。
- 全过程未重跑环境预检、157 项、资产哈希、native load、GPU forward、LangGraph 或 mutation；原任务工作区、返回目录与暂存仓库均为只读访问（本轮结束后其文件数仍为顶层 60 / 全部 80，运行进程数 0）。
