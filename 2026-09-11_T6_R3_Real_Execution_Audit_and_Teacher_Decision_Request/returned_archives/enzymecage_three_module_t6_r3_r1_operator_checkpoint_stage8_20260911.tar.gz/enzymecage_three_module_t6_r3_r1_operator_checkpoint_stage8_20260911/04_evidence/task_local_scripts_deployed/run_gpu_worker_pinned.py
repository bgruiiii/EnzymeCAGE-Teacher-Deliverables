"""T6-R1 per-worker forward runner.

Invoked once per physical GPU. Each worker:
  - sees exactly ONE CUDA device (CUDA_VISIBLE_DEVICES=<physical_index>),
  - imports the frozen D4 wrapper,
  - calls initialize_runtime(v1_overlay) EXACTLY once,
  - performs the sequence/ESM hard gate before any forward,
  - for each assigned request: predict(base) then predict(repeat),
  - writes results only under ${RETURN_DIR}/workers/worker_<id>/.
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--worker-id", type=int, required=True)
    p.add_argument("--gpu-index", type=int, required=True)
    p.add_argument("--gpu-uuid", type=str, required=True)
    p.add_argument("--requests", type=str, required=True,
                   help="JSON array of {request_label, reaction_task_id, reaction_smiles}")
    p.add_argument("--v1-overlay", type=str, required=True)
    p.add_argument("--d4-wrapper-dir", type=str, required=True)
    p.add_argument("--code-root", type=str, required=True)
    p.add_argument("--worker-out", type=str, required=True)
    p.add_argument("--seq-sha-json", type=str, required=True,
                   help="JSON map {uid: expected_sequence_sha256} from T6 CORRECTED_UID")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    # Pin thread env BEFORE importing torch so workers do not fight for CPU.
    for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[k] = "8"
    # Enforce single-GPU view (already set by launcher; reassert).
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu_index)
    # Add frozen code + D4 wrapper to path.
    sys.path.insert(0, args.code_root)
    sys.path.insert(0, args.d4_wrapper_dir)

    out_dir = Path(args.worker_out)
    out_dir.mkdir(parents=True, exist_ok=True)

    expected_seq_sha = json.loads(Path(args.seq_sha_json).read_text(encoding="utf-8"))

    result: dict = {
        "worker_id": args.worker_id,
        "physical_gpu_index": args.gpu_index,
        "expected_gpu_uuid": args.gpu_uuid,
        "host": socket.gethostname(),
        "pid": os.getpid(),
        "requests": json.loads(args.requests),
        "stdout_log": str(out_dir / "stdout.log"),
        "stderr_log": str(out_dir / "stderr.log"),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "monotonic_start": time.monotonic(),
        "status": "RUNNING",
        "events": [],
    }
    with open(out_dir / "worker_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    def flush():
        with open(out_dir / "worker_result.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

    try:
        import torch  # noqa: E402  after env pinning
        # ---- 1) CUDA isolation self-check (hard-gate before any work). ----
        if not torch.cuda.is_available():
            raise RuntimeError("torch.cuda.is_available() == False")
        dc = torch.cuda.device_count()
        if dc != 1:
            raise RuntimeError(f"expected exactly 1 CUDA device, got {dc}")
        # Fetch UUID of the single CUDA-visible device via torch (respects CUDA_VISIBLE_DEVICES).
        # NOTE: pynvml is absent here and NVML index ignores CUDA_VISIBLE_DEVICES (always GPU0),
        # so torch.cuda.get_device_properties(0).uuid is the only CUDA_VISIBLE_DEVICES-aware source.
        def _fetch_uuid():
            u = str(torch.cuda.get_device_properties(0).uuid)  # e.g. 'c5b417ae-...' (no prefix)
            return u if u.startswith("GPU-") else "GPU-" + u
        actual_uuid = _fetch_uuid()
        if actual_uuid != args.gpu_uuid:
            raise RuntimeError(f"worker cuda:0 UUID {actual_uuid} != expected {args.gpu_uuid}")
        result["actual_device_uuid"] = actual_uuid
        result["torch_visible_device_count"] = dc
        result["physical_gpu_count_on_host"] = len(subprocess.run(["nvidia-smi", "--query-gpu=uuid", "--format=csv,noheader"], capture_output=True, text=True).stdout.strip().splitlines())
        result["actual_device_name"] = torch.cuda.get_device_name(0)
        result["cuda_visible_devices_env"] = os.environ.get("CUDA_VISIBLE_DEVICES")
        mem = torch.cuda.mem_get_info(0)
        result["device_memory_free_mib"] = mem[0] // (1024 * 1024)
        result["device_memory_total_mib"] = mem[1] // (1024 * 1024)
        result["events"].append({"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                                 "monotonic": time.monotonic(), "step": "cuda_preflight_ok"})
        flush()

        # ---- 2) Import frozen D4 wrapper. ----
        from enzymecage_wrapper import predictor as wrapper_predictor  # noqa: E402
        from enzymecage_wrapper.schema import EnzymeCAGERequest  # noqa: E402
        result["events"].append({"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                                 "monotonic": time.monotonic(), "step": "wrapper_imported"})
        flush()

        # ---- 3) initialize_runtime EXACTLY ONCE. ----
        t_init0 = time.monotonic()
        runtime = wrapper_predictor.initialize_runtime(args.v1_overlay)
        t_init1 = time.monotonic()
        result["runtime_init_sec"] = round(t_init1 - t_init0, 3)
        # Verify checkpoint identity as observed by runtime (each seed file SHA).
        import hashlib
        cksum: dict = {}
        for seed in (40, 41, 42, 43, 44):
            pth = Path(args.v1_overlay) / "3b_ensemble" / f"seed_{seed}" / "best_model.pth"
            h = hashlib.sha256()
            with open(pth, "rb") as fp:
                for b in iter(lambda: fp.read(4 * 1024 * 1024), b""):
                    h.update(b)
            cksum[seed] = h.hexdigest()
        result["observed_checkpoint_sha256"] = cksum
        result["runtime_model_object_count"] = len(runtime.models)
        result["runtime_package_root"] = str(runtime.package_root)
        result["runtime_device"] = str(runtime.device)
        result["events"].append({"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                                 "monotonic": time.monotonic(), "step": "runtime_initialized"})
        flush()

        # ---- 4) Sequence/ESM identity hard gate (§8) BEFORE forward. ----
        ai = runtime.asset_index
        seq_gate: dict = {"uids": {}, "overall_pass": True, "issues": []}
        for uid in list(expected_seq_sha.keys()):
            entry = {"uid": uid}
            try:
                seq = ai.sequence_for(uid)
            except KeyError as exc:
                entry.update({"ok": False, "reason": f"sequence_for raised KeyError: {exc}"})
                seq_gate["overall_pass"] = False
                seq_gate["issues"].append(entry["reason"])
                seq_gate["uids"][uid] = entry
                continue
            entry["sequence_len"] = len(seq)
            entry["sequence_non_empty"] = bool(seq)
            import hashlib as _h
            seq_sha = _h.sha256(seq.encode("utf-8")).hexdigest()
            entry["sequence_sha256"] = seq_sha
            entry["sequence_sha256_matches_T6"] = (seq_sha == expected_seq_sha[uid])
            entry["uid_in_gvp"] = uid in ai.gvp
            entry["uid_in_pocket_node"] = uid in ai.pocket_node
            entry["sequence_in_esm_mean"] = seq in ai.sequence_esm
            entry["not_ambiguous"] = uid not in ai.ambiguous_uids
            esm_mean_vec = ai.sequence_esm.get(seq)
            if esm_mean_vec is None:
                esm_all_zero = None
                esm_nonzero = False
            else:
                try:
                    esm_all_zero = bool((esm_mean_vec.abs().sum().item() == 0.0))
                except AttributeError:
                    import torch as _t
                    tt = _t.as_tensor(esm_mean_vec)
                    esm_all_zero = bool((tt.abs().sum().item() == 0.0))
                esm_nonzero = not esm_all_zero
            entry["esm_mean_all_zero"] = esm_all_zero
            entry["esm_mean_nonzero"] = esm_nonzero
            ok = (entry["sequence_non_empty"] and entry["sequence_sha256_matches_T6"]
                  and entry["uid_in_gvp"] and entry["uid_in_pocket_node"]
                  and entry["sequence_in_esm_mean"] and entry["not_ambiguous"] and esm_nonzero)
            entry["ok"] = ok
            if not ok:
                seq_gate["overall_pass"] = False
                seq_gate["issues"].append(f"uid {uid} failed seq/ESM gate: {entry}")
            seq_gate["uids"][uid] = entry
        (out_dir / "SEQUENCE_ESM_IDENTITY_CHECK.json").write_text(
            json.dumps(seq_gate, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        result["sequence_gate_pass"] = seq_gate["overall_pass"]
        result["events"].append({"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                                 "monotonic": time.monotonic(), "step": "seq_esm_gate_done"})
        flush()
        if not seq_gate["overall_pass"]:
            raise RuntimeError("BLOCKED_AT_SEQUENCE_ESM_IDENTITY")

        # ---- 5) For each assigned request: predict(base) + predict(repeat). ----
        def run_predict(req_label: str, rid: str, rxn: str, mode: str):
            req = EnzymeCAGERequest(
                reaction_smiles=rxn,
                enzyme_pool_uids=["A0A011QK89", "A0A017SP50"],
                top_k=2,
                return_ci=True,
            )
            t0 = time.monotonic()
            u0 = time.time()
            resp = runtime.predict(req)
            t1 = time.monotonic()
            trace = dict(runtime.last_trace or {})
            per_seed = trace.get("per_seed_scores") or []
            rec = {
                "request_label": req_label,
                "reaction_task_id": rid,
                "reaction_smiles": rxn,
                "mode": mode,
                "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(u0)),
                "monotonic_start": t0,
                "monotonic_end": t1,
                "elapsed_sec": round(t1 - t0, 4),
                "forward_executed": trace.get("forward_executed"),
                "batch_count": trace.get("batch_count"),
                "batch_size": trace.get("batch_size"),
                "original_uids": trace.get("original_uids"),
                "unique_uids": trace.get("unique_uids"),
                "valid_uids": trace.get("valid_uids"),
                "returned_uids": trace.get("returned_uids"),
                "per_seed_scores": per_seed,
                "ranked_enzymes": [
                    {"uid": row.uid, "rank": row.rank, "score": row.score, "ensemble_ci": row.ensemble_ci}
                    for row in resp.ranked_enzymes
                ],
                "evidence_hash": resp.evidence_hash,
                "model_version": resp.model_version,
                "forward_call_count_after": runtime.forward_call_count,
            }
            return rec

        per_request: dict = {}
        for item in result["requests"]:
            label = item["request_label"]
            rid = item["reaction_task_id"]
            rxn = item["reaction_smiles"]
            base = run_predict(label, rid, rxn, "base")
            (out_dir / f"{label}_base.json").write_text(json.dumps(base, ensure_ascii=False, indent=2), encoding="utf-8")
            rep = run_predict(label, rid, rxn, "repeat")
            (out_dir / f"{label}_repeat.json").write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
            per_request[label] = {"base": base, "repeat": rep}
            result["events"].append({"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                                     "monotonic": time.monotonic(), "step": f"forward_done_{label}"})
            flush()
        result["per_request"] = per_request

        # ---- 6) Capture peak GPU memory and end timestamps. ----
        try:
            peak_bytes = torch.cuda.max_memory_allocated(0)
            result["peak_cuda_mem_allocated_mib"] = peak_bytes // (1024 * 1024)
        except Exception:
            pass
        result["monotonic_end"] = time.monotonic()
        result["ended_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        result["status"] = "OK"
        flush()
        return 0
    except Exception as exc:
        result["status"] = "FAILED"
        result["error_type"] = type(exc).__name__
        result["error_msg"] = str(exc)
        import traceback
        result["traceback"] = traceback.format_exc()
        result["monotonic_end"] = time.monotonic()
        result["ended_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        flush()
        print(f"WORKER_FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        print(result["traceback"], file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
