# Real Smoke Selection Pre-registration (T6-R3-R1 §8 stage A)

run_utc: 2026-09-11T04:27:23Z
pinned interpreter: `/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python`
observer: `p14b_prereg_observer.py` sha256=0421aae5d7738246ad87150642a7435935ed1da39ee3b4d41cbb755d09fef84d exit=0 wall=14.3s
teacher graph: `/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910/depending_teacher_fixed_r1/src/graph.py` compiled once with real `langgraph.graph.StateGraph` (14 nodes); CUDA_VISIBLE_DEVICES=""; torch imported: False
UID map sha: 7b92e8e625cb73f070c8e902687ea5bbdbf749f04a19828e550e3fe205684fe6 (bytes=104025134)
C8 lookup sha: d51a540db2f9798d65e25b46f22960ba29ae2d4b288be218c83c299f24f5d5af (bytes=57211793); porTraits NOT enabled
§7 forward evidence: `T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl` sha256=01f22baf362ff323f4617e1a4abe4b46150773e4afc1bc945c1eb876667972ae; scores csv sha256=e132065939077388594367532d0f992186fbe163a5055ffb894992b3b8e69815

## Rules (fixed before any full-chain observation)
- S1: CASE_B real pool, pool order = production build_enzyme_pool order (sorted EC iteration + dict.fromkeys dedup); take the highest-rank UID with >=1 OBSERVED trait among F1-F15 from the production C8TraitAdapter; if none, take rank 1 and record the observed-coverage block
- S2: CASE_C real pool, same production pool order; take the highest-rank UID with >=1 MISSING trait among F1-F15 from the production C8TraitAdapter; if none, take rank 1 and record the reason
- S3-S8: contract §5 frozen UID order ['A0A011QK89', 'A0A017SP50', 'A0A017SR40'] intersected with the UIDs really forwarded in the §7 record for that staged reaction, first two; preselection_rank = that UID's real EnzymeCAGE rank inside the §7 base ranking
- CASE_B_PRIMARY_SUCCESS / CASE_C_FALLBACK_SUCCESS are **contract scenario labels**: the teacher tree contains no such identifiers (verified by grep over the frozen source); the labels are bound to real graph runs as follows, and nothing was hand-typed to make them fit.

## Real runs the selection was made from
| label | substrate (source) | executed nodes | route | pool |
|---|---|---|---|---|
| CASE_B_PRIMARY_SUCCESS | `CN1CCC[C@H]1c1ccc(O)nc1` read from `cases/case_1_realrun.json:expected.substrate.smiles` | orchestrator>substrate>reaction>enzyme_pool | B | 14 |
| CASE_C_FALLBACK_SUCCESS | `CCCCCCCCCC=O` (first eligible entry of the §6 probe battery, eligibility = real production route C with pool>=1, tie-break largest pool, then shortest then lexicographic SMILES) | orchestrator>substrate>reaction>enzyme_pool | C | 17 |

C battery as really observed (all 8 frozen candidates, none hidden):
- `CCCC(C)N` route=C pool=2 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `C[C@@H]1Cc2c3c(cc(O)c2C(=O)O1)O[C@@]1(C)CC[C@H]2C(C)(C)C(=O)CC[C@]2(C)[C@@H]1C3` route=C pool=8 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCC/C=C\CCCCCCCC(=O)OC[C@H](CO)OC(=O)CCCCCCC/C=C\CCCCCCCC` route=C pool=8 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCCCC=O` route=C pool=17 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCCCCCCC/C=C/[C@@H](O)[C@H](CO)NC(=O)CCCCC` route=C pool=7 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCCCCCCC/C=C/[C@@H](O)[C@H](CO)NC(=O)CCCCCCCCCCCCCCC` route=C pool=4 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCC/C=C\CCCCCCCC(=O)OC[C@H](CO)OC(=O)CCCCCCC/C=C\CCCCCCCC` route=C pool=8 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCC/C=C\CCCCCCCC(=O)OC[C@@H](O)COP(=O)(O)O` route=C pool=17 nodes=orchestrator>substrate>reaction>enzyme_pool error=

## Selections (real pools, real production C8TraitAdapter)
B pool order: `["A0A0H3LKL4", "O87682", "Q88FY1", "Q93NH4", "A0A075BSX9", "P08159", "O87681", "Q59128", "F8G0P2", "Q933N0", "Q59127", "P86491", "Q88FY2", "Q93NH5"]`
C pool order: `["P76217", "Q88JH0", "O06413", "O33855", "P9WIN5", "P9WQ55", "Q88JH5", "P9WQ51", "Q04458", "O05307", "Q6F7B8", "A0R618", "Q79FC3", "C5BK10", "P39518", "A0A0L8M630", "P69451"]`
S1 selected UID = O87682 (pool rank 2, OBSERVED traits=10 ['F1', 'F2', 'F4', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12', 'F14'])
S2 selected UID = P76217 (pool rank 1, MISSING traits=15)
S1 fallback_to_rank1=False ; S2 fallback_to_rank1=False
Trait probe carrier: `PROBE_CARRIER_NOT_FINAL_HOST` - the real host evidence for the final chain must come from the real microbe node output in §8 stage B; nothing here may be reused as a host claim.

## S3-S8 source rows (§7 real forward, frozen UID order)
- `RT-1a7bea59ede1acf0` `c1ccc2[nH]nnc2c1>>Nc1ccccc1C(=O)[O-]` sha256(prod)=1652ac57f073c02b… evidence_hash=756d513638ef1ec9… real ranks=[['A0A017SP50', 1], ['A0A011QK89', 2]]
- `RT-f00e98d322e2380e` `Nc1ccccc1C(=O)[O-]>>Oc1ccccc1O` sha256(prod)=33504ceadd0a929b… evidence_hash=… real ranks=[]
- `RT-bbb9dc4b010674c1` `Nc1ccccc1C(=O)[O-]>>C=C(OC1C=C(C(=O)[O-])C=CC1O)C(=O)[O-]` sha256(prod)=149ab7c3474ddd1b… evidence_hash=… real ranks=[]

## §5 minimum coverage table as early as this stage
- database_lookup (enviPath known-route) -> False (no such node/adapter/condition exists in the teacher fixed topology; see LOOKUP_THEN_PREDICTION_ORDER=NOT_ESTABLISHED in ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json)
- controlled_prediction (enviPath-gated fallback) -> False (reachable only behind a lookup that does not exist; the graph's own reaction_prediction node is driven by route_after_reaction's pipeline_mode/candidate_reactions test)
- proxy (T3A frozen proxy) -> None (decided in §8 stage B / TEST-06)
- staged generated reaction -> True (S3—S8 from the three §7 RT-* staged forward records)
- UNMATCHED / fail-closed enzyme -> None (C1 / TEST-09 in §8 stage B)
- MISSING trait -> True (production C8TraitAdapter MISSING classes above)
- OBSERVED trait -> True (S1 selection under rule 1; if false the observed-coverage gate stays blocked)

## Honesty constraints
- No substrate, UID, rank, route or hash was typed by hand; every value in `REAL_SMOKE_INPUTS.csv` points at a file, a real run, or a production return value.
- `wrapper_model_version` / `forward_evidence_hash` stay explicit `NOT_OBSERVED_AT_PREREGISTRATION` placeholders for S1/S2 until §8-B really runs the wrapper; they are never guessed forward.
- Samples cannot be switched after the final output: the eight selection hashes above are frozen here, and §8-B/§8-C must reference these record ids verbatim.
- `preselection_rank` for S1/S2 is the **pool rank** produced by `build_enzyme_pool`; if the §8-B real EnzymeCAGE ranking puts these UIDs elsewhere, the record is kept and both orders are reported - the sample is never swapped.
- enviPath known-route lookup is NOT part of the teacher fixed topology (`LOOKUP_THEN_PREDICTION_ORDER=NOT_ESTABLISHED`, ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json); because contract §5 counts "database lookup" and "controlled prediction" in the minimum coverage table, this gap also blocks any final READY claim here, independently of this gate's own verdict.
- Teacher topology, nodes, routers and edges were only imported and executed, never edited: `TOPOLOGY_BYTES_EQUAL_4_3_RECORD=YES`.

