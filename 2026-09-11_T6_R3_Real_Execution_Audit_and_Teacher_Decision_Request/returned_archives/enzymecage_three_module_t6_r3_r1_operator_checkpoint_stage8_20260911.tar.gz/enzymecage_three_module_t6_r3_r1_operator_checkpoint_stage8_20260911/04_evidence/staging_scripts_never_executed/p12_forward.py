#!/usr/bin/env python3
"""T6-R3-R1 p12 — §7 real GPU forward: three pinned workers, base + repeat, in parallel.

This is the only stage of the task that touches CUDA, so everything it needs is taken from the
gates that already proved it instead of being measured twice:

* the three shared protein assets, the five seed checkpoints and the reaction overlay come from
  §6.2 FIXED_ASSET_IDENTITY (SHA-verified member by member there), so this launcher only reads
  that gate JSON and stats the paths; it never re-hashes a byte of them;
* the fixed sequences and per-UID identities come from §6.3's persisted evidence, and the three
  ``load_geometric_dataset`` calls that §9 requires to happen exactly once already happened
  there;
* the worker is the first round's pinned byte code plus the three §7-permitted additions only.
  The baseline stays read-only, its bytes/SHA are re-verified before any launch, and the
  derivation is proven purely additive.

If anything blocks here, the block is loud: every traceback and every already-successful worker
is kept, the chain stops, and §10 still has to produce the three files.
"""
import ast
import csv
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import r1_common as C  # noqa: E402

SECTION = "§7"
W, RD, LOGS, RA = C.WORK_ROOT, C.RETURN_DIR, C.LOGS, C.RUNTIME_ASSETS

P62 = RD / "FIXED_ASSET_IDENTITY_GATE.json"
P63 = RD / "UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json"
PREFLIGHT = RD / "PYTHON_RUNTIME_PREFLIGHT.json"      # the accepted §4 GPU table
P63_EVIDENCE = LOGS / "p11_native_evidence.json"
SEQ_SHA = RA / "p12_sequence_sha256.json"

BASELINE = W / "scripts" / "run_gpu_worker_pinned.py"
DERIVED = W / "scripts" / "run_gpu_worker_t6r3r1.py"
BASELINE_SHA = C.RUN_GPU_WORKER_SHA        # 79fb9ba2..., re-checked against the frozen constant
BASELINE_BYTES = C.RUN_GPU_WORKER_BYTES    # 13037
DERIVED_SHA = "d2c0730511c617982207069579e4943dbc0ccd8118cb1bab71d8d76a351626da"
DERIVED_BYTES = 19358
ADDENDUM_DIFF = LOGS / "p12_worker_addendum.diff"

WORKER_TIMEOUT_SEC = 1800            # §7: no worker may be killed below 1800 s
POLL_SEC = 5
TOLERANCE = C.REPEAT_TOLERANCE       # 1e-5, frozen by the prompt, never relaxed
MIN_RAM_GB = 240
ASSET_SHA = {"GVP": "8e1c5138aaf6fe45af2ca14b61631925cdbed661a052deff35155b01027ff96e",
             "ESM_NODE": "960e882fd116466785b7d648a085e78be1b5e00975cc3b8660ac566e724ea89e",
             "ESM_MEAN": "e44f70f4e2e5f9cc1269a8271397c5f51736ec4d7c0268f3a7f1427bc0201707"}
# These are the pieces of worker behaviour that must survive from the baseline untouched; an
# added line may only talk about the interpreter, the environment or an output path.
SCIENCE_TOKENS = ("EnzymeCAGERequest", "initialize_runtime", "runtime.predict", "predict(",
                  "per_seed_scores", "aggregate_seed_scores", "best_model.pth", "torch.load",
                  "load_state_dict", "evaluate(", "top_k", "enzyme_pool_uids", "return_ci",
                  "expected_seq_sha", "get_device_properties", "compute_evidence_hash",
                  "reaction_smiles=", "cuda.is_available")

FORWARD_JSONL = RD / "T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl"
MATRIX_CSV = RD / "LIGHTGBM_OVERLAY_MODULE_SOURCE_MATRIX.csv"   # the accepted §4 module sources
ISOLATION_CSV = RD / "GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv"
SCORES_CSV = RD / "FORWARD_PER_REACTION_UID_SEED_SCORES.csv"
GATE_JSON = RD / "T3B_BOUNDED_FORWARD_GATE.json"
STDOUT_TXT = RD / "GPU_FORWARD_GATE_STDOUT.txt"
WORKER_LOGS_TXT = LOGS / "p12_worker_logs.txt"
INTERP_LOG = LOGS / "p12_interpreters.jsonl"
RUN_ONCE = LOGS / "p12_run_once.json"
ATTEMPT_LOG = LOGS / "p12_attempts.jsonl"

problems, notes, say = [], [], []
results = {}
# The venv prefix of the pinned interpreter.  Do not resolve() PY here: the venv's bin/python is
# a symlink into the system interpreter, so resolving it would report /usr as the prefix and make
# every "inside the pinned environment" comparison vacuously true.
ENVP = str(Path(C.PY).parent.parent)
if not Path(ENVP).is_dir() or not Path(ENVP, "pyvenv.cfg").is_file():
    raise SystemExit("pinned environment prefix %r is not a virtualenv" % ENVP)
# The operator's rule is that the read-only LightGBM overlay may not change where ase, torch,
# PyG, numpy, scipy, RDKit, Pydantic or LangGraph come from.  "Unchanged" is therefore measured
# against the §4 record that this task already accepted, not against the venv directory: torch
# and numpy legitimately resolve to the host dist-packages that the pinned interpreter sits on
# top of, and LangGraph is a file-less namespace package.
with open(MATRIX_CSV, newline="", encoding="utf-8") as _fh:
    ACCEPTED_SOURCE = {r["module"]: r for r in csv.DictReader(_fh)}
PROVENANCE_GATE_MODULES = ("ase", "torch", "torch_geometric", "numpy", "scipy", "rdkit",
                           "pydantic", "langgraph")


def emit(text):
    say.append(text)
    print(text, flush=True)


def sha_of(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# --------------------------------------------------------------------------- 0. run-once discipline
invocation, relaunched = 1, True
if RUN_ONCE.exists():
    invocation = int(json.loads(RUN_ONCE.read_text(encoding="utf-8"))["invocation"]) + 1
RUN_ONCE.write_text(json.dumps({"invocation": invocation, "started_utc": C.now_utc(),
                                "section": "T6-R3-R1 §7 GPU forward"}, indent=2) + "\n",
                    encoding="utf-8")
with open(ATTEMPT_LOG, "a", encoding="utf-8") as fh:
    fh.write(json.dumps({"invocation": invocation, "utc": C.now_utc()}) + "\n")
prior = None
if GATE_JSON.exists():
    prior = json.loads(GATE_JSON.read_text(encoding="utf-8"))
if prior is not None and not prior.get("problems") and prior.get("forward_pair_count") == 6:
    relaunched = False
    emit("-- §7 was already satisfied by invocation %d (6/6 pairs, 0 problems); §9 forbids"
         " re-executing a completed forward, so this run adopts that evidence"
         % prior["invocation"])
else:
    if prior is not None:
        archive = LOGS / ("p12_attempt_%d" % (prior.get("invocation") or invocation - 1))
        archive.mkdir(parents=True, exist_ok=True)
        for name in (GATE_JSON.name, FORWARD_JSONL.name, ISOLATION_CSV.name, SCORES_CSV.name):
            if (RD / name).exists():
                shutil.copy2(str(RD / name), str(archive / name))
        workers_dir = RD / "workers"
        if workers_dir.exists():
            shutil.move(str(workers_dir), str(archive / "workers"))
        for extra in (STDOUT_TXT,):
            if extra.exists():
                shutil.copy2(str(extra), str(archive / extra.name))
        GATE_JSON.unlink()
        notes.append("invocation %d: previous attempt %s preserved under %s"
                     % (invocation, str(prior.get("invocation")), archive))
        emit("-- previous attempt archived to %s (nothing deleted)" % archive)

emit("=" * 78)
emit("T6-R3-R1 §7  THREE GPU WORKERS / REAL BASE+REPEAT FORWARD   invocation %d" % invocation)
emit("=" * 78)

# --------------------------------------------------------------------------- 1. upstream gates
g62 = json.loads(P62.read_text(encoding="utf-8"))
if g62.get("status") != "PASS" or g62.get("problems"):
    problems.append("upstream_6_2: FIXED_ASSET_IDENTITY status=%r problems=%s"
                    % (g62.get("status"), g62.get("problems")))
g63 = json.loads(P63.read_text(encoding="utf-8"))
if g63.get("problems") or g63.get("failed_checks") or g63.get("problem_count"):
    problems.append("upstream_6_3: gate carries problems=%s count=%s failed_checks=%s"
                    % (g63.get("problems"), g63.get("problem_count"), g63.get("failed_checks")))
for key, want in (("UID_SEQUENCE_GVP_POCKET_ESM", "PASS"), ("T3B_NATIVE_LOAD", "PASS_3_OF_3"),
                  ("status", "PASS")):
    if g63.get(key) != want:
        problems.append("upstream_6_3: %s=%r, expected %r" % (key, g63.get(key), want))
native_loads_63 = g63.get("native_loads") or []
ev63 = json.loads(P63_EVIDENCE.read_text(encoding="utf-8"))
if not ev63.get("per_row_tensor_evidence"):
    problems.append("upstream_6_3: no persisted per-row native load evidence at %s" % P63_EVIDENCE)
if len(native_loads_63) != 3:
    problems.append("upstream_6_3: the gate records %d native loads, three are required"
                    % len(native_loads_63))
run_once_63 = g63.get("run_once") or {}
if run_once_63.get("native_loads_expected_for_the_whole_task") != 3:
    problems.append("upstream_6_3: run_once records %r expected loads"
                    % run_once_63.get("native_loads_expected_for_the_whole_task"))
native_load_evidence = {"reaction_task_id": sorted(str(r.get("reaction_task_id"))
                                                   for r in native_loads_63),
                        "run_once": run_once_63,
                        "re_executed_in_p12": False}

assets_62 = {r["asset"]: r for r in g62["protein_assets"]}
asset_evidence = {}
for name, want in ASSET_SHA.items():
    row = assets_62.get(name) or {}
    path = Path(str(row.get("path", "")))
    regular = path.is_file() and not path.is_symlink()
    asset_evidence[name] = {"path": str(path), "bytes_6_2": row.get("bytes"),
                            "sha256_6_2": row.get("sha256"),
                            "expected_by_operator": want,
                            "matches_expected": row.get("sha256") == want,
                            "regular_file_on_disk_now": regular,
                            "re_hashed_in_p12": False,
                            "identity_established_in": "§6.2 FIXED_ASSET_IDENTITY_GATE.json"}
    if row.get("sha256") != want:
        problems.append("protein_asset: §6.2 records %s sha %r, operator pins %r"
                        % (name, row.get("sha256"), want))
    if not regular:
        problems.append("protein_asset: %s is not a regular file at %s right now" % (name, path))
    if str(path) != str(C.PROTEIN_ASSETS[name]):
        problems.append("protein_asset: %s path %s != the frozen path %s" % (name, path, C.PROTEIN_ASSETS[name]))
emit("-- §6.2 protein assets (stat only, never re-hashed): %s"
     % json.dumps({k: "%s@%d" % (v["sha256_6_2"][:12], v["bytes_6_2"])
                   for k, v in asset_evidence.items()}, ensure_ascii=False))

overlay_by_relpath = {r["relpath"]: r for r in g62["v1_checkpoints_and_overlay"]["overlay"]}
ckpt_expect = {}
for seed in C.SEEDS:
    rel = "3b_ensemble/seed_%d/best_model.pth" % seed
    rec = overlay_by_relpath.get(rel) or {}
    ckpt_expect[seed] = {"relpath": rel, "sha256": rec.get("sha256"), "bytes": rec.get("bytes"),
                         "pinned_sha": C.CHECKPOINT_SHA[seed], "pinned_bytes": C.CHECKPOINT_BYTES}
    if rec.get("sha256") != C.CHECKPOINT_SHA[seed] or rec.get("bytes") != C.CHECKPOINT_BYTES:
        problems.append("checkpoint: §6.2 overlay record for seed %d is %r/%r, expected %s/%d"
                        % (seed, rec.get("sha256"), rec.get("bytes"), C.CHECKPOINT_SHA[seed][:12],
                           C.CHECKPOINT_BYTES))
emit("-- five seed checkpoints taken from §6.2 (bytes/SHA per seed, no re-hash): %s"
     % json.dumps({str(s): "%s/%d" % (v["sha256"][:12], v["bytes"]) for s, v in ckpt_expect.items()}))

# --------------------------------------------------------------------------- 2. worker identity
baseline_identity = {}
if BASELINE.is_symlink() or not BASELINE.is_file():
    problems.append("baseline_worker: %s is not a regular non-symlink file" % BASELINE)
else:
    b_mode = BASELINE.stat().st_mode
    baseline_identity = {"path": str(BASELINE), "bytes": BASELINE.stat().st_size,
                         "sha256": sha_of(BASELINE), "mode": oct(b_mode & 0o777),
                         "writable": bool(b_mode & 0o222)}
    if BASELINE_BYTES != C.RUN_GPU_WORKER_BYTES or BASELINE_SHA != C.RUN_GPU_WORKER_SHA:
        problems.append("local constant drift: BASELINE %d/%s != frozen %d/%s"
                        % (BASELINE_BYTES, BASELINE_SHA[:12], C.RUN_GPU_WORKER_BYTES,
                           C.RUN_GPU_WORKER_SHA[:12]))
    if baseline_identity["bytes"] != C.RUN_GPU_WORKER_BYTES \
            or baseline_identity["sha256"] != C.RUN_GPU_WORKER_SHA:
        problems.append("baseline_worker: bytes=%d sha=%s != the immutable first-round worker"
                        " %d/%s. The original may not be overwritten while still being reported"
                        " as %s; §7 changes must live in a separate derived file."
                        % (baseline_identity["bytes"], baseline_identity["sha256"][:12],
                           C.RUN_GPU_WORKER_BYTES, C.RUN_GPU_WORKER_SHA[:12], C.RUN_GPU_WORKER_SHA[:12]))
    if baseline_identity["writable"]:
        problems.append("baseline_worker: mode %s is still writable; it must stay a read-only"
                        " baseline" % baseline_identity["mode"])
    emit("-- baseline worker %s: %d bytes sha=%s mode=%s read_only=%s"
         % (BASELINE.name, baseline_identity["bytes"], baseline_identity["sha256"][:12],
            baseline_identity["mode"], not baseline_identity["writable"]))

derived_identity, addendum = {}, {"baseline_lines": 0, "derived_lines": 0, "added": 0,
                                  "removed": 0, "replaced": 0, "science_lines_added": [],
                                  "diff": str(ADDENDUM_DIFF)}
if DERIVED.is_symlink() or not DERIVED.is_file():
    problems.append("derived_worker: missing or not regular at %s" % DERIVED)
else:
    derived_identity = {"path": str(DERIVED), "bytes": DERIVED.stat().st_size,
                        "sha256": sha_of(DERIVED)}
    text_d = DERIVED.read_text(encoding="utf-8")
    if derived_identity["sha256"] != DERIVED_SHA or derived_identity["bytes"] != DERIVED_BYTES:
        problems.append("derived_worker: %d/%s != the identity registered with this launcher %d/%s"
                        % (derived_identity["bytes"], derived_identity["sha256"][:12],
                           DERIVED_BYTES, DERIVED_SHA[:12]))
    try:
        ast.parse(text_d)
    except SyntaxError as exc:
        problems.append("derived_worker: does not parse: %s" % exc)
    b_lines = BASELINE.read_text(encoding="utf-8").splitlines()
    d_lines = text_d.splitlines()
    sm = difflib.SequenceMatcher(None, b_lines, d_lines, autojunk=False)
    science_lines_added = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "delete":
            addendum["removed"] += i2 - i1
        elif tag == "replace":
            addendum["replaced"] += i2 - i1
            addendum["added"] += j2 - j1
        elif tag == "insert":
            addendum["added"] += j2 - j1
        if tag != "equal":
            for line in d_lines[j1:j2]:
                if line.strip().startswith("#") or '"""' in line:
                    continue
                if any(tok in line for tok in SCIENCE_TOKENS):
                    science_lines_added.append(line.strip()[:140])
    addendum.update({"baseline_lines": len(b_lines), "derived_lines": len(d_lines),
                     "science_lines_added": science_lines_added})
    with open(ADDENDUM_DIFF, "w", encoding="utf-8") as fh:
        fh.writelines(difflib.unified_diff(b_lines, d_lines,
                                           fromfile="run_gpu_worker_pinned.py (immutable baseline)",
                                           tofile="run_gpu_worker_t6r3r1.py (derived)", lineterm=""))
    if addendum["removed"] or addendum["replaced"]:
        problems.append("worker_derivation: %d removed / %d replaced baseline lines; the"
                        " derivation must be purely additive"
                        % (addendum["removed"], addendum["replaced"]))
    if science_lines_added:
        problems.append("worker_derivation: added code lines touch request/predict/score/"
                        "checkpoint semantics: %s" % science_lines_added[:3])
    for kind, marker in (("sys.executable assertion", "equals_pinned_py"),
                         ("process argv[0] assertion", "process_argv0_equals_pinned_py"),
                         ("environment evidence", "R1_INTERP"),
                         ("module provenance evidence", "module_provenance"),
                         ("post-forward environment sample", "loaded_module_origin_after_forward"),
                         ("task output path", "worker_out_argument")):
        addendum.setdefault("markers", {})[kind] = marker in text_d
        if marker not in text_d:
            problems.append("worker_derivation: no %s marker (%s) in the derived worker"
                            % (kind, marker))
    emit("-- derived worker %s: %d bytes sha=%s"
         % (DERIVED.name, derived_identity["bytes"], derived_identity["sha256"][:12]))
    emit("-- addendum diff: %d baseline lines -> %d derived lines, +%d -%d ~%d;"
         " science-token code lines among additions: %d"
         % (addendum["baseline_lines"], addendum["derived_lines"], addendum["added"],
            addendum["removed"], addendum["replaced"], len(science_lines_added)))
    emit("-- diff archived at %s" % ADDENDUM_DIFF)

# --------------------------------------------------------------------------- 3. hardware, RAM
rc, out, err_txt = C.run(["nvidia-smi", "--query-gpu=index,name,uuid,memory.total,memory.used",
                          "--format=csv,noheader"], note="physical GPU topology for §7")
gpus = {}
for line in out.splitlines():
    parts = [p.strip() for p in line.split(",")]
    if len(parts) >= 5:
        gpus[parts[0]] = {"name": parts[1], "uuid": parts[2], "memory_total": parts[3],
                          "memory_used": parts[4]}
if len(gpus) != 4:
    problems.append("gpu_topology: %d physical GPUs discovered, the frozen map covers 0/1/2 of 4"
                    % len(gpus))
# The device name and memory size are not asserted from a literal here.  They are read back from
# the §4 preflight this task already accepted, so both a host hardware change and a stale
# expectation in this script surface as a problem instead of hiding behind a literal.
ACCEPTED_GPU = {}
for gkey, rec in sorted((json.loads(PREFLIGHT.read_text(encoding="utf-8"))
                         .get("gpu_uuid_frozen_vs_observed") or {}).items()):
    ACCEPTED_GPU[str(gkey).replace("GPU", "")] = {
        "frozen_uuid": rec.get("frozen_uuid"), "accepted_observed_uuid": rec.get("observed_uuid"),
        "name": rec.get("name"), "reaction": rec.get("reaction"), "match_in_4": rec.get("verdict")}
for row_ in json.loads(PREFLIGHT.read_text(encoding="utf-8")).get("gpu_table") or []:
    rec = ACCEPTED_GPU.get(str(row_.get("index")))
    if rec is not None:
        rec["memory_total_mib_4"] = str(row_.get("memory_total_mib"))
for index, (uuid, rid) in sorted(C.GPU_ASSIGNMENT.items()):
    got = gpus.get(str(index), {})
    accepted = ACCEPTED_GPU.get(str(index)) or {}
    if got.get("uuid") != uuid:
        problems.append("gpu_uuid[%d]: %r != frozen %r (R%s)" % (index, got.get("uuid"), uuid, rid))
    if accepted.get("frozen_uuid") != uuid or accepted.get("accepted_observed_uuid") != uuid:
        problems.append("gpu_map[%d]: the §4 record %r disagrees with the frozen map %s (R%s)"
                        % (index, accepted, uuid, rid))
    if accepted.get("reaction") != rid:
        problems.append("gpu_reaction[%d]: §4 recorded R%r for this card, the frozen map says R%s"
                        % (index, accepted.get("reaction"), rid))
    if not accepted.get("name") or got.get("name") != accepted.get("name"):
        problems.append("gpu_name[%d]: observed %r != the §4-accepted %r"
                        % (index, got.get("name"), accepted.get("name")))
rc, freeram, _rf_err = C.run(["free", "-g"], env=C.base_env(),
                             note="host RAM headroom for three workers")
avail_gb = None
for line in freeram.splitlines():
    if line.startswith("Mem:"):
        cols = line.split()
        if len(cols) >= 7:
            avail_gb = int(cols[6])
if avail_gb is None or avail_gb < MIN_RAM_GB:
    problems.append("ram: %r GiB available; three concurrent workers each load five 69 MiB"
                    " checkpoints plus the 932 MiB ESM mean index" % avail_gb)
emit("-- GPUs: %s" % json.dumps({k: "%s %s total=%s used=%s" % (
        v["uuid"][:18] + "...", v["name"].replace("NVIDIA GeForce ", ""),
        v["memory_total"], v["memory_used"])
     for k, v in sorted(gpus.items())}, ensure_ascii=False))
emit("-- §4-accepted card identity: %s"
     % json.dumps({("GPU" + k): "%s | %s | R%s | %s"
                   % (v.get("name"), v.get("frozen_uuid", "")[:18] + "...",
                      v.get("reaction"), v.get("memory_total_mib_4"))
                   for k, v in sorted(ACCEPTED_GPU.items())}, ensure_ascii=False))
emit("-- GPU3 is deliberately unused by this task; RAM available %s GiB" % avail_gb)

# --------------------------------------------------------------------------- 4. sequence pins
seq_id = ev63["sequence_identity_per_uid"]
seq_sha, seq_gate_summary_6_3 = {}, {}
for uid in C.THREE_UIDS:
    row = seq_id.get(uid) or {}
    digest = row.get("sequence_sha256_utf8")
    if not digest:
        problems.append("sequence_pin: §6.3 recorded no sequence SHA for %s" % uid)
        continue
    if uid not in C.FORMAL_UIDS and not row.get("matches_d4_frozen_sha"):
        notes.append("SR40 SHA provenance stays %s (asset identity only, never forwarded)"
                     % row.get("frozen_sha_provenance"))
    seq_sha[uid] = digest
    seq_gate_summary_6_3[uid] = {"sequence_length": row.get("sequence_length"),
                                 "sequence_sha256": digest,
                                 "in_gvp_and_pocket_and_esm_mean_6_3":
                                     bool(row.get("production_index_sequence_agrees_with_direct_read"))}
if sorted(seq_sha) != sorted(C.THREE_UIDS):
    problems.append("sequence_pin: expected all three frozen UIDs, got %s" % sorted(seq_sha))
if sorted(k for k in seq_sha if k in C.FORMAL_UIDS) != sorted(C.FORMAL_UIDS):
    problems.append("sequence_pin: a forwarded UID has no SHA")
SEQ_SHA.write_text(json.dumps(seq_sha, indent=2, sort_keys=True) + "\n", encoding="utf-8")
emit("-- sequence SHAs for the worker's own hard gate (from §6.3, %s): %s"
     % (", ".join("%s=%s" % (u, seq_sha[u][:12]) for u in C.THREE_UIDS if u in seq_sha),
        str(SEQ_SHA)))

# ------------------------------------------------------------------- 4b. sys.path entries + probe
# Invocation 2 handed the workers the *package* directory where the worker expects a sys.path
# entry, so all three died on "No module named 'enzymecage_wrapper'" five seconds in - before any
# CUDA context.  The worker's own code is the authority: it does
# ``sys.path.insert(0, args.d4_wrapper_dir)`` and then imports the package by name, so the
# argument must be the directory that CONTAINS enzymecage_wrapper/, i.e. exactly the entry §6.3
# used (C.D4_WRAPPER_PARENT).  No teacher file, wrapper file, asset, model or checkpoint was
# touched by this correction; only the path the launcher exports.
D4_IMPORT_ROOT = C.D4_WRAPPER_PARENT
PACKAGE_MEMBERS = {}
for pkg_root, pkg, members in ((D4_IMPORT_ROOT, "enzymecage_wrapper",
                                ("__init__.py", "predictor.py", "schema.py", "asset_index.py",
                                 "utils.py")),
                               (Path(C.CODE_ROOT), "enzymecage", ("__init__.py",))):
    for m in members:
        pth = Path(pkg_root) / pkg / m
        PACKAGE_MEMBERS["%s/%s" % (pkg, m)] = {"path": str(pth), "present": pth.is_file(),
                                               "bytes": pth.stat().st_size if pth.is_file() else None}
        if not pth.is_file():
            problems.append("import_root: %s is absent from %s" % (pkg + "/" + m, pkg_root))

# The probe reproduces the worker's own path set-up and then imports precisely what the worker
# imports before it calls initialize_runtime, plus every module initialize_runtime itself
# importlibs (predictor.py lines 29/49/68/69/109).  It never builds a runtime and never touches
# an asset index, so the "exactly once" counters of §7 and §9 are untouched; it is the cheap way
# to discover a broken launch contract before it costs three model initialisations.
PROBE_SRC = '''
import importlib, importlib.util, json, os, sys
out = {"sys_executable": sys.executable, "sys_prefix": sys.prefix,
       "python_version": "%d.%d.%d" % sys.version_info[:3],
       "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
       "cwd": os.getcwd(), "sys_path_head": list(sys.path)[:3]}
code_root, d4_root = sys.argv[1], sys.argv[2]
sys.path.insert(0, code_root)
sys.path.insert(0, d4_root)
out["sys_path_after_inserts"] = list(sys.path)[:3]
try:
    from enzymecage_wrapper import predictor as wp
    from enzymecage_wrapper.schema import EnzymeCAGERequest
    import enzymecage_wrapper as wpkg
    out["enzymecage_wrapper"] = wpkg.__file__
    out["wrapper_predictor"] = wp.__file__
    out["has_initialize_runtime"] = callable(getattr(wp, "initialize_runtime", None))
    out["has_predict"] = callable(getattr(wp, "predict", None))
    out["request_class_module"] = EnzymeCAGERequest.__module__
    out["runtime_still_unset"] = getattr(wp, "_RUNTIME", "ABSENT") is None
except Exception as exc:
    out["wrapper_import_error"] = "%s: %s" % (type(exc).__name__, exc)
imports = {}
for name in ("yaml", "enzymecage", "enzymecage.model", "enzymecage.dataset.geometric",
             "torch_geometric.data", "torch_geometric.loader"):
    try:
        mod = importlib.import_module(name)
        imports[name] = getattr(mod, "__file__", None) or list(getattr(mod, "__path__", []))
    except Exception as exc:
        imports[name] = "ERROR %s: %s" % (type(exc).__name__, exc)
out["imports"] = imports
specs = {}
for name in ("ase", "torch", "torch_geometric", "numpy", "scipy", "rdkit", "pydantic",
             "langgraph", "lightgbm"):
    try:
        spec = importlib.util.find_spec(name)
    except Exception as exc:
        specs[name] = {"error": "%s: %s" % (type(exc).__name__, exc)}
        continue
    specs[name] = (None if spec is None else
                   {"origin": spec.origin,
                    "location": (list(spec.submodule_search_locations)[:1]
                                 if spec.submodule_search_locations else None)})
out["spec_origin"] = specs
import torch
out["torch"] = torch.__file__
out["torch_version"] = torch.__version__
out["cuda_built"] = torch.version.cuda
out["cuda_initialized"] = torch.cuda.is_initialized()
print("@@P12PROBE@@" + json.dumps(out, ensure_ascii=False), flush=True)
'''
probe_env = C.base_env({"CUDA_VISIBLE_DEVICES": "", "R1_PINNED_PY": C.PY})
probe_env.pop("PYTHONPATH", None)
probe_env.pop("PYTHONHOME", None)
probe_rc, probe_out, probe_err = C.run(
    [C.PY, "-B", "-c", PROBE_SRC, C.CODE_ROOT, str(D4_IMPORT_ROOT)], cwd=C.CODE_ROOT,
    env=probe_env, note="§7 pre-launch contract probe: import the frozen wrapper and the modules"
    " initialize_runtime needs, on the same interpreter and sys.path the workers get, without"
    " building a runtime and without touching CUDA")
probe = {}
for line in probe_out.splitlines():
    if line.startswith("@@P12PROBE@@"):
        probe = json.loads(line[len("@@P12PROBE@@"):])
probe_record = {"argv": [C.PY, "-B", "-c", "<%d byte probe>" % len(PROBE_SRC), C.CODE_ROOT,
                         str(D4_IMPORT_ROOT)], "cwd": C.CODE_ROOT,
                "env_cuda_visible_devices": "", "env_pythonpath": probe_env.get("PYTHONPATH"),
                "exit_code": probe_rc, "stdout": probe_out.strip(), "stderr": probe_err.strip(),
                "parsed": probe,
                "meaning": "import contract only: no initialize_runtime call, no asset index build,"
                " no CUDA context, therefore no §7/§9 once-counter consumed"}
emit("-- wrapper import probe: exit=%d %s" % (
    probe_rc, json.dumps({k: probe.get(k) for k in ("enzymecage_wrapper", "wrapper_import_error",
                                                    "cuda_initialized", "runtime_still_unset")},
                         ensure_ascii=False)[:300]))
if probe_rc != 0 or not probe:
    problems.append("wrapper_import_probe: the pinned interpreter cannot reproduce the worker's"
                    " import contract (exit=%d, stderr=%s)" % (probe_rc, probe_err[-400:]))
elif probe.get("wrapper_import_error"):
    problems.append("wrapper_import_probe: %s" % probe["wrapper_import_error"])
else:
    if probe.get("sys_executable") != C.PY or probe.get("sys_prefix") != ENVP:
        problems.append("wrapper_import_probe: runs on %r/%r, expected %r inside %s"
                        % (probe.get("sys_executable"), probe.get("sys_prefix"), C.PY, ENVP))
    if not str(probe.get("enzymecage_wrapper", "")).startswith(str(D4_IMPORT_ROOT)):
        problems.append("wrapper_import_probe: enzymecage_wrapper resolved to %r, outside the"
                        " frozen D4 package %s" % (probe.get("enzymecage_wrapper"),
                                                   D4_IMPORT_ROOT))
    for flag in ("has_initialize_runtime", "has_predict", "runtime_still_unset"):
        if probe.get(flag) is not True:
            problems.append("wrapper_import_probe: %s=%r" % (flag, probe.get(flag)))
    for name, val in sorted((probe.get("imports") or {}).items()):
        if isinstance(val, str) and val.startswith("ERROR"):
            problems.append("wrapper_import_probe: initialize_runtime needs %s, which fails to"
                            " import (%s)" % (name, val[:200]))
    if not str((probe.get("imports") or {}).get("enzymecage") or "").startswith(C.CODE_ROOT):
        problems.append("wrapper_import_probe: the teacher package resolves outside the frozen"
                        " %s copy (%r)" % (C.CODE_ROOT, (probe.get("imports") or {}).get(
                            "enzymecage")))
    for mod, rec in sorted(ACCEPTED_SOURCE.items()):
        if mod == "lightgbm" or mod not in PROVENANCE_GATE_MODULES:
            continue
        entry = (probe.get("spec_origin") or {}).get(mod) or {}
        origin = entry.get("origin") or ""
        if rec.get("changed") != "False":
            problems.append("wrapper_import_probe: the accepted §4 record for %s is not UNCHANGED"
                            % mod)
        if rec["before_file"] and origin != rec["before_file"]:
            problems.append("wrapper_import_probe: %s resolves to %r, the accepted §4 source is %r"
                            % (mod, origin, rec["before_file"]))
    if (probe.get("spec_origin") or {}).get("lightgbm"):
        problems.append("wrapper_import_probe: lightgbm is importable on the worker path (%s); the"
                        " forward needs none of it" % json.dumps(
                            probe["spec_origin"]["lightgbm"]))
    if probe.get("cuda_initialized"):
        problems.append("wrapper_import_probe: a CUDA context already exists before the workers"
                        " were started")

# --------------------------------------------------------------------------- 5. launch plan
workers_dir = RD / "workers"
plan = []
for index in sorted(C.GPU_ASSIGNMENT):
    uuid, rid = C.GPU_ASSIGNMENT[index]
    task_id, rxn = C.REACTIONS[index]
    requests = [{"request_label": rid, "reaction_task_id": task_id, "reaction_smiles": rxn}]
    req_json = json.dumps(requests, ensure_ascii=False)
    out_dir = workers_dir / ("worker_%d" % index)
    argv = [C.PY, str(DERIVED),
            "--worker-id", str(index),
            "--gpu-index", str(index),
            "--gpu-uuid", uuid,
            "--requests", req_json,
            "--v1-overlay", str(C.V1_OVERLAY),
            "--d4-wrapper-dir", str(D4_IMPORT_ROOT),
            "--code-root", C.CODE_ROOT,
            "--worker-out", str(out_dir),
            "--seq-sha-json", str(SEQ_SHA)]
    env = C.base_env({"CUDA_VISIBLE_DEVICES": str(index), "R1_PINNED_PY": C.PY})
    env.pop("PYTHONPATH", None)
    env.pop("PYTHONHOME", None)
    plan.append({"worker_index": index, "worker_id": index, "request_label": rid,
                 "reaction_task_id": task_id, "reaction_smiles": rxn, "gpu": index,
                 "gpu_uuid": uuid, "argv": argv, "env": env, "cwd": C.CODE_ROOT,
                 "out_dir": str(out_dir), "requests": requests,
                 "env_provenance": {"PATH": env.get("PATH"), "CUDA_VISIBLE_DEVICES":
                                    env["CUDA_VISIBLE_DEVICES"],
                                    "TMPDIR": env.get("TMPDIR"),
                                    "TORCH_HOME": env.get("TORCH_HOME")}})

# --------------------------------------------------------------------------- 6. parallel launch
# The preflight is a hard gate: a broken preflight may never reach CUDA, because that is how a
# cheap mistake turns into three expensive half-finished model initialisations.
launch = {"relaunched": relaunched, "launch_utc": None, "all_done_utc": None,
          "wall_sec": None, "timed_out": [], "refused": False}
if relaunched and problems:
    launch["refused"] = True
    emit("-- pre-launch gates failed with %d problem(s); the three workers are NOT started"
         % len(problems))
    for p in problems[:10]:
        emit("   - " + p[:280])
    emit("-- status: BLOCKED_AT_T3B_FORWARD_PREFLIGHT (no CUDA context was created)")
elif relaunched:
    handles = []
    launch["launch_utc"] = C.now_utc()
    t0 = time.monotonic()
    launch["launch_mono"] = t0
    for item in plan:
        out_dir = Path(item["out_dir"])
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "reactions.json").write_text(
            json.dumps(item["requests"], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        stdout_h = open(out_dir / "stdout.log", "wb")
        stderr_h = open(out_dir / "stderr.log", "wb")
        proc = subprocess.Popen(item["argv"], cwd=item["cwd"], env=item["env"],
                                stdin=subprocess.DEVNULL, stdout=stdout_h, stderr=stderr_h,
                                start_new_session=True)
        handles.append({"item": item, "proc": proc, "out": stdout_h, "err": stderr_h,
                        "start_mono": time.monotonic(), "start_utc": C.now_utc()})
        emit("-- launched worker_%d on GPU%d (uuid %s) pid=%d, per-worker limit %d s"
             % (item["worker_index"], item["gpu"], item["gpu_uuid"][:18] + "...", proc.pid,
                WORKER_TIMEOUT_SEC))
    deadline = t0 + WORKER_TIMEOUT_SEC
    while True:
        alive = [h for h in handles if h["proc"].poll() is None]
        if not alive:
            break
        if time.monotonic() > deadline:
            launch["timed_out"] = [h["item"]["worker_index"] for h in alive]
            for h in alive:
                try:
                    os.killpg(os.getpgid(h["proc"].pid), 15)
                except OSError:
                    h["proc"].terminate()
            time.sleep(15)
            for h in alive:
                if h["proc"].poll() is None:
                    try:
                        os.killpg(os.getpgid(h["proc"].pid), 9)
                    except OSError:
                        h["proc"].kill()
            emit("-- deadline %d s reached; SIGTERM/SIGKILL sent to workers %s"
                 % (WORKER_TIMEOUT_SEC, launch["timed_out"]))
            break
        time.sleep(POLL_SEC)
    for h in handles:
        h["out"].close()
        h["err"].close()
        h["end_utc"] = C.now_utc()
        h["end_mono"] = time.monotonic()
    launch["all_done_utc"] = C.now_utc()
    launch["wall_sec"] = round(time.monotonic() - t0, 3)
    emit("-- all three workers returned at %s (wall %.1f s)"
         % (launch["all_done_utc"], launch["wall_sec"]))
    handles_by_index = {h["item"]["worker_index"]: h for h in handles}
else:
    handles_by_index, handles = {}, []


# --------------------------------------------------------------------------- 7. harvest
def note_interp(worker_index, payload_obj):
    with open(INTERP_LOG, "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"utc": C.now_utc(), "worker_index": worker_index,
                             "identity": payload_obj}, ensure_ascii=False) + "\n")


ISOLATION_FIELDS = [
    "worker_index", "worker_id", "physical_gpu_index", "declared_gpu_uuid", "request_label",
    "reaction_task_id", "reaction_smiles", "argv0", "sys_executable", "sys_executable_realpath",
    "python_version", "prefix_equals_pinned_env", "worker_pid", "exit_code", "worker_status",
    "started_utc", "ended_utc", "wall_sec", "timeout_limit_sec", "runtime_init_sec",
    "runtime_initialized_events", "runtime_model_object_count", "runtime_package_root",
    "runtime_device", "torch_visible_device_count", "physical_gpu_count_on_host",
    "actual_device_name", "actual_device_uuid", "uuid_matches_frozen", "cuda_visible_devices_env",
    "device_memory_free_mib", "device_memory_total_mib", "peak_cuda_mem_allocated_mib",
    "sequence_gate_pass", "sequence_esm_gate", "esm_mean_nonzero", "checkpoint_identity_vs_6_2",
    "forward_requests", "forward_executed", "forward_call_count_after_repeat", "ranked_uids",
    "max_abs_base_repeat_delta", "requests_ok", "stdout_log", "stderr_log", "stdout_sha256",
    "ase_origin_after_forward", "enzymecage_origin_after_runtime_init",
    "stderr_sha256"] + ["module_source_vs_4_%s" % m for m in PROVENANCE_GATE_MODULES] + ["status"]
isol_rows, score_rows, jsonl_rows, windows, stdout_chunks = [], [], [], [], []
forward_pairs = set()
interp_of = {}

if relaunched and not launch["refused"]:
    for item in sorted(plan, key=lambda p: p["worker_index"]):
        wid = item["worker_index"]
        h = handles_by_index[wid]
        out_dir = Path(item["out_dir"])
        res_path = out_dir / "worker_result.json"
        stdout_path, stderr_path = out_dir / "stdout.log", out_dir / "stderr.log"
        stdout = stdout_path.read_text(encoding="utf-8", errors="replace") if stdout_path.exists() else ""
        stderr = stderr_path.read_text(encoding="utf-8", errors="replace") if stderr_path.exists() else ""
        stdout_chunks.append("===== worker_%d (GPU%d, %s) stdout.log =====\n%s" % (
            wid, item["gpu"], item["request_label"], stdout))
        stdout_chunks.append("===== worker_%d (GPU%d, %s) stderr.log =====\n%s" % (
            wid, item["gpu"], item["request_label"], stderr))
        interp = None
        for line in stdout.splitlines():
            if line.startswith("R1_INTERP "):
                interp = json.loads(line[len("R1_INTERP "):])
                note_interp(wid, interp)
        interp_of[wid] = interp
        payload = {}
        if res_path.exists():
            try:
                payload = json.loads(res_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                problems.append("worker_%d: worker_result.json unreadable: %s" % (wid, exc))
        else:
            problems.append("worker_%d: wrote no worker_result.json at %s" % (wid, res_path))
        seq_check = {}
        sc_path = out_dir / "SEQUENCE_ESM_IDENTITY_CHECK.json"
        if sc_path.exists():
            seq_check = json.loads(sc_path.read_text(encoding="utf-8"))
        else:
            problems.append("worker_%d: the worker's own SEQUENCE_ESM_IDENTITY_CHECK.json is absent" % wid)
        traces = {}
        for kind in ("base", "repeat"):
            tp = out_dir / ("%s_%s.json" % (item["request_label"], kind))
            if tp.exists():
                traces[kind] = json.loads(tp.read_text(encoding="utf-8"))
            else:
                problems.append("worker_%d: missing per-request file %s" % (wid, tp.name))
        C.log_command("python", item["argv"], cwd=item["cwd"], exit_code=h["proc"].returncode,
                      note="%s worker_%d GPU%d %s real base+repeat forward, wall %.1f s, "
                           "per-worker limit %d s"
                           % (SECTION, wid, item["gpu"], item["request_label"],
                              h["end_mono"] - h["start_mono"], WORKER_TIMEOUT_SEC),
                      stdout_sha=sha_of(stdout_path) if stdout_path.exists() else "",
                      stderr_sha=sha_of(stderr_path) if stderr_path.exists() else "",
                      utc=h["start_utc"], duration=round(h["end_mono"] - h["start_mono"], 3),
                      child=interp)
        results[wid] = {"item": item, "exit": h["proc"].returncode, "payload": payload,
                        "seq_check": seq_check, "traces": traces, "interp": interp,
                        "start_utc": h["start_utc"], "end_utc": h["end_utc"],
                        "wall_sec": round(h["end_mono"] - h["start_mono"], 3),
                        "stdout": str(stdout_path), "stderr": str(stderr_path),
                        "stdout_sha": sha_of(stdout_path) if stdout_path.exists() else "",
                        "stderr_sha": sha_of(stderr_path) if stderr_path.exists() else "",
                        "timed_out": wid in launch["timed_out"]}
    WORKER_LOGS_TXT.write_text("\n".join(stdout_chunks) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------- 8. per-worker gates
def gate_worker(wid, res):
    """Return one isolation/assignment row, appending every problem found to ``problems``."""
    item, payload, interp = res["item"], res["payload"], res["interp"]
    def bad(msg):
        problems.append("worker_%d(GPU%d): %s" % (wid, item["gpu"], msg))

    events = payload.get("events") or []
    prov = payload.get("module_provenance") or {}
    loaded = payload.get("loaded_module_origin_after_runtime_init") or {}
    loaded_after = payload.get("loaded_module_origin_after_forward") or {}
    row = {
        "worker_index": wid, "worker_id": payload.get("worker_id"), "physical_gpu_index": item["gpu"],
        "declared_gpu_uuid": item["gpu_uuid"], "request_label": item["request_label"],
        "reaction_task_id": item["reaction_task_id"], "reaction_smiles": item["reaction_smiles"],
        "argv0": (interp or {}).get("process_argv0"),
        "sys_executable": (interp or {}).get("sys_executable"),
        "sys_executable_realpath": (interp or {}).get("sys_executable_realpath"),
        "python_version": (interp or {}).get("python_version"),
        "prefix_equals_pinned_env": (interp or {}).get("prefix") == ENVP,
        "worker_pid": payload.get("pid"), "exit_code": res["exit"], "worker_status": payload.get("status"),
        "started_utc": res["start_utc"], "ended_utc": payload.get("ended_utc") or res["end_utc"],
        "wall_sec": res["wall_sec"], "timeout_limit_sec": WORKER_TIMEOUT_SEC,
        "runtime_init_sec": payload.get("runtime_init_sec"),
        "runtime_initialized_events": sum(1 for e in events if e.get("step") == "runtime_initialized"),
        "runtime_model_object_count": payload.get("runtime_model_object_count"),
        "runtime_package_root": payload.get("runtime_package_root"),
        "runtime_device": payload.get("runtime_device"),
        "torch_visible_device_count": payload.get("torch_visible_device_count"),
        "physical_gpu_count_on_host": payload.get("physical_gpu_count_on_host"),
        "actual_device_name": payload.get("actual_device_name"),
        "actual_device_uuid": payload.get("actual_device_uuid"),
        "uuid_matches_frozen": payload.get("actual_device_uuid") == item["gpu_uuid"],
        "cuda_visible_devices_env": payload.get("cuda_visible_devices_env"),
        "device_memory_free_mib": payload.get("device_memory_free_mib"),
        "device_memory_total_mib": payload.get("device_memory_total_mib"),
        "peak_cuda_mem_allocated_mib": payload.get("peak_cuda_mem_allocated_mib"),
        "ase_origin_after_forward": loaded_after.get("ase"),
        "enzymecage_origin_after_runtime_init": loaded.get("enzymecage"),
        "sequence_gate_pass": payload.get("sequence_gate_pass"),
        "sequence_esm_gate": [], "esm_mean_nonzero": [], "checkpoint_identity_vs_6_2": [],
        "forward_requests": [], "forward_executed": [], "forward_call_count_after_repeat": None,
        "ranked_uids": [], "max_abs_base_repeat_delta": None, "requests_ok": [],
        "stdout_log": res["stdout"], "stderr_log": res["stderr"],
        "stdout_sha256": res["stdout_sha"], "stderr_sha256": res["stderr_sha"], "status": "FAIL"}
    for mod in PROVENANCE_GATE_MODULES:
        row.setdefault("module_source_vs_4_%s" % mod, "")

    if res["timed_out"]:
        bad("killed by the %d s limit before it finished" % WORKER_TIMEOUT_SEC)
    if res["exit"] != 0:
        bad("exit=%d status=%r error=%s:%s" % (res["exit"], payload.get("status"),
                                               payload.get("error_type"),
                                               str(payload.get("error_msg"))[:300]))
    # (a) interpreter: the exec'd argv[0] and the in-process sys.executable must both be ${PY}.
    # sys.argv[0] is the script path, so the kernel's /proc/self/cmdline record is what proves
    # argv[0]; both are read inside the worker itself.
    if interp is None:
        bad("no R1_INTERP marker, so the in-process interpreter is unproven")
    else:
        if interp.get("sys_executable") != C.PY or interp.get("process_argv0") != C.PY:
            bad("process argv0=%r / sys.executable=%r != pinned %r (sys.argv0=%r)"
                % (interp.get("process_argv0"), interp.get("sys_executable"), C.PY,
                   interp.get("sys_argv0")))
        if not interp.get("equals_pinned_py") or not interp.get("venv_prefix_ok") \
                or not interp.get("process_argv0_equals_pinned_py"):
            bad("self-reported interpreter gate %s" % json.dumps(interp)[:240])
        if interp.get("python_version") != "3.12.3":
            bad("worker reports python %r" % interp.get("python_version"))
        if item["argv"][0] != interp.get("process_argv0"):
            bad("planned argv[0] %r != the worker's own /proc/self/cmdline argv[0] %r"
                % (item["argv"][0], interp.get("process_argv0")))
        if prov.get("_t2b_overlay_on_path"):
            bad("the read-only LightGBM overlay is on this worker's sys.path; ase/torch/PyG/"
                "numpy/scipy/RDKit/Pydantic must keep their pinned-environment origin")
        for mod in PROVENANCE_GATE_MODULES:
            entry = prov.get(mod) or {}
            record = ACCEPTED_SOURCE.get(mod)
            origin = entry.get("origin") or ""
            if record is None:
                bad("the accepted §4 module-source matrix has no row for %s" % mod)
                continue
            if record.get("changed") != "False":
                bad("the accepted §4 record for %s is not UNCHANGED (%r)" % (mod, record))
            if record["before_file"]:
                if origin != record["before_file"]:
                    bad("module %s resolves to %r inside the worker, the accepted §4 source is"
                        " %r (version %s)" % (mod, origin, record["before_file"],
                                              record["version_before"]))
            else:
                location = str((entry.get("search_location") or [""])[0])
                if entry.get("importable") is not True or origin or not location:
                    bad("module %s is a file-less package in the accepted §4 record, the worker"
                        " sees %s" % (mod, json.dumps(entry)))
                if C.T2B_SITES and C.T2B_SITES in location:
                    bad("module %s resolves through the LightGBM overlay: %r" % (mod, location))
            row["module_source_vs_4_%s" % mod] = origin or str(
                (entry.get("search_location") or [""])[0])
        if (prov.get("lightgbm") or {}).get("importable"):
            bad("lightgbm resolves inside this worker (%s); the forward needs no LightGBM, so"
                " that can only mean the read-only overlay leaked into the process"
                % json.dumps(prov.get("lightgbm")))
        loaded_after = payload.get("loaded_module_origin_after_forward") or {}
        ase_sample = loaded_after or payload.get("loaded_module_origin_after_runtime_init") or {}
        ase_sample_stage = ("after the forwards" if loaded_after
                            else "after runtime initialisation")
        if not str(ase_sample.get("ase") or "").startswith(ENVP):
            bad("ase was never imported from the pinned environment %s (got %r); the T6-R3 round"
                " died on exactly this module being absent from the interpreter it ran on"
                % (ase_sample_stage, ase_sample.get("ase")))
        enzymecage_origin = (payload.get("loaded_module_origin_after_runtime_init") or {}).get(
            "enzymecage")
        if not str(enzymecage_origin or "").startswith(C.CODE_ROOT):
            bad("the teacher package resolved to %r instead of the frozen %s copy"
                % (enzymecage_origin, C.CODE_ROOT))
    # (b) CUDA isolation as observed inside the worker
    if payload.get("status") != "OK":
        bad("worker status=%r (expected OK)%s" % (payload.get("status"),
            "; traceback kept at " + res["stderr"] if res["stderr_sha"] else ""))
    if payload.get("torch_visible_device_count") != 1:
        bad("torch sees %r CUDA devices, exactly 1 is required"
            % payload.get("torch_visible_device_count"))
    if payload.get("physical_gpu_count_on_host") != 4:
        bad("worker sees %r physical GPUs on the host" % payload.get("physical_gpu_count_on_host"))
    if not row["uuid_matches_frozen"]:
        bad("device UUID %r != frozen %r for GPU%d"
            % (payload.get("actual_device_uuid"), item["gpu_uuid"], item["gpu"]))
    if payload.get("cuda_visible_devices_env") != str(item["gpu"]):
        bad("CUDA_VISIBLE_DEVICES=%r" % payload.get("cuda_visible_devices_env"))
    if row["actual_device_name"] != (ACCEPTED_GPU.get(str(item["gpu"])) or {}).get("name"):
        bad("device name %r != the §4-accepted %r"
            % (row["actual_device_name"],
               (ACCEPTED_GPU.get(str(item["gpu"])) or {}).get("name")))
    accepted_total = int(str((ACCEPTED_GPU.get(str(item["gpu"])) or {})
                             .get("memory_total_mib_4", "0")).split()[0] or 0)
    if not accepted_total:
        bad("the §4 record carries no memory size for GPU%d" % item["gpu"])
    elif not row["device_memory_total_mib"] \
            or row["device_memory_total_mib"] < int(accepted_total * 0.95) \
            or row["device_memory_total_mib"] > accepted_total + 1024:
        bad("device memory total %r MiB is not the §4-accepted %d MiB"
            % (row["device_memory_total_mib"], accepted_total))
    # (c) one runtime, five seeds, frozen checkpoint identity, no extra hash pass
    if row["runtime_initialized_events"] != 1:
        bad("initialize_runtime produced %r events; exactly one per worker is required"
            % row["runtime_initialized_events"])
    if row["runtime_model_object_count"] != 5:
        bad("runtime holds %r models" % row["runtime_model_object_count"])
    if not row["runtime_init_sec"] or not 0.0 < row["runtime_init_sec"] < 900.0:
        bad("runtime_init_sec=%r" % row["runtime_init_sec"])
    if str(row["runtime_package_root"] or "") != str(C.V1_OVERLAY):
        bad("runtime_package_root=%r != the §6.2 overlay %s"
            % (row["runtime_package_root"], C.V1_OVERLAY))
    if str(row["runtime_device"] or "") != "cuda:0":
        bad("runtime_device=%r" % row["runtime_device"])
    observed = payload.get("observed_checkpoint_sha256") or {}
    for seed in C.SEEDS:
        digest = observed.get(str(seed), observed.get(seed))
        expect = ckpt_expect[seed]
        ok = digest == expect["sha256"] == expect["pinned_sha"] \
            and expect["bytes"] == expect["pinned_bytes"]
        row["checkpoint_identity_vs_6_2"].append("seed%d:%s" % (seed, "ok" if ok else "MISMATCH"))
        if not ok:
            bad("seed %d: worker observed %r, §6.2/pinned %s (%d bytes)"
                % (seed, digest, expect["pinned_sha"][:12], expect["pinned_bytes"]))
    if len(observed) != 5:
        bad("%r checkpoint hashes recorded" % len(observed))
    # (d) the worker's own sequence/ESM hard gate, against the §6.3 pins
    if payload.get("sequence_gate_pass") is not True:
        bad("the worker's own sequence/ESM gate did not pass: %s"
            % json.dumps((res["seq_check"] or {}).get("issues"))[:400])
    for uid, entry in sorted((res["seq_check"] or {}).get("uids", {}).items()):
        row["sequence_esm_gate"].append("%s:%s" % (uid, "ok" if entry.get("ok") else "FAIL"))
        row["esm_mean_nonzero"].append(bool(entry.get("esm_mean_nonzero")))
        if entry.get("ok") is not True:
            bad("UID %s failed the worker's identity entry: %s" % (uid, json.dumps(entry)[:300]))
        if entry.get("sequence_sha256") != seq_sha.get(uid):
            bad("UID %s live sequence sha %r != §6.3 frozen %r"
                % (uid, entry.get("sequence_sha256"), seq_sha.get(uid)))
        if uid in C.FORMAL_UIDS and not (entry.get("uid_in_gvp") and entry.get("uid_in_pocket_node")
                                         and entry.get("sequence_in_esm_mean")):
            bad("forwarded UID %s is not present in all three asset tables: %s" % (uid, entry))
    if sorted((res["seq_check"] or {}).get("uids", {})) != sorted(C.THREE_UIDS):
        bad("identity check covers %r, expected the three frozen UIDs"
            % sorted((res["seq_check"] or {}).get("uids", {})))
    # (e) the two real forwards (base + repeat) of the one assigned reaction
    per_request = payload.get("per_request") or {}
    if list(per_request) != [item["request_label"]]:
        bad("per_request holds %r, expected exactly [%r]"
            % (list(per_request), item["request_label"]))
    rec = per_request.get(item["request_label"]) or {}
    if sorted(rec) != ["base", "repeat"]:
        bad("request %r has modes %r, base and repeat are both required"
            % (item["request_label"], sorted(rec)))
    by_kind = {}
    for kind in ("base", "repeat"):
        tr = rec.get(kind) or {}
        row["forward_requests"].append("%s_%s" % (item["request_label"], kind))
        executed = tr.get("forward_executed")
        row["forward_executed"].append(executed)
        ok = (executed is True and tr.get("batch_count") == 1 and tr.get("batch_size") == 2
              and tr.get("original_uids") == list(C.FORMAL_UIDS)
              and tr.get("unique_uids") == list(C.FORMAL_UIDS)
              and tr.get("valid_uids") == list(C.FORMAL_UIDS)
              and tr.get("reaction_task_id") == item["reaction_task_id"]
              and tr.get("reaction_smiles") == item["reaction_smiles"]
              and tr.get("model_version") == C.MODEL_VERSION
              and len(tr.get("ranked_enzymes") or []) == 2
              and len(tr.get("per_seed_scores") or []) == 5
              and all(len(s) == 2 for s in tr.get("per_seed_scores") or [])
              and len(str(tr.get("evidence_hash") or "")) == 64)
        row["requests_ok"].append(ok)
        row["ranked_uids"].append(json.dumps([r_.get("uid") for r_ in tr.get("ranked_enzymes") or []]))
        if not ok:
            bad("%s_%s is not a complete real forward: executed=%r batch=%r/%r uids=%r/%r/%r"
                " ranks=%r seeds=%r error=%s"
                % (item["request_label"], kind, executed, tr.get("batch_count"),
                   tr.get("batch_size"), tr.get("original_uids"), tr.get("unique_uids"),
                   tr.get("valid_uids"), [r_.get("uid") for r_ in tr.get("ranked_enzymes") or []],
                   [len(s) for s in tr.get("per_seed_scores") or []],
                   json.dumps(tr.get("error"))[:200]))
        if tr.get("monotonic_start") and tr.get("monotonic_end"):
            windows.append({"worker": wid, "kind": kind, "gpu": item["gpu"],
                            "start": tr["monotonic_start"], "end": tr["monotonic_end"]})
        by_kind[kind] = tr
    row["forward_call_count_after_repeat"] = (by_kind.get("repeat") or {}).get(
        "forward_call_count_after")
    if row["forward_call_count_after_repeat"] != 2:
        bad("forward_call_count_after_repeat=%r; this worker runs one reaction x (base+repeat)"
            % row["forward_call_count_after_repeat"])
    if (by_kind.get("base") or {}).get("forward_call_count_after") != 1:
        bad("base call count %r != 1" % (by_kind.get("base") or {}).get("forward_call_count_after"))
    base_scores = (by_kind.get("base") or {}).get("per_seed_scores") or []
    rep_scores = (by_kind.get("repeat") or {}).get("per_seed_scores") or []
    if len(base_scores) == 5 and len(rep_scores) == 5:
        worst = 0.0
        for si in range(5):
            for ui, uid in enumerate(C.FORMAL_UIDS):
                b, r_ = float(base_scores[si][ui]), float(rep_scores[si][ui])
                delta = abs(b - r_)
                worst = max(worst, delta)
                score_rows.append({"worker_index": wid, "gpu": item["gpu"],
                                   "reaction_task_id": item["reaction_task_id"],
                                   "uid": uid, "seed_index": si, "seed": C.SEEDS[si],
                                   "base_score": repr(b), "repeat_score": repr(r_),
                                   "abs_delta": repr(delta),
                                   "within_1e_5": "true" if delta <= TOLERANCE else "false"})
                if delta > TOLERANCE:
                    bad("base/repeat differ by %.3e for %s seed %d, tolerance is %.0e"
                        % (delta, uid, C.SEEDS[si], TOLERANCE))
                forward_pairs.add((item["reaction_task_id"], uid))
        row["max_abs_base_repeat_delta"] = repr(worst)
        if (by_kind["base"] or {}).get("evidence_hash") != (by_kind["repeat"] or {}).get("evidence_hash"):
            bad("base and repeat evidence_hash differ (%s vs %s)"
                % ((by_kind["base"] or {}).get("evidence_hash"),
                   (by_kind["repeat"] or {}).get("evidence_hash")))
    else:
        bad("per_seed_scores are not 5x2 for both kinds, so no delta could be computed")
    row["status"] = ("PASS" if row["exit_code"] == 0 and row["worker_status"] == "OK"
                     and row["requests_ok"] == [True, True] and row["uuid_matches_frozen"]
                     and all(v.endswith(":ok") for v in row["checkpoint_identity_vs_6_2"])
                     and all(v.endswith(":ok") for v in row["sequence_esm_gate"])
                     and not [p for p in problems if p.startswith("worker_%d(" % wid)]
                     else "FAIL")
    jsonl_rows.append({"worker_index": wid, "worker_id": wid, "gpu_index": item["gpu"],
                       "gpu_uuid": item["gpu_uuid"],
                       "request_label": item["request_label"],
                       "reaction_task_id": item["reaction_task_id"],
                       "reaction_smiles": item["reaction_smiles"], "argv": item["argv"],
                       "cwd": item["cwd"], "env_provenance": item["env_provenance"],
                       "interpreter": interp, "pid": payload.get("pid"),
                       "exit_code": res["exit"], "worker_status": payload.get("status"),
                       "started_utc": res["start_utc"], "ended_utc": row["ended_utc"],
                       "wall_sec": res["wall_sec"], "runtime_init_sec": row["runtime_init_sec"],
                       "device": {"name": row["actual_device_name"],
                                  "uuid": row["actual_device_uuid"],
                                  "visible_count": row["torch_visible_device_count"],
                                  "physical_count_on_host": row["physical_gpu_count_on_host"],
                                  "memory_free_mib": row["device_memory_free_mib"],
                                  "memory_total_mib": row["device_memory_total_mib"],
                                  "peak_allocated_mib": row["peak_cuda_mem_allocated_mib"]},
                       "checkpoint_sha256_by_seed": {str(k): v for k, v in observed.items()},
                       "sequence_esm_identity_check": res["seq_check"],
                       "per_request": per_request, "events": events,
                       "isolated_forward_pairs": ["%s|%s" % t for t in
                                                  sorted(forward_pairs)],
                       "stdout_log": res["stdout"], "stderr_log": res["stderr"],
                       "stdout_sha256": res["stdout_sha"], "stderr_sha256": res["stderr_sha"]})
    return row


if relaunched and not launch["refused"]:
    for wid in sorted(results):
        isol_rows.append(gate_worker(wid, results[wid]))
    isol_rows.sort(key=lambda r: r["worker_index"])


# --------------------------------------------------------------------------- 9. cross-worker gates
overlaps = []
if relaunched and not launch["refused"]:
    if len(forward_pairs) != 6:
        problems.append("forward_coverage: %d unique (reaction, UID) pairs completed, 6 required: %s"
                        % (len(forward_pairs), sorted("%s|%s" % t for t in forward_pairs)))
    for task_id, _rxn in C.REACTIONS:
        for uid in C.FORMAL_UIDS:
            if (task_id, uid) not in forward_pairs:
                problems.append("forward_coverage: %s x %s never produced a forward" % (task_id, uid))
    if C.THIRD_UID in {u for _t, u in forward_pairs}:
        problems.append("forward_coverage: %s must not be forwarded, only identity-checked"
                        % C.THIRD_UID)
    uuids_seen = [r["actual_device_uuid"] for r in isol_rows]
    if len(set(uuids_seen)) != 3:
        problems.append("gpu_isolation: the three workers report %r device UUIDs, three distinct"
                        " ones are required" % uuids_seen)
    if sorted(r["declared_gpu_uuid"] for r in isol_rows) != sorted(C.GPU_ASSIGNMENT[i][0]
                                                                   for i in C.GPU_ASSIGNMENT):
        problems.append("gpu_isolation: the frozen UUID map is not what was launched: %r"
                        % [r["declared_gpu_uuid"] for r in isol_rows])
    if sorted(r["physical_gpu_index"] for r in isol_rows) != [0, 1, 2]:
        problems.append("gpu_isolation: GPU indices %r" % [r["physical_gpu_index"] for r in isol_rows])
    # time.monotonic() is CLOCK_MONOTONIC, i.e. one system-wide clock across processes, so a
    # positive intersection between two workers' forward windows is real concurrency and not a
    # per-process artefact.
    for a in windows:
        for b in windows:
            if a["worker"] >= b["worker"]:
                continue
            inter = min(a["end"], b["end"]) - max(a["start"], b["start"])
            overlaps.append({"a": "worker_%d/%s" % (a["worker"], a["kind"]),
                             "b": "worker_%d/%s" % (b["worker"], b["kind"]),
                             "intersection_sec": round(inter, 3)})
    positive = [o for o in overlaps if o["intersection_sec"] > 0]
    if not positive:
        problems.append("parallelism: no two workers' forward windows overlap, so the three runs"
                        " did not really happen concurrently: %s" % json.dumps(overlaps[:6]))
    emit("-- concurrency: %d/%d cross-worker window pairs overlap, max %.1f s of %d pairs"
         % (len(positive), len(overlaps),
            max([o["intersection_sec"] for o in overlaps] or [0.0]), len(overlaps)))
    emit("-- 6/6 (reaction, UID) pairs: %d | distinct device UUIDs: %d" % (len(forward_pairs),
                                                                           len(set(uuids_seen))))
    emit("-- per-worker wall: %s | runtime init: %s"
         % (json.dumps([r["wall_sec"] for r in isol_rows]),
            json.dumps([r["runtime_init_sec"] for r in isol_rows])))
else:
    overlaps = (prior or {}).get("cross_worker_overlap") or []

# --------------------------------------------------------------------------- 10. deliverables
if relaunched and not launch["refused"]:
    with open(ISOLATION_CSV, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=ISOLATION_FIELDS, lineterminator="\n")
        writer.writeheader()
        for row in isol_rows:
            out = dict(row)
            for key in ("sequence_esm_gate", "esm_mean_nonzero", "checkpoint_identity_vs_6_2",
                        "forward_requests", "forward_executed", "ranked_uids", "requests_ok"):
                out[key] = json.dumps(out[key], ensure_ascii=False)
            writer.writerow(out)
    if score_rows:
        with open(SCORES_CSV, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(score_rows[0].keys()), lineterminator="\n")
            writer.writeheader()
            writer.writerows(score_rows)
    with open(FORWARD_JSONL, "w", encoding="utf-8") as fh:
        for row in jsonl_rows:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
else:
    notes.append("no new CSV/JSONL written by this invocation (%s)"
                 % ("adopted from a passing earlier invocation" if not relaunched
                    else "preflight refused the launch"))

blocked_reason = None
if problems:
    if launch.get("refused"):
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_PREFLIGHT"
    elif launch["timed_out"]:
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_TIMEOUT"
    elif any("wrapper_import" in p or "import_root" in p for p in problems):
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_WRAPPER_IMPORT"
    elif any("argv0" in p or "interpreter" in p or "ase was not loaded" in p or "overlay is on" in p
             for p in problems):
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_INTERPRETER"
    elif any("traceback" in p or "status=" in p or "exit=" in p for p in problems):
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_WORKER_ERROR"
    elif any("sequence" in p or "UID" in p for p in problems):
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_SEQUENCE_ESM_IDENTITY"
    elif any("checkpoint" in p for p in problems):
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_CHECKPOINT_IDENTITY"
    elif any("forward_coverage" in p or "isolation" in p or "parallelism" in p for p in problems):
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_INCOMPLETE_OR_SERIAL"
    else:
        blocked_reason = "BLOCKED_AT_T3B_FORWARD_GATE_FAILURE"
verdict = {
    "WORKER_BASELINE_IMMUTABLE": ("PASS" if baseline_identity and not [
        p for p in problems if p.startswith("baseline_worker") or p.startswith("local constant")]
        else "FAIL"),
    "WORKER_DERIVATION_ADDITIVE_ONLY": ("PASS" if not [p for p in problems
                                                       if p.startswith("worker_derivation")] else "FAIL"),
    "GPU_TOPOLOGY_AND_UUID_MAP": "PASS" if not [p for p in problems if p.startswith("gpu_")] else "FAIL",
    "WORKER_INTERPRETER_AND_ISOLATION": ("PASS" if not [p for p in problems if "interpreter" in p
                                                        or "argv0" in p or "isolation" in p
                                                        or "ase was not loaded" in p
                                                        or "overlay is on" in p] else "FAIL"),
    "FORWARD_PAIRS": "%d/6" % len(forward_pairs) if relaunched else
                     str((prior or {}).get("forward_pair_count", 0)) + "/6 (adopted)",
    "REPEAT_TOLERANCE_USED": repr(TOLERANCE),
    "UPSTREAM_FAILURES_6_2_6_3": len([p for p in problems if p.startswith("upstream")]),
    "PROBLEM_COUNT": len(problems),
}
if relaunched and not launch["refused"] and isol_rows:
    all_pass = all(r["status"] == "PASS" for r in isol_rows) and not problems
    verdict["GPU_FORWARD_GATE"] = "PASS_6_OF_6" if all_pass else blocked_reason
    verdict["T3B_BOUNDED_FORWARD"] = "PASS_6_OF_6" if all_pass else blocked_reason
elif not relaunched:
    verdict["GPU_FORWARD_GATE"] = str((prior or {}).get("verdict", {}).get("GPU_FORWARD_GATE",
                                                                          "NOT_RECORDED")) + " (adopted)"
    verdict["T3B_BOUNDED_FORWARD"] = "PASS_6_OF_6 (adopted from invocation %s)" % (
        (prior or {}).get("invocation"))
else:
    verdict["GPU_FORWARD_GATE"] = blocked_reason
    verdict["T3B_BOUNDED_FORWARD"] = blocked_reason

# Every earlier invocation of this launcher is kept, never overwritten in place: its gate JSON
# sits under logs/p12_attempt_<n>/ together with the worker directories it produced.
attempt_history = []
for agate in sorted(LOGS.glob("p12_attempt_*/" + GATE_JSON.name)):
    try:
        aj = json.loads(agate.read_text(encoding="utf-8"))
    except Exception as exc:
        attempt_history.append({"gate_json": str(agate), "unreadable": type(exc).__name__})
        continue
    attempt_history.append({
        "gate_json": str(agate), "invocation": aj.get("invocation"),
        "verdict": aj.get("verdict"), "problem_count": len(aj.get("problems") or []),
        "first_problems": [p[:220] for p in (aj.get("problems") or [])[:4]]})

gate_doc = {
    "section": "T6-R3-R1 §7", "utc": C.now_utc(), "invocation": invocation,
    "verdict": verdict, "problems": problems, "notes": notes,
    "pinned_python": C.PY, "pinned_env_prefix": ENVP,
    "baseline_worker": baseline_identity, "frozen_baseline_expected": {
        "bytes": C.RUN_GPU_WORKER_BYTES, "sha256": C.RUN_GPU_WORKER_SHA},
    "derived_worker": derived_identity, "addendum": addendum,
    "import_roots_given_to_workers": {
        "d4_wrapper_sys_path_entry": str(D4_IMPORT_ROOT),
        "teacher_sys_path_entry": C.CODE_ROOT,
        "package_members": PACKAGE_MEMBERS},
    "wrapper_import_probe": probe_record,
    "protein_asset_identity": asset_evidence,
    "accepted_module_source_matrix": {str(k): {"version": v.get("version_before"),
                                               "file": v.get("before_file"),
                                               "changed": v.get("changed")}
                                      for k, v in sorted(ACCEPTED_SOURCE.items())},
    "module_source_matrix_csv": str(MATRIX_CSV),
    "checkpoint_identity_from_6_2": ckpt_expect,
    "sequence_pins_from_6_3": seq_gate_summary_6_3,
    "native_load_6_3": native_load_evidence,
    "gpu_topology_discovered": gpus, "gpu_accepted_record_4": ACCEPTED_GPU,
    "gpu_assignment_frozen": {
        str(k): list(v) for k, v in sorted(C.GPU_ASSIGNMENT.items())},
    "ram_available_gb": avail_gb, "launch": launch, "launch_plan": [
        {k: v for k, v in p.items() if k not in ("env",)} for p in plan],
    "workers": isol_rows, "forward_pair_count": len(forward_pairs) if relaunched else
        (prior or {}).get("forward_pair_count", 0),
    "forward_pairs": sorted("%s|%s" % t for t in forward_pairs),
    "forward_windows": [{"worker": w["worker"], "kind": w["kind"], "gpu": w["gpu"],
                         "start_relative_sec": round(w["start"] - (launch.get("launch_mono") or 0), 3),
                         "end_relative_sec": round(w["end"] - (launch.get("launch_mono") or 0), 3),
                         "duration_sec": round(w["end"] - w["start"], 4)} for w in windows],
    "cross_worker_overlap": overlaps, "overlapping_pairs": len(
        [o for o in overlaps if o["intersection_sec"] > 0]),
    "repeat_tolerance": TOLERANCE, "prior_gate_adopted": (not relaunched) and bool(prior),
    "attempt_history": attempt_history,
    "supersedes": str(prior.get("gate_json", "")) if (not relaunched) else "",
    "deliverables": {"GPU_WORKER_ASSIGNMENT_AND_ISOLATION": str(ISOLATION_CSV),
                     "FORWARD_PER_REACTION_UID_SEED_SCORES": str(SCORES_CSV),
                     "T3B_NATIVE_LOAD_AND_FORWARD_RESULTS": str(FORWARD_JSONL),
                     "worker_raw_output_dir": str(workers_dir),
                     "worker_combined_logs": str(WORKER_LOGS_TXT)},
}
if relaunched:
    GATE_JSON.write_text(json.dumps(gate_doc, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")

# --------------------------------------------------------------------------- 11. report
emit("")
emit("-- per worker " + "-" * 54)
for row in isol_rows:
    emit("   GPU%d %s pid=%s exit=%s status=%s wall=%ss init=%ss fwd_calls=%s uuid_ok=%s"
         % (row["physical_gpu_index"], row["request_label"], row["worker_pid"], row["exit_code"],
            row["worker_status"], row["wall_sec"], row["runtime_init_sec"],
            row["forward_call_count_after_repeat"], row["uuid_matches_frozen"]))
    emit("        checkpoints=%s" % " ".join(row["checkpoint_identity_vs_6_2"]))
    emit("        seq/ESM=%s esm_nonzero=%s requests_ok=%s max_delta=%s -> %s"
         % (" ".join(row["sequence_esm_gate"]), row["esm_mean_nonzero"], row["requests_ok"],
            row["max_abs_base_repeat_delta"], row["status"]))
    if row["worker_status"] != "OK" and row["worker_index"] in results:
        emit("        traceback tail: %s"
             % str((results[row["worker_index"]]["payload"].get("traceback") or "").splitlines()[-1:])[:300])
if problems:
    emit("-- PROBLEMS (%d):" % len(problems))
    for p in problems[:14]:
        emit("   - " + p[:300])
if attempt_history:
    emit("-- earlier invocations preserved (nothing deleted, each archived with its own workers):")
    for h in attempt_history:
        emit("   invocation %s -> %s problems=%s %s"
             % (h.get("invocation"), (h.get("verdict") or {}).get("T3B_BOUNDED_FORWARD"),
                h.get("problem_count"), h.get("gate_json")))
        for p in (h.get("first_problems") or [])[:2]:
            emit("       %s" % p[:220])
emit("")
emit("============ T6-R3-R1 §7 VERDICT ============")
for key in ("WORKER_BASELINE_IMMUTABLE", "WORKER_DERIVATION_ADDITIVE_ONLY",
            "GPU_TOPOLOGY_AND_UUID_MAP", "WORKER_INTERPRETER_AND_ISOLATION", "FORWARD_PAIRS",
            "GPU_FORWARD_GATE", "T3B_BOUNDED_FORWARD", "REPEAT_TOLERANCE_USED", "PROBLEM_COUNT"):
    emit("%s=%s" % (key, verdict[key]))
emit("===========================================")
STDOUT_TXT.write_text("\n".join(say) + "\n", encoding="utf-8")
C.self_audit(str(Path(__file__).resolve()), 0 if not problems else 3,
             "T6-R3-R1 §7 three-GPU real base+repeat forward coordinator")
sys.exit(0 if not problems else 3)
