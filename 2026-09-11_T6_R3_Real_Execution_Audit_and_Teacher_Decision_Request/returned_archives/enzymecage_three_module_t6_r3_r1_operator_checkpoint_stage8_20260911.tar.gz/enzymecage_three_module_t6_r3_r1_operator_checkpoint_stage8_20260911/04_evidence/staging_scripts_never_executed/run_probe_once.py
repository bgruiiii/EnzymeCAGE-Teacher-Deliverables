import ast, json, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
src = open("p12_forward.py", encoding="utf-8").read()
tree = ast.parse(src)
probe = None
for node in ast.walk(tree):
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id == "PROBE_SRC":
                probe = ast.literal_eval(node.value)
assert probe, "PROBE_SRC not found"
import r1_common as C
env = C.base_env({"CUDA_VISIBLE_DEVICES": "", "R1_PINNED_PY": C.PY})
env.pop("PYTHONPATH", None); env.pop("PYTHONHOME", None)
p = subprocess.run([sys.executable, "-B", "-c", probe, C.CODE_ROOT, str(C.D4_WRAPPER_PARENT)],
                   cwd=C.CODE_ROOT, env=env, capture_output=True, text=True, timeout=600)
print("exit", p.returncode)
for line in p.stdout.splitlines():
    if line.startswith("@@P12PROBE@@"):
        d = json.loads(line[12:])
        print(json.dumps(d, ensure_ascii=False, indent=1)[:3000])
    else:
        print("STDOUT:", line[:200])
print("STDERR tail:", p.stderr[-1500:])
