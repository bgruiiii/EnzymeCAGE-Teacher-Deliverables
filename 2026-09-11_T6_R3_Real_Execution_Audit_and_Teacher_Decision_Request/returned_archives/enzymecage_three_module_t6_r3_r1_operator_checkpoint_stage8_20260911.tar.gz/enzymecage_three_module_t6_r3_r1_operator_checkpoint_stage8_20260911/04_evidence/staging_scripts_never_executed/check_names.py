"""Static undefined-name probe (pyflakes is not installed and §3 forbids installing).

Reports names that are referenced but neither bound anywhere in the file nor a builtin, and
names that are referenced in a function before any binding in that function.  This is only a
cheap pre-flight so that a typo cannot waste the run-once §6.3 native loads.
"""
import builtins
import symtable
import sys

EXTRA = {"__file__", "__name__", "__doc__", "__builtins__", "__spec__", "__loader__",
         "__package__", "__class__", "__debug__"}


def module_bound(top):
    names = set()
    for s in top.get_symbols():
        if s.is_assigned() or s.is_imported() or s.is_namespace():
            names.add(s.get_name())
    for child in top.get_children():
        if child.get_name() in ("top",):
            continue
        names.add(child.get_name())          # def / class / comprehension scopes
    return names


def walk(table, bound, out, path=""):
    for s in table.get_symbols():
        name = s.get_name()
        if name in bound or name in EXTRA or hasattr(builtins, name):
            continue
        if s.is_assigned() or s.is_imported() or s.is_parameter() or s.is_local():
            continue
        if s.is_free() or s.is_global():
            if s.is_referenced():
                out.append("%s%s (%s)" % (path, name,
                                          "free" if s.is_free() else "global"))
    for child in table.get_children():
        if child.get_name() == "top":
            continue
        walk(child, bound, out, path + child.get_name() + ".")


def main(files):
    bad = 0
    for f in files:
        src = open(f, encoding="utf-8").read()
        top = symtable.symtable(src, f, "exec")
        bound = module_bound(top)
        out = []
        walk(top, bound, out)
        seen = set()
        for line in out:
            key = line.split(".")[0]
            if key in seen:
                continue
            seen.add(key)
        uniq = sorted(set(out))
        print("%s: %d unresolved reference(s)" % (f, len(uniq)))
        for u in uniq:
            print("   ", u)
            bad += 1
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
