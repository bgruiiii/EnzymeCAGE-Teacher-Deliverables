import csv
import hashlib
import sys
import time

UIDS = {"A0A011QK89", "A0A017SP50", "A0A017SR40"}
FILES = ["/usrdata/EnzymeCAGE_data/formal_splits/formal_filtered_train.csv",
         "/usrdata/EnzymeCAGE_data/formal_splits/formal_filtered_valid.csv",
         "/usrdata/EnzymeCAGE_data/formal_splits/formal_filtered_test.csv"]
seen = {}
t = time.time()
for f in FILES:
    n = 0
    with open(f, newline="", encoding="utf-8") as fh:
        r = csv.DictReader(fh)
        for row in r:
            n += 1
            u = row["UniprotID"]
            if u in UIDS:
                seen.setdefault(u, {}).setdefault(row["sequence"], []).append((f.split("_")[-1], n))
    print("%s rows=%d elapsed=%.1fs" % (f, n, time.time() - t), flush=True)
for u in sorted(seen):
    seqs = seen[u]
    print("== %s distinct_sequences=%d" % (u, len(seqs)), flush=True)
    for s, where in seqs.items():
        print("   len=%d sha_utf8=%s rows=%d first=%s"
              % (len(s), hashlib.sha256(s.encode("utf-8")).hexdigest(), len(where), where[0]),
              flush=True)
