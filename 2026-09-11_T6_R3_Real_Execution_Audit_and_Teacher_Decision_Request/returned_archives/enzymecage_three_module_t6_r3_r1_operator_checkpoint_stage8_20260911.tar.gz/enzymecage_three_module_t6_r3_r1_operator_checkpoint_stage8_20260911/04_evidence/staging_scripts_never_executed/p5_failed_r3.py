# -*- coding: utf-8 -*-
"""Phase E1 §5.1: identity and safe intake of the blocked first-round T6-R3 package.

Checks, in order:
  FAILED_R3 regular/non-symlink/bytes/SHA; identity sidecar SHA and its CONTENT_STATUS line;
  single root; member safety (no absolute, '..', symlink, hardlink, device, FIFO);
  extraction into INPUT_ROOT/failed_r3;
  the first-round manifest covers 66 of 68 regular files: every listed SHA must hold on the
  extracted bytes, and the two files the manifest does not list are recorded as known input
  problem P1 rather than used to reject the audited SOURCE_PATCH.diff;
  the three frozen re-uses (SOURCE_PATCH.diff, T6_INCREMENTAL_PATCH.diff,
  scripts/run_gpu_worker.py) by bytes + SHA;
  FINAL_STATUS.txt content status and root cause.

Writes R3_BLOCKED_BASELINE_IDENTITY.json and FAILED_R3_MANIFEST_VERIFICATION.csv.
"""
import hashlib
import json
import sys
import tarfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import r1_common as C                                                   # noqa: E402

C.self_audit(__file__, -1, note="E1 §5.1 blocked first-round intake")
problems = []
notes = []

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


print("PHASE=E1.1 failed-R3 intake")
print("UTC=" + C.now_utc())

# ---------------------------------------------------------------- archive identity
def file_identity(p, want_bytes, want_sha, label):
    rec = {"path": str(p), "expected_bytes": want_bytes, "expected_sha256": want_sha}
    q = Path(p)
    rec["exists"] = q.is_file()
    rec["is_regular_non_symlink"] = q.is_file() and not q.is_symlink()
    if not rec["is_regular_non_symlink"]:
        rec["verdict"] = "ABSENT_OR_NOT_REGULAR"
        problems.append("%s absent or not a regular non-symlink file" % label)
        return rec
    rec["bytes"] = q.stat().st_size
    rec["sha256"] = sha(q)
    ok = (rec["bytes"] == want_bytes and rec["sha256"] == want_sha)
    rec["verdict"] = "VERIFIED_MATCH" if ok else "MISMATCH"
    if not ok:
        problems.append("%s identity mismatch bytes=%s/%s sha=%s" % (
            label, rec["bytes"], want_bytes, rec["sha256"][:16]))
    print("%-14s bytes=%-8s sha=%s %s" % (label, rec["bytes"], rec["sha256"][:16],
                                          rec["verdict"]))
    return rec


arc = file_identity(C.FAILED_R3, C.FAILED_R3_BYTES, C.FAILED_R3_SHA, "FAILED_R3")
idt = file_identity(C.FAILED_R3_ID, 470, C.FAILED_R3_ID_SHA, "FAILED_R3_ID")

identity_text = C.FAILED_R3_ID.read_text(encoding="utf-8") if C.FAILED_R3_ID.is_file() else ""
identity_fields = {}
for line in identity_text.splitlines():
    if "=" in line:
        k, v = line.split("=", 1)
        identity_fields[k.strip()] = v.strip()
content_status = identity_fields.get("CONTENT_STATUS", "")
print("identity CONTENT_STATUS=%s ARCHIVE_BYTES=%s ARCHIVE_SHA=%s"
      % (content_status, identity_fields.get("ARCHIVE_BYTES"),
         identity_fields.get("ARCHIVE_SHA256", "")[:16]))
if content_status != "BLOCKED_AT_T3B_FORWARD":
    problems.append("identity CONTENT_STATUS is %r, expected BLOCKED_AT_T3B_FORWARD"
                    % content_status)
if identity_fields.get("ARCHIVE_SHA256") != C.FAILED_R3_SHA:
    problems.append("identity archive sha does not match the prompt's frozen sha")
if identity_fields.get("BASE_COMMIT") != C.BASE_COMMIT:
    problems.append("identity BASE_COMMIT=%s differs from the frozen base"
                    % identity_fields.get("BASE_COMMIT"))

# ---------------------------------------------------------------- membership + safety
dest = C.INPUT_ROOT / "failed_r3"
rejected = []
members = []
with tarfile.open(str(C.FAILED_R3), "r:gz") as tf:
    for m in tf.getmembers():
        parts = Path(m.name).parts
        kind = ("dir" if m.isdir() else "file" if m.isfile() else "other")
        unsafe = (m.name.startswith("/") or ".." in parts
                  or not (m.isfile() or m.isdir()))
        members.append({"name": m.name, "kind": kind, "bytes": m.size, "unsafe": unsafe})
        if unsafe:
            rejected.append({"member": m.name, "reason": "unsafe path or non-regular type"})
roots = {Path(x["name"]).parts[0] for x in members}
single_root = len(roots) == 1
root_name = sorted(roots)[0] if single_root else "MULTIPLE"
regular = [x for x in members if x["kind"] == "file"]
print("members total=%d regular=%d dirs=%d single_root=%s root=%s unsafe=%d"
      % (len(members), len(regular), sum(1 for x in members if x["kind"] == "dir"),
         single_root, root_name, len(rejected)))
if not single_root:
    problems.append("archive is not single-root: %s" % sorted(roots))
if rejected:
    problems.append("unsafe members present: %d" % len(rejected))
if root_name != C.FAILED_R3_TASK:
    problems.append("archive root %s != expected first-round task id" % root_name)

ex = C.safe_extract(C.FAILED_R3, dest)
print("safe_extract written=%d rejected=%d" % (ex["written"], len(ex["rejected"])))
if ex["rejected"]:
    problems.append("extractor rejected members: %s" % ex["rejected"][:3])
pkg = dest / C.FAILED_R3_TASK

# ---------------------------------------------------------------- manifest 66/68
on_disk = sorted(p for p in pkg.rglob("*") if p.is_file())
rel = [str(p.relative_to(pkg)) for p in on_disk]
man_files = pkg / "MANIFEST.files"
man_sha = pkg / "MANIFEST.sha256"
listed = [x.strip() for x in man_files.read_text(encoding="utf-8").splitlines() if x.strip()] \
    if man_files.is_file() else []
sha_rows = []
if man_sha.is_file():
    for line in man_sha.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) == 2:
            sha_rows.append({"sha256": parts[0], "name": parts[1]})
        elif len(parts) == 3 and parts[0] == "sha256sum":
            sha_rows.append({"sha256": parts[1], "name": parts[2].lstrip("*")})
missing_from_disk = [x for x in listed if x not in rel]
extra_on_disk = [x for x in rel if x not in listed]
rows = []
bad = 0
for r in sha_rows:
    p = pkg / r["name"]
    if not p.is_file():
        rows.append(dict(r, observed="", verdict="FILE_ABSENT"))
        bad += 1
        continue
    got = sha(p)
    ok = got == r["sha256"]
    if not ok:
        bad += 1
    rows.append(dict(r, observed=got, verdict="PASS" if ok else "SHA_MISMATCH"))
print("MANIFEST.files lines=%d  MANIFEST.sha256 lines=%d  regular on disk=%d"
      % (len(listed), len(sha_rows), len(rel)))
print("sha rows verified=%d/%d ; files listed but absent=%d ; on disk but unlisted=%d -> %s"
      % (len(sha_rows) - bad, len(sha_rows), len(missing_from_disk), len(extra_on_disk),
         extra_on_disk))
if bad:
    problems.append("%d listed SHA rows failed" % bad)
if len(sha_rows) != 66 or len(rel) != 68:
    notes.append("manifest coverage is %d listed of %d regular files; the prompt fixes this "
                 "as known input problem P1" % (len(sha_rows), len(rel)))
if sorted(extra_on_disk) != sorted(["MANIFEST.files", "MANIFEST.sha256"]):
    notes.append("unlisted set differs from the expected manifest-self pair: %s"
                 % extra_on_disk)
P1 = {"known_input_problem": "P1",
      "description": ("the blocked first-round manifest lists 66 of 68 regular files; the two "
                      "unlisted members are the manifest files themselves. All 66 listed SHAs "
                      "were required to hold and were verified on the extracted bytes; the "
                      "gap did not block reading the audited SOURCE_PATCH.diff"),
      "unlisted_members": extra_on_disk,
      "listed_rows_verified": len(sha_rows) - bad,
      "listed_rows_total": len(sha_rows)}

# ---------------------------------------------------------------- frozen re-use
fixed = {
    "SOURCE_PATCH.diff": (C.SOURCE_PATCH_BYTES, C.SOURCE_PATCH_SHA),
    "T6_INCREMENTAL_PATCH.diff": (C.T6_INCREMENTAL_BYTES, C.T6_INCREMENTAL_SHA),
    "scripts/run_gpu_worker.py": (C.RUN_GPU_WORKER_BYTES, C.RUN_GPU_WORKER_SHA),
}
reuse = {}
for name, (wb, ws) in sorted(fixed.items()):
    p = pkg / name
    rec = {"path": str(p), "expected_bytes": wb, "expected_sha256": ws}
    if not p.is_file():
        rec["verdict"] = "ABSENT"
        problems.append("frozen reuse absent: %s" % name)
    else:
        rec["bytes"] = p.stat().st_size
        rec["sha256"] = sha(p)
        rec["regular_non_symlink"] = not p.is_symlink()
        rec["verdict"] = ("VERIFIED_MATCH" if (rec["bytes"] == wb and rec["sha256"] == ws)
                          else "MISMATCH")
        if rec["verdict"] != "VERIFIED_MATCH":
            problems.append("frozen reuse identity mismatch: %s" % name)
    reuse[name] = rec
    print("reuse %-26s %s" % (name, rec["verdict"]))

# exploratory copy made earlier in this task: prove it is byte-identical to the verified one
frs = C.INPUT_ROOT / "fr_scripts"
expl = {"directory": str(frs),
        "note": ("five scripts were read out of this archive before this step existed, to "
                 "study the 157-item and forward recipes; re-hashed here against the "
                 "verified package members, and superseded by the formal extraction"),
        "files": {}}
for p in sorted(frs.glob("*.py")) if frs.is_dir() else []:
    twin = pkg / "scripts" / p.name
    same = twin.is_file() and sha(p) == sha(twin)
    expl["files"][p.name] = {"sha256": sha(p), "package_twin": str(twin),
                             "matches_verified_package_copy": same}
    if not same:
        notes.append("exploratory copy %s is not byte-identical to the package member"
                     % p.name)

# ---------------------------------------------------------------- first-round status
fs_path = pkg / "FINAL_STATUS.txt"
final_status_text = fs_path.read_text(encoding="utf-8") if fs_path.is_file() else ""
fs_fields = {}
for line in final_status_text.splitlines():
    if "=" in line:
        k, v = line.split("=", 1)
        fs_fields[k.strip()] = v.strip()
if final_status_text.splitlines()[:1] != ["BLOCKED_AT_T3B_FORWARD"]:
    problems.append("first-round FINAL_STATUS first line is %r"
                    % (final_status_text.splitlines()[:1]))
cmd_log = pkg / "COMMAND_LOG.txt"
cmd_log_text = cmd_log.read_text(encoding="utf-8") if cmd_log.is_file() else ""

doc = {
    "task_id": C.TASK_ID,
    "generated_utc": C.now_utc(),
    "phase": "E1 §5.1 blocked first-round baseline identity",
    "failed_r3_archive": arc,
    "failed_r3_identity_sidecar": idt,
    "identity_fields": identity_fields,
    "content_status": content_status,
    "membership": {"total_members": len(members), "regular_files": len(regular),
                   "single_root": single_root, "root": root_name,
                   "rejected_unsafe": rejected},
    "extraction": {"dest": str(pkg), "files_written": ex["written"],
                   "rejected": ex["rejected"], "regular_on_disk": len(rel)},
    "manifest_coverage": {"listed_files": len(listed), "sha_rows": len(sha_rows),
                          "regular_on_disk": len(rel), "verified": len(sha_rows) - bad,
                          "unlisted_members": extra_on_disk,
                          "listed_but_absent": missing_from_disk},
    "known_input_problem_P1": P1,
    "frozen_reuse": reuse,
    "exploratory_script_copy": expl,
    "first_round_final_status": {"text": final_status_text, "fields": fs_fields},
    "first_round_command_log_bytes": len(cmd_log_text.encode()),
    "first_round_command_log_sha256": hashlib.sha256(cmd_log_text.encode()).hexdigest(),
    "first_round_root_cause": fs_fields.get("ROOT_CAUSE", ""),
    "problems": problems,
    "notes": notes,
    "verdict": "PASS" if not problems else "FAIL",
}
C.RETURN_DIR.mkdir(parents=True, exist_ok=True)
(C.RETURN_DIR / "R3_BLOCKED_BASELINE_IDENTITY.json").write_text(
    json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
csv_rows = ["name,listed_sha256,observed_sha256,verdict"]
for r in rows:
    csv_rows.append("%s,%s,%s,%s" % (r["name"], r["sha256"], r.get("observed", ""),
                                     r["verdict"]))
for name in extra_on_disk:
    csv_rows.append("%s,NOT_LISTED_BY_FIRST_ROUND_MANIFEST,%s,P1_UNLISTED_KNOWN_INPUT_PROBLEM"
                    % (name, sha(pkg / name)))
(C.RETURN_DIR / "FAILED_R3_MANIFEST_VERIFICATION.csv").write_text(
    "\n".join(csv_rows) + "\n", encoding="utf-8")
print("E1_1_VERDICT=%s problems=%s" % (doc["verdict"], json.dumps(problems)))
print("P1=%s" % json.dumps(P1["unlisted_members"]))
sys.exit(0 if not problems else 3)
