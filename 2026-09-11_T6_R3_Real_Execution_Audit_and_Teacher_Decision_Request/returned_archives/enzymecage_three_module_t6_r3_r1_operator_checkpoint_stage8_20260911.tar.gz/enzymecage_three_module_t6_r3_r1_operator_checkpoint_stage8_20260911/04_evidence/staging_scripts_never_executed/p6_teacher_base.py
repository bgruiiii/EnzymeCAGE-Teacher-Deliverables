# -*- coding: utf-8 -*-
"""Phase E1 §5.2 + §5.3: deterministic teacher exact base, frozen patch, topology gate.

§5.2 order of attempts (each bounded, no retries beyond two):
  1. network: git ls-remote then git clone of the teacher remote, 60 s per attempt, at most
     two attempts, into a scratch directory under WORK_ROOT/tmp;
  2. local read-only object stores named by the prompt, which must prove
     cat-file -e BASE^{commit}, rev-parse BASE^{tree} == BASE_TREE, and a de-credentialled
     remote URL that points at the teacher depending repository;
  3. the chosen source is turned into a brand-new STAGED_REPO with
     `git clone --no-hardlinks`, checked out detached at BASE_COMMIT, verified
     HEAD/tree/clean.  No pull/fetch/reset/clean/stash is ever run on an existing repo.

§5.3 then applies the frozen SOURCE_PATCH.diff (check first, no content edits), proves the
regenerated cumulative patch or the per-file final identities, matches the changed set
against the first-round CHANGED_FILES.csv, and requires the four teacher topology files to
stay byte-identical to BASE_COMMIT.
"""
import hashlib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import r1_common as C                                                   # noqa: E402

C.self_audit(__file__, -1, note="E1 §5.2-5.3 teacher base, patch and topology gate")
problems = []
LINES = []


def say(msg):
    LINES.append(msg)
    print(msg, flush=True)


def git(args, cwd, note=""):
    rc, out, err = C.run(["git"] + list(args), cwd=cwd, note=note)
    return rc, out, err


def mask(text):
    """Remove anything that could carry credentials from a git message."""
    t = re.sub(r"(https?://)([^/@]+)@", r"\1***@", text or "")
    t = re.sub(r"(ssh://)?[^ ]*@([^ :]+:)", r"***@\2:", t)
    return t.strip()


say("PHASE=E1.2/E1.3 teacher base + source/topology gate")
say("UTC=" + C.now_utc())

PKG = C.INPUT_ROOT / "failed_r3" / C.FAILED_R3_TASK          # verified in §5.1
PATCH = PKG / "SOURCE_PATCH.diff"
INC_PATCH = PKG / "T6_INCREMENTAL_PATCH.diff"
if not PATCH.is_file():
    say("BLOCKED_SOURCE_OR_TEACHER_TOPOLOGY_IDENTITY :: frozen patch absent")
    sys.exit(3)

# ---------------------------------------------------------------- §5.2 acquisition
net_attempts = []
remote_source = None
for attempt in (1, 2):
    scratch = C.TMPS / ("teacher_remote_clone_try%d" % attempt)
    probe_rc, probe_out, probe_err = C.run(
        ["git", "ls-remote", "--heads", C.TEACHER_REMOTE],
        env={"GIT_TERMINAL_PROMPT": "0", "GIT_SSH_COMMAND": "ssh -o BatchMode=yes "
                                                           "-o ConnectTimeout=20"},
        note="§5.2 network attempt %d: bounded ls-remote (60s)" % attempt, timeout=60)
    rec = {"attempt": attempt, "ls_remote_rc": probe_rc,
           "ls_remote_stderr_masked": mask(probe_err)[-400:],
           "ls_remote_heads": [x.split()[-1] for x in probe_out.splitlines()][:5]}
    if probe_rc == 0:
        clone_rc, _, cerr = C.run(
            ["git", "clone", "--origin", "teacher", "--", C.TEACHER_REMOTE, str(scratch)],
            env={"GIT_TERMINAL_PROMPT": "0",
                 "GIT_SSH_COMMAND": "ssh -o BatchMode=yes -o ConnectTimeout=20"},
            note="§5.2 network attempt %d: bounded fresh clone (60s)" % attempt, timeout=60)
        rec["clone_rc"] = clone_rc
        rec["clone_stderr_masked"] = mask(cerr)[-400:]
        rec["clone_path"] = str(scratch)
        if clone_rc == 0 and scratch.is_dir():
            v_rc, v_out, _ = git(["cat-file", "-e", "%s^{commit}" % C.BASE_COMMIT], scratch,
                                 note="§5.2 remote clone contains BASE_COMMIT")
            rec["contains_base_commit"] = v_rc == 0
            t_rc, t_out, _ = git(["rev-parse", "%s^{tree}" % C.BASE_COMMIT], scratch,
                                 note="§5.2 remote clone BASE tree")
            rec["base_tree"] = t_out.strip()
            if v_rc == 0 and t_out.strip() == C.BASE_TREE:
                remote_source = scratch
    else:
        rec["clone_attempted"] = False
    net_attempts.append(rec)
    say("network attempt %d: ls-remote rc=%s clone_rc=%s usable=%s"
        % (attempt, rec["ls_remote_rc"], rec.get("clone_rc", "n/a"),
           rec.get("contains_base_commit", False)))
    if remote_source is not None:
        break

LOCAL_CANDIDATES = [
    # prompt-named local object stores, teacher URL attached, read-only use only
    Path("/usrdata/EnzymeCAGE_data/workspaces/"
         "enzymecage_three_module_t6_r3a_r2a_microbe_node_output_uid_map_fallback_host_"
         "signature_correction_20260909/depending_exact_teacher_base"),
    Path("/root/projects/depending"),
    Path("/root/projects/enzymecage_crew"),
    C.FAILED_R3_WS / "depending_teacher_fixed_final",
    C.FAILED_R3_WS / "validation_patch_replay",
    C.FAILED_R3_WS / "prefreeze_patch_replay",
]
fallback_audit = []
local_source = None
for cand in LOCAL_CANDIDATES:
    entry = {"candidate": str(cand), "exists": cand.is_dir()}
    if not cand.is_dir():
        fallback_audit.append(entry)
        continue
    rc_git, out_git, _ = git(["rev-parse", "--git-dir"], cand,
                             note="§5.2 candidate is a git repository")
    entry["is_git_repo"] = rc_git == 0
    entry["git_dir"] = out_git.strip()
    if rc_git != 0:
        fallback_audit.append(entry)
        continue
    rc_c, _, _ = git(["cat-file", "-e", "%s^{commit}" % C.BASE_COMMIT], cand,
                     note="§5.2 candidate has BASE_COMMIT object")
    entry["cat_file_base_commit"] = "PASS" if rc_c == 0 else "FAIL"
    rc_t, out_t, _ = git(["rev-parse", "%s^{tree}" % C.BASE_COMMIT], cand,
                         note="§5.2 candidate BASE tree")
    entry["tree_of_base_commit"] = out_t.strip()
    entry["tree_matches"] = out_t.strip() == C.BASE_TREE
    rc_u, out_u, err_u = git(["config", "--get", "remote.origin.url"], cand,
                             note="§5.2 candidate remote url")
    url = out_u.strip()
    entry["remote_origin_url_masked"] = mask(url)
    entry["remote_is_local_object_store"] = bool(url) and not re.search(r"github\.com", url)
    entry["matches_teacher_repo"] = (url == C.TEACHER_REMOTE or
                                     url.endswith("Water-Quality-Risk-Control-Engineering/"
                                                  "depending.git"))
    rc_d, out_d, _ = git(["status", "--porcelain"], cand,
                         note="§5.2 candidate worktree dirtiness (informational)")
    entry["candidate_worktree_dirty_records"] = len(out_d.splitlines())
    entry["read_only_use"] = ("only git object reads and `git clone --no-hardlinks` from it; "
                              "no fetch/pull/reset/clean/stash/commit was ever run here")
    fallback_audit.append(entry)
    if local_source is None and entry["cat_file_base_commit"] == "PASS" and \
            entry["tree_matches"] and entry["matches_teacher_repo"]:
        local_source = cand

source = remote_source or local_source
source_kind = "remote_fresh_clone" if remote_source else (
    "local_read_only_object_store" if local_source else "UNAVAILABLE")
if source is None:
    say("BLOCKED_TEACHER_BASE_UNAVAILABLE")
    (C.RETURN_DIR / "TEACHER_BASE_ACQUISITION.json").write_text(json.dumps(
        {"network_attempts": net_attempts, "local_candidates": fallback_audit,
         "verdict": "BLOCKED_TEACHER_BASE_UNAVAILABLE"}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    sys.exit(3)

if C.STAGED_REPO.exists():
    say("STAGED_REPO already exists: %s (refusing to reuse or wipe)" % C.STAGED_REPO)
    problems.append("STAGED_REPO pre-exists")
else:
    rc, out, err = C.run(["git", "clone", "--no-hardlinks", "--origin", "teacher",
                          str(source), str(C.STAGED_REPO)],
                         note="§5.2 brand-new staged repo via git clone --no-hardlinks")
    if rc != 0:
        problems.append("clone --no-hardlinks failed: %s" % mask(err)[-300:])
say("acquisition source=%s kind=%s" % (source, source_kind))

head_ok = tree_ok = clean_ok = False
if C.STAGED_REPO.is_dir():
    rc, out, _ = git(["checkout", "--detach", C.BASE_COMMIT], C.STAGED_REPO,
                     note="§5.2 checkout --detach exact BASE_COMMIT")
    say("checkout rc=%s" % rc)
    if rc != 0:
        problems.append("detach checkout failed")
    _, out_h, _ = git(["rev-parse", "HEAD"], C.STAGED_REPO, note="§5.2 staged HEAD")
    _, out_t, _ = git(["rev-parse", "HEAD^{tree}"], C.STAGED_REPO, note="§5.2 staged tree")
    _, out_c, _ = git(["status", "--porcelain"], C.STAGED_REPO, note="§5.2 staged clean?")
    head_ok = out_h.strip() == C.BASE_COMMIT
    tree_ok = out_t.strip() == C.BASE_TREE
    clean_ok = out_c.strip() == ""
    _, out_r, _ = git(["config", "--get", "remote.teacher.url"], C.STAGED_REPO,
                      note="§5.2 staged remote url")
    _, out_n, _ = git(["ls-files"], C.STAGED_REPO, note="§5.2 tracked file count")
    say("HEAD=%s tree=%s clean=%s files=%d remote=%s"
        % (out_h.strip()[:12], out_t.strip()[:12], clean_ok,
           len([x for x in out_n.splitlines() if x.strip()]), mask(out_r)))
    for flag, name in ((head_ok, "HEAD"), (tree_ok, "tree"), (clean_ok, "clean worktree")):
        if not flag:
            problems.append("staged repo %s verification failed" % name)

(C.RETURN_DIR / "TEACHER_BASE_ACQUISITION.json").write_text(json.dumps(
    {"task_id": C.TASK_ID, "generated_utc": C.now_utc(),
     "teacher_remote": mask(C.TEACHER_REMOTE), "base_commit": C.BASE_COMMIT,
     "base_tree": C.BASE_TREE, "network_attempts": net_attempts,
     "local_object_store_audit": fallback_audit,
     "acquisition_source": str(source), "acquisition_source_kind": source_kind,
     "staged_repo": str(C.STAGED_REPO),
     "staged_repo_created_here": C.STAGED_REPO.is_dir(),
     "head_ok": head_ok, "tree_ok": tree_ok, "worktree_clean_ok": clean_ok,
     "no_history_mutation_on_existing_repos": (
         "candidate repos were only read (cat-file/rev-parse/status/config) and cloned from "
         "with --no-hardlinks; no fetch/pull/reset/clean/stash/commit anywhere"),
     "verdict": "PASS" if not problems else "FAIL", "problems": problems},
    ensure_ascii=False, indent=2), encoding="utf-8")
if problems:
    say("E1_2_VERDICT=FAIL problems=%s" % json.dumps(problems))
    print("FIRST_FAILING_GATE=BLOCKED_TEACHER_BASE_UNAVAILABLE")
    sys.exit(3)

# ---------------------------------------------------------------- §5.3 patch gate
say("=== §5.3 frozen patch application and teacher topology gate ===")
patch_text = PATCH.read_text(encoding="utf-8", errors="replace")
touched = re.findall(r"^diff --git a/(\S+) b/(\S+)", patch_text, re.MULTILINE)
touched_files = sorted({b for _, b in touched})
say("patch touches %d files" % len(touched_files))
topo_overlap = [f for f in C.TOPOLOGY_FILES if f in touched_files]
say("topology overlap: %s" % (topo_overlap or "none"))
if topo_overlap:
    problems.append("frozen patch touches teacher topology files: %s" % topo_overlap)

rc_chk, out_chk, err_chk = git(["apply", "--check", "--binary", str(PATCH)], C.STAGED_REPO,
                               note="§5.3 git apply --check frozen SOURCE_PATCH.diff")
say("apply --check rc=%s %s" % (rc_chk, err_chk.strip()[-300:]))
if rc_chk != 0:
    problems.append("git apply --check failed for the frozen patch")
rc_ap, out_ap, err_ap = git(["apply", "--binary", str(PATCH)], C.STAGED_REPO,
                            note="§5.3 git apply frozen SOURCE_PATCH.diff")
say("apply rc=%s %s" % (rc_ap, err_ap.strip()[-300:]))
if rc_ap != 0:
    problems.append("git apply failed for the frozen patch")

_, out_after, _ = git(["status", "--porcelain"], C.STAGED_REPO, note="§5.3 post-apply status")
applied_records = [x for x in out_after.splitlines() if x.strip()]
_, names_now, _ = git(["diff", "--name-only", C.BASE_COMMIT], C.STAGED_REPO,
                      note="§5.3 changed names (tracked diff)")
_, names_cached, _ = git(["ls-files", "--others", "--exclude-standard"], C.STAGED_REPO,
                         note="§5.3 untracked files created by the patch")
untracked_new = [x for x in names_cached.splitlines() if x.strip()]
changed_now = sorted(set([x for x in names_now.splitlines() if x.strip()]) |
                     set(untracked_new))
first_round_changed = []
fr_csv = PKG / "CHANGED_FILES.csv"
if fr_csv.is_file():
    for line in fr_csv.read_text(encoding="utf-8").splitlines()[1:]:
        if line.strip():
            first_round_changed.append(line.split(",")[0].strip())
first_round_changed = sorted(set(first_round_changed))
same_set = changed_now == first_round_changed
say("changed set r1=%d first-round=%d identical=%s"
    % (len(changed_now), len(first_round_changed), same_set))
if not same_set:
    only_r1 = [x for x in changed_now if x not in first_round_changed]
    only_fr = [x for x in first_round_changed if x not in changed_now]
    say("only in r1=%s ; only in first round=%s" % (only_r1, only_fr))
    if only_fr:
        problems.append("first-round changed-set entries missing in r1: %s" % only_fr)
    if only_r1:
        problems.append("r1 changed-set entries not in the first round: %s" % only_r1)

# regenerated cumulative patch (intent-to-add so new files are included, nothing committed)
git(["add", "--all", "--intent-to-add"], C.STAGED_REPO,
    note="§5.3 intent-to-add so `git diff` covers patch-created files")
rc_d, diff_out, diff_err = git(["diff", "--binary", C.BASE_COMMIT], C.STAGED_REPO,
                               note="§5.3 regenerate cumulative patch from BASE_COMMIT")
regen = C.WORK_ROOT / "tmp" / "SOURCE_PATCH_R1_REGENERATED.diff"
regen.write_text(diff_out, encoding="utf-8")
regen_sha = hashlib.sha256(diff_out.encode()).hexdigest()
identical_bytes = regen_sha == C.SOURCE_PATCH_SHA
say("regenerated cumulative patch bytes=%d sha=%s equal_to_frozen=%s"
    % (len(diff_out.encode()), regen_sha[:16], identical_bytes))

# per-file final identity fallback (the prompt's "或" branch): compare against the
# first-round staged tree, which is the audited reference
fr_tree = C.FAILED_R3_WS / "depending_teacher_fixed_final"
per_file = []
per_file_all_ok = True
for rel in changed_now:
    mine = C.STAGED_REPO / rel
    theirs = fr_tree / rel
    m = ("ABSENT" if not mine.is_file() else
         (mine.stat().st_size, hashlib.sha256(mine.read_bytes()).hexdigest()))
    t = ("ABSENT" if not theirs.is_file() else
         (theirs.stat().st_size, hashlib.sha256(theirs.read_bytes()).hexdigest()))
    ok = isinstance(m, tuple) and m == t
    per_file_all_ok &= ok
    per_file.append({"path": rel, "r1_bytes": m[0] if ok or isinstance(m, tuple) else m,
                     "r1_sha256": m[1] if isinstance(m, tuple) else "",
                     "first_round_bytes": t[0] if isinstance(t, tuple) else t,
                     "first_round_sha256": t[1] if isinstance(t, tuple) else "",
                     "verdict": "IDENTICAL" if ok else "DIFFERS"})
diff_files = [r["path"] for r in per_file if r["verdict"] != "IDENTICAL"]
say("per-file final SHA vs audited first-round tree: %d/%d identical, differing=%s"
    % (len(per_file) - len(diff_files), len(per_file), diff_files[:10]))
if not identical_bytes and not per_file_all_ok:
    problems.append("neither the regenerated cumulative patch nor the per-file final SHAs "
                    "match the frozen identity")
if diff_files:
    problems.append("final file bytes differ from the audited first-round tree: %s"
                    % diff_files[:5])

# ---------------------------------------------------------------- topology byte gate
topo = {}
for rel in C.TOPOLOGY_FILES:
    rc_b, blob_b, err_b = git(["cat-file", "-e", "%s:%s" % (C.BASE_COMMIT, rel)],
                              C.STAGED_REPO, note="§5.3 base has topology file %s" % rel)
    _, blob_sha_b, _ = git(["rev-parse", "%s:%s" % (C.BASE_COMMIT, rel)], C.STAGED_REPO,
                           note="§5.3 base blob oid %s" % rel)
    p = C.STAGED_REPO / rel
    disk = p.is_file() and not p.is_symlink()
    disk_sha = hashlib.sha256(p.read_bytes()).hexdigest() if disk else ""
    disk_bytes = p.stat().st_size if disk else None
    _, base_text, _ = git(["show", "%s:%s" % (C.BASE_COMMIT, rel)], C.STAGED_REPO,
                          note="§5.3 base bytes of %s" % rel)
    base_sha = hashlib.sha256(base_text.encode()).hexdigest() if rc_b == 0 else ""
    fr_p = fr_tree / rel
    fr_sha = (hashlib.sha256(fr_p.read_bytes()).hexdigest()
              if fr_p.is_file() else "ABSENT")
    ok = bool(disk) and bool(base_sha) and disk_sha == base_sha
    topo[rel] = {"base_blob_sha1": blob_sha_b.strip(), "base_sha256": base_sha,
                 "staged_sha256": disk_sha, "staged_bytes": disk_bytes,
                 "first_round_sha256": fr_sha,
                 "regular_non_symlink": bool(disk),
                 "verdict": "BYTE_IDENTICAL_TO_BASE_COMMIT" if ok else "MODIFIED"}
    say("topology %-42s %s" % (rel, topo[rel]["verdict"]))
    if not ok:
        problems.append("teacher topology file modified: %s" % rel)

# node / edge order of the teacher graph, read out of the byte-identical source
graph_src = (C.STAGED_REPO / "src/graph.py").read_text(encoding="utf-8") \
    if (C.STAGED_REPO / "src/graph.py").is_file() else ""
node_order = re.findall(r"workflow\.add_node\(\s*\"([^\"]+)\"", graph_src)
edge_order = re.findall(r"workflow\.add_edge\(\s*\"([^\"]+)\"\s*,\s*\"([^\"]+)\"", graph_src)
cond_order = re.findall(r"workflow\.add_conditional_edges\(\s*\"([^\"]+)\"", graph_src)
fr_graph = (fr_tree / "src/graph.py")
fr_graph_src = fr_graph.read_text(encoding="utf-8") if fr_graph.is_file() else ""
order_same = (node_order == re.findall(r"workflow\.add_node\(\s*\"([^\"]+)\"", fr_graph_src)
              and edge_order == re.findall(
                  r"workflow\.add_edge\(\s*\"([^\"]+)\"\s*,\s*\"([^\"]+)\"", fr_graph_src)
              and cond_order == re.findall(
                  r"workflow\.add_conditional_edges\(\s*\"([^\"]+)\"", fr_graph_src))
say("teacher order nodes=%d edges=%d conditional=%d same_as_audited_first_round=%s"
    % (len(node_order), len(edge_order), len(cond_order), order_same))
if not order_same:
    problems.append("teacher node/edge order differs from the audited first-round tree")

state_src = (C.STAGED_REPO / "src/state.py")
state_text = state_src.read_text(encoding="utf-8") if state_src.is_file() else ""
base_state = git(["show", "%s:src/state.py" % C.BASE_COMMIT], C.STAGED_REPO,
                 note="§5.3 base src/state.py")[1]
new_public_keys = sorted(set(re.findall(r"^\s{4}([a-z_][a-z0-9_]*)\s*:", state_text,
                                        re.MULTILINE)) -
                         set(re.findall(r"^\s{4}([a-z_][a-z0-9_]*)\s*:", base_state,
                                        re.MULTILINE)))
say("state.py identical to base=%s ; candidate new public keys=%s"
    % (state_text == base_state, new_public_keys or "none"))
if new_public_keys:
    problems.append("BLOCKED_PUBLIC_STATE_CONTRACT :: %s" % new_public_keys)

verdict = "PASS" if not problems else "FAIL"
rows = ["path,scope,r1_bytes,r1_sha256,first_round_sha256,verdict"]
for r in per_file:
    rows.append("%s,cumulative_preR3_plus_T2_T5_integration,%s,%s,%s,%s"
                % (r["path"], r["r1_bytes"], r["r1_sha256"], r["first_round_sha256"],
                   r["verdict"]))
(C.RETURN_DIR / "CHANGED_FILES_R1.csv").write_text("\n".join(rows) + "\n", encoding="utf-8")
(C.RETURN_DIR / "TEACHER_FIXED_TOPOLOGY_IDENTITY.json").write_text(json.dumps(
    {"task_id": C.TASK_ID, "generated_utc": C.now_utc(),
     "base_commit": C.BASE_COMMIT, "base_tree": C.BASE_TREE,
     "staged_repo": str(C.STAGED_REPO),
     "topology_files": topo,
     "teacher_node_order": node_order, "teacher_edge_order": [list(e) for e in edge_order],
     "teacher_conditional_edges": cond_order,
     "order_matches_audited_first_round": order_same,
     "state_py_identical_to_base": state_text == base_state,
     "new_public_state_keys": new_public_keys,
     "patch_touched_files": touched_files,
     "patch_touches_topology_files": topo_overlap,
     "frozen_patch": {"path": str(PATCH), "bytes": PATCH.stat().st_size,
                      "sha256": hashlib.sha256(PATCH.read_bytes()).hexdigest(),
                      "expected_sha256": C.SOURCE_PATCH_SHA,
                      "verdict": "VERIFIED_MATCH" if
                      hashlib.sha256(PATCH.read_bytes()).hexdigest() == C.SOURCE_PATCH_SHA
                      else "MISMATCH"},
     "incremental_patch": {"path": str(INC_PATCH),
                           "bytes": INC_PATCH.stat().st_size,
                           "sha256": hashlib.sha256(INC_PATCH.read_bytes()).hexdigest(),
                           "expected_sha256": C.T6_INCREMENTAL_SHA},
     "apply_check_rc": rc_chk, "apply_rc": rc_ap,
     "apply_stdout": out_ap.strip(), "apply_stderr": err_ap.strip(),
     "post_apply_status_records": len(applied_records),
     "regenerated_cumulative_patch": {"path": str(regen),
                                      "bytes": len(diff_out.encode()),
                                      "sha256": regen_sha,
                                      "byte_equal_to_frozen": identical_bytes,
                                      "per_file_final_identical": per_file_all_ok},
     "changed_set_count": len(changed_now),
     "changed_set_matches_first_round": same_set,
     "verdict": verdict, "problems": problems},
    ensure_ascii=False, indent=2), encoding="utf-8")
(C.RETURN_DIR / "SOURCE_AND_TOPOLOGY_GATE_STDOUT.txt").write_text("\n".join(LINES) + "\n",
                                                                  encoding="utf-8")
say("E1_3_VERDICT=%s problems=%s" % (verdict, json.dumps(problems, ensure_ascii=False)))
print("SOURCE_AND_TOPOLOGY=%s" % verdict)
if verdict == "FAIL":
    print("FIRST_FAILING_GATE=BLOCKED_SOURCE_OR_TEACHER_TOPOLOGY_IDENTITY")
    sys.exit(3)
