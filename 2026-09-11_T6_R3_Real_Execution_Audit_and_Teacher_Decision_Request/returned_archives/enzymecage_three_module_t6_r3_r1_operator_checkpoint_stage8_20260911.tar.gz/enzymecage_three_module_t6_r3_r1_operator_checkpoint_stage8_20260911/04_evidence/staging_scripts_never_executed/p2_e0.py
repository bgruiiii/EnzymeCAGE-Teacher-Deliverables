# -*- coding: utf-8 -*-
"""Phase E0 (§4.1/§4.2): pinned-interpreter and import hard gate, before any asset or model init.

Produces exactly the four required artifacts:
  PYTHON_RUNTIME_PREFLIGHT.json
  PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv
  ENTRYPOINT_IMPORT_IDENTITIES.csv
  ENVIRONMENT_PREFLIGHT_STDOUT.txt

Operator correction of 2026-09-10 (recorded in the output, not silently applied):
xgboost is gated as the real gradient-boosting dependency; lightgbm keeps its real
traceback and needs a zero-reference audit, and is never reported as PASS.
"""
import importlib
import importlib.util
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import r1_common as C                                            # noqa: E402

ALLOWED_PATH_ADDITIONS = [C.CODE_ROOT, str(C.D4_WRAPPER_DIR.parent)]
for p in ALLOWED_PATH_ADDITIONS:
    if p not in sys.path:
        sys.path.insert(0, p)

OUT_LINES = []


def say(msg):
    OUT_LINES.append(msg)
    print(msg)


C.emit_interp()
say("PHASE=E0 pinned interpreter probe")
say("UTC=" + C.now_utc())

interp = C.interp_identity()
say("sys.executable=%s realpath=%s prefix=%s base_prefix=%s version=%s"
    % (interp["sys_executable"], interp["realpath"], interp["prefix"],
       interp["base_prefix"], interp["version"]))

problems = []
gate = {}

# ---------------------------------------------------------------- interpreter gate
if not Path(C.PY).is_file() or not os.access(C.PY, os.X_OK):
    print("BLOCKED_ENVIRONMENT_INTERPRETER_MISSING")
    sys.exit(3)
if interp["sys_executable"] != C.PY:
    problems.append("this probe is not running under the pinned interpreter")
say("argv0_must_be_absolute_pinned_path=true (launched as %s -B %s)" % (C.PY, __file__))
say("interpreter_realpath_note=${PY} is a venv whose bin/python symlink resolves to %s; "
    "launching that realpath directly would lose sys.prefix=%s and its site-packages, so the "
    "only valid launch form is the absolute venv path itself"
    % (interp["realpath"], interp["prefix"]))

# ---------------------------------------------------------------- module matrix
rows = []
import_results = {}
for name in C.PROBE_MODULES:
    try:
        mod = importlib.import_module(name)
        version = getattr(mod, "__version__", None)
        if version is None:
            try:
                import importlib.metadata as md
                version = md.version(name)
            except Exception:
                version = "unknown"
        mfile = getattr(mod, "__file__", None)
        import_results[name] = {"ok": True, "version": version, "file": mfile}
        say("import %-16s OK      version=%-12s file=%s" % (name, str(version), mfile))
    except BaseException as exc:                                     # noqa: B036
        import_results[name] = {"ok": False, "error_type": type(exc).__name__,
                                "error": str(exc),
                                "traceback": subprocess.run(
                                    [C.PY, "-B", "-c", "import %s" % name],
                                    capture_output=True,
                                    env=C.base_env()).stderr.decode("utf-8", "replace")}
        say("import %-16s FAIL    %s: %s" % (name, type(exc).__name__, exc))

# langgraph.graph.StateGraph is checked as a symbol, not just the package
try:
    from langgraph.graph import StateGraph as _SG
    lg_stategraph = {"ok": True, "qualname": "%s.%s" % (_SG.__module__, _SG.__qualname__),
                     "module_file": sys.modules[_SG.__module__].__file__}
except BaseException as exc:                                         # noqa: B036
    lg_stategraph = {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
say("langgraph.graph.StateGraph -> %s" % json.dumps(lg_stategraph))

for name in C.HARD_GATE_MODULES:
    if not import_results.get(name, {}).get("ok"):
        problems.append("HARD_GATE import failure: %s" % name)
        gate["BLOCKED_ENVIRONMENT_PREFLIGHT_%s" % name.upper()] = True
if not lg_stategraph["ok"]:
    problems.append("HARD_GATE import failure: langgraph.graph.StateGraph")
if import_results.get("ase", {}).get("ok"):
    gate["ASE_IMPORT"] = "PASS"

# ---------------------------------------------------------------- entrypoint identities
entry_rows = []
entry_points = [
    ("enzymecage", "code root package", None),
    ("enzymecage.model", "EnzymeCAGE model module", None),
    ("enzymecage.schnet", "EnzymeCAGE schnet module (needs ase)", None),
    ("enzymecage_wrapper.predictor", "frozen D4 wrapper predictor", None),
    ("enzymecage_wrapper.schema", "frozen D4 wrapper schema", None),
    ("enzymecage_wrapper.utils", "frozen D4 wrapper utils", None),
    ("langgraph.graph", "StateGraph provider", None),
]
for mod_name, role, _ in entry_points:
    try:
        mod = importlib.import_module(mod_name)
        f = getattr(mod, "__file__", None)
        sha = C.sha256_file(f) if f and Path(f).is_file() else ""
        status = "IMPORTED"
    except BaseException as exc:                                     # noqa: B036
        f, sha, status = "", "", "IMPORT_FAIL %s: %s" % (type(exc).__name__, exc)
        if mod_name.startswith(("enzymecage", "enzymecage_wrapper")):
            problems.append("HARD_GATE entrypoint failure: %s (%s)" % (mod_name, status))
    entry_rows.append({"module": mod_name, "role": role, "module_file": f or "",
                       "file_sha256": sha, "version": getattr(
                           sys.modules.get(mod_name), "__version__", "") or "",
                       "status": status,
                       "under_expected_root": bool(
                           f and (f.startswith(C.CODE_ROOT) or
                                  str(C.D4_WRAPPER_DIR).startswith(str(f))) or
                           (f and str(C.D4_WRAPPER_DIR.parent) in f))})
    say("entrypoint %-28s %-12s %s" % (mod_name, status, f))

# wrapper directory and the three source identities
wrapper_dir_ok = C.D4_WRAPPER_DIR.is_dir()
if not wrapper_dir_ok:
    problems.append("D4 wrapper package directory absent: %s" % C.D4_WRAPPER_DIR)
wrapper_identity = {}
for fname, (exp_b, exp_s) in sorted(C.WRAPPER_FILES.items()):
    p = C.D4_WRAPPER_DIR / fname
    b = p.stat().st_size if p.is_file() else None
    s = C.sha256_file(p) if p.is_file() else ""
    ok = b == exp_b and s == exp_s
    wrapper_identity[fname] = {"path": str(p), "expected_bytes": exp_b, "observed_bytes": b,
                               "expected_sha256": exp_s, "observed_sha256": s,
                               "verdict": "VERIFIED_MATCH" if ok else "MISMATCH"}
    if not ok:
        problems.append("wrapper source identity mismatch: %s" % fname)
    say("wrapper %-14s bytes=%s sha=%s %s" % (fname, b, s[:16],
                                              "VERIFIED_MATCH" if ok else "MISMATCH"))

# exposed API surface, without constructing a runtime (no initialize_runtime call here)
api = {}
try:
    import enzymecage_wrapper.predictor as pred
    import enzymecage_wrapper.schema as schema
    api["initialize_runtime_present"] = callable(getattr(pred, "initialize_runtime", None))
    api["request_class_present"] = getattr(schema, "EnzymeCAGERequest", None) is not None
    api["runtime_initialized_in_E0"] = False
    api["model_version_constant"] = getattr(pred, "MODEL_VERSION",
                                            getattr(schema, "MODEL_VERSION", "")) or ""
except BaseException as exc:                                         # noqa: B036
    api["error"] = "%s: %s" % (type(exc).__name__, exc)
    problems.append("wrapper API surface: " + api["error"])
if not api.get("initialize_runtime_present"):
    problems.append("enzymecage_wrapper.predictor.initialize_runtime missing")
if not api.get("request_class_present"):
    problems.append("enzymecage_wrapper.schema.EnzymeCAGERequest missing")
say("wrapper API %s" % json.dumps(api))

# ---------------------------------------------------------------- CUDA / GPU identity
cuda = {}
rc, out, err = C.run_py(["-B", "-c",
                         "import torch,json;"
                         "print(json.dumps({'available':torch.cuda.is_available(),"
                         "'count':torch.cuda.device_count(),"
                         "'names':[torch.cuda.get_device_name(i) for i in "
                         "range(torch.cuda.device_count())],"
                         "'memory':[torch.cuda.get_device_properties(i).total_memory for i "
                         "in range(torch.cuda.device_count())]}))"],
                        env={"CUDA_VISIBLE_DEVICES": "0,1,2"}, note="E0 cuda probe",
                        label="e0_cuda_probe")
say("cuda probe rc=%s out=%s err=%s" % (rc, out.strip()[:400], err.strip()[-200:]))
try:
    cuda = json.loads(out.strip().splitlines()[-1])
except Exception:
    cuda = {"available": False, "count": 0, "parse_error": out[-200:] + err[-200:]}
rc2, smi, err2 = C.run(["nvidia-smi", "--query-gpu=index,uuid,name,memory.total,memory.used",
                        "--format=csv,noheader"], note="E0 gpu uuid table")
gpu_rows = []
for line in smi.strip().splitlines():
    parts = [x.strip() for x in line.split(",")]
    if len(parts) >= 3:
        gpu_rows.append({"index": parts[0], "uuid": parts[1], "name": parts[2],
                         "memory_total_mib": parts[3] if len(parts) > 3 else "",
                         "memory_used_mib": parts[4] if len(parts) > 4 else ""})
uuid_map = {r["index"]: r["uuid"] for r in gpu_rows}
uuid_check = {}
for idx, (frozen_uuid, reaction) in sorted(C.GPU_ASSIGNMENT.items()):
    got = uuid_map.get(str(idx), "")
    ok = got == frozen_uuid
    uuid_check["GPU%d" % idx] = {"frozen_uuid": frozen_uuid, "observed_uuid": got,
                                 "reaction": reaction, "verdict": "MATCH" if ok else "MISMATCH",
                                 "name": next((r["name"] for r in gpu_rows
                                               if r["index"] == str(idx)), "")}
    if not ok:
        problems.append("GPU%d uuid mismatch: observed %s" % (idx, got))
say("gpu uuids %s" % json.dumps(uuid_check))
if not cuda.get("available") or cuda.get("count", 0) < 3:
    problems.append("CUDA not available or fewer than 3 devices: %s" % json.dumps(cuda))

# ---------------------------------------------------------------- single-card isolation probe
iso = {}
for idx, (frozen_uuid, _) in sorted(C.GPU_ASSIGNMENT.items()):
    rc3, out3, err3 = C.run_py(["-B", "-c",
                                "import torch;"
                                "print(torch.cuda.device_count(), torch.cuda.get_device_name(0))"],
                               env={"CUDA_VISIBLE_DEVICES": str(idx)},
                               note="E0 single-card isolation probe GPU%d" % idx,
                               label="e0_isolation_gpu%d" % idx)
    iso["GPU%d" % idx] = {"rc": rc3, "observed": out3.strip(), "stderr_tail": err3.strip()[-160:]}
    if rc3 != 0 or not out3.strip().startswith("1 "):
        problems.append("single-card isolation failed for GPU%d: %s" % (idx, out3.strip()))
say("single-card isolation %s" % json.dumps(iso))

# ---------------------------------------------------------------- pytest / info only
pytest_present = importlib.util.find_spec("pytest") is not None
say("pytest_present=%s (informational only; unittest/self-runner is the sanctioned form)"
    % pytest_present)

# ---------------------------------------------------------------- lightgbm adjudication pass 1
lgb = import_results.get("lightgbm", {})
ref_audit_pass1 = {}
SOURCES_PASS1 = {
    "enzyme_cage_code_root": [C.CODE_ROOT + "/enzymecage", C.CODE_ROOT + "/config",
                              C.CODE_ROOT + "/dataset", C.CODE_ROOT + "/feature"],
    "d4_wrapper_dir": [str(C.D4_WRAPPER_DIR)],
}


def count_refs(roots, needle="lightgbm"):
    n, hits = 0, []
    for root in roots:
        rp = Path(root)
        if not rp.exists():
            continue
        walker = rp.rglob("*") if rp.is_dir() else [rp]
        for p in walker:
            if not p.is_file() or "__pycache__" in p.parts or p.suffix in (".pyc", ".so"):
                continue
            try:
                if p.stat().st_size > 4 << 20:
                    continue
            except OSError:
                continue
            try:
                text = p.read_text("utf-8", "replace")
            except Exception:
                continue
            if needle in text.lower():
                n += 1
                hits.append(str(p))
    return n, hits[:10]


for label, roots in SOURCES_PASS1.items():
    n, hits = count_refs(roots)
    ref_audit_pass1[label] = {"reference_count": n, "sample_paths": hits}
say("lightgbm reference audit pass 1 %s" % json.dumps(ref_audit_pass1))

xgb = import_results.get("xgboost", {})
say("xgboost (the gradient-boosting library the v3.2 runtime actually loads) "
    "version=%s file=%s" % (xgb.get("version"), xgb.get("file")))

# ---------------------------------------------------------------- write the four artifacts
preflight = {
    "task_id": C.TASK_ID,
    "generated_utc": C.now_utc(),
    "phase": "E0 (before any asset read or model init)",
    "pinned_interpreter": {
        "PY": C.PY,
        "exists": Path(C.PY).is_file(), "executable": os.access(C.PY, os.X_OK),
        "sys_executable": interp["sys_executable"], "realpath": interp["realpath"],
        "sys_prefix": interp["prefix"], "sys_base_prefix": interp["base_prefix"],
        "python_version": interp["version"],
        "equals_pinned_py": interp["equals_pinned_py"],
        "venv_prefix_ok": interp["venv_prefix_ok"],
        "realpath_note": ("bin/python is the venv symlink into %s; launching the realpath "
                          "directly would drop the venv prefix and its site-packages, so every "
                          "command uses the absolute venv path" % interp["realpath"]),
    },
    "launch_policy": {
        "all_python_commands_use_absolute_pinned_py": True,
        "forbidden_forms": ["python", "python3", "/usr/bin/python", "/usr/bin/python3"],
        "pythondontwritebytecode": "1",
        "cache_and_temp": {"TMPDIR": str(C.TMPS), "XDG_CACHE_HOME": str(C.CACHE),
                           "MPLCONFIGDIR": str(C.CACHE / "mpl"),
                           "NUMBA_CACHE_DIR": str(C.CACHE / "numba"),
                           "TORCH_HOME": str(C.CACHE / "torch")},
        "allowed_sys_path_additions": ALLOWED_PATH_ADDITIONS,
        "audit_file": "PYTHON_COMMAND_AUDIT.csv",
    },
    "host": {"platform": platform.platform(), "node": platform.node()},
    "modules": import_results,
    "langgraph_stategraph": lg_stategraph,
    "hard_gate_modules": C.HARD_GATE_MODULES,
    "entrypoints": entry_rows,
    "wrapper": {"directory": str(C.D4_WRAPPER_DIR), "directory_exists": wrapper_dir_ok,
                "files": wrapper_identity, "api": api,
                "runtime_constructor": "enzymecage_wrapper.predictor.initialize_runtime(v1_overlay)",
                "request_class": "enzymecage_wrapper.schema.EnzymeCAGERequest",
                "model_call": "runtime.predict(request)",
                "model_version_expected": C.MODEL_VERSION,
                "initialize_runtime_called_in_E0": False,
                "checkpoint_loaded_in_E0": False,
                "large_asset_read_in_E0": False},
    "cuda": cuda,
    "gpu_table": gpu_rows,
    "gpu_uuid_frozen_vs_observed": uuid_check,
    "single_card_isolation_probe": iso,
    "pytest_informational": {"present": pytest_present,
                             "blocking_if_absent": False,
                             "sanctioned_runner": "unittest / task self-runner"},
    "operator_correction_lightgbm": {
        "recorded_by": "operator (local audit) 2026-09-10, forwarded as authority input",
        "status_keys": {"LIGHTGBM_IMPORT": "NOT_IMPORTABLE_UNREQUIRED" if not lgb.get("ok")
                        else "IMPORTABLE",
                        "LIGHTGBM_REFERENCE_COUNT": "see LIGHTGBM_REFERENCE_AUDIT.json "
                                                    "(final count is taken on the fresh tree)",
                        "LIGHTGBM_GATE": "NOT_APPLICABLE"},
        "reason": ("lightgbm is not a teacher-contract requirement and not a dependency of "
                   "this chain; the entry was an error in the prompt's module list"),
        "real_import_traceback": lgb.get("traceback", ""),
        "never_reported_as_pass": True,
        "xgboost_is_the_gated_real_dependency": True,
        "reference_audit_pass1": ref_audit_pass1,
        "escalation_rule": ("if any real lightgbm reference is found that this interpreter "
                            "cannot import, block immediately"),
    },
    "gate_verdicts": gate,
    "problems": problems,
    "verdict": "PASS" if not problems else "BLOCKED",
}
(C.RETURN_DIR / "PYTHON_RUNTIME_PREFLIGHT.json").write_text(
    json.dumps(preflight, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

with open(str(C.RETURN_DIR / "PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv"), "w", encoding="utf-8") as fh:
    fh.write("module,purpose,import_ok,version,module_file,hard_gate,"
             "blocked_if_import_fails,note\n")
    purpose = {"ase": "EnzymeCAGE geometry (root cause of the blocked first round)",
               "torch": "model compute", "torch_geometric": "native dataset loader",
               "rdkit": "reaction SMILES chemistry", "numpy": "array math",
               "pandas": "table IO", "yaml": "frozen run config",
               "pydantic": "public objects", "langgraph": "teacher StateGraph",
               "jsonschema": "official G-SCHEMA Draft202012 validator",
               "sklearn": "metric utilities", "joblib": "artifact IO",
               "scipy": "numeric support", "xgboost": "v3.2 runtime gradient booster",
               "lightgbm": "listed in the prompt module list; audited for real references"}
    for name in C.PROBE_MODULES:
        r = import_results[name]
        hg = name not in C.NOT_APPLICABLE_MODULES
        note = ""
        if name == "lightgbm":
            note = ("NOT_IMPORTABLE_UNREQUIRED (operator correction); real traceback kept in "
                    "PYTHON_RUNTIME_PREFLIGHT.json; never claimed as PASS")
        if name == "xgboost":
            note = "gated as the real gradient-boosting dependency used by the v3.2 adapter"
        fh.write("%s,%s,%s,%s,%s,%s,%s,%s\n" % (
            name, purpose.get(name, ""), "true" if r.get("ok") else "false",
            str(r.get("version", r.get("error", ""))).replace(",", ";"),
            str(r.get("file", "")).replace(",", ";"), "true" if hg else "false",
            "true" if hg else "false", note.replace(",", ";")))
    fh.write("langgraph.graph.StateGraph,teacher graph builder dependency,%s,%s,%s,true,true,\n"
             % ("true" if lg_stategraph["ok"] else "false",
                str(lg_stategraph.get("qualname", "")).replace(",", ";"),
                str(lg_stategraph.get("module_file", "")).replace(",", ";")))

with open(str(C.RETURN_DIR / "ENTRYPOINT_IMPORT_IDENTITIES.csv"), "w", encoding="utf-8") as fh:
    fh.write("module,role,module_file,file_sha256,version,status,under_expected_root\n")
    for r in entry_rows:
        fh.write(",".join(str(r[k]).replace(",", ";") for k in
                          ("module", "role", "module_file", "file_sha256", "version",
                           "status", "under_expected_root")) + "\n")

(C.RETURN_DIR / "ENVIRONMENT_PREFLIGHT_STDOUT.txt").write_text(
    "\n".join(OUT_LINES) + "\n", encoding="utf-8")

print("E0_PROBLEMS=" + json.dumps(problems))
print("E0_VERDICT=" + ("PASS" if not problems else
                       "BLOCKED_ENVIRONMENT_PREFLIGHT_" +
                       next((p.split(": ")[0].split(" ")[-1] for p in problems), "UNKNOWN")))
_code = 0 if not problems else 1
C.self_audit(__file__, _code, "Phase E0 environment hard gate")
if problems:
    for p in problems:
        if p.startswith("HARD_GATE import failure:"):
            print("BLOCKED_ENVIRONMENT_PREFLIGHT_" + p.split(": ")[-1].upper())
            break
    else:
        print("BLOCKED_ENVIRONMENT_PREFLIGHT_GATE")
sys.exit(_code)
