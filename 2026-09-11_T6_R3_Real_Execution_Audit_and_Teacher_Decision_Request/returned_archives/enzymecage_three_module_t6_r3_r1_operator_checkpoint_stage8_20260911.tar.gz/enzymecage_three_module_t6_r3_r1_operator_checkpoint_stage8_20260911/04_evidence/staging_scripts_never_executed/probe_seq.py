import hashlib
import pickle
import sys
import time

sys.path.insert(0, "/root/projects/EnzymeCAGE-master")
from enzymecage.dataset import sharded_protein as sp  # noqa: E402

GVP = "/usrdata/EnzymeCAGE_data/feature/protein/gvp/gvp_protein_feature_flat.pt"
NODE = ("/usrdata/EnzymeCAGE_data/feature/protein/ESM2_3B_corrected_107705/pocket_node_feature/"
        "esm_node_feature.torch.pt")
MEAN = ("/usrdata/EnzymeCAGE_data/feature/protein/ESM2_3B_corrected_107705/protein_level/"
        "seq2feature.pkl")
UIDS = ["A0A011QK89", "A0A017SP50", "A0A017SR40"]


def describe(v):
    if hasattr(v, "shape"):
        return "tensor%s/%s" % (tuple(v.shape), v.dtype)
    if isinstance(v, (str, bytes)):
        return "%s(len=%d)" % (type(v).__name__, len(v))
    return "%s(%s)" % (type(v).__name__, repr(v)[:40])


t = time.time()
g = sp.load_protein_gvp_data(GVP)
print("gvp type=%s len=%d in %.1fs" % (type(g).__name__, len(g), time.time() - t), flush=True)
t = time.time()
n = sp.load_pocket_node_feature_data(NODE)
print("node type=%s len=%d in %.1fs" % (type(n).__name__, len(n), time.time() - t), flush=True)
t = time.time()
m = pickle.load(open(MEAN, "rb"))
print("esm_mean type=%s len=%d in %.1fs" % (type(m).__name__, len(m), time.time() - t), flush=True)
k0 = next(iter(m))
print("  esm_mean first key %s -> %s" % (describe(k0), describe(m[k0])), flush=True)

for u in UIDS:
    v = g[u]
    print("== %s gvp value type=%s arity=%s" % (u, type(v).__name__, len(v)), flush=True)
    for i, e in enumerate(v):
        print("     [%d] %s" % (i, describe(e)), flush=True)
    seq = v[1]
    s = seq if isinstance(seq, str) else (seq.decode() if isinstance(seq, bytes) else None)
    print("   pocket %s" % describe(n[u]), flush=True)
    if s is None:
        continue
    print("   seqlen=%d head=%r" % (len(s), s[:24]), flush=True)
    print("   sha_utf8  =%s" % hashlib.sha256(s.encode("utf-8")).hexdigest(), flush=True)
    print("   sha_ascii =%s" % hashlib.sha256(s.encode("ascii")).hexdigest(), flush=True)
    print("   in_esm_mean=%s" % (s in m), flush=True)
