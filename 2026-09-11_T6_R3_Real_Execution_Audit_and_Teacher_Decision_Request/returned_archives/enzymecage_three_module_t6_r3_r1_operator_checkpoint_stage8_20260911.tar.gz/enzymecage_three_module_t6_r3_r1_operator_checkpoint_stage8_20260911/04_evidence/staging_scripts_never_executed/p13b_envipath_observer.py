# -*- coding: utf-8 -*-
"""T6-R3-R1 §8 supplementary read-only gate: observability probe.

Question answered by this process: does the teacher's *fixed* LangGraph topology really
implement ``enviPath local known-route lookup -> HIT (database_lookup result, prediction
call count 0) / MISS (recorded lookup miss, then depending v3.2 call count 1) / INVALID
INPUT (both counts 0, fail-closed)``?

This file observes and never modifies.  Concretely:

* the teacher tree is imported read-only from the fresh staged checkout; ``src/graph.py``,
  ``src/state.py``, every node, router and edge is used exactly as the teacher wrote it;
  nothing is monkeypatched, no subclass of ``StateGraph`` is built, no node is called by
  hand to fake the main graph;
* call counting uses ``sys.settrace`` + ``threading.settrace`` (CPython observation API:
  it sees ``call`` events, it cannot change them);
* module/side-effect reachability uses ``sys.addaudithook`` (``import``, ``socket.connect``,
  ``socket.getaddrinfo``, ``http.client.request``, ``urllib.Request``);
* the model import roots (§4.2 ``CODE_ROOT`` / D4 wrapper parent) are deliberately **not**
  added to ``sys.path`` here: this probe stops at ``enzyme_pool`` and adding the code root
  would put its top-level ``config.py`` in front of the teacher ``config`` package.

Exit code 0 means "the observation completed", not "the ordering was established"; the
verdict is computed by the driver from the emitted JSON.
"""
import hashlib
import inspect
import json
import os
import re
import sys
import threading
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

CFG = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
STAGED = CFG["staged"]
OUT = CFG["out_json"]

TEACHER_PREFIX = STAGED + os.sep
OBS_SELF_FILE = os.path.abspath(__file__)
# A comprehension, generator or lambda frame is NOT a function entry: counting those inflated
# "retrieve_similar_reactions" from 1 to 16,974 in the first attempt of this gate.  Only frames
# whose *last* qualname segment is an angle-bracket construct are dropped; named nested helpers
# (``outer.<locals>.inner``) are still counted.
ANGLE_FRAME_RE = re.compile(r"<locals>\.<[^>]+>$")
# a lookup implemented *outside* the teacher tree must still be caught when it runs
RELEVANT_PATH_RE = re.compile(r"(eawag|envipath|depending|single_smiles_v32|reaction_predictor"
                              r"|reaction_retriever|enzyme_pool_builder|chem_name_resolver)")
WATCH_IMPORT_RE = re.compile(
    r"(^|\.)(envipath|eawag|known_route|database_lookup|depending_v32_adapter"
    r"|single_smiles_v32|biotransformer|reaction_predictor|reaction_retriever"
    r"|enzyme_pool_builder|chem_name_resolver|substrate_parser)(\.|$)", re.I)
WATCH_QUAL_RE = re.compile(
    r"(^lookup$|_lookup|lookup_|known_route|database_lookup|retrieve_similar_reactions"
    r"|predict_reactions|build_enzyme_pool|build_pool_route|^load$|parse_substrate"
    r"|resolve_name_to_smiles|split_multistep_route|_retrieval_for)")


def _utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


IMPORT_EVENTS = []
SOCKET_EVENTS = []
IMPORT_TOTAL = [0]
IMPORT_ARG_SHAPE = []


def _import_name(args):
    """CPython hands the ``import`` audit event as ``(module, filename, sys.path-like,
    meta_path-like, path_hooks-like)`` packed together.  Only the *module name* may be matched
    against the watcher: a first attempt stringified the whole tuple, so every import of the
    process matched on the substring ``depending`` contributed by the staged tree inside
    ``sys.path``, and 1,052 unrelated modules were reported.  Match the name, nothing else."""
    head = args[0] if args else ""
    if isinstance(head, tuple):
        head = head[0] if head else ""
    return str(head)


def _audit(event, *args):
    if event == "import":
        IMPORT_TOTAL[0] += 1
        if not IMPORT_ARG_SHAPE:
            IMPORT_ARG_SHAPE.append(repr(args)[:400])
        mod = _import_name(args)
        if WATCH_IMPORT_RE.search(mod):
            IMPORT_EVENTS.append({"utc": _utc(), "module": mod})
    elif event in ("socket.connect", "socket.getaddrinfo", "http.client.request",
                   "urllib.Request"):
        SOCKET_EVENTS.append({"utc": _utc(), "event": event,
                              "args": [repr(a)[:160] for a in args]})


sys.addaudithook(_audit)

CALLS = {}
TIMED = []
CURRENT = ["init"]


def _global_trace(frame, event, arg):
    if event != "call":
        return None
    code = frame.f_code
    fn = code.co_filename
    if fn == OBS_SELF_FILE:
        return None                      # this probe must never observe itself
    if ANGLE_FRAME_RE.search(code.co_qualname):
        return None                      # <listcomp>/<genexpr>/<lambda> is not a call entry
    if not (fn.startswith(TEACHER_PREFIX) or RELEVANT_PATH_RE.search(fn)):
        return None
    mod = frame.f_globals.get("__name__") or "?"
    key = "%s:%s" % (mod, code.co_qualname)
    rec = CALLS.get(key)
    if rec is None:
        rec = {"module": mod, "qualname": code.co_qualname, "file": fn,
               "firstlineno": code.co_firstlineno, "count": 0,
               "under_teacher_tree": fn.startswith(TEACHER_PREFIX)}
        CALLS[key] = rec
    rec["count"] += 1
    if WATCH_QUAL_RE.search(code.co_qualname) and len(TIMED) < 6000:
        TIMED.append({"scenario": CURRENT[0], "utc": _utc(), "t_ns": time.time_ns(),
                      "callable": key, "lineno": code.co_firstlineno})
    return None


def sha256_file(path):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def ident(obj):
    """module:qualname + defining file + that file's SHA256 for a live callable."""
    try:
        fn = inspect.getfile(obj)
    except (TypeError, OSError):
        fn = None
    out = {"module": getattr(obj, "__module__", None),
           "qualname": getattr(obj, "__qualname__", repr(obj)[:60]),
           "file": fn,
           "firstlineno": getattr(getattr(obj, "__code__", None), "co_firstlineno", None),
           "definition_sha256": sha256_file(fn) if fn and os.path.isfile(fn) else None}
    try:
        src = inspect.getsource(obj)
    except (OSError, TypeError):
        src = None
    out["source_lines"] = len(src.splitlines()) if src else None
    out["source_sha256_of_body"] = hashlib.sha256(src.encode()).hexdigest() if src else None
    return out


# ------------------------------------------------------------------ 1. wiring
sys.path.insert(0, STAGED)
for key in ("M3_AGENT_DATA_ASSETS_ROOT", "C8_LOOKUP_ROOT", "C8_UID_SOURCE_MAP_PATH",
            "DEPENDING_V32_RUNTIME_ROOT", "D4_WRAPPER_ROOT", "ENZYMECAGE_CODE_ROOT",
            "ENZYMECAGE_V1_PACKAGE_ROOT", "ENZYMECAGE_DRY_RUN"):
    if CFG["env"].get(key) is not None:
        os.environ[key] = str(CFG["env"][key])
# offline discipline: no LLM credential exists in this round, so any node that reaches an
# LLM must fail closed *immediately* rather than opening a socket.
POP_ENV = [k for k in ("LLM_API_BASE_URL", "LLM_API_KEY", "DASHSCOPE_API_KEY", "OPENAI_API_KEY")
           if os.environ.pop(k, None) is not None]

RESULT = {
    "utc_started": _utc(),
    "interp": {"sys_executable": sys.executable, "argv0": sys.argv[0],
               "version": sys.version.split()[0], "prefix": sys.prefix,
               "is_pinned": sys.executable == CFG["pinned_py"]},
    "sys_path": list(sys.path),
    "env_written_by_probe": {k: os.environ.get(k) for k in CFG["env"]},
    "env_credentials_popped": POP_ENV,
}

# ------------------------------------------------------------------ 2. graph structure
t0 = time.monotonic()
try:
    import src.graph as graph_mod
    RESULT["graph_module_import"] = {"ok": True, "file": graph_mod.__file__,
                                     "sha256": sha256_file(graph_mod.__file__),
                                     "duration_s": round(time.monotonic() - t0, 3)}
except Exception:
    RESULT["graph_module_import"] = {"ok": False, "traceback": traceback.format_exc()}
    Path(OUT).write_text(json.dumps(RESULT, ensure_ascii=False, indent=1), encoding="utf-8")
    print("@@P13RESULT@@ " + json.dumps({"ok": False, "stage": "import_src_graph"}))
    sys.exit(3)

from src.graph import build_graph, compile_graph, route_after_reaction, should_continue  # noqa
from src.state import EnzymeCrewState  # noqa

RESULT["state_contract"] = {
    "class": "%s:%s" % (EnzymeCrewState.__module__, EnzymeCrewState.__qualname__),
    "fields": sorted(EnzymeCrewState.model_fields),
    "reaction_source_annotation": str(
        EnzymeCrewState.model_fields["reaction_source"].annotation),
    "pipeline_mode_annotation": str(EnzymeCrewState.model_fields["pipeline_mode"].annotation),
    "candidate_reaction_source_annotation": None,
}
try:
    from src.schemas.evidence import CandidateReaction, PredictedReaction, SubstrateInfo
    RESULT["state_contract"]["candidate_reaction_source_annotation"] = str(
        CandidateReaction.model_fields["source"].annotation)
    RESULT["state_contract"]["candidate_reaction_source_tag_annotation"] = str(
        CandidateReaction.model_fields["source_tag"].annotation)
    RESULT["state_contract"]["predicted_reaction_source_annotation"] = str(
        PredictedReaction.model_fields["source"].annotation)
    RESULT["state_contract"]["substrate_source_annotation"] = str(
        SubstrateInfo.model_fields["source"].annotation)
    RESULT["state_contract"]["evidence_module_sha256"] = sha256_file(
        Path(STAGED) / "src/schemas/evidence.py")
except Exception:
    RESULT["state_contract"]["evidence_schema_error"] = traceback.format_exc()

workflow = build_graph()
compiled = compile_graph()
RESULT["langgraph"] = {
    "module_file": sys.modules["langgraph"].__file__,
    "stategraph_is_real_langgraph": (type(workflow).__module__ == "langgraph.graph.state"
                                     and type(workflow).__name__ == "StateGraph"),
    "workflow_type": "%s.%s" % (type(workflow).__module__, type(workflow).__name__),
    "compiled_type": "%s.%s" % (type(compiled).__module__, type(compiled).__name__),
    "checkpointer": "%s.%s" % (type(compiled.checkpointer).__module__,
                               type(compiled.checkpointer).__name__),
}


def _spec_callable(spec):
    for attr in ("callable", "bound", "node", "fn", "func"):
        v = getattr(spec, attr, None)
        if callable(v):
            return v, attr
        inner = getattr(v, "func", None)
        if callable(inner):
            return inner, attr + ".func"
    return None, None


nodes = {}
try:
    node_map = workflow.nodes
except Exception:
    node_map = getattr(compiled, "nodes", {})
for name in sorted(node_map):
    spec = node_map[name]
    call, attr = _spec_callable(spec)
    nodes[name] = {"spec_type": type(spec).__name__, "callable_attr": attr}
    if call is not None:
        nodes[name]["callable"] = ident(call)
RESULT["graph_nodes"] = nodes
RESULT["graph_node_count"] = len(nodes)

drawn = {}
try:
    g = compiled.get_graph()
    drawn["node_ids"] = sorted(str(getattr(n, "id", n)) for n in g.nodes)
    drawn["edges"] = [{"source": getattr(e, "source", None),
                       "target": getattr(e, "target", None),
                       "data": str(getattr(e, "data", ""))[:80],
                       "conditional": bool(getattr(e, "conditional", False))}
                      for e in g.edges]
except Exception:
    drawn["error"] = traceback.format_exc().splitlines()[-1]
RESULT["graph_drawn"] = drawn

RESULT["routers"] = {
    "route_after_reaction": ident(route_after_reaction),
    "should_continue": ident(should_continue),
    "route_after_reaction_source": inspect.getsource(route_after_reaction),
    "router_source_sha256": hashlib.sha256(
        inspect.getsource(route_after_reaction).encode()).hexdigest(),
}
src_graph_txt = (Path(STAGED) / "src/graph.py").read_text(encoding="utf-8")
_drawn_edges = RESULT["graph_drawn"].get("edges") or []
RESULT["conditional_branch_targets"] = {
    "in_source_predict_edge": '"predict": "reaction_prediction"' in src_graph_txt,
    "lookup_edge_in_source": bool(re.search(r"(envipath|known_route|database_lookup)",
                                            src_graph_txt, re.I)),
    "edge_labels_seen_in_compiled_graph": sorted(
        {str(e.get("data")) for e in _drawn_edges if e.get("conditional")}),
}

RESULT["envipath_string_survey"] = {}
for rel in ("src/graph.py", "src/state.py", "src/schemas/bridge.py", "src/schemas/evidence.py",
            "src/nodes/multi_step_bridge_node.py", "src/nodes/reaction_node.py",
            "src/nodes/reaction_prediction_node.py", "src/tools/reaction_predictor.py",
            "src/tools/depending_v32_adapter.py", "src/tools/reaction_retriever.py",
            "src/tools/enzyme_pool_builder.py", "config/settings.py"):
    p = Path(STAGED) / rel
    if not p.is_file():
        RESULT["envipath_string_survey"][rel] = {"present": False}
        continue
    txt = p.read_text(encoding="utf-8", errors="replace")
    hits = [ln.strip()[:130] for ln in txt.splitlines()
            if re.search(r"envipath|eawag|known_route|database_lookup", ln, re.I)]
    RESULT["envipath_string_survey"][rel] = {
        "present": True, "bytes": p.stat().st_size, "sha256": sha256_file(p),
        "hit_count": len(hits), "hit_lines": hits[:6],
    }

# ------------------------------------------------------------------ 3. scenarios
def _values_of(snapshot):
    vals = getattr(snapshot, "values", None)
    if vals is None:
        return {}
    if hasattr(vals, "model_dump"):
        return vals.model_dump()
    if isinstance(vals, dict):
        return vals
    return {"__repr__": repr(vals)[:500]}


def _fld(obj, key):
    """Read one field from a pydantic model or a plain dict without guessing the type."""
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)


def _extract(vals):
    out = {"fail_closed": vals.get("fail_closed"), "error": vals.get("error"),
           "pipeline_mode": vals.get("pipeline_mode"),
           "substrate_smiles": None, "substrate_source": None,
           "candidate_reaction_count": None, "first_candidate": None,
           "predicted_reaction_count": None,
           "reaction_source": vals.get("reaction_source"),
           "pool_route_used": vals.get("pool_route_used"),
           "pool_size": vals.get("pool_size"),
           "reaction_task_id": vals.get("reaction_task_id"),
           "source_signature": vals.get("source_signature"),
           "evidence_stages": [(getattr(e, "stage", None) or (e or {}).get("stage"))
                               for e in (vals.get("evidence_chain") or [])]}
    si = vals.get("substrate_info")
    if si is not None:
        g = lambda k: getattr(si, k, None) if not isinstance(si, dict) else si.get(k)
        out["substrate_smiles"] = g("substrate_smiles")
        out["substrate_source"] = g("source")
    cands = vals.get("candidate_reactions") or []
    out["candidate_reaction_count"] = len(cands)
    if cands:
        c0 = cands[0]
        gc = lambda k: getattr(c0, k, None) if not isinstance(c0, dict) else c0.get(k)
        rsm = gc("reaction_smiles") or ""
        out["first_candidate"] = {
            "reaction_smiles_head": rsm[:120],
            "reaction_sha256_field": gc("reaction_sha256"),
            "reaction_sha256_recomputed": hashlib.sha256(rsm.encode()).hexdigest(),
            "source": gc("source"), "source_tag": gc("source_tag"),
            "source_tool": gc("source_tool"), "similarity_score": gc("similarity_score"),
            "rhea_id": gc("rhea_id")}
    # The operator asks for "the reaction_task_id that finally enters the enzyme pool".  In this
    # fixed topology the enzyme-pool node consumes ``state.candidate_reactions``, whose per-reaction
    # anchor is the G5 field pair (reaction_smiles, reaction_sha256); ``state.reaction_task_id`` is
    # written *only* by the bridge node for multistep routes.  Both are recorded so that an unset
    # task id is never mistaken for a probe failure.
    out["pool_entry_identifiers"] = {
        "candidate_reaction_count": len(cands),
        "sampled_first_3": [{
            "reaction_sha256": _fld(c, "reaction_sha256"),
            "rhea_id": _fld(c, "rhea_id"),
            "ec_numbers": _fld(c, "ec_numbers"),
            "source": _fld(c, "source"),
            "source_tag": _fld(c, "source_tag"),
            "source_tool": _fld(c, "source_tool"),
            "reaction_task_id": _fld(c, "reaction_task_id"),
            "reaction_smiles_head": (_fld(c, "reaction_smiles") or "")[:100],
        } for c in cands[:3]],
        "state_reaction_task_id": vals.get("reaction_task_id"),
        "pool_consumer": "src/nodes/enzyme_pool_node.py reads state.candidate_reactions -> "
                         "state.enzyme_pool_final / pool_route_used / pool_size",
    }
    preds = vals.get("predicted_reactions") or []
    out["predicted_reaction_count"] = len(preds)
    if preds:
        p0 = preds[0]
        gp = lambda k: getattr(p0, k, None) if not isinstance(p0, dict) else p0.get(k)
        out["first_predicted"] = {"source_tag": gp("source_tag"),
                                  "source_tool": gp("source_tool")}
    # bridge_result carries the *label* the teacher stamps on caller-supplied multistep edges;
    # this is what a reader could mistake for an enviPath lookup, so it is extracted verbatim.
    br = vals.get("bridge_result")
    if br is not None:
        gb = lambda k: getattr(br, k, None) if not isinstance(br, dict) else br.get(k)
        steps = gb("steps") or []
        out["bridge_result"] = {
            "route_id": gb("route_id"),
            "step_count": len(steps),
            "steps": [{
                "reaction_task_id": (getattr(s, "reaction_task_id", None)
                                      or (s or {}).get("reaction_task_id")),
                "source_tool": getattr(s, "source_tool", None) or (s or {}).get("source_tool"),
                "reaction_source": (getattr(s, "reaction_source", None)
                                    or (s or {}).get("reaction_source")),
                "reaction_smiles_head": ((getattr(s, "reaction_smiles", None)
                                          or (s or {}).get("reaction_smiles")) or "")[:110],
                "enzyme_match_status": (getattr(s, "enzyme_match_status", None)
                                        or (s or {}).get("enzyme_match_status")),
            } for s in steps[:4]]}
    return out


def _delta_calls(baseline):
    out = {}
    for k, v in CALLS.items():
        base = baseline.get(k, 0)
        if v["count"] - base:
            out[k] = {"count": v["count"] - base, "file": v["file"],
                      "under_teacher_tree": v["under_teacher_tree"],
                      "firstlineno": v["firstlineno"]}
    return out


def _count_of(delta, pattern):
    rx = re.compile(pattern)
    return sum(v["count"] for k, v in delta.items() if rx.search(k))


def _window(timing, pattern):
    rx = re.compile(pattern)
    hits = [t for t in timing if rx.search(t["callable"])]
    if not hits:
        return {"matched_calls": 0, "started_utc": None, "ended_utc": None, "callables": []}
    return {"matched_calls": len(hits), "started_utc": hits[0]["utc"],
            "ended_utc": hits[-1]["utc"],
            "callables": sorted({h["callable"] for h in hits})}


def run_scenario(name, inputs, stop_after=None):
    CURRENT[0] = name
    baseline = {k: v["count"] for k, v in CALLS.items()}
    tstart = len(TIMED)
    imark, smark = len(IMPORT_EVENTS), len(SOCKET_EVENTS)
    wall0 = time.monotonic()
    started = _utc()
    node_order, err, raised = [], None, None
    thread_cfg = {"configurable": {"thread_id": "%s-%d" % (name, int(time.time() * 1000))}}
    final_vals = {}
    try:
        for chunk in compiled.stream(inputs, thread_cfg, stream_mode="updates"):
            if isinstance(chunk, dict):
                for nm in chunk:
                    node_order.append(nm)
            if stop_after and node_order and node_order[-1] == stop_after:
                break
        final_vals = _values_of(compiled.get_state(thread_cfg))
    except Exception:
        err = traceback.format_exc()
        raised = err.strip().splitlines()[-1][:300]
    ended = _utc()
    delta = _delta_calls(baseline)
    timing = TIMED[tstart:]
    sc = {
        "scenario": name,
        "input_identity": {
            "user_query_head": str(inputs.get("user_query"))[:90],
            "user_query_sha256": hashlib.sha256(
                str(inputs.get("user_query")).encode()).hexdigest(),
            "pipeline_mode": inputs.get("pipeline_mode"),
            "multistep_route_given": inputs.get("multistep_route") is not None,
            "driver": "compiled.stream(stream_mode='updates') + compiled.get_state()",
            "thread_id": thread_cfg["configurable"]["thread_id"]},
        "started_utc": started, "ended_utc": ended,
        "wall_s": round(time.monotonic() - wall0, 3),
        "node_execution_order": node_order,
        "raised": raised, "traceback": err,
        "calls": delta,
        "new_imports_watchlisted": [e["module"] for e in IMPORT_EVENTS[imark:]],
        "new_socket_events": SOCKET_EVENTS[smark:],
        "timing": {
            "any_envipath_known_route_lookup": _window(
                timing, r"(eawag|envipath|known_route|database_lookup)"),
            "route_c_similar_retrieval": _window(timing, r"retrieve_similar_reactions"),
            "graph_prediction_fallback": _window(
                timing, r"reaction_predictor:predict_reactions"),
            "depending_v32_entry": _window(
                timing, r"(single_smiles_v32|depending_v32_adapter)"),
        },
        "counts": {
            "envipath_known_route_lookup_calls": _count_of(
                delta, r"(eawag|envipath|known_route|database_lookup)"),
            "route_c_retrieval_calls": _count_of(delta, r":retrieve_similar_reactions$"),
            "biotransformer_prediction_calls": _count_of(
                delta, r"src\.tools\.reaction_predictor:predict_reactions$"),
            "any_predict_reactions_calls": _count_of(delta, r":predict_reactions$"),
            "depending_v32_adapter_calls": _count_of(
                delta, r"(depending_v32_adapter|single_smiles_v32)"),
            "reaction_prediction_node_calls": _count_of(delta, r"reaction_prediction_node:"),
            "bridge_node_calls": _count_of(delta, r"multi_step_bridge_node:"),
            "enzyme_pool_build_calls": _count_of(delta, r":build_enzyme_pool$"),
            "teacher_functions_called_total": sum(v["count"] for v in delta.values()),
        },
        "terminal_state": _extract(final_vals),
    }
    CURRENT[0] = "done"
    return sc


VALID_SMILES = CFG["valid_smiles"]
INVALID_QUERY = CFG["invalid_query"]
NEAR_ISOLATED = CFG["near_isolated_smiles"]

sys.settrace(_global_trace)
threading.settrace(_global_trace)

SCENARIOS = []
for sname, sinputs, sstop in (
    ("S_INVALID_INPUT", {"user_query": INVALID_QUERY, "pipeline_mode": "m3"}, None),
    ("S_HIT_LIKE_M3", {"user_query": VALID_SMILES, "pipeline_mode": "m3"}, "enzyme_pool"),
    ("S_MISS_PROBE_M5", {"user_query": NEAR_ISOLATED, "pipeline_mode": "m5"}, "enzyme_pool"),
    ("S_ENVIPATH_LABEL_BRIDGE", {
        "user_query": VALID_SMILES, "pipeline_mode": "m5",
        "multistep_route": {"route_id": "P13-LABEL-ONLY",
                            "reactant_smiles": [VALID_SMILES, "c1ccc2[nH]nnc2c1"],
                            "source_tool": "enviPath",
                            "reaction_source": "retrieved"}}, "reaction"),
):
    try:
        SCENARIOS.append(run_scenario(sname, sinputs, sstop))
    except Exception:
        RESULT.setdefault("scenario_errors", {})[sname] = traceback.format_exc()

RESULT["scenarios"] = SCENARIOS

# ------------------------------------------------------------------ 4. reachability proof
sys.settrace(None)
threading.settrace(None)

RESULT["sys_modules_reachability"] = {
    m: {"imported": m in sys.modules,
        "file": getattr(sys.modules.get(m), "__file__", None)}
    for m in ("src.graph", "src.nodes.reaction_node", "src.nodes.reaction_prediction_node",
              "src.nodes.multi_step_bridge_node", "src.tools.reaction_retriever",
              "src.tools.reaction_predictor", "src.tools.enzyme_pool_builder",
              "src.tools.chem_name_resolver", "src.tools.depending_v32_adapter",
              "reaction_analogy.single_smiles_v32", "reaction_analogy.eawag_lookup",
              "depending_frozen_single_smiles_v32", "envipath", "eawag_lookup")}
RESULT["import_audit"] = {
    "total_import_events": IMPORT_TOTAL[0],
    "audit_import_event_arg_shape_first_seen": IMPORT_ARG_SHAPE[:1],
    "module_name_extracted_from": "args[0][0] (tuple) or args[0] (str)",
    "watchlisted_import_modules": sorted({e["module"] for e in IMPORT_EVENTS}),
    "watchlisted_import_events_tail": IMPORT_EVENTS[-40:]}
RESULT["socket_audit"] = {"event_count": len(SOCKET_EVENTS), "events": SOCKET_EVENTS[:20]}
RESULT["all_traced_callables"] = [
    {"callable": k, "count": v["count"], "file": v["file"],
     "under_teacher_tree": v["under_teacher_tree"]}
    for k, v in sorted(CALLS.items(), key=lambda kv: -kv[1]["count"])][:220]
RESULT["utc_finished"] = _utc()

Path(OUT).write_text(json.dumps(RESULT, ensure_ascii=False, indent=1), encoding="utf-8")
print("@@P13RESULT@@ " + json.dumps({
    "ok": True, "nodes": RESULT["graph_node_count"], "scenarios": len(SCENARIOS),
    "socket_events": len(SOCKET_EVENTS),
    "envipath_calls": sum(s["counts"]["envipath_known_route_lookup_calls"]
                          for s in SCENARIOS)}))
