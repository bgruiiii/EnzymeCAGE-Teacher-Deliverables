#!/usr/bin/env python3
"""T6-R3-R1 p14 — §8 stage A: freeze the eight real smoke records BEFORE any full chain.

Original contract §5 is explicit: ``先在任何整链运行前生成 REAL_SMOKE_SELECTION_PREREGISTRATION.md，
再按规则选择，不能看最终输出后换样本``.  This driver therefore runs *only* the cheap CPU work that
the selection rules need and writes the frozen selection down before §8 stage B touches a GPU:

    S1  one UID out of the real B-primary pool that the *real teacher graph* builds for the
        teacher's own B-primary case substrate;
    S2  one UID out of the real C-fallback pool produced by the same graph for the first
        substrate of the frozen §6 probe list that the production pool builder really routes
        through C;
    S3—S8  the three T3B staged reactions of §7 x the first two UIDs of the contract's frozen
        UID order, taken straight out of the §7 real forward evidence.

Selection rules are quoted verbatim from contract §5 and are evaluated against the *production*
``C8TraitAdapter`` (authority C8 index + authority UID map, both SHA-pinned), never against a
re-implementation.  Every measurement is taken by the child ``p14b_prereg_observer.py``; this
driver only pins inputs, launches it, cross-checks the result, and refuses to release a
preregistration whose evidence is thin.  Persistent inputs are hashed before and after.
"""
import csv
import hashlib
import json
import os
import re
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import r1_common as C  # noqa: E402

SECTION = "§8-A-smoke-preregistration"
W, RD, LOGS = C.WORK_ROOT, C.RETURN_DIR, C.LOGS
STAGED = str(C.STAGED_REPO)

OBS = W / "scripts" / "p14b_prereg_observer.py"
CFG_PATH = LOGS / "p14b_prereg_cfg.json"
OUT_JSON = LOGS / "p14b_prereg_result.json"
OBS_STDOUT = LOGS / "p14b_prereg.stdout.log"
OBS_STDERR = LOGS / "p14b_prereg.stderr.log"
OBS_TIMEOUT = 2400

CASE_B = C.STAGED_REPO / "cases" / "case_1_realrun.json"
C_PROBE = LOGS / "probe_c_fallback.json"
FWD_JSONL = RD / "T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl"
FWD_CSV = RD / "FORWARD_PER_REACTION_UID_SEED_SCORES.csv"
ASSET_GATE = RD / "FIXED_ASSET_IDENTITY_GATE.json"
OVERLAY_MANIFEST = RD / "REACTION_OVERLAY_MANIFEST.csv"
P43_GATE = RD / "UNIFIED_GRAPH_RUNTIME_GATE.json"
ASSETS = C.RETURN_ROOT / "m3_agent_data_assets" / "assets"
FROZEN_UID_ORDER = ["A0A011QK89", "A0A017SP50", "A0A017SR40"]

PREREG_MD = RD / "REAL_SMOKE_SELECTION_PREREGISTRATION.md"
INPUTS_CSV = RD / "REAL_SMOKE_INPUTS.csv"
EVID_JSON = RD / "REAL_SMOKE_PREREG_EVIDENCE.json"
RUNS_CSV = RD / "REAL_SMOKE_REAL_POOL_RUNS.csv"
STDOUT_TXT = RD / "REAL_SMOKE_PREREG_STDOUT.txt"

S1_RULE = ("CASE_B real pool, pool order = production build_enzyme_pool order (sorted EC "
           "iteration + dict.fromkeys dedup); take the highest-rank UID with >=1 OBSERVED trait "
           "among F1-F15 from the production C8TraitAdapter; if none, take rank 1 and record the "
           "observed-coverage block")
S2_RULE = ("CASE_C real pool, same production pool order; take the highest-rank UID with >=1 "
           "MISSING trait among F1-F15 from the production C8TraitAdapter; if none, take rank 1 "
           "and record the reason")
S38_RULE = ("contract §5 frozen UID order %s intersected with the UIDs really forwarded in the "
            "§7 record for that staged reaction, first two; preselection_rank = that UID's real "
            "EnzymeCAGE rank inside the §7 base ranking" % FROZEN_UID_ORDER)

problems = []
report = []
attempt_history = []

DELIVERABLES = [PREREG_MD, INPUTS_CSV, EVID_JSON, RUNS_CSV, STDOUT_TXT]


def archive_previous_attempt():
    """A preregistration is never silently overwritten: an earlier freeze is kept verbatim."""
    if not PREREG_MD.exists() and not INPUTS_CSV.exists():
        return
    n = 1
    while (LOGS / ("p14_attempt_%d" % n)).exists():
        n += 1
    adir = LOGS / ("p14_attempt_%d" % n)
    adir.mkdir(parents=True, exist_ok=True)
    rec = {"archive_dir": str(adir)}
    for p in DELIVERABLES:
        if p.exists():
            dst = adir / p.name
            shutil.move(str(p), str(dst))
            rec[p.name] = {"sha256": sha_file(dst), "bytes": dst.stat().st_size}
    attempt_history.append(rec)
    say("previous preregistration archived to %s (a freeze is never overwritten in place)"
        % adir.name)


def say(msg):
    stamp = datetime.now(timezone.utc).strftime("%H:%M:%S")
    line = "[%s][p14] %s" % (stamp, msg)
    report.append(line)
    print(line, flush=True)


def problem(msg):
    problems.append(msg)
    say("PROBLEM: %s" % msg)


def canon(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str)


def h(obj):
    return hashlib.sha256(canon(obj).encode("utf-8")).hexdigest()


def sha_file(p):
    hh = hashlib.sha256()
    with open(str(p), "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            hh.update(blk)
    return hh.hexdigest()


archive_previous_attempt()


# ------------------------------------------------------ 0. authority-pinned C8 asset paths
if not ASSET_GATE.is_file():
    say("PROBLEM: §6.2 asset gate missing"); print("@@P14@@ " + json.dumps(
        {"verdict": "FAIL", "problems": 1})); sys.exit(1)
gate = json.loads(ASSET_GATE.read_text(encoding="utf-8"))


def frozen(label, want_sha):
    hits = [e for e in gate.get("in_place_frozen_inputs", []) if e.get("label") == label]
    if len(hits) != 1:
        problem("cannot resolve the pinned path of %r from §6.2" % label)
        return None, None
    e = hits[0]
    p = Path(e["path"])
    if e.get("status") != "PASS" or not p.is_file() or p.is_symlink():
        problem("pinned input %s is not a PASS regular non-symlink file: %s" % (label, e))
    if want_sha and e.get("sha256") != want_sha:
        problem("pinned input %s hash %s != authority pin %s" % (label, e.get("sha256"), want_sha))
    return p, e.get("sha256")


UID_MAP, UID_MAP_SHA = frozen("uid_to_source_keep_bacteria_fungi_archaea.csv", C.UID_MAP_SHA)
C8_INDEX, C8_INDEX_SHA = frozen("C8_METATRAITS_LOOKUP_INDEX.jsonl", C.C8_LOOKUP_SHA)
C8_ROOT = C8_INDEX.parent if C8_INDEX else None
say("C8 authority inputs: uid_map=%s (%s…) lookup=%s (%s…)"
    % (UID_MAP.name, (UID_MAP_SHA or "")[:12], C8_INDEX.name, (C8_INDEX_SHA or "")[:12]))

# ------------------------------------- 1. pre-scan of every persistent input this stage uses
SCAN_ROOTS = [("staged_teacher_tree", C.STAGED_REPO),
              ("m3_reaction_assets", ASSETS),
              ("t3b_staged_overlay", C.RUNTIME_ASSETS / "t3"),
              ("v1_overlay", C.V1_OVERLAY),
              ("task_scripts", W / "scripts")]


def scan():
    out = {}
    for tag, root in SCAN_ROOTS:
        root = Path(root)
        if not root.is_dir():
            problem("scan root missing: %s" % root)
            continue
        for p in sorted(root.rglob("*")):
            if p.is_symlink():
                out["%s::SYMLINK::%s" % (tag, p)] = ["symlink", ""]
                continue
            if not p.is_file():
                continue
            if "__pycache__" in p.parts or p.suffix in (".pyc", ".log"):
                continue
            out["%s::%s" % (tag, p.relative_to(root))] = [p.stat().st_size, sha_file(p)]
    for tag, p in (("c8_lookup_index", C8_INDEX), ("c8_uid_map", UID_MAP),
                   ("forward_jsonl", FWD_JSONL), ("forward_scores_csv", FWD_CSV),
                   ("case_b_primary", CASE_B), ("c_fallback_probe", C_PROBE),
                   ("reaction_overlay_manifest", OVERLAY_MANIFEST),
                   ("unified_graph_runtime_gate", P43_GATE)):
        if p and Path(p).is_file():
            out["%s::%s" % (tag, Path(p).name)] = [Path(p).stat().st_size, sha_file(p)]
    return out


say("pre-run persistent input scan …")
t0 = time.monotonic()
PRE = scan()
say("  %d inputs scanned in %.1fs" % (len(PRE), time.monotonic() - t0))

# ---- topology unchanged since §4.3 (the same four frozen files must still carry their SHA)
topo_now = {rel: sha_file(C.STAGED_REPO / rel) for rel in C.TOPOLOGY_FILES}
p43_txt = P43_GATE.read_text(encoding="utf-8") if P43_GATE.is_file() else ""
topology_vs_4_3 = {}
for rel, sha in topo_now.items():
    hit = sha in p43_txt
    topology_vs_4_3[rel] = {"sha256_now": sha, "found_in_4_3_gate_text": hit}
    if not hit:
        problem("topology file %s no longer matches the §4.3 recorded SHA (%s…)"
                % (rel, sha[:16]))
say("topology vs §4.3: unchanged_all_4=%s" % all(v["found_in_4_3_gate_text"]
                                                 for v in topology_vs_4_3.values()))

# ---------------------------------------------------------------- 2. launch the child probe
for p, what in ((OBS, "p14b observer"), (CASE_B, "B-primary case file"),
                (C_PROBE, "C-fallback probe"), (FWD_JSONL, "§7 forward jsonl"),
                (FWD_CSV, "§7 score csv"), (OVERLAY_MANIFEST, "overlay manifest")):
    if not Path(p).is_file():
        problem("%s missing: %s" % (what, p))

cfg = {
    "staged": STAGED,
    "out_json": str(OUT_JSON),
    "pinned_py": C.PY,
    "case_b_primary": str(CASE_B),
    "c_fallback_probe": str(C_PROBE),
    "forward_jsonl": str(FWD_JSONL),
    "forward_scores_csv": str(FWD_CSV),
    "c8_lookup_root": str(C8_ROOT), "c8_uid_map_path": str(UID_MAP),
    "c8_lookup_sha256": C8_INDEX_SHA, "uid_map_sha256": UID_MAP_SHA,
    "frozen_uid_order": FROZEN_UID_ORDER,
    "env": {
        "M3_AGENT_DATA_ASSETS_ROOT": str(ASSETS),
        "C8_LOOKUP_ROOT": str(C8_ROOT),
        "C8_UID_SOURCE_MAP_PATH": str(UID_MAP),
        "DEPENDING_V32_RUNTIME_ROOT": str(C.V32_FROZEN_REPO),
        "D4_WRAPPER_ROOT": str(C.D4_WRAPPER_PARENT),
        "ENZYMECAGE_CODE_ROOT": C.CODE_ROOT,
        "ENZYMECAGE_V1_PACKAGE_ROOT": str(C.V1_OVERLAY),
        "ENZYMECAGE_DRY_RUN": "0",
        "PORTRAITS_ENABLED": "0",
    },
    "determinism_control": {
        "PYTHONHASHSEED": "0",
        "why": ("src/tools/enzyme_pool_builder.build_pool_route_b turns a Python ``set`` of ECs "
                "into a list (``ec_uid_mapper.query(list(all_ec))``) and build_pool_route_c "
                "returns ``list(uids)`` of a set; under CPython string hash randomization the "
                "pool ORDER therefore drifts between fresh processes. The seed is fixed at the "
                "harness boundary (subprocess env, read at interpreter start) so this "
                "preregistration can be reproduced; no teacher file is modified.")},
    "env_pop": ["OPENAI_API_KEY", "OPENAI_BASE_URL", "ANTHROPIC_API_KEY", "AZURE_API_KEY",
                "AZURE_OPENAI_API_KEY", "DEEPSEEK_API_KEY", "MOONSHOT_API_KEY",
                "DASHSCOPE_API_KEY", "LLM_API_KEY", "QWEN_API_KEY", "BIGMODEL_API_KEY"],
}
CFG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")

# ------------------------------------------------------------------ 2. three fresh processes
# A freeze is only worth anything if it repeats, so the very same probe is executed in three
# separate processes with PYTHONHASHSEED=0 and the ordered pools / selections are compared.
OBS_RUNS = 3
env = C.base_env({"CUDA_VISIBLE_DEVICES": "", "PYTHONHASHSEED": "0"})
observer_runs = []
obs = {}
rc = 0
out = err = ""
wall = 0.0
for n in range(1, OBS_RUNS + 1):
    cfg["out_json"] = str(LOGS / ("p14b_prereg_result_run%d.json" % n))
    CFG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
    t_run = time.monotonic()
    rc, out, err = C.run_py([OBS, str(CFG_PATH)], cwd=W, env=env,
                            note="§8-A smoke pre-registration probe run %d/%d: one real "
                                 "StateGraph compile, real B-primary + 8-substrate C battery runs "
                                 "stopped at enzyme_pool, production C8TraitAdapter trait classes "
                                 "(PYTHONHASHSEED=0, no CUDA, no writes)" % (n, OBS_RUNS),
                            timeout=OBS_TIMEOUT, label="p14b_prereg_run%d" % n)
    w = round(time.monotonic() - t_run, 1)
    wall += w
    one = {}
    p = LOGS / ("p14b_prereg_result_run%d.json" % n)
    if p.is_file():
        one = json.loads(p.read_text(encoding="utf-8"))
    if rc != 0 or not one:
        problem("observer run %d failed rc=%d tail=%s" % (n, rc, (err or out).strip().splitlines()[-6:]))
    if (one.get("interp") or {}).get("pythonhashseed") != "0":
        problem("observer run %d did not inherit PYTHONHASHSEED=0: %r"
                % (n, (one.get("interp") or {}).get("pythonhashseed")))
    if (one.get("interp") or {}).get("cuda_visible_devices") != "":
        problem("observer run %d did not run with CUDA_VISIBLE_DEVICES emptied: %r"
                % (n, (one.get("interp") or {}).get("cuda_visible_devices")))
    observer_runs.append({"run": n, "exit_code": rc, "wall_s": w,
                          "out_json": str(p),
                          "stdout_log": str(LOGS / ("p14b_prereg_run%d.stdout.log" % n)),
                          "stderr_log": str(LOGS / ("p14b_prereg_run%d.stderr.log" % n)),
                          "stdout_sha256": hashlib.sha256(out.encode()).hexdigest(),
                          "stderr_sha256": hashlib.sha256(err.encode()).hexdigest(),
                          "console_tail": out.strip().splitlines()[-2:],
                          "interp": one.get("interp"),
                          "problems": one.get("problems"),
                          "b_pool": (one.get("trait_probe_b") or {}).get("uids_in_pool_order"),
                          "c_pool": (one.get("trait_probe_c") or {}).get("uids_in_pool_order"),
                          "s1_uid": ((one.get("selection_b") or {}).get("chosen") or {}).get("UID"),
                          "s2_uid": ((one.get("selection_c") or {}).get("chosen") or {}).get("UID"),
                          "b_chain_sha": (one.get("run_b_primary") or {}).get(
                              "evidence_chain_sha256"),
                          "anchor_sha": ((one.get("run_b_primary") or {}).get(
                              "candidate_reactions_head") or [{}])[0].get("reaction_sha256")})
    say("observer run %d exit=%d wall=%ss B_pool=%s S1=%s S2=%s"
        % (n, rc, w, len((one.get("trait_probe_b") or {}).get("uids_in_pool_order") or []),
           observer_runs[-1]["s1_uid"], observer_runs[-1]["s2_uid"]))
    if one:
        obs = one


def _stability(key):
    vals = [json.dumps(r.get(key), sort_keys=True) for r in observer_runs]
    return {"values_identical": len(set(vals)) == 1, "distinct_values": len(set(vals)),
            "per_run": [r.get(key) for r in observer_runs]}


stability = {"fresh_process_runs": OBS_RUNS,
             "pythonhashseed": "0 (set in the subprocess env, read by CPython at start)",
             "b_pool_order": _stability("b_pool"), "c_pool_order": _stability("c_pool"),
             "s1_selection": _stability("s1_uid"), "s2_selection": _stability("s2_uid"),
             "b_anchor_reaction_sha256": _stability("anchor_sha")}
for nm, blk in stability.items():
    if isinstance(blk, dict) and blk.get("values_identical") is False:
        problem("pre-registration is not reproducible across %d fresh processes: %s differs (%s)"
                % (OBS_RUNS, nm, blk.get("distinct_values")))
stability["reproducible"] = all(
    b.get("values_identical") for k, b in stability.items() if isinstance(b, dict))
stability["uncontrolled_prior_observation"] = {
    "note": ("the two earlier attempts of this same stage ran without a fixed hash seed and "
             "produced the same UID *sets* in different *orders*; they are kept as the "
             "observation of the teacher-side order nondeterminism"),
    "evidence": [str(LOGS / "p14_attempt_1" / "REAL_SMOKE_PREREG_EVIDENCE.json"),
                 str(OUT_JSON)]}
say("fresh-process stability: reproducible=%s" % stability["reproducible"])

interp = obs.get("interp", {})
if interp and interp.get("is_pinned") is not True:
    problem("observer interpreter is not the pinned ${PY}: %r" % interp)
if obs.get("network_events"):
    problem("observer saw network activity: %s" % obs["network_events"][:3])
for cp, cv in (obs.get("env_credentials_popped") or {}).items():
    if cv is not None:
        say("  credential %s was present in the parent env and popped in the child" % cp)

compile_info = obs.get("compile", {})
EXPECTED_NODES = {"orchestrator", "substrate", "reaction", "reaction_prediction", "enzyme_pool",
                  "enzymecage", "reranking", "microbe", "organism_selection", "trait",
                  "synthesis", "bridge"}
real_nodes = set(compile_info.get("pre_compile_stategraph_nodes") or [])
if len(real_nodes) != 12 or real_nodes != EXPECTED_NODES:
    problem("the compiled teacher graph is not the frozen 12-node topology: %s (extra=%s "
            "missing=%s)" % (len(real_nodes), sorted(real_nodes - EXPECTED_NODES),
                             sorted(EXPECTED_NODES - real_nodes)))
if set(compile_info.get("compiled_drawn_nodes") or []) - real_nodes != {"__start__", "__end__"}:
    problem("the drawn compiled graph carries unexpected virtual nodes: %s"
            % sorted(set(compile_info.get("compiled_drawn_nodes") or []) - real_nodes))
if not (obs.get("langgraph") or {}).get("stategraph_is_real_langgraph"):
    problem("StateGraph is not the installed langgraph one")
if (obs.get("torch_state") or {}).get("torch_in_sys_modules"):
    problem("torch was imported by the pre-registration probe (a GPU node ran): %s"
            % [s.get("node_execution_order") for s in obs.get("c_battery_runs") or []])

# ------------------------------------------------------------- 3. post-scan and equality
say("post-run persistent input scan …")
t0 = time.monotonic()
POST = scan()
say("  %d inputs scanned in %.1fs" % (len(POST), time.monotonic() - t0))
changed = sorted(k for k in set(PRE) | set(POST) if PRE.get(k) != POST.get(k))
if changed:
    for k in changed[:12]:
        say("  CHANGED %s: %s -> %s" % (k, PRE.get(k), POST.get(k)))
    problem("%d persistent input entries changed during a read-only pre-registration run"
            % len(changed))
persistence = {"pre_scan_entries": len(PRE), "post_scan_entries": len(POST),
               "changed_entries": changed, "changed": bool(changed),
               "method": "relative_path/bytes/SHA256 of every regular file under the scanned "
                         "roots plus the individually pinned inputs (no mtime, no size shortcut)",
               "pre_scan_sha256": h(PRE), "post_scan_sha256": h(POST)}

# ------------------------------------------------------------ 4. the measurements are read
run_b = obs.get("run_b_primary") or {}
run_c = obs.get("run_c_fallback") or {}
sel_b = (obs.get("selection_b") or {}).get("chosen") or {}
sel_c = (obs.get("selection_c") or {}).get("chosen") or {}
b_cls = obs.get("trait_probe_b") or {}
c_cls = obs.get("trait_probe_c") or {}
staged_rows = obs.get("staged_forward_rows") or []
staged_trait = {r["UID"]: r for r in obs.get("trait_probe_staged") or []}

if run_b.get("enzymecage_gpu_node_entered") or run_c.get("enzymecage_gpu_node_entered"):
    problem("a pre-registration run entered a GPU node")
if run_b.get("pool_route_used") != "B":
    problem("the B-primary real run did not use route B: %r" % run_b.get("pool_route_used"))
if not run_c:
    problem("no C-fallback real run was selected")
elif run_c.get("pool_route_used") != "C":
    problem("the selected CASE_C run did not use route C: %r" % run_c.get("pool_route_used"))
for tag, cls, sel in (("S1", b_cls, sel_b), ("S2", c_cls, sel_c)):
    if not cls.get("per_uid_trait_classification"):
        problem("%s pool was never trait-classified by the production adapter" % tag)
    if not sel.get("UID"):
        problem("%s has no selected UID" % tag)
if len(staged_rows) != 3:
    problem("expected three §7 staged forward rows, found %d" % len(staged_rows))

opened_sha = (obs.get("opened_files") or {}).get("data_paths_sha256") or {}
asset_bundle = {"opened_data_files": opened_sha,
                "bundle_sha256": h(opened_sha) if opened_sha else None}
overlay_rows = []
if OVERLAY_MANIFEST.is_file():
    with open(str(OVERLAY_MANIFEST), encoding="utf-8") as fh:
        overlay_rows = list(csv.DictReader(fh))
overlay_bundle = {"manifest_path": str(OVERLAY_MANIFEST),
                  "manifest_sha256": sha_file(OVERLAY_MANIFEST),
                  "member_sha256": {r["relative"]: r["observed_sha256"] for r in overlay_rows},
                  "bundle_sha256": h({r["relative"]: r["observed_sha256"]
                                      for r in overlay_rows}) if overlay_rows else None}


def anchor_of(run):
    head = run.get("candidate_reactions_head") or []
    return head[0] if head else {}


def trait_summary(row):
    if not row:
        return "NOT_CLASSIFIED"
    parts = ["%s=%d" % (k, v) for k, v in sorted((row.get("trait_class_counts") or {}).items())]
    return "%s|sig=%s|mapped_taxids=%s|resolution=%s|uid_map_rows=%s|not_mapped=%s" % (
        " ".join(parts),
        ",".join(row.get("source_signatures") or [])[:40],
        ",".join(str(t) for t in row.get("host_taxids_mapped") or [])[:40],
        ",".join(row.get("host_resolutions") or []),
        row.get("uid_map_row_count"), row.get("not_mapped"))


def run_identity(run):
    return "scenario=%s thread=%s nodes=%s started=%s ended=%s evidence_chain_sha256=%s" % (
        run.get("scenario"), run.get("thread_id"), ">".join(run.get("node_execution_order") or []),
        run.get("started_utc"), run.get("ended_utc"), run.get("evidence_chain_sha256"))


COLUMNS = ["smoke_record_id", "case_id", "substrate", "reaction_task_id", "original_reaction",
           "predicted_reaction", "asset_track", "asset_identity", "source_tag", "pool_source",
           "UID", "preselection_rank", "selection_rule", "selection_input_hash",
           "wrapper_model_version", "forward_evidence_hash", "pool_anchor_reaction_smiles",
           "pool_anchor_reaction_sha256", "trait_class_summary_from_production_c8",
           "real_run_identity", "selection_provenance"]
records = []


def pool_record(sid, case_id, run, cls, sel, rule, case_identity, probe_identity):
    anchor = anchor_of(run)
    nodes = run.get("node_execution_order") or []
    predicted_seen = "reaction_prediction" in nodes
    sel_hash = h({
        "rule": rule, "case_identity": case_identity, "probe_identity": probe_identity,
        "run": {k: run.get(k) for k in ("scenario", "input_user_query", "pipeline_mode",
                                        "node_execution_order", "thread_id", "pool_route_used",
                                        "pool_size", "enzyme_pool_final_ordered",
                                        "evidence_chain_sha256", "started_utc", "ended_utc")},
        "per_uid_trait_classification": [
            {k: r.get(k) for k in ("UID", "preselection_rank", "observed_trait_count",
                                   "missing_trait_count", "identity_only_trait_count",
                                   "source_signatures", "not_mapped")}
            for r in (cls.get("per_uid_trait_classification") or [])],
        "asset_bundle_sha256": asset_bundle["bundle_sha256"]})
    prov = ("selected by %s against the real pool produced by %s; the trait classes come from "
            "the production src.tools.trait_query.C8TraitAdapter over the SHA-pinned authority "
            "C8 index and UID map; the carrier host %s is a probe carrier and is NOT final host "
            "evidence (final host must come from the real microbe node in §8 stage B)"
            % (rule[:40] + "…", run.get("scenario"), "PROBE_CARRIER_NOT_FINAL_HOST"))
    return {
        "smoke_record_id": sid,
        "case_id": case_id,
        "substrate": run.get("input_user_query"),
        "reaction_task_id": (run.get("reaction_task_id_state")
                             or "NONE:single-step M3 path writes no state.reaction_task_id "
                                "(bridge-only key, see ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json)"),
        "original_reaction": anchor.get("reaction_smiles") or "NONE:no candidate reaction",
        "predicted_reaction": (anchor.get("reaction_smiles") if predicted_seen else
                              "N/A:reaction_prediction node not executed in this real run "
                              "(pool came from retrieval)"),
        "asset_track": "M3_base_library_retrieved_route_%s" % (run.get("pool_route_used") or "?"),
        "asset_identity": ("opened_asset_bundle_sha256=%s;case_file_sha256=%s;"
                           "probe_file_sha256=%s" % (asset_bundle["bundle_sha256"],
                                                     (case_identity or {}).get("sha256"),
                                                     (probe_identity or {}).get("sha256"))),
        "source_tag": (str(anchor.get("source_tag"))
                       if anchor.get("source_tag") is not None else
                       "null(production CandidateReaction.source_tag for retrieved rows)"),
        "pool_source": "route_%s" % (run.get("pool_route_used") or "?"),
        "UID": sel.get("UID"),
        "preselection_rank": sel.get("preselection_rank"),
        "selection_rule": rule,
        "selection_input_hash": sel_hash,
        "wrapper_model_version": "NOT_OBSERVED_AT_PREREGISTRATION (filled only from the §8-B "
                                 "real wrapper run; never pre-filled)",
        "forward_evidence_hash": "NOT_OBSERVED_AT_PREREGISTRATION (filled only from the §8-B "
                                 "real forward)",
        "pool_anchor_reaction_smiles": anchor.get("reaction_smiles"),
        "pool_anchor_reaction_sha256": anchor.get("reaction_sha256"),
        "trait_class_summary_from_production_c8": trait_summary(sel),
        "real_run_identity": run_identity(run),
        "selection_provenance": prov}


records.append(pool_record("S1", "CASE_B_PRIMARY_SUCCESS", run_b, b_cls, sel_b, S1_RULE,
                           obs.get("case_b_primary_identity"), None))
records.append(pool_record("S2", "CASE_C_FALLBACK_SUCCESS", run_c, c_cls, sel_c, S2_RULE,
                           None, obs.get("c_fallback_probe_identity")))

rank_of_uid = {}
for row in staged_rows:
    rank_of_uid[row["reaction_task_id"]] = dict(
        (u, r) for (u, r) in row.get("real_rank_order") or [])
for idx, row in enumerate(staged_rows):
    present = [u for u in FROZEN_UID_ORDER if u in (row.get("original_uids") or [])]
    for j, uid in enumerate(present[:2]):
        sid = "S%d" % (3 + idx * 2 + j)
        react = row.get("reaction_smiles")
        sel_hash = h({"rule": S38_RULE, "frozen_uid_order": FROZEN_UID_ORDER,
                      "staged_row": {k: row.get(k) for k in
                                     ("reaction_task_id", "reaction_smiles",
                                      "reaction_sha256_production", "evidence_hash",
                                      "original_uids", "real_rank_order", "worker_index",
                                      "gpu_uuid", "exit_code", "stdout_sha256")},
                      "forward_jsonl_sha256": (obs.get("forward_identity") or {}).get("jsonl_sha256"),
                      "overlay_bundle_sha256": overlay_bundle["bundle_sha256"],
                      "uid": uid})
        records.append({
            "smoke_record_id": sid,
            "case_id": "T3B_STAGED_%s" % row.get("reaction_task_id"),
            "substrate": (react or ">>").split(">>")[0],
            "reaction_task_id": row.get("reaction_task_id"),
            "original_reaction": react,
            "predicted_reaction": react,
            "asset_track": "staged_real_asset_T3B (generated reaction staged into the §6.2 "
                           "read-only overlay)",
            "asset_identity": ("T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl#sha256=%s;"
                               "overlay_bundle_sha256=%s" % (
                                   (obs.get("forward_identity") or {}).get("jsonl_sha256"),
                                   overlay_bundle["bundle_sha256"])),
            "source_tag": "staged_generated_T3B_three_reaction_package",
            "pool_source": "T3B_frozen_D4_uid_pair_not_graph_pool",
            "UID": uid,
            "preselection_rank": rank_of_uid.get(row.get("reaction_task_id"), {}).get(uid),
            "selection_rule": S38_RULE,
            "selection_input_hash": sel_hash,
            "wrapper_model_version": row.get("model_version"),
            "forward_evidence_hash": row.get("evidence_hash"),
            "pool_anchor_reaction_smiles": react,
            "pool_anchor_reaction_sha256": row.get("reaction_sha256_production"),
            "trait_class_summary_from_production_c8": trait_summary(staged_trait.get(uid)),
            "real_run_identity": ("§7 worker%s gpu=%s exit=%s status=%s forward_executed=%s "
                                  "call_count=%s started=%s ended=%s wall=%ss stdout_sha=%s" % (
                                      row.get("worker_index"), row.get("gpu_uuid"),
                                      row.get("exit_code"), row.get("worker_status"),
                                      row.get("forward_executed"),
                                      row.get("forward_call_count_after"),
                                      row.get("started_utc"), row.get("ended_utc"),
                                      row.get("wall_sec"), row.get("stdout_sha256"))),
            "selection_provenance": "taken from the §7 real forward evidence file; no score was "
                                    "retyped, every value references a file and its SHA"})

# ---------------------------------------------------------- 5. record-level integrity checks
if len(records) != 8:
    problem("the contract requires exactly 8 candidate records, built %d" % len(records))
seen_ids = [r["smoke_record_id"] for r in records]
if seen_ids != ["S%d" % i for i in range(1, 9)]:
    problem("record ids are not S1..S8: %s" % seen_ids)
for r in records:
    empty = [k for k in COLUMNS if r.get(k) in (None, "")]
    if empty:
        problem("%s has empty frozen fields: %s" % (r["smoke_record_id"], empty))
    if r["smoke_record_id"] in ("S1", "S2"):
        if not r["UID"] or not r["pool_anchor_reaction_sha256"]:
            problem("%s is not anchored on a real pool UID + reaction_sha256 pair"
                    % r["smoke_record_id"])
        if re.fullmatch(r"[0-9a-f]{64}", str(r["pool_anchor_reaction_sha256"])) is None:
            problem("%s pool anchor sha256 is not a real hash: %r"
                    % (r["smoke_record_id"], r["pool_anchor_reaction_sha256"]))
    if r["smoke_record_id"] >= "S3" and r["smoke_record_id"] <= "S8":
        if re.fullmatch(r"RT-[0-9a-f]{16}", str(r["reaction_task_id"])) is None:
            problem("%s has no real §7 reaction_task_id: %r"
                    % (r["smoke_record_id"], r["reaction_task_id"]))
        if not r["forward_evidence_hash"] or r["forward_evidence_hash"] == "None":
            problem("%s has no §7 forward evidence hash" % r["smoke_record_id"])
if len({r["selection_input_hash"] for r in records}) != 8:
    problem("selection_input_hash values are not eight distinct hashes")
if len({(r["smoke_record_id"], r["UID"]) for r in records}) != 8:
    problem("duplicated (record, UID) pairs")

# S1/S2 substrates must be traceable to a file, never hand-typed
b_sub = (obs.get("case_b_primary_identity") or {}).get("substrate_smiles")
c_order = (obs.get("c_fallback_probe_identity") or {}).get("candidate_order") or []
if records[0]["substrate"] != b_sub:
    problem("S1 substrate %r is not the teacher case file's expected.substrate.smiles %r"
            % (records[0]["substrate"], b_sub))
if records[1]["substrate"] not in c_order:
    problem("S2 substrate %r is not one of the frozen §6 probe list %s"
            % (records[1]["substrate"], c_order[:3]))

# ------------------------------------------------------------ 6. the §5 minimum coverage table
coverage = {}
for key, present, evidence in (
        ("database_lookup (enviPath known-route)", False,
         "no such node/adapter/condition exists in the teacher fixed topology; see "
         "LOOKUP_THEN_PREDICTION_ORDER=NOT_ESTABLISHED in "
         "ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json"),
        ("controlled_prediction (enviPath-gated fallback)", False,
         "reachable only behind a lookup that does not exist; the graph's own "
         "reaction_prediction node is driven by route_after_reaction's "
         "pipeline_mode/candidate_reactions test"),
        ("proxy (T3A frozen proxy)", None, "decided in §8 stage B / TEST-06"),
        ("staged generated reaction", True,
         "S3—S8 from the three §7 RT-* staged forward records"),
        ("UNMATCHED / fail-closed enzyme", None, "C1 / TEST-09 in §8 stage B"),
        ("MISSING trait", True, "production C8TraitAdapter MISSING classes above"),
        ("OBSERVED trait", bool(sel_b.get("observed_trait_count")),
         "S1 selection under rule 1; if false the observed-coverage gate stays blocked")):
    coverage[key] = {"covered_at_preregistration": present, "evidence": evidence}

# --------------------------------------------------------------------------- 7. deliverables
with open(str(INPUTS_CSV), "w", newline="", encoding="utf-8") as fh:
    wcsv = csv.DictWriter(fh, fieldnames=COLUMNS)
    wcsv.writeheader()
    for r in records:
        wcsv.writerow({k: r.get(k) for k in COLUMNS})

run_cols = ["scenario", "case_label", "substrate", "pipeline_mode", "node_execution_order",
            "pool_route_used", "pool_size", "pool_b_size", "pool_c_size",
            "candidate_reaction_count", "anchor_reaction_smiles", "anchor_reaction_sha256",
            "anchor_source", "anchor_source_tag", "anchor_rhea_id", "anchor_similarity",
            "state_reaction_task_id", "state_error", "fail_closed", "evidence_chain_sha256",
            "selected_UID", "selected_rank", "started_utc", "ended_utc", "wall_s",
            "gpu_node_entered"]


def run_row(run, case_label, sel):
    anchor = anchor_of(run) if run else {}
    return {"scenario": (run or {}).get("scenario"), "case_label": case_label,
            "substrate": (run or {}).get("input_user_query"),
            "pipeline_mode": (run or {}).get("pipeline_mode"),
            "node_execution_order": ">".join((run or {}).get("node_execution_order") or []),
            "pool_route_used": (run or {}).get("pool_route_used"),
            "pool_size": (run or {}).get("pool_size"),
            "pool_b_size": (run or {}).get("enzyme_pool_b_size"),
            "pool_c_size": (run or {}).get("enzyme_pool_c_size"),
            "candidate_reaction_count": (run or {}).get("candidate_reaction_count"),
            "anchor_reaction_smiles": anchor.get("reaction_smiles"),
            "anchor_reaction_sha256": anchor.get("reaction_sha256"),
            "anchor_source": anchor.get("source"),
            "anchor_source_tag": anchor.get("source_tag"),
            "anchor_rhea_id": anchor.get("rhea_id"),
            "anchor_similarity": anchor.get("similarity_score"),
            "state_reaction_task_id": (run or {}).get("reaction_task_id_state"),
            "state_error": (run or {}).get("state_error"),
            "fail_closed": (run or {}).get("state_fail_closed"),
            "evidence_chain_sha256": (run or {}).get("evidence_chain_sha256"),
            "selected_UID": (sel or {}).get("UID"), "selected_rank": (sel or {}).get(
                "preselection_rank"),
            "started_utc": (run or {}).get("started_utc"),
            "ended_utc": (run or {}).get("ended_utc"),
            "wall_s": (run or {}).get("wall_s"),
            "gpu_node_entered": (run or {}).get("enzymecage_gpu_node_entered")}


with open(str(RUNS_CSV), "w", newline="", encoding="utf-8") as fh:
    wc = csv.DictWriter(fh, fieldnames=run_cols)
    wc.writeheader()
    wc.writerow(run_row(run_b, "CASE_B_PRIMARY_SUCCESS(case_1_realrun)", sel_b))
    wc.writerow(run_row(run_c, "CASE_C_FALLBACK_SUCCESS(chosen from §6 probe battery)", sel_c))
    for r in obs.get("c_battery_runs") or []:
        wc.writerow(run_row(r, "CASE_C_battery_candidate", None))

EVID = {
    "section": SECTION,
    "utc": C.now_utc(),
    "purpose": "freeze the eight contract-§5 smoke records before any §8-B full-chain run",
    "authorisation": ("operator rulings 2026-09-10: continue §7—§14 without new manual "
                      "confirmation; do not modify teacher topology; never claim a full T6 pass "
                      "while a gate is unmet"),
    "contract": {"main": C.PRINCIPAL_PROMPT_NAME if hasattr(C, "PRINCIPAL_PROMPT_NAME") else
                 "HPC_ENZYMECAGE_THREE_MODULE_T6_R3_R1_PINNED_PYTHON_FORWARD_REAL_LANGGRAPH_"
                 "20_TEST_FINAL_EXECUTOR_ONLY_PROMPT_2026-09-10.md",
                 "smoke_rules": "original T6 contract §5 (REAL_SMOKE_SELECTION_PREREGISTRATION)"},
    "pinned_interpreter": C.PY,
    "observer": {"script": str(OBS), "script_sha256": sha_file(OBS), "exit_code": rc,
                 "stdout_log": str(OBS_STDOUT), "stderr_log": str(OBS_STDERR),
                 "stdout_sha256": hashlib.sha256(out.encode()).hexdigest(),
                 "stderr_sha256": hashlib.sha256(err.encode()).hexdigest(),
                 "wall_s": wall, "console_tail": out.strip().splitlines()[-3:],
                 "interp": interp, "problems_reported_by_observer": obs.get("problems")},
    "observers": observer_runs,
    "determinism_control": cfg["determinism_control"],
    "pool_order_stability": stability,
    "compile_once": compile_info,
    "graph_module_file": obs.get("graph_module_file"),
    "langgraph": obs.get("langgraph"),
    "settings_resolved": obs.get("settings_resolved"),
    "c8_assets": obs.get("c8_assets"), "c8_adapter": obs.get("c8_adapter"),
    "case_b_primary_identity": obs.get("case_b_primary_identity"),
    "c_fallback_probe_identity": obs.get("c_fallback_probe_identity"),
    "c_eligibility": obs.get("c_eligibility"),
    "forward_identity": obs.get("forward_identity"),
    "staged_selection_rule": obs.get("staged_selection_rule"),
    "run_b_primary": run_b, "run_c_fallback": run_c,
    "c_battery_runs": obs.get("c_battery_runs"),
    "trait_probe_b": b_cls, "trait_probe_c": c_cls, "trait_probe_staged": list(
        staged_trait.values()),
    "selection_b": obs.get("selection_b"), "selection_c": obs.get("selection_c"),
    "staged_forward_rows": staged_rows,
    "asset_bundle": asset_bundle, "reaction_overlay_bundle": overlay_bundle,
    "topology_vs_4_3": {"files": topology_vs_4_3,
                        "all_four_unchanged": all(v["found_in_4_3_gate_text"]
                                                  for v in topology_vs_4_3.values())},
    "records": records, "minimum_coverage_table": coverage,
    "persistence_check": persistence,
    "attempt_history": attempt_history,
    "gpu_used": False, "network_events": obs.get("network_events"),
    "opened_data_files": asset_bundle["opened_data_files"],
    "torch_state": obs.get("torch_state"),
    "preregistered_before_full_chain_run": True,
    "no_sample_switch_after_final_output": True,
    "problem_count": len(problems), "problems": problems,
    "verdict": "PREREGISTRATION_FROZEN" if not problems else "PREREGISTRATION_BLOCKED",
}

md = []
md.append("# Real Smoke Selection Pre-registration (T6-R3-R1 §8 stage A)")
md.append("")
md.append("run_utc: %s" % EVID["utc"])
md.append("pinned interpreter: `%s`" % C.PY)
md.append("observer: `%s` sha256=%s, %d fresh-process runs (total wall %ss), last exit=%s" % (
    OBS.name, sha_file(OBS), OBS_RUNS, wall, rc))
md.append("determinism control: `PYTHONHASHSEED=0` is exported in the *subprocess* environment "
          "(CPython reads it only at interpreter start). Reason, found in the frozen teacher "
          "source and NOT changed here: `build_pool_route_b` calls "
          "`ec_uid_mapper.query(list(all_ec))` on a ``set`` and `build_pool_route_c` returns "
          "`list(uids)` of a ``set``, so the enzyme-pool ORDER drifts between processes while "
          "the pool SET stays identical. This was observed first-hand: two earlier attempts of "
          "this stage (no seed) produced the same 14/17 UID sets in different orders, and the "
          "S1/S2 choices moved - which is why the freeze below is repeated three times under "
          "the control and compared. Reproducible: %s. Any §8 run that consumes these pools must "
          "carry the same control, and the determinism gate must report it explicitly."
          % stability["reproducible"])
md.append("teacher graph: `%s` compiled once with real `langgraph.graph.StateGraph` "
          "(%d nodes); CUDA_VISIBLE_DEVICES=\"\"; torch imported: %s" % (
              obs.get("graph_module_file"), compile_info.get("node_count") or -1,
              (obs.get("torch_state") or {}).get("torch_in_sys_modules")))
md.append("UID map sha: %s (bytes=%s)" % (UID_MAP_SHA, (obs.get("c8_assets") or {}).get(
    "uid_map_bytes")))
md.append("C8 lookup sha: %s (bytes=%s); porTraits NOT enabled" % (
    C8_INDEX_SHA, (obs.get("c8_assets") or {}).get("lookup_index_bytes")))
md.append("§7 forward evidence: `%s` sha256=%s; scores csv sha256=%s" % (
    FWD_JSONL.name, (obs.get("forward_identity") or {}).get("jsonl_sha256"),
    (obs.get("forward_identity") or {}).get("scores_csv_sha256")))
md.append("")
md.append("## Rules (fixed before any full-chain observation)")
md.append("- S1: %s" % S1_RULE)
md.append("- S2: %s" % S2_RULE)
md.append("- S3-S8: %s" % S38_RULE)
md.append("- CASE_B_PRIMARY_SUCCESS / CASE_C_FALLBACK_SUCCESS are **contract scenario labels**: "
          "the teacher tree contains no such identifiers (verified by grep over the frozen "
          "source); the labels are bound to real graph runs as follows, and nothing was "
          "hand-typed to make them fit.")
md.append("")
md.append("## Real runs the selection was made from")
md.append("| label | substrate (source) | executed nodes | route | pool |")
md.append("|---|---|---|---|---|")
md.append("| CASE_B_PRIMARY_SUCCESS | `%s` read from `cases/case_1_realrun.json:"
          "expected.substrate.smiles` | %s | %s | %s |" % (
              run_b.get("input_user_query"), ">".join(run_b.get("node_execution_order") or []),
              run_b.get("pool_route_used"), run_b.get("pool_size")))
md.append("| CASE_C_FALLBACK_SUCCESS | `%s` (first eligible entry of the §6 probe battery, "
          "eligibility = real production route C with pool>=1, tie-break largest pool, then "
          "shortest then lexicographic SMILES) | %s | %s | %s |" % (
              run_c.get("input_user_query"), ">".join(run_c.get("node_execution_order") or []),
              run_c.get("pool_route_used"), run_c.get("pool_size")))
md.append("")
md.append("C battery as really observed (all %d frozen candidates, none hidden):" % len(
    obs.get("c_battery_runs") or []))
for r in obs.get("c_battery_runs") or []:
    md.append("- `%s` route=%s pool=%s nodes=%s error=%s" % (
        r.get("input_user_query"), r.get("pool_route_used"), r.get("pool_size"),
        ">".join(r.get("node_execution_order") or []), (r.get("state_error") or "")[:70]))
md.append("")
md.append("## Selections (real pools, real production C8TraitAdapter)")
md.append("B pool order: `%s`" % json.dumps(run_b.get("enzyme_pool_final_ordered")))
md.append("C pool order: `%s`" % json.dumps(run_c.get("enzyme_pool_final_ordered")))
md.append("S1 selected UID = %s (pool rank %s, OBSERVED traits=%s %s)" % (
    sel_b.get("UID"), sel_b.get("preselection_rank"), sel_b.get("observed_trait_count"),
    sel_b.get("observed_trait_ids")))
md.append("S2 selected UID = %s (pool rank %s, MISSING traits=%s)" % (
    sel_c.get("UID"), sel_c.get("preselection_rank"), sel_c.get("missing_trait_count")))
md.append("Authority-UID-map mapping status of the two selected UIDs (reported, not hidden): "
          "S1 not_mapped=%s (source_signature=%s, uid_map_rows=%s); S2 not_mapped=%s "
          "(source_signature=%s, uid_map_rows=%s) - an unmapped UID yields fifteen MISSING slots "
          "through `_unresolved_annotation`, which does satisfy the S2 rule but is reported as "
          "weak trait coverage rather than dressed up as observed evidence."
          % (sel_b.get("not_mapped"), (sel_b.get("source_signatures") or [""])[0],
             sel_b.get("uid_map_row_count"), sel_c.get("not_mapped"),
             (sel_c.get("source_signatures") or [""])[0], sel_c.get("uid_map_row_count")))
md.append("S1 fallback_to_rank1=%s ; S2 fallback_to_rank1=%s" % (
    (obs.get("selection_b") or {}).get("fallback_to_rank1"),
    (obs.get("selection_c") or {}).get("fallback_to_rank1")))
md.append("Trait probe carrier: `PROBE_CARRIER_NOT_FINAL_HOST` - the real host evidence for the "
          "final chain must come from the real microbe node output in §8 stage B; nothing here "
          "may be reused as a host claim.")
md.append("")
md.append("## S3-S8 source rows (§7 real forward, frozen UID order)")
for row in staged_rows:
    md.append("- `%s` `%s` sha256(prod)=%s evidence_hash=%s real ranks=%s" % (
        row.get("reaction_task_id"), row.get("reaction_smiles"),
        (row.get("reaction_sha256_production") or "")[:16] + "…",
        (row.get("evidence_hash") or "")[:16] + "…", row.get("real_rank_order")))
md.append("")
md.append("## §5 minimum coverage table as early as this stage")
for k, v in coverage.items():
    md.append("- %s -> %s (%s)" % (k, v["covered_at_preregistration"], v["evidence"]))
md.append("")
md.append("## Honesty constraints")
md.append("- No substrate, UID, rank, route or hash was typed by hand; every value in "
          "`REAL_SMOKE_INPUTS.csv` points at a file, a real run, or a production return value.")
md.append("- `wrapper_model_version` / `forward_evidence_hash` stay explicit "
          "`NOT_OBSERVED_AT_PREREGISTRATION` placeholders for S1/S2 until §8-B really runs the "
          "wrapper; they are never guessed forward.")
md.append("- Samples cannot be switched after the final output: the eight selection hashes above "
          "are frozen here, and §8-B/§8-C must reference these record ids verbatim.")
md.append("- `preselection_rank` for S1/S2 is the **pool rank** produced by "
          "`build_enzyme_pool`; if the §8-B real EnzymeCAGE ranking puts these UIDs elsewhere, "
          "the record is kept and both orders are reported - the sample is never swapped.")
md.append("- enviPath known-route lookup is NOT part of the teacher fixed topology "
          "(`LOOKUP_THEN_PREDICTION_ORDER=NOT_ESTABLISHED`, "
          "ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json); because contract §5 counts "
          "\"database lookup\" and \"controlled prediction\" in the minimum coverage table, this "
          "gap also blocks any final READY claim here, independently of this gate's own verdict.")
md.append("- Teacher topology, nodes, routers and edges were only imported and executed, never "
          "edited: `TOPOLOGY_BYTES_EQUAL_4_3_RECORD=%s`." % (
              "YES" if all(v["found_in_4_3_gate_text"]
                           for v in topology_vs_4_3.values()) else "NO"))
md.append("")
PREREG_MD.write_text("\n".join(md) + "\n", encoding="utf-8")

verdict = EVID["verdict"]
EVID["deliverables"] = [str(PREREG_MD), str(INPUTS_CSV), str(RUNS_CSV), str(EVID_JSON)]
EVID["gate"] = {"problem_count": len(problems), "problems": problems,
                "verdict": "PASS" if not problems else "FAIL"}
EVID_JSON.write_text(json.dumps(EVID, ensure_ascii=False, indent=1, default=str),
                     encoding="utf-8")

say("=" * 78)
for ln in ("REAL_LANGGRAPH_COMPILE=%s (1 compile, %d real nodes + __start__/__end__)" % (
            bool(compile_info), len(real_nodes)),
           "REAL_POOL_RUNS=%d (1 B-primary + %d C battery)" % (
               1 + len(obs.get("c_battery_runs") or []), len(obs.get("c_battery_runs") or [])),
           "CASE_B_ROUTE=%s pool=%s -> S1 UID=%s rank=%s observed=%s" % (
               run_b.get("pool_route_used"), run_b.get("pool_size"), sel_b.get("UID"),
               sel_b.get("preselection_rank"), sel_b.get("observed_trait_count")),
           "CASE_C_ROUTE=%s pool=%s -> S2 UID=%s rank=%s missing=%s" % (
               run_c.get("pool_route_used"), run_c.get("pool_size"), sel_c.get("UID"),
               sel_c.get("preselection_rank"), sel_c.get("missing_trait_count")),
           "FRESH_PROCESS_STABILITY=reproducible=%s (%d runs, PYTHONHASHSEED=0)" % (
               stability["reproducible"], OBS_RUNS),
           "S3_S8_FROM_T3B_FORWARD_ROWS=%d" % len(staged_rows),
           "S1_TRAIT_STATUS=%s" % trait_summary(sel_b),
           "S2_TRAIT_STATUS=%s" % trait_summary(sel_c),
           "SMOKE_RECORD_COUNT=%d" % len(records),
           "GPU_NODES_ENTERED=NO (torch imported: %s)" % (
               (obs.get("torch_state") or {}).get("torch_in_sys_modules")),
           "NETWORK_EVENTS=%d" % len(obs.get("network_events") or []),
           "TOPOLOGY_BYTES_EQUAL_4_3_RECORD=%s" % (
               "YES" if all(v["found_in_4_3_gate_text"]
                            for v in topology_vs_4_3.values()) else "NO"),
           "PERSISTENT_INPUTS_CHANGED=%s (%d entries before/after)" % (
               "YES" if changed else "NO", len(PRE)),
           "OBSERVED_TRAIT_COVERAGE=%s" % coverage["OBSERVED trait"]["covered_at_preregistration"],
           "ENVIPATH_DATABASE_LOOKUP_COVERED=NO (teacher contract gap, pending teacher ruling)",
           "T6_FULL_PASS_CLAIMED_HERE=NO",
           "GATE_PROBLEM_COUNT=%d" % len(problems)):
    say(ln)
STDOUT_TXT.write_text("\n".join(report) + "\n", encoding="utf-8")
C.self_audit(__file__, 0, "%s: %s (%d problems)" % (SECTION, verdict, len(problems)))
print("@@P14@@ " + json.dumps({"verdict": verdict, "problems": len(problems),
                               "records": len(records), "rc": rc,
                               "s1": sel_b.get("UID"), "s2": sel_c.get("UID")}))
sys.exit(0 if not problems and rc == 0 else 1)
