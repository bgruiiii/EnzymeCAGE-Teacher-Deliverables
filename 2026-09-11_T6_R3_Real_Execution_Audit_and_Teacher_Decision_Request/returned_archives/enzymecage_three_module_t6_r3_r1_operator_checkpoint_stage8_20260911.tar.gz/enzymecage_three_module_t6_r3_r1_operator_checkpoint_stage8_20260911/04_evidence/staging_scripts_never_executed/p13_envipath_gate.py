#!/usr/bin/env python3
"""T6-R3-R1 p13 — §8 supplementary read-only gate: enviPath known-route lookup -> prediction.

The operator instruction of 2026-09-10/11 asks one question about the teacher's *fixed*
topology: is ``enviPath local known-route lookup`` really the first stage, with

    HIT   -> the database_lookup result is used, depending prediction call count == 0
    MISS  -> the lookup miss is recorded, then depending v3.2 call count == 1
    INVALID INPUT -> both counts == 0 and the pipeline fails closed

This driver answers it by observation only.  It never edits ``src/graph.py``, ``src/state.py``,
any node, router or edge (the topology byte-identity was already gated in §5.3/§4.3 and is
re-confirmed here from the freshly imported module), and it never repurposes one of the other
three reaction-acquisition mechanisms as an "enviPath lookup":

    (1) enviPath / EAWAG known-route lookup          -- category 1, the thing being asked about
    (2) depending v3.2 internal retrieval/prediction -- category 2
    (3) enzyme-pool Route C 4,051 similarity search  -- category 3
    (4) D8-stage BBD / RHEA / literature reference   -- category 4

Everything it reports comes from one child process (``p13b_envipath_observer.py``) that really
builds and compiles ``langgraph.graph.StateGraph`` and really runs it; call counts come from
``sys.settrace``/``threading.settrace`` and reachability from ``sys.addaudithook``.  A non-zero
lookup count would be reported as ESTABLISHED; the observed verdict is written as it is found.
"""
import os
import csv
import shutil
import hashlib
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import r1_common as C  # noqa: E402

SECTION = "§8-supplementary-read-only-gate"
W, RD, LOGS, RA = C.WORK_ROOT, C.RETURN_DIR, C.LOGS, C.RUNTIME_ASSETS
STAGED = str(C.STAGED_REPO)

OBS = W / "scripts" / "p13b_envipath_observer.py"
CFG_PATH = LOGS / "p13_observer_cfg.json"
OUT_JSON = LOGS / "p13_observer_result.json"
OBS_STDOUT = LOGS / "p13_observer.stdout.log"
OBS_STDERR = LOGS / "p13_observer.stderr.log"
OBS_TIMEOUT = 1500

ASSETS = C.RETURN_ROOT / "m3_agent_data_assets" / "assets"
V32 = RA / "t2_v32"
V32_FROZEN = C.V32_FROZEN_REPO
AUTH_DIR = W / "inputs" / "authority" / C.AUTH_ROOTNAME
ORIG_CONTRACT_NAME = ("HPC_ENZYMECAGE_THREE_MODULE_T6_REAL_LANGGRAPH_20_TEST_EIGHT_RECORD_"
                      "END_TO_END_SMOKE_EXECUTOR_ONLY_PROMPT_2026-09-08.md")
ORIG_CONTRACT = AUTH_DIR / ORIG_CONTRACT_NAME

VALID_SMILES = "CN1CCC[C@H]1c1ccc(O)nc1"          # (S)-6-hydroxynicotine, case_1_realrun substrate
NEAR_ISOLATED = "FC(F)(F)Oc1ccc(N)cc1"            # organofluorine ether, outside the 4,051 set
INVALID_QUERY = "帮我查找该污染物最可能的降解途径与相关微生物"

TRACE_JSON = RD / "ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json"
LOOKUP_CSV = RD / "ENVIPATH_LOOKUP_CALLS.csv"
PRED_CSV = RD / "PREDICTION_FALLBACK_CALLS.csv"
SEP_JSON = RD / "LOOKUP_PREDICTION_SOURCE_SEPARATION.json"
STDOUT_TXT = RD / "ENVIPATH_GATE_STDOUT.txt"

EXPECTED_NODES = {"orchestrator", "substrate", "reaction", "reaction_prediction", "enzyme_pool",
                  "enzymecage", "reranking", "microbe", "organism_selection", "trait",
                  "synthesis", "bridge"}
LOOKUP_NAME_RE = re.compile(r"(envipath|eawag|known_route|known-route|database_lookup)", re.I)

problems = []          # evidence-integrity faults of THIS gate (never the scientific verdict)
report = []


def say(msg):
    stamp = datetime.now(timezone.utc).strftime("%H:%M:%S")
    line = "[%s][p13] %s" % (stamp, msg)
    print(line, flush=True)
    report.append(line)


def sha256_file(path):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def art(path, note=""):
    p = Path(path)
    if not p.is_file():
        return {"path": str(p), "present": False, "note": note}
    size = p.stat().st_size
    return {"path": str(p), "present": True, "bytes": size,
            "sha256": sha256_file(p) if size <= (80 << 20) else "NOT_HASHED_TOO_LARGE",
            "note": note}


def utc():
    return C.now_utc()


# ------------------------------------------------------------------ 0. preflight
say("gate=%s question=enviPath known-route lookup -> depending prediction ordering" % SECTION)
if not OBS.is_file():
    say("FATAL observer script missing: %s" % OBS)
    sys.exit(2)
obs_identity = {"path": str(OBS), "bytes": OBS.stat().st_size, "sha256": sha256_file(OBS)}
say("observer identity: bytes=%d sha256=%s…" % (obs_identity["bytes"], obs_identity["sha256"][:16]))

contract = {"path": str(ORIG_CONTRACT), "exists": ORIG_CONTRACT.is_file()}
if contract["exists"]:
    csha = sha256_file(ORIG_CONTRACT)
    pinned = C.AUTH_MEMBERS.get(ORIG_CONTRACT_NAME, (None, None))[1]
    contract.update({"sha256": csha, "pinned_in_authority_payload": pinned,
                     "sha_matches_authority_pin": csha == pinned})
    if csha != pinned:
        problems.append("authority payload contract SHA mismatch: observed %s pinned %s"
                        % (csha, pinned))
    lines = ORIG_CONTRACT.read_text(encoding="utf-8").splitlines()
    hits = [(i + 1, ln.strip()) for i, ln in enumerate(lines)
            if re.search(r"known-route|database|source_tag", ln, re.I)]
    contract["quoted_lines"] = [{"line_no": n, "text": t[:200]} for n, t in hits[:12]]
    contract["order_line_no"] = next((n for n, t in hits if "known-route" in t), None)
    say("original contract %s §3 line %s = %r" % (ORIG_CONTRACT_NAME[:48],
                                                  contract.get("order_line_no"),
                                                  next((t for n, t in hits if "known-route" in t),
                                                       "")[:60]))
else:
    problems.append("original contract file missing, citation impossible")

# teacher topology files must be the same bytes the §5.3/§4.3 gates accepted
topology_identity = {}
for rel in C.TOPOLOGY_FILES:
    p = Path(STAGED) / rel
    topology_identity[rel] = {"present": p.is_file(),
                              "sha256": sha256_file(p) if p.is_file() else None,
                              "bytes": p.stat().st_size if p.is_file() else None}
say("topology files re-hashed from the staged tree (no write performed): %s"
    % ", ".join("%s=%s…" % (k, v["sha256"][:8] if v["sha256"] else "-")
                for k, v in sorted(topology_identity.items())))

# "we did not touch the topology" is only worth anything if it is compared against the bytes an
# earlier gate already accepted, so the §4.3 unified-graph-runtime gate is re-read here and every
# frozen topology file is matched against the SHA it recorded.
P43 = RD / "UNIFIED_GRAPH_RUNTIME_GATE.json"
topology_vs_4_3 = {"gate_file": str(P43), "gate_file_present": P43.is_file(), "files": {}}
if P43.is_file():
    p43_txt = P43.read_text(encoding="utf-8")
    try:
        p43 = json.loads(p43_txt)
    except Exception:
        p43 = None
    # collect every sha the §4.3 gate associates with each topology path
    recorded = {}
    if isinstance(p43, dict):
        stack = [(p43, None)]
        while stack:
            node, parent_key = stack.pop()
            if isinstance(node, dict):
                path_hint = node.get("path") or node.get("file") or parent_key
                sha = node.get("sha256") or node.get("source_sha256") or node.get(
                    "definition_sha256")
                if isinstance(path_hint, str) and isinstance(sha, str):
                    for rel, val in topology_identity.items():
                        if path_hint.endswith(rel) and val["sha256"]:
                            recorded.setdefault(rel, set()).add(sha)
                if isinstance(sha, str):
                    for rel, val in topology_identity.items():
                        if val["sha256"] and sha == val["sha256"]:
                            recorded.setdefault(rel, set()).add(sha)
                for k, v in node.items():
                    if isinstance(v, (dict, list)):
                        stack.append((v, k))
            elif isinstance(node, list):
                for item in node:
                    stack.append((item, parent_key))
    for rel, val in sorted(topology_identity.items()):
        seen = recorded.get(rel, set())
        match = bool(val["sha256"]) and val["sha256"] in seen
        topology_vs_4_3["files"][rel] = {
            "sha256_now": val["sha256"], "sha256_recorded_in_4_3": sorted(seen),
            "byte_identical_to_4_3": match,
            "fallback_substring_hit": None if match else (val["sha256"][:16] in p43_txt)}
        if not match and val["sha256"][:16] not in p43_txt:
            problems.append("topology file %s does not match the SHA recorded by §4.3 "
                            "(now=%s there=%s)" % (rel, val["sha256"][:16],
                                                   sorted(seen)[:2]))
    topology_vs_4_3["all_four_unchanged_since_4_3"] = all(
        f["byte_identical_to_4_3"] or f["fallback_substring_hit"]
        for f in topology_vs_4_3["files"].values())
    say("topology vs §4.3 gate: unchanged_all_4=%s (%s)"
        % (topology_vs_4_3["all_four_unchanged_since_4_3"],
           ", ".join("%s:%s" % (k.split("/")[-1], "MATCH" if v["byte_identical_to_4_3"]
                                else ("IN_GATE" if v["fallback_substring_hit"] else "DRIFT"))
                     for k, v in sorted(topology_vs_4_3["files"].items()))))
else:
    problems.append("§4.3 gate JSON missing, topology-unchanged claim cannot be cross-checked")

# databases/artefacts of the four categories ------------------------------------
artifacts = {
    "category1_envipath_eawag_known_route": {
        "eawag_lookup_engine_D": art(V32 / "reaction_analogy/eawag_lookup.py",
                                     "known-pathway lookup engine; lives INSIDE frozen v3.2"),
        "donor_product_snapshot": art(V32 / "reaction_analogy/data/bbd_expand/donor_product.jsonl",
                                      "the 1,066-reaction EAWAG-BBD curated snapshot Engine D reads"),
        "lib_envipath_templates": art(V32 / "reaction_v3/data/lib_envipath/templates.tsv.gz",
                                      "enviPath template library (v3 side, not v3.2 graph input)"),
        "lib_envipath_provenance": art(V32 / "reaction_v3/data/lib_envipath/PROVENANCE.txt"),
        "envipath_rules_module": art(V32 / "reaction_analogy/src/ra/envipath_rules.py"),
        "envipath_ra_module": art(V32 / "reaction_analogy/src/ra/envipath.py"),
        "envipath_ranker": art(V32 / "data/bbd_v31/envipath_ranker.txt"),
        "in_teacher_staged_tree": {
            "any_envipath_snapshot": bool(list(Path(STAGED).rglob("*envipath*")))
            or bool(list(Path(STAGED).rglob("*eawag*"))),
            "staged_data_dir_exists": (Path(STAGED) / "data").is_dir()},
    },
    "category2_depending_v32_internal": {
        "single_smiles_v32_entry": art(C.V32_ENTRY, "the only frozen v3.2 public entrypoint"),
        "frozen_repo_same_bytes": (str(C.V32_ENTRY) != "" and
                                   (V32 / "reaction_analogy/single_smiles_v32.py").is_file()),
        "teacher_adapter": art(Path(STAGED) / "src/tools/depending_v32_adapter.py",
                               "present but wired to no node"),
    },
    "category3_route_c_similarity": {
        "reference_reaction_index": art(ASSETS / "route_c/reference_reaction_index.csv.gz",
                                        "4,051 query-excluded reference reactions"),
        "reference_morgan_radius8": art(ASSETS / "route_c/reference_morgan_radius8.pkl",
                                        "Morgan radius=8 fingerprints, Tanimoto ranking"),
        "implementation": art(Path(STAGED) / "src/tools/reaction_retriever.py"),
    },
    "category4_d8_bbd_rhea_literature": {
        "route_b_ec_to_uid": art(ASSETS / "route_b/ec_to_uid_query_excluded.csv.gz",
                                 "fair EC->UID table, enzyme-pool B-primary source"),
        "rhea2ec": art(ASSETS / "rhea140/rhea2ec.tsv", "RHEA -> EC reference mapping"),
        "rhea_reaction_smiles": art(ASSETS / "rhea140/rhea-reaction-smiles.tsv"),
        "d4_uid_availability": art(ASSETS / "d4/uid_asset_availability.csv.gz",
                                   "already SHA-verified in §6.2; re-hashed here for identity"),
        "organism_aggregator_rule_source_note": (
            "src/utils/organism_aggregator.py cites "
            "TEACHER_REPLY_MTD5_ACCEPTED_AND_MTD1_D8_DECISIONS_2026-07-16.md"),
        "chem_name_resolver": art(Path(STAGED) / "src/tools/chem_name_resolver.py",
                                  "PubChem/CHEBI substrate NAME resolution, not a route lookup"),
    },
    "graph_prediction_fallback_engine": {
        "reaction_predictor": art(Path(STAGED) / "src/tools/reaction_predictor.py",
                                  "BioTransformer 3.0 ENVMICRO (EAWAG-BBD/PPS rule lineage)"),
        "biotransformer_jar_env": "BIOTRANSFORMER_JAR=%s" % (
            os.environ.get("BIOTRANSFORMER_JAR") or "unset on this offline host"),
    },
}
say("artifacts hashed: %d entries across the four source categories"
    % sum(len(v) for v in artifacts.values()))

# ------------------------------------------------------------------ 1. run the observer
def archive_prior_attempt():
    """Never overwrite evidence of an earlier run of this gate; copy it aside and keep going."""
    prior = [p for p in (TRACE_JSON, LOOKUP_CSV, PRED_CSV, SEP_JSON, STDOUT_TXT, OUT_JSON,
                         OBS_STDOUT, OBS_STDERR) if p.exists()]
    if not prior:
        return None
    n = 1
    while True:
        ad = LOGS / ("p13_attempt_%d" % n)
        if not ad.exists() or not any(ad.iterdir()):
            break
        n += 1
    ad.mkdir(parents=True, exist_ok=True)
    for p in prior:
        shutil.copy2(str(p), str(ad / p.name))
    verdict = problems_n = None
    if TRACE_JSON.is_file():
        try:
            old = json.loads(TRACE_JSON.read_text(encoding="utf-8"))
            verdict = old.get("verdict")
            problems_n = old.get("problem_count")
        except Exception:
            verdict = "UNREADABLE"
    return {"attempt": n, "archived_to": str(ad), "files": [p.name for p in prior],
            "prior_verdict": verdict, "prior_problem_count": problems_n}


prior_archive = archive_prior_attempt()
if prior_archive:
    say("prior run of this gate archived to %s (verdict=%s problems=%s)"
        % (prior_archive["archived_to"], prior_archive["prior_verdict"],
           prior_archive["prior_problem_count"]))

attempt_history = []
for adir in sorted(LOGS.glob("p13_attempt_*")):
    atrace = adir / TRACE_JSON.name
    rec = {"archive_dir": str(adir), "trace_present": atrace.is_file()}
    if atrace.is_file():
        try:
            old = json.loads(atrace.read_text(encoding="utf-8"))
            rec.update({"verdict": old.get("verdict"),
                        "problem_count": old.get("problem_count"),
                        "aggregates": old.get("aggregates"),
                        "utc": old.get("utc")})
        except Exception as exc:
            rec["read_error"] = repr(exc)[:160]
    attempt_history.append(rec)

cfg = {
    "staged": STAGED,
    "out_json": str(OUT_JSON),
    "pinned_py": C.PY,
    "valid_smiles": VALID_SMILES,
    "invalid_query": INVALID_QUERY,
    "near_isolated_smiles": NEAR_ISOLATED,
    "env": {
        "M3_AGENT_DATA_ASSETS_ROOT": str(ASSETS),
        "C8_LOOKUP_ROOT": "/tmp/t5b_test_cache/enzymecage_m4b_c8_1_lookup_index_delta_review_"
                          "dependency_payload_rerun2_repack_fix_20260820",
        "C8_UID_SOURCE_MAP_PATH": "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_"
                                  "Result_Summaries/enzymecage_m4b_c8_1_lookup_index_delta_"
                                  "review_dependency_payload_rerun1_20260820/_input_payload/"
                                  "enzymecage_m4b_c8_1_dependency_payload_20260820/inputs/"
                                  "uid_to_source/uid_to_source_keep_bacteria_fungi_archaea.csv",
        "DEPENDING_V32_RUNTIME_ROOT": str(V32_FROZEN),
        "D4_WRAPPER_ROOT": str(C.D4_WRAPPER_PARENT),
        "ENZYMECAGE_CODE_ROOT": C.CODE_ROOT,
        "ENZYMECAGE_V1_PACKAGE_ROOT": str(C.V1_OVERLAY),
        "ENZYMECAGE_DRY_RUN": "0",
    },
}
CFG_PATH.parent.mkdir(parents=True, exist_ok=True)
CFG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")

env = C.base_env({"CUDA_VISIBLE_DEVICES": ""})
t_run = time.monotonic()
rc, out, err = C.run_py([OBS, str(CFG_PATH)], cwd=W, env=env,
                        note="§8 read-only enviPath lookup->prediction observability probe "
                             "(real StateGraph compile + 4 graph runs, no CUDA, no write)",
                        timeout=OBS_TIMEOUT, label="p13_observer")
wall = round(time.monotonic() - t_run, 1)
say("observer exit=%d wall=%ss stdout=%dB stderr=%dB" % (rc, wall, len(out), len(err)))
say("observer raw log: %s / %s" % (OBS_STDOUT.name, OBS_STDERR.name))

obs = {}
if OUT_JSON.is_file():
    obs = json.loads(OUT_JSON.read_text(encoding="utf-8"))
if rc != 0 or not obs:
    problems.append("observer failed rc=%d tail=%s" % (rc, (err or out).strip().splitlines()[-6:]))

scen = {s["scenario"]: s for s in obs.get("scenarios", [])}
interp = obs.get("interp", {})
if interp and interp.get("is_pinned") is not True:
    problems.append("observer interpreter is not the pinned ${PY}: %r" % interp)

# fail-loud on the counting defect that superseded attempt 1: an angle-bracket frame
# (<listcomp>/<genexpr>/<lambda>) is not a function entry and must never be traced as one.
angle_keys = sorted({k for s in scen.values() for k in (s.get("calls") or {}) if "<" in k})
if angle_keys:
    problems.append("angle-bracket frames were counted as calls: %s" % angle_keys[:5])
for tag, s in scen.items():
    cnt = s.get("counts") or {}
    if cnt.get("route_c_retrieval_calls", 0) > 4:
        problems.append("call count inflated in %s: route_c_retrieval_calls=%d (the reaction "
                        "node can call it at most once per run)" % (tag,
                                                                     cnt["route_c_retrieval_calls"]))
    if cnt.get("enzyme_pool_build_calls", 0) > 2:
        problems.append("call count inflated in %s: enzyme_pool_build_calls=%d"
                        % (tag, cnt["enzyme_pool_build_calls"]))

# ------------------------------------------------------------------ 2. structural verdict
lg = obs.get("langgraph", {})
gnodes = obs.get("graph_nodes", {})
node_names = set(gnodes)
lookup_nodes = sorted(n for n in node_names if LOOKUP_NAME_RE.search(n))
drawn = obs.get("graph_drawn", {})
edges = drawn.get("edges") or []
router_src = obs.get("routers", {}).get("route_after_reaction_source", "")

LOOKUP_CONDITION_RE = re.compile(r"(envipath|eawag|known_route|database_lookup|lookup\()", re.I)
cond_is_lookup = bool(LOOKUP_CONDITION_RE.search(router_src))

struct = {
    "real_langgraph_stategraph": lg.get("stategraph_is_real_langgraph"),
    "workflow_type": lg.get("workflow_type"), "compiled_type": lg.get("compiled_type"),
    "checkpointer": lg.get("checkpointer"),
    "langgraph_module_file": lg.get("module_file"),
    "node_count_observed": len(node_names),
    "node_set_equals_frozen_teacher_12": node_names == EXPECTED_NODES,
    "unexpected_nodes": sorted(node_names - EXPECTED_NODES),
    "missing_nodes": sorted(EXPECTED_NODES - node_names),
    "lookup_named_nodes": lookup_nodes,
    "envipath_lookup_node_present": bool(lookup_nodes),
    "edge_count": len(edges),
    "conditional_edges": [{"source": e.get("source"), "target": e.get("target"),
                           "label": e.get("data")} for e in edges if e.get("conditional")],
    "reaction_prediction_edge_present": any(
        e.get("source") == "reaction" and e.get("target") == "reaction_prediction"
        for e in edges),
    "route_after_reaction_condition_is_a_lookup_test": cond_is_lookup,
    "route_after_reaction_source_sha256": obs.get("routers", {}).get("router_source_sha256"),
    "conditional_branch_targets": obs.get("conditional_branch_targets"),
    "node_callables": {n: {"callable": (gnodes[n].get("callable") or {}).get("module"),
                           "qualname": (gnodes[n].get("callable") or {}).get("qualname"),
                           "file": (gnodes[n].get("callable") or {}).get("file"),
                           "definition_sha256": (gnodes[n].get("callable") or {}).get(
                               "definition_sha256")}
                       for n in sorted(gnodes)},
}
if struct["node_count_observed"] and not struct["node_set_equals_frozen_teacher_12"]:
    problems.append("compiled node set drifted from the frozen teacher 12: missing=%s extra=%s"
                    % (struct["missing_nodes"], struct["unexpected_nodes"]))
if struct["envipath_lookup_node_present"]:
    problems.append("unexpected lookup-named node present: %s" % struct["lookup_named_nodes"])

reach = obs.get("sys_modules_reachability", {})
adapter_imported = (reach.get("src.tools.depending_v32_adapter") or {}).get("imported")
v32_imported = any((reach.get(m) or {}).get("imported") for m in
                   ("reaction_analogy.single_smiles_v32", "depending_frozen_single_smiles_v32",
                    "reaction_analogy.eawag_lookup", "eawag_lookup", "envipath"))
import_audit = obs.get("import_audit", {})
envipath_modules_imported = sorted(m for m in import_audit.get("watchlisted_import_modules", [])
                                   if LOOKUP_NAME_RE.search(m))
sock = obs.get("socket_audit", {})
if sock.get("event_count"):
    problems.append("network activity observed during graph runs: %s" % sock.get("events")[:3])

total_lookup_calls = sum(s["counts"]["envipath_known_route_lookup_calls"] for s in scen.values())
total_route_c = sum(s["counts"]["route_c_retrieval_calls"] for s in scen.values())
total_bio = sum(s["counts"]["biotransformer_prediction_calls"] for s in scen.values())
total_v32 = sum(s["counts"]["depending_v32_adapter_calls"] for s in scen.values())

ORDER_ESTABLISHED = bool(struct["envipath_lookup_node_present"] and cond_is_lookup
                         and total_lookup_calls > 0)
verdict = "ESTABLISHED" if ORDER_ESTABLISHED else "NOT_ESTABLISHED"

# scenario-by-scenario conformance against the three required branches
s_inv = scen.get("S_INVALID_INPUT", {})
s_hit = scen.get("S_HIT_LIKE_M3", {})
s_miss = scen.get("S_MISS_PROBE_M5", {})
s_lbl = scen.get("S_ENVIPATH_LABEL_BRIDGE", {})

branch_check = {
    "HIT": {
        "expected_by_operator": "use database_lookup result; depending prediction call count 0",
        "observed": {"node_order": s_hit.get("node_execution_order"),
                     "lookup_calls": (s_hit.get("counts") or {}).get(
                         "envipath_known_route_lookup_calls"),
                     "reaction_node_route_c_calls": (s_hit.get("counts") or {}).get(
                         "route_c_retrieval_calls"),
                     "prediction_calls": (s_hit.get("counts") or {}).get(
                         "biotransformer_prediction_calls"),
                     "entered_enzyme_pool": (s_hit.get("terminal_state") or {}).get(
                         "pool_route_used") is not None,
                     "pool_route_used": (s_hit.get("terminal_state") or {}).get("pool_route_used"),
                     "candidate_count": (s_hit.get("terminal_state") or {}).get(
                         "candidate_reaction_count"),
                     "first_candidate": (s_hit.get("terminal_state") or {}).get("first_candidate")},
        "status": ("PASS" if ORDER_ESTABLISHED else
                   "NOT_IMPLEMENTED_BY_TEACHER_TOPOLOGY"),
        "note": ("what actually runs is Route C similarity retrieval over the 4,051 reference "
                 "reactions, which returns top-k unconditionally and therefore has no HIT/MISS "
                 "semantics at all"),
    },
    "MISS": {
        "expected_by_operator": "record lookup miss, then depending v3.2 call count 1",
        "observed": {"node_order": s_miss.get("node_execution_order"),
                     "lookup_calls": (s_miss.get("counts") or {}).get(
                         "envipath_known_route_lookup_calls"),
                     "reaction_prediction_node_calls": (s_miss.get("counts") or {}).get(
                         "reaction_prediction_node_calls"),
                     "depending_v32_calls": total_v32,
                     "candidate_count": (s_miss.get("terminal_state") or {}).get(
                         "candidate_reaction_count"),
                     "pool_route_used": (s_miss.get("terminal_state") or {}).get("pool_route_used")},
        "status": "NOT_IMPLEMENTED_BY_TEACHER_TOPOLOGY",
        "note": ("no lookup result is tested on any edge, so a MISS cannot be produced; "
                 "reaction_prediction is reachable only through route_after_reaction's "
                 "m5 empty-candidate/error branch, and even there it invokes BioTransformer "
                 "ENVMICRO, never depending v3.2 and never enviPath"),
    },
    "INVALID_INPUT": {
        "expected_by_operator": "lookup and prediction call counts both 0, fail closed",
        "observed": {"node_order": s_inv.get("node_execution_order"),
                     "lookup_calls": (s_inv.get("counts") or {}).get(
                         "envipath_known_route_lookup_calls"),
                     "prediction_calls": (s_inv.get("counts") or {}).get(
                         "biotransformer_prediction_calls"),
                     "fail_closed": (s_inv.get("terminal_state") or {}).get("fail_closed"),
                     "error": (s_inv.get("terminal_state") or {}).get("error"),
                     "raised": s_inv.get("raised")},
        "status": "OBSERVED_FAIL_CLOSED_BUT_NOT_BY_A_LOOKUP",
        "note": ("the counts are 0 because no lookup/prediction stage exists on that path, not "
                 "because a lookup guarded them; fail-closed itself is real and observable"),
    },
    "LABEL_ONLY_ENVIPATH": {
        "expected_by_operator": "do not present a non-enviPath mechanism as an enviPath lookup",
        "observed": {"node_order": s_lbl.get("node_execution_order"),
                     "lookup_calls": (s_lbl.get("counts") or {}).get(
                         "envipath_known_route_lookup_calls"),
                     "bridge_result": (s_lbl.get("terminal_state") or {}).get("bridge_result")},
        "status": "MISATTRIBUTION_HAZARD_CONFIRMED",
        "note": ("src/schemas/bridge.py:27 defaults source_tool to the literal string "
                 "\"enviPath\" and multi_step_bridge_node copies that label verbatim onto every "
                 "split step, so a graph output can carry source_tool=\"enviPath\" while zero "
                 "lookup calls happened. This gate records the label as a label only."),
    },
}

gate = {
    "gate": "ENVIPATH_LOOKUP_THEN_PREDICTION_ORDER",
    "verdict": verdict,
    "verdict_code_line": "LOOKUP_THEN_PREDICTION_ORDER=%s" % verdict,
    "section": SECTION,
    "task_id": C.TASK_ID,
    "utc": utc(),
    "requested_by": "operator instruction 2026-09-10/11 (supplementary read-only evidence gate)",
    "question": ("does the teacher's fixed LangGraph topology implement "
                 "enviPath local known-route lookup -> HIT / MISS / INVALID INPUT with the "
                 "stated call-count discipline"),
    "read_only_guarantee": {
        "teacher_graph_state_router_edge_modified": False,
        "teacher_tree_written": False,
        "monkeypatch_applied": False,
        "custom_StateGraph_subclass": False,
        "nodes_called_by_hand_to_fake_main_graph": False,
        "observation_apis_used": ["sys.settrace", "threading.settrace", "sys.addaudithook",
                                  "inspect", "langgraph compiled.get_graph()",
                                  "compiled.stream(stream_mode='updates')",
                                  "compiled.get_state()"],
        "cuda_touched": False,
        "cuda_visible_devices_forced": "",
        "network_events_observed": sock.get("event_count"),
    },
    "pinned_python": C.PY,
    "attempt": 1 + len(attempt_history),
    "prior_attempt_archive": prior_archive,
    "attempt_history": attempt_history,
    "supersedes_note": ("attempt 1 counted <listcomp>/<genexpr>/<lambda> frames as function "
                        "entries (route_c_retrieval_calls=16974 per scenario instead of 1) and "
                        "the probe matched its own filename; attempt 2 additionally stringified "
                        "the whole import-audit argument tuple, so 1,052 unrelated modules "
                        "matched on the staged path substring 'depending'. Both are fixed in the "
                        "observer; the call counts and the import reachability set reported here "
                        "come from the corrected probe, and every earlier artefact is kept in "
                        "the archive directories." if attempt_history else None),
    "observer": {
        "script": str(OBS), "identity": obs_identity, "exit_code": rc,
        "wall_s": wall, "stdout_log": str(OBS_STDOUT), "stderr_log": str(OBS_STDERR),
        "raw_result_json": str(OUT_JSON),
        "raw_result_sha256": sha256_file(OUT_JSON) if OUT_JSON.is_file() else None,
        "interp": interp, "graph_module_import": obs.get("graph_module_import"),
        "scenario_status": {k: {"nodes": v.get("node_execution_order"),
                                "raised": v.get("raised"), "wall_s": v.get("wall_s")}
                            for k, v in scen.items()},
    },
    "teacher_contract_citation": contract,
    "topology_identity_reconfirmed": topology_identity,
    "topology_unchanged_since_4_3": topology_vs_4_3,
    "structural_findings": struct,
    "module_reachability": reach,
    "import_audit": import_audit,
    "socket_audit": sock,
    "aggregates": {
        "envipath_known_route_lookup_calls_total": total_lookup_calls,
        "route_c_similarity_retrieval_calls_total": total_route_c,
        "biotransformer_envmicro_prediction_calls_total": total_bio,
        "depending_v32_calls_total": total_v32,
        "depending_v32_adapter_imported_during_graph_runs": adapter_imported,
        "any_v32_or_envipath_module_imported_during_graph_runs": v32_imported,
        "envipath_named_modules_imported": envipath_modules_imported,
        "teacher_functions_called_total": sum(
            s["counts"]["teacher_functions_called_total"] for s in scen.values()),
    },
    "branch_conformance": branch_check,
    "evidence_lines": {
        "1_compiled_topology": "12 nodes, none named/implementing a known-route lookup",
        "2_static_source_survey": obs.get("envipath_string_survey"),
        "3_adapter_wiring": "no node, router or edge imports depending_v32_adapter "
                            "(grep of staged tree + sys.modules reachability)",
        "4_public_state_schema": obs.get("state_contract"),
        "5_real_execution": "call counts + import/socket audit from 4 real graph runs",
    },
    "four_source_separation_file": str(SEP_JSON),
    "teacher_contract_gap": {
        "status": "TEACHER_FIXED_TOPOLOGY_CONTRACT_GAP_PENDING_ADJUDICATION",
        "awaiting": "黄老师 (teacher) ruling",
        "gap": ("the original T6 contract §3 line %s fixes the main-graph order as "
                "'known-route lookup / controlled prediction', and line 138 requires "
                "database/BioTransformer/ECLIPSE/depending source_tag to survive the whole "
                "chain; the teacher's frozen topology implements the controlled-prediction part "
                "(reaction_prediction node) but contains no known-route lookup node, adapter "
                "wiring or conditional order, and the public state schema has no "
                "database/known-route reaction source tag at all "
                "(CandidateReaction.source is Literal['retrieved','predicted'])"
                % contract.get("order_line_no")),
        "not_done_by_this_round": [
            "拓扑未被自行修改 (no node, edge, router or state field was added)",
            "depending v3.2 内部 retrieval 未被写成 enviPath",
            "Route C 4051 相似检索未被写成 enviPath lookup",
            "D8/RHEA/PubChem 参考搜索未被写成 enviPath lookup",
        ],
        "effect_on_final_status": {
            "T6_FULL_PASS_CLAIMED": False,
            "statement": ("this round reports the four enviPath evidence files plus "
                          "LOOKUP_THEN_PREDICTION_ORDER=NOT_ESTABLISHED and must NOT be read as "
                          "T6 fully passed on this point; the rest of §8-§14 proceeds and its "
                          "own gates are reported separately"),
        },
        "options_for_adjudication": [
            "A: teacher adds an enviPath/EAWAG known-route lookup node + conditional "
            "HIT/MISS edge + a database source_tag, then this gate is re-run (needs a new "
            "authority payload because it changes the frozen topology)",
            "B: teacher rules that the fixed topology intentionally has no known-route lookup "
            "and amends contract §3, after which this gate closes as NOT_APPLICABLE_BY_CONTRACT",
            "C: teacher rules that the Route C similarity retrieval is the intended stand-in "
            "for 'known-route lookup'; this round then needs an explicit source_tag decision so "
            "category 3 is never reported as category 1",
        ],
    },
    "smoke_and_one_run_discipline": {
        "these_graph_runs_are_frozen_smoke_records": False,
        "why": ("this is the operator's supplementary ordering gate; every run stops at "
                "enzyme_pool or reaction, never reaches the EnzymeCAGE node, loads no protein "
                "asset and consumes no CUDA context"),
        "frozen_smoke_preregistration_still_required_before_whole_chain": True,
        "determinism_double_run_budget_consumed_here": False,
    },
    "problems": problems,
    "problem_count": len(problems),
}

# ------------------------------------------------------------------ 3. TRACE json
TRACE = dict(gate)
TRACE["records"] = []


def pool_anchor(ts):
    """Compact identifier of the reaction that actually reaches the enzyme pool in one run.

    The single-step path carries no ``state.reaction_task_id`` (only the bridge node writes that
    key), so its real pool-entry anchor is the G5 pair field ``reaction_sha256``; multistep bridge
    runs are anchored by ``<route_id>:step<n>``.  Reporting the unset task id alone would leave a
    reader unable to tell a topology fact from a probe failure.
    """
    pid = ts.get("pool_entry_identifiers") or {}
    if ts.get("reaction_task_id"):
        steps = (ts.get("bridge_result") or {}).get("steps") or []
        alls = [st.get("reaction_task_id") for st in steps] or [ts.get("reaction_task_id")]
        return "bridge_task_id=%s(total %d steps)" % (",".join(str(a) for a in alls[:3]), len(alls))
    first = (pid.get("sampled_first_3") or [{}])[0]
    sha = first.get("reaction_sha256")
    if not sha:
        return "NONE:no candidate reaction reached the pool (fail-closed before reaction node)"
    return ("candidate_sha256=%s…(source=%s,source_tag=%s,rhea=%s,pool_size=%s)"
            % (sha[:16], first.get("source"), first.get("source_tag") or "null",
               first.get("rhea_id") or "null", ts.get("pool_size")))


for tag, s in (("S_INVALID_INPUT", s_inv), ("S_HIT_LIKE_M3", s_hit),
               ("S_MISS_PROBE_M5", s_miss), ("S_ENVIPATH_LABEL_BRIDGE", s_lbl)):
    s["_pool_anchor"] = pool_anchor(s.get("terminal_state") or {})

for tag, s in (("S_INVALID_INPUT", s_inv), ("S_HIT_LIKE_M3", s_hit),
               ("S_MISS_PROBE_M5", s_miss), ("S_ENVIPATH_LABEL_BRIDGE", s_lbl)):
    ts = s.get("terminal_state") or {}
    counts = s.get("counts") or {}
    timing = s.get("timing") or {}
    TRACE["records"].append({
        "record_id": tag,
        "input_identity": s.get("input_identity"),
        "envipath_adapter_module_callable": {
            "adapter_present_in_teacher_tree": str(
                Path(STAGED) / "src/tools/depending_v32_adapter.py"),
            "adapter_wired_into_any_graph_node": False,
            "lookup_module_resolved_at_runtime": None,
            "lookup_callable_invoked": None,
            "lookup_call_count": counts.get("envipath_known_route_lookup_calls", 0),
        },
        "local_snapshot_or_database_identity": {
            "enviPath/EAWAG snapshot read by this run": None,
            "nearest_snapshot_on_disk (unreachable from graph)":
                artifacts["category1_envipath_eawag_known_route"]["donor_product_snapshot"],
            "databases_actually_read_by_this_run": {
                "route_c_reference_index":
                    artifacts["category3_route_c_similarity"]["reference_reaction_index"],
                "route_c_morgan_radius8":
                    artifacts["category3_route_c_similarity"]["reference_morgan_radius8"],
                "route_b_ec_to_uid":
                    artifacts["category4_d8_bbd_rhea_literature"]["route_b_ec_to_uid"],
                "rhea2ec": artifacts["category4_d8_bbd_rhea_literature"]["rhea2ec"],
                "d4_uid_availability":
                    artifacts["category4_d8_bbd_rhea_literature"]["d4_uid_availability"]},
        },
        "lookup_started_utc": (timing.get("any_envipath_known_route_lookup") or {}).get(
            "started_utc"),
        "lookup_ended_utc": (timing.get("any_envipath_known_route_lookup") or {}).get(
            "ended_utc"),
        "lookup_hit_miss_error": ("NO_LOOKUP_PERFORMED: enviPath known-route lookup node is "
                                  "absent from the fixed topology"),
        "lookup_result_count": 0,
        "depending_prediction_call_count": counts.get("depending_v32_adapter_calls", 0),
        "graph_prediction_fallback_call_count": counts.get("biotransformer_prediction_calls", 0),
        "prediction_started_utc": (timing.get("graph_prediction_fallback") or {}).get(
            "started_utc"),
        "source_tag": {"candidate_reactions_first": (ts.get("first_candidate") or {}).get(
                           "source_tag"),
                       "candidate_source": (ts.get("first_candidate") or {}).get("source"),
                       "predicted_first": (ts.get("first_predicted") or {}).get("source_tag"),
                       "bridge_step_labels": [st.get("source_tool")
                                              for st in (ts.get("bridge_result") or {}).get(
                                                  "steps", [])]},
        "reaction_task_id_into_pool": ts.get("reaction_task_id"),
        "pool_entry_reaction_identifier": s.get("_pool_anchor"),
        "pool_entry_reaction_identifiers": ts.get("pool_entry_identifiers"),
        "reaction_task_id_meaning": ("None here means the fixed topology leaves the anchor unset "
                                     "on the single-step path; it is only written by the bridge "
                                     "node for multistep routes"),
        "fail_closed": ts.get("fail_closed"), "error": ts.get("error"),
        "node_execution_order": s.get("node_execution_order"),
        "evidence_stages": ts.get("evidence_stages"),
        "calls": s.get("calls"),
        "raw_log": {"stdout": str(OBS_STDOUT), "stderr": str(OBS_STDERR),
                    "observer_result_json": str(OUT_JSON)},
        "exit_code": rc,
    })
TRACE["operator_field_checklist"] = {
    # every field the operator demanded, and exactly where it is realised in this delivery
    "input identity": ["records[].input_identity",
                       "ENVIPATH_LOOKUP_CALLS.csv:input_identity",
                       "PREDICTION_FALLBACK_CALLS.csv:input_identity"],
    "enviPath adapter/module/callable": ["records[].envipath_adapter_module_callable",
                                         "csv:candidate_lookup_module/candidate_lookup_callable/"
                                         "callable_location"],
    "local snapshot/database identity + SHA": [
        "records[].local_snapshot_or_database_identity",
        "csv:local_snapshot_or_database_identity + snapshot_sha256"],
    "lookup started/ended time": ["records[].lookup_started_utc/lookup_ended_utc",
                                  "csv:lookup_started_utc/lookup_ended_utc"],
    "lookup hit/miss/error": ["records[].lookup_hit_miss_error", "csv:lookup_hit_miss_error"],
    "lookup result count": ["records[].lookup_result_count", "csv:lookup_result_count"],
    "depending prediction call count": ["records[].depending_prediction_call_count",
                                        "csv:depending_prediction_call_count",
                                        "PREDICTION_FALLBACK_CALLS.csv:call_count"],
    "prediction started time": ["records[].prediction_started_utc",
                                "csv:prediction_started_utc",
                                "PREDICTION_FALLBACK_CALLS.csv:started_utc"],
    "source_tag": ["records[].source_tag", "csv:source_tag"],
    "reaction_task_id entering the enzyme pool": [
        "records[].reaction_task_id_into_pool",
        "records[].pool_entry_reaction_identifiers (per-candidate G5 reaction_sha256 anchors)",
        "csv:pool_entry_reaction_identifier"],
    "raw log and exit code": ["records[].raw_log", "records[].exit_code",
                              "ENVIPATH_GATE_STDOUT.txt", "logs/p13_observer.{stdout,stderr}.log"],
}
TRACE_JSON.write_text(json.dumps(TRACE, ensure_ascii=False, indent=1), encoding="utf-8")
say("wrote %s (%d records)" % (TRACE_JSON.name, len(TRACE["records"])))

# ------------------------------------------------------------------ 4. ENVIPATH_LOOKUP_CALLS.csv
LOOKUP_FIELDS = ["record_id", "input_identity", "candidate_lookup_module",
                 "candidate_lookup_callable", "callable_location",
                 "is_envipath_known_route_lookup", "local_snapshot_or_database_identity",
                 "snapshot_sha256", "lookup_started_utc", "lookup_ended_utc",
                 "lookup_call_count", "lookup_hit_miss_error", "lookup_result_count",
                 "depending_prediction_call_count", "prediction_started_utc", "source_tag",
                 "reaction_task_id_into_pool", "pool_entry_reaction_identifier", "evidence_kind",
                 "raw_log", "exit_code"]
donor = artifacts["category1_envipath_eawag_known_route"]["donor_product_snapshot"]
route_c_idx = artifacts["category3_route_c_similarity"]["reference_reaction_index"]
CANDIDATES = [
    # (module, callable, location, is_envipath_known_route_lookup, snapshot_identity,
    #  snapshot_sha256, evidence_kind)
    ("<teacher compiled topology>", "<none: no lookup node exists>",
     "langgraph StateGraph node set of the frozen teacher tree", False,
     "no known-route snapshot is read by the graph", None, "lookup_node_absent"),
    ("src.tools.depending_v32_adapter", "predict_reactions",
     str(Path(STAGED) / "src/tools/depending_v32_adapter.py"), False,
     "n/a - the only teacher-side door into frozen v3.2, imported by no node", None,
     "adapter_unwired"),
    ("reaction_analogy.eawag_lookup", "lookup",
     str(V32 / "reaction_analogy/eawag_lookup.py"), True,
     donor["path"], donor.get("sha256"), "true_known_route_lookup_but_outside_graph"),
    ("src.tools.reaction_retriever", "retrieve_similar_reactions",
     str(Path(STAGED) / "src/tools/reaction_retriever.py"), False,
     route_c_idx["path"], route_c_idx.get("sha256"), "category3_similarity_not_known_route"),
]
with open(str(LOOKUP_CSV), "w", newline="", encoding="utf-8") as fh:
    wtr = csv.writer(fh)
    wtr.writerow(LOOKUP_FIELDS)
    for tag, s in (("S_INVALID_INPUT", s_inv), ("S_HIT_LIKE_M3", s_hit),
                   ("S_MISS_PROBE_M5", s_miss), ("S_ENVIPATH_LABEL_BRIDGE", s_lbl)):
        ts = s.get("terminal_state") or {}
        counts = s.get("counts") or {}
        timing = s.get("timing") or {}
        for mod, qual, loc, is_envi, snap, snap_sha, kind in CANDIDATES:
            if kind == "category3_similarity_not_known_route":
                cnt = counts.get("route_c_retrieval_calls", 0)
                window = timing.get("route_c_similar_retrieval") or {}
                hm = ("NOT_A_KNOWN_ROUTE_LOOKUP: similarity search returns top-k=10 "
                      "unconditionally, so no HIT/MISS is defined" if cnt else "not called")
                res = (ts.get("candidate_reaction_count") if cnt else 0)
            elif kind == "lookup_node_absent":
                cnt = 0
                window = {}
                hm = ("NO_LOOKUP: the fixed topology has no enviPath known-route lookup node")
                res = 0
            else:
                cnt = counts.get("envipath_known_route_lookup_calls", 0) + \
                    counts.get("depending_v32_adapter_calls", 0)
                window = timing.get("any_envipath_known_route_lookup") or {}
                hm = ("NOT_INVOKED: reachable from the graph by no path (call count 0)") \
                    if not cnt else "INVOKED"
                res = 0
            wtr.writerow([
                tag, (s.get("input_identity") or {}).get("user_query_head"), mod, qual, loc,
                "YES" if is_envi else "NO", snap, snap_sha or "n/a",
                window.get("started_utc") or "null", window.get("ended_utc") or "null",
                cnt, hm, res,
                counts.get("depending_v32_adapter_calls", 0),
                (timing.get("graph_prediction_fallback") or {}).get("started_utc") or "null",
                (ts.get("first_candidate") or {}).get("source_tag") or "null",
                ts.get("reaction_task_id") or "null", s.get("_pool_anchor"), kind,
                "%s|%s" % (OBS_STDOUT.name, OBS_STDERR.name), rc])
say("wrote %s (%d rows x %d columns)" % (LOOKUP_CSV.name, 4 * len(CANDIDATES), len(LOOKUP_FIELDS)))

# ------------------------------------------------------------------ 5. PREDICTION_FALLBACK_CALLS.csv
PRED_FIELDS = ["record_id", "input_identity", "engine", "engine_module", "engine_callable",
               "is_depending_v32", "is_envipath_lookup", "call_count", "started_utc",
               "ended_utc", "result_count", "fail_closed", "error", "source_tag",
               "reaction_task_id_into_pool", "pool_entry_reaction_identifier",
               "trigger_condition_in_fixed_topology",
               "entered_in_this_run", "raw_log", "exit_code"]
PRED_ROWS = [
    ("depending v3.2 (frozen single-smiles runtime)", "src.tools.depending_v32_adapter",
     "predict_reactions", "YES", "NO", "depending_v32_adapter_calls",
     "no edge in the fixed topology routes to it; the adapter is imported by no node"),
    ("BioTransformer 3.0 ENVMICRO (graph fallback node)", "src.tools.reaction_predictor",
     "predict_reactions", "NO", "NO", "biotransformer_prediction_calls",
     "route_after_reaction: pipeline_mode=='m5' and (candidate_reactions empty or "
     "error-without-fail_closed) -> 'predict'  [a state test, NOT a lookup HIT/MISS test]"),
    ("enviPath / EAWAG known-route lookup", "reaction_analogy.eawag_lookup",
     "lookup(index, parent_smiles)", "NO", "YES", "envipath_known_route_lookup_calls",
     "absent: no node, no edge, no conditional tests it"),
]
with open(str(PRED_CSV), "w", newline="", encoding="utf-8") as fh:
    wtr = csv.writer(fh)
    wtr.writerow(PRED_FIELDS)
    for tag, s in (("S_INVALID_INPUT", s_inv), ("S_HIT_LIKE_M3", s_hit),
                   ("S_MISS_PROBE_M5", s_miss), ("S_ENVIPATH_LABEL_BRIDGE", s_lbl)):
        ts = s.get("terminal_state") or {}
        counts = s.get("counts") or {}
        timing = s.get("timing") or {}
        for engine, mod, qual, is_v32, is_envi, key, cond in PRED_ROWS:
            cnt = counts.get(key, 0)
            if key == "biotransformer_prediction_calls":
                window = timing.get("graph_prediction_fallback") or {}
            elif key == "depending_v32_adapter_calls":
                window = timing.get("depending_v32_entry") or {}
            else:
                window = timing.get("any_envipath_known_route_lookup") or {}
            res = (ts.get("predicted_reaction_count") if key == "biotransformer_prediction_calls"
                   else 0)
            wtr.writerow([
                tag, (s.get("input_identity") or {}).get("user_query_head"), engine, mod, qual,
                is_v32, is_envi, cnt, window.get("started_utc") or "null",
                window.get("ended_utc") or "null", res,
                "true" if ts.get("fail_closed") else "false", ts.get("error") or "null",
                (ts.get("first_predicted") or {}).get("source_tag")
                or (ts.get("first_candidate") or {}).get("source_tag") or "null",
                ts.get("reaction_task_id") or "null", s.get("_pool_anchor"), cond,
                "YES" if cnt else "NO", "%s|%s" % (OBS_STDOUT.name, OBS_STDERR.name), rc])
say("wrote %s (%d rows x %d columns)" % (PRED_CSV.name, 4 * len(PRED_ROWS), len(PRED_FIELDS)))

# ------------------------------------------------------------------ 6. SOURCE_SEPARATION json
SEP = {
    "gate": "LOOKUP_PREDICTION_SOURCE_SEPARATION",
    "section": SECTION, "utc": utc(), "verdict": verdict,
    "statement": ("the four reaction-acquisition mechanisms below are distinct; only category 1 "
                  "may ever be reported as an 'enviPath known-route lookup', and it is not "
                  "present in the teacher's fixed topology"),
    "categories": {
        "1_envipath_known_route_lookup": {
            "what_it_is": "exact known-pathway lookup against a curated EAWAG-BBD/enviPath "
                          "donor->product snapshot (HIT = database answer, MISS = no answer)",
            "callable_that_would_do_it": "reaction_analogy.eawag_lookup:lookup(index, parent_smiles)",
            "artefacts": artifacts["category1_envipath_eawag_known_route"],
            "present_in_teacher_fixed_topology": False,
            "imported_during_graph_runs": bool(envipath_modules_imported),
            "call_count_observed": total_lookup_calls,
            "source_tag_produced_by_graph": None,
            "label_only_occurrences_in_teacher_code": [
                {"file": "src/schemas/bridge.py", "line": 27,
                 "text": 'source_tool: str = "enviPath"     # 整条路径默认来源工具（每步可引用）',
                 "kind": "pydantic default label, no I/O, no lookup"},
                {"file": "src/schemas/bridge.py", "line": 45,
                 "text": "source_tool: str  # enviPath / BioTransformer / ECLIPSE / ...",
                 "kind": "comment listing possible values"},
                {"file": "src/nodes/multi_step_bridge_node.py", "line": 57,
                 "text": "source_tool=route.source_tool",
                 "kind": "copies the caller-supplied label verbatim onto every split step"},
            ],
            "hazard": ("a graph output can therefore carry source_tool=\"enviPath\" with zero "
                       "lookups performed; this gate labels it as a label and refuses to "
                       "report it as a lookup"),
        },
        "2_depending_v32_internal_retrieval_prediction": {
            "what_it_is": "the frozen depending BBD v3.2 single-SMILES runtime's own "
                          "retrieval/prediction engines (analogy transfer, rules, MPNN etc.)",
            "entrypoint": artifacts["category2_depending_v32_internal"]["single_smiles_v32_entry"],
            "teacher_side_adapter": artifacts["category2_depending_v32_internal"]["teacher_adapter"],
            "adapter_reaches_it_via": "DEPENDING_V32_RUNTIME_ROOT + importlib spec of "
                                      "reaction_analogy/single_smiles_v32.py",
            "present_in_teacher_fixed_topology": False,
            "adapter_imported_during_graph_runs": bool(adapter_imported),
            "call_count_observed": total_v32,
            "must_not_be_reported_as": "enviPath known-route lookup",
            "note": ("TEST-01 of the original contract exercises this adapter directly as a "
                     "component; that is category 2 evidence and is labelled as such")},
        "3_enzyme_pool_route_c_4051_similarity_retrieval": {
            "what_it_is": "Morgan radius=8 Tanimoto similarity over the 4,051 query-excluded "
                          "reference reactions; returns top-k always",
            "implementation": artifacts["category3_route_c_similarity"]["implementation"],
            "databases": {k: v for k, v in
                          artifacts["category3_route_c_similarity"].items() if k != "implementation"},
            "graph_node": "reaction (src/nodes/reaction_node.py -> retrieve_similar_reactions)",
            "present_in_teacher_fixed_topology": True,
            "call_count_observed": total_route_c,
            "source_tag_produced_by_graph": "retrieved (CandidateReaction.source), source_tag=None",
            "semantic_difference": ("similarity ranking of a reaction library is not a "
                                    "known-route database answer; empty result is not even "
                                    "reachable for a parseable SMILES"),
            "must_not_be_reported_as": "enviPath known-route lookup"},
        "4_d8_stage_bbd_rhea_literature_reference_search": {
            "what_it_is": "reference search used by the pool/organism side and the D8 decision "
                          "records: RHEA140 EC mapping, fair EC->UID table, D4 asset "
                          "availability, UniProt/KEGG host resolution, PubChem/CHEBI name "
                          "resolution",
            "artefacts": artifacts["category4_d8_bbd_rhea_literature"],
            "graph_nodes": ["enzyme_pool (route_b B-primary)", "microbe / organism_selection",
                            "substrate (pubchem_lookup name resolution only)"],
            "present_in_teacher_fixed_topology": "partially (pool and host side, never as a "
                                                 "reaction source answer)",
            "source_tag_produced_by_graph": "retrieved / predicted + host provenance "
                                            "UniProtKB/KEGG/C8_METATRAITS_LOOKUP_INDEX",
            "must_not_be_reported_as": "enviPath known-route lookup"},
        "extra_graph_prediction_fallback": {
            "what_it_is": "the node the topology actually calls 'controlled prediction'",
            "engine": artifacts["graph_prediction_fallback_engine"],
            "implementation": "src/tools/reaction_predictor.py::predict_reactions(method="
                              "'biotransformer_envmicro')",
            "teacher_own_words": {
                "reaction_predictor.py:7": "#   ENVMICRO 是 EAWAG-BBD/PPS 规则系统：SMARTS 决定"
                                           "\"底物哪里能反应\"",
                "README.md:40": "引擎选型中：BioTransformer ENVMICRO 机制已验证——EAWAG 规则系统，"
                                "SMARTS 命中 + SMIRKS 变换，非数据库查询",
            },
            "is_a_database_lookup": False,
            "source_tag_produced": "biotransformer_envmicro",
            "call_count_observed": total_bio,
            "hard_dependency": "BIOTRANSFORMER_JAR (java) absent on this host -> returns [] and "
                               "the node fails closed"},
    },
    "prohibition_tests": [
        {"rule": "category 2 must not be written as enviPath lookup", "violated": False,
         "proof": "0 depending_v32 calls, adapter never imported"},
        {"rule": "category 3 must not be written as enviPath lookup", "violated": False,
         "proof": "recorded separately with its own callable, database SHA and source_tag"},
        {"rule": "category 4 must not be written as enviPath lookup", "violated": False,
         "proof": "RHEA/EC/PubChem identities listed only under category 4"},
        {"rule": "a source_tool label must not be treated as an executed lookup", "violated": False,
         "proof": "S_ENVIPATH_LABEL_BRIDGE shows label present / lookup count 0"},
    ],
    "discriminator_rules_for_future_rounds": [
        "an enviPath lookup claim requires a callable binding to a donor/product snapshot with "
        "a SHA, plus a HIT/MISS branch test in a router",
        "source_tool / source_tag strings are metadata, never execution evidence",
        "similarity top-k retrieval must report its threshold behaviour; without a threshold it "
        "cannot produce a MISS",
    ],
    "aggregates": gate["aggregates"],
    "problems": problems, "problem_count": len(problems),
}
SEP_JSON.write_text(json.dumps(SEP, ensure_ascii=False, indent=1), encoding="utf-8")
say("wrote %s (4 categories + fallback engine, %d prohibition tests)"
    % (SEP_JSON.name, len(SEP["prohibition_tests"])))

# ------------------------------------------------------------------ 7. report
say("=" * 78)
for ln in ("REAL_LANGGRAPH_COMPILE=%s" % ("PASS" if struct["real_langgraph_stategraph"] else "FAIL"),
           "TEACHER_NODE_COUNT=%s (frozen 12 expected)" % struct["node_count_observed"],
           "ENVIPATH_LOOKUP_NODE_PRESENT=%s" % (
               "YES" if struct["envipath_lookup_node_present"] else "NO"),
           "ENVIPATH_ADAPTER_WIRED_IN_GRAPH=%s" % ("YES" if adapter_imported else "NO"),
           "LOOKUP_CONDITION_IN_ROUTER=%s" % ("YES" if cond_is_lookup else "NO"),
           "OBSERVED_ENVIPATH_LOOKUP_CALLS=%d" % total_lookup_calls,
           "OBSERVED_ROUTE_C_SIMILARITY_CALLS=%d" % total_route_c,
           "OBSERVED_BIOTRANSFORMER_PREDICTION_CALLS=%d" % total_bio,
           "OBSERVED_DEPENDING_V32_CALLS=%d" % total_v32,
           "NETWORK_EVENTS_OBSERVED=%s" % sock.get("event_count"),
           "INVALID_INPUT_FAIL_CLOSED=%s" % (
               "OBSERVED" if (s_inv.get("terminal_state") or {}).get("fail_closed") else "NO"),
           "LOOKUP_THEN_PREDICTION_ORDER=%s" % verdict,
           "TEACHER_TOPOLOGY_MODIFIED=NO",
           "TOPOLOGY_BYTES_EQUAL_4_3_RECORD=%s" % (
               "YES" if topology_vs_4_3.get("all_four_unchanged_since_4_3") else "CHECK_REPORTED"),
           "T6_FULL_PASS_CLAIMED_ON_THIS_POINT=NO (contract gap pending teacher adjudication)",
           "GATE_PROBLEM_COUNT=%d" % len(problems)):
    say(ln)
stdout_block = "\n".join(report) + "\n"
STDOUT_TXT.write_text(stdout_block, encoding="utf-8")
gate["deliverables"] = [str(TRACE_JSON), str(LOOKUP_CSV), str(PRED_CSV), str(SEP_JSON),
                        str(STDOUT_TXT)]
TRACE["deliverables"] = gate["deliverables"]
TRACE_JSON.write_text(json.dumps(TRACE, ensure_ascii=False, indent=1), encoding="utf-8")
C.self_audit(__file__, 0, "§8 read-only enviPath lookup->prediction gate: %s" % verdict)
print("@@P13@@ " + json.dumps({"verdict": verdict, "problems": len(problems),
                               "lookup_calls": total_lookup_calls,
                               "prediction_calls": total_bio, "rc": rc}))
sys.exit(0 if not problems and rc == 0 else 1)
