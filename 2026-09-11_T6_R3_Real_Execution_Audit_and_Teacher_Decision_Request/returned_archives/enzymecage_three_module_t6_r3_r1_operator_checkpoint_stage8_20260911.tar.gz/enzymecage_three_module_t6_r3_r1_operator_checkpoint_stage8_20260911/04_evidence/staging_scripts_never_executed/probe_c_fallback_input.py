# -*- coding: utf-8 -*-
"""CPU-only search for a substrate that makes the PRODUCTION pool builder fall back to C.

Contract §5 S2 must come from a *real* M3 CASE_C_FALLBACK_SUCCESS run, i.e. a query whose
retrieved candidate reactions carry no EC, so ``build_enzyme_pool`` honestly returns
``route_used == "C"`` ("B empty -> C-fallback").  The decision is therefore taken by the
production function itself, never by this probe.  Nothing is modified; the answer only selects an
input for the real graph run that follows.
"""
import json
import os
import sys
import time
from pathlib import Path

CFG = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
STAGED = CFG["staged"]
os.environ["M3_AGENT_DATA_ASSETS_ROOT"] = CFG["assets_root"]
os.environ["ENZYMECAGE_DRY_RUN"] = "0"
sys.path.insert(0, STAGED)

from src.tools.reaction_retriever import ReactionDatabase, retrieve_similar_reactions  # noqa
from src.tools.enzyme_pool_builder import build_enzyme_pool  # noqa

t0 = time.time()
db = ReactionDatabase()
db.load()
print("db ready %.1fs reactions=%d" % (time.time() - t0, len(db._rxn_smiles_list)), flush=True)

no_ec = [r for r in db._rxn_smiles_list if not db._rxn_ec_map.get(r)]
print("reactions without EC: %d / %d" % (len(no_ec), len(db._rxn_smiles_list)), flush=True)

checked = 0
found = []
errors = []
for rxn in no_ec:
    substrate = rxn.split(">>")[0].split(".")[0]
    if not substrate or len(substrate) > 80:
        continue
    checked += 1
    try:
        cands = retrieve_similar_reactions(substrate_smiles=substrate, topk=10, db=db)
        pool, route, pool_b, pool_c = build_enzyme_pool(candidate_reactions=cands)
    except Exception as exc:                      # noqa: BLE001 - probe only, never a verdict
        errors.append({"substrate": substrate[:60], "error": repr(exc)[:200]})
        continue
    if route != "C" or not pool:
        continue
    found.append({"substrate": substrate, "reaction": rxn[:200],
                  "candidate_count": len(cands),
                  "candidate_ec_present": [bool(c.ec_numbers) for c in cands],
                  "top_similarity": cands[0].similarity_score,
                  "top_rhea_id": getattr(cands[0], "rhea_id", None),
                  "top_reaction_sha256": cands[0].reaction_sha256,
                  "route_used": route, "pool_b_size": len(pool_b), "pool_c_size": len(pool_c),
                  "pool_size": len(pool), "pool_first_20": pool[:20]})
    print("C-FALLBACK substrate=%s |B|=%d |C|=%d pool=%d" % (
        substrate[:48], len(pool_b), len(pool_c), len(pool)), flush=True)
    if len(found) >= 8:
        break

out = {"checked_substrates": checked, "candidates_with_route_C": found,
       "errors": errors[:10], "error_count": len(errors),
       "seconds": round(time.time() - t0, 1)}
print(json.dumps(out, ensure_ascii=False, indent=1)[:4000], flush=True)
with open(CFG["out"], "w", encoding="utf-8") as fh:
    json.dump(out, fh, ensure_ascii=False, indent=1)
print("wrote", CFG["out"], flush=True)
