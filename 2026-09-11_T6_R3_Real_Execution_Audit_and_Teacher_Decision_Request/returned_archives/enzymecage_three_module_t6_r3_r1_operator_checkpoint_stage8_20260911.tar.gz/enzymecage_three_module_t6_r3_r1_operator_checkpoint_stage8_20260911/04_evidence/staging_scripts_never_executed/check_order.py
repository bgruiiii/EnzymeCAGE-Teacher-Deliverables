"""Module-level use-before-bind probe (cheap pre-flight; symtable alone cannot see order).

Walks the module body in execution order and reports every loaded name that has not been
bound by an earlier statement, i.e. the class of bug that only shows up after a long GPU
run has already started.  Function/class bodies are skipped (they run later); symtable in
check_names.py covers those.
"""
import ast
import builtins
import sys

EXTRA = {"__file__", "__name__", "__doc__", "__builtins__", "__spec__", "__loader__",
         "__package__", "__class__"}
SKIP_STMT = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def binds(node, out):
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        for a in node.names:
            out.add((a.asname or a.name).split(".")[0])
    elif isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
        out.add(node.id)
    elif isinstance(node, ast.arg):
        out.add(node.arg)
    elif isinstance(node, ast.alias):
        out.add(node.asname or node.name)
    elif isinstance(node, ast.ExceptHandler) and node.name:
        out.add(node.name)
    elif isinstance(node, ast.Global):
        out.update(node.names)
    elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        out.add(node.name)


def scan(body, bound, problems, depth=0):
    """Statement-order walk, deliberately over-permissive inside one statement.

    Names stored anywhere in a statement are treated as bound before its loads are checked
    (a single statement cannot use-before-assign itself), and both branches of an ``if`` bind
    unconditionally.  What this still catches - the point of the exercise - is a name used in
    a *later* statement that no *earlier* statement ever binds: typos and ordering mistakes
    in a script whose first third costs twenty minutes of model loading.
    """
    for st in body:
        if isinstance(st, SKIP_STMT):
            bound.add(st.name)                    # the def/class name itself
            continue                              # its body runs later, if at all
        for node in ast.walk(st):
            binds(node, bound)
        for node in ast.walk(st):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                if node.id not in bound and node.id not in EXTRA \
                        and not hasattr(builtins, node.id):
                    problems.append((st.lineno, node.id))
        for attr in ("body", "orelse", "finalbody"):
            scan(getattr(st, attr, None) or [], bound, problems, depth + 1)
        for h in getattr(st, "handlers", None) or []:
            scan([h], bound, problems, depth + 1)


def main(files):
    rc = 0
    for f in files:
        tree = ast.parse(open(f, encoding="utf-8").read(), f)
        bound, problems = set(), []
        scan(tree.body, bound, problems)
        seen, uniq = set(), []
        for ln, nm in problems:
            if (ln, nm) not in seen:
                seen.add((ln, nm))
                uniq.append((ln, nm))
        print("%s: %d use-before-bind reference(s)" % (f, len(uniq)))
        for ln, nm in sorted(uniq):
            print("   line %-5d %s" % (ln, nm))
            rc = 1
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
