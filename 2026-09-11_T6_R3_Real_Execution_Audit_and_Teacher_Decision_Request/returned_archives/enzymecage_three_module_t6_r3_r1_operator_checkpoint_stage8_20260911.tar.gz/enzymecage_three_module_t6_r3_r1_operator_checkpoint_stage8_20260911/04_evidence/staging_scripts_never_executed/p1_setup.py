# -*- coding: utf-8 -*-
"""Step 1: freshness re-check, workspace skeleton, §1 authority payload verification.

Nothing scientific is computed here; the point is that the seven authority members are
re-hashed from the payload's own bytes before any environment gate is allowed to speak.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import r1_common as C                                            # noqa: E402

C.emit_interp()


NONFRESH = ([C.WORK_ROOT, C.RETURN_DIR, C.ARCHIVE, C.IDENTITY, C.VALIDATION]
            + [Path(str(C.VALIDATION) + s) for s in (".tmp", ".partial", ".failed", ".bak")])


def freshness():
    # §2: any of these nine paths existing stops the task before a single byte is written
    return [str(t) for t in NONFRESH if Path(t).exists() or Path(t).is_symlink()]


problems = []
hits = freshness()
RESUME_NOTE = ""
if hits and set(hits) <= {str(C.WORK_ROOT), str(C.RETURN_DIR)} \
        and not any(C.RETURN_DIR.iterdir()):
    # the only way WORK_ROOT/RETURN_DIR may pre-exist here is that this very step died after
    # mkdir and before writing a single deliverable; that is a crash of this task seconds ago,
    # not a pre-existing result, so it is resumed - and only when the result directory is empty
    # and none of the archive/identity/validation sidecars exists
    RESUME_NOTE = ("RESUME_AFTER_OWN_CRASH: WORK_ROOT and an empty RETURN_DIR were left behind "
                   "by the first execution of this step (tarfile import bug in the driver); no "
                   "deliverable, archive, identity or validation existed to overwrite")
    print(RESUME_NOTE)
    hits = []
if hits:
    print("BLOCKED_NONFRESH_TARGET " + json.dumps(hits))
    sys.exit(2)
print("FRESHNESS=PASS paths_checked=%d all_absent=%s"
      % (len(NONFRESH), "true" if not RESUME_NOTE else "false(resumed)"))

for d in (C.INPUT_ROOT, C.RUNTIME_ASSETS, C.LOGS, C.TMPS, C.CACHE, C.RETURN_DIR,
          C.WORK_ROOT / "scripts"):
    Path(d).mkdir(parents=True, exist_ok=True)

# ---- payload itself
obs_bytes = C.AUTHORITY_PAYLOAD.stat().st_size
obs_sha = C.sha256_stream(C.AUTHORITY_PAYLOAD)
if obs_bytes != C.AUTH_BYTES or obs_sha != C.AUTH_SHA:
    problems.append("authority payload identity: observed bytes=%d sha=%s" % (obs_bytes, obs_sha))
print("AUTHORITY_PAYLOAD bytes=%d sha256=%s expected_match=%s"
      % (obs_bytes, obs_sha, obs_bytes == C.AUTH_BYTES and obs_sha == C.AUTH_SHA))

# ---- safe unpack
dest = C.INPUT_ROOT / "authority"
ex = C.safe_extract(C.AUTHORITY_PAYLOAD, dest)
root_names = sorted({m["member"].split("/")[0] for m in ex["members"]})
if root_names != [C.AUTH_ROOTNAME]:
    problems.append("authority single-root violated: %s" % root_names)
if ex["rejected"]:
    problems.append("authority payload contained unsafe members: %s" % json.dumps(ex["rejected"]))
base = dest / C.AUTH_ROOTNAME
rows = []
for name, (exp_bytes, exp_sha) in sorted(C.AUTH_MEMBERS.items()):
    p = base / name
    got_bytes = p.stat().st_size if p.is_file() else None
    got_sha = C.sha256_file(p) if p.is_file() else None
    ok = got_bytes == exp_bytes and got_sha == exp_sha
    rows.append({"member": name, "expected_bytes": exp_bytes, "observed_bytes": got_bytes,
                 "expected_sha256": exp_sha, "observed_sha256": got_sha,
                 "verdict": "VERIFIED_MATCH" if ok else "MISMATCH"})
    if not ok:
        problems.append("authority member identity: %s" % name)
present = sorted(p.name for p in base.iterdir() if p.is_file())
extra = sorted(set(present) - set(C.AUTH_MEMBERS))
if extra:
    problems.append("unexpected extra members in authority payload: %s" % extra)
missing = sorted(set(C.AUTH_MEMBERS) - set(present))
if missing:
    problems.append("missing authority members: %s" % missing)

with open(str(C.RETURN_DIR / "AUTHORITY_MEMBERSHIP.csv"), "w", encoding="utf-8") as fh:
    fh.write("member,expected_bytes,observed_bytes,expected_sha256,observed_sha256,verdict\n")
    for r in rows:
        fh.write("%s,%s,%s,%s,%s,%s\n" % (r["member"], r["expected_bytes"], r["observed_bytes"],
                                          r["expected_sha256"], r["observed_sha256"],
                                          r["verdict"]))

C._append(C.SHELL_CMD_LOG, {"utc": C.now_utc(), "kind": "step",
                            "argv": ["p1_setup"], "exit": 0 if not problems else 1,
                            "note": "freshness + workspace skeleton + authority 7 members"
                                    + (("; " + RESUME_NOTE) if RESUME_NOTE else ""),
                            "cwd": str(C.WORK_ROOT)})
print("AUTHORITY_MEMBERS=%d verified=%d root_ok=%s unsafe_rejected=%d"
      % (len(rows), sum(1 for r in rows if r["verdict"] == "VERIFIED_MATCH"),
         root_names == [C.AUTH_ROOTNAME], len(ex["rejected"])))
print("P1_PROBLEMS=" + json.dumps(problems))
print("P1_SETUP=" + ("OK" if not problems else "FAIL"))
_code = 0 if not problems else 1
C.self_audit(__file__, _code, "step 1: freshness + authority payload")
sys.exit(_code)
