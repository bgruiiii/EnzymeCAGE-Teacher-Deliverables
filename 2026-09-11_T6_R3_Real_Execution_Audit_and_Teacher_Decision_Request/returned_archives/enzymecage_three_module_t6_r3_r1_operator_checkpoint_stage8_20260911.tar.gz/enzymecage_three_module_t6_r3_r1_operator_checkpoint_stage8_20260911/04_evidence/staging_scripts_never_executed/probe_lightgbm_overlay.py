# -*- coding: utf-8 -*-
"""Last-position read-only LightGBM overlay probe (T6-R3-R1, operator requirement 3-5).

Launched by ${PY} with one argument: the frozen T2B venv site-packages directory.

1. snapshot every gated module's __file__ and version *before* any path change;
2. append the T2B site-packages at the END of sys.path (lowest priority, so it can never
   shadow anything already provided by ${PY});
3. import lightgbm through that overlay and record its real module and native library path
   from /proc/self/maps;
4. re-snapshot every gated module and additionally resolve each one with
   importlib.util.find_spec *after* the injection, to prove no module created later would
   be picked up from the T2B tree;
5. hash the whole lightgbm package directory before and after the import to prove the
   injected capability stays byte-identical (read-only, PYTHONDONTWRITEBYTECODE=1).
"""
import hashlib
import importlib
import importlib.util
import json
import os
import sys
from pathlib import Path

PINNED = "/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python"
CODE_ROOT = "/root/projects/EnzymeCAGE-master"   # §4.2 explicitly allowed import path
MODULES = ["ase", "torch", "torch_geometric", "numpy", "scipy", "sklearn", "pandas",
           "rdkit", "pydantic", "langgraph", "langgraph.graph", "jsonschema", "yaml",
           "joblib", "xgboost", "enzymecage", "enzymecage.model", "enzymecage.schnet"]

print("R1_INTERP " + json.dumps({
    "sys_executable": sys.executable, "realpath": os.path.realpath(sys.executable),
    "prefix": sys.prefix, "base_prefix": sys.base_prefix,
    "version": sys.version.split()[0], "argv": sys.argv,
    "equals_pinned_py": sys.executable == PINNED,
}))
sys.stdout.flush()

T2B_SITES = os.path.realpath(sys.argv[1])
out = {"sys_executable": sys.executable, "equals_pinned_py": sys.executable == PINNED,
       "t2b_sites": T2B_SITES, "sys_prefix": sys.prefix,
       "dont_write_bytecode": sys.dont_write_bytecode}


def pkg_digest(root):
    """Digest of every regular file in a tree: path + bytes + sha256, order sorted."""
    root = Path(root)
    if not root.is_dir():
        return {"absent": str(root)}
    files = sorted(p for p in root.rglob("*") if p.is_file())
    h = hashlib.sha256()
    total = 0
    for p in files:
        blob = p.read_bytes()
        total += len(blob)
        h.update(str(p.relative_to(root)).encode())
        h.update(len(blob).to_bytes(8, "little"))
        h.update(hashlib.sha256(blob).hexdigest().encode())
    return {"file_count": len(files), "total_bytes": total, "tree_sha256": h.hexdigest()}


def snap(names, phase):
    rows = []
    for name in names:
        rec = {"module": name}
        mod = sys.modules.get(name)
        if mod is None:
            try:
                mod = importlib.import_module(name)
                rec["imported_in_this_phase"] = True
            except BaseException as exc:                                  # noqa: B036
                rec.update({"imported_in_this_phase": False, "error":
                            "%s: %s" % (type(exc).__name__, exc)})
                rows.append(rec)
                continue
        else:
            rec["imported_in_this_phase"] = False
        version = getattr(mod, "__version__", "")
        if version == "":
            try:
                import importlib.metadata as md
                version = md.version(name)
            except Exception:
                version = ""
        rec["version"] = str(version)
        rec["file"] = getattr(mod, "__file__", "") or ""
        rec["in_pinned_prefix"] = str(rec["file"]).startswith(str(Path(PINNED).parent.parent))
        rows.append(rec)
    return rows


def resolve_after(names):
    """find_spec() resolution after injection, to prove nothing would come from T2B."""
    rows = []
    for name in names:
        try:
            spec = importlib.util.find_spec(name)
            origin = getattr(spec, "origin", "") or ""
        except BaseException as exc:                                      # noqa: B036
            origin = "FIND_SPEC_ERROR %s: %s" % (type(exc).__name__, exc)
        rows.append({"module": name, "resolved_origin": origin,
                     "resolves_from_t2b": bool(origin) and
                     str(Path(origin).parent) .startswith(T2B_SITES)})
    return rows


before_path = list(sys.path)
out["sys_path_at_entry"] = before_path
if CODE_ROOT not in sys.path:
    sys.path.insert(0, CODE_ROOT)
    out["allowed_code_root_inserted"] = True
else:
    out["allowed_code_root_inserted"] = False
out["before_snapshot"] = snap(MODULES, "before")
out["sys_path_before"] = list(sys.path)
before_path = list(sys.path)

pkg_dir = Path(T2B_SITES) / "lightgbm"
digest_pre = pkg_digest(pkg_dir)

# ---- the injection itself: last position only, nothing removed, nothing re-ordered ----
if T2B_SITES in sys.path:
    out["already_on_path"] = True
    out["append_index"] = sys.path.index(T2B_SITES)
else:
    sys.path.append(T2B_SITES)
    out["already_on_path"] = False
    out["append_index"] = len(sys.path) - 1
after_path = list(sys.path)
pinned_site = [i for i, p in enumerate(after_path)
               if p.startswith(str(Path(PINNED).parent.parent))]
out["sys_path_after"] = after_path
out["t2b_is_last_entry"] = after_path[-1] == T2B_SITES
out["code_root_index"] = (after_path.index(CODE_ROOT) if CODE_ROOT in after_path else -1)
out["t2b_index"] = out["append_index"]
out["pinned_prefix_path_indices"] = pinned_site
out["pinned_paths_before_t2b"] = bool(pinned_site) and max(pinned_site) < out["append_index"]
out["prefix_before_equals_after"] = [p for p in before_path if
                                     p.startswith(str(Path(PINNED).parent.parent))] == \
                                    [p for p in after_path[:-1]
                                     if p.startswith(str(Path(PINNED).parent.parent))]

out["overlay_import_ok"] = False
try:
    lgb = importlib.import_module("lightgbm")
    out["overlay_import_ok"] = True
    out["version"] = getattr(lgb, "__version__", "")
    out["module_path"] = os.path.realpath(getattr(lgb, "__file__", "") or "")
    out["module_path_is_symlink"] = os.path.islink(getattr(lgb, "__file__", "") or "")
    out["module_path_under_t2b"] = out["module_path"].startswith(T2B_SITES)
    try:
        out["booster_api_present"] = callable(getattr(lgb, "Booster", None))
    except Exception:
        out["booster_api_present"] = False
except BaseException as exc:                                              # noqa: B036
    out["overlay_error"] = "%s: %s" % (type(exc).__name__, exc)
    out["overlay_traceback"] = __import__("traceback").format_exc()

# native library actually mapped into this process
maps = []
try:
    with open("/proc/self/maps", "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if "lightgbm" in line:
                maps.append(line.strip())
except OSError as exc:
    maps = ["maps unreadable: %s" % exc]
out["proc_self_maps_lightgbm"] = maps[:6]
so_paths = sorted({l.split()[-1] for l in maps if l and l.split()[-1].startswith("/")})
out["shared_library_path"] = so_paths[0] if so_paths else ""
out["shared_library_paths_all"] = so_paths

out["after_snapshot"] = snap(MODULES, "after")
out["after_resolution"] = resolve_after(MODULES)
out["modules"] = []
drift = []
for b in out["before_snapshot"]:
    name = b["module"]
    a = next((x for x in out["after_snapshot"] if x["module"] == name), {})
    changed = (str(b.get("file", "")) != str(a.get("file", "")) or
               str(b.get("version", "")) != str(a.get("version", "")))
    verdict = "UNCHANGED" if not changed else "DRIFTED"
    out["modules"].append({"module": name, "before_version": b.get("version", ""),
                           "before_file": b.get("file", ""),
                           "after_version": a.get("version", ""),
                           "after_file": a.get("file", ""), "changed": changed,
                           "before_in_pinned_prefix": b.get("in_pinned_prefix"),
                           "after_in_pinned_prefix": a.get("in_pinned_prefix"),
                           "before_error": b.get("error", ""), "after_error": a.get("error", ""),
                           "verdict": verdict})
    if changed:
        drift.append(name)
for r in out["after_resolution"]:
    if r["resolves_from_t2b"]:
        drift.append("resolution:%s" % r["module"])
out["shadowed_or_drifted_modules"] = drift
out["digest_pre_import"] = digest_pre
out["digest_post_import"] = pkg_digest(pkg_dir)
out["capability_tree_unchanged"] = (digest_pre.get("tree_sha256") ==
                                    out["digest_post_import"].get("tree_sha256"))
out["sys_executable_final"] = sys.executable
ok = (out["overlay_import_ok"] and out["equals_pinned_py"] and out["t2b_is_last_entry"]
      and out["pinned_paths_before_t2b"] and not drift and out["capability_tree_unchanged"])
out["verdict"] = "PASS" if ok else "FAIL"
print("R1_LG_PROBE " + json.dumps(out, ensure_ascii=False))
sys.stdout.flush()
sys.exit(0 if ok else 3)
