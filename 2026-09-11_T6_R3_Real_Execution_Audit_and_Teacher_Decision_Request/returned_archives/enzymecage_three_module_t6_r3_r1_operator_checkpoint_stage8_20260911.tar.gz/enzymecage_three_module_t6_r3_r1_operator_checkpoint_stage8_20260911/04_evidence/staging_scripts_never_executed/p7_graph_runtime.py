# -*- coding: utf-8 -*-
"""Phase §4.3: unified graph runtime gate, run under the pinned ${PY}.

Everything below is imported in this one process, which is the process that will later
compile/invoke/stream the teacher graph:

  * the installed real ``langgraph.graph.StateGraph`` symbol (not a task-local lookalike);
  * the teacher ``src.graph`` module and its ``build_graph`` / ``compile_graph`` builder,
    plus all 13 node modules (T2 prediction bridge, T3 enzyme, T5 microbe/organism/trait);
  * the EnzymeCAGE model modules from the code root and the frozen D4 wrapper package;
  * every ``module.__file__`` must land on the expected staged / code-root / wrapper path,
    and no expected name may be shadowed by a fake, stub, mock or task-local module;
  * only after that, the frozen read-only T2B LightGBM overlay is appended at the END of
    sys.path, and the already-established module sources are re-checked for drift.

If the same ${PY} cannot carry the teacher graph and the real EnzymeCAGE nodes at once the
result is BLOCKED_NO_UNIFIED_GRAPH_RUNTIME; no subprocess-node workaround is allowed.
"""
import hashlib
import importlib
import importlib.metadata as md
import importlib.util
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import r1_common as C                                                   # noqa: E402

C.emit_interp()
say_lines = []


def say(msg):
    say_lines.append(msg)
    print(msg, flush=True)


say("PHASE=§4.3 unified graph runtime gate")
say("UTC=" + C.now_utc())
say("cwd=%s" % os.getcwd())

problems = []
rows = []
EXPECTED = {
    "src.graph": C.STAGED_REPO,
    "src.state": C.STAGED_REPO,
    "src.nodes": C.STAGED_REPO,
    "src.tools": C.STAGED_REPO,
    "src.schemas": C.STAGED_REPO,
    "enzymecage": Path(C.CODE_ROOT),
    "enzymecage_wrapper": C.D4_WRAPPER_DIR.parent,
}


def import_and_record(name, role, expect_root):
    rec = {"module": name, "role": role, "expected_root": str(expect_root)}
    try:
        mod = importlib.import_module(name)
    except BaseException as exc:                                      # noqa: B036
        rec.update({"status": "IMPORT_FAIL",
                    "error": "%s: %s" % (type(exc).__name__, exc),
                    "traceback": __import__("traceback").format_exc(limit=8)})
        problems.append("cannot import %s (%s)" % (rec["error"].split(":")[0], name))
        rows.append(rec)
        say("%-42s %-14s %s" % (name, "IMPORT_FAIL", rec["error"]))
        return None, rec
    f = getattr(mod, "__file__", "") or ""
    version = getattr(mod, "__version__", "")
    if not version:
        try:
            version = md.version(name)
        except Exception:
            version = ""
    under = bool(f) and bool(expect_root) and str(f).startswith(str(expect_root))
    bad_name = bool(re_bad(f))
    rec.update({"status": "IMPORTED", "module_file": f, "file_sha256":
                (hashlib.sha256(Path(f).read_bytes()).hexdigest()
                 if f and Path(f).is_file() else ""),
                "version": str(version), "under_expected_root": under,
                "fake_stub_mock_path": bad_name,
                "verdict": "PASS" if under and not bad_name else "WRONG_SOURCE"})
    if not under:
        problems.append("%s resolved outside its expected root: %s" % (name, f))
    if bad_name:
        problems.append("%s resolved from a fake/stub/mock file: %s" % (name, f))
    rows.append(rec)
    say("%-42s %-14s %s" % (name, rec["verdict"], f))
    return mod, rec


def re_bad(path):
    import re
    return re.search(r"(^|/)(fake|stub|mock|dummy)[^/]*\.py$", str(path) or "")


# ---------------------------------------------------------------- StateGraph symbol
from langgraph.graph import StateGraph as SG                            # noqa: E402
sg = {"qualname": "%s.%s" % (SG.__module__, SG.__qualname__),
      "module": SG.__module__,
      "module_file": sys.modules[SG.__module__].__file__,
      "under_pinned_prefix": sys.modules[SG.__module__].__file__.startswith(
          str(Path(C.PY).parent.parent)) or
      sys.modules[SG.__module__].__file__.startswith("/usr/local/lib"),
      "defined_in_task_dirs": str(Path(C.WORK_ROOT)) in
                              sys.modules[SG.__module__].__file__ or
                              str(C.STAGED_REPO) in sys.modules[SG.__module__].__file__}
say("StateGraph -> %s @ %s" % (sg["qualname"], sg["module_file"]))
if sg["defined_in_task_dirs"] or not sg["under_pinned_prefix"]:
    problems.append("StateGraph is not the installed library symbol: %s" % sg)
import langgraph.graph.state as lgs
sg2 = getattr(lgs, "StateGraph")
if sg2 is not SG:
    problems.append("langgraph.graph.StateGraph is not langgraph.graph.state.StateGraph")
from langgraph.checkpoint.memory import MemorySaver                      # noqa: E402,F401
say("langgraph checkpointer MemorySaver importable: %s" % MemorySaver.__module__)

# ---------------------------------------------------------------- staged sys.path setup
# §4.3 runs on the fresh staged tree, so the tree itself becomes the first entry.  The two
# import roots sanctioned by §4.2 (EnzymeCAGE code root, D4 wrapper directory) are NOT added
# yet: the code root carries a top-level ``config.py`` that would hijack the teacher's
# ``config.settings`` namespace package, and a same-name shadow is exactly what this gate has
# to exclude.  They are appended only after the teacher side is fully bound, and the binding
# is re-checked for drift there.  This ordering is the recipe the successful T6-R2 round used
# (``sys.path.insert(0, STAGED_REPO)`` first, model roots wired through the teacher's own
# D4_WRAPPER_ROOT / ENZYMECAGE_CODE_ROOT / ENZYMECAGE_V1_PACKAGE_ROOT environment variables).
STAGED = str(C.STAGED_REPO)
if STAGED in sys.path:
    sys.path.remove(STAGED)
sys.path.insert(0, STAGED)
systematic = [{"path": STAGED, "index": 0,
               "reason": ("§4.3 fresh staged teacher tree; first entry so that `src` and the "
                          "`config` namespace package resolve there")}]
say("sys.path[0:5]=%s" % json.dumps(sys.path[:5]))

# the teacher reads its own entrypoint wiring with getenv() at import time, so the wiring is
# in place before src.config.settings is bound (values are re-checked in §8)
os.environ["D4_WRAPPER_ROOT"] = str(C.D4_WRAPPER_PARENT)
os.environ["ENZYMECAGE_CODE_ROOT"] = C.CODE_ROOT
os.environ["ENZYMECAGE_V1_PACKAGE_ROOT"] = str(C.RUNTIME_ASSETS / "v1_overlay")
os.environ["ENZYMECAGE_DRY_RUN"] = "0"
say("teacher entrypoint wiring exported: D4_WRAPPER_ROOT=%s ENZYMECAGE_CODE_ROOT=%s "
    "ENZYMECAGE_V1_PACKAGE_ROOT=%s ENZYMECAGE_DRY_RUN=0" % (os.environ["D4_WRAPPER_ROOT"],
                                                            C.CODE_ROOT,
                                                            os.environ["ENZYMECAGE_V1_PACKAGE_ROOT"]))
for p in ("src", "config", "enzymecage", "enzymecage_wrapper"):
    hits = []
    for entry in sys.path:
        base = Path(os.getcwd()) if not entry else Path(entry)
        for cand in (base / p, base / (p + ".py")):
            if cand.exists():
                hits.append(str(cand))
    if hits:
        say("pre-import candidates for %r: %s" % (p, hits))


def enable_model_import_paths():
    """Append the two §4.2-sanctioned roots after the teacher side is bound."""
    for entry, why in ((C.CODE_ROOT, "§4.2 sanctioned EnzymeCAGE code root"),
                       (str(C.D4_WRAPPER_PARENT),
                        "§4.2 sanctioned D4 wrapper package directory")):
        if entry not in sys.path:
            sys.path.append(entry)
        systematic.append({"path": entry, "index": sys.path.index(entry),
                           "reason": why + "; appended after the teacher imports so that its "
                                       "config.py cannot shadow the teacher config package"})
    say("model import roots appended: %s" % json.dumps(
        [s["path"] for s in systematic[1:]], ensure_ascii=False))


def teacher_binding_snapshot():
    snap = {}
    for name, mod in sorted(sys.modules.items()):
        if not (name == "config" or name.startswith("config.") or name == "src"
                or name.startswith("src.")):
            continue
        f = getattr(mod, "__file__", None) or ""
        snap[name] = {"file": f,
                      "path": [str(x) for x in getattr(mod, "__path__", [])]}
    return snap

# ---------------------------------------------------------------- teacher graph + nodes
graph_mod, _ = import_and_record("src.graph", "teacher graph module", C.STAGED_REPO)
import_and_record("src.state", "teacher public state contract", C.STAGED_REPO)
NODES = ["orchestrator_node", "substrate_node", "reaction_node", "reaction_prediction_node",
         "enzyme_pool_node", "enzymecage_node", "llm_reranking_node",
         "multi_step_bridge_node", "microbe_selection_node", "organism_selection_node",
         "trait_filter_node", "evidence_synthesis_node"]
for n in NODES:
    import_and_record("src.nodes." + n, "teacher/staged graph node", C.STAGED_REPO)
for tool in ("depending_v32_adapter", "enzymecage_client", "microbe_recommender",
             "trait_query", "reaction_retriever", "reaction_predictor",
             "route_edge_bridge"):
    p = C.STAGED_REPO / ("src/tools/%s.py" % tool)
    if p.is_file():
        import_and_record("src.tools." + tool, "staged production tool", C.STAGED_REPO)
for sch in ("evidence", "bridge"):
    p = C.STAGED_REPO / ("src/schemas/%s.py" % sch)
    if p.is_file():
        import_and_record("src.schemas." + sch, "staged schema", C.STAGED_REPO)
import config                                                       # teacher namespace package
import config.settings as teacher_settings
rows.append({"module": "config", "role": "teacher settings namespace package",
             "expected_root": STAGED, "status": "IMPORTED",
             "module_file": (config.__path__[0] + "/__init__.py (namespace)")
             if config.__path__ else "",
             "file_sha256": "", "version": "", "under_expected_root":
             bool(config.__path__) and config.__path__[0].startswith(STAGED),
             "fake_stub_mock_path": False,
             "verdict": "PASS" if config.__path__ and
             config.__path__[0].startswith(STAGED) else "WRONG_SOURCE"})
rows.append({"module": "config.settings", "role": "teacher production entrypoint settings",
             "expected_root": STAGED, "status": "IMPORTED",
             "module_file": teacher_settings.__file__,
             "file_sha256": hashlib.sha256(
                 Path(teacher_settings.__file__).read_bytes()).hexdigest(),
             "version": "",
             "under_expected_root": teacher_settings.__file__.startswith(STAGED),
             "fake_stub_mock_path": bool(re_bad(teacher_settings.__file__)),
             "verdict": "PASS"})
say("config -> %s ; config.settings -> %s" % (list(config.__path__),
                                              teacher_settings.__file__))
if not teacher_settings.__file__.startswith(STAGED):
    problems.append("config.settings resolved outside the staged tree")
for flag in ("D4_WRAPPER_ROOT", "ENZYMECAGE_CODE_ROOT", "ENZYMECAGE_V1_PACKAGE_ROOT",
             "ENZYMECAGE_MODEL_VERSION", "ENZYMECAGE_DRY_RUN"):
    if not hasattr(teacher_settings, flag):
        problems.append("config.settings exposes no %s" % flag)
teacher_snapshot = teacher_binding_snapshot()
say("teacher modules bound before the model roots are added: %d" % len(teacher_snapshot))

build_graph = getattr(graph_mod, "build_graph", None) if graph_mod else None
build_graph_t6 = getattr(graph_mod, "build_graph_t6", None) if graph_mod else None
compile_graph = getattr(graph_mod, "compile_graph", None) if graph_mod else None
say("teacher builder callables: build_graph=%s build_graph_t6=%s compile_graph=%s defined_in=%s"
    % (callable(build_graph), callable(build_graph_t6), callable(compile_graph),
       getattr(build_graph, "__module__", "")))
if not callable(build_graph) and not callable(build_graph_t6):
    problems.append("teacher src.graph exposes neither build_graph nor build_graph_t6")
builder_file = sys.modules[getattr(build_graph, "__module__", "src.graph")].__file__ \
    if callable(build_graph) else ""
if builder_file != str(C.STAGED_REPO / "src/graph.py"):
    problems.append("build_graph does not come from the staged teacher graph file: %s"
                    % builder_file)

built = None
order = {}
if callable(build_graph):
    try:
        built = build_graph()
        order["builder_return_type"] = "%s.%s" % (type(built).__module__, type(built).__name__)
        order["is_real_StateGraph"] = isinstance(built, SG)
        order["nodes"] = list(getattr(built, "nodes", {}).keys())
        raw_edges = getattr(built, "edges", set())
        if isinstance(raw_edges, dict):                        # langgraph <= 0.2 layout
            pairs = [[s, t] for s, ts in raw_edges.items() for t in ts]
        else:                                                  # 1.2.9: set[(source, target)]
            pairs = [[str(s), str(t)] for s, t in raw_edges]
        edges = sorted(pairs)
        order["edges"] = edges
        cond = []
        for name, spec in getattr(built, "branches", {}).items():
            cond.append(name)
        order["conditional_source_nodes"] = cond
        # the builder keeps plain edges in an unordered set, so the declaration order is read
        # out of the teacher source and cross-checked against the compiled structure
        import re as _rx
        gsrc = (C.STAGED_REPO / "src/graph.py").read_text(encoding="utf-8", errors="replace")
        NAME = r"(?:\"([^\"]+)\"|'([^']+)'|(END|START|__end__|__start__))"

        def lit(text):
            return text if text in ("__end__", "__start__") else {
                "END": "__end__", "START": "__start__"}.get(text, text)

        declared_nodes, declared_cond, declared_plain, entry = [], [], [], None
        for m in _rx.finditer(r"add_node\(\s*" + NAME, gsrc):
            declared_nodes.append(lit(next(g for g in m.groups() if g)))
        for m in _rx.finditer(r"set_entry_point\(\s*" + NAME, gsrc):
            entry = lit(next(g for g in m.groups() if g))
        for m in _rx.finditer(r"add_conditional_edges\(\s*" + NAME, gsrc):
            declared_cond.append(lit(next(g for g in m.groups() if g)))
        for m in _rx.finditer(r"add_edge\(\s*" + NAME + r"\s*,\s*" + NAME, gsrc):
            first = m.group(1) or m.group(2) or m.group(3)
            second = m.group(4) or m.group(5) or m.group(6)
            declared_plain.append([lit(first), lit(second)])
        order["source_declaration"] = {
            "add_node_order": declared_nodes,
            "set_entry_point": entry,
            "add_conditional_edges_source_order": declared_cond,
            "add_edge_pairs": declared_plain}
        order["node_order_matches_source"] = order["nodes"] == declared_nodes
        order["conditional_order_matches_source"] = cond == declared_cond
        order["entry_edge_declared_and_present"] = (
            entry is not None and ["__start__", entry] in edges)
        order["plain_edges_exactly_as_declared"] = (
            sorted(declared_plain + [["__start__", entry]] if entry else declared_plain) ==
            edges)
        say("built StateGraph nodes=%d edges=%d conditional_sources=%d type=%s"
            % (len(order["nodes"]), len(edges), len(cond), order["builder_return_type"]))
        say("declaration cross-check: nodes=%s conditional=%s entry=%s plain=%s"
            % (order["node_order_matches_source"],
               order["conditional_order_matches_source"],
               order["entry_edge_declared_and_present"],
               order["plain_edges_exactly_as_declared"]))
        if not order["is_real_StateGraph"]:
            problems.append("build_graph() did not return the installed langgraph StateGraph")
        for key, label in (("node_order_matches_source", "add_node order"),
                           ("conditional_order_matches_source", "conditional edge order"),
                           ("entry_edge_declared_and_present", "entry point edge"),
                           ("plain_edges_exactly_as_declared", "plain edge set")):
            if not order[key]:
                problems.append("compiled graph does not reproduce the teacher %s: %s" % (
                    label, json.dumps(order["source_declaration"])))
    except BaseException as exc:                                      # noqa: B036
        problems.append("build_graph() raised: %s: %s" % (type(exc).__name__, exc))
        say("build_graph() raised: %s" % __import__("traceback").format_exc(limit=6))

# ---------------------------------------------------------------- EnzymeCAGE + wrapper
# now, and only now, the two §4.2-sanctioned import roots become visible
teacher_before = dict(teacher_snapshot)
enable_model_import_paths()
teacher_after = teacher_binding_snapshot()
teacher_drift = [{"module": k, "before": teacher_before.get(k), "after": teacher_after.get(k)}
                 for k in sorted(teacher_before) if teacher_before.get(k) != teacher_after.get(k)]
if teacher_drift:
    problems.append("adding the model import roots moved a teacher module: %s" % teacher_drift[:3])
say("teacher binding drift after the model roots were appended: %d" % len(teacher_drift))

import_and_record("enzymecage", "EnzymeCAGE code root package", Path(C.CODE_ROOT))
import_and_record("enzymecage.model", "EnzymeCAGE model module", Path(C.CODE_ROOT))
import_and_record("enzymecage.schnet", "EnzymeCAGE schnet module (ase consumer)",
                  Path(C.CODE_ROOT))
import_and_record("enzymecage_wrapper", "frozen D4 wrapper package",
                  C.D4_WRAPPER_DIR.parent)
import_and_record("enzymecage_wrapper.predictor", "wrapper runtime constructor",
                  C.D4_WRAPPER_DIR.parent)
import_and_record("enzymecage_wrapper.schema", "wrapper request schema",
                  C.D4_WRAPPER_DIR.parent)
import_and_record("enzymecage_wrapper.utils", "wrapper utils", C.D4_WRAPPER_DIR.parent)
import torch, ase                                                       # noqa: E402
say("torch=%s @%s ; ase=%s @%s" % (torch.__version__,
                                   sys.modules["ase"].__file__, ase.__version__,
                                   sys.modules["ase"].__file__))
for name in ("ase", "torch", "torch_geometric", "rdkit", "pydantic", "numpy", "pandas",
             "scipy", "sklearn", "joblib", "xgboost", "jsonschema", "yaml", "langgraph"):
    try:
        m = importlib.import_module(name)
        rec = {"module": name, "role": "hard-gate third-party module",
               "expected_root": "installed site-packages (never task dirs)",
               "status": "IMPORTED", "module_file": m.__file__,
               "file_sha256": hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()
               if m.__file__ and Path(m.__file__).is_file() else "",
               "version": str(getattr(m, "__version__", "")),
               "under_expected_root": not (str(C.WORK_ROOT) in str(m.__file__) or
                                           str(C.STAGED_REPO) in str(m.__file__)),
               "fake_stub_mock_path": bool(re_bad(m.__file__)),
               "verdict": "PASS"}
    except BaseException as exc:                                      # noqa: B036
        rec = {"module": name, "role": "hard-gate third-party module", "status":
               "IMPORT_FAIL", "verdict": "FAIL", "error": "%s: %s" % (type(exc).__name__,
                                                                      exc)}
        problems.append("third-party module unusable in the unified runtime: %s" % name)
    rows.append(rec)
    say("%-42s %-14s %s" % (rec["module"], rec["verdict"], rec.get("module_file", "")))

pre_overlay = {r["module"]: r.get("module_file", "") for r in rows if r["status"] == "IMPORTED"}

# ---------------------------------------------------------------- lightgbm overlay check
overlay = {"applied_after_all_graph_imports": True, "reason":
           "operator ruling 2026-09-10 requirement 3: last-position read-only append, "
           "never ahead of the pinned site-packages"}
if problems:
    overlay["skipped"] = "graph gate already failing; no path change applied"
else:
    if C.T2B_SITES not in sys.path:
        sys.path.append(C.T2B_SITES)
    overlay.update({"t2b_sites": C.T2B_SITES, "index": sys.path.index(C.T2B_SITES),
                    "path_length": len(sys.path), "is_last": sys.path[-1] == C.T2B_SITES,
                    "pinned_prefix_indices_before": [
                        i for i, p in enumerate(sys.path[:-1])
                        if str(p).startswith(str(Path(C.PY).parent.parent))]})
    try:
        lgb = importlib.import_module("lightgbm")
        overlay["lightgbm"] = {"version": lgb.__version__, "file": lgb.__file__}
    except BaseException as exc:                                      # noqa: B036
        overlay["lightgbm"] = {"error": "%s: %s" % (type(exc).__name__, exc)}
        problems.append("overlay lightgbm import failed inside the graph process")
    drift = []
    for r in rows:
        if r["status"] != "IMPORTED":
            continue
        mod = sys.modules.get(r["module"])
        now = getattr(mod, "__file__", "") if mod else ""
        if now and now != pre_overlay.get(r["module"], now):
            drift.append({"module": r["module"], "before": pre_overlay.get(r["module"]),
                          "after": now})
    for name in list(pre_overlay):
        try:
            spec = importlib.util.find_spec(name)
        except BaseException:                                         # noqa: B036
            continue
        origin = getattr(spec, "origin", "") or ""
        if origin and str(origin).startswith(C.T2B_SITES):
            drift.append({"module": name, "resolution_after_overlay": origin})
    overlay["drift_after_overlay"] = drift
    overlay["no_drift"] = not drift
    if drift:
        problems.append("overlay changed module sources: %s" % drift[:3])
    say("overlay appended at index %s/%s, no drift=%s"
        % (overlay.get("index"), overlay.get("path_length"), overlay.get("no_drift")))

# ---------------------------------------------------------------- wrapper API surface
api = {}
try:
    import enzymecage_wrapper.predictor as pred
    import enzymecage_wrapper.schema as schema
    api["initialize_runtime"] = callable(getattr(pred, "initialize_runtime", None))
    api["EnzymeCAGERequest"] = getattr(schema, "EnzymeCAGERequest", None) is not None
    api["model_version"] = str(getattr(pred, "MODEL_VERSION",
                                       getattr(schema, "MODEL_VERSION", "")))
    api["runtime_initialized_in_this_gate"] = False
except BaseException as exc:                                          # noqa: B036
    api["error"] = "%s: %s" % (type(exc).__name__, exc)
    problems.append("wrapper API surface unusable: " + api["error"])
if not api.get("initialize_runtime") or not api.get("EnzymeCAGERequest"):
    problems.append("wrapper API surface incomplete: %s" % api)
say("wrapper API %s" % json.dumps(api))

# same-name shadow scan across the whole import system for the staged namespace
shadow_scan = []
for name in ("src", "enzymecage", "enzymecage_wrapper"):
    found = []
    for entry in sys.path:
        base = Path(entry) if entry else Path(os.getcwd())
        try:
            if (base / name).is_dir() or (base / (name + ".py")).is_file():
                found.append(str(base / name))
        except OSError:
            continue
    shadow_scan.append({"name": name, "candidates": found,
                        "single_expected": len(found) == 1})
    if len(found) != 1:
        problems.append("ambiguous import source for %s: %s" % (name, found))
say("shadow scan %s" % json.dumps(shadow_scan))

# the one genuine same-name collision on this interpreter is the teacher's `config` package
# versus /root/projects/EnzymeCAGE-master/config.py; prove it is inert for the model side
import re as _re
model_config_users = []
for root in (Path(C.CODE_ROOT) / "enzymecage", C.D4_WRAPPER_DIR):
    for p in sorted(root.rglob("*.py")):
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if _re.search(r"^\s*(import config\b|from config[\.\s])", text, _re.MULTILINE):
            model_config_users.append(str(p))
config_shadow = {
    "teacher_config_package": list(config.__path__),
    "teacher_config_settings_file": teacher_settings.__file__,
    "code_root_config_candidates": sorted(str(x) for x in
                                          Path(C.CODE_ROOT).glob("config*") if x.is_file()
                                          or (x / "__init__.py").is_file() or x.is_dir()),
    "code_root_has_regular_config_module": (Path(C.CODE_ROOT) / "config.py").is_file(),
    "model_side_files_importing_top_level_config": model_config_users,
    "teacher_binding_drift_after_model_roots": teacher_drift,
    "resolution": ("the staged `config` namespace package is bound before the EnzymeCAGE code "
                   "root is appended, and neither the enzymecage package nor the frozen D4 "
                   "wrapper imports a top-level `config`, so no module of either side is "
                   "shadowed; verified by the zero-drift snapshot above"),
}
if model_config_users:
    problems.append("model side really does import a top-level config: %s" % model_config_users)
if config.__path__ and not config.__path__[0].startswith(STAGED):
    problems.append("teacher config package moved: %s" % config.__path__)
say("config shadow analysis: %s" % json.dumps(config_shadow, ensure_ascii=False))

verdict = "PASS" if not problems else "FAIL"
if verdict == "FAIL":
    say("BLOCKED_NO_UNIFIED_GRAPH_RUNTIME")
(C.RETURN_DIR / "UNIFIED_GRAPH_RUNTIME_GATE.json").write_text(json.dumps(
    {"task_id": C.TASK_ID, "generated_utc": C.now_utc(),
     "phase": "§4.3 unified graph runtime gate",
     "interp": C.interp_identity(),
     "pinned_py": C.PY, "sys_prefix": sys.prefix, "sys_base_prefix": sys.base_prefix,
     "staged_repo": str(C.STAGED_REPO), "cwd": os.getcwd(),
     "sys_path_at_end": list(sys.path),
     "sys_path_additions": systematic,
     "stategraph": sg, "stategraph_is_library_symbol": sg2 is SG,
     "graph_builder": {"build_graph_callable": callable(build_graph),
                       "build_graph_t6_callable": callable(build_graph_t6),
                       "compile_graph_callable": callable(compile_graph),
                       "defined_in": builder_file,
                       "source_sha256": hashlib.sha256(
                           (C.STAGED_REPO / "src/graph.py").read_bytes()).hexdigest()
                       if (C.STAGED_REPO / "src/graph.py").is_file() else ""},
     "built_graph_order": order,
     "modules": rows, "wrapper_api": api, "shadow_scan": shadow_scan,
     "config_shadow_analysis": config_shadow,
     "teacher_entrypoint_wiring": {k: os.environ.get(k, "") for k in (
         "D4_WRAPPER_ROOT", "ENZYMECAGE_CODE_ROOT", "ENZYMECAGE_V1_PACKAGE_ROOT",
         "ENZYMECAGE_DRY_RUN")},
     "lightgbm_overlay": overlay,
     "verdict": verdict, "problems": problems},
    ensure_ascii=False, indent=2), encoding="utf-8")
csv = ["module,role,expected_root,status,module_file,file_sha256,version,"
       "under_expected_root,fake_stub_mock_path,verdict"]
for r in rows:
    csv.append(",".join(str(r.get(k, "")) for k in
                        ("module", "role", "expected_root", "status", "module_file",
                         "file_sha256", "version", "under_expected_root",
                         "fake_stub_mock_path", "verdict")))
(C.RETURN_DIR / "GRAPH_MODULE_IMPORT_IDENTITIES.csv").write_text("\n".join(csv) + "\n",
                                                                 encoding="utf-8")
(C.RETURN_DIR / "UNIFIED_GRAPH_RUNTIME_STDOUT.txt").write_text("\n".join(say_lines) + "\n",
                                                               encoding="utf-8")
say("UNIFIED_GRAPH_RUNTIME=%s modules_checked=%d problems=%d"
    % (verdict, len(rows), len(problems)))
print("GRAPH_GATE_VERDICT=%s" % verdict)
sys.exit(0 if verdict == "PASS" else 3)
