# -*- coding: utf-8 -*-
"""§6.1 group 8 / TEST-01: real depending v3.2 adapter through the teacher production entrypoint.

Task-local driver only.  It calls
``src/tools/depending_v32_adapter.verify_runtime_assets()`` and
``src.tools.depending_v32_adapter.predict_reactions(...)`` — no re-implementation of the
runtime, no fixed output.  Per the operator ruling of 2026-09-10 the pinned ${PY} interpreter
keeps full control and the frozen read-only T2B site-packages directory (the only place that
carries the real LightGBM 4.7.0 ranker dependency) is appended at the END of sys.path, so it
can never shadow anything installed under ${PY}.

argv: --phase base|repeat --out <json path>
"""
import argparse
import hashlib
import json
import os
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import r1_common as C  # noqa: E402

C.emit_interp()

SUBSTRATE = "c1ccc2[nH]nnc2c1"      # indole: the substrate of frozen task RT-1a7bea59ede1acf0
TOP_K = 10
MAX_DEPTH = 1

ap = argparse.ArgumentParser()
ap.add_argument("--phase", required=True, choices=("base", "repeat"))
ap.add_argument("--out", required=True)
A = ap.parse_args()

report = {"phase": A.phase, "utc_start": C.now_utc(), "production_callable":
          "src.tools.depending_v32_adapter.predict_reactions",
          "input": {"substrate_smiles": SUBSTRATE, "top_k": TOP_K, "max_depth": MAX_DEPTH}}


def dump_and_exit(code):
    Path(A.out).parent.mkdir(parents=True, exist_ok=True)
    report["exit_code"] = code
    report["utc_end"] = C.now_utc()
    Path(A.out).write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n",
                           encoding="utf-8")
    print(json.dumps({"phase": A.phase, "status": report.get("status"),
                      "count": report.get("count"),
                      "output_sha256": report.get("output_sha256"),
                      "runtime_init_s": report.get("runtime_init_s")}))
    sys.exit(code)


# ---------------------------------------------------------------- 1. import-path construction
# the teacher side first, then the operator-sanctioned read-only overlay at the very END
STAGED = str(C.STAGED_REPO)
sys.path.insert(0, STAGED)
os.environ["DEPENDING_V32_RUNTIME_ROOT"] = str(C.RUNTIME_ASSETS / "t2_v32")
os.environ["D4_WRAPPER_ROOT"] = str(C.D4_WRAPPER_PARENT)
os.environ["ENZYMECAGE_CODE_ROOT"] = C.CODE_ROOT
os.environ["ENZYMECAGE_V1_PACKAGE_ROOT"] = str(C.RUNTIME_ASSETS / "v1_overlay")
os.environ["ENZYMECAGE_DRY_RUN"] = "0"        # the same wiring the §4.3 graph gate proved

before_overlay = {m: getattr(mod, "__file__", "") for m, mod in list(sys.modules.items())
                  if getattr(mod, "__file__", None)}
sys.path.append(C.T2B_SITES)
report["sys_path"] = list(sys.path)
report["overlay_site_packages"] = C.T2B_SITES
report["overlay_is_last_entry"] = sys.path[-1] == C.T2B_SITES
report["sys_executable"] = sys.executable
report["sys_executable_equals_pinned_py"] = sys.executable == C.PY

# where would each dependency resolve *now*?  only lightgbm may come from the overlay
import importlib.util as _ilu                                            # noqa: E402
resolution = {}
for name in ("numpy", "pandas", "scipy", "sklearn", "joblib", "rdkit", "yaml", "pydantic",
             "jsonschema", "torch", "xgboost", "lightgbm"):
    try:
        spec = _ilu.find_spec(name)
        resolution[name] = spec.origin if spec and spec.origin else "namespace/no-origin"
    except BaseException as exc:                       # noqa: B036
        resolution[name] = "ERROR %s" % exc
report["dependency_resolution_after_overlay"] = resolution
foreign = {k: v for k, v in resolution.items()
           if v.startswith(C.T2B_SITES) and k != "lightgbm"}
report["only_lightgbm_resolves_into_overlay"] = not foreign
if foreign:
    report["error"] = "the overlay would shadow non-lightgbm modules: %s" % foreign
    dump_and_exit(9)

# ---------------------------------------------------------------- 2. LightGBM through the overlay
try:
    import lightgbm as lgb
    report["lightgbm_import"] = "PASS"
    report["lightgbm_version"] = getattr(lgb, "__version__", "")
    report["lightgbm_module_file"] = lgb.__file__
    report["lightgbm_from_overlay_only"] = lgb.__file__.startswith(C.T2B_SITES)
except BaseException as exc:
    report["lightgbm_import"] = "FAIL"
    report["lightgbm_traceback"] = traceback.format_exc()
    print("lightgbm import failed: %s" % exc, file=sys.stderr)
    dump_and_exit(4)

after_overlay = {m: getattr(mod, "__file__", "") for m, mod in list(sys.modules.items())
                 if getattr(mod, "__file__", None)}
drift = [{"module": k, "before": before_overlay[k], "after": after_overlay.get(k)}
         for k in before_overlay if after_overlay.get(k) != before_overlay[k]]
report["preexisting_module_drift"] = drift
report["no_shadowing_except_lightgbm"] = all(d["module"] == "lightgbm" for d in drift)

# ---------------------------------------------------------------- 3. teacher production entrypoint
try:
    from src.tools import depending_v32_adapter as V
    report["adapter_file"] = V.__file__
    report["adapter_expected"] = str(C.STAGED_REPO / "src/tools/depending_v32_adapter.py")
    report["adapter_is_staged_teacher_file"] = V.__file__ == report["adapter_expected"]
    report["adapter_sha256"] = C.sha256_file(V.__file__)
except BaseException as exc:
    report["error"] = "import src.tools.depending_v32_adapter: %s" % exc
    report["traceback"] = traceback.format_exc()
    print(report["error"], file=sys.stderr)
    dump_and_exit(5)

try:
    t0 = time.monotonic()
    V.verify_runtime_assets()
    report["verify_runtime_assets"] = "PASS"
    report["verify_runtime_assets_s"] = round(time.monotonic() - t0, 3)
except BaseException as exc:
    report["verify_runtime_assets"] = "FAIL"
    report["error"] = "verify_runtime_assets: %s" % exc
    report["traceback"] = traceback.format_exc()
    print(report["error"], file=sys.stderr)
    dump_and_exit(6)

try:
    t1 = time.monotonic()
    records = V.predict_reactions(SUBSTRATE, top_k=TOP_K, max_depth=MAX_DEPTH)
    report["predict_seconds"] = round(time.monotonic() - t1, 3)
    dumps = [r.model_dump() for r in records]
except BaseException as exc:
    report["error"] = "predict_reactions: %s" % exc
    report["traceback"] = traceback.format_exc()
    print(report["error"], file=sys.stderr)
    dump_and_exit(7)

# canonical serialisation of the frozen record list (the same formula in both phases)
payload = json.dumps(dumps, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
report["count"] = len(dumps)
report["records"] = dumps
report["canonicalisation"] = ("json.dumps(records, sort_keys=True, "
                              "separators=(',',':'), ensure_ascii=False) -> sha256 of utf-8")
report["output_sha256"] = hashlib.sha256(payload.encode("utf-8")).hexdigest()
report["evidence_hashes"] = [r["evidence_hash"] for r in dumps]
report["source_tool_values"] = sorted({r["source_tool"] for r in dumps})
report["model_version_values"] = sorted({r["model_version"] for r in dumps})
report["score_semantics"] = sorted({r["prediction_score"]["score_semantics"] for r in dumps})
report["depths"] = sorted({r["depth"] for r in dumps})

# the LightGBM ranker really has to be loaded inside the frozen runtime
try:
    rt = V._load()
    engine_counts = rt.engine_counts()
    report["engine_counts"] = engine_counts
    report["rankers_loaded"] = sorted(engine_counts.get("rankers_loaded", []))
    report["runtime_initialized"] = (len(engine_counts.get("rankers_loaded", [])) == 3
                                      and not engine_counts.get("init_error"))
    report["single_smiles_module_file"] = rt.__file__
    report["single_smiles_module_sha256"] = C.sha256_file(rt.__file__)
    report["single_smiles_module_expected_sha256"] = \
        "4b1eb113413da5031a6bcd06908cbeb0190f5d8ab37746c022acd1218c219939"
    report["single_smiles_module_identity"] = (
        report["single_smiles_module_sha256"] == report["single_smiles_module_expected_sha256"])
    import lightgbm.basic as _lgb_basic
    report["lightgbm_shared_library"] = _lgb_basic._find_lib_path()[0]
    report["lightgbm_loaded_from"] = str(_lgb_basic._LIB)
except BaseException as exc:
    report["engine_counts_error"] = "%s: %s" % (type(exc).__name__, exc)

# ---------------------------------------------------------------- 4. side effects inside WORK_ROOT
staged_root = Path(os.environ["DEPENDING_V32_RUNTIME_ROOT"])
after = {}
for p in sorted(staged_root.rglob("*")):
    if p.is_file():
        after[str(p.relative_to(staged_root))] = [p.stat().st_size,
                                                  hashlib.sha256(p.read_bytes()).hexdigest()]
report["runtime_root_file_count_after"] = len(after)
Path(HERE / ("v32_runtime_tree_%s.json" % A.phase)).write_text(
    json.dumps(after, indent=1, sort_keys=True), encoding="utf-8")

# the eight pinned assets must still be intact after the run (no mutation of the runtime)
GATE = {
    "reaction_analogy/templates.json": "65a5ad25cbd0cb49eb860205456544f0da8579da13a18278f992e4118d1ce5b8",
    "reaction_v3/data/lib_envipath/templates.tsv.gz": "19ac04ca4d6c516f7dce0f7536959847bec91ba81a68384c58551ead18ebe4f1",
    "data/hfix/templates_implicitH.jsonl": "3c3db55c385cfbe6d0553f155edec2189bf92247d314baf2fad97afdf5fb1948",
    "reaction_analogy/data/corpus_v1/corpus_v1.jsonl": "20cbe34d3d2bf921fdc82d211986da5e36a864186d2ec1dfc65b9140814e858f",
    "reaction_analogy/data/corpus_v1/donor_index.jsonl": "0a2c894681db19708d7b0f91e67471c2cdb103a7a58593798cbe020e55b37110",
    "data/bbd_v31/uspto_ranker.txt": "e493fc031f217e18543d27081168ff6851414f8f080622cf3dd54bc9484e0944",
    "data/bbd_v31/envipath_ranker.txt": "e0920695c9d8e2609c64da18975d39275b8be581a5657b0cf45ed8da264141c1",
    "data/bbd_v31/retrieval_ranker.txt": "bdcb575e9685d47dbfa83b96f71dd05e326dc21cb7f4c0b224b1fffb49c65f65",
}
post = {}
for rel, want in GATE.items():
    got = after.get(rel, ["", ""])[1]
    post[rel] = {"expected": want, "observed": got, "unchanged": got == want}
report["asset_post_run_identity"] = post
report["assets_unchanged_after_run"] = all(v["unchanged"] for v in post.values())

ok = (report["count"] == TOP_K and report["adapter_is_staged_teacher_file"]
      and report["no_shadowing_except_lightgbm"] and report["overlay_is_last_entry"]
      and report["sys_executable_equals_pinned_py"] and report["lightgbm_from_overlay_only"]
      and report["assets_unchanged_after_run"] and len(report["evidence_hashes"]) == TOP_K
      and all(len(h) == 64 for h in report["evidence_hashes"])
      and report.get("runtime_initialized") is True
      and report.get("single_smiles_module_identity") is True)
report["status"] = "PASS" if ok else "FAIL"
dump_and_exit(0 if ok else 8)
