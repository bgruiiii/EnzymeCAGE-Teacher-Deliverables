# -*- coding: utf-8 -*-
"""Operator-adjudicated LightGBM close-out gate (T6-R3-R1, 2026-09-10).

Executes the operator ruling of 2026-09-10 verbatim:
  1. record bare import FAIL + real traceback + every reference path:line + the frozen
     T2B venv / site-packages / LightGBM 4.7.0 source identity;
  2. prove ${PY} and the T2B venv are interpreter/SOABI/CPU-arch compatible and that the
     lightgbm python package and its native shared library exist, are readable and fixed;
  3. inject the T2B site-packages LAST (sys.path.append) so nothing of ${PY} can be
     shadowed, and keep sys.executable exactly ${PY};
  4. compare module.__file__ and version before/after injection for every gated module;
     any source change other than lightgbm blocks;
  5. emit LIGHTGBM_OVERLAY_IMPORT / version / module path / shared library path and
     ENVIRONMENT_STATUS=PASS_WITH_PINNED_READONLY_T2B_LIGHTGBM_OVERLAY.

No pip/conda/apt, no download, no copy into ${PY}, no model or teacher-graph change.
"""
import importlib
import json
import os
import platform
import re
import subprocess
import sys
import tarfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import r1_common as C                                                  # noqa: E402

OUT = []
LINES = []
problems = []


def say(msg):
    LINES.append(msg)
    print(msg, flush=True)


C.self_audit(__file__, -1, note="E0-L lightgbm six-source audit + T2B read-only overlay gate")
say("PHASE=E0-L lightgbm close-out gate")
say("UTC=" + C.now_utc())

T2B_ENV = Path("/usrdata/EnzymeCAGE_envs/"
               "enzymecage_three_module_t2b_v32_single_smiles_runtime_adapter_staged_20260907")
V32_FROZEN_REPO = Path("/usrdata/EnzymeCAGE_data/workspaces/"
                       "enzymecage_three_module_t2b_v32_single_smiles_runtime_adapter_"
                       "staged_20260907/repo")
TEACHER_STORE_R3A_R2A_R1 = Path(
    "/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t6_r3a_r2a_r1_teacher_"
    "taxid_grouping_raw_row_bytes_delivery_closure_20260910/depending_exact_teacher_base")

PAT = re.compile(r"\blightgbm\b", re.IGNORECASE)
CODE_SUFFIXES = {".py"}
DOC_SUFFIXES = {".md", ".txt", ".csv", ".json", ".jsonl", ".tsv", ".yaml", ".yml", ".log"}
# archived evidence packages that live inside the code root: their copies of a file are the
# same bytes as the live source, so they are counted but reported separately
ARCHIVE_DIR_NAMES = {"HPC_Returned_Result_Summaries", "HPC_Inputs"}
ALWAYS_SKIP = {".git", "__pycache__", "node_modules", "site-packages"}
EXCLUDE_DIR_PARTS = ALWAYS_SKIP | ARCHIVE_DIR_NAMES


def is_in_archive_dir(path):
    return bool(set(Path(path).parts) & ARCHIVE_DIR_NAMES)


MAX_SCAN_BYTES = 20 * 1024 * 1024          # per-file cap; recorded in the audit output


def scan_tree(root, limit=200, skip_dirs=ALWAYS_SKIP):
    """Return code references (*.py) and non-code mentions with path:line for a directory.

    Two counts are always reported: the total number of executable references and the
    subset that lives outside archived evidence packages.  Nothing is silently dropped --
    `skip_dirs` only removes VCS caches and, where the caller asks for it, the archives of
    other tasks.
    """
    code, docs, scanned, skipped = [], [], 0, []
    root = Path(root)
    if not root.is_dir():
        return {"absent": str(root), "code_reference_count_total": 0,
                "code_references": [], "non_code_mentions": [], "files_scanned": 0}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if set(path.parts) & skip_dirs:
            continue
        if path.suffix.lower() not in CODE_SUFFIXES | DOC_SUFFIXES:
            continue
        try:
            if path.stat().st_size > MAX_SCAN_BYTES:
                skipped.append({"path": str(path), "bytes": path.stat().st_size})
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        scanned += 1
        bucket = code if path.suffix.lower() in CODE_SUFFIXES else docs
        for i, line in enumerate(text.splitlines(), 1):
            if PAT.search(line):
                bucket.append({"path": str(path), "line": i,
                               "text": line.strip()[:200],
                               "inside_archived_evidence": is_in_archive_dir(path)})
    prod = [r for r in code if not r["inside_archived_evidence"]]
    return {"root": str(root), "files_scanned": scanned,
            "skipped_dir_names": sorted(skip_dirs),
            "per_file_scan_cap_bytes": MAX_SCAN_BYTES,
            "files_skipped_over_cap": skipped[:10],
            "code_reference_count_total": len(code),
            "code_reference_count_production": len(prod),
            "non_code_mention_count": len(docs),
            "code_references": prod[:limit], "code_references_truncated": len(prod) > limit,
            "archived_evidence_code_references":
                [r for r in code if r["inside_archived_evidence"]][:limit],
            "non_code_mentions": docs[:10], "non_code_truncated": len(docs) > 10}


def scan_tar(tar_path, limit=40):
    """Read every text member of a gzip tar in memory (no extraction, no writes)."""
    code, docs, members = [], [], 0
    with tarfile.open(str(tar_path), "r:gz") as tf:
        for m in tf.getmembers():
            if not m.isfile() or m.size > 40 * 1024 * 1024:
                continue
            suffix = Path(m.name).suffix.lower()
            if suffix not in CODE_SUFFIXES | DOC_SUFFIXES:
                continue
            try:
                raw = tf.extractfile(m).read()
            except Exception:
                continue
            members += 1
            bucket = code if suffix in CODE_SUFFIXES else docs
            for i, line in enumerate(raw.decode("utf-8", "replace").splitlines(), 1):
                if PAT.search(line):
                    bucket.append({"member": m.name, "line": i, "text": line.strip()[:200]})
    return {"tar": str(tar_path), "text_members_scanned": members,
            "code_reference_count": len(code), "non_code_mention_count": len(docs),
            "code_references": code[:limit], "code_references_truncated": len(code) > limit,
            "non_code_mentions": docs[:10]}


def scan_patch_from_failed_r3(member_name, expected_sha, expected_bytes):
    """Pull one diff out of the blocked first-round archive, prove its frozen identity,
    then report lightgbm references (added lines and context lines separately)."""
    entry = {"member": member_name, "archive": str(C.FAILED_R3)}
    if not C.FAILED_R3.is_file():
        entry["error"] = "FAILED_R3 archive absent"
        return entry
    if C.sha256_stream(C.FAILED_R3) != C.FAILED_R3_SHA:
        entry["error"] = "FAILED_R3 archive sha mismatch"
        return entry
    with tarfile.open(str(C.FAILED_R3), "r:gz") as tf:
        cand = [m for m in tf.getmembers() if Path(m.name).name == member_name]
        if not cand:
            entry["error"] = "member absent from archive"
            return entry
        raw = tf.extractfile(cand[0]).read()
    sha = hashlib_sha(raw)
    entry.update({"bytes": len(raw), "expected_bytes": expected_bytes,
                  "sha256": sha, "expected_sha256": expected_sha,
                  "verdict": "VERIFIED_MATCH" if (sha == expected_sha and
                                                  len(raw) == expected_bytes) else "MISMATCH"})
    added, context = [], []
    for i, line in enumerate(raw.decode("utf-8", "replace").splitlines(), 1):
        if not PAT.search(line):
            continue
        rec = {"diff_line": i, "text": line.strip()[:200]}
        if line.startswith("+"):
            added.append(rec)
        elif line.startswith("-"):
            rec["removed_line"] = True
            added.append(rec)
        else:
            context.append(rec)
    entry["added_or_removed_references"] = added[:40]
    entry["context_only_references"] = context[:10]
    entry["reference_count_added_or_removed"] = len(added)
    entry["reference_count_total"] = len(added) + len(context)
    return entry


def hashlib_sha(blob):
    import hashlib
    return hashlib.sha256(blob).hexdigest()


# ------------------------------------------------------------------ 1. bare import
say("=== step 1: bare ${PY} import (no path addition) ===")
rc_bare, out_bare, err_bare = C.run_py(["-B", "-c",
                                        "import lightgbm; print('IMPORTED', lightgbm.__version__)"],
                                       note="E0-L bare lightgbm import under pinned ${PY}",
                                       label="e0l_lightgbm_bare_import")
BARE_TRACEBACK = err_bare
say("bare_import rc=%s stderr=%s" % (rc_bare, err_bare.strip().splitlines()[-1:]))
BARE = {"rc": rc_bare, "stdout": out_bare.strip(), "traceback": BARE_TRACEBACK,
        "verdict": "FAIL" if rc_bare != 0 else "UNEXPECTEDLY_IMPORTABLE"}
if rc_bare == 0:
    # the operator premise (bare import fails) would be false; nothing to overlay
    say("LIGHTGBM_BARE_IMPORT=IMPORTABLE (no overlay needed)")

# ------------------------------------------------------------------ 2. six-source audit
say("=== step 2: six-source reference audit ===")
audit = {}
audit["enzyme_cage_code_root"] = scan_tree(C.CODE_ROOT, skip_dirs=EXCLUDE_DIR_PARTS)
audit["enzyme_cage_code_root"]["note"] = (
    "walked twice conceptually: archived evidence directories are skipped for the "
    "production count but are still reported inside archived_evidence_code_references "
    "of the companion entry")
audit["enzyme_cage_code_root_including_archives"] = scan_tree(C.CODE_ROOT)
say("S1 code root: production_code_refs=%d archived_copy_refs=%d non_code=%d files=%d"
    % (audit["enzyme_cage_code_root"].get("code_reference_count_production", -1),
       audit["enzyme_cage_code_root_including_archives"].get("code_reference_count_total", -1)
       - audit["enzyme_cage_code_root"].get("code_reference_count_production", -1),
       audit["enzyme_cage_code_root"].get("non_code_mention_count", -1),
       audit["enzyme_cage_code_root"].get("files_scanned", -1)))

# fresh teacher tree: read-only git grep at the exact BASE_COMMIT in an existing object
# store whose HEAD commit/tree are proven equal to the frozen BASE identity first
teach = {"requested_commit": C.BASE_COMMIT, "requested_tree": C.BASE_TREE}
if TEACHER_STORE_R3A_R2A_R1.is_dir():
    rc_h, out_h, _ = C.run(["git", "rev-parse", "HEAD"], cwd=TEACHER_STORE_R3A_R2A_R1,
                           note="E0-L teacher store HEAD (read-only)")
    rc_t, out_t, _ = C.run(["git", "rev-parse", "HEAD^{tree}"], cwd=TEACHER_STORE_R3A_R2A_R1,
                           note="E0-L teacher store HEAD tree (read-only)")
    rc_g, out_g, err_g = C.run(["git", "grep", "-n", "-I", "-e", "lightgbm", C.BASE_COMMIT],
                               cwd=TEACHER_STORE_R3A_R2A_R1,
                               note="E0-L git grep lightgbm at BASE_COMMIT (read-only)")
    rc_n, out_n, _ = C.run(["git", "ls-tree", "-r", "--name-only", C.BASE_COMMIT],
                           cwd=TEACHER_STORE_R3A_R2A_R1, note="E0-L base file list")
    rc_v, out_v, _ = C.run(["git", "grep", "-l", "-I", "-e", "xgboost", "-e", "Booster",
                            C.BASE_COMMIT], cwd=TEACHER_STORE_R3A_R2A_R1,
                           note="E0-L git grep xgboost/Booster at BASE_COMMIT")
    teach.update({
        "object_store": str(TEACHER_STORE_R3A_R2A_R1),
        "store_head": out_h.strip(), "store_tree": out_t.strip(),
        "head_equals_base_commit": out_h.strip() == C.BASE_COMMIT,
        "tree_equals_base_tree": out_t.strip() == C.BASE_TREE,
        "tracked_file_count": len([x for x in out_n.splitlines() if x.strip()]),
        "git_grep_rc": rc_g,
        "git_grep_note": ("git grep exits 1 when nothing matches" if rc_g == 1 and not out_g
                          else ""),
        "code_references": [{"path": x, "line": None, "text": ""} for x in
                            out_g.splitlines() if x.strip()][:40],
        "code_reference_count": len([x for x in out_g.splitlines() if x.strip()]),
        "xgboost_or_Booster_files": [x for x in out_v.splitlines() if x.strip()][:20],
        "v32_runtime_present": bool(re.search(r"single_smiles_v32|reaction_analogy", out_n)),
    })
    if teach["head_equals_base_commit"] and teach["tree_equals_base_tree"]:
        teach["verdict"] = "READABLE_EXACT_BASE"
audit["fresh_teacher_tree"] = teach
say("S2 fresh teacher tree @%s: code_refs=%d files=%d v32_present=%s head/tree ok=%s"
    % (C.BASE_COMMIT[:8], teach.get("code_reference_count", -1),
       teach.get("tracked_file_count", -1), teach.get("v32_runtime_present"),
       teach.get("head_equals_base_commit")))

audit["frozen_source_patch"] = scan_patch_from_failed_r3(
    "SOURCE_PATCH.diff", C.SOURCE_PATCH_SHA, C.SOURCE_PATCH_BYTES)
audit["frozen_t6_incremental_patch"] = scan_patch_from_failed_r3(
    "T6_INCREMENTAL_PATCH.diff", C.T6_INCREMENTAL_SHA, C.T6_INCREMENTAL_BYTES)
for k in ("frozen_source_patch", "frozen_t6_incremental_patch"):
    say("S3 %s: identity=%s added_refs=%s total_refs=%s"
        % (k, audit[k].get("verdict", audit[k].get("error")),
           audit[k].get("reference_count_added_or_removed"),
           audit[k].get("reference_count_total")))

audit["d4_wrapper_dir"] = scan_tree(C.D4_WRAPPER_DIR)
say("S4 d4 wrapper: total_code_refs=%d files=%d"
    % (audit["d4_wrapper_dir"].get("code_reference_count_total", -1),
       audit["d4_wrapper_dir"].get("files_scanned", -1)))

# the actually loaded v3.2 entrypoint: <RUNTIME_ROOT>/reaction_analogy/single_smiles_v32.py
v32 = scan_tree(V32_FROZEN_REPO)
v32["reference_entry_file"] = [r for r in v32["code_references"]
                               if r["path"].endswith("single_smiles_v32.py")]
rc_v32, out_v32, _ = C.run(["git", "rev-parse", "HEAD"], cwd=V32_FROZEN_REPO,
                           note="E0-L frozen v3.2 runtime HEAD (read-only)")
rc_ls, out_ls, _ = C.run(["git", "status", "--porcelain"], cwd=V32_FROZEN_REPO,
                         note="E0-L frozen v3.2 runtime dirtiness (read-only)")
entry_file = V32_FROZEN_REPO / "reaction_analogy" / "single_smiles_v32.py"
v32.update({
    "git_head": out_v32.strip(), "dirty_records": [x for x in out_ls.splitlines()][:20],
    "entrypoint": str(entry_file),
    "entrypoint_bytes": entry_file.stat().st_size if entry_file.is_file() else None,
    "entrypoint_sha256": C.sha256_file(entry_file) if entry_file.is_file() else "",
    "entrypoint_is_regular_non_symlink": (entry_file.is_file() and
                                          not entry_file.is_symlink()),
})
audit["actually_loaded_v32_runtime"] = v32
say("S5 frozen v3.2 runtime @%s: total_code_refs=%d files=%d entry=%s"
    % (v32.get("git_head", "?")[:8], v32.get("code_reference_count_total", -1),
       v32.get("files_scanned", -1), v32.get("entrypoint_sha256", "")[:12]))

audit["historical_6of6_forward_package"] = scan_tar(C.HISTORICAL_FORWARD)
say("S6 historical T6-R1 6/6 forward package: code_refs=%d text_members=%d"
    % (audit["historical_6of6_forward_package"].get("code_reference_count", -1),
       audit["historical_6of6_forward_package"].get("text_members_scanned", -1)))
audit["historical_t6_r2_full_chain_package"] = scan_tar(
    C.RETURN_ROOT / ("enzymecage_three_module_t6_r2_remainder_real_graph_20_test_eight_"
                     "record_schema_closure_20260908.tar.gz"))
say("S6b historical T6-R2 whole-chain package: code_refs=%d text_members=%d"
    % (audit["historical_t6_r2_full_chain_package"].get("code_reference_count", -1),
       audit["historical_t6_r2_full_chain_package"].get("text_members_scanned", -1)))

# first-round blocked package: how the previous round obtained lightgbm (disclosure only)
fr = scan_tar(C.FAILED_R3)
fr["note"] = ("the blocked first round additionally carried a pip-downloaded lightgbm 4.6.0 "
              "tree under runtime_assets/python_packages plus a pip-cache; this round is "
              "forbidden to pip/download, so that route is rejected and recorded only")
audit["blocked_first_round_package"] = fr
say("S+ blocked first-round package: code_refs=%d text_members=%d"
    % (fr.get("code_reference_count", -1), fr.get("text_members_scanned", -1)))

SIX_SOURCE_KEYS = ["enzyme_cage_code_root", "fresh_teacher_tree", "frozen_source_patch",
                   "frozen_t6_incremental_patch", "d4_wrapper_dir",
                   "actually_loaded_v32_runtime", "historical_6of6_forward_package"]
TOTAL_CODE_REFS = 0


def ref_total(entry):
    for key in ("code_reference_count_total", "code_reference_count",
                "reference_count_total"):
        if key in entry:
            return int(entry.get(key) or 0)
    return int(entry.get("code_reference_count", 0) or 0)


for k in SIX_SOURCE_KEYS:
    TOTAL_CODE_REFS += ref_total(audit[k])
PRODUCTION_CODE_REFS = (audit["enzyme_cage_code_root"].get("code_reference_count_production", 0)
                        + audit["actually_loaded_v32_runtime"].get(
                            "code_reference_count_production", 0))
say("LIGHTGBM_REFERENCE_COUNT(six sources, executable code)=%d "
    "(production-code subset=%d)" % (TOTAL_CODE_REFS, PRODUCTION_CODE_REFS))
say("per-source totals: %s" % json.dumps({k: ref_total(audit[k]) for k in SIX_SOURCE_KEYS}))

# ------------------------------------------------------------------ 3. T2B source identity
say("=== step 3: frozen T2B lightgbm capability identity ===")
sites_candidates = sorted(T2B_ENV.glob("lib/python3.*/site-packages"))
if not sites_candidates:
    print("BLOCKED_ENVIRONMENT_PREFLIGHT_LIGHTGBM :: T2B site-packages absent")
    sys.exit(3)
T2B_SITES = sites_candidates[0]
LG_PKG = T2B_SITES / "lightgbm"
DIST = sorted(T2B_SITES.glob("lightgbm-*.dist-info"))
so_files = sorted(LG_PKG.rglob("lib_lightgbm*.so*"))
pkg_init = LG_PKG / "__init__.py"
capability = {
    "t2b_env_root": str(T2B_ENV),
    "t2b_site_packages": str(T2B_SITES),
    "t2b_pyvenv_cfg": (T2B_ENV / "pyvenv.cfg").read_text(encoding="utf-8")
                      if (T2B_ENV / "pyvenv.cfg").is_file() else "",
    "lightgbm_package_dir": str(LG_PKG),
    "lightgbm_package_is_regular_non_symlink": LG_PKG.is_dir() and
                                                not LG_PKG.is_symlink(),
    "dist_info": [str(p.name) for p in DIST],
    "init_py": {"path": str(pkg_init),
                "bytes": pkg_init.stat().st_size if pkg_init.is_file() else None,
                "sha256": C.sha256_file(pkg_init) if pkg_init.is_file() else "",
                "readable": os.access(str(pkg_init), os.R_OK)},
    "shared_library": [{"path": str(p), "bytes": p.stat().st_size,
                        "sha256": C.sha256_file(p), "readable": os.access(str(p), os.R_OK),
                        "magic": p.read_bytes()[:4].hex()}
                       for p in so_files],
    "package_file_count": sum(1 for p in LG_PKG.rglob("*") if p.is_file()),
    "package_total_bytes": sum(p.stat().st_size for p in LG_PKG.rglob("*") if p.is_file()),
    "writable_by_this_task": os.access(str(LG_PKG), os.W_OK),
    "disclosed_note": "writable flag is informational only; this task never writes there "
                      "(see the read-only probe that re-hashes every file after injection)",
}
say("T2B lightgbm dir=%s so=%s"
    % (LG_PKG, [x["path"].split("/")[-1] for x in capability["shared_library"]]))

# ------------------------------------------------------------------ 4. compatibility
say("=== step 4: ${PY} vs T2B venv compatibility ===")
ABI_PROBE = ("import sys,sysconfig,platform,json;"
             "print(json.dumps({'executable':sys.executable,'prefix':sys.prefix,"
             "'version':sys.version.split()[0],'major_minor':list(sys.version_info[:2]),"
             "'soabi':sysconfig.get_config_var('SOABI'),"
             "'ext_suffix':sysconfig.get_config_var('EXT_SUFFIX'),"
             "'pyd':sysconfig.get_config_var('pyd'),"
             "'implementation':sys.implementation.name,'machine':platform.machine(),"
             "'libc':list(platform.libc_ver()),'abi':sys.abiflags}))")
rc_pin, out_pin, err_pin = C.run_py(["-B", "-c", ABI_PROBE],
                                    note="E0-L pinned interpreter ABI facts",
                                    label="e0l_pin_abi")
rc_t2b, out_t2b, err_t2b = C.run([str(T2B_ENV / "bin" / "python"), "-B", "-c", ABI_PROBE],
                                 note="E0-L T2B venv interpreter ABI facts")
if rc_pin != 0 or not out_pin.strip():
    problems.append("pinned ABI probe broken rc=%s err=%s" % (rc_pin, err_pin[-300:]))
if rc_t2b != 0 or not out_t2b.strip():
    problems.append("T2B ABI probe broken rc=%s err=%s" % (rc_t2b, err_t2b[-300:]))


def last_json(txt):
    for line in reversed(txt.strip().splitlines()):
        try:
            return json.loads(line)
        except Exception:
            continue
    return {}


PIN_ABI, T2B_ABI = last_json(out_pin), last_json(out_t2b)
if not PIN_ABI or not T2B_ABI:
    problems.append("ABI facts unpresent: pinned=%s t2b=%s" % (bool(PIN_ABI), bool(T2B_ABI)))
compat = {"pinned": PIN_ABI, "t2b": T2B_ABI, "checks": {},
          "probe_rc": {"pinned": rc_pin, "t2b": rc_t2b}}
compat["checks"]["python_major_minor_equal"] = (
    PIN_ABI.get("major_minor") == T2B_ABI.get("major_minor"))
compat["checks"]["soabi_equal"] = PIN_ABI.get("soabi") == T2B_ABI.get("soabi")
compat["checks"]["ext_suffix_equal"] = (PIN_ABI.get("ext_suffix") ==
                                        T2B_ABI.get("ext_suffix"))
compat["checks"]["implementation_equal"] = (PIN_ABI.get("implementation") ==
                                            T2B_ABI.get("implementation"))
compat["checks"]["cpu_arch_equal"] = PIN_ABI.get("machine") == T2B_ABI.get("machine")
compat["checks"]["glibc_equal"] = PIN_ABI.get("libc") == T2B_ABI.get("libc")
# native library architecture, read from the ELF header of lib_lightgbm
elf = {}
for item in capability["shared_library"]:
    blob = Path(item["path"]).read_bytes()[:20]
    elf[item["path"]] = {
        "elf_class": {2: "ELF32", 1: "ELF?"}.get(blob[4], blob[4]),
        "elf_data": {1: "little"}.get(blob[5], blob[5]),
        "e_machine": int.from_bytes(blob[18:20], "little"),
        "e_machine_name": "x86-64" if int.from_bytes(blob[18:20], "little") == 62 else "other",
    }
compat["shared_library_elf"] = elf
compat["checks"]["shared_library_x86_64"] = bool(elf) and all(
    v["e_machine_name"] == "x86-64" for v in elf.values())
rc_ldd, out_ldd, _ = C.run(["ldd", capability["shared_library"][0]["path"]]
                           if capability["shared_library"] else ["true"],
                           note="E0-L lib_lightgbm dynamic dependencies")
compat["ldd"] = out_ldd.strip()
compat["cuda_linked_shared_library"] = bool(re.search(r"lib(cudart|cublas|nvrtc)", out_ldd))
compat["host_cpu_machine"] = platform.machine()
FAILED_CHECKS = [k for k, v in compat["checks"].items() if v is not True]
say("compat checks: %s" % json.dumps(compat["checks"]))
say("shared library arch=%s cuda_linked=%s"
    % ([v["e_machine_name"] for v in elf.values()], compat["cuda_linked_shared_library"]))

if FAILED_CHECKS:
    problems.append("T2B lightgbm compatibility failed: %s" % ",".join(FAILED_CHECKS))
if not capability["shared_library"]:
    problems.append("lib_lightgbm shared library absent in the frozen T2B capability")
for item in capability["shared_library"] + [capability["init_py"]]:
    if item.get("readable") is False:
        problems.append("capability file not readable: %s" % item.get("path"))

# ------------------------------------------------------------------ 5. overlay probe
say("=== step 5: last-position read-only injection probe (no shadowing) ===")
probe = Path(__file__).resolve().parent / "probe_lightgbm_overlay.py"
if not probe.is_file():
    problems.append("overlay probe script absent: %s" % probe)
    rc_probe, out_probe, err_probe = 99, "", "probe absent"
else:
    rc_probe, out_probe, err_probe = C.run_py(
        ["-B", str(probe), str(T2B_SITES)],
        note="E0-L before/after module source matrix + lightgbm overlay import",
        label="e0l_overlay_probe", timeout=900)
    payload = {}
    for line in out_probe.splitlines():
        if line.startswith("R1_LG_PROBE "):
            payload = json.loads(line[len("R1_LG_PROBE "):])
    say("probe rc=%s verdict=%s" % (rc_probe, payload.get("verdict")))
    if rc_probe != 0 or not payload:
        problems.append("overlay probe failed rc=%s stderr_tail=%s"
                        % (rc_probe, err_probe.strip()[-300:]))
    if payload.get("sys_executable") != C.PY:
        problems.append("overlay probe sys.executable drifted: %s"
                        % payload.get("sys_executable"))
    if payload.get("shadowed_or_drifted_modules"):
        problems.append("modules shadowed by the T2B path: %s"
                        % payload.get("shadowed_or_drifted_modules"))
    if payload.get("overlay_import_ok") is not True:
        problems.append("overlay lightgbm import failed: %s" % payload.get("overlay_error"))

OVERLAY = payload

# ------------------------------------------------------------------ 6. verdict + files
LIGHTGBM_CLOSE_KEYS = {}
if BARE["verdict"] == "FAIL":
    LIGHTGBM_CLOSE_KEYS["LIGHTGBM_BARE_IMPORT"] = "FAIL"
else:
    LIGHTGBM_CLOSE_KEYS["LIGHTGBM_BARE_IMPORT"] = BARE["verdict"]
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_REFERENCE_COUNT"] = str(TOTAL_CODE_REFS)
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_REFERENCE_COUNT_GT_ZERO"] = str(TOTAL_CODE_REFS > 0)
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_OVERLAY_IMPORT"] = ("PASS" if OVERLAY.get("overlay_import_ok")
                                                  else "FAIL")
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_VERSION"] = OVERLAY.get("version", "")
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_MODULE_PATH"] = OVERLAY.get("module_path", "")
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_SHARED_LIBRARY_PATH"] = OVERLAY.get("shared_library_path", "")
LIGHTGBM_CLOSE_KEYS["PYTHON_EXECUTABLE"] = C.PY
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_CAPABILITY_SOURCE"] = str(T2B_SITES)
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_INJECTION_METHOD"] = (
    "sys.path.append(<frozen T2B site-packages>) - last position, read-only, "
    "no pip/conda/apt, no download, no copy into ${PY}")
LIGHTGBM_CLOSE_KEYS["LIGHTGBM_NOT_A_SUBSTITUTION"] = (
    "xgboost 3.3.0 is gated as its own real dependency; it is NOT presented as a "
    "replacement for LightGBM")

VERDICT = "BLOCK" if problems else "PASS"
ENVIRONMENT_STATUS = ("PASS_WITH_PINNED_READONLY_T2B_LIGHTGBM_OVERLAY" if VERDICT == "PASS"
                      else "BLOCKED_ENVIRONMENT_PREFLIGHT_LIGHTGBM")

OPERATOR_RULING = """裁定：允许继续完整链，但必须采用“冻结、只读、末位注入、兼容性先验”的T2B LightGBM能力补充。

原因：
- v3.2真实运行入口确实引用LightGBM；
- ${PY}裸import真实失败，必须保留traceback，不能写成PASS；
- 主机已有冻结T2B venv中的LightGBM 4.7.0；
- 该处理不改变模型、ranker、老师拓扑或sys.executable，也不安装/下载任何东西。

执行要求：
1. 先记录：LIGHTGBM_BARE_IMPORT=FAIL / LIGHTGBM_REFERENCE_COUNT=>0 / 裸import完整traceback
   / 全部引用path:line / T2B venv、site-packages、LightGBM 4.7.0来源路径及文件SHA。
2. 核对${PY}与T2B venv：Python major.minor一致；SOABI兼容；CPU/CUDA架构兼容；
   lightgbm Python包和lib_lightgbm共享库均存在、可读、身份固定。
   任一不成立，立即BLOCKED_ENVIRONMENT_PREFLIGHT_LIGHTGBM并完成三文件，不进入大计算。
3. 不允许让T2B site-packages遮蔽${PY}已有依赖。PYTHONPATH顺序必须保证${PY}原有
   site-packages优先，T2B site-packages只作为最后补充；或在${PY}启动后用
   sys.path.append(T2B_SITE_PACKAGES)末位加入。sys.executable必须仍精确等于
   /usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python
4. 注入前后比较ase、torch、torch_geometric、numpy、scipy、sklearn、pandas、rdkit、
   pydantic、langgraph、xgboost等module.__file__与版本。除lightgbm外，任何模块来源
   发生变化或被T2B环境遮蔽，立即BLOCK，不继续。
5. 注入后记录：LIGHTGBM_OVERLAY_IMPORT=PASS / LIGHTGBM_VERSION=4.7.0 /
   LIGHTGBM_MODULE_PATH=<冻结T2B路径> / LIGHTGBM_SHARED_LIBRARY_PATH=<真实路径> /
   PYTHON_EXECUTABLE=<固定${PY}> /
   ENVIRONMENT_STATUS=PASS_WITH_PINNED_READONLY_T2B_LIGHTGBM_OVERLAY
   不得把裸import失败改写成PASS，也不得称xgboost替代LightGBM。
6. 在读取16GB/37GB资产和启动GPU前，先用真实v3.2入口完成TEST-01及确定性重复，并真实
   加载固定LightGBM ranker。若TEST-01失败，立即BLOCKED_AT_T2_V32_LIGHTGBM，不进入GPU。
7. TEST-01通过后，按原合同继续：§4.3 → §5 → §6.1全部157项 → §6.2 → §6.3 → 6/6 forward
   → real LangGraph → 8 smoke → TEST-01—20 → C8→T5 → 三文件。
8. 在FINAL_STATUS、validation和报告中完整披露：裸import失败、真实引用、只读冻结能力来源、
   兼容性检查、注入后module来源不变和TEST-01结果。
   这是操作员明确裁定的环境能力补充，不是老师科学合同变更。

禁止pip/conda/apt、下载、复制包进${PY}、修改模型代码、修改老师graph/state。"""

supersession = {
    "supersedes": "PYTHON_RUNTIME_PREFLIGHT.json:operator_correction_lightgbm.status_keys",
    "superseded_keys": {
        "LIGHTGBM_IMPORT": "NOT_IMPORTABLE_UNREQUIRED",
        "LIGHTGBM_REFERENCE_COUNT": "see LIGHTGBM_REFERENCE_AUDIT.json (final count is "
                                    "taken on the fresh tree)",
        "LIGHTGBM_GATE": "NOT_APPLICABLE",
    },
    "why": ("those three keys were issued by the operator's first correction under the "
            "stated premise that lightgbm had zero references and that the v3.2 entry used "
            "xgboost. The six-source audit below refutes that premise: the actually loaded "
            "frozen v3.2 runtime does import lightgbm at module scope. The operator issued "
            "a second ruling on 2026-09-10, recorded verbatim in this file, which replaces "
            "NOT_APPLICABLE with a frozen read-only last-position capability overlay."),
    "environment_preflight_probe_ran": ("once (p2_e0.py); this close-out is a separate gate "
                                        "that only reads identity data and imports a module, "
                                        "so the import gate itself was not re-run"),
}

doc = {
    "task_id": C.TASK_ID,
    "generated_utc": C.now_utc(),
    "phase": "E0-L lightgbm close-out (operator adjudication 2026-09-10)",
    "operator_ruling_verbatim": OPERATOR_RULING,
    "supersession_of_e0_provisional_keys": supersession,
    "bare_import": BARE,
    "reference_audit": audit,
    "lightgbm_reference_count_total": TOTAL_CODE_REFS,
    "t2b_capability_identity": capability,
    "compatibility": compat,
    "overlay_probe": OVERLAY,
    "gate_keys": LIGHTGBM_CLOSE_KEYS,
    "environment_status": ENVIRONMENT_STATUS,
    "verdict": VERDICT,
    "problems": problems,
}
C.RETURN_DIR.mkdir(parents=True, exist_ok=True)
(C.RETURN_DIR / "LIGHTGBM_REFERENCE_AUDIT.json").write_text(
    json.dumps({"task_id": C.TASK_ID, "generated_utc": C.now_utc(),
                "reference_count_total": TOTAL_CODE_REFS, "sources": audit},
               ensure_ascii=False, indent=2), encoding="utf-8")
(C.RETURN_DIR / "LIGHTGBM_GATE_CLOSE.json").write_text(
    json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
(C.RETURN_DIR / "LIGHTGBM_OVERLAY_COMPATIBILITY_CHECK.json").write_text(
    json.dumps({"task_id": C.TASK_ID, "generated_utc": C.now_utc(),
                "compatibility": compat, "t2b_capability_identity": capability,
                "checks": compat["checks"],
                "verdict": "PASS" if not FAILED_CHECKS else "FAIL"},
               ensure_ascii=False, indent=2), encoding="utf-8")

rows = ["module,version_before,before_file,version_after,after_file,changed,"
        "under_pinned_prefix,verdict"]
if OVERLAY:
    for r in OVERLAY.get("modules", []):
        rows.append(",".join(str(x) for x in [
            r["module"], r["before_version"], r["before_file"], r["after_version"],
            r["after_file"], r["changed"], r["before_in_pinned_prefix"], r["verdict"]]))
(C.RETURN_DIR / "LIGHTGBM_OVERLAY_MODULE_SOURCE_MATRIX.csv").write_text(
    "\n".join(rows) + "\n", encoding="utf-8")

say("=== stdout record ===")
say("LIGHTGBM_BARE_IMPORT=%s" % LIGHTGBM_CLOSE_KEYS["LIGHTGBM_BARE_IMPORT"])
say("LIGHTGBM_REFERENCE_COUNT=%s (>0 means the first correction premise is refuted)"
    % LIGHTGBM_CLOSE_KEYS["LIGHTGBM_REFERENCE_COUNT"])
say("LIGHTGBM_OVERLAY_IMPORT=%s" % LIGHTGBM_CLOSE_KEYS["LIGHTGBM_OVERLAY_IMPORT"])
say("LIGHTGBM_VERSION=%s" % LIGHTGBM_CLOSE_KEYS["LIGHTGBM_VERSION"])
say("LIGHTGBM_MODULE_PATH=%s" % LIGHTGBM_CLOSE_KEYS["LIGHTGBM_MODULE_PATH"])
say("LIGHTGBM_SHARED_LIBRARY_PATH=%s" % LIGHTGBM_CLOSE_KEYS["LIGHTGBM_SHARED_LIBRARY_PATH"])
say("PYTHON_EXECUTABLE=%s" % LIGHTGBM_CLOSE_KEYS["PYTHON_EXECUTABLE"])
say("ENVIRONMENT_STATUS=%s" % ENVIRONMENT_STATUS)
say("LIGHTGBM_PROBLEMS=%s" % json.dumps(problems, ensure_ascii=False))
(C.RETURN_DIR / "LIGHTGBM_GATE_STDOUT.txt").write_text("\n".join(LINES) + "\n",
                                                        encoding="utf-8")
say("LIGHTGBM_GATE_CLOSE=%s files_written=4" % VERDICT)
print("LIGHTGBM_GATE_VERDICT=%s" % VERDICT)
if VERDICT == "BLOCK":
    print("FIRST_FAILING_GATE=BLOCKED_ENVIRONMENT_PREFLIGHT_LIGHTGBM")
    sys.exit(3)
