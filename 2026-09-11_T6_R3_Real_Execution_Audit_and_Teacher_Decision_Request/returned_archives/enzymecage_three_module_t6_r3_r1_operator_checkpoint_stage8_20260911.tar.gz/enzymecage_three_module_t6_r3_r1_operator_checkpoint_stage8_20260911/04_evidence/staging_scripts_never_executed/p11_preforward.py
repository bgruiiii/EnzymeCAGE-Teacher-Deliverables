#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""§6.3 native load and the per-UID sequence/GVP/pocket/ESM hard gate, before any GPU runtime.

The first round called ``load_geometric_dataset`` but wrote ``"sequence": ""`` into the
candidate CSV and then inspected only ``dataset[0]``.  With an empty sequence the teacher's
``GeometricDataset.get_esm_feat`` takes its ``print('ESM feature not found')`` branch and
returns ``torch.zeros(esm_dim)`` (enzymecage/dataset/geometric.py:357-363), so a zero-vector
ESM feature could hide behind a metadata-only record.  This step closes both gaps:

* the sequence column is filled from the frozen formal splits through the production
  ``PrecomputedAssetIndex.sequence_for`` *and* independently re-derived by a direct streaming
  read of the same three split files; the two derivations must agree;
* every row of every reaction dataset is materialised through ``dataset[i]``, not just row 0,
  with stdout captured per row, so an ``ESM feature not found`` line is attributed to the exact
  reaction/row/UID that produced it instead of being lost in a console log.

Nothing here initialises CUDA: the gate exists precisely so that an identity failure blocks the
three expensive GPU workers before any of them creates a runtime.  §9 allows the three native
loads to run exactly once, so their raw evidence is persisted in logs/ and a second invocation
re-derives the reports from that file instead of re-loading 54 GB of protein assets.
"""
import csv
import gzip
import hashlib
import io
import json
import os
import pickle
import re
import sys
import time
import traceback
from contextlib import redirect_stdout
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import r1_common as C  # noqa: E402

C.emit_interp()
RD = C.RETURN_DIR
RD.mkdir(parents=True, exist_ok=True)
NATIVE = C.RUNTIME_ASSETS / "native_load"
GATE_JSON = RD / "UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json"
EVIDENCE = C.LOGS / "p11_native_evidence.json"
INVOCATIONS = C.LOGS / "p11_invocations.jsonl"
FWD_UIDS = ["A0A011QK89", "A0A017SP50"]          # §7: the two UIDs that really enter forward
NOT_FOUND = "ESM feature not found"
PROBLEMS = []
SAY = []


def say(msg):
    print(msg, flush=True)
    SAY.append(msg)


def problem(label, msg, **kw):
    rec = {"label": label, "problem": msg}
    rec.update(kw)
    PROBLEMS.append(rec)
    say("  PROBLEM %s :: %s" % (label, msg))


def sha_str(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# ------------------------------------------------------- 0. run-once discipline and §6.2 gate
with open(str(INVOCATIONS), "a", encoding="utf-8") as fh:
    fh.write(json.dumps({"utc": C.now_utc(), "argv0": sys.argv[0],
                         "executable": sys.executable, "pid": os.getpid()}) + "\n")
invocation_count = sum(1 for _ in open(str(INVOCATIONS), encoding="utf-8"))
say("== 0. pre-forward identity gate (invocation %d of this step)" % invocation_count)

prior = None
if EVIDENCE.exists():
    try:
        prior = json.loads(EVIDENCE.read_text(encoding="utf-8"))
    except ValueError:
        prior = None
    if prior is None:
        problem("p11_evidence", "existing raw evidence file is unreadable; refusing to guess",
                path=str(EVIDENCE))
        say("== verdict: T3B_NATIVE_LOAD=BLOCKED_AT_SEQUENCE_ESM_IDENTITY")
        sys.exit(3)
    say("  raw native-load evidence from this task's first invocation will be adopted")

gate62_path = RD / "FIXED_ASSET_IDENTITY_GATE.json"
if not gate62_path.exists():
    problem("p62_gate", "FIXED_ASSET_IDENTITY_GATE.json is absent, §6.2 did not run")
    sys.exit(3)
gate62 = json.loads(gate62_path.read_text(encoding="utf-8"))
if gate62.get("status") != "PASS":
    problem("p62_gate", "§6.2 fixed asset identity is %s" % gate62.get("status"))
    sys.exit(3)
say("  §6.2 FIXED_ASSET_IDENTITY=%s at %s" % (gate62["status"], gate62["utc"]))
PROTEIN_SHA_FROM_62 = {r["asset"]: r for r in gate62["protein_assets"]}

# ------------------------------------------------------- 1. CUDA must still be untouched
import torch  # noqa: E402
import yaml  # noqa: E402

say("  torch=%s cuda_initialised_before_gate=%s" % (torch.__version__,
                                                    torch.cuda.is_initialized()))
if torch.cuda.is_initialized():
    problem("cuda_prelude", "CUDA was already initialised before this gate ran")

sys.path.insert(0, C.CODE_ROOT)
sys.path.insert(0, str(C.D4_WRAPPER_PARENT))
import enzymecage.dataset.geometric as geometric  # noqa: E402
import enzymecage.dataset.sharded_protein as sharded  # noqa: E402
from enzymecage_wrapper.asset_index import PrecomputedAssetIndex  # noqa: E402

COLS = {"UID_COL": geometric.UID_COL, "SEQ_COL": geometric.SEQ_COL,
        "RXN_COL": geometric.RXN_COL, "LABEL_COL": "Label"}
say("  teacher column names in use: %s" % json.dumps(COLS, sort_keys=True))

# ------------------------------------------------------- 2. the overlay config is re-checked
say("== 1. the task-local overlay config the native loader will really read")
configs = []
for seed in C.SEEDS:
    p = C.V1_OVERLAY / ("3b_ensemble/seed_%d/config.yaml" % seed)
    if not p.is_file():
        problem("overlay_config", "missing", seed=seed, path=str(p))
        continue
    configs.append((seed, yaml.safe_load(p.read_text(encoding="utf-8"))))
if len(configs) != 5:
    problem("overlay_config", "expected five overlay configs, found %d" % len(configs))
cfg = configs[0][1] if configs else {}
for k in C.OVERLAY_CONFIG_FIELDS:
    if not str(cfg.get(k, "")).startswith(str(C.REACTION_OVERLAY)):
        problem("overlay_field", "config field does not point at the §6.2 reaction overlay",
                field=k, value=str(cfg.get(k)))
for _seed, _c in configs[1:]:
    if {k: _c.get(k) for k in C.OVERLAY_CONFIG_FIELDS} != \
            {k: cfg.get(k) for k in C.OVERLAY_CONFIG_FIELDS}:
        problem("overlay_field_seed", "overlay fields differ across seeds", seed=_seed)
say("  rxn_fp            = %s" % cfg.get("rxn_fp"))
say("  mol_conformation  = %s" % cfg.get("mol_conformation"))
say("  reaction_center   = %s" % cfg.get("reaction_center"))

# the three protein assets must be the §6.2 pinned files, not a look-alike directory
ASSET_KEY_TO_62_LABEL = {"protein_gvp_feat": "GVP", "esm_node_feature": "ESM_NODE",
                         "esm_mean_feature": "ESM_MEAN"}
for key, lab in ASSET_KEY_TO_62_LABEL.items():
    got = str(cfg.get(key, ""))
    ref = PROTEIN_SHA_FROM_62.get(lab, {})
    if not got or os.path.realpath(got) != os.path.realpath(str(ref.get("path", ""))):
        problem("config_asset_identity",
                "config %s does not resolve to the §6.2 pinned asset" % key,
                config_value=got, pinned=str(ref.get("path")))
    for probe in (cfg["rxn_fp"], cfg["reaction_center"],
                  os.path.join(str(cfg["mol_conformation"]), "mol2id.csv"),
                  os.path.join(str(cfg["mol_conformation"]), "mol_graph_dict.pt")):
        if not os.path.isfile(probe):
            problem("overlay_member", "overlay member is missing", path=probe)
say("  every configured asset path resolves to a §6.2 verified regular file")

# ------------------------------------------------------- 3. frozen sequence identity, twice
say("== 2. per-UID sequence identity, derived twice independently")
auth_md = C.INPUT_ROOT / "authority" / C.AUTH_ROOTNAME / C.AUTH_R1_AUDIT
auth_text = auth_md.read_text(encoding="utf-8", errors="replace") if auth_md.exists() else ""
if not auth_text:
    problem("authority_audit", "the SHA-verified authority audit could not be read",
            path=str(auth_md))
AUTH_SEQ_PINS = {m.group(1): {"length": int(m.group(2)), "sha256": m.group(3)}
                 for m in re.finditer(r"(A0A[0-9A-Z]{7})\s+length=(\d+)\s+SHA=([0-9a-f]{64})",
                                      auth_text)}
# An empty pin dict must never be readable as "the authority simply has no pins": that is how a
# wrong UID width silently disabled the comparison.  The expected pins are named explicitly.
say("  authority R1 audit carries sequence pins for: %s"
    % json.dumps(AUTH_SEQ_PINS, sort_keys=True))
if auth_text and not AUTH_SEQ_PINS:
    problem("authority_pin_parse",
            "the authority audit was read but yielded no sequence pin; the pin pattern or the "
            "expected file is wrong, so no UID could be pin-verified", path=str(auth_md))
for uid in FWD_UIDS:
    if auth_text and uid not in AUTH_SEQ_PINS:
        problem("authority_pin_missing:%s" % uid,
                "a forwarded UID has no frozen sequence pin in the authority R1 audit")

SPLITS = [cfg["train_path"], cfg["valid_path"], cfg["test_path"]]
split_rows, split_totals = {}, {}
t = time.monotonic()
for f in SPLITS:
    fp = Path(f)
    if not fp.is_file():
        problem("formal_split", "configured split file is missing", path=f)
        continue
    with open(str(fp), newline="", encoding="utf-8") as fh:
        rd = csv.DictReader(fh)
        for i, r in enumerate(rd, 1):
            split_totals[fp.name] = i
            u = r.get(geometric.UID_COL)
            if u in C.THREE_UIDS:
                split_rows.setdefault(u, {}).setdefault(r[geometric.SEQ_COL], []).append(i)
say("  direct streaming read of the three frozen splits (%s) in %.1fs"
    % (json.dumps(split_totals, sort_keys=True), time.monotonic() - t))

UIDS = list(C.THREE_UIDS)
seq_table = {}
for uid in UIDS:
    per_split = split_rows.get(uid, {})
    distinct = sorted(per_split)
    one = distinct[0] if len(distinct) == 1 else ""
    rec = {"uid": uid, "is_forward_uid": uid in FWD_UIDS,
           "split_row_hits": sum(len(v) for v in per_split.values()),
           "distinct_sequence_count": len(distinct),
           "ambiguous": len(distinct) != 1,
           "sequence_non_empty": bool(one.strip()),
           "sequence_length": len(one),
           "sequence_sha256_utf8": sha_str(one) if one else "",
           "sequence_charset_is_standard_aa": bool(one) and set(one) <= set("ACDEFGHIKLMNPQRSTVWY"),
           "authority_pin": AUTH_SEQ_PINS.get(uid, {"pin_available": False}),
           "matches_authority_pin": bool(one) and AUTH_SEQ_PINS.get(uid, {}).get("sha256")
           == sha_str(one)}
    seq_table[uid] = rec
    say("  [%-11s] rows=%-3d distinct=%d len=%-4s sha=%s authority_pin=%s"
        % (uid, rec["split_row_hits"], rec["distinct_sequence_count"], rec["sequence_length"],
           rec["sequence_sha256_utf8"][:12] or "-",
           "MATCH" if rec["matches_authority_pin"]
           else ("MISMATCH" if uid in AUTH_SEQ_PINS else "NO_PIN_IN_AUTHORITY")))
    if rec["ambiguous"] or not rec["sequence_non_empty"]:
        problem("sequence_identity:%s" % uid,
                "the frozen splits do not yield exactly one non-empty sequence for this UID",
                distinct_sequence_count=rec["distinct_sequence_count"])
    if uid in AUTH_SEQ_PINS and not rec["matches_authority_pin"]:
        problem("sequence_pin:%s" % uid, "observed sequence SHA differs from the authority pin",
                observed=rec["sequence_sha256_utf8"], expected=AUTH_SEQ_PINS[uid]["sha256"])
    if uid in AUTH_SEQ_PINS and rec["sequence_length"] != AUTH_SEQ_PINS[uid]["length"]:
        problem("sequence_length:%s" % uid, "observed length differs from the authority pin",
                observed=rec["sequence_length"], expected=AUTH_SEQ_PINS[uid]["length"])
for uid in FWD_UIDS:
    if not seq_table[uid]["matches_authority_pin"]:
        problem("forward_uid_sequence_pin:%s" % uid,
                "an actually forwarded UID has no matching frozen sequence SHA")

D4_ROWS, D4_TOTAL = {}, 0
with gzip.open(str(C.D4_WHITELIST), "rt", encoding="utf-8") as fh:
    rd = csv.DictReader(fh)
    D4_FIELDS = rd.fieldnames or []
    for r in rd:
        D4_TOTAL += 1
        if r.get("uid") in C.THREE_UIDS:
            D4_ROWS.setdefault(r["uid"], r)
say("  D4 whitelist rows=%d columns=%s" % (D4_TOTAL, json.dumps(D4_FIELDS)))
for uid in UIDS:
    rec = seq_table[uid]
    d4sha = D4_ROWS.get(uid, {}).get("sequence_sha256", "")
    rec["d4_frozen_sequence_sha256"] = d4sha
    rec["matches_d4_frozen_sha"] = bool(d4sha) and d4sha == rec["sequence_sha256_utf8"]
    if uid in AUTH_SEQ_PINS:
        rec["frozen_sha_provenance"] = "authority R1 audit pin, cross-checked against D4"
    else:
        # A missing authority pin must be disclosed, not silently downgraded: for such a UID the
        # D4 whitelist sequence_sha256 is the independent frozen reference.
        rec["frozen_sha_provenance"] = ("D4 whitelist sequence_sha256 (the authority R1 audit "
                                       "carries no sequence pin for this UID)")
        if not rec["matches_d4_frozen_sha"]:
            problem("d4_sequence_pin:%s" % uid, "observed sequence SHA differs from the D4 "
                    "frozen SHA and no authority pin exists to fall back on",
                    observed=rec["sequence_sha256_utf8"], expected=d4sha)
    say("  %-11s frozen_sha_provenance=%s matches_d4=%s authority=%s"
        % (uid, "D4" if uid not in AUTH_SEQ_PINS else "authority+D4",
           rec["matches_d4_frozen_sha"], "MATCH" if rec["matches_authority_pin"] else "none"))

# ------------------------------------------------------- 4. production asset index
say("== 3. the production PrecomputedAssetIndex over the §6.2 overlay config")
t = time.monotonic()
ai = PrecomputedAssetIndex(cfg)
ai_seconds = round(time.monotonic() - t, 2)
inventory = ai.inventory()
say("  built in %.2fs: unambiguous_uids=%s gvp=%s pocket=%s sequence_esm=%s drfp=%s "
    "molecules=%s mol_graphs=%s"
    % (ai_seconds, inventory.get("unambiguous_uid_count"), inventory.get("gvp_uid_count"),
       inventory.get("pocket_node_uid_count"), inventory.get("sequence_esm_count"),
       inventory.get("drfp_reaction_count"), inventory.get("molecule_index_count"),
       inventory.get("molecule_graph_count")))
for uid in UIDS:
    prod = ai.uid_to_sequence.get(uid)
    indep = next(iter(split_rows.get(uid, {})), None)
    same = bool(prod) and prod == indep and len(split_rows.get(uid, {})) == 1
    seq_table[uid]["production_index_sequence_agrees_with_direct_read"] = same
    seq_table[uid]["production_index_sequence_length"] = len(prod or "")
    seq_table[uid]["in_ambiguous_uids"] = uid in ai.ambiguous_uids
    if not same:
        problem("sequence_derivation:%s" % uid,
                "PrecomputedAssetIndex.sequence_for disagrees with the direct split read")
    if seq_table[uid]["in_ambiguous_uids"]:
        problem("ambiguous_uid:%s" % uid, "the production asset index marks this UID ambiguous")
    say("  %-11s sequence_for=%s agrees_with_direct_read=%s ambiguous=%s"
        % (uid, len(prod or ""), same, seq_table[uid]["in_ambiguous_uids"]))

# ------------------------------------------------------- 5. teacher protein loaders
say("== 4. the read-only protein assets through the teacher's own trusted loaders")
t = time.monotonic()
gvp_map = sharded.load_protein_gvp_data(cfg["protein_gvp_feat"])
gvp_seconds = round(time.monotonic() - t, 2)
t = time.monotonic()
node_map = sharded.load_pocket_node_feature_data(cfg["esm_node_feature"])
node_seconds = round(time.monotonic() - t, 2)
t = time.monotonic()
with open(cfg["esm_mean_feature"], "rb") as fh:
    esm_mean = pickle.load(fh)
mean_seconds = round(time.monotonic() - t, 2)
asset_load = {
    "gvp": {"path": cfg["protein_gvp_feat"], "type": type(gvp_map).__name__,
            "entries": len(gvp_map), "seconds": gvp_seconds,
            "sha256_verified_in": "§6.2", "sha256": PROTEIN_SHA_FROM_62.get("GVP", {}).get("sha256")},
    "pocket_node": {"path": cfg["esm_node_feature"], "type": type(node_map).__name__,
                    "entries": len(node_map), "seconds": node_seconds,
                    "sha256_verified_in": "§6.2",
                    "sha256": PROTEIN_SHA_FROM_62.get("ESM_NODE", {}).get("sha256")},
    "esm_mean": {"path": cfg["esm_mean_feature"], "type": type(esm_mean).__name__,
                 "entries": len(esm_mean), "seconds": mean_seconds,
                 "sha256_verified_in": "§6.2",
                 "sha256": PROTEIN_SHA_FROM_62.get("ESM_MEAN", {}).get("sha256")},
}
for k, v in asset_load.items():
    say("  %-11s type=%-6s entries=%-7d in %5.1fs sha=%s"
        % (k, v["type"], v["entries"], v["seconds"], str(v["sha256"])[:12]))


def tmeta(name, value):
    """Real tensor metadata, never a HeteroData meta-attribute."""
    if value is None:
        return {"name": name, "present": False, "shape": None, "dtype": None, "device": None}
    t = value if torch.is_tensor(value) else torch.as_tensor(value)
    rec = {"name": name, "present": True, "shape": list(t.shape), "dtype": str(t.dtype),
           "device": str(t.device), "numel": int(t.numel())}
    if t.dtype.is_floating_point or t.dtype.is_complex:
        rec["all_finite"] = bool(torch.isfinite(t).all())
        rec["abs_sum"] = float(t.abs().sum())
        rec["nonzero_elements"] = int((t != 0).sum().item())
        rec["is_all_zero"] = bool((t == 0).all().item())
    else:
        rec["min"] = int(t.min()) if t.numel() else None
        rec["max"] = int(t.max()) if t.numel() else None
    return rec


say("== 5. per-UID membership in GVP / pocket node / ESM mean")
UID_GATE = []
for uid in UIDS:
    seq = ai.uid_to_sequence.get(uid) or ""
    row = {"uid": uid, "is_forward_uid": uid in FWD_UIDS,
           "sequence_non_empty": bool(seq.strip()), "sequence_length": len(seq),
           "sequence_sha256_utf8": sha_str(seq) if seq else "",
           "sequence_sha256_equals_independent_derivation": (
               bool(seq) and sha_str(seq) == seq_table[uid]["sequence_sha256_utf8"]),
           "in_gvp": uid in gvp_map, "in_pocket_node": uid in node_map,
           "sequence_in_esm_mean": bool(seq) and seq in esm_mean,
           "has_enzyme_through_production_path": ai.has_enzyme(uid),
           "d4_whitelist_present": uid in D4_ROWS, "d4_flags_failed": [],
           "not_found_fallback_possible": not (bool(seq) and seq in esm_mean)}
    for k in ("unambiguous_sequence_available", "gvp_available", "pocket_node_available",
              "sequence_esm_available", "complete_d4_enzyme_assets"):
        if D4_ROWS.get(uid, {}).get(k) != "True":
            row["d4_flags_failed"].append("%s=%s" % (k, D4_ROWS.get(uid, {}).get(k)))
    if row["d4_whitelist_present"]:
        row["d4_sequence_sha256_agrees"] = (
            D4_ROWS[uid].get("sequence_sha256") == row["sequence_sha256_utf8"])
    if uid in gvp_map:
        row["gvp_node_xyz"] = tmeta("node_xyz", gvp_map[uid][0])
        row["gvp_seq_field"] = tmeta("seq", gvp_map[uid][1])
        row["gvp_arity"] = len(gvp_map[uid])
    if uid in node_map:
        row["pocket_node_feature"] = tmeta("esm_node_feature", node_map[uid])
        if uid in gvp_map:
            row["pocket_nodes_equal_gvp_nodes"] = (
                row["pocket_node_feature"]["shape"][0] == row["gvp_node_xyz"]["shape"][0])
    if seq and seq in esm_mean:
        row["esm_mean_vector"] = tmeta("esm_feature", esm_mean[seq])
    ok = (row["sequence_non_empty"]
          and row["sequence_sha256_equals_independent_derivation"]
          and row["in_gvp"] and row["in_pocket_node"] and row["sequence_in_esm_mean"]
          and row["has_enzyme_through_production_path"] and row["d4_whitelist_present"]
          and not row["d4_flags_failed"]
          and row.get("d4_sequence_sha256_agrees", False)
          and row.get("pocket_nodes_equal_gvp_nodes", False)
          and row.get("esm_mean_vector", {}).get("all_finite") is True
          and row.get("esm_mean_vector", {}).get("abs_sum", 0) > 0
          and row.get("esm_mean_vector", {}).get("nonzero_elements", 0) > 0
          and row.get("esm_mean_vector", {}).get("is_all_zero") is False)
    row["status"] = "PASS" if ok else "FAIL"
    UID_GATE.append(row)
    say("  [%-4s] %-11s gvp=%s pocket=%s esm_mean=%s has_enzyme=%s d4_ok=%s "
        "pocket==gvp_nodes=%s esm_abs_sum=%.4g nonzero=%s"
        % (row["status"], uid, row["in_gvp"], row["in_pocket_node"],
           row["sequence_in_esm_mean"], row["has_enzyme_through_production_path"],
           not row["d4_flags_failed"], row.get("pocket_nodes_equal_gvp_nodes"),
           row.get("esm_mean_vector", {}).get("abs_sum", float("nan")),
           row.get("esm_mean_vector", {}).get("nonzero_elements", 0)))
    if not ok:
        problem("uid_asset_gate:%s" % uid, "per-UID asset membership failed", detail=row)
    if row["is_forward_uid"] and not ok:
        problem("forward_uid_asset_gate:%s" % uid, "an actually forwarded UID failed the gate")

# ------------------------------------------------------- 6. the three genuine native loads
ROW_ROWS = []
LIVE = {}


def native_load(task_id, reaction, uids, seqs, out_dir):
    """One genuine load_geometric_dataset call, then materialise *every* row."""
    csv_path = out_dir / ("%s.csv" % task_id)
    with open(str(csv_path), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow([geometric.UID_COL, geometric.RXN_COL, geometric.SEQ_COL, COLS["LABEL_COL"]])
        for u, s in zip(uids, seqs):
            w.writerow([u, reaction, s, 0])
    rec = {"reaction_task_id": task_id, "reaction_smiles": reaction,
           "candidate_csv": str(csv_path), "candidate_uid_order": list(uids),
           "candidate_sequence_lengths": [len(s) for s in seqs],
           "candidate_sequence_sha256": [sha_str(s) for s in seqs],
           "written_under_work_root": str(csv_path).startswith(str(C.WORK_ROOT)),
           "status": "FAIL"}
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            ds = geometric.load_geometric_dataset(
                str(csv_path), gvp_map, cfg["rxn_fp"], str(cfg["mol_conformation"]),
                node_map, cfg["esm_mean_feature"], cfg["reaction_center"])
    except Exception:
        rec["loader_stdout"] = buf.getvalue()
        rec["status"] = "LOAD_EXCEPTION"
        rec["traceback"] = traceback.format_exc()
        problem("native_load:%s" % task_id, "load_geometric_dataset raised an exception",
                traceback=rec["traceback"][-1200:])
        return rec
    LIVE[task_id] = ds
    rec["loader_stdout"] = buf.getvalue()
    rec["dataset_length"] = len(ds)
    rec["row_uids_in_order"] = [str(x) for x in ds.uniprot_ids]
    rec["esm_dim_from_pocket_node"] = int(ds.esm_dim)
    rec["esm_feat_dict_type"] = type(ds.esm_feat_dict).__name__
    rec["esm_feat_dict_entries"] = (None if ds.esm_feat_dict is None
                                    else len(ds.esm_feat_dict))
    rec["loader_reported_size_of_df_data"] = (
        "size of df_data: %d" % len(ds) in rec["loader_stdout"])
    # ``ds[i]`` is inherited from torch_geometric.data.Dataset and resolves to
    # ``self.get(self.indices()[i])``; with ``_indices is None`` that mapping is the identity, so
    # row *i* really is the *i*-th frozen UID rather than a permuted one.
    rec["row_indexing"] = {
        "getitem_owner": "torch_geometric.data.dataset.Dataset (inherited, GeometricDataset.get)",
        "pyg_indices_is_none": ds._indices is None,
        "indices_equal_range": list(ds.indices()) == list(range(len(ds))),
        "teacher_len_method_equals_python_len": int(ds.len()) == len(ds),
        "uids_after_indexing": [str(ds[i].uid) for i in range(len(ds))]}
    rec["not_found_lines_in_loader_stdout"] = rec["loader_stdout"].count(NOT_FOUND)
    rows = []
    for i in range(len(ds)):
        rbuf = io.StringIO()
        data, err = None, ""
        try:
            with redirect_stdout(rbuf):
                data = ds[i]
        except Exception:
            err = traceback.format_exc()
        out = rbuf.getvalue()
        row = {"reaction_task_id": task_id, "row_index": i,
               "expected_uid_from_frame": str(ds.uniprot_ids[i]),
               "csv_sequence_length": len(str(ds.seqs[i])),
               "csv_sequence_sha256": sha_str(str(ds.seqs[i])),
               "csv_sequence_in_esm_feat_dict": bool(ds.esm_feat_dict) and (
                   ds.seqs[i] in ds.esm_feat_dict),
               "not_found_logged_for_this_row": NOT_FOUND in out,
               "row_stdout": out.strip(), "get_exception": err[-1200:]}
        if data is not None:
            row["data_uid"] = str(data.uid)
            row["uid_row_association_correct"] = (str(data.uid) == row["expected_uid_from_frame"])
            row["data_rxn"] = str(data.rxn)
            row["reaction_matches_frozen_smiles"] = str(data.rxn) == reaction
            tensors = [tmeta("seq", data.seq), tmeta("node_xyz", data.node_xyz),
                       tmeta("reaction_feature", data.reaction_feature),
                       tmeta("esm_feature", data.esm_feature),
                       tmeta("protein.esm_node_feature", data["protein"].esm_node_feature),
                       tmeta("protein.node_s", data["protein"].node_s),
                       tmeta("protein.node_v", data["protein"].node_v),
                       tmeta("substrates.x", data["substrates"].x),
                       tmeta("substrates.positions", data["substrates"].positions),
                       tmeta("products.x", data["products"].x),
                       tmeta("products.positions", data["products"].positions)]
            row["tensors"] = {t["name"]: t for t in tensors}
            esm = row["tensors"]["esm_feature"]
            row["esm_feature_shape"] = esm["shape"]
            row["esm_feature_is_zero_fallback"] = bool(esm.get("is_all_zero"))
            row["esm_feature_equals_esm_mean_lookup"] = (
                ds.seqs[i] in esm_mean and bool(torch.equal(
                    data.esm_feature, torch.as_tensor(esm_mean[ds.seqs[i]],
                                                     dtype=torch.float))))
            row["node_counts_consistent"] = (
                row["tensors"]["node_xyz"]["shape"][0]
                == row["tensors"]["protein.esm_node_feature"]["shape"][0])
            row["gvp_node_count"] = row["tensors"]["node_xyz"]["shape"][0]
            row["pocket_node_count"] = row["tensors"]["protein.esm_node_feature"]["shape"][0]
        else:
            row["uid_row_association_correct"] = False
            row["esm_feature_is_zero_fallback"] = True
            row["node_counts_consistent"] = False
            row["esm_feature_equals_esm_mean_lookup"] = False
        rows.append(row)
        ROW_ROWS.append(dict(row))
    rec["rows"] = rows
    ok = [rec["dataset_length"] == 3, len(rows) == 3,
          rec["candidate_uid_order"] == rec["row_uids_in_order"],
          (rec["row_indexing"]["pyg_indices_is_none"]
           and rec["row_indexing"]["indices_equal_range"]
           and rec["row_indexing"]["teacher_len_method_equals_python_len"]
           and rec["row_indexing"]["uids_after_indexing"] == rec["candidate_uid_order"]),
          all(r["uid_row_association_correct"] for r in rows),
          all(r["node_counts_consistent"] for r in rows),
          all(r["reaction_matches_frozen_smiles"] for r in rows),
          rec["not_found_lines_in_loader_stdout"] + sum(
              1 for r in rows if r["not_found_logged_for_this_row"]) == 0,
          all(r["esm_feature_equals_esm_mean_lookup"] for r in rows),
          all(not r["esm_feature_is_zero_fallback"] for r in rows
              if r["expected_uid_from_frame"] in FWD_UIDS)]
    rec["checks"] = dict(zip(
        ["dataset_length_is_3", "three_rows_materialised", "uid_order_preserved",
         "row_index_to_row_identity_is_the_pyg_identity_mapping",
         "every_row_uid_associated", "every_row_pocket_equals_gvp_nodes",
         "every_row_reaction_is_the_frozen_smiles", "no_esm_feature_not_found_log",
         "every_row_esm_feature_equals_esm_mean_lookup",
         "forward_uids_have_no_zero_esm_fallback"], ok))
    rec["status"] = "PASS" if all(ok) else "FAIL"
    if not all(ok):
        problem("native_load_gate:%s" % task_id, "one or more per-row native load gates failed",
                failed=[k for k, v in zip(
                    ["dataset_length_is_3", "three_rows_materialised", "uid_order_preserved",
                     "row_index_to_row_identity_is_the_pyg_identity_mapping",
                     "every_row_uid_associated", "every_row_pocket_equals_gvp_nodes",
                     "every_row_reaction_is_the_frozen_smiles", "no_esm_feature_not_found_log",
                     "every_row_esm_feature_equals_esm_mean_lookup",
                     "forward_uids_have_no_zero_esm_fallback"], ok) if not v],
                dataset_length=rec.get("dataset_length"),
                per_row=[(r["expected_uid_from_frame"], r.get("esm_feature_is_zero_fallback"),
                          r.get("node_counts_consistent")) for r in rows])
    return rec


REAC_DIR = NATIVE / "reactions"
REAC_DIR.mkdir(parents=True, exist_ok=True)
if prior is None:
    say("== 6. three genuine load_geometric_dataset calls, every row materialised")
    results = []
    for task_id, reaction in C.REACTIONS:
        seqs = [ai.sequence_for(u) for u in UIDS]
        rec = native_load(task_id, reaction, UIDS, seqs, REAC_DIR)
        results.append({k: v for k, v in rec.items() if k != "rows"})
        for r in rec.get("rows", []):
            say("      row%d %-11s uid_ok=%s esm%s zeros=%s not_found=%s nodes=%s/%s"
                % (r["row_index"], r["expected_uid_from_frame"],
                   r["uid_row_association_correct"], r.get("esm_feature_shape"),
                   r["esm_feature_is_zero_fallback"], r["not_found_logged_for_this_row"],
                   r.get("gvp_node_count", "-"), r.get("pocket_node_count", "-")))
        say("  [%-4s] %-22s length=%s uids=%s not_found_lines=%d"
            % (rec["status"], task_id, rec.get("dataset_length"),
               ",".join(rec.get("row_uids_in_order", [])),
               rec.get("not_found_lines_in_loader_stdout", -1)))

    # ---- labelled negative control: the first round's empty-sequence branch, on the SAME
    # live dataset object, so no fourth load_geometric_dataset call is needed and no file is
    # rewritten.  It exists to attribute and explain any 'ESM feature not found' log line.
    say("== 6b. negative control against the first-round defect (in memory only)")
    first_task = C.REACTIONS[0][0]
    live_ds = LIVE.get(first_task)
    control = {"purpose": ("show that an empty sequence column makes get_esm_feat print "
                           "'%s' and return torch.zeros(esm_dim), and that the resulting "
                           "tensor has the SAME shape as a genuine one, which is why a "
                           "metadata-only record of dataset[0] could not close this gate"
                           % NOT_FOUND),
               "dataset_reloaded": False, "files_written": False,
               "uses_live_dataset_of": first_task,
               "teacher_source": "enzymecage/dataset/geometric.py:357-363"}
    if live_ds is None:
        control["status"] = "UNAVAILABLE_NO_LIVE_DATASET"
        problem("negative_control", "the live dataset object needed by the control is gone")
    else:
        saved = list(live_ds.seqs)
        b_real, b_empty = io.StringIO(), io.StringIO()
        with redirect_stdout(b_real):
            real_vec = live_ds.get_esm_feat(0)
        live_ds.seqs[0] = ""
        try:
            with redirect_stdout(b_empty):
                zero_vec = live_ds.get_esm_feat(0)
        finally:
            live_ds.seqs[0] = saved[0]
        control.update({
            "uid_under_control": str(live_ds.uniprot_ids[0]),
            "row_index_under_control": 0,
            "real_sequence_row": tmeta("esm_feature", real_vec),
            "real_stdout": b_real.getvalue(),
            "empty_sequence_row": tmeta("esm_feature", zero_vec),
            "empty_stdout": b_empty.getvalue(),
            "empty_sequence_prints_not_found": NOT_FOUND in b_empty.getvalue(),
            "real_sequence_prints_not_found": NOT_FOUND in b_real.getvalue(),
            "empty_sequence_returns_all_zero": bool((zero_vec == 0).all().item()),
            "real_sequence_returns_non_zero": float(real_vec.abs().sum()) > 0,
            "real_control_equals_the_frozen_esm_mean_entry": bool(torch.equal(
                real_vec, torch.as_tensor(esm_mean[saved[0]], dtype=torch.float))),
            "shapes_are_identical_so_metadata_alone_cannot_tell_them_apart":
                list(real_vec.shape) == list(zero_vec.shape),
            "sequence_restored_after_control": list(live_ds.seqs) == saved,
            "status": "PASS"})
        if not (control["empty_sequence_prints_not_found"]
                and control["empty_sequence_returns_all_zero"]
                and control["real_sequence_returns_non_zero"]
                and not control["real_sequence_prints_not_found"]
                and control["shapes_are_identical_so_metadata_alone_cannot_tell_them_apart"]
                and control["sequence_restored_after_control"]):
            control["status"] = "FAIL"
            problem("negative_control", "the empty-sequence fallback could not be reproduced",
                    detail=control)
        say("  control: empty -> %s all_zero=%s prints_not_found=%s | real -> abs_sum=%.4g "
            "prints_not_found=%s | seqs_restored=%s"
            % (control["empty_sequence_row"]["shape"],
               control["empty_sequence_returns_all_zero"],
               control["empty_sequence_prints_not_found"], float(real_vec.abs().sum()),
               control["real_sequence_prints_not_found"],
               control["sequence_restored_after_control"]))
    evidence_raw = {
        "utc": C.now_utc(), "invocation": invocation_count,
        "interpreter": C.interp_identity(), "torch": torch.__version__,
        "column_names": COLS, "overlay_config": cfg,
        "config_seeds_checked": [s for s, _ in configs],
        "authority_sequence_pins": AUTH_SEQ_PINS,
        "sequence_identity_per_uid": seq_table,
        "d4_whitelist": {"path": str(C.D4_WHITELIST), "rows": D4_TOTAL, "columns": D4_FIELDS,
                         "sha256_verified_in": "§6.2", "per_uid": D4_ROWS},
        "asset_index_inventory": inventory, "asset_index_seconds": ai_seconds,
        "protein_asset_load": asset_load, "uid_asset_gate": UID_GATE,
        "reactions": results, "negative_control": control,
        "per_row_tensor_evidence": ROW_ROWS,
        "cuda_initialised_before": bool(torch.cuda.is_initialized()),
    }
    EVIDENCE.write_text(json.dumps(evidence_raw, indent=1, ensure_ascii=False, default=str),
                        encoding="utf-8")
    say("  raw native-load evidence persisted once to %s" % EVIDENCE)
else:
    evidence_raw = prior
    say("== 6. adopting the native load evidence already produced by this task")

# ------------------------------------------------------- 7. gate assembly
E = evidence_raw
reactions = E["reactions"]
# Sections 1-5 are cheap and were re-derived in *this* invocation; the expensive §9 run-once
# native-load evidence may come from an earlier one.  The identity gates below therefore read the
# freshly re-derived table, not a possibly stale copy, and the overlap between the two is
# compared first so that an adoption can never smuggle in an outdated fact.
SEQ_ID, UGATE = seq_table, UID_GATE
if prior is not None:
    for uid in sorted(SEQ_ID):
        old = evidence_raw["sequence_identity_per_uid"].get(uid, {})
        for field in ("sequence_length", "sequence_sha256_utf8", "distinct_sequence_count"):
            if old.get(field) != SEQ_ID[uid][field]:
                problem("identity_drift:%s" % uid,
                        "the re-derived sequence identity disagrees with the adopted raw "
                        "evidence", field=field, adopted=old.get(field), now=SEQ_ID[uid][field])
    for now in UGATE:
        old = next((g for g in evidence_raw["uid_asset_gate"] if g["uid"] == now["uid"]), {})
        for field in ("in_gvp", "in_pocket_node", "sequence_in_esm_mean", "status",
                      "sequence_sha256_utf8", "has_enzyme_through_production_path"):
            if old.get(field) != now[field]:
                problem("asset_drift:%s" % now["uid"],
                        "the re-verified per-UID asset membership disagrees with the adopted raw "
                        "evidence", field=field, adopted=old.get(field), now=now[field])
say("  identity inputs re-derived in this invocation; the run-once native load evidence of "
    "invocation %s is %s"
    % (evidence_raw.get("invocation"), "adopted" if prior is not None else "produced here"))
pass_3_of_3 = (len(reactions) == 3
               and all(r["status"] == "PASS" for r in reactions)
               and all(g["status"] == "PASS" for g in UGATE)
               and all(SEQ_ID[u]["matches_authority_pin"]
                       for u in FWD_UIDS))
ROW_LIST = E["per_row_tensor_evidence"]
rows_by_task = {}
for r in ROW_LIST:
    rows_by_task.setdefault(r["reaction_task_id"], []).append(r)
forward_rows = [r for tid, _ in C.REACTIONS for r in rows_by_task.get(tid, [])
                if r["expected_uid_from_frame"] in FWD_UIDS]
forward_clean = (len(forward_rows) == 6
                 and all(r.get("uid_row_association_correct") is True for r in forward_rows)
                 and all(r.get("esm_feature_is_zero_fallback") is False for r in forward_rows)
                 and all(r.get("esm_feature_equals_esm_mean_lookup") is True
                         for r in forward_rows)
                 and all(not r.get("get_exception") for r in forward_rows))
cuda_still_cold = not torch.cuda.is_initialized()
if not pass_3_of_3:
    problem("gate", "the 3/3 native load or a per-UID asset gate did not pass")
if not forward_clean:
    problem("gate", "a UID that really enters forward carries a zero/missing ESM fallback")
if not cuda_still_cold:
    problem("gate", "CUDA was initialised during the pre-forward gate")

REQUIRED_CHECKS = {
    "每个reaction dataset length=3": (
        len(reactions) == 3 and all(r.get("dataset_length") == 3 for r in reactions)
        and all(len(rows_by_task.get(tid, [])) == 3 for tid, _ in C.REACTIONS)),
    "逐个dataset row关联真实UID": (
        len(ROW_LIST) == 9 and all(r["uid_row_association_correct"] is True for r in ROW_LIST)
        and all(r["row_indexing"]["uids_after_indexing"] == r["candidate_uid_order"]
                and r["row_indexing"]["indices_equal_range"] for r in reactions)),
    "逐row保存seq/reaction_feature/node_xyz/esm_feature的shape/dtype/device/finite": (
        len(ROW_LIST) == 9 and all(
            isinstance(r.get("tensors"), dict)
            and all(n in r["tensors"] for n in ("seq", "reaction_feature", "node_xyz",
                                                "esm_feature"))
            and all(all(k in r["tensors"][n] for k in ("shape", "dtype", "device", "numel"))
                    for n in r["tensors"])
            and all(r["tensors"][n].get("all_finite") is True
                    for n in ("reaction_feature", "node_xyz", "esm_feature"))
            for r in ROW_LIST)),
    "逐UID核sequence非空和冻结SHA": all(
        g["sequence_non_empty"] and g["sequence_sha256_equals_independent_derivation"]
        and SEQ_ID[g["uid"]]["matches_d4_frozen_sha"]
        and (not g["is_forward_uid"]
             or SEQ_ID[g["uid"]]["matches_authority_pin"])
        for g in UGATE),
    "UID在GVP": all(g["in_gvp"] for g in UGATE),
    "UID在pocket node": all(g["in_pocket_node"] for g in UGATE),
    "sequence在ESM mean": all(g["sequence_in_esm_mean"] for g in UGATE),
    "ESM mean绝对值和非零": all(
        g.get("esm_mean_vector", {}).get("abs_sum", 0) > 0
        and g.get("esm_mean_vector", {}).get("nonzero_elements", 0) > 0
        and g.get("esm_mean_vector", {}).get("is_all_zero") is False
        and g.get("esm_mean_vector", {}).get("all_finite") is True
        for g in UGATE),
    "解释并归属任何ESM feature not found日志": (
        len(ROW_LIST) == 9
        and all(r["not_found_logged_for_this_row"] is False for r in ROW_LIST)
        and all(r["not_found_lines_in_loader_stdout"] == 0 for r in reactions)
        and all({"reaction_task_id", "row_index", "expected_uid_from_frame",
                 "not_found_logged_for_this_row"} <= set(r) for r in ROW_LIST)
        and E["negative_control"].get("status") == "PASS"
        and E["negative_control"].get("empty_sequence_prints_not_found") is True
        and E["negative_control"].get("empty_sequence_returns_all_zero") is True
        and E["negative_control"].get("real_sequence_prints_not_found") is False),
    "实际进入forward的两个UID不得有zero_missing_fallback": forward_clean,
}
CHECK_EVIDENCE = {
    "每个reaction dataset length=3": "reactions[].dataset_length + len(rows) in "
                                     "logs/p11_native_evidence.json",
    "逐个dataset row关联真实UID": "per_row_tensor_evidence[].expected_uid_from_frame == "
                                  "data_uid (ds.uniprot_ids[i] vs data.uid)",
    "逐row保存seq/reaction_feature/node_xyz/esm_feature的shape/dtype/device/finite":
        "NATIVE_LOAD_PER_ROW_TENSORS.csv, one row per (reaction, row index, tensor)",
    "逐UID核sequence非空和冻结SHA": "sequence_identity_per_uid + "
                                    "CORRECTED_UID_AND_PROTEIN_ASSET_IDENTITIES.csv",
    "UID在GVP": "uid_asset_gate[].in_gvp against load_protein_gvp_data(cfg['protein_gvp_feat'])",
    "UID在pocket node": "uid_asset_gate[].in_pocket_node against "
                        "load_pocket_node_feature_data(cfg['esm_node_feature'])",
    "sequence在ESM mean": "uid_asset_gate[].sequence_in_esm_mean (key = the real sequence string)",
    "ESM mean绝对值和非零": "uid_asset_gate[].esm_mean_vector.abs_sum/nonzero_elements/is_all_zero",
    "解释并归属任何ESM feature not found日志": "per-row redirect_stdout capture + "
                                            "negative_control (geometric.py:357-363 zeros branch)",
    "实际进入forward的两个UID不得有zero_missing_fallback":
        "per_row esm_feature_equals_esm_mean_lookup / esm_feature_is_zero_fallback for "
        "A0A011QK89 and A0A017SP50 in all three reactions",
}

# ------------------------------------------------------- 8. deliverables and verdict
say("== 7. deliverables")
# A failed earlier attempt of this step is preserved instead of being silently overwritten.
supersedes = None
if GATE_JSON.exists():
    try:
        old = json.loads(GATE_JSON.read_text(encoding="utf-8"))
    except ValueError:
        old = {}
    if old.get("status") != "PASS":
        attempt = C.LOGS / ("p11_gate_attempt_invocation_%s.json"
                            % old.get("run_once", {}).get("invocation_of_this_step", "?"))
        attempt.write_text(json.dumps(old, indent=1, ensure_ascii=False, default=str),
                           encoding="utf-8")
        supersedes = {"previous_status": old.get("status"), "previous_utc": old.get("utc"),
                      "previous_failed_checks": old.get("failed_checks"),
                      "previous_problems": [p["label"] for p in old.get("problems", [])],
                      "preserved_at": str(attempt),
                      "why_this_invocation_did_not_reload": (
                          "the raw native load evidence of the first invocation is adopted, so "
                          "the three expensive load_geometric_dataset calls stay at exactly one "
                          "for the whole task (§9)")}
        say("  a non-PASS gate of an earlier invocation was preserved to %s" % attempt.name)
FAILED_CHECKS = sorted(k for k, v in REQUIRED_CHECKS.items() if v is not True)
status = "PASS" if not PROBLEMS and not FAILED_CHECKS else "FAIL"
native_verdict = ("PASS_3_OF_3" if status == "PASS" and pass_3_of_3
                  else "BLOCKED_AT_SEQUENCE_ESM_IDENTITY")

tensor_csv = RD / "NATIVE_LOAD_PER_ROW_TENSORS.csv"
TCOLS = ["reaction_task_id", "row_index", "expected_uid_from_frame", "data_uid",
         "uid_row_association_correct", "data_rxn", "reaction_matches_frozen_smiles",
         "csv_sequence_length", "csv_sequence_sha256", "csv_sequence_in_esm_feat_dict",
         "not_found_logged_for_this_row", "row_stdout", "get_exception", "tensor_name",
         "shape", "dtype", "device", "numel", "all_finite", "abs_sum", "nonzero_elements",
         "is_all_zero", "min", "max", "esm_feature_shape", "esm_feature_is_zero_fallback",
         "esm_feature_equals_esm_mean_lookup", "node_counts_consistent", "gvp_node_count",
         "pocket_node_count"]
with open(str(tensor_csv), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(TCOLS)
    for r in ROW_LIST:
        tensors = r.get("tensors") if isinstance(r.get("tensors"), dict) else {}
        names = sorted(tensors) or [""]
        for n in names:
            t = tensors.get(n, {})
            w.writerow([r["reaction_task_id"], r["row_index"], r["expected_uid_from_frame"],
                        r.get("data_uid", ""), r.get("uid_row_association_correct"),
                        r.get("data_rxn", ""), r.get("reaction_matches_frozen_smiles"),
                        r["csv_sequence_length"], r["csv_sequence_sha256"],
                        r["csv_sequence_in_esm_feat_dict"], r["not_found_logged_for_this_row"],
                        r.get("row_stdout", ""), r.get("get_exception", ""), n,
                        json.dumps(t.get("shape")) if t else "", t.get("dtype", ""),
                        t.get("device", ""), t.get("numel", ""), t.get("all_finite", ""),
                        t.get("abs_sum", ""), t.get("nonzero_elements", ""),
                        t.get("is_all_zero", ""), t.get("min", ""), t.get("max", ""),
                        json.dumps(r.get("esm_feature_shape"))
                        if r.get("esm_feature_shape") else "",
                        r.get("esm_feature_is_zero_fallback", ""),
                        r.get("esm_feature_equals_esm_mean_lookup", ""),
                        r.get("node_counts_consistent", ""), r.get("gvp_node_count", ""),
                        r.get("pocket_node_count", "")])
say("  %s" % tensor_csv.name)

uid_csv = RD / "CORRECTED_UID_AND_PROTEIN_ASSET_IDENTITIES.csv"
UCOLS = ["uid", "is_forward_uid", "enters_forward", "sequence_length", "sequence_sha256_utf8",
         "distinct_sequence_count", "sequence_non_empty", "sequence_charset_is_standard_aa",
         "authority_pin_length", "authority_pin_sha256", "matches_authority_pin",
         "d4_frozen_sequence_sha256", "matches_d4_frozen_sha", "frozen_sha_provenance",
         "production_index_agrees_with_direct_read", "in_gvp", "in_pocket_node",
         "sequence_in_esm_mean", "gvp_node_xyz_shape", "gvp_seq_shape", "pocket_node_shape",
         "pocket_nodes_equal_gvp_nodes", "esm_mean_shape", "esm_mean_abs_sum",
         "esm_mean_nonzero_elements", "esm_mean_is_all_zero", "has_enzyme_through_production_path",
         "d4_whitelist_present", "d4_flags_failed", "not_found_fallback_possible", "status"]
with open(str(uid_csv), "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(UCOLS)
    for g in UGATE:
        s = SEQ_ID[g["uid"]]
        pin = s.get("authority_pin") or {}
        w.writerow([g["uid"], g["is_forward_uid"], g["uid"] in FWD_UIDS, s["sequence_length"],
                    g["sequence_sha256_utf8"], s["distinct_sequence_count"],
                    s["sequence_non_empty"], s["sequence_charset_is_standard_aa"],
                    pin.get("length", ""), pin.get("sha256", ""), s["matches_authority_pin"],
                    s["d4_frozen_sequence_sha256"], s["matches_d4_frozen_sha"],
                    s["frozen_sha_provenance"], s["production_index_sequence_agrees_with_direct_read"],
                    g["in_gvp"], g["in_pocket_node"], g["sequence_in_esm_mean"],
                    json.dumps(g.get("gvp_node_xyz", {}).get("shape")),
                    json.dumps(g.get("gvp_seq_field", {}).get("shape")),
                    json.dumps(g.get("pocket_node_feature", {}).get("shape")),
                    g.get("pocket_nodes_equal_gvp_nodes"),
                    json.dumps(g.get("esm_mean_vector", {}).get("shape")),
                    g.get("esm_mean_vector", {}).get("abs_sum", ""),
                    g.get("esm_mean_vector", {}).get("nonzero_elements", ""),
                    g.get("esm_mean_vector", {}).get("is_all_zero", ""),
                    g["has_enzyme_through_production_path"], g["d4_whitelist_present"],
                    ";".join(g["d4_flags_failed"]), g["not_found_fallback_possible"],
                    g["status"]])
say("  %s" % uid_csv.name)

gate = {
    "schema": "enzymecage.t6_r3_r1.uid_sequence_gvp_pocket_esm_preforward_gate.v1",
    "step": "§6.3 native load与逐UID ESM硬门",
    "task_id": C.TASK_ID,
    "utc": C.now_utc(),
    "status": status,
    "T3B_NATIVE_LOAD": native_verdict,
    "UID_SEQUENCE_GVP_POCKET_ESM": "PASS" if status == "PASS" else "FAIL",
    "gate_position": "before any GPU runtime initialisation",
    "run_once": {"invocation_of_this_step": invocation_count,
                 "native_loads_executed_in_this_invocation": prior is None,
                 "native_loads_expected_for_the_whole_task": 3,
                 "raw_evidence_file": str(EVIDENCE),
                 "adopted_from_prior_invocation": prior is not None},
    "fixed_sample_purity": {
        "reactions": [{"task_id": t, "smiles": r} for t, r in C.REACTIONS],
        "frozen_uid_order": UIDS,
        "per_reaction_candidate_uid_order": [r["candidate_uid_order"] for r in reactions],
        "samples_substituted": False,
        "forward_uids": FWD_UIDS,
        "source_of_reactions_and_uid_order": "original contract, inherited unchanged"},
    "required_checks": REQUIRED_CHECKS,
    "failed_checks": FAILED_CHECKS,
    "check_evidence_map": CHECK_EVIDENCE,
    "cuda_state": {"initialised_before_gate": E["cuda_initialised_before"],
                   "initialised_after_gate": not cuda_still_cold,
                   "note": "torch.cuda.is_available() was never called, so no CUDA context "
                           "could be created while this gate ran"},
    "teacher_column_names": COLS,
    "identity_provenance": {
        "sequence_identity_and_asset_membership": "re-derived by this invocation (sections 1-5)",
        "row_level_native_load": "adopted from the single run-once execution of "
                                 "load_geometric_dataset (logs/p11_native_evidence.json, "
                                 "invocation %s)" % E.get("invocation"),
        "authority_pin_parsing": "the pin pattern is applied to the authority text in every "
                                 "invocation, so a stale non-match cannot survive a re-run",
        "invocation_history": [json.loads(x) for x in open(str(INVOCATIONS), encoding="utf-8")]},
    "overlay_config_fields": {k: cfg.get(k) for k in C.OVERLAY_CONFIG_FIELDS},
    "authority_sequence_pins": AUTH_SEQ_PINS,
    "sequence_identity_per_uid": SEQ_ID,
    "uid_asset_gate": UGATE,
    "native_loads": reactions,
    "negative_control": E["negative_control"],
    "row_counts": {"total_rows": len(ROW_LIST), "forward_rows": len(forward_rows),
                   "per_reaction": {tid: len(v) for tid, v in rows_by_task.items()}},
    "first_round_deficiency_closed": {
        "only_dataset_0_inspected": "now every row of every reaction dataset is materialised",
        "empty_sequence_column": "the candidate CSV carries the frozen real sequences",
        "metadata_only_record": "abs_sum/nonzero/is_all_zero plus equality against the ESM mean "
                                "entry; the negative control shows the zero fallback has the "
                                "same shape as a genuine vector",
        "unattributed_log_line": "stdout is captured per row, so a '%s' line would name its "
                                 "reaction, row index and UID" % NOT_FOUND},
    "problems": PROBLEMS,
    "problem_count": len(PROBLEMS),
    "supersedes": supersedes,
    "evidence_files": [GATE_JSON.name, tensor_csv.name, uid_csv.name,
                       RD / "PREFORWARD_GATE_STDOUT.txt", str(EVIDENCE), str(INVOCATIONS)],
}
GATE_JSON.write_text(json.dumps(gate, indent=1, ensure_ascii=False, default=str),
                     encoding="utf-8")
say("  %s" % GATE_JSON.name)
(RD / "PREFORWARD_GATE_STDOUT.txt").write_text("\n".join(SAY) + "\n", encoding="utf-8")

say("== 8. per-check result")
for k, v in REQUIRED_CHECKS.items():
    say("  %-8s %s" % ("OK" if v is True else "FAIL", k))
for g in UGATE:
    s = SEQ_ID[g["uid"]]
    say("  [%-4s] %-11s fwd=%-5s len=%-4s sha=%s… gvp=%s pocket=%s esm_mean=%s "
        "abs_sum=%.4g frozen_sha=%s"
        % (g["status"], g["uid"], g["uid"] in FWD_UIDS, s["sequence_length"],
           g["sequence_sha256_utf8"][:12], g["in_gvp"], g["in_pocket_node"],
           g["sequence_in_esm_mean"], g.get("esm_mean_vector", {}).get("abs_sum", float("nan")),
           "authority" if s["matches_authority_pin"] else
           ("d4" if s["matches_d4_frozen_sha"] else "NONE")))
for r in reactions:
    failed = [k for k, v in sorted(r.get("checks", {}).items()) if v is not True]
    say("  [%-4s] %-22s length=%s not_found_lines=%s checks_failed=%s"
        % (r["status"], r["reaction_task_id"], r.get("dataset_length"),
           r.get("not_found_lines_in_loader_stdout"), json.dumps(failed, ensure_ascii=False)))
if PROBLEMS:
    say("  problems: %d" % len(PROBLEMS))
    for p in PROBLEMS:
        say("    - %s :: %s" % (p["label"], p["problem"]))
say("  cuda_initialised_after_gate=%s (gate runs before any GPU runtime)"
    % (not cuda_still_cold))
say("== verdict: UID_SEQUENCE_GVP_POCKET_ESM=%s | T3B_NATIVE_LOAD=%s "
    "(%d problems, %d failed checks)" % (gate["UID_SEQUENCE_GVP_POCKET_ESM"], native_verdict,
                                         len(PROBLEMS), len(FAILED_CHECKS)))
if native_verdict != "PASS_3_OF_3":
    say("  the three expensive GPU workers of §7 must NOT be started")

exit_code = 0 if status == "PASS" else 3
C.self_audit(__file__, exit_code, "§6.3 native load + per-UID sequence/GVP/pocket/ESM gate")
sys.exit(exit_code)
