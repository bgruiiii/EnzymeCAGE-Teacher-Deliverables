# Sourced before every step driver of T6-R3-R1 so that a manually launched ${PY} command runs
# under exactly the environment r1_common.base_env() gives to child processes (§4.1).
W=/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910
export PY=/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python
export PYTHONDONTWRITEBYTECODE=1
export TMPDIR="$W/tmp"
export XDG_CACHE_HOME="$W/cache"
export MPLCONFIGDIR="$W/cache/mpl"
export NUMBA_CACHE_DIR="$W/cache/numba"
export TORCH_HOME="$W/cache/torch"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export LC_ALL=C
export TZ=UTC
unset PYTHONPATH PYTHONHOME
