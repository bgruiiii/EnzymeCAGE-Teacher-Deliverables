# -*- coding: utf-8 -*-
"""§6.2 fixed asset identity: every frozen input is located *by pinned SHA256*.

§6.2 forbids resolving an input by "latest", by mtime or by a similar name, so this step does
the opposite of a name lookup: it hashes every regular file in the two declared input roots,
and only a byte-exact hit on one of the pinned digests is allowed to name a path.  Each hit is
then audited as an archive (regular, non-symlink, member safety, single root, internal
manifest recomputed from the member bytes) and the five seed40-44 checkpoints are recovered
from the V1 tar as *members*, which is the only way to disambiguate them from the six-hundred
million parameter ensemble that carries the same `seed_4X/best_model.pth` file names.

The task-local overlays the forward needs are built here (and only here): the T3B reaction
overlay is extracted twice independently and its generated mol_graph_dict.pt is compared at
content level, and the V1 overlay keeps the five checkpoints byte-identical while re-pointing
exactly the three config fields the contract allows.

Outputs (C.RETURN_DIR):
  FIXED_ASSET_IDENTITY_GATE.json
  INPUT_IDENTITIES.csv
  ASSET_SHA_DISCOVERY_SCAN.csv
  ARCHIVE_MANIFEST_AUDIT.csv
  V1_OVERLAY_MANIFEST.csv / V1_OVERLAY_CONFIG_DIFF.json
  REACTION_OVERLAY_MANIFEST.csv / REACTION_OVERLAY_REBUILD_DETERMINISM.json
"""
import csv
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tarfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import r1_common as C  # noqa: E402

C.emit_interp()
RD = C.RETURN_DIR
RD.mkdir(parents=True, exist_ok=True)
PROG = C.LOGS / "p10_asset_progress.json"
say_lines = []


def say(msg):
    print(msg, flush=True)
    say_lines.append(msg)


def sha_stream(path, chunk=1 << 24):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        for block in iter(lambda: fh.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


# ----------------------------------------------------------------- resumable markers
# §9 forbids repeated expensive compute, so a hash that this task already produced from the
# very same bytes (identical size, mtime_ns and inode) is adopted instead of re-read.
def load_markers():
    if PROG.exists():
        try:
            return json.loads(PROG.read_text(encoding="utf-8"))
        except ValueError:
            return {}
    return {}


MARKERS = load_markers()


def marker_key(tag, path):
    return "%s::%s" % (tag, path)


def fingerprint(path):
    st = os.stat(str(path))
    return {"bytes": st.st_size, "mtime_ns": st.st_mtime_ns, "inode": st.st_ino,
            "dev": st.st_dev}


def remember(tag, path, payload):
    rec = fingerprint(path)
    rec.update({"sha_or_payload": payload, "utc": C.now_utc()})
    MARKERS[marker_key(tag, str(path))] = rec
    PROG.parent.mkdir(parents=True, exist_ok=True)
    PROG.write_text(json.dumps(MARKERS, indent=1, sort_keys=True), encoding="utf-8")


def adopt(tag, path):
    key = marker_key(tag, str(path))
    rec = MARKERS.get(key)
    if not rec:
        return None
    try:
        cur = fingerprint(path)
    except OSError:
        return None
    if all(cur[k] == rec[k] for k in ("bytes", "mtime_ns", "inode", "dev")):
        return rec["sha_or_payload"]
    return None


def hash_once(tag, path):
    got = adopt(tag, path)
    if got is not None:
        return got, True
    t0 = time.monotonic()
    got = sha_stream(path)
    remember(tag, path, {"sha256": got, "seconds": round(time.monotonic() - t0, 2)})
    return got, False


# ----------------------------------------------------------------- pinned registry
REGISTRY = {}
Problems = []


def reg(sha, kind, label, note=""):
    REGISTRY.setdefault(sha, []).append({"kind": kind, "label": label, "note": note})


for _lab, _sha in sorted(C.ARCHIVES_SHA.items()):
    reg(_sha, "module_archive", _lab, "T6-R3 first-round prompt §4 / current §6.2")
reg(C.D4_WRAPPER_TAR_SHA, "archive", "D4_WRAPPER_TAR", "current §6.2")
reg(C.V1_ARCHIVE_SHA, "archive", "V1_ARCHIVE", "current §6.2")
reg(C.AUTH_SHA, "archive", "AUTHORITY_PAYLOAD", "current §1")
reg(C.FAILED_R3_SHA, "archive", "FAILED_R3_PACKAGE", "current §5.1")

# the §5.1 frozen reuse trio and the two reviewed dependency members: located in place here,
# because they live inside a package directory rather than at the top level of a scan root
IN_PLACE = [
    ("frozen_patch", "SOURCE_PATCH.diff",
     C.INPUT_ROOT / "failed_r3" / C.FAILED_R3_TASK / "SOURCE_PATCH.diff",
     C.SOURCE_PATCH_SHA, C.SOURCE_PATCH_BYTES),
    ("frozen_patch", "T6_INCREMENTAL_PATCH.diff",
     C.INPUT_ROOT / "failed_r3" / C.FAILED_R3_TASK / "T6_INCREMENTAL_PATCH.diff",
     C.T6_INCREMENTAL_SHA, C.T6_INCREMENTAL_BYTES),
    ("frozen_script", "run_gpu_worker.py", C.INPUT_ROOT / "fr_scripts/run_gpu_worker.py",
     C.RUN_GPU_WORKER_SHA, C.RUN_GPU_WORKER_BYTES),
    ("reviewed_input", "uid_to_source_keep_bacteria_fungi_archaea.csv",
     (C.RETURN_ROOT / "enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_"
      "rerun1_20260820/_input_payload/enzymecage_m4b_c8_1_dependency_payload_20260820/inputs/"
      "uid_to_source/uid_to_source_keep_bacteria_fungi_archaea.csv"),
     C.UID_MAP_SHA, 104025134),
    ("reviewed_input", "C8_METATRAITS_LOOKUP_INDEX.jsonl",
     (C.RETURN_ROOT / "enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_"
                           "rerun2_repack_fix_20260820/C8_METATRAITS_LOOKUP_INDEX.jsonl"),
     C.C8_LOOKUP_SHA, 57211793),
    ("code_asset", "uid_asset_availability.csv.gz (D4 whitelist)", C.D4_WHITELIST, None, None),
]
# a second, transient copy of the reviewed C8 index sits in this host's working cache; both are
# recorded because agreement between them is evidence, while the persistent copy alone is used
# as the runtime input
MIRRORS = {
    "C8_METATRAITS_LOOKUP_INDEX.jsonl": Path(
        "/tmp/t5b_test_cache/enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_"
        "rerun2_repack_fix_20260820/C8_METATRAITS_LOOKUP_INDEX.jsonl"),
}
for _i, (_k, _n, _p, _s, _b) in enumerate(IN_PLACE):
    if _s:
        REGISTRY.setdefault(_s, []).append(
            {"kind": _k, "label": _n, "note": "verified in place (§5.1/§6.1 lineage)"})

ROWS = []          # INPUT_IDENTITIES.csv rows
SCAN_ROWS = []     # ASSET_SHA_DISCOVERY_SCAN.csv rows
MANIFEST_ROWS = []  # ARCHIVE_MANIFEST_AUDIT.csv rows


def row(**kw):
    ROWS.append(kw)
    return kw


# ----------------------------------------------------------------- 1. discovery scan
say("== 1. discovery: hashing every regular file of the declared input roots")
SCAN_SPEC = [(C.RETURN_ROOT, 0), (C.ROOT / "HPC_Inputs", 99)]


def walk_files(root, maxdepth):
    root = str(root)
    base = root.rstrip("/").count("/")
    out = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        if dirpath.rstrip("/").count("/") - base >= maxdepth:
            dirnames[:] = []
        for fn in filenames:
            p = Path(dirpath) / fn
            out.append(p)
    return sorted(out)


candidates = []
for _root, _depth in SCAN_SPEC:
    _f = walk_files(_root, _depth)
    say("  root=%s maxdepth=%s regular_files=%d" % (_root, _depth, len(_f)))
    candidates += _f
hits = {}
t0 = time.monotonic()
for i, p in enumerate(candidates, 1):
    try:
        link = p.is_symlink()
        st = os.stat(str(p))
        digest = sha_stream(p) if not link else ""
    except OSError as exc:
        SCAN_ROWS.append({"path": str(p), "bytes": "", "sha256": "",
                          "symlink": link, "status": "STAT_ERROR:%s" % exc, "labels": ""})
        continue
    named = digest in REGISTRY
    SCAN_ROWS.append({"path": str(p), "bytes": st.st_size, "sha256": digest,
                      "symlink": link, "status": "PINNED_HIT" if named else "not_pinned",
                      "labels": ",".join(sorted({h["label"] for h in REGISTRY.get(digest, [])}))})
    if named:
        hits.setdefault(digest, []).append(str(p))
    if i % 100 == 0:
        say("  ... %d/%d files hashed (%.0fs)" % (i, len(candidates), time.monotonic() - t0))
scan_s = round(time.monotonic() - t0, 2)
say("  scanned %d files in %.2fs; pinned digests hit: %d/%d"
    % (len(candidates), scan_s, len(hits), len(REGISTRY)))

LOCATED = {}
for digest, entries in sorted(REGISTRY.items()):
    found = hits.get(digest, [])
    for ent in entries:
        if ent["kind"] in ("module_archive", "archive"):
            if len(found) != 1:
                Problems.append({"label": ent["label"], "problem": "sha_hit_count=%d" % len(found),
                                 "hits": found})
            LOCATED[ent["label"]] = found[0] if len(found) == 1 else ""
            row(**{"kind": ent["kind"], "label": ent["label"],
                   "expected_sha256": digest,
                   "path": LOCATED[ent["label"]],
                   "bytes": os.stat(found[0]).st_size if len(found) == 1 else "",
                   "observed_sha256": digest if len(found) == 1 else "",
                   "sha_hit_count": len(found),
                   "located_by": "sha256 discovery scan over %s"
                                 % ", ".join(str(r[0]) for r in SCAN_SPEC),
                   "pinned_in": ent["note"],
                   "status": "PASS" if len(found) == 1 else "NOT_UNAMBIGUOUSLY_LOCATED"})
            say("  [%-6s] %-18s -> %s" % ("PASS" if len(found) == 1 else "FAIL",
                                          ent["label"], LOCATED[ent["label"]] or "(no hit)"))

# prove that near-miss names were rejected rather than trusted
tokens = {"T2D": "t2d", "T3A": "t3a", "T3B": "t3b", "T3B_R1": "t3b_r1", "T5A_R2": "t5a_r2",
          "T5B_R2": "t5b_r2", "T5C_R2": "t5c_r2", "V1_ARCHIVE": "enzymecage_v1",
          "D4_WRAPPER_TAR": "d4b1a_wrapper"}
rejected_lookalikes = {}
for lab, tok in tokens.items():
    near = [r["path"] for r in SCAN_ROWS
            if tok in Path(r["path"]).name.lower().replace("_", "")
            or tok.replace("_", "") in Path(r["path"]).name.lower()]
    near = [p for p in near if LOCATED.get(lab) != p]
    rejected_lookalikes[lab] = sorted(set(near))[:12]
say("  look-alike files deliberately rejected (name only, no pinned digest): %d entries"
    % sum(len(v) for v in rejected_lookalikes.values()))


# ----------------------------------------------------------------- 2. archive audits
def parse_manifest_line(line):
    """Return (sha256, relative_path) for a `sha256sum`-style line, else None.

    Every manifest observed in these packages is `<64 hex><2 spaces><path>`, but the
    binary-mode marker (`<64 hex> *<path>`) and single-space variants are accepted too.
    This is parsed with an explicit split rather than one opaque regex so that a format
    change shows up as unparsed lines instead of a silently empty expectation map.
    """
    parts = line.split(None, 1)
    if len(parts) != 2 or not re.fullmatch(r"[0-9a-f]{64}", parts[0]):
        return None
    rel = parts[1].strip()
    if rel.startswith("*"):
        rel = rel[1:].strip()
    rel = rel[2:] if rel.startswith("./") else rel
    return (parts[0], rel) if rel else None


def audit_archive(label, path):
    """One streaming pass: member safety + every regular member's SHA + internal manifest."""
    members, member_sha, manifest_text, manifest_name = [], {}, "", ""
    member_sizes = {}
    unsafe = []
    roots = set()
    with tarfile.open(str(path), "r:*") as tf:
        for m in tf:
            parts = Path(m.name).parts
            kind = ("dir" if m.isdir() else "file" if m.isfile()
                    else "link" if (m.issym() or m.islnk()) else "special")
            members.append({"name": m.name, "kind": kind, "size": m.size,
                            "mode": oct(m.mode & 0o7777)})
            roots.add(parts[0] if parts else m.name)
            if m.name.startswith("/") or ".." in parts:
                unsafe.append({"name": m.name, "reason": "unsafe path"})
            elif kind == "link":
                unsafe.append({"name": m.name, "reason": "symlink/hardlink member"})
            elif kind == "special":
                unsafe.append({"name": m.name, "reason": "device/fifo member"})
            if kind != "file":
                continue
            h = hashlib.sha256()
            keep = bytearray() if Path(m.name).name in ("MANIFEST.sha256",
                                                        "MANIFEST.txt") else None
            src = tf.extractfile(m)
            for block in iter(lambda: src.read(1 << 24), b""):
                h.update(block)
                if keep is not None:
                    keep.extend(block)
            member_sha[m.name] = h.hexdigest()
            member_sizes[m.name] = m.size
            # the manifest must be captured during the same streaming read: a tar read
            # sequentially cannot be re-opened once its bytes have been consumed
            if keep is not None and (not manifest_name
                                     or Path(m.name).name == "MANIFEST.sha256"):
                manifest_name = m.name
                manifest_text = bytes(keep).decode("utf-8", "replace")
    expected, unparsed = {}, []
    for line in manifest_text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        got = parse_manifest_line(line)
        if got is None:
            unparsed.append(line[:120])
        else:
            expected[got[1]] = got[0]
    self_rel = manifest_name
    chk = {k: v for k, v in expected.items()
           if (self_rel + "/" + k) != self_rel and k != Path(self_rel).name}
    matched, mismatched = 0, []
    prefix = self_rel.rsplit("/", 1)[0] + "/" if "/" in self_rel else ""
    # a manifest lists members relative to the package root; anything it names that the tar
    # does not carry is reported as a mismatch with an empty observed digest
    uncovered = sorted(set(chk) - {n[len(prefix):] for n in member_sha
                                   if n.startswith(prefix)})
    for rel in uncovered:
        mismatched.append({"relative": rel, "member": "", "expected": chk[rel],
                           "observed": "MEMBER_NOT_IN_TAR"})
    for rel, want in sorted(chk.items()):
        full = prefix + rel
        got = member_sha.get(full, "")
        if got == want:
            matched += 1
        else:
            mismatched.append({"relative": rel, "member": full, "expected": want, "observed": got})
    rec = {"label": label, "tar": str(path), "members": len(members),
           "link_members": sum(1 for x in members if x["kind"] == "link"),
           "special_members": sum(1 for x in members if x["kind"] == "special"),
           "regular_members": len(member_sha), "unsafe_members": unsafe,
           "top_level_roots": sorted(roots), "single_root": len(roots) == 1,
           "manifest_member": self_rel, "manifest_lines": len(expected),
           "manifest_unparsed_lines": unparsed,
           "manifest_checked": len(chk), "manifest_matched": matched,
           "manifest_mismatched": mismatched,
           "member_sha": member_sha, "member_sizes": member_sizes}
    # an unreadable manifest must never degrade into `checked=0 -> PASS`
    rec["manifest_present"] = bool(manifest_name)
    rec["manifest_parseable"] = bool(expected)
    # §6.2 asks for `manifest通过` on the shipped packages.  The authority payload is not a
    # shipped package but a seven-member attestation whose members were each compared byte
    # for byte in §1, so the absence of an internal manifest is recorded as an explicit,
    # named exemption rather than as a silent pass.
    exempt = MANIFEST_EXEMPTIONS.get(label, "")
    rec["manifest_exemption"] = exempt
    manifest_ok = (bool(expected) and matched == len(chk) and bool(manifest_name)) or bool(exempt)
    rec["status"] = ("PASS" if not unsafe and len(roots) == 1 and not mismatched
                     and manifest_ok else "FAIL")
    MANIFEST_ROWS.append({k: v for k, v in rec.items()
                          if k not in ("member_sha", "member_sizes")})
    return rec


say("== 2. archive safety + internal manifest recomputation")
MANIFEST_EXEMPTIONS = {
    "AUTHORITY_PAYLOAD": ("no internal MANIFEST; §1 already compared all seven members "
                          "byte for byte against the R3/R1 attestations"),
}
ARCHIVE_RESULT = {}
ORDER = ["T2D", "T3A", "T3B", "T3B_R1", "T5A_R2", "T5B_R2", "T5C_R2", "D4_WRAPPER_TAR",
         "V1_ARCHIVE", "AUTHORITY_PAYLOAD", "FAILED_R3_PACKAGE"]
for lab in ORDER:
    p = LOCATED.get(lab)
    if not p:
        Problems.append({"label": lab, "problem": "not located"})
        continue
    st = os.stat(p)
    r = audit_archive(lab, p)
    ARCHIVE_RESULT[lab] = r
    if r["status"] != "PASS":
        Problems.append({"label": lab, "problem": "archive audit failed",
                         "detail": {k: r[k] for k in ("unsafe_members", "single_root",
                                                      "top_level_roots",
                                                      "manifest_mismatched", "manifest_lines",
                                                      "manifest_matched", "manifest_exemption")}})
    say("  [%-4s] %-18s members=%3d regular=%3d manifest=%d/%d roots=%s symlinks=%d bytes=%d"
        % ("PASS" if r["status"] == "PASS" else "FAIL", lab, r["members"], r["regular_members"],
           r["manifest_matched"], r["manifest_checked"], r["single_root"],
           r["link_members"], st.st_size))
    row(**{"kind": "archive_audit", "label": lab, "expected_sha256": "",
           "path": p, "bytes": st.st_size,
           "observed_sha256": "", "sha_hit_count": "",
           "located_by": "member-level manifest recomputation",
           "pinned_in": "inside-archive MANIFEST", "status": r["status"]})

# the D4 wrapper directory that §4.2 puts on sys.path
say("== 2b. the frozen D4 wrapper directory used as the sys.path entry")
wrap_rows = []
for name, (nb, ns) in sorted(C.WRAPPER_FILES.items()):
    f = C.D4_WRAPPER_DIR / name
    ok = f.is_file() and not f.is_symlink() and f.stat().st_size == nb
    got = sha_stream(f) if ok else ""
    ok = ok and got == ns
    wrap_rows.append({"file": str(f), "bytes": f.stat().st_size if f.exists() else "",
                      "sha256": got, "expected_sha256": ns, "status": "PASS" if ok else "FAIL"})
    if not ok:
        Problems.append({"label": "d4_wrapper_%s" % name, "problem": "identity mismatch",
                         "observed": got})
    say("  [%-4s] %s" % ("PASS" if ok else "FAIL", name))


# ----------------------------------------------------------------- 3. V1 checkpoints
say("== 3. five seed40-44 checkpoints, recovered as V1 tar members")
v1_path = LOCATED.get("V1_ARCHIVE")
V1 = {"checkpoint_members_seen": [], "per_seed": [], "overlay": {}, "config_diff": []}
MODEL_FIELDS = ("model", "esm_model", "use_esm", "use_structure", "use_drfp",
                "use_prods_info", "interaction_method", "rxn_inner_interaction",
                "pocket_inner_interaction")
if not v1_path:
    Problems.append({"label": "V1_ARCHIVE", "problem": "not located, checkpoints unavailable"})
else:
    v1_rec = ARCHIVE_RESULT["V1_ARCHIVE"]
    # every member whose file name is seed_4X/best_model.pth, so that the 600m ensemble
    # candidates are visible as *rejected* look-alikes instead of silently skipped
    for name, sha in sorted(v1_rec["member_sha"].items()):
        m = re.search(r"seed_(4[0-4])/best_model\.pth$", name)
        if not m:
            continue
        _s = int(m.group(1))
        _pinned = name == (C.V1_CKPT_MEMBER % _s)
        V1["checkpoint_members_seen"].append(
            {"member": name, "seed": _s, "sha256": sha,
             "is_pinned_3b_member": _pinned,
             "bytes": v1_rec["member_sizes"].get(name, -1)})
        if not _pinned:
            say("  rejected name-alike member (other ensemble, other digest): %s" % name)
    baseline = None
    for seed in C.SEEDS:
        ck = C.V1_CKPT_MEMBER % seed
        cf = C.V1_CONFIG_MEMBER % seed
        want = C.CHECKPOINT_SHA[seed]
        got = v1_rec["member_sha"].get(ck, "")
        entry = {"seed": seed, "checkpoint_member": ck, "expected_sha256": want,
                 "observed_member_sha256": got,
                 "observed_member_bytes": v1_rec["member_sizes"].get(ck, -1),
                 "expected_bytes": C.CHECKPOINT_BYTES,
                 "bytes_and_sha_match": (got == want
                                         and v1_rec["member_sizes"].get(ck, -1)
                                         == C.CHECKPOINT_BYTES)}
        same_name_alternatives = [x for x in V1["checkpoint_members_seen"]
                                  if x["seed"] == seed and x["member"] != ck]
        entry["rejected_same_name_members"] = same_name_alternatives
        if got != want:
            Problems.append({"label": "checkpoint_seed%d" % seed,
                             "problem": "V1 member sha %s != pinned %s" % (got, want)})
        if entry["observed_member_bytes"] != C.CHECKPOINT_BYTES:
            Problems.append({"label": "checkpoint_seed%d_bytes" % seed,
                             "problem": "V1 member is %d bytes, §6.2 demands %d"
                                        % (entry["observed_member_bytes"], C.CHECKPOINT_BYTES)})
        V1["per_seed"].append(entry)
        say("  seed%d member=%s bytes=%d %s (name-alike members rejected: %d)"
            % (seed, "MATCH" if entry["bytes_and_sha_match"] else "MISMATCH",
               entry["observed_member_bytes"], ck, len(same_name_alternatives)))

    # materialise the overlay exactly once, streaming the members straight out of the tar
    adopted = adopt("v1_overlay_build", v1_path)
    if adopted:
        V1["overlay"], V1["config_diff"] = adopted["overlay"], adopted["config_diff"]
        V1["build_adopted_from_earlier_invocation"] = True
        say("  overlay build adopted from this task's earlier invocation (no re-read of 1.2GB)")
    else:
        V1["build_adopted_from_earlier_invocation"] = False
        if C.V1_OVERLAY.exists():
            shutil.rmtree(str(C.V1_OVERLAY))
        C.V1_OVERLAY.mkdir(parents=True)
        import yaml
        with tarfile.open(v1_path, "r:*") as tf:
            for member in tf:
                if not member.isfile() or member.name not in (
                        [C.V1_CKPT_MEMBER % s for s in C.SEEDS]
                        + [C.V1_CONFIG_MEMBER % s for s in C.SEEDS]):
                    continue
                data = tf.extractfile(member).read()
                out = C.V1_OVERLAY / Path(member.name).relative_to("enzymecage_v1_20260714")
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(data)
                os.chmod(str(out), 0o644)
                if member.name.endswith("config.yaml"):
                    seed = int(re.search(r"seed_(\d+)", member.name).group(1))
                    original = yaml.safe_load(data.decode("utf-8"))
                    changed = {}
                    for k in C.OVERLAY_CONFIG_FIELDS:
                        changed[k] = {"before": original.get(k)}
                    cfg = dict(original)
                    cfg["rxn_fp"] = str(C.REACTION_OVERLAY / "drfp/rxn2fp.pkl")
                    cfg["mol_conformation"] = str(C.REACTION_OVERLAY / "molecule_conformation")
                    cfg["reaction_center"] = str(
                        C.REACTION_OVERLAY / "reacting_center/reacting_center.pkl")
                    for k in C.OVERLAY_CONFIG_FIELDS:
                        changed[k]["after"] = cfg[k]
                    untouched_before = {k: v for k, v in original.items()
                                        if k not in C.OVERLAY_CONFIG_FIELDS}
                    untouched_after = {k: v for k, v in cfg.items()
                                       if k not in C.OVERLAY_CONFIG_FIELDS}
                    only_allowed = (set(original) == set(cfg)
                                    and all(original.get(k) != cfg[k]
                                            for k in C.OVERLAY_CONFIG_FIELDS))
                    fields = {k: cfg.get(k) for k in MODEL_FIELDS}
                    if baseline is None:
                        baseline = fields
                    identical = fields == baseline
                    V1["config_diff"].append({
                        "seed": seed, "changed_fields": changed,
                        "all_other_fields_identical": untouched_before == untouched_after,
                        "only_allowed_fields_changed": only_allowed,
                        "model_fields": fields, "model_fields_identical_across_seeds": identical})
                    if not identical:
                        Problems.append({"label": "v1_overlay_seed%d" % seed,
                                         "problem": "MODEL_FIELDS differ from seed baseline"})
                    if not (only_allowed and untouched_before == untouched_after):
                        Problems.append({"label": "v1_overlay_seed%d_config" % seed,
                                         "problem": "config edit touched a non-allowed field"})
                    out.write_text(yaml.safe_dump(cfg, sort_keys=True), encoding="utf-8")
        # verify what was written, then remember it so a re-run cannot burn 1.2GB again
        man = []
        for seed in C.SEEDS:
            ck = C.V1_OVERLAY / ("3b_ensemble/seed_%d/best_model.pth" % seed)
            cf = C.V1_OVERLAY / ("3b_ensemble/seed_%d/config.yaml" % seed)
            for f in (ck, cf):
                man.append({"relpath": str(f.relative_to(C.V1_OVERLAY)),
                            "bytes": f.stat().st_size, "sha256": sha_stream(f)})
        ck_by_seed = {int(re.search(r"seed_(\d+)", r["relpath"]).group(1)): r["sha256"]
                      for r in man if r["relpath"].endswith("best_model.pth")}
        if any(ck_by_seed.get(s) != C.CHECKPOINT_SHA[s] for s in C.SEEDS):
            Problems.append({"label": "v1_overlay_checkpoints",
                             "problem": "written overlay checkpoint != pinned digest"})
        V1["overlay"] = man
        remember("v1_overlay_build", v1_path, {"overlay": man, "config_diff": V1["config_diff"]})
    V1["overlay_manifest"] = V1["overlay"]
    say("  overlay files=%d all five checkpoints pinned=%s"
        % (len(V1["overlay"]), all(
            r["sha256"] == C.CHECKPOINT_SHA[int(re.search(r"seed_(\d+)", r["relpath"]).group(1))]
            for r in V1["overlay"] if r["relpath"].endswith("best_model.pth"))))
    V1["model_fields_identical"] = all(d["model_fields_identical_across_seeds"]
                                       for d in V1["config_diff"])


# ----------------------------------------------------------------- 4. T3B reaction overlay
say("== 4. T3B staged reaction assets -> task-local overlay, built twice independently")


def build_reaction_overlay(dest, tag):
    """Safe-extract the SHA-verified T3B archive and keep only its verified staged_assets."""
    pkg = ARCHIVE_RESULT["T3B"]["top_level_roots"][0]      # taken from the audited tar, not typed
    stage = C.TMPS / tag
    if stage.exists():
        shutil.rmtree(str(stage))
    info = C.safe_extract(LOCATED["T3B"], stage)
    src = stage / pkg / "staged_assets"
    if not src.is_dir():
        found = [p for p in stage.rglob("staged_assets") if p.is_dir()]
        if not found:
            Problems.append({"label": "T3B_staged_assets", "problem": "no staged_assets member",
                             "extract": info})
            return []
        src = found[0]
    v1 = ARCHIVE_RESULT["T3B"]["member_sha"]
    if dest.exists():
        shutil.rmtree(str(dest))
    dest.mkdir(parents=True)
    checked = []
    for f in sorted(src.rglob("*")):
        if not f.is_file():
            continue
        rel = f.relative_to(src)
        member = f.relative_to(stage).as_posix()          # <pkg>/staged_assets/<rel>
        want = v1.get(member, "")
        if not want:
            alt = [k for k in v1 if k.endswith("/" + rel.as_posix())]
            member = alt[0] if alt else member
            want = v1.get(member, "")
        got = sha_stream(f)
        checked.append({"relative": rel.as_posix(), "member": member, "bytes": f.stat().st_size,
                        "manifest_sha256": want, "observed_sha256": got,
                        "identical_to_manifest": bool(want) and want == got})
        if want != got:
            Problems.append({"label": "staged_asset:%s" % rel.as_posix(),
                             "problem": "extracted bytes differ from the archive manifest"})
        out = dest / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(str(f), str(out))
    shutil.rmtree(str(stage))
    return checked


def mol_graph_report(mol_conf):
    """Re-derive every molecule graph from the frozen SDFs through the teacher loader."""
    import torch
    from rdkit import Chem
    import pandas as pd
    sys.path.insert(0, C.CODE_ROOT)
    from enzymecage.dataset.geometric import GeometricDataset  # frozen teacher source

    rows = list(csv.DictReader(open(str(mol_conf / "mol2id.csv"), encoding="utf-8")))
    ds = GeometricDataset.__new__(GeometricDataset)
    ds.mol_to_index = dict(zip([r["SMILES"] for r in rows], [int(r["ID"]) for r in rows]))
    cache = mol_conf / "mol_graph_dict.pt"
    if cache.exists():
        cache.unlink()
    ds.load_mol_feat(str(mol_conf), use_cache=False)
    if not cache.exists():
        Problems.append({"label": "mol_graph_dict", "problem": "loader wrote no cache file",
                         "dir": str(mol_conf)})
        return {}
    graphs = torch.load(str(cache), map_location="cpu", weights_only=False)
    per = []
    for r in rows:
        smi = r["SMILES"]
        # the frozen loader reads the SDF with RDKit defaults; record both readings so an atom
        # count can never be explained away by an implicit-hydrogen difference
        mol_default = Chem.SDMolSupplier(str(mol_conf / ("%s.sdf" % r["ID"])),
                                         removeHs=True)[0]
        mol_kept = Chem.SDMolSupplier(str(mol_conf / ("%s.sdf" % r["ID"])),
                                      removeHs=False)[0]
        g = graphs[smi]
        pos = getattr(g, "positions", None)
        rec = {"smiles": smi, "sdf_id": int(r["ID"]),
               "canonical_smiles": Chem.MolToSmiles(Chem.MolFromSmiles(smi)),
               "canonical_equals_frozen_raw": Chem.MolToSmiles(Chem.MolFromSmiles(smi)) == smi,
               "graph_atoms": int(g.x.shape[0]),
               "sdf_atoms_loader_default": mol_default.GetNumAtoms(),
               "sdf_atoms_keep_hs": mol_kept.GetNumAtoms(),
               "graph_edges": int(g.edge_index.shape[1]),
               "radius_edge_index_shape": list(getattr(g, "radius_edge_index").shape),
               "positions_shape": list(pos.shape),
               "positions_all_finite": bool(torch.isfinite(pos).all())}
        rec["atom_count_matches_sdf"] = rec["graph_atoms"] in (
            rec["sdf_atoms_loader_default"], rec["sdf_atoms_keep_hs"])
        per.append(rec)
        if (not rec["atom_count_matches_sdf"] or not rec["positions_all_finite"]
                or rec["canonical_equals_frozen_raw"] is False):
            Problems.append({"label": "mol_graph:%s" % smi[:24],
                             "problem": "atom count / finiteness / canonicality check failed",
                             "detail": rec})
    return {"mol2id_rows": len(rows), "graph_keys": sorted(graphs.keys()),
            "keys_match_mol2id": sorted(graphs.keys()) == sorted(r["SMILES"] for r in rows),
            "per_molecule": per,
            "bytes": cache.stat().st_size, "sha256": sha_stream(cache)}


def canon_hash(obj):
    """Stable content hash of a torch structure, independent of serialisation bytes."""
    import torch

    def walk(o, acc):
        if torch.is_tensor(o):
            t = o.detach().cpu().contiguous()
            try:
                payload = t.numpy().tobytes()
            except (TypeError, ValueError):
                payload = t.view(torch.uint8).numpy().tobytes()
            acc.append(["tensor", list(t.shape), str(t.dtype),
                        hashlib.sha256(payload).hexdigest()])
        elif isinstance(o, dict):
            acc.append(["dict", [[str(k), walk(v, [])]
                                 for k, v in sorted(o.items(), key=lambda kv: str(kv[0]))]])
        elif isinstance(o, (list, tuple)):
            acc.append(["seq", [walk(v, []) for v in o]])
        elif isinstance(o, (int, float, str, bool)) or o is None:
            acc.append(["prim", type(o).__name__, repr(o) if isinstance(o, float) else o])
        elif hasattr(o, "_store"):
            store = getattr(o, "_store", {}) or {}
            acc.append(["pyg", type(o).__name__,
                        [[str(k), walk(store[k], [])] for k in sorted(store.keys())]])
        else:
            acc.append(["other", type(o).__name__, repr(o)[:200]])
        return acc

    digest = hashlib.sha256(json.dumps(walk(obj, []), sort_keys=True,
                                       default=str).encode("utf-8")).hexdigest()
    return digest


overlay_check = build_reaction_overlay(C.REACTION_OVERLAY, "_t3b_primary")
primary = mol_graph_report(C.REACTION_OVERLAY / "molecule_conformation")
rebuild_check = build_reaction_overlay(C.REACTION_OVERLAY_REBUILD, "_t3b_rebuild")
rebuilt = mol_graph_report(C.REACTION_OVERLAY_REBUILD / "molecule_conformation")
import torch  # noqa: E402
canon_a = canon_hash(torch.load(str(C.REACTION_OVERLAY / "molecule_conformation"
                                   / "mol_graph_dict.pt"), map_location="cpu",
                                weights_only=False))
canon_b = canon_hash(torch.load(str(C.REACTION_OVERLAY_REBUILD / "molecule_conformation"
                                   / "mol_graph_dict.pt"), map_location="cpu",
                                weights_only=False))

# the frozen pins the authority payload records for these generated/staged files
auth_txt = (C.INPUT_ROOT / "authority" / C.AUTH_ROOTNAME / C.AUTH_R1_AUDIT)
auth_text = auth_txt.read_text(encoding="utf-8", errors="replace") if auth_txt.exists() else ""
AUDIT_PINS = {
    "drfp/rxn2fp.pkl": (r"DRFP rxn2fp\.pkl SHA=([0-9a-f]{64})", None),
    "reacting_center/reacting_center.pkl": (r"reaction center SHA=([0-9a-f]{64})", None),
    "molecule_conformation/mol2id.csv": (r"mol2id\.csv SHA=([0-9a-f]{64})", None),
    "molecule_conformation/mol_graph_dict.pt": (
        r"generated mol_graph_dict\.pt bytes=(\d+)\n.*?SHA=([0-9a-f]{64})", 2),
}
frozen_pins = {}
GENERATED_PIN = "molecule_conformation/mol_graph_dict.pt"
for rel, (pat, grp) in AUDIT_PINS.items():
    m = re.search(pat, auth_text, re.S)
    if not m:
        frozen_pins[rel] = {"pin_available": False}
        continue
    if grp == 2:
        frozen_pins[rel] = {"pin_available": True, "bytes": int(m.group(1)),
                            "sha256": m.group(2)}
    else:
        frozen_pins[rel] = {"pin_available": True, "sha256": m.group(1)}
say("  frozen pins parsed from the SHA-verified authority audit:")
for _rel, _pin in sorted(frozen_pins.items()):
    say("    %-44s %s" % (_rel, json.dumps(_pin)))

for rel, pin in frozen_pins.items():
    if rel == GENERATED_PIN:
        # not a T3B member: the teacher loader regenerates it, so the authority pin is compared
        # against what *this* step generated, and against the second independent generation
        obs = {"relative": rel, "member": "(generated by the teacher load_mol_feat)",
               "manifest_sha256": "", "identical_to_manifest": "NOT_AN_ARCHIVE_MEMBER",
               "observed_sha256": primary.get("sha256", ""),
               "bytes": primary.get("bytes", ""),
               "independent_rebuild_sha256": rebuilt.get("sha256", "")}
        overlay_check.append(obs)
        if primary.get("sha256") != rebuilt.get("sha256"):
            Problems.append({"label": "generated_pin:mol_graph_dict",
                             "problem": "the two independent generations disagree"})
    else:
        obs = next((c for c in overlay_check if c["relative"] == rel), None)
        if obs is None:
            Problems.append({"label": "overlay_missing_member", "problem": rel})
            continue
    if pin.get("pin_available"):
        if obs["observed_sha256"] != pin.get("sha256"):
            Problems.append({"label": "overlay_pin:%s" % rel,
                             "problem": "observed %s != authority-frozen %s"
                                        % (obs["observed_sha256"], pin.get("sha256"))})
        obs["frozen_pin_sha256"] = pin.get("sha256")
        obs["matches_frozen_pin"] = obs["observed_sha256"] == pin.get("sha256")
        if "bytes" in pin:
            obs["frozen_pin_bytes"] = pin["bytes"]
            if obs.get("bytes") != pin["bytes"]:
                Problems.append({"label": "overlay_pin_bytes:%s" % rel,
                                 "problem": "observed %s != authority-frozen %s"
                                            % (obs.get("bytes"), pin["bytes"])})
    else:
        obs["matches_frozen_pin"] = "NO_PIN_IN_AUTHORITY"

OVERLAY = {"primary_dir": str(C.REACTION_OVERLAY),
           "rebuild_dir": str(C.REACTION_OVERLAY_REBUILD),
           "primary_staged_assets": overlay_check,
           "rebuild_staged_assets": rebuild_check,
           "primary_mol_graph": primary, "rebuild_mol_graph": rebuilt,
           "primary_canonical_content_sha256": canon_a,
           "rebuild_canonical_content_sha256": canon_b,
           "independent_rebuild_identical": (canon_a == canon_b
                                             and primary.get("sha256") == rebuilt.get("sha256")),
           "frozen_pins": frozen_pins}
if not OVERLAY["independent_rebuild_identical"]:
    Problems.append({"label": "reaction_overlay_rebuild",
                     "problem": "two independent builds are not identical",
                     "detail": {"primary": primary.get("sha256"), "rebuild": rebuilt.get("sha256"),
                                "canon_a": canon_a, "canon_b": canon_b}})
say("  overlay members=%d manifest-verified=%d; mol_graph_dict bytes=%s sha=%s rebuild_identical=%s"
    % (len(overlay_check),
       sum(1 for c in overlay_check if c.get("identical_to_manifest") is True),
       primary.get("bytes"), str(primary.get("sha256"))[:12],
       OVERLAY["independent_rebuild_identical"]))
with open(str(RD / "REACTION_OVERLAY_MANIFEST.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=["relative", "member", "bytes", "manifest_sha256",
                                       "observed_sha256", "identical_to_manifest",
                                       "frozen_pin_sha256", "matches_frozen_pin"],
                       extrasaction="ignore")
    w.writeheader()
    for c in overlay_check:
        w.writerow(c)
(RD / "REACTION_OVERLAY_REBUILD_DETERMINISM.json").write_text(
    json.dumps(OVERLAY, indent=2, ensure_ascii=False), encoding="utf-8")
if V1.get("overlay"):
    with open(str(RD / "V1_OVERLAY_MANIFEST.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["relpath", "bytes", "sha256"])
        w.writeheader()
        for r in V1["overlay"]:
            w.writerow(r)
    (RD / "V1_OVERLAY_CONFIG_DIFF.json").write_text(json.dumps(
        {"allowed_field_changes": list(C.OVERLAY_CONFIG_FIELDS),
         "model_fields_checked": list(MODEL_FIELDS),
         "model_fields_identical_across_seeds": V1.get("model_fields_identical"),
         "build_adopted_from_earlier_invocation": V1.get("build_adopted_from_earlier_invocation"),
         "per_seed": V1.get("config_diff"),
         "checkpoint_members": V1.get("per_seed"),
         "name_alike_members_rejected": V1.get("checkpoint_members_seen")},
        indent=2, ensure_ascii=False), encoding="utf-8")


# ----------------------------------------------------------------- 5. protein assets
say("== 5. the three read-only protein assets, hashed against the T3B-R1 manifest")
t3b_r1 = ARCHIVE_RESULT.get("T3B_R1", {}).get("member_sha", {})
pin_member = next((n for n in t3b_r1 if n.endswith("FROZEN_PROTEIN_UID_ASSET_IDENTITIES.csv")),
                  "")
pin_rows = []
if pin_member:
    stage = C.TMPS / "_t3b_r1_pin"
    if stage.exists():
        shutil.rmtree(str(stage))
    C.safe_extract(LOCATED["T3B_R1"], stage)
    pin_rows = list(csv.DictReader(open(str(stage / pin_member), encoding="utf-8")))
    shutil.rmtree(str(stage))
PROTEIN = []
for lab, p in sorted(C.PROTEIN_ASSETS.items()):
    if not p.exists():
        Problems.append({"label": "protein_asset_%s" % lab, "problem": "missing", "path": str(p)})
        continue
    link = p.is_symlink()
    st = os.stat(str(p))
    dig, was_adopted = hash_once("protein_asset", p)
    pinned = [r for r in pin_rows if os.path.realpath(r["path"]) == os.path.realpath(str(p))]
    exp_sha = pinned[0]["sha256"] if pinned else ""
    exp_bytes = int(pinned[0]["bytes"]) if pinned and pinned[0]["bytes"].isdigit() else None
    ok = (not link) and p.is_file() and dig == exp_sha and (exp_bytes in (None, st.st_size))
    PROTEIN.append({"asset": lab, "path": str(p), "regular": p.is_file(), "symlink": link,
                    "bytes": st.st_size, "sha256": dig,
                    "expected_sha256_from_t3b_r1": exp_sha,
                    "expected_bytes_from_t3b_r1": exp_bytes if exp_bytes else "",
                    "pinned_uid_label": pinned[0]["uid"] if pinned else "",
                    "adopted_from_earlier_invocation": was_adopted,
                    "status": "PASS" if ok else "FAIL"})
    if not ok:
        Problems.append({"label": "protein_asset_%s" % lab, "problem": "identity mismatch",
                         "observed": dig, "expected": exp_sha})
    say("  [%-4s] %-9s bytes=%-12d sha=%s %s"
        % ("PASS" if ok else "FAIL", lab, st.st_size, dig[:12],
           "(adopted)" if was_adopted else ""))
say("  T3B-R1 pins the first UID on all three rows; that per-UID repetition is the known R1")
say("  table defect, so the per-UID identity is rebuilt in §6.3 (D4 whitelist membership).")

# ----------------------------------------------------------------- 6. in-place §5.1/§6.1 trio
say("== 6. the §5.1 frozen reuse trio and the reviewed dependency inputs, in place")
INPLACE_ROWS = []
for kind, name, p, want, nbytes in IN_PLACE:
    exists = p.exists()
    st = os.stat(str(p)) if exists else None
    dig = sha_stream(p) if exists and not p.is_symlink() else ""
    ok = bool(exists and not p.is_symlink() and p.is_file() and (want in (None, dig))
              and (nbytes in (None, st.st_size)))
    mirror = MIRRORS.get(name)
    mirror_rec = ""
    if mirror is not None:
        m_ok = mirror.is_file() and not mirror.is_symlink()
        m_dig = sha_stream(mirror) if m_ok else ""
        mirror_rec = {"path": str(mirror), "sha256": m_dig,
                      "agrees_with_persistent_copy": bool(ok and m_ok and m_dig == dig)}
        if not mirror_rec["agrees_with_persistent_copy"]:
            Problems.append({"label": "mirror:%s" % name, "problem":
                             "transient mirror does not agree with the pinned persistent copy",
                             "detail": mirror_rec})
    INPLACE_ROWS.append({"kind": kind, "label": name, "path": str(p),
                         "exists": exists, "regular": bool(p.is_file() and not p.is_symlink()),
                         "symlink": p.is_symlink() if exists else "",
                         "bytes": st.st_size if exists else "", "sha256": dig,
                         "expected_sha256": want or "", "expected_bytes": nbytes or "",
                         "mirror": mirror_rec,
                         "status": "PASS" if ok else ("NO_PIN" if not want else "FAIL")})
    if not ok and want:
        Problems.append({"label": name, "problem": "in-place identity mismatch",
                         "observed": dig, "expected": want})
    say("  [%-4s] %-52s %s" % ("PASS" if ok else ("NO-PIN" if not want else "FAIL"),
                               name[:52], str(p)[-46:]))

# ----------------------------------------------------------------- verdict + artefacts
problems = Problems
gate = {
    "section": "6.2 fixed asset identity (everything located by pinned SHA256)",
    "utc": C.now_utc(),
    "pinned_interpreter": C.PY,
    "status": "PASS" if not problems else "FAIL",
    "discovery_scan": {
        "roots": [{"path": str(r), "max_depth": d} for r, d in SCAN_SPEC],
        "files_hashed": len(SCAN_ROWS),
        "total_bytes_hashed": sum(r["bytes"] for r in SCAN_ROWS if isinstance(r["bytes"], int)),
        "seconds": scan_s,
        "distinct_pinned_digests": len(REGISTRY),
        "digests_located_exactly_once": sum(1 for d, v in hits.items() if len(v) == 1),
        "method": "SHA256 of every regular file, then name assigned only from a byte-exact "
                  "digest hit; no use of mtime, 'latest', or a similar file name",
        "look_alike_files_rejected_by_name_only": rejected_lookalikes,
    },
    "located": LOCATED,
    "archives": {k: {kk: vv for kk, vv in v.items()
                     if kk not in ("member_sha", "member_sizes")}
                 for k, v in ARCHIVE_RESULT.items()},
    "d4_wrapper_directory": {"dir": str(C.D4_WRAPPER_DIR), "files": wrap_rows},
    "v1_checkpoints_and_overlay": V1,
    "reaction_overlay": OVERLAY,
    "protein_assets": PROTEIN,
    "in_place_frozen_inputs": INPLACE_ROWS,
    "problems": problems,
    "resume_markers_present": sorted(k for k in MARKERS),
    "read_only_promise": "No asset outside WORK_ROOT was created, edited or deleted by this "
                         "step; every extraction target is under WORK_ROOT.",
}
(RD / "FIXED_ASSET_IDENTITY_GATE.json").write_text(
    json.dumps(gate, indent=2, ensure_ascii=False), encoding="utf-8")
with open(str(RD / "INPUT_IDENTITIES.csv"), "w", newline="", encoding="utf-8") as fh:
    keys = ["kind", "label", "path", "bytes", "expected_sha256", "observed_sha256",
            "sha_hit_count", "located_by", "pinned_in", "status"]
    w = csv.DictWriter(fh, fieldnames=keys, extrasaction="ignore")
    w.writeheader()
    for r in ROWS:
        w.writerow(r)
    for r in INPLACE_ROWS:
        w.writerow({"kind": r["kind"], "label": r["label"], "path": r["path"],
                    "bytes": r["bytes"], "expected_sha256": r["expected_sha256"],
                    "observed_sha256": r["sha256"], "sha_hit_count": "",
                    "located_by": "verified in place", "pinned_in": "current prompt §6.2/§5.1",
                    "status": r["status"]})
    for r in PROTEIN:
        w.writerow({"kind": "protein_asset", "label": r["asset"], "path": r["path"],
                    "bytes": r["bytes"],
                    "expected_sha256": r["expected_sha256_from_t3b_r1"],
                    "observed_sha256": r["sha256"], "sha_hit_count": "",
                    "located_by": "full-file SHA256", "pinned_in": "T3B-R1 archive manifest",
                    "status": r["status"]})
    for lab, r in sorted(ARCHIVE_RESULT.items()):
        w.writerow({"kind": "archive_internal_manifest", "label": lab, "path": r["tar"],
                    "bytes": "", "expected_sha256": "", "observed_sha256": "",
                    "sha_hit_count": "", "located_by": "member-level recomputation",
                    "pinned_in": "%d/%d manifest entries matched"
                                 % (r["manifest_matched"], r["manifest_checked"]),
                    "status": r["status"]})
with open(str(RD / "ASSET_SHA_DISCOVERY_SCAN.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=["path", "bytes", "sha256", "symlink", "status", "labels"])
    w.writeheader()
    for r in SCAN_ROWS:
        w.writerow(r)
with open(str(RD / "ARCHIVE_MANIFEST_AUDIT.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=["label", "tar", "members", "link_members",
                                       "special_members", "regular_members",
                                       "top_level_roots", "single_root", "manifest_member",
                                       "manifest_lines", "manifest_checked", "manifest_matched",
                                       "manifest_unparsed_lines", "manifest_exemption",
                                       "manifest_mismatched",
                                       "unsafe_members", "status"], extrasaction="ignore")
    w.writeheader()
    for r in MANIFEST_ROWS:
        w.writerow(r)
(RD / "FIXED_ASSET_IDENTITY_STDOUT.txt").write_text("\n".join(say_lines) + "\n",
                                                    encoding="utf-8")
say("== verdict: FIXED_ASSET_IDENTITY=%s (%d problems)"
    % ("PASS" if not problems else "FAIL", len(problems)))
for p in problems[:12]:
    say("   PROBLEM " + json.dumps(p, ensure_ascii=False, default=str)[:300])
(RD / "FIXED_ASSET_IDENTITY_STDOUT.txt").write_text("\n".join(say_lines) + "\n",
                                                    encoding="utf-8")
C.self_audit(__file__, 0 if not problems else 3, "§6.2 fixed asset identity")
sys.exit(0 if not problems else 3)
