#!/usr/bin/env python3
"""T6-R3-R1 p14b — pre-registration observer (CPU only, read-only).

Contract §5 requires the eight smoke records to be *selected from real runs* and frozen
**before** any full-chain execution.  This child process therefore

  1. imports the teacher's own ``src.graph`` from the §5.2/§5.3 gated tree and compiles it
     once with the real ``langgraph.graph.StateGraph``;
  2. runs the real graph for the teacher's B-primary case substrate and for every substrate
     of the frozen C-fallback probe list, stopping the stream at ``enzyme_pool`` so that no
     GPU node is ever entered (CUDA_VISIBLE_DEVICES is empty in this process anyway);
  3. asks the *production* ``src.tools.trait_query.C8TraitAdapter`` (authority C8 index +
     authority UID map, both SHA-pinned by the caller) for the F1—F15 evidence classes of
     every UID of those two real pools, in pool order;
  4. applies the two pre-registered selection rules and reads S3—S8 straight out of the §7
     real forward evidence.

Nothing here decides a verdict: it produces measurements.  Every path that was really opened
is captured through ``sys.addaudithook`` ("open" events) instead of being guessed, and the
network/credential audit is recorded for the caller.  Teacher source is never modified.
"""
import hashlib
import io
import json
import os
import re
import socket
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

CFG = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
OUT = Path(CFG["out_json"])
STAGED = CFG["staged"]

RES = {"utc_started": None, "problems": [], "phases": {}}
_OPENED = []
_NET = []
_OPEN_RE = re.compile(
    r"(m3_agent_data_assets|/usrdata/EnzymeCAGE_data/feature|C8_METATRAITS|"
    r"uid_to_source_keep|depending_teacher_fixed_r1|runtime_assets|cases/)", re.I)


def _utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def problem(kind, msg, **kw):
    RES["problems"].append(dict(kind=kind, message=str(msg)[:400], **kw))


def phase(name):
    RES["phases"][name] = {"utc": _utc(), "t": round(time.monotonic() - T0, 3)}


T0 = time.monotonic()
RES["utc_started"] = _utc()


def _audit(event, args):
    if event == "open":
        try:
            p = args[0]
            if not isinstance(p, (str, bytes, os.PathLike)):
                return
            sp = os.fspath(p)
            if isinstance(sp, bytes):
                sp = sp.decode("utf-8", "replace")
        except Exception:
            return
        if _OPEN_RE.search(sp):
            _OPENED.append(sp)
    elif event in {"socket.connect", "socket.getaddrinfo", "create_connection",
                   "urllib.Request", "http.client.connect"}:
        _NET.append({"event": event, "args": repr(args)[:200]})


try:
    sys.addaudithook(_audit)
except Exception as exc:                                       # pragma: no cover
    problem("audithook", "cannot install audit hook: %r" % exc)

# ------------------------------------------------------------------ 0. interpreter + env
RES["interp"] = {"sys_executable": sys.executable,
                 "realpath": os.path.realpath(sys.executable),
                 "version": sys.version.split()[0],
                 "is_pinned": os.path.realpath(sys.executable) == os.path.realpath(CFG["pinned_py"]),
                 "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
                 "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
                 "hash_algorithm_check": hashlib.sha256(b"p14b").hexdigest()[:8],
                 "argv0": sys.argv[0]}
if RES["interp"]["is_pinned"] is not True:
    problem("interpreter", "observer is not running on the pinned interpreter")
print("R1_INTERP " + json.dumps(RES["interp"]), flush=True)

ENV_WRITTEN = {}
for k, v in CFG["env"].items():
    ENV_WRITTEN[k] = os.environ.get(k)
    os.environ[k] = v
RES["env_pre_existing"] = ENV_WRITTEN
RES["env_set_by_observer"] = dict(CFG["env"])
for k in CFG.get("env_pop", []):
    RES.setdefault("env_credentials_popped", {})[k] = os.environ.pop(k, None)

sys.path.insert(0, STAGED)
RES["sys_path_head"] = sys.path[:3]

# ------------------------------------------------------------------ 1. teacher graph, once
from src.graph import build_graph, compile_graph                # noqa: E402
import langgraph.graph as _lgg                                   # noqa: E402
import config.settings as _S                                     # noqa: E402

RES["graph_module_file"] = os.path.realpath(sys.modules["src.graph"].__file__)
RES["langgraph"] = {"module_file": os.path.realpath(_lgg.__file__),
                    "StateGraph": str(_lgg.StateGraph),
                    "stategraph_is_real_langgraph":
                        "langgraph" in os.path.realpath(_lgg.__file__)}
RES["settings_resolved"] = {k: str(getattr(_S, k)) for k in
                            ("DATA_ASSETS_ROOT", "RHEA_DIR", "ROUTE_B_DIR", "ROUTE_C_DIR",
                             "D4_DIR") if hasattr(_S, k)}

workflow = build_graph()
compiled = compile_graph()
RES["compile"] = {"compile_calls": 1, "workflow_type": type(workflow).__name__,
                  "compiled_type": type(compiled).__name__,
                  "pre_compile_stategraph_nodes": sorted(workflow.nodes),
                  "pre_compile_node_count": len(workflow.nodes),
                  "compiled_drawn_nodes": sorted(compiled.get_graph().nodes),
                  "compiled_drawn_node_count": len(compiled.get_graph().nodes),
                  "node_count": len(workflow.nodes),
                  "drawn_note": ("compiled.get_graph() adds the virtual __start__/__end__ nodes; "
                                 "the teacher topology itself has the 12 named nodes")}
phase("graph_compiled")


def _leaf(v):
    """Pydantic-safe field reader for a model instance or plain dict."""
    if v is None:
        return None
    if isinstance(v, dict):
        return v
    return v


def _g(obj, key, default=None):
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


GPU_NODES = {"enzymecage", "reranking", "microbe", "organism_selection", "trait", "synthesis"}


def run_to_pool(tag, substrate, mode="m3"):
    """One real streamed run, consumed up to (and including) the enzyme_pool update."""
    thread = {"configurable": {"thread_id": "p14b-%s-%d" % (tag, int(time.time() * 1000))}}
    order, err, raised = [], None, None
    t0 = time.monotonic()
    started = _utc()
    vals = {}
    try:
        for chunk in compiled.stream({"user_query": substrate, "pipeline_mode": mode},
                                     thread, stream_mode="updates"):
            if isinstance(chunk, dict):
                for nm in chunk:
                    order.append(nm)
            if order and order[-1] == "enzyme_pool":
                break
        vals = _g(compiled.get_state(thread), "values", {}) or {}
    except Exception:
        err = traceback.format_exc()
        raised = err.strip().splitlines()[-1][:300]
    ended = _utc()

    cands = _g(vals, "candidate_reactions") or []
    pool = _g(vals, "enzyme_pool_final") or []
    chain = _g(vals, "evidence_chain") or []
    chain_json = json.dumps([{"stage": _g(e, "stage"), "action": _g(e, "action"),
                              "data": _g(e, "data")} for e in chain],
                            ensure_ascii=False, sort_keys=True, default=str)
    sub_info = _g(vals, "substrate_info")
    rec = {
        "scenario": tag, "input_user_query": substrate, "pipeline_mode": mode,
        "started_utc": started, "ended_utc": ended,
        "wall_s": round(time.monotonic() - t0, 3),
        "node_execution_order": order, "thread_id": thread["configurable"]["thread_id"],
        "raised": raised, "traceback": err,
        "substrate_smiles": _g(sub_info, "substrate_smiles"),
        "substrate_source": _g(sub_info, "source"),
        "substrate_provenance": _g(sub_info, "provenance"),
        "reaction_task_id_state": _g(vals, "reaction_task_id"),
        "candidate_reaction_count": len(cands),
        "candidate_reactions_head": [{
            "reaction_smiles": _g(c, "reaction_smiles"),
            "reaction_sha256": _g(c, "reaction_sha256"),
            "source": _g(c, "source"), "source_tag": _g(c, "source_tag"),
            "source_tool": _g(c, "source_tool"), "rhea_id": _g(c, "rhea_id"),
            "ec_numbers": _g(c, "ec_numbers"),
            "similarity_score": _g(c, "similarity_score"),
            "prediction_rank": _g(c, "prediction_rank"),
        } for c in cands[:5]],
        "candidate_sources_distinct": sorted({str(_g(c, "source")) for c in cands}),
        "pool_route_used": _g(vals, "pool_route_used"),
        "pool_size": _g(vals, "pool_size"),
        "enzyme_pool_b_size": len(_g(vals, "enzyme_pool_b") or []),
        "enzyme_pool_c_size": len(_g(vals, "enzyme_pool_c") or []),
        "enzyme_pool_final_ordered": list(pool),
        "state_error": _g(vals, "error"),
        "state_fail_closed": _g(vals, "fail_closed"),
        "evidence_chain_stages": [_g(e, "stage") for e in chain],
        "evidence_chain_sha256": hashlib.sha256(chain_json.encode("utf-8")).hexdigest(),
        "enzymecage_gpu_node_entered": bool(set(order) & GPU_NODES),
    }
    return rec


# ---------------------------------------------------------- 2. S1: real B-primary case
case_path = Path(CFG["case_b_primary"])
case_raw = case_path.read_bytes()
case = json.loads(case_raw.decode("utf-8"))
B_SUB = (case.get("expected") or {}).get("substrate", {}).get("smiles")
if not B_SUB:
    problem("case_substrate", "expected.substrate.smiles missing in the teacher case file")
RES["case_b_primary_identity"] = {
    "path": str(case_path), "bytes": len(case_raw),
    "sha256": hashlib.sha256(case_raw).hexdigest(),
    "case_id": case.get("case_id"), "case_name": case.get("case_name"),
    "query_field": case.get("query"), "expected_pool_route": (case.get("expected") or {}).get(
        "pool", {}).get("route_used"),
    "substrate_taken_from": "cases/case_1_realrun.json:expected.substrate.smiles "
                            "(not hand-typed)",
    "substrate_smiles": B_SUB,
    "graph_input_note": "user_query is set to the bare substrate SMILES so the substrate node "
                        "resolves it through the deterministic 'user_smiles' path; no LLM is "
                        "called and no query text is invented"}

r1 = run_to_pool("PREREG_B_PRIMARY", B_SUB, "m3")
RES["run_b_primary"] = r1
if r1["enzymecage_gpu_node_entered"]:
    problem("gpu_node_entered", "the B-primary probe run reached a GPU node",
            nodes=r1["node_execution_order"])
if r1["pool_route_used"] != "B":
    problem("b_primary_route", "real graph run did not take route B",
            observed=r1["pool_route_used"], error=r1["state_error"])
if (r1["candidate_reaction_count"] or 0) < int(
        ((case.get("expected") or {}).get("reaction") or {}).get("min_num_candidates", 0)):
    problem("b_primary_candidates", "fewer candidate reactions than the case expects",
            observed=r1["candidate_reaction_count"])

# --------------------------------------------- 3. S2: frozen C-fallback candidate battery
probe_path = Path(CFG["c_fallback_probe"])
probe_raw = probe_path.read_bytes()
probe = json.loads(probe_raw.decode("utf-8"))
battery = [{"substrate": c["substrate"], "probe_pool_size": c.get("pool_size")}
           for c in probe.get("candidates_with_route_C") or []]
if not battery:
    problem("c_battery", "the frozen C-fallback probe list is empty")
RES["c_fallback_probe_identity"] = {
    "path": str(probe_path), "bytes": len(probe_raw),
    "sha256": hashlib.sha256(probe_raw).hexdigest(),
    "candidate_order": [b["substrate"] for b in battery],
    "note": "frozen list produced by probe_c_fallback_input.py through the production "
            "build_enzyme_pool; this run re-tests every entry in the real graph"}

c_runs = []
for i, b in enumerate(battery):
    r = run_to_pool("PREREG_C_%d" % i, b["substrate"], "m3")
    r["battery_index"] = i
    c_runs.append(r)
    if r["enzymecage_gpu_node_entered"]:
        problem("gpu_node_entered", "a C battery run reached a GPU node", substrate=r["input_user_query"])
RES["c_battery_runs"] = c_runs
phase("c_battery_done")

eligible = [r for r in c_runs if r["pool_route_used"] == "C" and (r["pool_size"] or 0) >= 1]
RES["c_eligibility"] = {
    "rule": ("CASE_C_FALLBACK_SUCCESS := real graph run whose production pool_route_used == 'C' "
             "and pool_size >= 1; tie-break among eligible runs: largest real pool, then "
             "shortest substrate SMILES, then lexicographic minimum"),
    "eligible_substrates": [r["input_user_query"] for r in eligible],
    "observed_per_run": [{"substrate": r["input_user_query"], "route": r["pool_route_used"],
                          "pool_size": r["pool_size"], "nodes": r["node_execution_order"],
                          "error": r["state_error"]} for r in c_runs],
}
chosen_c = None
if eligible:
    chosen_c = sorted(eligible, key=lambda r: (-(r["pool_size"] or 0),
                                               len(r["input_user_query"]),
                                               r["input_user_query"]))[0]
    RES["c_eligibility"]["chosen"] = {"substrate": chosen_c["input_user_query"],
                                      "pool_size": chosen_c["pool_size"]}
else:
    problem("c_fallback_unavailable", "no real graph run produced a C-fallback pool")
RES["run_c_fallback"] = chosen_c

# ------------------------------------------------- 4. production C8 trait classes per UID
from src.tools.trait_query import C8TraitAdapter, F_TRAITS       # noqa: E402
from src.tools.reaction_retriever import reaction_sha256 as _prod_sha256  # noqa: E402
from src.schemas.evidence import OrganismCandidate, SupportingEnzyme  # noqa: E402

CARRIER = "PROBE_CARRIER_NOT_FINAL_HOST"


def sha_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


uid_map = CFG["c8_uid_map_path"]
lookup_root = CFG["c8_lookup_root"]
index_file = os.path.join(lookup_root, "C8_METATRAITS_LOOKUP_INDEX.jsonl")
RES["c8_assets"] = {
    "uid_map_path": uid_map, "uid_map_bytes": os.path.getsize(uid_map),
    "uid_map_sha256": sha_file(uid_map), "uid_map_expected_sha256": CFG["uid_map_sha256"],
    "lookup_root": lookup_root, "lookup_index_path": index_file,
    "lookup_index_bytes": os.path.getsize(index_file),
    "lookup_index_sha256": sha_file(index_file),
    "lookup_index_expected_sha256": CFG["c8_lookup_sha256"],
    "portraits_enabled": False,
}
if RES["c8_assets"]["uid_map_sha256"] != CFG["uid_map_sha256"]:
    problem("c8_asset_sha", "authority UID map hash mismatch")
if RES["c8_assets"]["lookup_index_sha256"] != CFG["c8_lookup_sha256"]:
    problem("c8_asset_sha", "authority C8 lookup index hash mismatch")

t_ad = time.monotonic()
adapter = C8TraitAdapter(lookup_root, uid_map)
RES["c8_adapter"] = {"class": "src.tools.trait_query.C8TraitAdapter",
                     "construct_s": round(time.monotonic() - t_ad, 2),
                     "f_traits": list(F_TRAITS),
                     "lookup_rows_expected": 37170, "uid_rows_expected": 168335}
phase("c8_adapter_loaded")


def classify(uid, rank):
    """Production annotation of one pool UID; the carrier host is explicitly not final host."""
    cand = OrganismCandidate(organism_uid=CARRIER, ncbi_taxon_id=1, organism_name=CARRIER,
                             supporting_enzymes=[SupportingEnzyme(uid=uid, score=0.0, rank=rank)],
                             supporting_enzyme_count=1)
    anns, meta = adapter.annotate([cand])
    classes = {}
    sigs, taxids, resolutions, groups = [], [], [], []
    for a in anns:
        sigs.append(a.source_signature)
        taxids.append(a.host_taxid)
        resolutions.append(a.host_resolution)
        groups.append(a.host_taxonomy_group)
        for tid in F_TRAITS:
            c = a.traits[tid].trait_evidence_class
            classes[c] = classes.get(c, 0) + 1
    first = anns[0] if anns else None
    return {
        "UID": uid, "preselection_rank": rank,
        "annotation_count": len(anns),
        "source_signatures": sorted({str(s) for s in sigs}),
        "host_taxids_mapped": sorted({t for t in taxids if t}),
        "host_resolutions": sorted({str(r) for r in resolutions}),
        "taxonomy_groups": sorted({str(g) for g in groups}),
        "host_evidence_sources": sorted({s for a in anns for s in a.host_evidence_sources}),
        "trait_class_counts": {k: v for k, v in sorted(classes.items())},
        "observed_trait_count": classes.get("OBSERVED", 0),
        "missing_trait_count": classes.get("MISSING", 0),
        "identity_only_trait_count": classes.get("IDENTITY_ONLY", 0),
        "observed_trait_ids": [tid for tid in F_TRAITS
                               if first is not None and
                               first.traits[tid].trait_evidence_class == "OBSERVED"],
        "missing_trait_ids": [tid for tid in F_TRAITS
                              if first is not None and
                              first.traits[tid].trait_evidence_class == "MISSING"],
        "not_mapped": uid in (meta.get("not_mapped_uids") or []),
        "uid_map_row_count": len(anns),
        "adapter_meta_hashes": meta.get("asset_hashes"),
        "carrier_host": CARRIER,
        "carrier_is_final_host_evidence": False,
    }


def classify_pool(run, label):
    out = []
    for rank, uid in enumerate(run["enzyme_pool_final_ordered"], 1):
        out.append(classify(uid, rank))
    return {"pool_of": label, "substrate": run["input_user_query"],
            "pool_route_used": run["pool_route_used"], "pool_size": run["pool_size"],
            "uids_in_pool_order": run["enzyme_pool_final_ordered"],
            "per_uid_trait_classification": out}


b_class = classify_pool(r1, "CASE_B_PRIMARY_SUCCESS")
c_class = classify_pool(chosen_c, "CASE_C_FALLBACK_SUCCESS") if chosen_c else None
RES["trait_probe_b"] = b_class
RES["trait_probe_c"] = c_class
phase("trait_probe_done")

# ------------------------------------------------------------------ 5. the two §5 rules
S1_RULE = ("CASE_B real pool, pool order = production build_enzyme_pool order "
           "(sorted EC iteration + dict.fromkeys dedup); take the highest-rank (first) UID "
           "that has at least one OBSERVED trait among F1-F15 via the production "
           "C8TraitAdapter; if none, take rank 1 and record the observed-coverage block")
S2_RULE = ("CASE_C real pool, same pool order; take the highest-rank UID that has at least "
           "one MISSING trait among F1-F15 via the production C8TraitAdapter; if none, take "
           "rank 1 and record the reason")


def pick(cls, want, rule):
    considered = []
    chosen = None
    for row in cls["per_uid_trait_classification"]:
        key = "observed_trait_count" if want == "OBSERVED" else "missing_trait_count"
        considered.append({"UID": row["UID"], "rank": row["preselection_rank"],
                           key: row[key]})
        if chosen is None and row[key] >= 1:
            chosen = row
    fallback = not chosen
    if fallback:
        chosen = cls["per_uid_trait_classification"][0]
    return {"rule": rule, "chosen": chosen, "fallback_to_rank1": fallback,
            "considered_in_rank_order": considered}


RES["selection_b"] = pick(b_class, "OBSERVED", S1_RULE)
RES["selection_c"] = pick(c_class, "MISSING", S2_RULE) if c_class else None

# ------------------------------------------------- 6. S3—S8 straight out of the §7 evidence
fwd_jsonl = Path(CFG["forward_jsonl"])
fwd_rows = [json.loads(l) for l in fwd_jsonl.read_text(encoding="utf-8").splitlines() if l.strip()]
scores_csv = Path(CFG["forward_scores_csv"])
score_lines = scores_csv.read_text(encoding="utf-8").splitlines()
RES["forward_identity"] = {
    "jsonl_path": str(fwd_jsonl), "jsonl_bytes": fwd_jsonl.stat().st_size,
    "jsonl_sha256": sha_file(fwd_jsonl), "jsonl_rows": len(fwd_rows),
    "scores_csv_path": str(scores_csv), "scores_csv_bytes": scores_csv.stat().st_size,
    "scores_csv_sha256": sha_file(scores_csv), "scores_csv_header": score_lines[0],
    "scores_csv_rows": len(score_lines) - 1}

staged_rows = []
for row in fwd_rows:
    labels = list((row.get("per_request") or {}).keys())
    if len(labels) != 1:
        problem("forward_row_request_labels", "expected exactly one §7 request label, got %s"
                % labels, reaction_task_id=row.get("reaction_task_id"))
    label = labels[0] if labels else None
    base = ((row.get("per_request") or {}).get(label) or {}).get("base") or {}
    ranking = {r["uid"]: r for r in base.get("ranked_enzymes") or []}
    forwarded = [u for u, _s in sorted(ranking.items(), key=lambda kv: kv[1]["rank"])]
    staged_rows.append({
        "request_label": label,
        "forward_pair_isolation": row.get("isolated_forward_pairs"),
        "reaction_task_id": row.get("reaction_task_id"),
        "reaction_smiles": row.get("reaction_smiles"),
        "reaction_sha256_production": _prod_sha256(row.get("reaction_smiles") or ""),
        "g5_pair_contract": "reaction_smiles + reaction_sha256 produced by the teacher's own "
                            "src.tools.reaction_retriever.reaction_sha256 (UTF-8, no newline)",
        "worker_index": row.get("worker_index"), "gpu_uuid": row.get("gpu_uuid"),
        "exit_code": row.get("exit_code"), "worker_status": row.get("worker_status"),
        "forward_executed": base.get("forward_executed"),
        "forward_call_count_after": base.get("forward_call_count_after"),
        "model_version": base.get("model_version"),
        "evidence_hash": base.get("evidence_hash"),
        "original_uids": base.get("original_uids"),
        "real_rank_order": [(u, ranking[u]["rank"]) for u in forwarded],
        "scores_per_uid_seed": {u: [se[i] for se in base.get("per_seed_scores") or []]
                                for i, u in enumerate(base.get("original_uids") or [])},
        "stdout_log": row.get("stdout_log"), "stdout_sha256": row.get("stdout_sha256"),
        "stderr_log": row.get("stderr_log"), "stderr_sha256": row.get("stderr_sha256"),
        "started_utc": row.get("started_utc"), "ended_utc": row.get("ended_utc"),
        "wall_sec": row.get("wall_sec")})
RES["staged_forward_rows"] = staged_rows

FROZEN_UID_ORDER = CFG["frozen_uid_order"]
RES["staged_selection_rule"] = (
    "contract §5 line 210-211: three T3B staged reactions x the frozen UID order %s, first "
    "two UIDs actually present in the §7 real forward; preselection_rank reported below is "
    "that UID's real EnzymeCAGE rank in the §7 base ranking" % FROZEN_UID_ORDER)

# the same production adapter is asked about the S3—S8 UIDs, so the §5 minimum trait-coverage
# table (observed trait / trait missing) can be filled from a real lookup and not from prose
staged_uids = sorted({u for row in staged_rows for u in (row.get("original_uids") or [])})
RES["trait_probe_staged"] = [dict(classify(u, 0), uid_probe_order=i + 1,
                                  preselection_rank_note=(
                                      "preselection_rank=0: these UIDs are §7 forward targets, "
                                      "not members of a graph-built enzyme pool"))
                             for i, u in enumerate(staged_uids)]
phase("trait_probe_staged_done")

# ------------------------------------------------------------------ 7. reachability notes
RES["torch_state"] = {"torch_in_sys_modules": "torch" in sys.modules,
                      "cuda_initialised": (
                          bool(sys.modules["torch"].cuda.is_initialized())
                          if "torch" in sys.modules and
                          hasattr(sys.modules["torch"], "cuda") else None)}
DATA_SUFFIX = (".pkl", ".pt", ".csv", ".gz", ".tsv", ".jsonl", ".json", ".sdf", ".txt")
opened_data = [p for p in sorted(set(_OPENED))
               if p.endswith(DATA_SUFFIX) and os.path.isfile(p) and len(p) < 400]
RES["opened_files"] = {
    "unique_open_events": len(_OPENED),
    "unique_paths": len(set(_OPENED)),
    "data_paths": opened_data,
    "data_paths_sha256": {p: sha_file(p) for p in opened_data},
    "source_paths": [p for p in sorted(set(_OPENED)) if p.endswith(".py")]}
RES["network_events"] = _NET
RES["utc_ended"] = _utc()
RES["wall_s"] = round(time.monotonic() - T0, 2)

buf = io.StringIO()
json.dump(RES, buf, ensure_ascii=False, indent=1, default=str)
OUT.write_text(buf.getvalue(), encoding="utf-8")
print("@@P14B@@ %s" % json.dumps({"ok": not RES["problems"], "problems": len(RES["problems"]),
                                  "b_route": r1["pool_route_used"],
                                  "b_pool": r1["pool_size"],
                                  "c_chosen": (chosen_c or {}).get("input_user_query"),
                                  "c_pool": (chosen_c or {}).get("pool_size"),
                                  "opened_data": len(opened_data),
                                  "net": len(_NET),
                                  "wall": RES["wall_s"]}))
