# -*- coding: utf-8 -*-
"""§6.1 preflight: locate every frozen input the CPU regression needs *by pinned identity*.

The 157 named component checks of §6.1 are executed by the teacher's own frozen test files,
which hard-code absolute paths under /usrdata and /tmp.  This step does not run any test; it
proves that every one of those paths is a regular, non-symlink file whose bytes and SHA256
are the identity the contract (or the frozen test itself) pins, and it materialises the
depending v3.2 runtime as a WORK_ROOT copy so that TEST-01 can execute without writing into
another task's tree.

Outputs (C.RETURN_DIR):
  CPU_REGRESSION_INPUT_GATE.json
  CPU_TEST_INPUT_IDENTITIES.csv
  V32_RUNTIME_STAGING.csv
"""
import csv
import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import r1_common as C  # noqa: E402

C.emit_interp()
RC_DIR = C.RETURN_DIR
RC_DIR.mkdir(parents=True, exist_ok=True)
say_lines = []


def say(msg):
    print(msg, flush=True)
    say_lines.append(msg)


def sha_of(path):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


ROWS = []


def check(label, path, exp_bytes=None, exp_sha=None, required=True, note=""):
    """Record the real identity of one frozen input and judge it against the pinned value."""
    p = Path(str(path))
    row = {"label": label, "path": str(p), "expected_bytes": exp_bytes if exp_bytes else "",
           "expected_sha256": exp_sha if exp_sha else "", "note": note}
    if not p.exists():
        row.update({"exists": False, "regular": False, "symlink": False, "bytes": "",
                    "sha256": "", "status": "MISSING" if required else "ABSENT_OPTIONAL"})
        ROWS.append(row)
        say("[%-6s] %s  %s" % (row["status"][:6], label, p))
        return row
    p_real = p.resolve()
    link = p.is_symlink()
    if p.is_dir():
        row.update({"exists": True, "regular": False, "symlink": link, "bytes": "dir",
                    "sha256": "", "status": "DIR"})
        ROWS.append(row)
        say("[DIR   ] %s  %s" % (label, p))
        return row
    b = p.stat().st_size
    s = sha_of(p)
    ok = (exp_bytes in (None, b)) and (exp_sha in (None, s))
    row.update({"exists": True, "regular": p.is_file() and not link, "symlink": link,
                "bytes": b, "sha256": s, "status": "PASS" if ok else "IDENTITY_MISMATCH",
                "resolved": str(p_real) if link else ""})
    ROWS.append(row)
    say("[%-6s] %s  %s  bytes=%d sha=%s%s" % (
        row["status"][:6], label, p.name, b, s[:16],
        "  (symlink->%s)" % p_real.name if link else ""))
    return row


RETURN_ROOT = C.RETURN_ROOT
WS = Path("/usrdata/EnzymeCAGE_data/workspaces")

# ──────────────────────────────────────────────────────────────────────────────────────────
# 1. the four fixed inputs the frozen C8/T5 tests read directly
# ──────────────────────────────────────────────────────────────────────────────────────────
say("== 1. fixed C8 / T1 / UID inputs read directly by the frozen tests")
UID_MAP = (RETURN_ROOT / "enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_"
           "rerun1_20260820/_input_payload/enzymecage_m4b_c8_1_dependency_payload_20260820/"
           "inputs/uid_to_source/uid_to_source_keep_bacteria_fungi_archaea.csv")
check("uid_map_reviewed_frozen", UID_MAP, 104025134, C.UID_MAP_SHA,
      note="pinned by task §6.2, by src/tools/trait_query.py and by tests/_t6r3ar2a_support.py")

CACHE = Path("/tmp/t5b_test_cache")
C8_ROOTNAME = ("enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_rerun2_"
               "repack_fix_20260820")
T1_ROOTNAME = ("enzymecage_three_module_t1_r2_r1_pool100_cpu_metadata_validator_"
               "correction_20260905")
C8_ARCHIVE_TAR = RETURN_ROOT / (C8_ROOTNAME + ".tar.gz")
T1_ARCHIVE_TAR = RETURN_ROOT / (T1_ROOTNAME + ".tar.gz")
check("c8_rerun2_archive_tar", C8_ARCHIVE_TAR, note="canonical archive behind /tmp/t5b_test_cache")
check("t1_r2_r1_archive_tar", T1_ARCHIVE_TAR, note="canonical archive behind /tmp/t5b_test_cache")
check("c8_lookup_index_in_tmp_cache", CACHE / C8_ROOTNAME / "C8_METATRAITS_LOOKUP_INDEX.jsonl",
      57211793, C.C8_LOOKUP_SHA,
      note="bytes+SHA pinned by trait_query.py and by the first round INPUT_IDENTITIES.csv")
T1_GPU_TMP = CACHE / T1_ROOTNAME / "GPU_FORMAL_ENTRY_RESULTS.jsonl"
t1gpu = check("t1_gpu_results_in_tmp_cache", T1_GPU_TMP,
              note="fixture source for the 17 unique UIDs")

# re-extract both archives into WORK_ROOT and compare against the /tmp cache, so the cache is
# proven to be the frozen archive and not an untracked edit
verify_root = C.RUNTIME_ASSETS / "cpu_input_verify"
verify_root.mkdir(parents=True, exist_ok=True)
mismatch = []
for tar, rootname, relfiles in (
        (C8_ARCHIVE_TAR, C8_ROOTNAME, ["C8_METATRAITS_LOOKUP_INDEX.jsonl"]),
        (T1_ARCHIVE_TAR, T1_ROOTNAME, ["GPU_FORMAL_ENTRY_RESULTS.jsonl"])):
    dest = verify_root / rootname
    if dest.exists():
        shutil.rmtree(str(dest))
    info = C.safe_extract(tar, verify_root)
    for rel in relfiles:
        fresh = verify_root / rootname / rel
        if not fresh.exists():
            hits = sorted(p for p in verify_root.rglob(Path(rel).name) if p.is_file())
            fresh = hits[0] if hits else fresh
        cached = CACHE / rootname / rel
        if not fresh.exists():
            members = [m["member"] for m in info["members"] if m["member"].endswith(rel)]
            fresh = (verify_root / members[0]) if members else fresh
        fb = (fresh.stat().st_size if fresh.exists() else None)
        fs = (sha_of(fresh) if fresh.exists() else "")
        cb = (cached.stat().st_size if cached.exists() else None)
        cs = (sha_of(cached) if cached.exists() else "")
        same = bool(fs) and fs == cs and fb == cb
        say("  %s/%s fresh=%s cache=%s -> %s" % (rootname[:18], rel[:28], fs[:12], cs[:12],
                                                 "IDENTICAL" if same else "DIFFERENT"))
        if not same:
            mismatch.append({"archive": str(tar), "relative": rel,
                             "fresh_bytes": fb, "fresh_sha": fs,
                             "cache_bytes": cb, "cache_sha": cs})

# the fixture assertion the frozen test makes about the T1 output
uids = set()
with open(str(T1_GPU_TMP), encoding="utf-8") as fh:
    for line in fh:
        rec = json.loads(line)
        for r in rec["wrapper"].get("ranked_enzymes", []):
            uids.add(r["uid"])
say("  T1 ranked enzyme UIDs present: %d (frozen fixture asserts 17)" % len(uids))

# ──────────────────────────────────────────────────────────────────────────────────────────
# 2. frozen G-SCHEMA copies used by the tests
# ──────────────────────────────────────────────────────────────────────────────────────────
say("== 2. frozen G-SCHEMA trees")
GS_SHA = "4d313d06bf95718a54c79e002989445f554f730a9157a1385a620ddaccf34797"
GS_DIRS = {
    "gs_t5b_r1": Path("/tmp/enzymecage_three_module_t5b_r1_gschema_asset_identity_frozen_patch_"
                      "validation_correction_20260905/gs/"
                      "G_SCHEMA_THREE_MODULE_EVIDENCE_CHAIN_V0_1_2026-09-05"),
    "gs_t5b_r2": Path("/tmp/enzymecage_three_module_t5b_r2_host_evidence_source_enum_final_"
                      "closure_20260906/gs/G_SCHEMA_THREE_MODULE_EVIDENCE_CHAIN_V0_1_2026-09-05"),
    "gs_t6r3ar1": Path("/tmp/t6r3ar1_gschema_Z0FGnC/G_SCHEMA_THREE_MODULE_EVIDENCE_CHAIN_"
                       "V0_1_2026-09-05"),
    "gs_r3a_r2a_workdir": (WS / "enzymecage_three_module_t6_r3a_r2a_microbe_node_output_uid_map_"
                           "fallback_host_signature_correction_20260909/frozen_inputs/gschema"),
}
gs_report = {}
for label, d in GS_DIRS.items():
    target = d.resolve() if d.is_symlink() else d
    hits = sorted(target.rglob("THREE_MODULE_EVIDENCE_CHAIN_SCHEMA.json")) if target.is_dir() else []
    entry = {"requested": str(d), "resolved": str(target), "is_symlink": d.is_symlink(),
             "is_dir": target.is_dir(), "schema_files": [], "valid_example": []}
    for h in hits:
        entry["schema_files"].append({"path": str(h), "bytes": h.stat().st_size,
                                      "sha256": sha_of(h),
                                      "match_pinned": sha_of(h) == GS_SHA})
    for v in sorted(target.rglob("VALID_EXAMPLE.json")) if target.is_dir() else []:
        entry["valid_example"].append({"path": str(v), "bytes": v.stat().st_size,
                                       "sha256": sha_of(v)})
    gs_report[label] = entry
    n_ok = sum(1 for s in entry["schema_files"] if s["match_pinned"])
    say("  %-18s dirs=%s schema_files=%d pinned_match=%d symlink=%s" % (
        label, entry["is_dir"], len(entry["schema_files"]), n_ok, entry["is_symlink"]))
    ROWS.append({"label": "gschema_%s" % label, "path": str(d), "expected_bytes": "",
                 "expected_sha256": GS_SHA, "exists": entry["is_dir"],
                 "regular": False, "symlink": entry["is_symlink"], "bytes": "dir",
                 "sha256": ",".join(s["sha256"] for s in entry["schema_files"]),
                 "status": "PASS" if n_ok else ("NO_PINNED_SCHEMA" if hits else "MISSING"),
                 "note": "directory tree; judged on THREE_MODULE_EVIDENCE_CHAIN_SCHEMA.json"})

# ──────────────────────────────────────────────────────────────────────────────────────────
# 3. frozen UniProt raw responses (no network is allowed, these bytes are the transport)
# ──────────────────────────────────────────────────────────────────────────────────────────
say("== 3. frozen UniProt raw bytes")
RAW_SHAS = {"Q7X2D3": "3f9e0d84b760cee75c3a9cadb19d911ae0f6e187ed1f62fa694fcc9863df6121",
            "A0A075BSX9": "b2f36ac98ed3c80b22b25f210f7ff59f189eb7d28c9d7be72b030d7e8a2a407f",
            "A0A017SP50": "63813f5f079261d76363de89cc29c5c2188aef26ba239a9ab5d9a5252d0d6288",
            "A0A011QK89": "d43c34a83cc59df5d972d87888856663e43e95a5c432cc91625194fde32f5cce"}
RAW_DIRS = [WS / ("enzymecage_three_module_t6_r3a_r2a_microbe_node_output_uid_map_fallback_host_"
                 "signature_correction_20260909/frozen_raw"),
            RETURN_ROOT / ("enzymecage_three_module_t6_r3a_r1_uniprot_host_provenance_runtime_"
                           "wiring_delivery_correction_20260909/uniprot_raw")]
raw_ok = {}
for i, d in enumerate(RAW_DIRS):
    per = {}
    for uid, want in RAW_SHAS.items():
        f = d / (uid + ".json")
        got = sha_of(f) if f.exists() else ""
        per[uid] = {"path": str(f), "bytes": f.stat().st_size if f.exists() else "",
                    "sha256": got, "status": "PASS" if got == want else "MISMATCH_OR_MISSING"}
        if got == want:
            per[uid]["regular"] = f.is_file() and not f.is_symlink()
    raw_ok[str(d)] = per
    n_ok = sum(1 for v in per.values() if v["status"] == "PASS")
    say("  dir%d usable=%d/4  %s" % (i, n_ok, d))
    ROWS.append({"label": "uniprot_raw_dir%d" % i, "path": str(d), "expected_bytes": "",
                 "expected_sha256": "", "exists": d.is_dir(), "regular": False,
                 "symlink": False, "bytes": "dir", "sha256": "",
                 "status": "PASS" if n_ok == 4 else ("PARTIAL_%d" % n_ok if n_ok else "MISSING"),
                 "note": "four frozen response bytes pinned by tests/_t6r3ar2a_support.py"})

# ──────────────────────────────────────────────────────────────────────────────────────────
# 4. the depending v3.2 runtime: staged copy inside WORK_ROOT, verified file by file
# ──────────────────────────────────────────────────────────────────────────────────────────
say("== 4. depending v3.2 runtime staging for TEST-01")
V32_SRC = Path("/usrdata/EnzymeCAGE_data/workspaces/"
               "enzymecage_three_module_t2b_r3_real_cycle_access_audit_cache_recovery_external_"
               "validation_closure_20260907/staged_repo")
ENTRY_SHA = "4b1eb113413da5031a6bcd06908cbeb0190f5d8ab37746c022acd1218c219939"
V32_DEST = C.RUNTIME_ASSETS / "t2_v32"
staging = []
entry_seen = ""
if V32_DEST.exists():
    shutil.rmtree(str(V32_DEST))
src_files = sorted(p for p in V32_SRC.rglob("*")
                   if p.is_file() and not p.is_symlink()
                   and "__pycache__" not in p.parts and ".git" not in p.parts)
t0 = time.monotonic()
for p in src_files:
    rel = p.relative_to(V32_SRC)
    dst = V32_DEST / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(str(p), str(dst))
    hs = hashlib.sha256(p.read_bytes()).hexdigest()
    hd = sha_of(dst)
    staging.append({"relative": str(rel).replace(os.sep, "/"), "bytes": p.stat().st_size,
                    "source_sha256": hs, "staged_sha256": hd,
                    "identical": hs == hd})
    if str(rel).replace(os.sep, "/") == "reaction_analogy/single_smiles_v32.py":
        entry_seen = hd
copy_s = round(time.monotonic() - t0, 2)
n_bad = [s for s in staging if not s["identical"]]
say("  staged %d regular files from %s in %.2fs; byte-identical=%d mismatches=%d" % (
    len(staging), V32_SRC.name, copy_s, len(staging) - len(n_bad), len(n_bad)))
say("  entry reaction_analogy/single_smiles_v32.py sha=%s expected=%s -> %s" % (
    entry_seen[:16], ENTRY_SHA[:16], "PASS" if entry_seen == ENTRY_SHA else "MISMATCH"))

# the eight runtime assets the frozen entrypoint gates on internally
ASSETS = {
    "reaction_analogy/templates.json": (11217167, "65a5ad25cbd0cb49eb860205456544f0da8579da13a18278f992e4118d1ce5b8"),
    "reaction_v3/data/lib_envipath/templates.tsv.gz": (31059, "19ac04ca4d6c516f7dce0f7536959847bec91ba81a68384c58551ead18ebe4f1"),
    "data/hfix/templates_implicitH.jsonl": (138383, "3c3db55c385cfbe6d0553f155edec2189bf92247d314baf2fad97afdf5fb1948"),
    "reaction_analogy/data/corpus_v1/corpus_v1.jsonl": (47818894, "20cbe34d3d2bf921fdc82d211986da5e36a864186d2ec1dfc65b9140814e858f"),
    "reaction_analogy/data/corpus_v1/donor_index.jsonl": (13734527, "0a2c894681db19708d7b0f91e67471c2cdb103a7a58593798cbe020e55b37110"),
    "data/bbd_v31/uspto_ranker.txt": (1263228, "e493fc031f217e18543d27081168ff6851414f8f080622cf3dd54bc9484e0944"),
    "data/bbd_v31/envipath_ranker.txt": (645960, "e0920695c9d8e2609c64da18975d39275b8be581a5657b0cf45ed8da264141c1"),
    "data/bbd_v31/retrieval_ranker.txt": (659831, "bdcb575e9685d47dbfa83b96f71dd05e326dc21cb7f4c0b224b1fffb49c65f65"),
}
asset_rows = []
for rel, (eb, es) in ASSETS.items():
    f = V32_DEST / rel
    got = sha_of(f) if f.exists() else ""
    st = ("PASS" if got == es else ("MISSING" if not f.exists() else "MISMATCH"))
    asset_rows.append({"relative": rel, "expected_bytes": eb, "expected_sha256": es,
                       "bytes": f.stat().st_size if f.exists() else "", "sha256": got,
                       "regular_non_symlink": f.is_file() and not f.is_symlink(),
                       "status": st})
    say("  asset %-52s %s" % (rel[:52], st))
    ROWS.append({"label": "v32_runtime_asset", "path": str(f), "expected_bytes": eb,
                 "expected_sha256": es, "exists": f.exists(),
                 "regular": f.is_file() and not f.is_symlink(), "symlink": f.is_symlink(),
                 "bytes": f.stat().st_size if f.exists() else "", "sha256": got,
                 "status": st, "note": "ASSET_IDENTITY_GATE of the frozen v3.2 entrypoint"})

# ──────────────────────────────────────────────────────────────────────────────────────────
# 5. the frozen test tree itself (the 8 groups of §6.1) must be the patched teacher sources
# ──────────────────────────────────────────────────────────────────────────────────────────
say("== 5. frozen test tree identity (STAGED_REPO/tests)")
GROUPS = [
    ("G1_prer3_16", "tests/run_t6r3a_tests.py"),
    ("G2_prer3r1_50", "tests/run_t6r3ar1_tests.py"),
    ("G3_g2_4", "tests/test_t6r3a_g2_unique_predicted_reaction.py"),
    ("G4_g5_7", "tests/test_t6r3a_g5_pair_contract.py"),
    ("G5_c8_32", "tests/test_c8_trait_adapter.py"),
    ("G6_route_42", "tests/test_route_step_organism_aggregator.py"),
    ("G7_trait_6", "tests/test_trait_filter_node_c8.py"),
    ("G8_v32_adapter", "src/tools/depending_v32_adapter.py"),
]
group_rows = []
for label, rel in GROUPS:
    f = C.STAGED_REPO / rel
    s = sha_of(f) if f.exists() else ""
    # identity against BASE_COMMIT: compare the git blob SHA-1 of the base version with the
    # working file, which is byte exact and independent of any text decoding
    rc, out, _ = C.run(["git", "rev-parse", "%s:%s" % (C.BASE_COMMIT, rel)],
                       cwd=C.STAGED_REPO, note="§6.1 base blob oid for %s" % rel)
    base_oid = out.strip() if rc == 0 else ""
    rc2, out2, _ = C.run(["git", "hash-object", rel], cwd=C.STAGED_REPO,
                         note="§6.1 working blob oid for %s" % rel)
    work_oid = out2.strip() if rc2 == 0 else ""
    from_patch = bool(s) and bool(base_oid) and work_oid != base_oid
    group_rows.append({"group": label, "path": rel,
                       "bytes": f.stat().st_size if f.exists() else "",
                       "sha256": s, "git_blob_sha1_at_base_commit": base_oid,
                       "git_blob_sha1_working": work_oid,
                       "comes_from_frozen_source_patch": from_patch})
    say("  %-16s %-52s sha=%s %s" % (label, rel[:52], s[:12],
                                     "from SOURCE_PATCH" if from_patch else "teacher base"))

# ──────────────────────────────────────────────────────────────────────────────────────────
# verdict
# ──────────────────────────────────────────────────────────────────────────────────────────
hard_fail = []
for r in ROWS:
    if r["status"] not in ("PASS", "DIR", "ABSENT_OPTIONAL"):
        hard_fail.append(r)
if mismatch:
    hard_fail.append({"label": "tmp_cache_vs_archive", "status": "DIFFERENT", **mismatch[0]})
if n_bad:
    hard_fail.append({"label": "v32_staging", "status": "MISMATCH", "count": len(n_bad)})
if entry_seen != ENTRY_SHA:
    hard_fail.append({"label": "v32_entrypoint_identity", "status": "MISMATCH",
                      "observed": entry_seen, "expected": ENTRY_SHA})
if any(a["status"] != "PASS" for a in asset_rows):
    hard_fail.append({"label": "v32_asset_gate", "status": "NOT_ALL_PASS"})
usable_raw = sum(1 for d, per in raw_ok.items()
                 if all(v["status"] == "PASS" for v in per.values()))
gs_ok = sum(1 for e in gs_report.values()
            if any(s["match_pinned"] for s in e["schema_files"]))

status = "PASS" if not hard_fail else "FAIL"
gate = {
    "section": "6.1 preflight: fixed input identity for the 157 named CPU regression checks",
    "utc": C.now_utc(),
    "pinned_interpreter": C.PY,
    "status": status,
    "uid_map": [r for r in ROWS if r["label"] == "uid_map_reviewed_frozen"][0],
    "c8_lookup_index_pinned_sha": C.C8_LOOKUP_SHA,
    "tmp_cache_matches_canonical_archive": not mismatch,
    "tmp_cache_mismatches": mismatch,
    "t1_unique_ranked_uids": len(uids),
    "t1_frozen_fixture_asserts": 17,
    "gschema": {"usable_trees_with_pinned_schema": gs_ok, "trees_checked": len(gs_report),
                "pinned_schema_sha256": GS_SHA, "detail": gs_report},
    "uniprot_raw": {"fully_verified_dirs": usable_raw, "detail": raw_ok},
    "v32_runtime": {
        "source_readonly_tree": str(V32_SRC),
        "staged_copy": str(V32_DEST),
        "files_staged": len(staging),
        "files_byte_identical": len(staging) - len(n_bad),
        "entrypoint_relative": "reaction_analogy/single_smiles_v32.py",
        "entrypoint_expected_sha256": ENTRY_SHA,
        "entrypoint_observed_sha256": entry_seen,
        "asset_gate": asset_rows,
        "copy_seconds": copy_s,
        "writes_stay_inside_work_root": str(V32_DEST).startswith(str(C.WORK_ROOT)),
    },
    "test_groups": group_rows,
    "hard_failures": hard_fail,
    "disclosure": {
        "test01_lineage": (
            "TEST-01 is executed through the teacher production entrypoint "
            "src/tools/depending_v32_adapter.py against the v3.2 runtime whose entrypoint "
            "sha256 is 4b1eb113... (the T2B-R3 lineage also used by the first round). The "
            "older T2B test file test_t2b_single_smiles.py is deliberately not used as the "
            "production callable here."),
        "runtime_root_choice": (
            "DEPENDING_V32_RUNTIME_ROOT points at a WORK_ROOT copy so that any cache the "
            "runtime writes stays inside this task's workspace."),
    },
}
(RC_DIR / "CPU_REGRESSION_INPUT_GATE.json").write_text(
    json.dumps(gate, indent=2, ensure_ascii=False), encoding="utf-8")
with open(str(RC_DIR / "CPU_TEST_INPUT_IDENTITIES.csv"), "w", newline="", encoding="utf-8") as fh:
    keys = ["label", "path", "exists", "regular", "symlink", "bytes", "expected_bytes",
            "sha256", "expected_sha256", "status", "note"]
    w = csv.DictWriter(fh, fieldnames=keys, extrasaction="ignore")
    w.writeheader()
    for r in ROWS:
        w.writerow(r)
with open(str(RC_DIR / "V32_RUNTIME_STAGING.csv"), "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=["relative", "bytes", "source_sha256", "staged_sha256",
                                       "identical"])
    w.writeheader()
    for s in staging:
        w.writerow(s)
say("== verdict: CPU_REGRESSION_INPUTS=%s (%d rows, %d hard failures)" % (
    status.upper(), len(ROWS), len(hard_fail)))
(C.RETURN_DIR / "CPU_REGRESSION_INPUT_STDOUT.txt").write_text("\n".join(say_lines) + "\n",
                                                              encoding="utf-8")
C.self_audit(__file__, 0 if status == "PASS" else 3, "§6.1 input intake")
sys.exit(0 if status == "PASS" else 3)
