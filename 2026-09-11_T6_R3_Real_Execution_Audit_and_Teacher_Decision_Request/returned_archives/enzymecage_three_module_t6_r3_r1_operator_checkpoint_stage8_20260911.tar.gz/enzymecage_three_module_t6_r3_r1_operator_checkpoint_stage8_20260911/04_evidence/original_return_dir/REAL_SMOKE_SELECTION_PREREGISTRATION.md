# Real Smoke Selection Pre-registration (T6-R3-R1 §8 stage A)

run_utc: 2026-09-11T04:34:16Z
pinned interpreter: `/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python`
observer: `p14b_prereg_observer.py` sha256=a885683290a600f9bde411d9be43a34465027ddc922a1a69831031290c85260e, 3 fresh-process runs (total wall 39.7s), last exit=0
determinism control: `PYTHONHASHSEED=0` is exported in the *subprocess* environment (CPython reads it only at interpreter start). Reason, found in the frozen teacher source and NOT changed here: `build_pool_route_b` calls `ec_uid_mapper.query(list(all_ec))` on a ``set`` and `build_pool_route_c` returns `list(uids)` of a ``set``, so the enzyme-pool ORDER drifts between processes while the pool SET stays identical. This was observed first-hand: two earlier attempts of this stage (no seed) produced the same 14/17 UID sets in different orders, and the S1/S2 choices moved - which is why the freeze below is repeated three times under the control and compared. Reproducible: True. Any §8 run that consumes these pools must carry the same control, and the determinism gate must report it explicitly.
teacher graph: `/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910/depending_teacher_fixed_r1/src/graph.py` compiled once with real `langgraph.graph.StateGraph` (12 nodes); CUDA_VISIBLE_DEVICES=""; torch imported: False
UID map sha: 7b92e8e625cb73f070c8e902687ea5bbdbf749f04a19828e550e3fe205684fe6 (bytes=104025134)
C8 lookup sha: d51a540db2f9798d65e25b46f22960ba29ae2d4b288be218c83c299f24f5d5af (bytes=57211793); porTraits NOT enabled
§7 forward evidence: `T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl` sha256=01f22baf362ff323f4617e1a4abe4b46150773e4afc1bc945c1eb876667972ae; scores csv sha256=e132065939077388594367532d0f992186fbe163a5055ffb894992b3b8e69815

## Rules (fixed before any full-chain observation)
- S1: CASE_B real pool, pool order = production build_enzyme_pool order (sorted EC iteration + dict.fromkeys dedup); take the highest-rank UID with >=1 OBSERVED trait among F1-F15 from the production C8TraitAdapter; if none, take rank 1 and record the observed-coverage block
- S2: CASE_C real pool, same production pool order; take the highest-rank UID with >=1 MISSING trait among F1-F15 from the production C8TraitAdapter; if none, take rank 1 and record the reason
- S3-S8: contract §5 frozen UID order ['A0A011QK89', 'A0A017SP50', 'A0A017SR40'] intersected with the UIDs really forwarded in the §7 record for that staged reaction, first two; preselection_rank = that UID's real EnzymeCAGE rank inside the §7 base ranking
- CASE_B_PRIMARY_SUCCESS / CASE_C_FALLBACK_SUCCESS are **contract scenario labels**: the teacher tree contains no such identifiers (verified by grep over the frozen source); the labels are bound to real graph runs as follows, and nothing was hand-typed to make them fit.

## Real runs the selection was made from
| label | substrate (source) | executed nodes | route | pool |
|---|---|---|---|---|
| CASE_B_PRIMARY_SUCCESS | `CN1CCC[C@H]1c1ccc(O)nc1` read from `cases/case_1_realrun.json:expected.substrate.smiles` | orchestrator>substrate>reaction>enzyme_pool | B | 14 |
| CASE_C_FALLBACK_SUCCESS | `CCCCCCCCCC=O` (first eligible entry of the §6 probe battery, eligibility = real production route C with pool>=1, tie-break largest pool, then shortest then lexicographic SMILES) | orchestrator>substrate>reaction>enzyme_pool | C | 17 |

C battery as really observed (all 8 frozen candidates, none hidden):
- `CCCC(C)N` route=C pool=2 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `C[C@@H]1Cc2c3c(cc(O)c2C(=O)O1)O[C@@]1(C)CC[C@H]2C(C)(C)C(=O)CC[C@]2(C)[C@@H]1C3` route=C pool=8 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCC/C=C\CCCCCCCC(=O)OC[C@H](CO)OC(=O)CCCCCCC/C=C\CCCCCCCC` route=C pool=8 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCCCC=O` route=C pool=17 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCCCCCCC/C=C/[C@@H](O)[C@H](CO)NC(=O)CCCCC` route=C pool=7 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCCCCCCC/C=C/[C@@H](O)[C@H](CO)NC(=O)CCCCCCCCCCCCCCC` route=C pool=4 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCC/C=C\CCCCCCCC(=O)OC[C@H](CO)OC(=O)CCCCCCC/C=C\CCCCCCCC` route=C pool=8 nodes=orchestrator>substrate>reaction>enzyme_pool error=
- `CCCCCCCC/C=C\CCCCCCCC(=O)OC[C@@H](O)COP(=O)(O)O` route=C pool=17 nodes=orchestrator>substrate>reaction>enzyme_pool error=

## Selections (real pools, real production C8TraitAdapter)
B pool order: `["A0A075BSX9", "Q933N0", "Q88FY2", "F8G0P2", "O87681", "O87682", "P08159", "A0A0H3LKL4", "P86491", "Q88FY1", "Q59127", "Q93NH5", "Q59128", "Q93NH4"]`
C pool order: `["O06413", "A0R618", "Q04458", "P9WQ55", "Q88JH0", "P69451", "Q79FC3", "A0A0L8M630", "O05307", "O33855", "P9WIN5", "P39518", "P9WQ51", "P76217", "Q88JH5", "C5BK10", "Q6F7B8"]`
S1 selected UID = A0A075BSX9 (pool rank 1, OBSERVED traits=12 ['F1', 'F2', 'F3', 'F4', 'F6', 'F7', 'F9', 'F10', 'F11', 'F12', 'F13', 'F14'])
S2 selected UID = O06413 (pool rank 1, MISSING traits=4)
Authority-UID-map mapping status of the two selected UIDs (reported, not hidden): S1 not_mapped=False (source_signature=taxon:879274|organism:shinella sp. (strain hzn7), uid_map_rows=1); S2 not_mapped=False (source_signature=proteome:UP000001584, uid_map_rows=1) - an unmapped UID yields fifteen MISSING slots through `_unresolved_annotation`, which does satisfy the S2 rule but is reported as weak trait coverage rather than dressed up as observed evidence.
S1 fallback_to_rank1=False ; S2 fallback_to_rank1=False
Trait probe carrier: `PROBE_CARRIER_NOT_FINAL_HOST` - the real host evidence for the final chain must come from the real microbe node output in §8 stage B; nothing here may be reused as a host claim.

## S3-S8 source rows (§7 real forward, frozen UID order)
- `RT-1a7bea59ede1acf0` `c1ccc2[nH]nnc2c1>>Nc1ccccc1C(=O)[O-]` sha256(prod)=1652ac57f073c02b… evidence_hash=756d513638ef1ec9… real ranks=[['A0A017SP50', 1], ['A0A011QK89', 2]]
- `RT-f00e98d322e2380e` `Nc1ccccc1C(=O)[O-]>>Oc1ccccc1O` sha256(prod)=33504ceadd0a929b… evidence_hash=22fb0c754354029c… real ranks=[['A0A017SP50', 1], ['A0A011QK89', 2]]
- `RT-bbb9dc4b010674c1` `Nc1ccccc1C(=O)[O-]>>C=C(OC1C=C(C(=O)[O-])C=CC1O)C(=O)[O-]` sha256(prod)=149ab7c3474ddd1b… evidence_hash=2bedebd4ce17624c… real ranks=[['A0A017SP50', 1], ['A0A011QK89', 2]]

## §5 minimum coverage table as early as this stage
- database_lookup (enviPath known-route) -> False (no such node/adapter/condition exists in the teacher fixed topology; see LOOKUP_THEN_PREDICTION_ORDER=NOT_ESTABLISHED in ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json)
- controlled_prediction (enviPath-gated fallback) -> False (reachable only behind a lookup that does not exist; the graph's own reaction_prediction node is driven by route_after_reaction's pipeline_mode/candidate_reactions test)
- proxy (T3A frozen proxy) -> None (decided in §8 stage B / TEST-06)
- staged generated reaction -> True (S3—S8 from the three §7 RT-* staged forward records)
- UNMATCHED / fail-closed enzyme -> None (C1 / TEST-09 in §8 stage B)
- MISSING trait -> True (production C8TraitAdapter MISSING classes above)
- OBSERVED trait -> True (S1 selection under rule 1; if false the observed-coverage gate stays blocked)

## Honesty constraints
- No substrate, UID, rank, route or hash was typed by hand; every value in `REAL_SMOKE_INPUTS.csv` points at a file, a real run, or a production return value.
- `wrapper_model_version` / `forward_evidence_hash` stay explicit `NOT_OBSERVED_AT_PREREGISTRATION` placeholders for S1/S2 until §8-B really runs the wrapper; they are never guessed forward.
- Samples cannot be switched after the final output: the eight selection hashes above are frozen here, and §8-B/§8-C must reference these record ids verbatim.
- `preselection_rank` for S1/S2 is the **pool rank** produced by `build_enzyme_pool`; if the §8-B real EnzymeCAGE ranking puts these UIDs elsewhere, the record is kept and both orders are reported - the sample is never swapped.
- enviPath known-route lookup is NOT part of the teacher fixed topology (`LOOKUP_THEN_PREDICTION_ORDER=NOT_ESTABLISHED`, ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json); because contract §5 counts "database lookup" and "controlled prediction" in the minimum coverage table, this gap also blocks any final READY claim here, independently of this gate's own verdict.
- Teacher topology, nodes, routers and edges were only imported and executed, never edited: `TOPOLOGY_BYTES_EQUAL_4_3_RECORD=YES`.

