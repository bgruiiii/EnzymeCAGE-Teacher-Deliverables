# T6-R3-R1 现在真正做到哪一步（白话版）

**一句话**：操作员在 §8-B（真实 LangGraph 整链）还没启动任何进程时叫停。
§4—§7 的科学结果真实完成并有 gate 文件；§8 只完成了 enviPath 只读门（结论=合同缺口）
和 §8-A 的 8 条输入预注册；§8-B 只有写好的脚本，零执行。

## 已经真实通过
1. 环境/解释器（§4 E0-E0b）：**PASS**
2. 统一 graph 运行时（§4.3）：**PASS**（第 4 次尝试才 PASS，前三次是驱动自身 bug）
3. 老师基座/patch/拓扑（§5）：**PASS**，base commit `2d4cc766322a6a01b8a88491aed07536b3b0a320`
4. 157 项 CPU 回归（§6.1）：**PASS**（named_checks_expected=157；从日志逐 test 解析=157；G1—G7 去重标识=141）
5. 固定资产身份（§6.2）：**PASS**
6. native load + 逐 UID ESM（§6.3）：**PASS**
7. §7 三 GPU 6 条 forward：**PASS_6_OF_6** —— 3 个 worker 各 3 条（1 基座 + 2 重复），
   墙钟、runtime_init、UUID 核对见 `GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv`；
   分数不是逐字节可复现，最大偏差在 REPEAT_TOLERANCE=1e-05 内；
   逐条 UID/seed/score 见 `FORWARD_PER_REACTION_UID_SEED_SCORES.csv`。

## §8 的真实边界（重点）
- enviPath 只读附加门：**NOT_ESTABLISHED**（5 次 attempt 后定稿）。原因是老师固定拓扑内没有
  enviPath lookup 节点；MISS 分支无数据库可查；v3.2 prediction 由下游酶池节点直接调用。
  这是**合同缺口**，按裁定未改拓扑、未把 depending retrieval 冒充 enviPath、未伪写 T6 完整通过。
- §8-A：**8 条 smoke 输入已冻结**（REAL_SMOKE_INPUTS.csv，8×21 字段，问题数 0）。
- §8-B：**0 次执行**。compile/invoke/stream/8 条实跑/C1-C4/C8→T5/TEST-01—20/G-SCHEMA/
  mutation/determinism/access/pre-post 全部 NOT_RUN。
  存在的只有 3 个未部署的子进程脚本（p15_shared/p15b_chain_base/p15c_chain_staged）
  和一次 0.17 秒纯 CPU 的老师拓扑只读探针；驱动 p15_real_langgraph_chain.py 未写，
  v1 基座包未建，**没有任何 GPU/模型/图进程被 §8 启动**。

## 当前有没有命令还在跑
见 `PROCESS_SNAPSHOT_AT_STOP.csv`：任务相关进程 2 个（只有 jupyter-lab 常驻），
GPU compute-apps 0 个。未发 SIGINT/SIGTERM，未中断任何写入。

## 为什么停
用户即时裁定：执行器在 §8-B 前置核对耗时过长，立即停止并只交检查点。
停止类型 = INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT，**不是科学 FAIL**。

## 可直接复用 vs 必须续跑
- 复用（禁止重做）：E0、§4.3、§5 身份/patch/拓扑、§6.1、§6.2、§6.3、§7 全部结果与
  UID 池映射、§8-A 冻结输入、enviPath 结论。
- 必须真实续跑：§8-B 全部、TEST-01—20、G-SCHEMA、mutation、determinism、access audit、
  persistent pre/post、§10—§14。
