# “80 个变更文件”的实物对账

本检查点不猜测数字，只列出磁盘上实际存在的两个不同总体；两表都已逐文件分类。

| 口径 | 实物来源 | 数量 | 对应分类表 |
|---|---|---|---|
| A. 仓库变更集（git tracked + untracked） | `git status --porcelain` 于 `/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910/depending_teacher_fixed_r1` | **36** | `CHANGED_FILE_CLASSIFICATION.csv` |
| A′. 冻结 source patch 触达的文件 | `"+++ b/"` 行于 `tmp/SOURCE_PATCH_R1_REGENERATED.diff` | **36** | 同上 |
| A″. 本轮已登记的变更清单 | `/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries/enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910/CHANGED_FILES_R1.csv` 数据行 | **36** | 同上 |
| B. 返回目录交付物（本轮产出的全部文件） | `find /usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries/enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910 -type f` | **80**（顶层条目 60） | `RETURN_DIR_DELIVERABLE_CLASSIFICATION.csv` |
| C. task-local 脚本（工作区） | `/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910/scripts` | **25** | 04_evidence/task_local_scripts_deployed/ |
| D. task-local 脚本（开发暂存，含从未执行的 §8-B） | `/root/projects/EnzymeCAGE-master/t6r3r1_tmp` | **30** | 04_evidence/staging_scripts_never_executed/ |

结论（事实，不外推）：

1. 口径 A/A′/A″ 相互一致，均为 **36** 个仓库变更文件（其中老师固定拓扑 4 个仅记 pre/post SHA，未改）。
2. 磁盘上**不存在**一个由 80 个文件组成的单一仓库变更集；**80** 与口径 B（返回目录全部文件数）一致。
3. 因此本包同时提供两视图分类，避免把 “证据交付物” 误当 “科学代码变更” 或反之。
4. 以上数字均在封口时从实物重算；任何未覆盖的口径写 `UNKNOWN_NOT_YET_AUDITED`。
