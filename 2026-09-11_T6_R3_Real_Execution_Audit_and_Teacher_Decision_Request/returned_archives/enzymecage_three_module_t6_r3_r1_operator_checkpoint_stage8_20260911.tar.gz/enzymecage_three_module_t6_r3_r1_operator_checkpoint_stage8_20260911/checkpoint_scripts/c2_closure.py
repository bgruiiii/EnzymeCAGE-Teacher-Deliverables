#!/usr/bin/env python3
"""T6-R3-R1 checkpoint closure: mechanical validation, manifest, archive,
fresh-unpack verification, identity file, validation file, read-only recheck.

Order is fixed by the operator directive §8:
  all checkpoint files -> FINAL_STATUS (already written by c1) -> manifest ->
  archive -> fresh unpack check -> identity -> validation -> read-only recheck.
Nothing here re-runs any scientific command.
"""
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
from datetime import datetime, timezone

CKPT_TASK = "enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911"
ORIG_TASK = ("enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_"
             "20_test_final_20260910")
WS_ROOT = "/usrdata/EnzymeCAGE_data/workspaces"
RR_ROOT = ("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/"
           "HPC_Returned_Result_Summaries")
W = "%s/%s" % (WS_ROOT, ORIG_TASK)
RD = "%s/%s" % (RR_ROOT, ORIG_TASK)
S = "%s/depending_teacher_fixed_r1" % W
CD = "%s/%s" % (RR_ROOT, CKPT_TASK)
CW = "%s/%s" % (WS_ROOT, CKPT_TASK)
ARCHIVE = "%s/%s.tar.gz" % (RR_ROOT, CKPT_TASK)
IDENTITY = ARCHIVE + ".identity.txt"
VALIDATION = ARCHIVE + ".validation.txt"
UNPACK = "%s/unpack_u1" % CW
TEACHER_TOPOLOGY = ["src/graph.py", "src/state.py",
                    "src/nodes/multi_step_bridge_node.py", "src/schemas/bridge.py"]
MAX_FILE = 50 * 1024 * 1024
BAN_EXT = (".pkl", ".pt", ".ckpt", ".pth", ".npz", ".npy", ".h5", ".onnx", ".tar",
           ".tar.gz", ".tgz", ".zip", ".7z", ".so", ".whl", ".env")
BAN_NAME = ("venv", "site-packages", "id_rsa", ".ssh", "credential", "runtime_assets",
            "enzymecage_v1_20260714", "HPC_Inputs")
CRED_PATTERNS = [
    re.compile(r"(?i)\b(api[_-]?key|secret[_-]?key|access[_-]?key|auth[_-]?token|"
               r"api[_-]?token|client[_-]?secret|password|passwd)\b\s*[=:]\s*['\"]?"
               r"[A-Za-z0-9/+._-]{8,}"),
    re.compile(r"\bsk-[A-Za-z0-9]{20,}"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bLTAI[0-9A-Za-z]{12,}\b"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._-]{25,}"),
    re.compile(r"://[^\s/:@]{4,}:[^\s/@]{4,}@"),
]
TEXT_EXT = (".json", ".jsonl", ".csv", ".txt", ".md", ".py", ".log", ".diff", ".patch",
            ".tsv", ".yaml", ".yml", ".out", ".tab")
UTC = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
DRY = os.environ.get("CKPT_DRY") == "1"
DAY = datetime.now(timezone.utc).strftime("%Y-%m-%d")
problems = []


def sha_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def files_in(root):
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        for name in filenames:
            p = os.path.join(dirpath, name)
            if os.path.islink(p):
                out.append((os.path.relpath(p, root), "SYMLINK"))
            elif not os.path.isfile(p):
                out.append((os.path.relpath(p, root), "NOT_REGULAR"))
            else:
                out.append((os.path.relpath(p, root), "REGULAR"))
    return sorted(out)


# ---- step 0: the closure scripts themselves become part of the package -------
os.makedirs("%s/checkpoint_scripts" % CD, exist_ok=True)
for script in ("c1_collect.py", "c2_closure.py"):
    src = "%s/scripts/%s" % (CW, script)
    if os.path.isfile(src):
        shutil.copy2(src, "%s/checkpoint_scripts/%s" % (CD, script))

regular = [(r, k) for r, k in files_in(CD)]
reg = [r for r, k in regular if k == "REGULAR"]

# ---- check 1: safety / size / banned content ---------------------------------
if len(regular) != len(reg):
    problems.append("non-regular or symlink members: %s" % [x for x in regular if x[1] != "REGULAR"])
oversized = [[r, os.path.getsize(os.path.join(CD, r))] for r in reg
             if os.path.getsize(os.path.join(CD, r)) > MAX_FILE]
if oversized:
    problems.append("oversized files: %s" % oversized)
banned = [r for r in reg if r.lower().endswith(BAN_EXT) or any(b in r.lower() for b in BAN_NAME)]
if banned:
    problems.append("banned asset/venv/input paths: %s" % banned)
total_bytes = sum(os.path.getsize(os.path.join(CD, r)) for r in reg)

cred_hits = []
for r in reg:
    if not r.lower().endswith(TEXT_EXT):
        continue
    p = os.path.join(CD, r)
    if os.path.getsize(p) > 20 * 1024 * 1024:
        continue
    try:
        with open(p, encoding="utf-8", errors="ignore") as fh:
            body = fh.read()
    except OSError:
        continue
    for pat in CRED_PATTERNS:
        for m in pat.finditer(body):
            cred_hits.append([r, pat.pattern[:24], m.group(0)[:24] + "...(masked)"])
if cred_hits:
    problems.append("credential-pattern matches: %d" % len(cred_hits))

binary_like = [r for r in reg if not r.lower().endswith(TEXT_EXT)]

# ---- check 2: every path referenced by CURRENT_PROGRESS is present or listed --
progress = json.load(open("%s/CURRENT_PROGRESS.json" % CD, encoding="utf-8"))
missing_declared = set()
with open("%s/MISSING_EXPECTED_EVIDENCE.csv" % CD, encoding="utf-8") as fh:
    for row in csv.DictReader(fh):
        missing_declared.add(row["requested"])
unresolved = []
declared_unresolved = []
declared_blob = json.dumps(sorted(missing_declared), ensure_ascii=False)
for stage in progress["stages"]:
    for ev in stage["evidence_sha256"]:
        path = ev["path"]
        if ev["sha256"] == "NOT_RESOLVED_AT_CHECKPOINT_TIME":
            base = os.path.basename(path)
            if base in declared_blob or str(stage["status"]).startswith(
                    ("NOT_RUN", "UNKNOWN", "PARTIAL", "NONE")):
                declared_unresolved.append([stage["stage_id"], base])
            else:
                unresolved.append([stage["stage_id"], "UNDECLARED_MISSING:" + path])
        else:
            full = path if os.path.isabs(path) else os.path.join(CD, path)
            if not os.path.isfile(full):
                unresolved.append([stage["stage_id"], "MISSING_ON_DISK:" + path])
            elif os.path.isfile(full) and not ev["path"].startswith("/") and \
                    sha_file(full) != ev["sha256"]:
                unresolved.append([stage["stage_id"], "SHA_DRIFT:" + path])
if unresolved:
    problems.append("CURRENT_PROGRESS references unresolved: %s" % unresolved[:8])

# ---- check 3: FINAL_STATUS carries no false PASS -----------------------------
fs_text = open("%s/FINAL_STATUS.txt" % CD, encoding="utf-8").read()
fs_lines = [l for l in fs_text.splitlines() if l]
checks = {"first_line_fixed": fs_lines[0] ==
          "T6_R3_R1_CHECKPOINT_INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT",
          "t6_ready_false": "T6_FINAL_READY=false" in fs_lines,
          "g7_false": "G7_PASSED=false" in fs_lines,
          "not_final": "NOT_A_FINAL_T6_DELIVERY=true" in fs_lines}
for line in fs_lines:
    key = line.split("=")[0]
    if key in ("REAL_LANGGRAPH_COMPILE", "REAL_LANGGRAPH_INVOKE",
               "REAL_LANGGRAPH_STREAM_TO_TERMINAL", "TEST_01_TO_20",
               "C8_TO_T5_REAL_CONTINUOUS_REGRESSION", "GSCHEMA", "MUTATION",
               "REAL_SMOKE_RECORDS") and "PASS" in line:
        checks["no_false_pass_" + key] = False
if not all(checks.values()):
    problems.append("FINAL_STATUS check failed: %s" % {k: v for k, v in checks.items() if not v})

# ---- check 4: teacher topology still unchanged -------------------------------
topo = list(csv.DictReader(open("%s/05_changed/TEACHER_TOPOLOGY_PRE_POST_SHA.csv" % CD,
                                encoding="utf-8")))
topo_ok = len(topo) == 4 and all(r["verdict"] == "UNCHANGED" for r in topo)
for r in topo:
    live = os.path.join(S, r["path"])
    if not os.path.isfile(live) or sha_file(live) != r["post_sha256_at_stop"]:
        topo_ok = False
        problems.append("teacher topology drifted after collection: %s" % r["path"])

# ---- check 5: copies still byte-match their current originals ----------------
mismatch = []
checked = 0
with open("%s/EVIDENCE_COPY_REPORT.csv" % CD, encoding="utf-8") as fh:
    for row in csv.DictReader(fh):
        if row["action"] != "COPIED":
            continue
        checked += 1
        if not os.path.isfile(row["source_path"]):
            mismatch.append([row["source_path"], "SOURCE_GONE"])
        elif sha_file(row["source_path"]) != row["dst_sha256"]:
            mismatch.append([row["source_path"], "SHA_DIFFERS_FROM_RECORDED"])
        if os.path.isfile(row["checkpoint_path"]) and \
                sha_file(row["checkpoint_path"]) != row["dst_sha256"]:
            mismatch.append([row["checkpoint_path"], "PACKAGED_COPY_DRIFTED"])
if mismatch:
    problems.append("copy integrity failures: %s" % mismatch[:8])

mech_name = "CHECKPOINT_MECHANICAL_VALIDATION.json"
# On a cold checkpoint dir the three files this closure writes do not exist yet, so the
# packaged set is defined as: what is on disk now UNION what this closure is guaranteed
# to write before the archive is created.  Hashing / counting / identity all use exactly
# this set, so `regular_files` cannot lag behind the archive content.
pre_set = set(r for r, k in files_in(CD) if k == "REGULAR")
names = sorted(pre_set | {"MANIFEST.files", "MANIFEST.sha256", mech_name})
mech = {"run_utc": UTC, "checkpoint_dir": CD,
        "regular_files": len(names),
        "regular_files_definition": "union of files on disk at closure time and the three "
        "files this closure writes before `tar` (MANIFEST.files, MANIFEST.sha256, "
        "CHECKPOINT_MECHANICAL_VALIDATION.json); the safety scans below ran over the "
        "on-disk set at closure time (%d files)" % len(pre_set),
        "total_bytes_at_closure_time": total_bytes,
        "largest_file_bytes": max([os.path.getsize(os.path.join(CD, r)) for r in reg]),
        "oversized_over_50MiB": oversized, "banned_asset_or_venv_paths": banned,
        "non_text_like_members": binary_like,
        "credential_pattern_hits": cred_hits,
        "current_progress_unresolved_references": unresolved,
        "current_progress_references_declared_missing": declared_unresolved,
        "final_status_checks": checks, "teacher_topology_unchanged": topo_ok,
        "copy_integrity_events_checked": checked, "copy_integrity_failures": mismatch,
        "problems": problems,
        "MECHANICAL_PACKAGE_VALIDATION": "PASS" if not problems else "FAIL",
        "MECHANICAL_PACKAGE_VALIDATION_scope": "checks 1-5 only (references, FINAL_STATUS "
        "honesty, teacher topology, copy integrity, secrets/size), evaluated before the "
        "manifest exists; manifest coverage, archive safety and identity consistency are "
        "reported in <archive>.validation.txt",
        "SCIENTIFIC_REPLAY": "NOT_RUN_PER_OPERATOR_STOP"}
with open("%s/%s" % (CD, mech_name), "w", encoding="utf-8") as fh:
    json.dump(mech, fh, indent=2, sort_keys=True)
    fh.write("\n")
if problems:
    print("MECHANICAL_PROBLEMS=" + json.dumps(problems, default=str)[:4000])

# ---- manifest: written over `names`, so it also covers both manifests ---------
with open("%s/MANIFEST.files" % CD, "w", encoding="utf-8") as fh:
    for r in names:
        fh.write(r + "\n")
with open("%s/MANIFEST.sha256" % CD, "w", encoding="utf-8") as fh:
    for r in names:
        if r == "MANIFEST.sha256":
            continue
        fh.write("%s  %s\n" % (sha_file(os.path.join(CD, r)), r))
chk = subprocess.run(["sha256sum", "-c", "--quiet", "MANIFEST.sha256"], cwd=CD,
                     capture_output=True, text=True)
manifest_ok = chk.returncode == 0
listed = set(open("%s/MANIFEST.files" % CD, encoding="utf-8").read().split())
ondisk = set(r for r, k in files_in(CD) if k == "REGULAR")
coverage_ok = listed == ondisk and "MANIFEST.files" in listed and "MANIFEST.sha256" in listed
set_equal_ok = set(names) == ondisk
hashlines = sum(1 for _ in open("%s/MANIFEST.sha256" % CD, encoding="utf-8"))
if not manifest_ok:
    problems.append("sha256sum -c failed: %s" % chk.stdout[-400:])
if not coverage_ok:
    problems.append("MANIFEST.files does not cover the package: %s" %
                    (sorted(ondisk ^ listed)[:8]))
if not set_equal_ok:
    problems.append("closure wrote an unexpected file: %s" % sorted(ondisk ^ set(names))[:8])
reg = sorted(ondisk)
total_bytes = sum(os.path.getsize(os.path.join(CD, r)) for r in reg)

if DRY:
    print("DRY_RUN_CHECKPOINT_DIR=%s files=%d problems=%d" % (CD, len(reg), len(problems)))
    print("DRY_PROBLEMS=" + json.dumps(problems, default=str)[:3000])
    print("DRY_unresolved=%s declared_missing=%d cred_hits=%d banned=%s oversized=%s "
          "binary_like=%s"
          % (json.dumps(unresolved)[:1200], len(declared_unresolved), len(cred_hits),
             banned[:4], oversized[:2], binary_like[:8]))
    sys.exit(0)

# ---- archive + fresh unpack verification ------------------------------------
if os.path.exists(ARCHIVE):
    print("BLOCKED_ARCHIVE_ALREADY_EXISTS")
    sys.exit(3)
tar = subprocess.run(["tar", "-czf", ARCHIVE, "-C", RR_ROOT, CKPT_TASK],
                     capture_output=True, text=True)
if tar.returncode != 0 or not os.path.isfile(ARCHIVE):
    print("ARCHIVE_CREATION_FAILED " + tar.stderr[-400:])
    sys.exit(4)
arch_bytes = os.path.getsize(ARCHIVE)
arch_sha = sha_file(ARCHIVE)

if os.path.isdir(UNPACK):
    shutil.rmtree(UNPACK)
os.makedirs(UNPACK, exist_ok=True)
members = []
unsafe = []
with tarfile.open(ARCHIVE, "r:gz") as tf:
    for m in tf.getmembers():
        members.append(m)
        if m.islnk() or m.issym() or m.isdev():
            unsafe.append(["NOT_REGULAR_OR_LINK", m.name])
        if m.name.startswith("/") or ".." in m.name.split("/"):
            unsafe.append(["ABSOLUTE_OR_PARENT_PATH", m.name])
    tf.extractall(UNPACK, filter="data")
roots = sorted({m.name.split("/")[0] for m in members})
unpacked = [r for r, k in files_in(os.path.join(UNPACK, CKPT_TASK))] if \
    os.path.isdir(os.path.join(UNPACK, CKPT_TASK)) else []
unpack_sha_fail = []
for r in unpacked:
    full = os.path.join(UNPACK, CKPT_TASK, r)
    src = os.path.join(CD, r)
    if not os.path.isfile(src) or sha_file(full) != sha_file(src):
        unpack_sha_fail.append(r)
archive_ok = (len(unsafe) == 0 and roots == [CKPT_TASK] and len(unpacked) == len(reg)
              and not unpack_sha_fail)

# ---- identity file -----------------------------------------------------------
id_lines = [
    "filename=%s.tar.gz" % CKPT_TASK,
    "bytes=%d" % arch_bytes,
    "sha256=%s" % arch_sha,
    "archive_format=tar.gz",
    "single_root=%s/" % CKPT_TASK,
    "regular_files=%d" % len(reg),
    "generated_date=%s" % DAY,
    "generated_utc=%s" % UTC,
    "task_id=%s" % CKPT_TASK,
    "original_task_id=%s" % ORIG_TASK,
    "package_kind=CHECKPOINT_ONLY_NOT_FINAL_T6_DELIVERY",
    "created_by=scripts/c2_closure.py, executed as a SEPARATE process by %s; the archive "
    "is `tar -czf` of the whole CHECKPOINT_DIR (whose every regular file is enumerated in "
    "MANIFEST.files); gzip mtime is not normalised, so archive bytes are not reproducible "
    "by design; the sha256 below is of the delivered archive" % sys.executable,
    "",
    "members:",
]
for r in sorted(reg):
    id_lines.append("%s bytes=%d sha256=%s" % (r, os.path.getsize(os.path.join(CD, r)),
                                               sha_file(os.path.join(CD, r))))
with open(IDENTITY, "w", encoding="utf-8") as fh:
    fh.write("\n".join(id_lines) + "\n")

# ---- validation file ---------------------------------------------------------
v_ok = (manifest_ok and coverage_ok and archive_ok and not problems)
val = [
    "T6_R3_R1_OPERATOR_CHECKPOINT_INDEPENDENT_MECHANICAL_VALIDATION",
    "run_utc: %s" % UTC,
    "task: %s" % CKPT_TASK,
    "original_task: %s" % ORIG_TASK,
    "archive: %s" % ARCHIVE,
    "archive_bytes: %d" % arch_bytes,
    "archive_sha256: %s" % arch_sha,
    "validator: %s/scripts/c2_closure.py executed as a SEPARATE process by %s"
    % (CW, sys.executable),
    "validator_unpacked_to: %s" % UNPACK,
    "",
    "CHECKPOINT_PACKAGE_VALIDATION=%s" % ("PASS" if v_ok else "FAIL"),
    "SCIENTIFIC_REPLAY=NOT_RUN_PER_OPERATOR_STOP",
    "T6_FINAL_READY=false",
    "G7_PASSED=false",
    "NOT_A_FINAL_T6_DELIVERY=true",
    "",
    "checks (each re-derived from bytes on disk, not from reported booleans):",
    "  [%s] package_files_come_from_current_originals: %d COPIED rows re-hashed at "
    "closure, failures=%d" % ("PASS" if not mismatch else "FAIL",
                              mech["copy_integrity_events_checked"], len(mismatch)),
    "  [%s] manifest_sha256_recomputed: sha256sum -c rc=%d, hash lines=%d, files=%d "
    "(MANIFEST.sha256 self-excluded), MANIFEST.files covers every regular file "
    "including both manifests=%s"
    % ("PASS" if (manifest_ok and coverage_ok) else "FAIL", chk.returncode, hashlines,
       len(reg), coverage_ok),
    "  [%s] archive_safe_single_root: members=%d, unsafe=%s, roots=%s, unpacked files=%d, "
    "unpack sha failures=%d"
    % ("PASS" if archive_ok else "FAIL", len(members), unsafe[:4], roots, len(unpacked),
       len(unpack_sha_fail)),
    "  [%s] current_progress_references_resolve_or_are_declared_missing: "
    "hard_unresolved=%s declared_missing=%d"
    % ("PASS" if not unresolved else "FAIL", unresolved[:6], len(declared_unresolved)),
    "  [%s] final_status_has_no_false_pass: %s"
    % ("PASS" if all(checks.values()) else "FAIL", checks),
    "  [%s] teacher_topology_pre_post_sha_unchanged: 4 files=%s (%s)"
    % ("PASS" if topo_ok else "FAIL", topo_ok,
       ", ".join("%s=%s" % (r["path"].split("/")[-1], r["verdict"]) for r in topo)),
    "  [%s] no_credential_no_large_asset_no_model_no_checkpoint_no_venv: "
    "credential hits=%d, banned paths=%s, oversized=%s, total_bytes=%d, largest=%d"
    % ("PASS" if (not cred_hits and not banned and not oversized) else "FAIL",
       len(cred_hits), banned[:4], oversized[:2], total_bytes,
       mech["largest_file_bytes"]),
    "",
    "scope and limits:",
    "  * this validates the CHECKPOINT PACKAGE only: manifest integrity, that packaged",
    "    files still byte-match the originals, archive safety, absence of secrets and",
    "    of large assets, and that FINAL_STATUS makes no false claim.",
    "  * it is NOT the T6 final closure (§10/§13 of the original prompt) and NOT a",
    "    validator of the T6-R3-R1 scientific gates; no E0 preflight, no 157-test",
    "    regression, no asset re-hash, no native load, no GPU forward, no LangGraph",
    "    run, no mutation, no model load was executed by this checkpoint.",
    "  * scientific results for §4-§7 and the §8 enviPath / §8-A artifacts are carried",
    "    verbatim from the original task's return directory; their own gate files and",
    "    SHAs are inside original_return_dir/ and were not re-derived here.",
    "  * the interruption is classified as INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT,",
    "    not as a scientific FAIL; no process was signalled or killed at stop",
    "    (0 task processes, 0 GPU compute apps - see 06_timing/PROCESS_SNAPSHOT_AT_STOP.csv).",
    "  * problem count=%d" % len(problems),
    "",
    "FINAL_VALIDATION=%s" % ("CHECKPOINT_PACKAGE_VALIDATION_PASS" if v_ok else "FAIL"),
]
with open(VALIDATION, "w", encoding="utf-8") as fh:
    fh.write("\n".join(val) + "\n")

# ---- read-only recheck of the three external files ---------------------------
recheck = {"identity_exists": os.path.isfile(IDENTITY), "validation_exists": os.path.isfile(VALIDATION),
           "identity_archive_bytes_matches_recomputed":
               ("bytes=%d" % os.path.getsize(ARCHIVE)) in open(IDENTITY, encoding="utf-8").read(),
           "identity_archive_sha_matches_recomputed":
               ("sha256=%s" % sha_file(ARCHIVE)) in open(IDENTITY, encoding="utf-8").read(),
           "validation_declares_checkpoint_only":
               "NOT_A_FINAL_T6_DELIVERY=true" in open(VALIDATION, encoding="utf-8").read(),
           "validation_declares_no_replay":
               "SCIENTIFIC_REPLAY=NOT_RUN_PER_OPERATOR_STOP" in open(VALIDATION,
                                                                     encoding="utf-8").read(),
           "archive_unchanged_after_validation": arch_sha == sha_file(ARCHIVE)}
with open("%s/CHECKPOINT_THREE_FILE_RECHECK.json" % CW, "w", encoding="utf-8") as fh:
    json.dump({"run_utc": UTC, "recheck": recheck,
               "all_pass": all(recheck.values())}, fh, indent=2, sort_keys=True)
    fh.write("\n")

fs = open("%s/FINAL_STATUS.txt" % CD, encoding="utf-8").read()


def shown(key):
    for line in fs.splitlines():
        if line.startswith(key + "="):
            return line.split("=", 1)[1]
    return "ABSENT"


# Extra diagnostics go to stderr only; directive §9 requires stdout to be exactly 11 lines.
print("MECH_VALIDATION=%s PROBLEM_COUNT=%d THREE_FILE_RECHECK_ALL_PASS=%s "
      "ARCHIVE_UNCHANGED_AFTER_VALIDATION=%s"
      % (mech["MECHANICAL_PACKAGE_VALIDATION"], len(problems), all(recheck.values()),
         recheck["archive_unchanged_after_validation"]), file=sys.stderr)
print("CHECKPOINT_ARCHIVE=%s bytes=%d SHA256=%s" % (ARCHIVE, arch_bytes, arch_sha))
print("CHECKPOINT_IDENTITY=%s bytes=%d SHA256=%s"
      % (IDENTITY, os.path.getsize(IDENTITY), sha_file(IDENTITY)))
print("CHECKPOINT_VALIDATION=%s bytes=%d SHA256=%s"
      % (VALIDATION, os.path.getsize(VALIDATION), sha_file(VALIDATION)))
print("LAST_COMPLETED_STAGE=%s" % shown("LAST_COMPLETED_STAGE"))
print("CURRENT_OR_INTERRUPTED_STAGE=%s" % shown("CURRENT_OR_INTERRUPTED_STAGE"))
print("T3B_FORWARD=%s" % shown("T3B_BOUNDED_FORWARD"))
print("REAL_LANGGRAPH=%s/%s/%s" % (shown("REAL_LANGGRAPH_COMPILE"),
                                   shown("REAL_LANGGRAPH_INVOKE"),
                                   shown("REAL_LANGGRAPH_STREAM_TO_TERMINAL")))
print("TEST_01_TO_20=%s" % shown("TEST_01_TO_20"))
wa = json.load(open("%s/06_timing/WALL_TIME_ACCOUNTING.json" % CD, encoding="utf-8"))
print("SAFE_TO_RESUME_WITHOUT_REPEATING_E0_E7=%s"
      % str(json.load(open("%s/RESUME_READINESS.json" % CD,
                           encoding="utf-8"))["safe_to_resume_without_repeating_E0_E7"]).lower())
print("UNEXPLAINED_WALL_TIME_SECONDS=%d" % wa["dead_seconds_over_600s"])
print("FINAL_STATUS=%s" % fs.splitlines()[0])
