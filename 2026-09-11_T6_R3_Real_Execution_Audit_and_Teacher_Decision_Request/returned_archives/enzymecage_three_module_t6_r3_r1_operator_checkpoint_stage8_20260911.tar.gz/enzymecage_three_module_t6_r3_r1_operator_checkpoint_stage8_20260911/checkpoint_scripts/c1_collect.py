#!/usr/bin/env python3
"""T6-R3-R1 operator checkpoint collector.

Read-only against the original run (WORK_ROOT / RETURN_DIR / staged repo).
Writes only inside CHECKPOINT_WORK and CHECKPOINT_DIR.
No scientific command is executed here: no env preflight rerun, no 157 tests,
no large-asset hashing, no native load, no GPU forward, no LangGraph, no
mutation.  Only mechanical copy, identity capture and timing recovery from
existing logs.
"""
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
from datetime import datetime, timezone

ORIG_TASK = ("enzymecage_three_module_t6_r3_r1_pinned_python_forward_"
             "real_langgraph_20_test_final_20260910")
CKPT_TASK = "enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911"
WS_ROOT = "/usrdata/EnzymeCAGE_data/workspaces"
RR_ROOT = ("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/"
           "HPC_Returned_Result_Summaries")
W = "%s/%s" % (WS_ROOT, ORIG_TASK)
RD = "%s/%s" % (RR_ROOT, ORIG_TASK)
S = "%s/depending_teacher_fixed_r1" % W
LOGS = "%s/logs" % W
RUNTIME_TMP = "%s/tmp" % W
DEV_TMP = "/root/projects/EnzymeCAGE-master/t6r3r1_tmp"
CW = "%s/%s" % (WS_ROOT, CKPT_TASK)
CD = "%s/%s" % (RR_ROOT, CKPT_TASK)
DOC_DIR = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/docs"
DIRECTIVE = "%s/T6_R3_R1_OPERATOR_STOP_AND_STAGE8_CHECKPOINT_RETURN_NOW_DIRECTIVE_" \
            "2026-09-11.md" % DOC_DIR
PROMPT = "%s/HPC_ENZYMECAGE_THREE_MODULE_T6_R3_R1_PINNED_PYTHON_FORWARD_REAL_LANGGRAPH_" \
         "20_TEST_FINAL_EXECUTOR_ONLY_PROMPT_2026-09-10.md" % DOC_DIR
MAXCOPY = 50 * 1024 * 1024
TEACHER_TOPOLOGY = ["src/graph.py", "src/state.py",
                    "src/nodes/multi_step_bridge_node.py", "src/schemas/bridge.py"]
SKIP_PARTS = ("__pycache__", ".pyc")
CRED_RE = re.compile(r"(?i)\b([A-Z0-9_]*(?:KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)[A-Z0-9_]*)"
                     r"([=:\s]+)([^\s,;]+)")
NOW_UTC = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
NOW_DT = datetime.strptime(NOW_UTC, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
copy_rows = []
missing_rows = []


def sha_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_text(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except Exception:
        return ""


def load_json(path):
    try:
        return json.loads(read_text(path))
    except Exception:
        return None


def redact(text):
    return CRED_RE.sub(lambda m: m.group(1) + m.group(2) + "<REDACTED>", str(text))


def write_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def write_json(path, obj):
    write_text(path, json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n")


def write_csv(path, header, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        cw = csv.writer(fh)
        cw.writerow(header)
        for row in rows:
            cw.writerow(row)


def iter_files(root):
    if not os.path.isdir(root):
        return
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d != "__pycache__")
        for name in sorted(filenames):
            yield os.path.join(dirpath, name)


CDG = lambda name: "%s/04_evidence/original_return_dir/%s" % (CD, name)


def tokens(*paths):
    """All GATE-LIKE=VALUE tokens found in the given files (authoritative wording)."""
    out = []
    for p in paths:
        for m in re.finditer(r"\b[A-Z][A-Z0-9_]{3,}=[A-Za-z0-9_./+-]{2,60}", read_text(p)):
            if m.group(0) not in out:
                out.append(m.group(0))
    return out


def find_token(needle, *paths):
    for t in tokens(*paths):
        if needle.lower() in t.lower():
            return t
    return ""


def gs(needle, *paths):
    """Gate value for a stage: prefer the literal TOKEN=VALUE written by the real
    gate file / stdout, else fall back to the JSON verdict/status field."""
    t = find_token(needle, *paths)
    if t:
        return t
    for p in paths:
        d = load_json(p)
        if not isinstance(d, dict):
            continue
        for k in ("verdict", "status", "gate", "result"):
            if k in d:
                v = d[k]
                if isinstance(v, dict):
                    return "%s=%s" % (needle.upper(), ";".join(
                        "%s=%s" % (a, b) for a, b in sorted(v.items())
                        if not isinstance(b, (dict, list))))
                if not isinstance(v, (dict, list)):
                    return "%s=%s" % (needle.upper(), v)
    return "UNKNOWN_NOT_YET_AUDITED"


def field(path, *keys):
    d = load_json(path)
    if isinstance(d, dict):
        for k in keys:
            if k in d and not isinstance(d[k], (dict, list)):
                return d[k]
    return "?"


def exists(path):
    return os.path.exists(path)


def copy_in(src, dstdir, tag):
    if not os.path.isfile(src):
        return None
    size = os.path.getsize(src)
    if any(p in src for p in SKIP_PARTS) or os.path.basename(src).startswith(("c1_", "c2_")):
        copy_rows.append([src, "", "SKIPPED_CACHE_OR_CHECKPOINT_SELF", size, "", "", tag])
        return None
    if size > MAXCOPY:
        copy_rows.append([src, "", "SKIPPED_OVER_50MIB", size, "", "", tag])
        return None
    os.makedirs(dstdir, exist_ok=True)
    dst = os.path.join(dstdir, os.path.basename(src))
    shutil.copy2(src, dst)
    copy_rows.append([src, dst, "COPIED", size, sha_file(src), sha_file(dst), tag])
    return dst


def copy_tree(srcroot, dstdir, tag):
    for f in iter_files(srcroot):
        rel = os.path.relpath(f, srcroot)
        size = os.path.getsize(f)
        if any(p in rel for p in SKIP_PARTS) or rel.startswith(("c1_", "c2_")):
            copy_rows.append([f, "", "SKIPPED_CACHE_OR_CHECKPOINT_SELF", size, "", "", tag])
            continue
        if size > MAXCOPY:
            copy_rows.append([f, "", "SKIPPED_OVER_50MIB", size, "", "", tag])
            continue
        dst = os.path.join(dstdir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(f, dst)
        copy_rows.append([f, dst, "COPIED", size, sha_file(f), sha_file(dst), tag])


for p in (CW, CD):
    os.makedirs(p, exist_ok=True)

# ------------------------------------------------- directive / prompt identity
GIVEN = ("/home/a/EnzymeCAGE/custom/docs/enzyme_feature_expansion/"
         "ENZYMECAGE_LUCAPCYCLE_MODEL_TRAINING_RUN_2026-07-01/07_HPC_Prompts/"
         "T6_R3_R1_OPERATOR_STOP_AND_STAGE8_CHECKPOINT_RETURN_NOW_DIRECTIVE_2026-09-11.md")
directive_info = {
    "directive_path_as_given_by_user": GIVEN,
    "given_path_exists_on_this_host": exists(GIVEN),
    "given_home_a_exists": exists("/home/a"),
    "directive_path_actually_read": DIRECTIVE,
    "directive_bytes": os.path.getsize(DIRECTIVE),
    "directive_sha256": sha_file(DIRECTIVE),
    "directive_lines": len(read_text(DIRECTIVE).splitlines()),
    "directive_found_by_filename_search_copies": 1,
    "original_prompt_path": PROMPT,
    "original_prompt_bytes": os.path.getsize(PROMPT),
    "original_prompt_sha256": sha_file(PROMPT),
    "checkpoint_utc": NOW_UTC,
    "sections_actually_present_in_directive": sorted(
        set(re.findall(r"^## \d+\.", read_text(DIRECTIVE), re.M))),
}
write_json("%s/00_directive/DIRECTIVE_READ_PROOF.json" % CD, directive_info)

ps_out = subprocess.run(["ps", "-eo", "pid,etime,user,args", "--no-headers"],
                        capture_output=True, text=True).stdout
gpu_out = subprocess.run(["nvidia-smi", "--query-compute-apps=pid,used_memory,gpu_uuid",
                          "--format=csv,noheader"], capture_output=True, text=True).stdout
task_procs = [l for l in ps_out.splitlines()
              if re.search(r"run_gpu_worker|p1[0-9]_|p[0-9]_[a-z]|langgraph|enzymecage", l, re.I)
              and "ps -eo" not in l]
proc_rows = [["task_matching_process_count", len(task_procs), "", ""],
             ["gpu_compute_app_count_at_stop", len([l for l in gpu_out.splitlines() if l.strip()]),
              "", ""],
             ["checkpoint_collector_pid", os.getpid(), "", ""],
             ["interrupt_signal_sent", "NONE(SIGINT/SIGTERM not needed: no task process running)",
              "", ""]]
for l in task_procs:
    proc_rows.append(["process_line", l.strip()[:300], "", ""])
for l in gpu_out.splitlines():
    proc_rows.append(["gpu_compute_app", l.strip()[:200], "", ""])
write_csv("%s/06_timing/PROCESS_SNAPSHOT_AT_STOP.csv" % CD,
          ["kind", "value", "unused1", "unused2"], proc_rows)

# ------------------------------------------------------- §4 evidence inventory
EVIDENCE_MANIFEST = [
    ("PYTHON_RUNTIME_PREFLIGHT.json", ["PYTHON_RUNTIME_PREFLIGHT.json"]),
    ("PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv", ["PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv"]),
    ("ENTRYPOINT_IMPORT_IDENTITIES.csv", ["ENTRYPOINT_IMPORT_IDENTITIES.csv"]),
    ("OPTIONAL_DEPENDENCY_REFERENCE_AUDIT.json", ["LIGHTGBM_REFERENCE_AUDIT.json",
                                                  "OPTIONAL_DEPENDENCY_REFERENCE_AUDIT.json"]),
    ("UNIFIED_GRAPH_RUNTIME_GATE.json", ["UNIFIED_GRAPH_RUNTIME_GATE.json"]),
    ("PYTHON_COMMAND_AUDIT.csv", ["command_log.jsonl", "PYTHON_COMMAND_AUDIT.csv"]),
    ("TEACHER_FIXED_TOPOLOGY_IDENTITY.json", ["TEACHER_FIXED_TOPOLOGY_IDENTITY.json"]),
    ("SOURCE_PATCH.diff", ["SOURCE_PATCH_R1_REGENERATED.diff", "SOURCE_PATCH.diff"]),
    ("T6_INCREMENTAL_PATCH.diff", ["T6_INCREMENTAL_PATCH.diff"]),
    ("CHANGED_FILES.csv", ["CHANGED_FILES_R1.csv", "CHANGED_FILES.csv"]),
    ("COMPONENT_TESTS_GATE.json", ["COMPONENT_TESTS_GATE.json"]),
    ("COMPONENT_TEST_GROUP_RUNS.csv", ["COMPONENT_TEST_GROUP_RUNS.csv"]),
    ("COMPONENT_TEST_LOG_INDEX.csv", ["COMPONENT_TEST_LOG_INDEX.csv"]),
    ("PREFREEZE component regression logs", ["COMPONENT_TESTS_STDOUT.txt"]),
    ("FIXED_ASSET_IDENTITY_GATE.json", ["FIXED_ASSET_IDENTITY_GATE.json"]),
    ("fixed asset hash ledger", ["CORRECTED_UID_AND_PROTEIN_ASSET_IDENTITIES.csv",
                                 "ASSET_SHA_DISCOVERY_SCAN.csv", "INPUT_IDENTITIES.csv",
                                 "CPU_RUNTIME_ASSET_IDENTITIES.csv"]),
    ("UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json",
     ["UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json"]),
    ("NATIVE_LOAD_PER_ROW_TENSORS.csv", ["NATIVE_LOAD_PER_ROW_TENSORS.csv"]),
    ("native load raw log + adoption/supersedes", ["p11_native_evidence.json"]),
    ("GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv", ["GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv"]),
    ("T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl", ["T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl"]),
    ("worker result/base/repeat/sequence gate/stdout/stderr", ["worker_result.json"]),
    ("original run_gpu_worker.py", ["run_gpu_worker.py"]),
    ("derived worker + diff", ["run_gpu_worker_t6r3r1.py", "WORKER_DERIVATION_DIFF.txt"]),
    ("GRAPH_TOPOLOGY.json", ["GRAPH_TOPOLOGY.json"]),
    ("GRAPH_CALLABLE_IDENTITIES.csv", ["GRAPH_CALLABLE_IDENTITIES.csv"]),
    ("REAL_LANGGRAPH_INVOKE_TRACE.jsonl", ["REAL_LANGGRAPH_INVOKE_TRACE.jsonl"]),
    ("REAL_LANGGRAPH_STREAM_TRACE.jsonl", ["REAL_LANGGRAPH_STREAM_TRACE.jsonl"]),
    ("NODE_STATE_TRANSITIONS.jsonl", ["NODE_STATE_TRANSITIONS.jsonl"]),
    ("REAL_SMOKE_INPUTS.csv", ["REAL_SMOKE_INPUTS.csv"]),
    ("REAL_SMOKE_OUTPUTS.jsonl", ["REAL_SMOKE_OUTPUTS.jsonl"]),
    ("TEST_CASE_MATRIX.csv", ["TEST_CASE_MATRIX.csv"]),
    ("TEST_RESULTS.txt", ["TEST_RESULTS.txt"]),
    ("C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json", ["C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json"]),
    ("SCHEMA_VALIDATION_REPORT.json", ["SCHEMA_VALIDATION_REPORT.json"]),
    ("DETERMINISTIC_ORDER_CHECK.json", ["DETERMINISTIC_ORDER_CHECK.json"]),
    ("MUTATION_CHECK.json", ["MUTATION_CHECK.json"]),
    ("ACCESS_AUDIT.jsonl", ["ACCESS_AUDIT.jsonl"]),
    ("PERSISTENT_SOURCE_NONMUTATION.json", ["PERSISTENT_SOURCE_NONMUTATION.json"]),
    ("EVIDENCE_CHAIN_OUTPUTS.jsonl", ["EVIDENCE_CHAIN_OUTPUTS.jsonl"]),
    ("ENVIPATH 4 files", ["ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json", "ENVIPATH_LOOKUP_CALLS.csv",
                          "PREDICTION_FALLBACK_CALLS.csv", "LOOKUP_PREDICTION_SOURCE_SEPARATION.json"]),
    ("§8-A preregistration evidence", ["REAL_SMOKE_PREREG_EVIDENCE.json",
                                       "REAL_SMOKE_SELECTION_PREREGISTRATION.md",
                                       "REAL_SMOKE_REAL_POOL_RUNS.csv"]),
    ("ESM2_650M_IDENTITY_GATE.json", ["ESM2_650M_IDENTITY_GATE.json"]),
    ("NATIVE_LOAD_FIXED_T3B_R1_GATE.json", ["NATIVE_LOAD_FIXED_T3B_R1_GATE.json"]),
    ("wrapper predictor preflight", ["ENZYMECAGE_WRAPPER_PREDICTOR_PREFLIGHT.json",
                                     "T3B_R1_WRAPPER_PREDICTOR_PREFLIGHT.json"]),
    ("AUTHORITY_AND_SCOPE.md (actual name this round)", ["AUTHORITY_MEMBERSHIP.csv"]),
    ("FAILED_R3_INTEGRITY_VERIFICATION.json (actual name this round)",
     ["FAILED_R3_MANIFEST_VERIFICATION.csv", "R3_BLOCKED_BASELINE_IDENTITY.json"]),
    ("V1_OVERLAY_REBUILD_MANIFEST.json (actual name this round)",
     ["V1_OVERLAY_MANIFEST.csv", "REACTION_OVERLAY_MANIFEST.csv"]),
    ("§6.2 asset identity stdout / §4 env stdout / §6.3 preforward stdout",
     ["FIXED_ASSET_IDENTITY_STDOUT.txt", "ENVIRONMENT_PREFLIGHT_STDOUT.txt",
      "PREFORWARD_GATE_STDOUT.txt", "GPU_FORWARD_GATE_STDOUT.txt",
      "SOURCE_AND_TOPOLOGY_GATE_STDOUT.txt", "LIGHTGBM_GATE_STDOUT.txt"]),
    ("TEACHER_BASE_ACQUISITION.json", ["TEACHER_BASE_ACQUISITION.json"]),
]
THIS_ROUND_ROOTS = [RD, LOGS, RUNTIME_TMP, "%s/scripts" % W, DEV_TMP]
PREV_ROOT = "%s/inputs/failed_r3" % W
found = {}
for req, basenames in EVIDENCE_MANIFEST:
    hit = None
    for base in basenames:
        for root in THIS_ROUND_ROOTS:
            for f in iter_files(root):
                if os.path.basename(f) == base:
                    hit = f
                    break
            if hit:
                break
        if hit:
            break
    if hit:
        found[req] = hit
        continue
    prev = None
    for base in basenames:
        for f in iter_files(PREV_ROOT):
            if os.path.basename(f) == base:
                prev = f
                break
        if prev:
            break
    detail = "searched %s under this round's RETURN_DIR/logs/tmp/scripts only" % basenames
    if prev:
        detail += ("; a same-named file exists in the PREVIOUS failed-R3 package at %s "
                   "and was deliberately NOT adopted as this round's evidence" % prev)
    missing_rows.append([req, "NOT_CREATED_YET", detail])
for req, path in sorted(found.items()):
    copy_in(path, "%s/04_evidence/primary" % CD, "§4_named:%s" % req)

copy_tree(RD, "%s/04_evidence/original_return_dir" % CD, "§4_whole_RETURN_DIR")
copy_tree(LOGS, "%s/04_evidence/original_logs" % CD, "§4_task_logs")
copy_tree("%s/scripts" % W, "%s/04_evidence/task_local_scripts_deployed" % CD,
          "§4_deployed_task_scripts")
copy_tree(RUNTIME_TMP, "%s/04_evidence/work_tmp" % CD, "§4_work_tmp")
copy_tree(DEV_TMP, "%s/04_evidence/staging_scripts_never_executed" % CD,
          "§4_staging_scripts_never_executed")
write_json("%s/04_evidence/EVIDENCE_NAME_RESOLUTION.json" % CD,
           {k: (os.path.relpath(v, CD) if v.startswith(CD) else v) for k, v in found.items()})

# ------------------------------------------------- §5 changed-file boundary
git = {}
for key, args in (("HEAD", ["rev-parse", "HEAD"]), ("TREE", ["rev-parse", "HEAD^{tree}"]),
                  ("BRANCH", ["rev-parse", "--abbrev-ref", "HEAD"])):
    git[key] = subprocess.run(["git", "-C", S] + args, capture_output=True,
                              text=True).stdout.strip()
porc = subprocess.run(["git", "-C", S, "status", "--porcelain"],
                      capture_output=True, text=True).stdout
tracked_diff = subprocess.run(["git", "-C", S, "diff", "--binary"],
                              capture_output=True, text=True).stdout
write_text("%s/05_changed/STAGED_REPO_GIT_IDENTITY.txt" % CD,
           "staged_repo=%s\nbase_commit=%s\nbase_tree=%s\nbranch=%s\n"
           "status_porcelain_lines=%d\ntracked_diff_bytes=%d\ncaptured_utc=%s\n"
           "capture_method=git read-only invocations on the existing staged tree\n"
           % (S, git["HEAD"], git["TREE"], git["BRANCH"], len(porc.splitlines()),
              len(tracked_diff.encode()), NOW_UTC))
write_text("%s/05_changed/STAGED_REPO_STATUS_PORCELAIN.txt" % CD, porc)
write_text("%s/05_changed/STAGED_REPO_TRACKED_DIFF.patch" % CD, tracked_diff)

sp = "%s/tmp/SOURCE_PATCH_R1_REGENERATED.diff" % W
src_patch_files = set(re.findall(r"^\+\+\+ b/(.+)$", read_text(sp), re.M))
patched = set(re.findall(r"^\+\+\+ b/(.+)$", tracked_diff, re.M))
prev_changed = set()
cfr = "%s/CHANGED_FILES_R1.csv" % RD
if os.path.isfile(cfr):
    with open(cfr, encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            prev_changed.add(row.get("path", ""))

untracked_rows, class_rows = [], []
for line in porc.splitlines():
    code, rel = line[:2], line[3:]
    full = os.path.join(S, rel)
    untracked = "??" in code
    size = os.path.getsize(full) if os.path.isfile(full) else -1
    if untracked:
        untracked_rows.append([rel, size, sha_file(full) if size >= 0 else ""])
    if size < 0:
        sha, note = "", "NOT_A_PLAIN_FILE"
    elif size > MAXCOPY:
        sha, note = "", "NOT_REHASHED_CHECKPOINT_OVER_50MIB"
    else:
        sha, note = sha_file(full), ""
    if rel in TEACHER_TOPOLOGY:
        cls = "scientific_source_teacher_fixed_topology"
    elif rel.startswith("tests/"):
        cls = "test"
    elif rel.startswith(("src/", "config/", "models/")):
        cls = "scientific_source"
    else:
        cls = "unknown"
    if rel in src_patch_files:
        intro = "T6_R3_R1_5.3_SOURCE_PATCH_R1_REGENERATED"
    elif rel in prev_changed:
        intro = "carried_in_from_previous_R3_changed_set"
    elif rel in patched:
        intro = "T6_R3_R1_5.3_tracked_diff"
    else:
        intro = "UNKNOWN_NOT_YET_AUDITED"
    class_rows.append([rel, "untracked" if untracked else "tracked", size, sha, cls, intro,
                       "true" if cls.startswith("scientific_source") or cls == "test" else "false",
                       "true" if rel in TEACHER_TOPOLOGY else "false",
                       "true" if rel.startswith(("src/", "config/")) else "false", note])
write_csv("%s/05_changed/STAGED_REPO_UNTRACKED_FILES.csv" % CD,
          ["path", "bytes", "sha256"], untracked_rows)
write_csv("%s/05_changed/CHANGED_FILE_CLASSIFICATION.csv" % CD,
          ["path", "tracked_or_untracked", "bytes", "SHA256", "class", "introduced_stage",
           "required_for_resume", "teacher_topology_file", "production_or_formal_path",
           "hash_note"], class_rows)

pre_map = {}
def collect_topo(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, dict) and k.count("/") and ("staged_sha256" in v
                                                         or "base_sha256" in v):
                pre_map[k] = v.get("staged_sha256") or v.get("base_sha256") \
                    or v.get("first_round_sha256")
            elif isinstance(v, str) and re.fullmatch(r"[0-9a-f]{64}", v) and \
                    os.path.basename(str(k)) in TEACHER_TOPOLOGY:
                pre_map.setdefault(os.path.basename(str(k)), v)
            collect_topo(v)
    elif isinstance(obj, list):
        for v in obj:
            collect_topo(v)
t53 = load_json("%s/TEACHER_FIXED_TOPOLOGY_IDENTITY.json" % RD) or {}
if isinstance(t53.get("topology_files"), dict):
    for rel, info in t53["topology_files"].items():
        if isinstance(info, dict):
            pre_map[rel] = info.get("staged_sha256") or info.get("base_sha256") \
                or info.get("first_round_sha256")
else:
    collect_topo(t53)
topo_rows = []
for rel in TEACHER_TOPOLOGY:
    full = os.path.join(S, rel)
    post = sha_file(full) if os.path.isfile(full) else "MISSING"
    pre = pre_map.get(rel) or pre_map.get(os.path.basename(rel)) or ""
    topo_rows.append([rel, os.path.getsize(full) if os.path.isfile(full) else -1,
                      pre or "NOT_MATCHED_IN_5.3_FILE", post,
                      "UNCHANGED" if pre and pre == post else "CHANGED_OR_PRE_UNMATCHED"])
write_csv("%s/05_changed/TEACHER_TOPOLOGY_PRE_POST_SHA.csv" % CD,
          ["path", "bytes", "pre_sha256_recorded_in_5_3", "post_sha256_at_stop", "verdict"],
          topo_rows)
write_text("%s/05_changed/TEACHER_TOPOLOGY_PRE_POST_SHA.txt" % CD,
           "".join("%s bytes=%s pre=%s post=%s %s\n" % tuple(r) for r in topo_rows))

# ---- §5 supplement: reconcile the two candidate "changed file" populations ------
# The directive asks for the classification of "80 changed files".  On disk there is
# no single 80-file changed set; there are two different populations, and both are
# classified here so the audit does not have to guess which number was meant.
rd_files = sorted(iter_files(RD))


def rd_class(rel):
    base = os.path.basename(rel)
    low = base.lower()
    if rel.startswith("workers/"):
        return "gpu_worker_evidence"
    if low.endswith((".diff", ".patch")):
        return "source_patch"
    if low.endswith((".py",)):
        return "task_driver_or_script"
    if low.endswith((".log", ".err", ".out", ".stdout", ".stderr", ".console")):
        return "log"
    if low.endswith((".json", ".jsonl", ".csv", ".txt", ".md", ".tsv")):
        return "report_or_evidence"
    return "unknown"


rd_rows = []
for f in rd_files:
    rel = os.path.relpath(f, RD)
    size = os.path.getsize(f)
    sha = (sha_file(f) if size <= MAXCOPY
           else "NOT_REHASHED_CHECKPOINT_OVER_50MIB")
    cls = rd_class(rel)
    rd_rows.append([rel, "return_dir_deliverable_not_git_tracked", size, sha, cls,
                    "T6_R3_R1_produced_this_round" if not rel.startswith("depending/")
                    else "UNKNOWN_NOT_YET_AUDITED",
                    "true" if cls in ("source_patch", "gpu_worker_evidence",
                                      "report_or_evidence") else "UNKNOWN_NOT_YET_AUDITED",
                    "false",
                    "false (copied into HPC_Returned_Result_Summaries, not a production "
                    "source path)", ""])
write_csv("%s/05_changed/RETURN_DIR_DELIVERABLE_CLASSIFICATION.csv" % CD,
          ["path", "tracked_or_untracked", "bytes", "SHA256", "class", "introduced_stage",
           "required_for_resume", "teacher_topology_file", "production_or_formal_path",
           "hash_note"], rd_rows)
devas = sorted(os.listdir(DEV_TMP))
dev_scripts = [d for d in devas if d.endswith(".py")]
wrk_scripts = sorted(os.listdir("%s/scripts" % W))
write_text("%s/05_changed/CHANGED_SCOPE_RECONCILIATION.md" % CD, """# “80 个变更文件”的实物对账

本检查点不猜测数字，只列出磁盘上实际存在的两个不同总体；两表都已逐文件分类。

| 口径 | 实物来源 | 数量 | 对应分类表 |
|---|---|---|---|
| A. 仓库变更集（git tracked + untracked） | `git status --porcelain` 于 `%s` | **%d** | `CHANGED_FILE_CLASSIFICATION.csv` |
| A′. 冻结 source patch 触达的文件 | `\"+++ b/\"` 行于 `tmp/SOURCE_PATCH_R1_REGENERATED.diff` | **%d** | 同上 |
| A″. 本轮已登记的变更清单 | `%s/CHANGED_FILES_R1.csv` 数据行 | **%d** | 同上 |
| B. 返回目录交付物（本轮产出的全部文件） | `find %s -type f` | **%d**（顶层条目 %d） | `RETURN_DIR_DELIVERABLE_CLASSIFICATION.csv` |
| C. task-local 脚本（工作区） | `%s/scripts` | **%d** | 04_evidence/task_local_scripts_deployed/ |
| D. task-local 脚本（开发暂存，含从未执行的 §8-B） | `%s` | **%d** | 04_evidence/staging_scripts_never_executed/ |

结论（事实，不外推）：

1. 口径 A/A′/A″ 相互一致，均为 **%d** 个仓库变更文件（其中老师固定拓扑 4 个仅记 pre/post SHA，未改）。
2. 磁盘上**不存在**一个由 80 个文件组成的单一仓库变更集；**%d** 与口径 B（返回目录全部文件数）一致。
3. 因此本包同时提供两视图分类，避免把 “证据交付物” 误当 “科学代码变更” 或反之。
4. 以上数字均在封口时从实物重算；任何未覆盖的口径写 `UNKNOWN_NOT_YET_AUDITED`。
""" % (S, len(class_rows), len(src_patch_files), RD, len(prev_changed), RD, len(rd_rows),
       len(os.listdir(RD)), W, len(wrk_scripts), DEV_TMP, len(dev_scripts),
       len(class_rows), len(rd_rows)))

# ------------------------------------------------------ §6 command timeline
def parse_utc(s):
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except Exception:
        return None


def category(argv, note):
    text = (argv + " " + note).lower()
    if "run_gpu_worker" in text or "forward" in text:
        return "GPU"
    if "sha256" in text or "hash" in text:
        return "HASH"
    if "tar " in text or "unpack" in text or "extract" in text:
        return "PACKAGE"
    if "test" in text or "regression" in text:
        return "TEST"
    if any(k in text for k in ("git ", "ls ", "find ", "ps ", "wc ", "nvidia-smi", "free ")):
        return "IO"
    if "pip" in text or "curl" in text:
        return "NETWORK"
    if argv.endswith(".py") or "python" in text:
        return "CPU"
    return "UNKNOWN"


events = []
cl = [json.loads(l) for l in open("%s/logs/command_log.jsonl" % W, encoding="utf-8") if l.strip()]
for i, r in enumerate(cl, 1):
    argv = " ".join(redact(a) for a in (r.get("argv") or []))
    note = redact(r.get("note") or "")
    start = parse_utc(r.get("utc") or "")
    dur = float(r["duration_s"]) if isinstance(r.get("duration_s"), (int, float)) else None
    if not start:
        continue
    events.append({"command_id": "CL-%03d" % i, "phase": note.split(";")[0][:70] or "unclassified",
                   "argv": argv, "start": start, "dur": dur,
                   "end": start.timestamp() + dur if dur is not None else None,
                   "exit": r.get("exit"), "kind": r.get("kind"), "note": note[:400],
                   "stdout": "", "stderr": "", "cat": category(argv, note)})

gw = CDG("GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv")
if os.path.isfile(gw):
    with open(gw, encoding="utf-8") as fh:
        for j, row in enumerate(csv.DictReader(fh), 1):
            start = parse_utc(row.get("started_utc") or "")
            try:
                dur = float(row.get("wall_sec"))
            except Exception:
                dur = None
            events.append({"command_id": "GPU-%02d" % j, "phase": "T6_R3_R1_7_bounded_forward",
                           "argv": "run_gpu_worker.py worker=%s gpu=%s reaction=%s uid=%s" % (
                               row.get("worker_index"), row.get("physical_gpu_index"),
                               (row.get("reaction_task_id") or "")[:18], row.get("assigned_uid")),
                           "start": start, "dur": dur,
                           "end": parse_utc(row.get("ended_utc") or "").timestamp()
                           if parse_utc(row.get("ended_utc") or "") else
                           (start.timestamp() + dur if start and dur else None),
                           "exit": row.get("exit_code"), "kind": "gpu_worker",
                           "note": "runtime_init_sec=%s" % row.get("runtime_init_sec"),
                           "stdout": "original_return_dir/workers/worker_%s/stdout.log"
                           % row.get("worker_index"),
                           "stderr": "original_return_dir/workers/worker_%s/stderr.log"
                           % row.get("worker_index"), "cat": "GPU"})

for f in sorted(iter_files(LOGS)):
    base = os.path.basename(f)
    if base.endswith(".jsonl") and "invocation" in base:
        for k, line in enumerate(open(f, encoding="utf-8"), 1):
            d = json.loads(line) if line.strip() else {}
            st = parse_utc(str(d.get("utc") or ""))
            if not st:
                continue
            events.append({"command_id": "%s-%02d" % (base.split(".")[0], k),
                           "phase": "recorded_invocation", "argv": redact(json.dumps(d))[:200],
                           "start": st, "dur": None, "end": None, "exit": "",
                           "kind": "invocation_log", "note": "", "stdout": "",
                           "stderr": "", "cat": "CPU"})

events.sort(key=lambda e: e["start"])
tl_rows = [[e["command_id"], e["phase"], e["argv"][:240],
            e["start"].strftime("%Y-%m-%dT%H:%M:%SZ"),
            datetime.fromtimestamp(e["end"], timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            if e["end"] else "",
            "%.3f" % e["dur"] if e["dur"] is not None else "",
            e["exit"], e["stdout"], e["stderr"], e["cat"], e["kind"]] for e in events]
write_csv("%s/06_timing/COMMAND_TIMELINE.csv" % CD,
          ["command_id", "phase", "argv_redacted", "start_utc", "end_utc", "elapsed_seconds",
           "exit_code", "stdout_path", "stderr_path", "category", "log_kind"], tl_rows)

buckets = {}
for e in events:
    m = re.search(r"(p\d+[a-z]?_[a-z0-9_]+)", e["argv"])
    key = m.group(1) if m else ("git" if "git " in e["argv"] else
                                ("nvidia-smi" if "nvidia-smi" in e["argv"] else "other"))
    b = buckets.setdefault(key, {"n": 0, "sum": 0.0, "fail": 0, "first": e["start"],
                                 "last": e["start"]})
    b["n"] += 1
    b["sum"] += e["dur"] or 0
    if str(e["exit"]) not in ("0", "", "None"):
        b["fail"] += 1
    b["first"] = min(b["first"], e["start"])
    b["last"] = max(b["last"], e["start"])
write_csv("%s/06_timing/PHASE_TIMING_BREAKDOWN.csv" % CD,
          ["script_or_tool", "logged_events", "logged_cpu_gpu_seconds",
           "failed_or_nonzero_exit_events", "first_utc", "last_utc"],
          [[k, v["n"], "%.3f" % v["sum"], v["fail"], v["first"].strftime("%Y-%m-%dT%H:%M:%SZ"),
            v["last"].strftime("%Y-%m-%dT%H:%M:%SZ")] for k, v in sorted(buckets.items())])

gaps, total_gap = [], 0.0
fmt = lambda ts: datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
explained = sum(e["dur"] or 0 for e in events)
ivs = sorted([(e["start"].timestamp(), e["end"] or e["start"].timestamp()) for e in events])
merged = []
for st, en in ivs:
    if merged and st <= merged[-1][1]:
        merged[-1][1] = max(merged[-1][1], en)
    else:
        merged.append([st, en])
busy = sum(en - st for st, en in merged)
for a, b in zip(merged, merged[1:]):
    if b[0] - a[1] > 300:
        gaps.append(["", "", fmt(a[1]), fmt(b[0]), int(b[0] - a[1])])
        total_gap += b[0] - a[1]

# every artifact write is proof that something happened at that instant; a span
# with neither a logged command nor a file write cannot be attributed at all
points = []
for e in events:
    points.append(e["start"].timestamp())
    if e["end"]:
        points.append(e["end"])
artifact_ts = {}
for root in (RD, LOGS, RUNTIME_TMP, "%s/scripts" % W, DEV_TMP):
    for f in iter_files(root):
        try:
            ts = int(os.path.getmtime(f))
        except OSError:
            continue
        points.append(ts)
        artifact_ts.setdefault(re.sub(r"^(p\d+[a-z]?)_.*", r"\1",
                                      os.path.basename(f)), []).append(ts)
points = sorted(set(points))
points.append(int(NOW_DT.timestamp()))
dead = [[fmt(a), fmt(b), int(b - a)] for a, b in zip(points, points[1:]) if b - a > 600]
dead_total = sum(d[2] for d in dead)
window = int(points[-1] - points[0])
first_cmd_ts = events[0]["start"].strftime("%Y-%m-%dT%H:%M:%SZ") if events else ""
idle_total = int(window - busy)
write_json("%s/06_timing/WALL_TIME_ACCOUNTING.json" % CD, {
    "method": "(a) busy = merged intervals of logged events that carry a measured "
              "duration; (b) dead spans = gaps between consecutive evidence points "
              "(command start/end OR artifact file mtime) over 600s",
    "first_evidence_point_utc": fmt(points[0]), "last_evidence_point_utc": fmt(points[-1]),
    "first_logged_command_utc": first_cmd_ts, "checkpoint_utc": NOW_UTC,
    "total_wall_window_seconds": window, "logged_event_count": len(events),
    "artifact_files_scanned": len([1 for v in artifact_ts.values() for _ in v]),
    "sum_of_individual_logged_durations_seconds": round(explained, 3),
    "merged_busy_seconds": int(busy), "idle_seconds_window_minus_busy": idle_total,
    "idle_spans_over_300s_between_timed_events": len(gaps),
    "idle_seconds_in_those_spans": int(total_gap),
    "dead_spans_over_600s_no_command_and_no_file_write": len(dead),
    "dead_seconds_over_600s": dead_total,
    "unattributed_seconds": dead_total,
    "note": "the 3 GPU workers ran in parallel, so sum_of_individual_logged_durations "
            "exceeds merged busy time; dead spans are the only quantity that has "
            "literally no evidence of any kind"})
write_csv("%s/06_timing/IDLE_GAPS_BETWEEN_TIMED_EVENTS_OVER_300S.csv" % CD,
          ["after_event_id", "before_event_id", "gap_start_utc", "gap_end_utc",
           "gap_seconds"], gaps)
write_csv("%s/06_timing/DEAD_SPANS_OVER_600S.csv" % CD,
          ["span_start_utc", "span_end_utc", "seconds"],
          sorted(dead, key=lambda d: -d[2]))
write_csv("%s/06_timing/PHASE_SPANS_FROM_ARTIFACT_MTIME.csv" % CD,
          ["phase_key", "artifact_events", "first_write_utc", "last_write_utc",
           "span_seconds"],
          [[k, len(v), fmt(min(v)), fmt(max(v)), int(max(v) - min(v))]
           for k, v in sorted(artifact_ts.items()) if k.startswith("p")])
retry_rows = [[k, v["n"], v["fail"]] for k, v in sorted(buckets.items())
              if re.match(r"p\d", k) and v["n"] > 1]
write_csv("%s/06_timing/SCRIPT_RETRY_COUNTS.csv" % CD,
          ["driver_script", "logged_invocations", "nonzero_exit_or_failed"], retry_rows)
write_csv("%s/06_timing/STAGING_SCRIPT_MTIME_SHA.csv" % CD,
          ["file", "bytes", "sha256", "mtime_utc"],
          [[f, os.path.getsize(os.path.join(DEV_TMP, f)), sha_file(os.path.join(DEV_TMP, f)),
            datetime.fromtimestamp(os.path.getmtime(os.path.join(DEV_TMP, f)), timezone.utc)
            .strftime("%Y-%m-%dT%H:%M:%SZ")]
           for f in sorted(os.listdir(DEV_TMP)) if f.endswith(".py")])
write_text("%s/06_timing/LLM_OR_EXECUTOR_DELAY_OBSERVATIONS.md" % CD, ("""# 耗时与空窗观察（只写可证明事实）

- 第一条有日志命令 UTC：%(first)s；第一个证据点 UTC：%(p0)s；检查点 UTC：%(now)s。
- 总 wall window：**%(win)d 秒**（%(winh)s）。
- 有实测时长的命令事件合并占用（busy）：**%(busy)d 秒**；其各条时长直加（含 3 worker 并行重叠）：**%(expl).1f 秒**（command_log %(ncl)d 行 + 3 条 GPU worker 行 + invocation 登记行，共 %(nev)d 个事件）。
- **完全没有任何证据的空窗（既无命令记录、也无任何文件写入）：%(ndead)d 段，共 %(dead)d 秒（%(deadh)s）**——明细 `DEAD_SPANS_OVER_600S.csv`，这就是“无命令活动的时间空窗”。
- 只按“有实测时长的命令”算的空闲：%(idle)d 秒；两者差额说明大部分阶段只有“结果文件写入时间”，没有逐命令时长日志（驱动 step 行不记 duration_s）。
- §7 三个 GPU worker 的真实墙钟/runtime_init 见 `original_return_dir/GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv`
  的 started_utc/ended_utc/wall_sec 字段（本检查点未重跑，未重新计时）。
- 同一驱动脚本被记录多次（含失败重试）见 `SCRIPT_RETRY_COUNTS.csv` 与
  `PHASE_TIMING_BREAKDOWN.csv`：§4.3 p7 记 4 次（1 crash、2 次 rc=3、1 次 PASS）、
  §7 p12 记 3 次 attempt、enviPath 门 p13 记 5 次 attempt、§8-A p14 记 2 次、§6.3 p11 记 3 次调用。
- 脚本被逐次编辑的次数：本主机不保存编辑历史，只能由 mtime+SHA 侧面体现
  （`STAGING_SCRIPT_MTIME_SHA.csv`），因此记 **UNKNOWN_NOT_YET_AUDITED**。
- 是否存在"模型未运行但长时间等待"：`DEAD_SPANS_OVER_600S.csv` 与
  `IDLE_GAPS_BETWEEN_TIMED_EVENTS_OVER_300S.csv` 所列空窗内，除 §7 worker 自身
  运行期外没有任何 GPU 计算进程证据；成因无法由现有日志判定。
- 空窗中可部分归因的实物：GPU worker 串行等待（§7 每 worker 需完整模型初始化）、
  以及 §8-B 前置只读勘察（读合同、读 langgraph/老师源码、读 §7 冻结结果）。

本文件不指责任何主体（Qoder/LLM/用户/科学模型），仅留证供本地审计裁定。
""" % {"first": first_cmd_ts, "p0": fmt(points[0]), "now": NOW_UTC, "win": window,
       "winh": "%dh%dm" % (window // 3600, (window % 3600) // 60),
       "expl": explained, "ncl": len(cl), "nev": len(events), "busy": int(busy),
       "idle": idle_total, "ngap": len(gaps), "gap": int(total_gap),
       "ndead": len(dead), "dead": dead_total,
       "deadh": "%dh%dm" % (dead_total // 3600, (dead_total % 3600) // 60),
       "unatt": dead_total}))

def gsv(needle, *paths):
    """Bare gate VALUE for FINAL_STATUS: prefer the literal TOKEN=VALUE written by
    the real gate file / its stdout, then an exact JSON key, then verdict/status."""
    for t in tokens(*paths):
        if needle.lower() in t.lower():
            return t.rsplit("=", 1)[-1]
    for p in paths:
        d = load_json(p)
        if not isinstance(d, dict):
            continue
        if needle in d and not isinstance(d[needle], (dict, list)):
            return str(d[needle])
        v = d.get("verdict", d.get("status", d.get("gate")))
        if isinstance(v, dict) and needle in v:
            return str(v[needle])
        if isinstance(v, dict):
            return ";".join("%s=%s" % (a, b) for a, b in sorted(v.items())
                            if not isinstance(b, (dict, list)))
        if v is not None and not isinstance(v, (dict, list)):
            return str(v)
    return "UNKNOWN_NOT_YET_AUDITED"


# --------------------------------------------------- §3 progress per stage
FWD = CDG("T3B_BOUNDED_FORWARD_GATE.json")
ENV_G = CDG("ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json")
PREREG = CDG("PYTHON_RUNTIME_PREFLIGHT.json")
stages = [
    ["§0", "唯一目标", "PASS", "p1_setup", "AUTHORITY_MEMBERSHIP.csv",
     "非独立门；authority/fresh 路径实物齐备"],
    ["§1", "Authority payload 与优先级", "PASS", "p1_setup",
     "AUTHORITY_MEMBERSHIP.csv;FAILED_R3_MANIFEST_VERIFICATION.csv;R3_BLOCKED_BASELINE_IDENTITY.json",
     "7 成员身份核对（上一轮 R3 包）"],
    ["§2", "Fresh 路径", "PASS", "p1_setup", "ARCHIVE_MANIFEST_AUDIT.csv",
     "WORK_ROOT/RETURN_DIR 全新，未替换旧输出"],
    ["§3", "绝对红线", "UNKNOWN", "", "",
     "过程约束，无独立 gate 实物；不主张已完成红线审计"],
    ["§4.E0-E0b", "锁定 Python/入口/包矩阵（计算前硬门）",
     gs("PYTHON_RUNTIME_PREFLIGHT", PREREG, CDG("PYTHON_RUNTIME_PREFLIGHT_STDOUT.txt")),
     "p2_e0", "PYTHON_RUNTIME_PREFLIGHT.json;PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv;"
     "ENTRYPOINT_IMPORT_IDENTITIES.csv;ENVIRONMENT_PREFLIGHT_STDOUT.txt",
     "真实运行；argv[0] 与内部 sys.executable 均为固定 PY"],
    ["§4.3", "统一 graph 运行时门",
     gs("UNIFIED_GRAPH_RUNTIME", CDG("UNIFIED_GRAPH_RUNTIME_GATE.json"),
        CDG("UNIFIED_GRAPH_RUNTIME_STDOUT.txt")),
     "p7_graph_runtime x4 attempts", "UNIFIED_GRAPH_RUNTIME_GATE.json;"
     "UNIFIED_GRAPH_RUNTIME_STDOUT.txt;GRAPH_MODULE_IMPORT_IDENTITIES.csv",
     "langgraph 1.2.9 与老师节点/工具/schema 单一绑定"],
    ["§5.1", "首轮 blocked 包与权威输入", "PASS", "p5_failed_r3",
     "FAILED_R3_MANIFEST_VERIFICATION.csv;R3_BLOCKED_BASELINE_IDENTITY.json",
     "上一轮 R3 包只读采纳"],
    ["§5.2", "teacher exact base 取得", "PASS", "p6_teacher_base",
     "TEACHER_BASE_ACQUISITION.json;SOURCE_AND_TOPOLOGY_GATE_STDOUT.txt",
     "base_commit=%s tree=%s" % (git.get("HEAD"), git.get("TREE"))],
    ["§5.3", "patch 与拓扑硬门",
     gs("TOPOLOGY", CDG("TEACHER_FIXED_TOPOLOGY_IDENTITY.json")), "p6/p7",
     "TEACHER_FIXED_TOPOLOGY_IDENTITY.json;CHANGED_FILES_R1.csv;"
     "SOURCE_AND_TOPOLOGY_GATE_STDOUT.txt;work_tmp/SOURCE_PATCH_R1_REGENERATED.diff",
     "4 个老师拓扑文件在本检查点复核后未改动"],
    ["§6.1", "CPU 回归 157 项（只跑一次）",
     gs("COMPONENT_TESTS", CDG("COMPONENT_TESTS_GATE.json"),
        CDG("COMPONENT_TESTS_GATE_STDOUT.txt")),
     "p9_cpu_regression", "COMPONENT_TESTS_GATE.json;COMPONENT_NAMED_CHECKS.csv;"
     "COMPONENT_TEST_GROUP_RUNS.csv;COMPONENT_TEST_LOG_INDEX.csv;"
     "CPU_TEST_INPUT_IDENTITIES.csv;CPU_REGRESSION_INPUT_GATE.json", "真实运行，未重跑"],
    ["§6.2", "固定资产身份",
     gs("ASSET_IDENTITY", CDG("FIXED_ASSET_IDENTITY_GATE.json")), "p10_assets",
     "FIXED_ASSET_IDENTITY_GATE.json;CORRECTED_UID_AND_PROTEIN_ASSET_IDENTITIES.csv;"
     "ASSET_SHA_DISCOVERY_SCAN.csv;INPUT_IDENTITIES.csv;V1_OVERLAY_MANIFEST.csv;"
     "REACTION_OVERLAY_MANIFEST.csv;V1_OVERLAY_CONFIG_DIFF.json;"
     "REACTION_OVERLAY_REBUILD_DETERMINISM.json;FIXED_ASSET_IDENTITY_STDOUT.txt",
     "3 归档 + v1 tar 身份，未重算"],
    ["§6.3", "native load 与逐 UID ESM 硬门",
     gs("UID_SEQUENCE", CDG("UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json")),
     "p11_preforward x3", "UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json;"
     "NATIVE_LOAD_PER_ROW_TENSORS.csv;PREFORWARD_GATE_STDOUT.txt",
     "真实运行；PASS_3_OF_3"],
    ["§7", "三 GPU 真实 6 条 forward", gs("T3B_BOUNDED_FORWARD", FWD),
     "3 workers parallel + 1 repeat invocation",
     "T3B_BOUNDED_FORWARD_GATE.json;GPU_FORWARD_GATE_STDOUT.txt;"
     "T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl;"
     "GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv;FORWARD_PER_REACTION_UID_SEED_SCORES.csv;"
     "T2_V32_REAL_ADAPTER_BASE.json;T2_V32_REAL_ADAPTER_REPEAT.json;"
     "V32_RUNTIME_STAGING.csv;workers/worker_0/worker_result.json;"
     "workers/worker_1/worker_result.json;workers/worker_2/worker_result.json",
     "6/6；分数非逐字节可复现，1e-05 容差内"],
    ["§8-enviPath附加门", "enviPath lookup->prediction 只读证据门",
     gs("LOOKUP_THEN_PREDICTION_ORDER", ENV_G), "p13_envipath_gate x5 attempts",
     "ENVIPATH_GATE_STDOUT.txt;ENVIPATH_LOOKUP_CALLS.csv;PREDICTION_FALLBACK_CALLS.csv;"
     "LOOKUP_PREDICTION_SOURCE_SEPARATION.json;ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json",
     "真实执行完成；结论是老师固定拓扑合同缺口（无 lookup 节点），非科学 FAIL，未改拓扑，等裁定"],
    ["§8-A", "8 条 smoke 真实输入预注册", "PASS_FROZEN_8_OF_8_INPUTS", "p14_smoke_prereg x2",
     "REAL_SMOKE_INPUTS.csv;REAL_SMOKE_PREREG_EVIDENCE.json;REAL_SMOKE_REAL_POOL_RUNS.csv;"
     "REAL_SMOKE_SELECTION_PREREGISTRATION.md", "输入冻结完成；输出 JSONL 未产生"],
    ["§8-B", "真实 LangGraph compile/invoke/stream 整链 + C1-C4 + C8->T5", "NOT_RUN",
     "NONE(no process started)", "04_evidence/staging_scripts_never_executed/p15_shared.py;"
     "04_evidence/staging_scripts_never_executed/p15b_chain_base.py;"
     "04_evidence/staging_scripts_never_executed/p15c_chain_staged.py",
     "只写子进程脚本 + AST/名字/use-before-bind 自检 + 1 次 0.17s 纯 CPU 拓扑探针；"
     "驱动 p15_real_langgraph_chain.py 未写；v1 基座包未建；0 次模型/图进程启动"],
    ["§8-TEST", "TEST-01 到 20 矩阵", "NOT_RUN", "NONE", "", "TEST_CASE_MATRIX.csv 未创建"],
    ["§9", "一次执行一次验证（禁止重复长算）", "PARTIAL", "", "",
     "约束层面遵守：E0-E7 未重跑；本检查点亦不重放模型"],
    ["§10", "最终三文件 closure", "NOT_RUN", "NONE", "",
     "本轮 T6 archive/identity/validation 未生成"],
    ["§11", "Validator 与 mutation 硬规则", "NOT_RUN", "NONE", "",
     "G-SCHEMA 正负例、五类 mutation、access audit、外置 validator 全未执行"],
    ["§12", "必须返回（最终交付清单）", "NOT_RUN", "NONE", "",
     "§12 命名的 §8 之后交付文件全部不存在"],
    ["§13", "最终状态", "NOT_RUN", "NONE", "", "未写 T6 READY / G7 PASS（本包 CHECKPOINT_ONLY）"],
    ["§14", "最终终端输出", "NOT_RUN", "NONE", "", "原任务输出块未产生"],
]
cd_index = {}
for _f in iter_files(CD):
    cd_index.setdefault(os.path.basename(_f), []).append(_f)
progress = {"task": "T6-R3-R1 checkpoint at operator stop", "original_task_id": ORIG_TASK,
            "checkpoint_utc": NOW_UTC, "stage_count": len(stages),
            "evidence_resolution_note": "every output path below is resolved against the "
            "packaged copy of the original return dir / logs / tmp, or is reported as "
            "NOT_RESOLVED_AT_CHECKPOINT_TIME and listed in MISSING_EXPECTED_EVIDENCE.csv",
            "status_semantics": {
                "PASS_real_run": "status 字段以 gate 文件内真实 token 表述（真实运行）",
                "PASS_COMPONENT_ONLY": "组件级证据，不等同真实整链通过",
                "NOT_RUN": "实物不存在且无日志",
                "UNKNOWN": "无独立 gate 实物，不主张"},
            "ui_todo_state_used_as_evidence": False,
            "stages": []}
for sid, name, st, cmds, outs, note in stages:
    ev = []
    for o in [x for x in outs.split(";") if x]:
        for c in (CDG(o), "%s/%s" % (CD, o), "%s/%s" % (RD, o), "%s/%s" % (LOGS, o),
                  "%s/%s" % (RUNTIME_TMP, o), "%s/%s" % (W, o)) + \
                tuple(cd_index.get(os.path.basename(o), [])):
            if os.path.isfile(c):
                ev.append({"path": os.path.relpath(c, CD) if c.startswith(CD) else c,
                           "sha256": sha_file(c)})
                break
        else:
            ev.append({"path": o, "sha256": "NOT_RESOLVED_AT_CHECKPOINT_TIME"})
    progress["stages"].append({"stage_id": sid, "name": name, "status": st,
                               "started_utc": "", "ended_utc": "", "elapsed_seconds": "",
                               "command_ids": cmds, "output_files": outs,
                               "evidence_sha256": ev, "first_error": "", "notes": note})
write_json("%s/CURRENT_PROGRESS.json" % CD, progress)

comp = load_json("%s/COMPONENT_TESTS_GATE.json" % RD) or {}
human = """# T6-R3-R1 现在真正做到哪一步（白话版）

**一句话**：操作员在 §8-B（真实 LangGraph 整链）还没启动任何进程时叫停。
§4—§7 的科学结果真实完成并有 gate 文件；§8 只完成了 enviPath 只读门（结论=合同缺口）
和 §8-A 的 8 条输入预注册；§8-B 只有写好的脚本，零执行。

## 已经真实通过
1. 环境/解释器（§4 E0-E0b）：**%(e0)s**
2. 统一 graph 运行时（§4.3）：**%(gr)s**（第 4 次尝试才 PASS，前三次是驱动自身 bug）
3. 老师基座/patch/拓扑（§5）：**%(topo)s**，base commit `%(head)s`
4. 157 项 CPU 回归（§6.1）：**%(cpu)s**（%(compcounts)s）
5. 固定资产身份（§6.2）：**%(asset)s**
6. native load + 逐 UID ESM（§6.3）：**%(pre)s**
7. §7 三 GPU 6 条 forward：**%(fwd)s** —— 3 个 worker 各 3 条（1 基座 + 2 重复），
   墙钟、runtime_init、UUID 核对见 `GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv`；
   分数不是逐字节可复现，最大偏差在 REPEAT_TOLERANCE=1e-05 内；
   逐条 UID/seed/score 见 `FORWARD_PER_REACTION_UID_SEED_SCORES.csv`。

## §8 的真实边界（重点）
- enviPath 只读附加门：**%(envi)s**（5 次 attempt 后定稿）。原因是老师固定拓扑内没有
  enviPath lookup 节点；MISS 分支无数据库可查；v3.2 prediction 由下游酶池节点直接调用。
  这是**合同缺口**，按裁定未改拓扑、未把 depending retrieval 冒充 enviPath、未伪写 T6 完整通过。
- §8-A：**8 条 smoke 输入已冻结**（REAL_SMOKE_INPUTS.csv，8×21 字段，问题数 0）。
- §8-B：**0 次执行**。compile/invoke/stream/8 条实跑/C1-C4/C8→T5/TEST-01—20/G-SCHEMA/
  mutation/determinism/access/pre-post 全部 NOT_RUN。
  存在的只有 3 个未部署的子进程脚本（p15_shared/p15b_chain_base/p15c_chain_staged）
  和一次 0.17 秒纯 CPU 的老师拓扑只读探针；驱动 p15_real_langgraph_chain.py 未写，
  v1 基座包未建，**没有任何 GPU/模型/图进程被 §8 启动**。

## 当前有没有命令还在跑
见 `PROCESS_SNAPSHOT_AT_STOP.csv`：任务相关进程 %(nproc)d 个（只有 jupyter-lab 常驻），
GPU compute-apps %(ngpu)d 个。未发 SIGINT/SIGTERM，未中断任何写入。

## 为什么停
用户即时裁定：执行器在 §8-B 前置核对耗时过长，立即停止并只交检查点。
停止类型 = INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT，**不是科学 FAIL**。

## 可直接复用 vs 必须续跑
- 复用（禁止重做）：E0、§4.3、§5 身份/patch/拓扑、§6.1、§6.2、§6.3、§7 全部结果与
  UID 池映射、§8-A 冻结输入、enviPath 结论。
- 必须真实续跑：§8-B 全部、TEST-01—20、G-SCHEMA、mutation、determinism、access audit、
  persistent pre/post、§10—§14。
""" % {"e0": gsv("PYTHON_RUNTIME_PREFLIGHT", PREREG), "gr": gsv("UNIFIED_GRAPH_RUNTIME",
       CDG("UNIFIED_GRAPH_RUNTIME_GATE.json")),
       "topo": gsv("TEACHER_FIXED_TOPOLOGY", CDG("TEACHER_FIXED_TOPOLOGY_IDENTITY.json")),
       "head": git.get("HEAD"), "cpu": gsv("COMPONENT_TESTS", CDG("COMPONENT_TESTS_GATE.json")),
       "compcounts": "named_checks_expected=%s；从日志逐 test 解析=%s；G1—G7 去重标识=%s"
       % (comp.get("named_checks_expected", "?"),
          comp.get("named_checks_parsed_from_logs", "?"),
          comp.get("distinct_check_identifiers_g1_g7", "?")),
       "asset": gsv("ASSET_IDENTITY", CDG("FIXED_ASSET_IDENTITY_GATE.json")),
       "pre": gsv("UID_SEQUENCE_GVP_POCKET_ESM", CDG(
           "UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json")),
       "fwd": gsv("T3B_BOUNDED_FORWARD", FWD),
       "envi": gsv("LOOKUP_THEN_PREDICTION_ORDER", ENV_G), "nproc": len(task_procs),
       "ngpu": len([l for l in gpu_out.splitlines() if l.strip()])}
write_text("%s/CURRENT_PROGRESS_HUMAN_READABLE.md" % CD, human)

write_text("%s/REMAINING_WORK.md" % CD, """# 剩余工作（只列未完成，不重设计方案）

## P0 scientific remaining
| 项 | 入口 | 依赖 | 预计命令 | 已有可复用输入 | 禁止重做 |
|---|---|---|---|---|---|
| v1 基座包物化（5 config.yaml 逐字节解出 + 5 checkpoint 硬链 + 与 overlay 仅 3 字段差异） | 驱动未写 | FIXED_ASSET_IDENTITY_GATE.json、V1_OVERLAY_REBUILD_MANIFEST.json | tar seek 读 + 硬链（0 次模型加载） | v1 tar 已核 SHA cc2103e1…（未重算） | §6.2 |
| §8-B base 轨：真 compile + 1 invoke + 1 stream + invoke/stream 同输入等价 + C1—C4 + 8 条 smoke 实跑 | scripts/p15b_chain_base.py（已写未跑，在 04_evidence/staging_scripts_never_executed/） | §7 池映射、§8-A 冻结输入、v1 基座包 | 1 fresh 子进程 ×2 次（同一物理 GPU index，PYTHONHASHSEED=0） | FORWARD_PER_REACTION_UID_SEED_SCORES.csv、FORWARD_BASE_SCORES.csv、REAL_SMOKE_INPUTS.csv | E0—E7 |
| §8-B staged 轨：ST1 真 stream、ST2 无注入（静态+动态）、ST3 缺资产 fail-closed、SK1—SK3 wrapper 级确认 | p15c_chain_staged.py（已写未跑） | V1_OVERLAY 根 | 1 fresh 子进程 ×2 次 | overlay 与 3 条 staged 反应已核 | §6.2、§7 |
| C8→T5 同一 thread 连续链（并记录 organism_selection→trait 图内不可达） | p15b 内（未跑） | 本机无任何 LLM 凭据的事实 | 复用同进程 | p14 的凭据 pop 清单 | E0—E7 |
| TEST-01—20 矩阵与逐项真 callable | 未写 | §8-B 输出 + 原合同 §6 的 20 项（在 inputs/authority、inputs/failed_r3） | CPU only | 上一轮矩阵仅可参考 | E0—E7 |
| G-SCHEMA Draft202012 正负例 + mutation 原类别 + TaxID/signature/CRLF/validation/旧 route_bridge 四类 | 未写 | 冻结 schema | CPU only | COMPONENT_TEST_* 实物 | E0—E7 |
| determinism：同一 8 条输入 fresh process 两次，规范化科学 JSONL 逐字节 + 分数容差 | 未写 | §8-B 双轨 ×2 | 复用 4 次进程输出 | p15_shared 的 scrub/mask 规则 | E0—E7 |
| access audit + persistent input/output tree pre/post | 未写 | §8-B 驱动 | 轻量哈希遍历 | p8_cpu_inputs 的输入身份 | E0—E7 |

## P1 evidence/delivery remaining
- §10 最终包 closure（本轮尚未生成任何 T6 archive/identity/validation）。
- §11 外置 validator（不得重载 5 checkpoint、不得重复 GPU forward）。
- §12 交付命名核对、§13 最终状态、§14 终端输出。
- enviPath 缺口需黄老师裁定后才能定 TEST-01—20 的判定口径。

## P2 nonblocking
- p15_shared 的浮点掩码只覆盖含小数点的数字（纯整数保留），可再收紧。
- check_order.py（模块级 use-before-bind 探针）尚未部署到 scripts/。
- p15b/p15c 尚未做过任何真实 import 冒烟（除 0.17s 纯 CPU 拓扑探针）。
- §7 attempt 1/2 的 wrapper 导入矩阵可补进最终包（文件已存在）。
""")

# ------------------------------------------------------- §7 resume readiness
env = load_json("%s/ENZYMECAGE_PYTHON_ENVIRONMENT_GATE.json" % RD) or {}
def dig(obj, *keys):
    cur = obj
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return "?"
        cur = cur[k]
    return cur if isinstance(cur, str) else "?"
fwd_obj = load_json("%s/T3B_BOUNDED_FORWARD_GATE.json" % RD) or {}
fwd_6 = isinstance(fwd_obj.get("verdict"), dict) and \
    fwd_obj["verdict"].get("T3B_BOUNDED_FORWARD") == "PASS_6_OF_6"
resume = {
    "original_work_root_exists": exists(W),
    "original_work_root_frozen_readonly_or_hash_anchored":
        "HASH_ANCHORED_ONLY: 原件 SHA 见 EVIDENCE_COPY_REPORT.csv；未改权限、未改写任何原件",
    "staged_repo_exists": exists(S),
    "base_commit": git.get("HEAD"), "base_tree": git.get("TREE"),
    "source_patch_sha256": sha_file(sp) if os.path.isfile(sp) else "MISSING",
    "source_patch_member_count": len(src_patch_files),
    "porcelain_change_count": len(porc.splitlines()),
    "teacher_topology_unchanged": bool(topo_rows) and all(r[4] == "UNCHANGED" for r in topo_rows),
    "teacher_topology_detail": [r[:5] for r in topo_rows],
    "python_absolute_path": dig(env, "python", "absolute_path"),
    "python_version": field("%s/PYTHON_RUNTIME_PREFLIGHT.json" % RD, "python_version"),
    "langgraph_version": "1.2.9",
    "python_overlay_order": dig(env, "prefix_resolution", "resolution_order"),
    "runtime_preflight_pass": "PASS" in stages[4][2],
    "unified_graph_runtime_pass": "PASS" in stages[5][2],
    "fixed_assets_registry_present": exists("%s/FIXED_ASSET_IDENTITY_GATE.json" % RD),
    "native_evidence_present": exists("%s/NATIVE_LOAD_PER_ROW_TENSORS.csv" % RD),
    "forward_evidence_present": exists("%s/T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl" % RD),
    "forward_6_of_6_if_true": bool(fwd_6),
    "pool_uid_map_present": exists("%s/§8_B_POOL_UID_MAP.csv" % RD),
    "smoke_inputs_frozen_present": exists("%s/REAL_SMOKE_INPUTS.csv" % RD),
    "graph_scripts_present": {"deployed_in_work_scripts": sorted(
        f for f in os.listdir("%s/scripts" % W) if f.startswith("p15")),
        "authored_not_deployed": ["p15_shared.py", "p15b_chain_base.py", "p15c_chain_staged.py"],
        "chain_driver_written": False, "expected_driver": "p15_real_langgraph_chain.py",
        "v1_base_package_built": exists("%s/runtime_assets/v1_base_package" % W)},
    "remaining_stage_entrypoint":
        "§8-B: 物化 v1 基座包 -> 部署 p15_* 到 WORK/scripts -> 写 p15_real_langgraph_chain.py "
        "-> {base,staged}×{run1,run2} 四个 fresh 进程 -> §12 交付 -> TEST-01—20 -> "
        "G-SCHEMA/mutation/determinism/access/pre-post -> §10—§14",
    "safe_to_resume_without_repeating_E0_E7": bool(
        fwd_6 and exists("%s/T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl" % RD)
        and exists("%s/FIXED_ASSET_IDENTITY_GATE.json" % RD)
        and exists("%s/COMPONENT_TESTS_GATE.json" % RD)
        and topo_rows and all(r[4] == "UNCHANGED" for r in topo_rows)),
    "unsafe_reasons": [],
    "checkpoint_only_not_t6_pass": True,
}
if not resume["safe_to_resume_without_repeating_E0_E7"]:
    resume["unsafe_reasons"] = [r for r in (
        "" if fwd_6 else "§7 forward 非 6/6",
        "" if exists("%s/FIXED_ASSET_IDENTITY_GATE.json" % RD) else "§6.2 资产身份缺失",
        "" if all(r[4] == "UNCHANGED" for r in topo_rows) else "老师拓扑 SHA 有变",
    ) if r] or ["见各字段"]
write_json("%s/RESUME_READINESS.json" % CD, resume)

# ------------------------------------------------------------ §2 FINAL_STATUS
comp = load_json("%s/COMPONENT_TESTS_GATE.json" % RD) or {}
UIDG = CDG("UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json")
comp_counts = ("named_checks_expected=%s parsed_from_logs=%s distinct_g1_g7_identifiers=%s"
               % (comp.get("named_checks_expected", "?"),
                  comp.get("named_checks_parsed_from_logs", "?"),
                  comp.get("distinct_check_identifiers_g1_g7", "?")))
ENVG = CDG("ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json")
V = {
    "e0": gsv("PYTHON_RUNTIME_PREFLIGHT", PREREG, CDG("PYTHON_RUNTIME_PREFLIGHT_STDOUT.txt")),
    "graph": gsv("UNIFIED_GRAPH_RUNTIME", CDG("UNIFIED_GRAPH_RUNTIME_GATE.json"),
                 CDG("UNIFIED_GRAPH_RUNTIME_STDOUT.txt")),
    "topo": gsv("TEACHER_FIXED_TOPOLOGY", CDG("TEACHER_FIXED_TOPOLOGY_IDENTITY.json")),
    "comp": gsv("COMPONENT_TESTS", CDG("COMPONENT_TESTS_GATE.json"),
                CDG("COMPONENT_TESTS_GATE_STDOUT.txt")),
    "asset": gsv("ASSET_IDENTITY", CDG("FIXED_ASSET_IDENTITY_GATE.json")),
    "native": gsv("T3B_NATIVE_LOAD", UIDG),
    "uid": gsv("UID_SEQUENCE_GVP_POCKET_ESM", UIDG),
    "fwd": gsv("T3B_BOUNDED_FORWARD", FWD),
    "envi": gsv("LOOKUP_THEN_PREDICTION_ORDER", ENV_G),
}
final_lines = [
    "T6_R3_R1_CHECKPOINT_INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT",
    "ORIGINAL_TASK_ID=%s" % ORIG_TASK,
    "CHECKPOINT_UTC=%s" % NOW_UTC,
    "LAST_COMPLETED_STAGE=§8_A_REAL_SMOKE_INPUT_PREREGISTRATION_FROZEN_8_OF_8",
    "CURRENT_OR_INTERRUPTED_STAGE=§8_B_REAL_LANGGRAPH_FULL_CHAIN_NOT_RUN_"
    "SCRIPTS_AUTHORED_ONLY_NO_PROCESS_RUNNING_AT_STOP",
    "STOP_REASON=USER_REQUESTED_CHECKPOINT_DUE_TO_EXECUTOR_DELAY",
    "T6_FINAL_READY=false", "G7_PASSED=false", "NOT_A_FINAL_T6_DELIVERY=true",
    "PYTHON_ENVIRONMENT_PREFLIGHT=%s" % V["e0"],
    "UNIFIED_GRAPH_RUNTIME=%s" % V["graph"],
    "TEACHER_FIXED_TOPOLOGY=%s" % V["topo"],
    "COMPONENT_TESTS=%s (%s)" % (V["comp"], comp_counts),
    "FIXED_ASSET_IDENTITY=%s" % V["asset"],
    "T3B_NATIVE_LOAD=%s" % V["native"],
    "UID_SEQUENCE_GVP_POCKET_ESM=%s" % V["uid"],
    "T3B_BOUNDED_FORWARD=%s" % V["fwd"],
    "REAL_LANGGRAPH_COMPILE=NOT_RUN", "REAL_LANGGRAPH_INVOKE=NOT_RUN",
    "REAL_LANGGRAPH_STREAM_TO_TERMINAL=NOT_RUN",
    "REAL_SMOKE_RECORDS=NOT_RUN_OUTPUTS_JSONL_ABSENT_INPUTS_FROZEN_8_OF_8",
    "TEST_01_TO_20=NOT_RUN", "C8_TO_T5_REAL_CONTINUOUS_REGRESSION=NOT_RUN",
    "GSCHEMA=NOT_RUN",
    "DETERMINISM=NOT_RUN_§8_B_DUAL_FRESH_PROCESS",
    "MUTATION=NOT_RUN", "ACCESS_AUDIT=NOT_RUN_FINAL",
    "PERSISTENT_INPUT_NONMUTATION=NOT_RUN_§8_B_PRE_POST",
    "", "# appended facts (outside the fixed key list above)",
    "ENVIPATH_LOOKUP_THEN_PREDICTION_ORDER=%s" % V["envi"],
    "ENVIPATH_GATE_CLASS=TEACHER_FIXED_TOPOLOGY_CONTRACT_GAP_NOT_SCIENTIFIC_FAIL",
    "STOP_CLASSIFICATION=INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT",
    "SCIENTIFIC_FAIL_AT_INTERRUPTED_STAGE=false", "PROCESS_KILLED_AT_STOP=0",
    "SIGINT_SENT_AT_STOP=0",
    "GPU_COMPUTE_APPS_AT_STOP=%d" % len([l for l in gpu_out.splitlines() if l.strip()]),
    "SCIENTIFIC_REPLAY_BY_THIS_CHECKPOINT=NOT_RUN",
    "E0_E7_RERUN_BY_THIS_CHECKPOINT=NO",
    "DIRECTIVE_GIVEN_PATH_EXISTS=%s" % directive_info["given_path_exists_on_this_host"],
    "DIRECTIVE_READ_PATH=%s" % DIRECTIVE,
    "DIRECTIVE_SHA256=%s" % directive_info["directive_sha256"],
    "UI_TODO_STATE_USED_AS_EVIDENCE=false",
    "SAFE_TO_RESUME_WITHOUT_REPEATING_E0_E7=%s" % str(
        resume["safe_to_resume_without_repeating_E0_E7"]).lower(),
    "CHECKPOINT_PACKAGE=CHECKPOINT_ONLY_NOT_FINAL_T6_DELIVERY",
]
write_text("%s/FINAL_STATUS.txt" % CD, "\n".join(final_lines) + "\n")

write_csv("%s/MISSING_EXPECTED_EVIDENCE.csv" % CD, ["requested", "state", "detail"],
          missing_rows)
write_csv("%s/EVIDENCE_COPY_REPORT.csv" % CD,
          ["source_path", "checkpoint_path", "action", "bytes", "src_sha256", "dst_sha256",
           "tag"], copy_rows)

summary = {"checkpoint_dir": CD, "checkpoint_work": CW,
           "copied": sum(1 for r in copy_rows if r[2] == "COPIED"),
           "skipped": sum(1 for r in copy_rows if r[2].startswith("SKIPPED")),
           "sha_mismatch_rows": [r for r in copy_rows if r[2] == "COPIED" and r[4] != r[5]],
           "missing_evidence_rows": len(missing_rows),
           "porcelain_lines": len(porc.splitlines()),
           "classified_rows": len(class_rows), "timeline_rows": len(tl_rows),
           "teacher_topology_unchanged": bool(topo_rows) and all(
               r[4] == "UNCHANGED" for r in topo_rows),
           "forward_6_of_6": fwd_6, "wall_window_seconds": window,
           "logged_command_seconds": round(explained, 1),
           "idle_over_300s_seconds": int(total_gap), "idle_seconds_total": idle_total,
           "merged_busy_seconds": int(busy), "dead_spans_over_600s": len(dead),
           "unattributed_seconds": dead_total,
           "safe_to_resume_without_repeating_E0_E7":
               resume["safe_to_resume_without_repeating_E0_E7"],
           "final_status_values": V, "component_counts": comp_counts,
           "final_status_first_line": "T6_R3_R1_CHECKPOINT_INTERRUPTED_BY_OPERATOR_"
                                      "FOR_PERFORMANCE_AUDIT",
           "utc": NOW_UTC}
print(json.dumps(summary, indent=2, sort_keys=True))
write_json("%s/checkpoint_scripts/COLLECT_SUMMARY.json" % CD, summary)
