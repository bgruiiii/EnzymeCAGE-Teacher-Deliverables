# 剩余工作（只列未完成，不重设计方案）

## P0 scientific remaining
| 项 | 入口 | 依赖 | 预计命令 | 已有可复用输入 | 禁止重做 |
|---|---|---|---|---|---|
| v1 基座包物化（5 config.yaml 逐字节解出 + 5 checkpoint 硬链 + 与 overlay 仅 3 字段差异） | 驱动未写 | FIXED_ASSET_IDENTITY_GATE.json、V1_OVERLAY_REBUILD_MANIFEST.json | tar seek 读 + 硬链（0 次模型加载） | v1 tar 已核 SHA cc2103e1…（未重算） | §6.2 |
| §8-B base 轨：真 compile + 1 invoke + 1 stream + invoke/stream 同输入等价 + C1—C4 + 8 条 smoke 实跑 | scripts/p15b_chain_base.py（已写未跑，在 04_evidence/staging_scripts_never_executed/） | §7 池映射、§8-A 冻结输入、v1 基座包 | 1 fresh 子进程 ×2 次（同一物理 GPU index，PYTHONHASHSEED=0） | FORWARD_PER_REACTION_UID_SEED_SCORES.csv、FORWARD_BASE_SCORES.csv、REAL_SMOKE_INPUTS.csv | E0—E7 |
| §8-B staged 轨：ST1 真 stream、ST2 无注入（静态+动态）、ST3 缺资产 fail-closed、SK1—SK3 wrapper 级确认 | p15c_chain_staged.py（已写未跑） | V1_OVERLAY 根 | 1 fresh 子进程 ×2 次 | overlay 与 3 条 staged 反应已核 | §6.2、§7 |
| C8→T5 同一 thread 连续链（并记录 organism_selection→trait 图内不可达） | p15b 内（未跑） | 本机无任何 LLM 凭据的事实 | 复用同进程 | p14 的凭据 pop 清单 | E0—E7 |
| TEST-01—20 矩阵与逐项真 callable | 未写 | §8-B 输出 + 原合同 §6 的 20 项（在 inputs/authority、inputs/failed_r3） | CPU only | 上一轮矩阵仅可参考 | E0—E7 |
| G-SCHEMA Draft202012 正负例 + mutation 原类别 + TaxID/signature/CRLF/validation/旧 route_bridge 四类 | 未写 | 冻结 schema | CPU only | COMPONENT_TEST_* 实物 | E0—E7 |
| determinism：同一 8 条输入 fresh process 两次，规范化科学 JSONL 逐字节 + 分数容差 | 未写 | §8-B 双轨 ×2 | 复用 4 次进程输出 | p15_shared 的 scrub/mask 规则 | E0—E7 |
| access audit + persistent input/output tree pre/post | 未写 | §8-B 驱动 | 轻量哈希遍历 | p8_cpu_inputs 的输入身份 | E0—E7 |

## P1 evidence/delivery remaining
- §10 最终包 closure（本轮尚未生成任何 T6 archive/identity/validation）。
- §11 外置 validator（不得重载 5 checkpoint、不得重复 GPU forward）。
- §12 交付命名核对、§13 最终状态、§14 终端输出。
- enviPath 缺口需黄老师裁定后才能定 TEST-01—20 的判定口径。

## P2 nonblocking
- p15_shared 的浮点掩码只覆盖含小数点的数字（纯整数保留），可再收紧。
- check_order.py（模块级 use-before-bind 探针）尚未部署到 scripts/。
- p15b/p15c 尚未做过任何真实 import 冒烟（除 0.17s 纯 CPU 拓扑探针）。
- §7 attempt 1/2 的 wrapper 导入矩阵可补进最终包（文件已存在）。
