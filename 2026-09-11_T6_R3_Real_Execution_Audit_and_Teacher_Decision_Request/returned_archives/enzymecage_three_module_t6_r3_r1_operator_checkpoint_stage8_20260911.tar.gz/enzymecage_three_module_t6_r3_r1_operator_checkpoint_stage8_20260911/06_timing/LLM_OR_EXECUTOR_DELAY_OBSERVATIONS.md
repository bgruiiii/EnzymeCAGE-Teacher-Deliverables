# 耗时与空窗观察（只写可证明事实）

- 第一条有日志命令 UTC：2026-09-10T10:17:10Z；第一个证据点 UTC：2026-09-10T10:17:00Z；检查点 UTC：2026-09-11T06:11:42Z。
- 总 wall window：**71682 秒**（19h54m）。
- 有实测时长的命令事件合并占用（busy）：**229 秒**；其各条时长直加（含 3 worker 并行重叠）：**746.6 秒**（command_log 99 行 + 3 条 GPU worker 行 + invocation 登记行，共 105 个事件）。
- **完全没有任何证据的空窗（既无命令记录、也无任何文件写入）：14 段，共 62441 秒（17h20m）**——明细 `DEAD_SPANS_OVER_600S.csv`，这就是“无命令活动的时间空窗”。
- 只按“有实测时长的命令”算的空闲：71452 秒；两者差额说明大部分阶段只有“结果文件写入时间”，没有逐命令时长日志（驱动 step 行不记 duration_s）。
- §7 三个 GPU worker 的真实墙钟/runtime_init 见 `original_return_dir/GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv`
  的 started_utc/ended_utc/wall_sec 字段（本检查点未重跑，未重新计时）。
- 同一驱动脚本被记录多次（含失败重试）见 `SCRIPT_RETRY_COUNTS.csv` 与
  `PHASE_TIMING_BREAKDOWN.csv`：§4.3 p7 记 4 次（1 crash、2 次 rc=3、1 次 PASS）、
  §7 p12 记 3 次 attempt、enviPath 门 p13 记 5 次 attempt、§8-A p14 记 2 次、§6.3 p11 记 3 次调用。
- 脚本被逐次编辑的次数：本主机不保存编辑历史，只能由 mtime+SHA 侧面体现
  （`STAGING_SCRIPT_MTIME_SHA.csv`），因此记 **UNKNOWN_NOT_YET_AUDITED**。
- 是否存在"模型未运行但长时间等待"：`DEAD_SPANS_OVER_600S.csv` 与
  `IDLE_GAPS_BETWEEN_TIMED_EVENTS_OVER_300S.csv` 所列空窗内，除 §7 worker 自身
  运行期外没有任何 GPU 计算进程证据；成因无法由现有日志判定。
- 空窗中可部分归因的实物：GPU worker 串行等待（§7 每 worker 需完整模型初始化）、
  以及 §8-B 前置只读勘察（读合同、读 langgraph/老师源码、读 §7 冻结结果）。

本文件不指责任何主体（Qoder/LLM/用户/科学模型），仅留证供本地审计裁定。
