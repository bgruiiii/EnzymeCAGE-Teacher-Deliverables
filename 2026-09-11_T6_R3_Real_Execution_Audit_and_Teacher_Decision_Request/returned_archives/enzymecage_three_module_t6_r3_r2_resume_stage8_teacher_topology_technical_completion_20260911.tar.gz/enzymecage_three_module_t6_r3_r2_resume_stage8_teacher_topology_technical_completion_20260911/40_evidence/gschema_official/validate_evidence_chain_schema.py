#!/usr/bin/env python3
"""Validate three_module_evidence_chain_v0.1 structure and cross-field semantics."""

from __future__ import annotations

import argparse
import copy
import json
import math
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TRAIT_IDS = {f"F{i}" for i in range(1, 16)}
FORBIDDEN_KEYS = {"trait_score", "total_score", "confidence", "reranked_rank"}
CI_SEMANTICS = "empirical_2.5_97.5_percentile_range_across_5_seeds_not_statistical_confidence_interval"
RESOLUTION_LEVEL = {
    "UNRESOLVED": 0,
    "IDENTITY_ONLY": 0,
    "SPECIES": 1,
    "REPRESENTATIVE_STRAIN": 1,
    "EXACT_STRAIN": 2,
}


def _json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _schema_errors(schema: dict, document: dict) -> list[str]:
    try:
        from jsonschema import Draft7Validator, FormatChecker
    except ImportError:
        return ["jsonschema package is required for structural validation"]
    validator = Draft7Validator(schema, format_checker=FormatChecker())
    errors = []
    for error in sorted(validator.iter_errors(document), key=lambda e: list(e.absolute_path)):
        location = "/" + "/".join(str(x) for x in error.absolute_path)
        errors.append(f"schema {location}: {error.message}")
    return errors


def _walk_forbidden(value, path="") -> list[str]:
    errors = []
    if isinstance(value, dict):
        for key, child in value.items():
            child_path = f"{path}/{key}"
            if key in FORBIDDEN_KEYS:
                errors.append(f"forbidden field {child_path}")
            errors.extend(_walk_forbidden(child, child_path))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            errors.extend(_walk_forbidden(child, f"{path}/{index}"))
    return errors


def _finite(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def semantic_errors(document: dict) -> list[str]:
    errors = _walk_forbidden(document)
    query = document.get("query", {})
    query_id = query.get("query_id")
    route_ids, task_ids, evidence_ids = set(), set(), set()
    task_index, enzyme_pairs, source_signatures = {}, set(), set()

    for route_index, route in enumerate(document.get("routes", [])):
        rp = f"/routes/{route_index}"
        route_id = route.get("route_id")
        if route_id in route_ids:
            errors.append(f"duplicate route_id {route_id}")
        route_ids.add(route_id)
        if route.get("query_id") != query_id:
            errors.append(f"{rp}/query_id does not match top-level query_id")
        tasks = route.get("reaction_tasks", [])
        if route.get("total_route_step_count") != len(tasks):
            errors.append(f"{rp}/total_route_step_count must equal reaction_tasks length")

        route_unmatched = set()
        for task_index_in_route, task in enumerate(tasks):
            tp = f"{rp}/reaction_tasks/{task_index_in_route}"
            task_id = task.get("reaction_task_id")
            if task_id in task_ids:
                errors.append(f"duplicate reaction_task_id {task_id}")
            task_ids.add(task_id)
            task_index[task_id] = task
            if task.get("query_id") != query_id or task.get("route_id") != route_id:
                errors.append(f"{tp} query_id/route_id linkage mismatch")
            expected_reaction = f"{task.get('substrate_smiles', '')}>>{task.get('product_smiles', '')}"
            if task.get("reaction_smiles") != expected_reaction:
                errors.append(f"{tp}/reaction_smiles must equal substrate_smiles>>product_smiles")
            if task.get("reaction_source") == "model_prediction":
                if task.get("prediction_rank") is None or not isinstance(task.get("prediction_score"), dict) or not task.get("model_version"):
                    errors.append(f"{tp} model_prediction requires rank/raw-score semantics/model_version")
            if task.get("reaction_source") == "database_lookup" and (task.get("prediction_rank") is not None or task.get("prediction_score") is not None):
                errors.append(f"{tp} database_lookup must not carry model prediction score")
            prediction_score = task.get("prediction_score")
            if isinstance(prediction_score, dict) and not _finite(prediction_score.get("raw_score")):
                errors.append(f"{tp}/prediction_score/raw_score must be finite")

            asset = task.get("reaction_asset", {})
            asset_status = asset.get("reaction_asset_status")
            proxy = asset.get("proxy")
            manifest_hash = asset.get("asset_manifest_hash")
            identity_hash = asset.get("identity_hash")
            if asset_status == "FROZEN_PROXY":
                if not isinstance(proxy, dict):
                    errors.append(f"{tp} FROZEN_PROXY requires proxy object")
                if task.get("reaction_source") == "database_lookup":
                    errors.append(f"{tp} database_lookup cannot masquerade as FROZEN_PROXY")
            elif proxy is not None:
                errors.append(f"{tp} proxy object is only allowed for FROZEN_PROXY")
            if asset_status == "STAGED_GENERATED" and not manifest_hash:
                errors.append(f"{tp} STAGED_GENERATED requires asset_manifest_hash")
            if asset_status in {"FROZEN_EXACT", "FROZEN_PROXY", "STAGED_GENERATED"} and not identity_hash:
                errors.append(f"{tp} usable reaction asset requires identity_hash")
            if asset_status in {"MISSING", "INVALID"} and task.get("enzyme_match_status") == "MATCHED":
                errors.append(f"{tp} missing/invalid reaction asset cannot be MATCHED")

            pool = task.get("candidate_pool", {})
            pool_b = pool.get("pool_b_uids", [])
            pool_c = pool.get("pool_c_uids", [])
            selected = pool.get("selected_pool_uids", [])
            pool_route = pool.get("candidate_pool_route")
            if len(selected) > 100:
                errors.append(f"{tp} selected pool exceeds teacher hard maximum 100")
            if pool_route == "B_PRIMARY" and selected != pool_b:
                errors.append(f"{tp} B_PRIMARY selected pool must equal pool_b_uids")
            if pool_route == "C_FALLBACK" and (pool_b or selected != pool_c):
                errors.append(f"{tp} C_FALLBACK requires empty B and selected pool equal C")
            if pool_route is None and selected:
                errors.append(f"{tp} null pool route requires empty selected pool")
            if pool.get("pool_limit_exceeded") and selected:
                errors.append(f"{tp} pool-limit failure must not retain selected UIDs")
            if task.get("enzyme_match_status") == "POOL_LIMIT_EXCEEDED" and not pool.get("pool_limit_exceeded"):
                errors.append(f"{tp} POOL_LIMIT_EXCEEDED requires pool_limit_exceeded=true")

            enzymes = task.get("enzymes", [])
            if task.get("enzyme_match_status") == "MATCHED" and not enzymes:
                errors.append(f"{tp} MATCHED requires at least one enzyme")
            if task.get("enzyme_match_status") != "MATCHED" and enzymes:
                errors.append(f"{tp} non-MATCHED task cannot contain ranked enzymes")
            if task.get("enzyme_match_status") != "MATCHED":
                route_unmatched.add(task_id)
            enzyme_uids = [enzyme.get("enzyme_uid") for enzyme in enzymes]
            enzyme_ranks = [enzyme.get("enzyme_rank") for enzyme in enzymes]
            if len(enzyme_uids) != len(set(enzyme_uids)):
                errors.append(f"{tp} duplicate enzyme_uid")
            if enzyme_ranks != list(range(1, len(enzymes) + 1)):
                errors.append(f"{tp} enzyme ranks must be ordered and continuous from 1")
            if any(uid not in selected for uid in enzyme_uids):
                errors.append(f"{tp} ranked enzyme must belong to selected pool")
            for enzyme_index, enzyme in enumerate(enzymes):
                ep = f"{tp}/enzymes/{enzyme_index}"
                if enzyme.get("reaction_task_id") != task_id:
                    errors.append(f"{ep}/reaction_task_id linkage mismatch")
                if not _finite(enzyme.get("enzymecage_score")):
                    errors.append(f"{ep}/enzymecage_score must be finite")
                ci = enzyme.get("ensemble_ci")
                if ci is not None:
                    if not _finite(ci.get("lower")) or not _finite(ci.get("upper")) or ci.get("lower") > ci.get("upper"):
                        errors.append(f"{ep}/ensemble_ci bounds invalid")
                    if ci.get("ensemble_ci_semantics") != CI_SEMANTICS:
                        errors.append(f"{ep}/ensemble_ci semantics invalid")
                enzyme_pairs.add((task_id, enzyme.get("enzyme_uid")))
                for host_index, host in enumerate(enzyme.get("host_evidence", [])):
                    hp = f"{ep}/host_evidence/{host_index}"
                    if host.get("enzyme_uid") != enzyme.get("enzyme_uid"):
                        errors.append(f"{hp}/enzyme_uid linkage mismatch")
                    if host.get("host_resolution") == "UNRESOLVED":
                        if any(host.get(x) is not None for x in ("source_signature", "host_taxid", "host_name")):
                            errors.append(f"{hp} UNRESOLVED host must not invent identity")
                    else:
                        if not host.get("source_signature") or not host.get("host_taxid") or not host.get("host_name"):
                            errors.append(f"{hp} resolved host requires signature/taxid/name")
                        source_signatures.add(host.get("source_signature"))

        aggregates = route.get("organism_aggregates", [])
        ranks = [aggregate.get("default_order_rank") for aggregate in aggregates]
        if ranks != list(range(1, len(aggregates) + 1)):
            errors.append(f"{rp} organism default_order_rank must be continuous and preserve deterministic order")
        for aggregate_index, aggregate in enumerate(aggregates):
            ap = f"{rp}/organism_aggregates/{aggregate_index}"
            if aggregate.get("route_id") != route_id:
                errors.append(f"{ap}/route_id linkage mismatch")
            supported = set(aggregate.get("supported_reaction_task_ids", []))
            unmatched = set(aggregate.get("unmatched_steps", []))
            route_task_ids = {task.get("reaction_task_id") for task in tasks}
            if not supported <= route_task_ids or not unmatched <= route_task_ids:
                errors.append(f"{ap} references reaction task outside its route")
            if aggregate.get("covered_step_count") != len(supported):
                errors.append(f"{ap}/covered_step_count must equal unique supported steps")
            if aggregate.get("total_route_step_count") != len(tasks):
                errors.append(f"{ap}/total_route_step_count mismatch")
            if unmatched != route_unmatched:
                errors.append(f"{ap}/unmatched_steps must equal all non-MATCHED route tasks")
            for support in aggregate.get("supporting_enzymes", []):
                pair = (support.get("reaction_task_id"), support.get("enzyme_uid"))
                if pair not in enzyme_pairs:
                    errors.append(f"{ap} supporting enzyme pair not found in reaction task results")
            traits = aggregate.get("traits", [])
            trait_ids = [trait.get("trait_id") for trait in traits]
            if set(trait_ids) != TRAIT_IDS or len(trait_ids) != 15:
                errors.append(f"{ap} traits must contain exactly one each of F1-F15")
            host_level = RESOLUTION_LEVEL.get(aggregate.get("host_resolution"), -1)
            for trait_index, trait in enumerate(traits):
                trp = f"{ap}/traits/{trait_index}"
                klass = trait.get("trait_evidence_class")
                if trait.get("trait_id") == "F5" and klass == "PREDICTED":
                    errors.append(f"{trp} F5 availability must never be predicted")
                if klass in {"MISSING", "IDENTITY_ONLY"} and trait.get("trait_value") is not None:
                    errors.append(f"{trp} missing/identity-only trait value must be null")
                if klass == "PREDICTED" and not all(trait.get(x) for x in ("trait_source", "source_record_id", "source_tool", "model_version", "evidence_hash")):
                    errors.append(f"{trp} predicted trait requires source/tool/model/hash provenance")
                if klass == "OBSERVED" and not all(trait.get(x) for x in ("trait_source", "source_record_id", "source_tool", "evidence_hash")):
                    errors.append(f"{trp} observed trait requires source/tool/hash provenance")
                trait_level = RESOLUTION_LEVEL.get(trait.get("trait_resolution"), -1)
                if trait_level > host_level:
                    errors.append(f"{trp} trait resolution cannot exceed host identity resolution")
                if trait.get("used_for_hard_filtering") or trait.get("used_for_ranking") or trait.get("direct_target_degradation_claim"):
                    errors.append(f"{trp} violates trait redline")
            source_signatures.add(aggregate.get("source_signature"))

    selection = document.get("selection_policy", {})
    if selection.get("llm_changes_order") or selection.get("trait_score_used") or selection.get("hard_filter_used"):
        errors.append("selection policy violates teacher D7 redline")

    for index, record in enumerate(document.get("evidence_records", [])):
        ep = f"/evidence_records/{index}"
        evidence_id = record.get("evidence_id")
        if evidence_id in evidence_ids:
            errors.append(f"duplicate evidence_id {evidence_id}")
        evidence_ids.add(evidence_id)
        if record.get("query_id") != query_id:
            errors.append(f"{ep}/query_id mismatch")
        if record.get("route_id") is not None and record.get("route_id") not in route_ids:
            errors.append(f"{ep}/route_id unresolved")
        if record.get("reaction_task_id") is not None and record.get("reaction_task_id") not in task_ids:
            errors.append(f"{ep}/reaction_task_id unresolved")
        if record.get("enzyme_uid") is not None:
            task_id = record.get("reaction_task_id")
            if task_id is None or (task_id, record.get("enzyme_uid")) not in enzyme_pairs:
                errors.append(f"{ep}/enzyme_uid is not linked to the stated reaction task")
        if record.get("source_signature") is not None and record.get("source_signature") not in source_signatures:
            errors.append(f"{ep}/source_signature unresolved")

    return errors


def validate(schema: dict, document: dict) -> list[str]:
    return _schema_errors(schema, document) + semantic_errors(document)


def _pointer_parent(document, pointer: str):
    parts = [part.replace("~1", "/").replace("~0", "~") for part in pointer.split("/")[1:]]
    target = document
    for part in parts[:-1]:
        target = target[int(part)] if isinstance(target, list) else target[part]
    return target, parts[-1]


def apply_mutation(document: dict, spec: dict) -> dict:
    mutated = copy.deepcopy(document)
    parent, key = _pointer_parent(mutated, spec["path"])
    operation = spec["operation"]
    if operation == "remove":
        parent.pop(int(key)) if isinstance(parent, list) else parent.pop(key)
    elif operation in {"replace", "add"}:
        if isinstance(parent, list):
            if operation == "add" and key == "-":
                parent.append(spec["value"])
            else:
                parent[int(key)] = spec["value"]
        else:
            parent[key] = spec["value"]
    else:
        raise ValueError(f"unsupported operation: {operation}")
    return mutated


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--schema", type=Path, default=HERE / "THREE_MODULE_EVIDENCE_CHAIN_SCHEMA.json")
    parser.add_argument("--document", type=Path, default=HERE / "VALID_EXAMPLE.json")
    parser.add_argument("--negative-specs", type=Path)
    args = parser.parse_args()
    schema, document = _json(args.schema), _json(args.document)
    base_errors = validate(schema, document)
    if base_errors:
        print("VALIDATION_FAIL")
        print("\n".join(base_errors))
        return 1
    print("VALIDATION_PASS")
    if args.negative_specs:
        failures = []
        count = 0
        for line in args.negative_specs.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            count += 1
            spec = json.loads(line)
            errors = validate(schema, apply_mutation(document, spec))
            if not errors:
                failures.append(spec["case_id"])
            else:
                print(f"NEGATIVE_CAUGHT {spec['case_id']}: {errors[0]}")
        if failures:
            print("NEGATIVE_MISSED " + ",".join(failures))
            return 1
        print(f"NEGATIVE_PASS {count}/{count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
