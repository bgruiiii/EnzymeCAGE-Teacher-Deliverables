# T6-R3-R1操作员立即停止与§8检查点收包指令

日期：2026-09-11

性质：用户即时裁定；高于当前T6-R3-R1 prompt中“继续§8—§14”的执行安排，但不改变黄老师authority、老师固定拓扑、科学结果或禁止事项

目标：停止当前执行器继续长时间规划/开发，保存截至当前的全部真实结果、失败、脚本、patch、命令与耗时，返回一个可供本地审计和另一执行器接手的检查点包

## 0. 立即执行

```text
不要再开始任何新的scientific command、test group、mutation、validator开发或最终closure任务。
不要继续§8剩余场景、§10、§11、§12—§14。
不要重新运行E0、157项、资产哈希、native load或GPU forward。
不要修改老师graph/state/router/edge、冻结SOURCE_PATCH、wrapper、模型、checkpoint或大资产。
不要删除、覆盖、回滚或清理当前RUN_ROOT中的任何证据。
```

如果此刻有一个已经启动的真实命令：

1. 先记录PID、完整非敏感argv、start UTC、当前UTC、阶段、stdout/stderr路径。
2. 若它正在进行原子写入或即将在10分钟内自然结束，最多等待10分钟让该命令结束，然后停止。
3. 若超过10分钟仍运行，先发送一次可恢复的`SIGINT`，等待最多60秒；保存exit和完整stdout/stderr。
4. 只有进程对`SIGINT`无响应且用户数据无损时才可`SIGTERM`；不得`SIGKILL`模型/写包进程，不得杀其他任务。
5. 明确写`INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT`，不能把中断写成科学FAIL。

随后只做轻量只读收集和检查点打包。不得继续深度思考如何完成原任务。

## 1. 原任务与检查点路径

原任务：

```text
ORIGINAL_TASK_ID=enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910
ORIGINAL_WORK_ROOT=/usrdata/EnzymeCAGE_data/workspaces/${ORIGINAL_TASK_ID}
ORIGINAL_RETURN_DIR=/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries/${ORIGINAL_TASK_ID}
```

检查点使用全新路径：

```text
CHECKPOINT_TASK_ID=enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911
CHECKPOINT_WORK=/usrdata/EnzymeCAGE_data/workspaces/${CHECKPOINT_TASK_ID}
CHECKPOINT_RETURN_ROOT=/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries
CHECKPOINT_DIR=${CHECKPOINT_RETURN_ROOT}/${CHECKPOINT_TASK_ID}
CHECKPOINT_ARCHIVE=${CHECKPOINT_RETURN_ROOT}/${CHECKPOINT_TASK_ID}.tar.gz
CHECKPOINT_IDENTITY=${CHECKPOINT_ARCHIVE}.identity.txt
CHECKPOINT_VALIDATION=${CHECKPOINT_ARCHIVE}.validation.txt
```

这五个新检查点路径任一已存在就只打印`BLOCKED_CHECKPOINT_TARGET_COLLISION`并停止；不删除、不覆盖、不自动改名。

只允许创建`CHECKPOINT_WORK`、`CHECKPOINT_DIR`和外置三文件。原任务工作区和返回目录从此只读。

## 2. 先写一句话状态，不得美化

`CHECKPOINT_DIR/FINAL_STATUS.txt`第一行固定：

```text
T6_R3_R1_CHECKPOINT_INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT
```

随后必须从实物填写，未知就写`UNKNOWN_NOT_YET_AUDITED`：

```text
ORIGINAL_TASK_ID=
CHECKPOINT_UTC=
LAST_COMPLETED_STAGE=
CURRENT_OR_INTERRUPTED_STAGE=
STOP_REASON=USER_REQUESTED_CHECKPOINT_DUE_TO_EXECUTOR_DELAY
T6_FINAL_READY=false
G7_PASSED=false
NOT_A_FINAL_T6_DELIVERY=true
PYTHON_ENVIRONMENT_PREFLIGHT=
UNIFIED_GRAPH_RUNTIME=
TEACHER_FIXED_TOPOLOGY=
COMPONENT_TESTS=
FIXED_ASSET_IDENTITY=
T3B_NATIVE_LOAD=
UID_SEQUENCE_GVP_POCKET_ESM=
T3B_BOUNDED_FORWARD=
REAL_LANGGRAPH_COMPILE=
REAL_LANGGRAPH_INVOKE=
REAL_LANGGRAPH_STREAM_TO_TERMINAL=
REAL_SMOKE_RECORDS=
TEST_01_TO_20=
C8_TO_T5_REAL_CONTINUOUS_REGRESSION=
GSCHEMA=
DETERMINISM=
MUTATION=
ACCESS_AUDIT=
PERSISTENT_INPUT_NONMUTATION=
```

不能因为UI显示17/21就推算任何PASS。只认当前文件、日志和进程实物。

## 3. 必须生成的检查点摘要

### 3.1 `CURRENT_PROGRESS.json`

每个§0—§14阶段记录：

```text
stage_id
name
status=PASS/FAIL/BLOCKED/PARTIAL/NOT_RUN/INTERRUPTED/UNKNOWN
started_utc
ended_utc
elapsed_seconds
command_ids
output_files
evidence_sha256
first_error
notes
```

区分：真实运行PASS、仅组件PASS、证据已生成但未审计、UI待办状态。不得用一个`completed=true`覆盖差异。

### 3.2 `CURRENT_PROGRESS_HUMAN_READABLE.md`

用白话回答：

```text
现在真正做到哪一步；
环境、老师拓扑、157项、资产、native load是否通过；
§7三GPU 6/6 forward是否真实完成，输出和耗时如何；
§8已经真实执行了哪些compile/invoke/stream/smoke/test，哪些只是写了脚本；
当前有没有命令仍运行；
为什么停止；
未完成的§8、§10、§11、§12—§14分别是什么；
哪些结果可由下一执行器直接复用，哪些必须真实续跑。
```

### 3.3 `REMAINING_WORK.md`

只列未完成内容，不重新设计方案。至少按：

```text
P0 scientific remaining
P1 evidence/delivery remaining
P2 nonblocking
```

并为每项列：入口、依赖、预计命令、已有可复用输入、禁止重做的阶段。

## 4. 必须保存§7和§8真实证据

复制到检查点包时保留相对路径和原始bytes；不得改写日志：

```text
PYTHON_RUNTIME_PREFLIGHT.json
PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv
ENTRYPOINT_IMPORT_IDENTITIES.csv
OPTIONAL_DEPENDENCY_REFERENCE_AUDIT.json
UNIFIED_GRAPH_RUNTIME_GATE.json
PYTHON_COMMAND_AUDIT.csv
TEACHER_FIXED_TOPOLOGY_IDENTITY.json
SOURCE_PATCH.diff
T6_INCREMENTAL_PATCH.diff
CHANGED_FILES.csv
PREFREEZE/组件回归日志和逐test解析表
固定资产身份和hash ledger
UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json
NATIVE_LOAD_PER_ROW_TENSORS.csv
native load原始日志和采纳/supersedes记录
GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv
T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl
每个worker目录中的result/base/repeat/sequence gate/stdout/stderr
原始run_gpu_worker.py
派生worker及原件到派生件diff
GRAPH_TOPOLOGY.json（若已有）
GRAPH_CALLABLE_IDENTITIES.csv（若已有）
REAL_LANGGRAPH_INVOKE_TRACE.jsonl（若已有，哪怕partial）
REAL_LANGGRAPH_STREAM_TRACE.jsonl（若已有，哪怕partial）
NODE_STATE_TRANSITIONS.jsonl（若已有）
REAL_SMOKE_INPUTS.csv / REAL_SMOKE_OUTPUTS.jsonl（若已有）
TEST_CASE_MATRIX.csv / TEST_RESULTS.txt（若已有）
C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json（若已有）
SCHEMA_VALIDATION_REPORT.json（若已有）
DETERMINISTIC_ORDER_CHECK.json（若已有）
MUTATION_CHECK.json（若已有）
ACCESS_AUDIT.jsonl（若已有）
PERSISTENT_SOURCE_NONMUTATION.json（若已有）
所有task-local scripts及其SHA
```

文件不存在时不要创建假占位覆盖事实；在`MISSING_EXPECTED_EVIDENCE.csv`逐项记录`NOT_CREATED_YET`。

不得打包55GB大资产、checkpoint、模型、venv、T4/T6受限原件或credential。对大资产只带已有identity/registry，不重新计算SHA。

## 5. 保存80个变更的准确边界

生成：

```text
STAGED_REPO_GIT_IDENTITY.txt
STAGED_REPO_STATUS_PORCELAIN.txt
STAGED_REPO_TRACKED_DIFF.patch
STAGED_REPO_UNTRACKED_FILES.csv
CHANGED_FILE_CLASSIFICATION.csv
```

`CHANGED_FILE_CLASSIFICATION.csv`每项列：

```text
path
tracked/untracked
bytes
SHA256（仅文件<=50MiB；更大复用已有身份并标NOT_REHASHED_CHECKPOINT）
class=scientific_source/test/task_driver/report/log/cache/large_asset/reference/unknown
introduced_stage
required_for_resume
teacher_topology_file
production_or_formal_path
```

对所有task-local source/test/driver文件实际复制入包；cache、pyc、模型和大资产不复制。老师固定`graph.py/state.py/multi_step_bridge_node.py/schemas/bridge.py`只记录pre/post SHA，不改动。

## 6. 专门记录到底哪里耗时

生成：

```text
COMMAND_TIMELINE.csv
PROCESS_SNAPSHOT_AT_STOP.csv
PHASE_TIMING_BREAKDOWN.csv
LLM_OR_EXECUTOR_DELAY_OBSERVATIONS.md
```

`COMMAND_TIMELINE.csv`必须从现有command log、shell/history/task日志和文件时间恢复，不能伪造；每行：

```text
command_id
phase
argv_redacted
start_utc
end_utc
elapsed_seconds
exit_code
stdout_path/SHA
stderr_path/SHA
category=CPU/GPU/IO/HASH/NETWORK/TEST/PACKAGE/UNKNOWN
```

`LLM_OR_EXECUTOR_DELAY_OBSERVATIONS.md`只写可证明事实：

```text
总wall time；
可由命令解释的时间；
无命令/进程/I/O证据覆盖的空窗时间；
重复修改同一脚本次数；
validator失败/重写次数；
是否存在模型未运行但长时间等待；
哪些空窗无法从现有日志归因。
```

不得自行断言Qoder、LLM、用户或科学模型负责；只留证供本地审计裁定。

## 7. 可接续性检查

生成`RESUME_READINESS.json`：

```text
original_work_root_exists
original_work_root_frozen_readonly_or_hash_anchored
staged_repo_exists
base_commit/tree
source_patch_sha
teacher_topology_unchanged
python_absolute_path
python_overlay_order
runtime_preflight_pass
fixed_assets_registry_present
native_evidence_present
forward_evidence_present
forward_6_of_6_if_true
graph_scripts_present
remaining_stage_entrypoint
safe_to_resume_without_repeating_E0_E7
unsafe_reasons
```

只有所有引用证据存在时才可写`safe_to_resume_without_repeating_E0_E7=true`。这只是接续准备状态，不是T6 PASS。

## 8. 最小检查点验证与三文件

本次不开发复杂scientific validator、不跑mutation、不重放模型。只做机械验证：

```text
包内文件来自当前实物且SHA匹配；
CURRENT_PROGRESS引用的路径存在或列入missing表；
FINAL_STATUS没有T6/G7虚假PASS；
teacher topology pre/post SHA未变；
无credential/大资产/model/checkpoint/venv/T4 restricted内容；
MANIFEST.files覆盖包内全部regular files并包含两个manifest；
MANIFEST.sha256排除自身、覆盖其余全部regular files；
archive安全、单根；
identity与archive bytes/SHA/root/file count一致；
validation明确CHECKPOINT_ONLY、NOT_FINAL、未运行scientific replay。
```

固定closure：

```text
先完成所有检查点文件；
写FINAL_STATUS；
生成manifest；
创建archive；
fresh unpack核安全和manifest；
从落盘archive写identity；
写validation；
只读复核三文件。
```

validation最终必须包含：

```text
CHECKPOINT_PACKAGE_VALIDATION=PASS
SCIENTIFIC_REPLAY=NOT_RUN_PER_OPERATOR_STOP
T6_FINAL_READY=false
G7_PASSED=false
NOT_A_FINAL_T6_DELIVERY=true
```

## 9. 最终只打印

```text
CHECKPOINT_ARCHIVE=<absolute path> bytes=<n> SHA256=<64hex>
CHECKPOINT_IDENTITY=<absolute path> bytes=<n> SHA256=<64hex>
CHECKPOINT_VALIDATION=<absolute path> bytes=<n> SHA256=<64hex>
LAST_COMPLETED_STAGE=<value>
CURRENT_OR_INTERRUPTED_STAGE=<value>
T3B_FORWARD=<observed value>
REAL_LANGGRAPH=<observed value>
TEST_01_TO_20=<observed value>
SAFE_TO_RESUME_WITHOUT_REPEATING_E0_E7=<true/false>
UNEXPLAINED_WALL_TIME_SECONDS=<n or UNKNOWN>
FINAL_STATUS=T6_R3_R1_CHECKPOINT_INTERRUPTED_BY_OPERATOR_FOR_PERFORMANCE_AUDIT
```

然后停止。不要继续原任务，不上传GitHub，不反馈黄老师，不运行DBP/SCNET/T4。
