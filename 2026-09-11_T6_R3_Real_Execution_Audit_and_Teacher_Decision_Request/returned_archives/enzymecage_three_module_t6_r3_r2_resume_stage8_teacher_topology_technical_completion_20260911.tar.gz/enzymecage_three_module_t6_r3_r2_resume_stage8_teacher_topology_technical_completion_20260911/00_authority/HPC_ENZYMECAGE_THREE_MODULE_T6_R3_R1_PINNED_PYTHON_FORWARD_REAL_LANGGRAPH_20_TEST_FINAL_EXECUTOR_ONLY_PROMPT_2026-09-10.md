# HPC executor-only prompt：T6-R3-R1锁定历史成功Python、真实forward、LangGraph、20项与最终三文件

日期：2026-09-10

执行者：Chenyu AI / executor only

任务类型：一次性完成T6-R3首轮环境阻塞修复与剩余真实整链；不是只做环境报告，不是只补sidecar

## 0. 唯一目标

T6-R3首轮已经诚实停止在：

```text
T3B_NATIVE_LOAD=PASS_3_OF_3
T3B_BOUNDED_FORWARD=FAIL_0_OF_6
ROOT_CAUSE=ModuleNotFoundError: No module named 'ase'
```

本轮只修复“没有锁定历史成功EnzymeCAGE解释器”这一执行入口问题。先在任何大资产加载和模型初始化之前完成秒级/分钟级环境硬门；通过后，在同一轮继续完成原T6-R3全部合同：

```text
fresh teacher exact base
→ 应用首轮已组件验证的冻结累计SOURCE_PATCH.diff
→ 固定Python环境下相关CPU回归
→ 3/3 T3B native load和逐UID资产硬门
→ 3个隔离GPU worker完成6个唯一(reaction_task_id, UID)的真实五seed forward与repeat
→ 老师真实StateGraph compile + invoke + stream到终态
→ 8条真实smoke
→ TEST-01—TEST-20
→ C8→T5真实连续回归
→ G-SCHEMA / determinism / mutation / access / persistent nonmutation
→ archive / identity / validation三文件。
```

不得只修`ase`后重新封一个forward包。环境门通过后必须继续剩余整链，直到READY或新的首个真实P0硬门。

## 1. Authority payload与优先级

输入：

```text
t6_r3_r1_teacher_authority_r3_blocked_audit_and_successful_forward_runtime_payload_20260910.tar.gz
bytes=28415
SHA256=18e59c90d5f44d97cd05d02013593c0ba653e46f495a3335b0e9de3d025c5a95
single root=t6_r3_r1_teacher_authority_r3_blocked_audit_and_successful_forward_runtime_payload_20260910/
regular members=7
```

七个成员必须逐字节命中：

```text
TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md
  bytes=5995
  SHA256=953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4

ENZYMECAGE_THREE_MODULE_T6_R3A_R2A_R3_CLEAN_EXTERNAL_VALIDATION_ORDER_THREE_FILE_FINAL_RETURN_LOCAL_AUDIT_2026-09-10.md
  bytes=4974
  SHA256=30c9711042daf0e5ddfff53ddf3bb3af0827d46bcae7cefde5d575c00904ba80

ENZYMECAGE_THREE_MODULE_T6_R3_TEACHER_FIXED_TOPOLOGY_REAL_LANGGRAPH_20_TEST_FINAL_RETURN_LOCAL_AUDIT_2026-09-10.md
  bytes=9636
  SHA256=279ec84158b481aa664de18ddc13ef6c536f540a53f7014f37420dbb9de47634

HPC_ENZYMECAGE_THREE_MODULE_T6_R3_TEACHER_FIXED_TOPOLOGY_REAL_LANGGRAPH_20_TEST_FINAL_EXECUTOR_ONLY_PROMPT_2026-09-10.md
  bytes=12392
  SHA256=0dd2c83d203b936a44640e5c33820377b9979cb7d0cd2d000aed16ebae1aa763

HPC_ENZYMECAGE_THREE_MODULE_T6_REAL_LANGGRAPH_20_TEST_EIGHT_RECORD_END_TO_END_SMOKE_EXECUTOR_ONLY_PROMPT_2026-09-08.md
  bytes=20806
  SHA256=ab4aa93d174fdf33e198c4f70abdd8c220523a60d0ded26964e2988a12901b38

ENZYMECAGE_THREE_MODULE_T6_R1_MULTI_GPU_FORWARD_RECOVERY_RETURN_LOCAL_AUDIT_2026-09-08.md
  bytes=8362
  SHA256=6059a95858936b3e2cd980451654b6d310cbd1350aa0f65d4521ddb1d6f1271b

enzymecage_three_module_t6_r3_teacher_fixed_topology_real_langgraph_20_test_final_20260910.tar.gz.identity.txt
  bytes=470
  SHA256=4a86bdb7a5547e74e8306c8bd496a3afe8ba23f20e6d793a54ed2111141e8abb
```

优先级：

```text
黄老师09-09原件
> T6-R3首轮本地审计
> pre-R3最终审计
> 本R1 prompt
> T6-R3首轮prompt
> 原TEST-01—20合同
> 历史T6-R1 forward审计（只用于环境/运行入口证据）
```

老师拓扑、公共对象和科学测试不因本轮改变。本轮不能重新解释老师合同。

## 2. Fresh路径

```bash
TASK_ID=enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910
ROOT=/usrdata/EnzymeCAGE_data/EnzymeCAGE-master
WORK_ROOT=/usrdata/EnzymeCAGE_data/workspaces/${TASK_ID}
STAGED_REPO=${WORK_ROOT}/depending_teacher_fixed_r1
INPUT_ROOT=${WORK_ROOT}/inputs
RUNTIME_ASSETS=${WORK_ROOT}/runtime_assets
RETURN_ROOT=${ROOT}/HPC_Returned_Result_Summaries
RETURN_DIR=${RETURN_ROOT}/${TASK_ID}
ARCHIVE=${RETURN_ROOT}/${TASK_ID}.tar.gz
IDENTITY=${ARCHIVE}.identity.txt
VALIDATION=${ARCHIVE}.validation.txt
AUTHORITY_PAYLOAD=${ROOT}/HPC_Inputs/t6_r3_r1_teacher_authority_r3_blocked_audit_and_successful_forward_runtime_payload_20260910.tar.gz

FAILED_R3=${RETURN_ROOT}/enzymecage_three_module_t6_r3_teacher_fixed_topology_real_langgraph_20_test_final_20260910.tar.gz
FAILED_R3_ID=${FAILED_R3}.identity.txt
HISTORICAL_FORWARD=${RETURN_ROOT}/enzymecage_three_module_t6_r1_two_to_three_single_gpu_worker_parallel_forward_recovery_20260908.tar.gz
PRER3=${RETURN_ROOT}/enzymecage_three_module_t6_r3a_r2a_r3_clean_external_validation_order_three_file_final_20260910.tar.gz
```

以下任一路径或同basename临时文件存在即在写任何东西前停止：

```text
WORK_ROOT
RETURN_DIR
ARCHIVE
IDENTITY
VALIDATION
VALIDATION.tmp / .partial / .failed / .bak
```

输出`BLOCKED_NONFRESH_TARGET`，不得删除、覆盖、续跑或自动改名。

## 3. 绝对红线

```text
不修改老师graph/state/router/edge；
不修改pre-R3 microbe科学代码；
不修改EnzymeCAGE模型、schnet.py或wrapper来绕过ase；
不pip/conda/apt安装、升级、卸载任何包；
不从网络下载环境、模型、checkpoint或资产；
不重启/重建/访问127.0.0.1:8001；
不训练、不backward、不调参；
不运行T4，不读取T4 gold/restricted；
不merge production，不push；
不复用首轮RETURN_DIR作为新结果目录；
不把历史T6-R1的6/6复制成本轮forward证据；
不把组件测试写成真实整链通过；
不使用or True、if True、空all、固定PASS列表或异常即PASS。
```

历史包仅用于确定“哪个环境曾经成功”以及核对输出结构；本轮所有forward、LangGraph和终验必须真实重新执行。

## 4. Phase E0：计算前Python/入口硬门

### 4.1 唯一默认解释器

固定：

```bash
PY=/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python
```

历史证据：2026-09-08同一host、相同GPU 0/1/2、相同三反应和相同wrapper由该绝对解释器完成6/6 forward；T6-R2也以该解释器运行真实LangGraph 1.2.9。

在本任务中：

```text
所有Python科学命令、测试、worker、graph、validator和打包脚本必须以${PY}绝对路径启动；
禁止裸python、python3、/usr/bin/python、/usr/bin/python3；
禁止子进程隐式继承错误sys.executable；launch argv第一项必须等于readlink -f(${PY})或记录的同一解释器；
shell/tar/git/sha256sum/nvidia-smi可直接调用；
PYTHONDONTWRITEBYTECODE=1；所有cache/temp重定向到WORK_ROOT。
```

若`${PY}`不存在、不可执行或realpath异常，不尝试安装，立即快速封包：

```text
BLOCKED_ENVIRONMENT_INTERPRETER_MISSING
```

### 4.2 必须在大文件读取和模型初始化前完成的探针

使用`${PY}`一次性生成：

```text
PYTHON_RUNTIME_PREFLIGHT.json
PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv
ENTRYPOINT_IMPORT_IDENTITIES.csv
ENVIRONMENT_PREFLIGHT_STDOUT.txt
```

必须记录并验证：

```text
sys.executable绝对路径与realpath；
sys.prefix / sys.base_prefix；
Python版本；
每个模块的version和module.__file__；
ase；
torch；
torch_geometric；
rdkit；
numpy；
pandas；
yaml/PyYAML；
pydantic；
langgraph.graph.StateGraph；
jsonschema；
sklearn；
xgboost；
lightgbm（信息项；仅在真实调用闭包有引用时才是硬门）；
joblib；
scipy；
EnzymeCAGE代码根/root/projects/EnzymeCAGE-master；
D4 wrapper目录及enzymecage_wrapper.predictor/schema；
import enzymecage.model；
import enzymecage.schnet；
torch.cuda.is_available()；
torch.cuda.device_count()；
GPU 0/1/2 UUID与历史冻结UUID；
pytest是否存在只作信息；pytest缺失不是阻塞，允许用unittest/正式self-runner。
```

只允许为了import检查向`sys.path`加入这两个明确路径：

```text
/root/projects/EnzymeCAGE-master
/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries/d4b1a_wrapper_hash_relative_path_final_package_correction_20260716
```

EnzymeCAGE正式入口固定为：

```text
wrapper package=/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries/d4b1a_wrapper_hash_relative_path_final_package_correction_20260716/enzymecage_wrapper
predictor.py bytes=7616 SHA256=b9877649deea4f929778331453a0f1f4eb73d72529e3f1c4b95d0a56c4ab82d3
schema.py bytes=1310 SHA256=a27f33adf78bb2c7a9961d4372cfea0f7728ca91eb89e3b0a6cc7a1e6488fc35
utils.py bytes=2046 SHA256=732fb1ca4ba19c0a2238b9b7fb7a551d29893c518890199156521af7ba68cfc2
runtime constructor=enzymecage_wrapper.predictor.initialize_runtime(v1_overlay)
request class=enzymecage_wrapper.schema.EnzymeCAGERequest
model call=runtime.predict(request)
model version=v1_20260714
```

若目录位置不同，只能通过D4 wrapper tar固定SHA和包内manifest定位相同字节；三份source SHA必须一致。禁止换用项目中其他同名wrapper、`infer.py`或临时自写模型入口。

此阶段不得调用`initialize_runtime()`、不得加载checkpoint、不得加载16GB/37GB protein资产。目标是在几十秒内捕获`ase`、PyG、Pydantic、LangGraph等缺依赖。

依赖分级必须基于本轮解析后的真实入口和调用闭包，不按工具名称猜依赖：

```text
CORE_REQUIRED：ase、模型模块、wrapper、PyTorch/PyG、RDKit、Pydantic、LangGraph；
ACTUAL_ROUTE_REQUIRED：xgboost（现场环境预期版本3.3.0，记录真实version/path）；
REFERENCE_CONDITIONAL：yaml/jsonschema/sklearn/joblib/scipy等，若当前source/test入口实际引用则必须import；零引用可记UNREQUIRED；
LIGHTGBM：当前冻结patch、wrapper和历史成功forward证据均为零引用。若完整实际代码根/老师tree/固定patch/wrapper/历史成功包继续0引用，则允许NOT_IMPORTABLE_UNREQUIRED，不阻塞。
```

LightGBM零引用判断必须输出`OPTIONAL_DEPENDENCY_REFERENCE_AUDIT.json`，范围至少包括：

```text
EnzymeCAGE code root；
fresh teacher staged tree；
fixed SOURCE_PATCH.diff / T6_INCREMENTAL_PATCH.diff；
D4 wrapper；
实际加载的depending v3.2 adapter模块；
历史成功T6-R1包中的source/driver文本。
```

必须保存真实`import lightgbm` traceback。只有引用计数全部为0时，才可写：

```text
LIGHTGBM_IMPORT=NOT_IMPORTABLE_UNREQUIRED
LIGHTGBM_REFERENCE_COUNT=0
LIGHTGBM_GATE=NOT_APPLICABLE
```

这不是用xgboost“替代LightGBM”，而是确认实际链本来只依赖xgboost。不得把LightGBM写PASS，也不得写成老师豁免。如果发现任何真实LightGBM引用，缺import立即阻塞。

硬门：CORE_REQUIRED、实际被引用的REFERENCE_CONDITIONAL、xgboost任一import失败，或CUDA/GPU UUID不成立，写真实traceback并停止：

```text
BLOCKED_ENVIRONMENT_PREFLIGHT_<MODULE_OR_GPU>
```

不得退回系统Python，不得安装缺失包。

### 4.3 Graph统一运行时门

用同一个`${PY}`在fresh staged tree建成后再次验证：

```text
真实import langgraph.graph.StateGraph；
真实import老师src.graph和build_graph_t6/build_graph；
真实importT2/T5/microbe/trait节点；
真实importEnzymeCAGE wrapper和模型模块；
所有module.__file__命中预期staged/source/wrapper路径；
没有同名fake/stub/本地遮蔽模块。
```

如果同一`${PY}`不能同时承载老师graph和真实EnzymeCAGE节点，输出`BLOCKED_NO_UNIFIED_GRAPH_RUNTIME`。不得自行增加subprocess替代节点、不得修改graph/state来跨环境。

## 5. Phase E1：固定输入、source与老师拓扑

在Phase E0通过后再做。

### 5.1 首轮blocked包

必须核：

```text
FAILED_R3 bytes=154506
FAILED_R3 SHA256=74b5a2bf22673a3644cbb55bb5cded64e2cbea84a4d4cdbfc3f59eac8168e2f4
FAILED_R3_ID SHA256=4a86bdb7a5547e74e8306c8bd496a3afe8ba23f20e6d793a54ed2111141e8abb
FAILED_R3 CONTENT_STATUS=BLOCKED_AT_T3B_FORWARD
```

安全解包到`INPUT_ROOT`，拒绝absolute/`..`/symlink/hardlink/device/FIFO。已知首轮manifest只覆盖66/68：必须验证其中列出的66个SHA全部成立，同时把两个manifest自身未列入记作已知输入P1；不得因此拒绝读取已审计的`SOURCE_PATCH.diff`。

固定复用：

```text
SOURCE_PATCH.diff
bytes=381120
SHA256=074f5c31d516e1f699648008ed86767244e25fb128905e119366ad346f8f027a

T6_INCREMENTAL_PATCH.diff
bytes=120528
SHA256=c718f8d7df2b670b057122060e16d8c703d168234409602080437346f1d6154d

scripts/run_gpu_worker.py
bytes=13037
SHA256=79fb9ba2f5ec8ec33ca4bc86441f8ff4ab0ff1d4eedf7d549704aa1994fb5fdd
```

本轮直接将固定`SOURCE_PATCH.diff`应用到teacher exact base，不重新做T2/T5语义合并，不修改patch内容。它已在首轮通过157项相关组件检查，本地审计确认未触及老师固定拓扑文件。

### 5.2 teacher exact base的快速、确定性取得

固定：

```text
teacher remote=git@github.com:Water-Quality-Risk-Control-Engineering/depending.git
BASE_COMMIT=2d4cc766322a6a01b8a88491aed07536b3b0a320
BASE_TREE=c0acb9bd30b985ad43bf969946842da97a68a400
```

先以有界网络尝试fresh clone，单次超时60秒，最多两次。若网络失败，允许从以下已存在Git对象库只读定位精确commit：

```text
/root/projects/depending
/root/projects/enzymecage_crew
首轮T6-R3 workspace中的Git对象库（只读，若仍存在）
```

本地fallback必须：

```text
git cat-file -e BASE_COMMIT^{commit}=PASS；
git rev-parse BASE_COMMIT^{tree}=BASE_TREE；
source repo的remote URL经脱敏后对应老师depending仓库；
用git clone --no-hardlinks创建全新STAGED_REPO；
checkout --detach BASE_COMMIT；
HEAD/tree/clean全部PASS。
```

不得在既有repo上pull/fetch/reset/clean/stash，不得按branch当前HEAD猜测。如果远端和本地对象均不可用，快速`BLOCKED_TEACHER_BASE_UNAVAILABLE`。

### 5.3 patch与拓扑硬门

```text
git apply --check fixed SOURCE_PATCH.diff；
git apply fixed SOURCE_PATCH.diff；
git diff --binary BASE_COMMIT重新生成的累计patch SHA必须仍为074f5c31...或逐文件最终SHA完全相同；
changed set必须与首轮CHANGED_FILES.csv科学source集合一致；
src/graph.py、src/state.py、src/nodes/multi_step_bridge_node.py、src/schemas/bridge.py必须与BASE_COMMIT逐字节一致；
老师节点/edge顺序必须与base一致；
不得新增public state key。
```

任一失败立即`BLOCKED_SOURCE_OR_TEACHER_TOPOLOGY_IDENTITY`，不自动合并或改patch。

## 6. Phase E2：一次CPU回归与资产前门

### 6.1 CPU回归只跑一次

所有命令明确使用`${PY}`，禁止系统Python。运行并保存逐测试原始输出、argv、cwd、UTC、exit、stdout/stderr SHA：

```text
pre-R3 16项；
pre-R3 R1 50项；
G2 4项；
G5 7项；
T5 C8 adapter 32项；
T5 route-step aggregator 42项；
T5 trait node 6项；
T2 v3.2 real adapter及repeat。
```

总数应为157个具名组件检查。不能只写`COMPONENT_TESTS_PASS=157`；必须从日志重新解析每个具名test/assertion和exit。首轮`/usr/bin/python: No module named pytest`不得复制进当前成功日志，本轮也不得运行裸`/usr/bin/python`命令。

CPU回归通过后冻结source。后续报告或sidecar问题不得再修改source。

### 6.2 固定资产身份

继续使用T6-R3首轮prompt §4全部固定SHA，包括：

```text
T2D/T3A/T3B/T3B-R1/T5A-R2/T5B-R2/T5C-R2 archives；
UID map SHA256=7b92e8e625cb73f070c8e902687ea5bbdbf749f04a19828e550e3fe205684fe6；
C8 lookup SHA256=d51a540db2f9798d65e25b46f22960ba29ae2d4b288be218c83c299f24f5d5af；
D4 wrapper tar SHA256=12df378964793561c2d193d92c16276739b14df1761ff34c0e46f426e5cad0f7；
V1 archive SHA256=cc2103e17389baca02ec11df150a413350c09bacad87b7de59ffdfd644a73893；
五个seed40—44 checkpoint身份沿用历史成功T6-R1并重新核实。
```

checkpoint必须分别为72,266,498 bytes并命中：

```text
seed40=a95d4687e2cadad1c12f7c1defd21dbdf43db3cce96aa9caace39dbcc226586d
seed41=c429a98bc265e20d415c3d6f479e0f0d6c47d81c13135c589e2a5e173978dbef
seed42=cc54be33a23b78fb89c183f0bca6f87b442a5be4dad9666428d05a72a9b7f7a3
seed43=3eb80be83cb41574204239c80f11008f728029dd9e4ba14c639749d8176b5220
seed44=b9547d3ba17725a5910cf243d33af9367abb12b3215f4b526405f8bdb14acd16
```

所有路径必须由固定SHA定位，不能按`latest`、mtime或相似名称猜。

### 6.3 native load与逐UID ESM硬门

三条固定反应和UID顺序沿用原合同，不得更换样本。真实调用`load_geometric_dataset`，但本轮必须修正首轮只检查`dataset[0]`的证据不足：

```text
每个reaction dataset length=3；
逐个dataset row关联真实UID；
逐row保存seq/reaction_feature/node_xyz/esm_feature的shape/dtype/device/finite；
逐UID核sequence非空和冻结SHA；
UID在GVP；
UID在pocket node；
sequence在ESM mean；
ESM mean绝对值和非零；
解释并归属任何`ESM feature not found`日志；
实际进入forward的两个UID不得有zero/missing fallback。
```

将该检查放在GPU runtime初始化之前并输出`UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json`。任一实际forward UID失败，立即`BLOCKED_AT_SEQUENCE_ESM_IDENTITY`；不得启动三个昂贵worker。

## 7. Phase E3：三GPU真实6条forward

必须用`${PY}`绝对路径并行启动3个worker。禁止由系统Python协调器的`sys.executable`代替`${PY}`。每个launch argv第一项、worker内部`sys.executable`、realpath必须一致并写入`GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv`。

固定：

```text
worker0 → physical GPU0 / UUID GPU-c5b417ae-284e-8385-262f-57faf35e3771 / reaction R1；
worker1 → physical GPU1 / UUID GPU-74f9ec77-8678-5c1d-2051-586647300e90 / reaction R2；
worker2 → physical GPU2 / UUID GPU-355dac3b-3ce2-4e25-5247-a913ca688d9e / reaction R3；
每worker只见1张CUDA卡；
每reaction对冻结前两个UID做base + repeat；
唯一(reaction_task_id, UID)=6/6；
5 seeds；
initialize_runtime每worker恰好1次；
eval/no_grad；不训练、不backward；
repeat tolerance=1e-5，不放宽；
每worker超时至少1800秒，不能因历史初始化约287秒而设置过短timeout。
```

每个反应的正式请求固定为：

```text
enzyme_pool_uids=[A0A011QK89, A0A017SP50]
top_k=2
return_ci=true
```

第三个UID `A0A017SR40`仍参与三UID资产身份/native-load完整性检查，但不静默替换上述两个正式forward UID。

使用首轮`run_gpu_worker.py`的科学调用逻辑；只允许在任务本地driver增加`sys.executable`断言、环境证据和新输出路径，不改wrapper、模型或score语义。

必须保存：

```text
每worker完整argv；
PID、start/end UTC和monotonic；
GPU UUID、device name、visible count、memory；
runtime init秒数；
五checkpoint bytes/SHA；
sequence/ESM gate；
每reaction×UID×seed raw score；
base/repeat delta；
forward_executed=true；
forward call count；
stdout/stderr和exit。
```

6/6任一失败，保留真实堆栈并停止后续整链，状态为`BLOCKED_AT_T3B_FORWARD_<PRECISE_REASON>`。即使blocked，也必须执行第10节的完整三文件失败交付。

## 8. Phase E4：继续原T6-R3全部剩余合同

6/6 forward通过后，完整执行T6-R3首轮prompt §7—§10和原合同§3、§5—§7，不得删减：

```text
真实langgraph.graph.StateGraph；
老师真实graph builder；
compile至少1次；
invoke至少1次；
stream至少1次并消费到终态；
8条预注册真实smoke；
C1—C4控制场景；
TEST-01—TEST-20；
真实microbe节点输出→C8 adapter/lookup→F1—F15→T5 route-step aggregator；
official G-SCHEMA Draft202012正负例；
同一8条输入fresh process完整运行两次；
原mutation类别 + TaxID/signature/CRLF/validation/旧route_bridge四类；
access audit；
所有持久输入pre/post SHA零变化。
```

特别边界：

```text
老师G1拓扑不改；
检索/单步成功直连酶池，多步桥只作旁路；
PredictedReaction只认一个定义；
microbe节点以positive NCBI TaxID聚合；
T5 route-step才使用精确signature/resolution/TaxID/name分组；
host只能来自真实microbe节点输出；
C8→T5必须同一真实连续调用链，不能分别跑后拼报告；
reaction_smiles + reaction_sha256必须成对；
UNRESOLVED必须为合法大写字面量；
8001 active dependency/config/request=0；
组件fixture不能替代真实graph输出。
```

每项TEST必须记录test file/function、production callable、input identity、expected、observed、raw log和exit。不能把`PASS_COMPONENT_ONLY`计入最终20/20。

## 9. 一次执行、一次验证，不再制造长时间重复计算

```text
环境import门只跑一次且位于最前；
157项CPU回归只在最终source tree跑一次；
3/3 native load只跑一次；
6/6 forward + required repeat只跑一次正式组；
8条整链的合同要求双run只做规定的两次；
外置validator不得再次加载五checkpoint或重复GPU forward；
外置validator必须验证当前run的不可变raw worker文件、进程/设备/时间/score/checkpoint证据和mutation，而不是第二次烧GPU；
报告、manifest和sidecar错误不得触发模型重算；
所有P0/P1在打包前一次性扫描。
```

这不降低科学门：真实计算仍按合同执行；只是禁止为了外置交付再重复同一昂贵计算。

## 10. 不论READY或BLOCKED都必须完成三文件

首轮缺validation的错误不得重复。无论在环境、source、asset、forward或graph阶段失败，都生成诚实blocked evidence archive和完整三文件。

### 10.1 package manifest

最终archive内所有regular files均纳入：

```text
MANIFEST.files：包含MANIFEST.files和MANIFEST.sha256自身；
MANIFEST.sha256：排除MANIFEST.sha256自身，覆盖其余所有regular files，包括MANIFEST.files；
若regular files=N，则MANIFEST.files=N行、MANIFEST.sha256=N-1行；
sha256sum -c全部PASS。
```

生成最终`FINAL_STATUS.txt`后必须重新生成manifest，之后包内文件不得改变。

### 10.2 clean closure顺序

```text
archive内部只写CONTENT_READY或精确BLOCKED，external=PENDING_AT_ARCHIVE_TIME；
创建archive；
fresh unpack U1核安全、单根、manifest和内容；
从落盘archive真实stat/hash写identity；
确认validation及.tmp/.partial/.failed/.bak均不存在；
pre-write gates只要求archive+identity，不得要求validation存在；
全部通过后exclusive首次写validation(PENDING_POSTWRITE)；
fresh unpack U2做post-write三文件核验；
原子重写一次validation为PASS或精确FAIL；
第三个只读进程final-readonly；
archive/identity/validation同basename、同目录、regular、non-symlink、非空。
```

blocked validation也必须包含：首个失败门、真实expected/observed、traceback、已完成门、未运行门、archive/identity身份、manifest结果、pre/post closure结果。不能因科学失败省略validation。

## 11. Validator与mutation硬规则

正式validator必须从实物计算，禁止读取报告里的结论当输入事实。至少检查：

```text
authority payload及七成员；
FAILED_R3和固定SOURCE_PATCH身份；
PY绝对路径、realpath、sys.executable和必需imports；
teacher BASE_COMMIT/TREE；
老师拓扑四文件字节不变；
157项具名CPU回归；
逐UID/逐row native和ESM门；
3 workers、3 UUID、6 unique pairs、五seed、base/repeat；
真实compile/invoke/stream及终态；
8 smoke；
TEST-01—20恰20个全PASS；
C8→T5连续链；
schema/determinism/mutation/access/nonmutation；
manifest N/N与N-1/N-1；
三文件closure顺序。
```

mutation至少证明以下错误会被拒绝：

```text
sys.executable改成/usr/bin/python；
ase import失败；
worker argv使用裸python；
一个worker GPU UUID错误；
一个UID ESM全零或missing；
一个forward_executed=false；
缺一个unique reaction×UID；
把PASS_COMPONENT_ONLY计入20/20；
manifest漏自身；
validation预创建；
原合同全部scientific mutations。
```

每个mutation独立副本、真实非零exit或指定门FAIL，并命中预期门。不能固定生成PASS。

## 12. 必须返回

继承T6-R3首轮prompt §12和原合同§8全部文件，并新增：

```text
PYTHON_RUNTIME_PREFLIGHT.json
PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv
ENTRYPOINT_IMPORT_IDENTITIES.csv
ENVIRONMENT_PREFLIGHT_STDOUT.txt
PYTHON_COMMAND_AUDIT.csv
UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json
R3_BLOCKED_BASELINE_IDENTITY.json
R3_TO_R1_CHANGED_EXECUTION_ONLY.csv
R3_R1_VALIDATOR_MUTATION_RESULTS.json
OPTIONAL_DEPENDENCY_REFERENCE_AUDIT.json
```

`PYTHON_COMMAND_AUDIT.csv`必须列出每个Python命令的实际argv[0]、子进程内sys.executable、realpath和是否等于`${PY}`。任何科学命令使用系统Python即最终FAIL。

`R3_TO_R1_CHANGED_EXECUTION_ONLY.csv`必须证明source科学patch没有改变；变化只允许task-local driver、环境门、报告、日志、manifest和三文件closure。

## 13. 最终状态

只有全部成立才允许外置validation写：

```text
T6_R3_R1_PINNED_PYTHON_TEACHER_FIXED_TOPOLOGY_FINAL_READY_FOR_LOCAL_AUDIT
PYTHON_ENVIRONMENT_PREFLIGHT=PASS
PYTHON_EXECUTABLE=/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python
ASE_IMPORT=PASS
XGBOOST_IMPORT=PASS
LIGHTGBM_IMPORT=NOT_IMPORTABLE_UNREQUIRED_OR_PASS_IF_ACTUALLY_PRESENT
UNIFIED_GRAPH_RUNTIME=PASS
TEACHER_FIXED_TOPOLOGY=PASS_UNCHANGED
COMPONENT_TESTS=PASS_157
T3B_NATIVE_LOAD=PASS_3_OF_3
UID_SEQUENCE_GVP_POCKET_ESM=PASS
T3B_BOUNDED_FORWARD=PASS_6_OF_6
REAL_LANGGRAPH_COMPILE_INVOKE_STREAM=PASS
REAL_SMOKE_RECORDS=PASS_8_OF_8
TEST_01_TO_20=PASS_20_OF_20
C8_TO_T5_REAL_CONTINUOUS_REGRESSION=PASS
GSCHEMA=PASS
DETERMINISM=PASS
MUTATION=PASS
ACCESS_AUDIT=PASS
PERSISTENT_INPUT_NONMUTATION=PASS
ARCHIVE_MANIFEST=PASS_COMPLETE
EXTERNAL_THREE_FILE_DELIVERY=PASS
T6_OVERALL_READY_FOR_LOCAL_AUDIT=true
G7_PASSED=AWAITING_LOCAL_AUDIT
```

任何P0失败：

```text
BLOCKED_AT_<FIRST_REAL_GATE>
T6_OVERALL_READY_FOR_LOCAL_AUDIT=false
G7_PASSED=false
```

但仍必须完成诚实blocked三文件。不要把P2标题/排版问题升级为失败；P1证据问题在本轮打包前一次修完，不在模型完成后再开R2。

## 14. 最终终端输出

只打印：

```text
ARCHIVE=<absolute path> bytes=<n> SHA256=<64hex>
IDENTITY=<absolute path> bytes=<n> SHA256=<64hex>
VALIDATION=<absolute path> bytes=<n> SHA256=<64hex>
PYTHON_EXECUTABLE=<absolute path>
ENVIRONMENT_PREFLIGHT=<PASS/BLOCKED>
T3B_FORWARD=<PASS_6_OF_6/BLOCKED>
REAL_LANGGRAPH=<PASS/BLOCKED/NOT_RUN_AFTER_FIRST_GATE>
TEST_01_TO_20=<PASS_20_OF_20/BLOCKED>
C8_TO_T5=<PASS/BLOCKED/NOT_RUN_AFTER_FIRST_GATE>
FINAL_STATUS=<READY or BLOCKED_AT_first_gate>
PHASE_TIMING=<preflight/cpu/native/init_forward/graph/tests/closure seconds>
```

然后停止。不上传GitHub、不反馈老师、不运行T4、不开始其他任务。
