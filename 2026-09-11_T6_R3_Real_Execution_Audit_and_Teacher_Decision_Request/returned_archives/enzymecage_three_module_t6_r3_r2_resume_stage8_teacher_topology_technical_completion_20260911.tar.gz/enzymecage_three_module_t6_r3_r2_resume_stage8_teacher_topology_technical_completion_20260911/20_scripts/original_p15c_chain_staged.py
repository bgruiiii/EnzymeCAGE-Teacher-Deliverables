# -*- coding: utf-8 -*-
"""T6-R3-R1 p15c — the real full-chain child on the STAGED (read-only overlay) root (§8-B).

Second asset track, second process, for one reason: ``enzymecage_wrapper.predictor`` keeps a
single runtime that is *locked* to the package root it was first created with, so a base-root
and an overlay-root forward cannot live in the same interpreter (the wrapper raises
RuntimeError on the second root).  This child therefore repeats the harness on
``runtime_assets/v1_overlay``, the §6.2 copy whose only three changed config fields are
``rxn_fp`` / ``mol_conformation`` / ``reaction_center``, re-pointed at a bundle holding exactly
the three T3-B staged reactions.

What is established here, and nothing else:

  ST1  the same teacher graph compiles and runs on the overlay root (real stream, consumed to
       the node it really reaches)
  ST2  the fixed topology has no injection point for a caller-supplied staged reaction:
       statically (the three SMILES / task ids appear in no teacher source file) and
       dynamically (no state.candidate_reactions entry ever equals a staged reaction)
  ST3  the overlay root fails closed for a base-library reaction (MissingReactionAssetError
       before any forward) - which is why S1/S2 belong to the base track
  SK1—SK3 the three §7 staged reactions forwarded through the *production* client callable with
       the §7-frozen UID pair, cross-checked against the §7 evidence hashes (S3—S8)

No teacher file is patched, no state key is written by this harness.
"""
import hashlib
import json
import os
import re
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import p15_shared as SH                                              # noqa: E402

CFG = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
OUT_JSON = Path(CFG["out_json"])
OUT_NORM = Path(CFG["out_norm"])
OUT_SCORES = Path(CFG["out_scores"])
RUN_LABEL = CFG["run_label"]

RES = {"run_label": RUN_LABEL, "track": "staged", "utc_started": SH.utc(),
       "problems": [], "gaps": [], "scenarios": [], "control_scenarios": [],
       "smoke_records": [], "forwards": [], "assets": {}, "counters": {}}
ALL_FLOATS = []


def prob(kind, msg, **kw):
    RES["problems"].append(dict(kind=kind, message=str(msg)[:500], **kw))


def gap(kind, msg, **kw):
    RES["gaps"].append(dict(kind=kind, message=str(msg)[:500], **kw))


def say(line):
    print("[%s][%s] %s" % (RUN_LABEL, SH.utc(), line), flush=True)


def _int_or_none(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


# ------------------------------------------------------------------ 0. interpreter gate
RES["interp"] = {"sys_executable": sys.executable, "realpath": os.path.realpath(sys.executable),
                 "version": sys.version.split()[0], "argv0": sys.argv[0],
                 "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
                 "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
                 "is_pinned": os.path.realpath(sys.executable)
                 == os.path.realpath(CFG["pinned_py"])}
if not RES["interp"]["is_pinned"]:
    prob("interpreter", "child is not on the pinned interpreter")
print("R1_INTERP " + json.dumps(RES["interp"]), flush=True)
AUDIT = SH.install_audit()

ENV_PRE = {}
for k, v in CFG["env"].items():
    ENV_PRE[k] = os.environ.get(k)
    os.environ[k] = v
RES["env_pre_existing"] = ENV_PRE
RES["env_set_by_child"] = dict(CFG["env"])
RES["env_credentials_popped"] = {}
for k in CFG.get("env_pop", []):
    RES["env_credentials_popped"][k] = os.environ.pop(k, None)
# this child runs the STAGED overlay package root
os.environ["ENZYMECAGE_V1_PACKAGE_ROOT"] = CFG["v1_overlay_root"]
RES["package_root_under_test"] = CFG["v1_overlay_root"]

STAGED = CFG["staged"]
sys.path.insert(0, STAGED)
RES["sys_path_head"] = sys.path[:4]

# ------------------------------------------------------------------ 1. overlay identity
RES["assets"]["v1_overlay"] = {"root": CFG["v1_overlay_root"],
                               "manifest_path": CFG["overlay_manifest_path"],
                               "manifest_sha256": SH.sha_file(CFG["overlay_manifest_path"]),
                               "expected_manifest_sha256": CFG["overlay_manifest_sha256"],
                               "staged_reaction_count": len(CFG["staged_reactions"])}
if RES["assets"]["v1_overlay"]["manifest_sha256"] != CFG["overlay_manifest_sha256"]:
    prob("overlay_identity", "the §6.2 overlay manifest no longer matches")
# the config the wrapper will really read, on this root
CFG_FILE = os.path.join(CFG["v1_overlay_root"], "3b_ensemble", "seed_40", "config.yaml")
_cfg_txt = Path(CFG_FILE).read_text(encoding="utf-8")
RES["assets"]["overlay_seed40_config"] = {
    "path": CFG_FILE, "sha256": hashlib.sha256(_cfg_txt.encode("utf-8")).hexdigest(),
    "fields": {f: (re.search(r"^%s:\s*(\S+)" % f, _cfg_txt, re.M) or [None, None])[1]
               for f in ("rxn_fp", "mol_conformation", "reaction_center")}}
for f, val in RES["assets"]["overlay_seed40_config"]["fields"].items():
    if not val or CFG["v1_overlay_root"] not in val:
        prob("overlay_config", "field %s on the overlay root does not point inside it: %r"
             % (f, val))

CASE_B = json.loads(Path(CFG["case_b"]).read_text(encoding="utf-8"))
RES["assets"]["case_b"] = {"path": CFG["case_b"], "sha256": SH.sha_file(CFG["case_b"]),
                           "case_id": CASE_B.get("case_id"),
                           "substrate": CASE_B["expected"]["substrate"]["smiles"]}
SMOKE = {r["smoke_record_id"]: r for r in CFG["smoke_rows"]}

# ------------------------------------------------------------------ 2. teacher graph, once
from src.graph import build_graph, compile_graph                      # noqa: E402
from src.tools.enzymecage_client import call_enzymecage               # noqa: E402
import langgraph.graph as lgg                                         # noqa: E402
import config.settings as settings                                    # noqa: E402

workflow = build_graph()
compiled = compile_graph()
RES["compile"] = {"compile_calls": 1, "graph_builder": "src.graph.build_graph",
                  "compiler": "src.graph.compile_graph", "stategraph_class": str(lgg.StateGraph),
                  "stategraph_from_langgraph": "langgraph" in os.path.realpath(lgg.__file__),
                  "workflow_nodes": sorted(workflow.nodes), "node_count": len(workflow.nodes),
                  "compiled_type": type(compiled).__name__}
RES["production_config"] = {
    "module_file": os.path.realpath(settings.__file__),
    "roots": {"ENZYMECAGE_V1_PACKAGE_ROOT": str(settings.ENZYMECAGE_V1_PACKAGE_ROOT),
              "D4_WRAPPER_ROOT": str(settings.D4_WRAPPER_ROOT),
              "ENZYMECAGE_CODE_ROOT": str(settings.ENZYMECAGE_CODE_ROOT),
              "ENZYMECAGE_MODEL_VERSION": str(settings.ENZYMECAGE_MODEL_VERSION),
              "ENZYMECAGE_TOP_K": settings.ENZYMECAGE_TOP_K,
              "ENZYMECAGE_DRY_RUN": settings.ENZYMECAGE_DRY_RUN},
    "dry_run_must_be_false": settings.ENZYMECAGE_DRY_RUN is False}
if settings.ENZYMECAGE_DRY_RUN is not False:
    prob("dry_run", "ENZYMECAGE_DRY_RUN is not False - no real forward would be evidence")
say("compiled the teacher graph on the overlay root: %d nodes" % len(workflow.nodes))


def counters():
    ws = SH.wrapper_state()
    return {"wrapper_forward_call_count": ws["forward_call_count"],
            "runtime_initialized": ws["runtime_initialized"],
            "package_root": ws["package_root"], "wrapper_module_loaded": ws["wrapper_imported"],
            "network_events_so_far": len(AUDIT.net)}


# ------------------------------------------------------------------ 3. ST2 static no-injection
staged_smiles = {r["reaction_smiles"]: r["reaction_task_id"] for r in CFG["staged_reactions"]}
static_hits = []
files_scanned = 0
for root in CFG["src_scan_roots"]:
    for dirpath, dirnames, filenames in os.walk(str(root)):
        dirnames[:] = [d for d in dirnames if d not in ("__pycache__", ".git")]
        for fn in filenames:
            if not fn.endswith((".py", ".yaml", ".yml", ".json", ".md", ".txt")):
                continue
            p = os.path.join(dirpath, fn)
            try:
                txt = Path(p).read_text(encoding="utf-8")
            except Exception:
                continue
            files_scanned += 1
            for smi, tid in staged_smiles.items():
                n_smi = txt.count(smi)
                n_tid = txt.count(tid)
                if n_smi or n_tid:
                    static_hits.append({"file": p, "staged_reaction_smiles_hits": n_smi,
                                        "staged_task_id_hits": n_tid, "task_id": tid})
RES["no_injection_static"] = {
    "roots_scanned": [str(r) for r in CFG["src_scan_roots"]],
    "files_scanned": files_scanned,
    "patterns_searched": sorted(staged_smiles.values()) + sorted(staged_smiles),
    "hits": static_hits,
    "lookup_or_injection_node_in_state_graph": (
        sorted(set(workflow.nodes) & {"envipath_lookup", "known_route_lookup", "database_lookup",
                                      "route_lookup", "staged_reaction_inject"})),
    "verdict": ("NO_STAGED_REACTION_INJECTION_PATH" if not static_hits
                else "STAGED_IDENTIFIER_PRESENT_IN_SOURCE")}

# ------------------------------------------------------------------ 4. ST1/ST3 real graph run
rec, updates, transitions, floats = SH.run_graph(
    compiled, "ST1_OVERLAY_ROOT_M3_STREAM_CASE_B",
    {"user_query": CASE_B["expected"]["substrate"]["smiles"], "pipeline_mode": "m3"},
    "%s-ST1-%s" % (RUN_LABEL, re.sub(r"[^A-Za-z0-9]", "",
                                     CASE_B["expected"]["substrate"]["smiles"][:12])))
rec["api"] = "stream"
ALL_FLOATS.extend([["scenario:ST1_OVERLAY_ROOT_M3_STREAM_CASE_B"] + f for f in floats])
cand_smiles = [c["reaction_smiles"] for c in rec["candidate_reactions_head"]]
rec["staged_smiles_present_in_candidates"] = sorted(set(cand_smiles) & set(staged_smiles))
norm, nfloats = SH.norm_line("ST1_OVERLAY_ROOT_M3_STREAM_CASE_B", rec["thread_id"], rec)
ALL_FLOATS.extend([["scenario:ST1_OVERLAY_ROOT_M3_STREAM_CASE_B"] + f for f in nfloats])
with OUT_NORM.open("a", encoding="utf-8") as fh:
    fh.write(norm + "\n")
RES["scenarios"].append({"scenario": "ST1_OVERLAY_ROOT_M3_STREAM_CASE_B", "record": rec,
                         "node_updates": updates, "state_transitions": transitions})
RES["control_scenarios"].append({
    "control": "ST2_no_staged_reaction_injection_path",
    "expected": ("the fixed graph never receives a staged reaction: its candidates come from the "
                 "production retrieval/prediction nodes only"),
    "observed": {"static": RES["no_injection_static"]["verdict"],
                 "static_hit_count": len(static_hits),
                 "graph_candidate_reactions_observed": cand_smiles,
                 "graph_candidate_reactions_equal_staged": rec["staged_smiles_present_in_candidates"],
                 "state_reaction_task_id": rec["reaction_task_id"]},
    "status": ("PASS" if not static_hits
               and not rec["staged_smiles_present_in_candidates"] else "FAIL")})
RES["control_scenarios"].append({
    "control": "ST3_overlay_root_fails_closed_for_base_library_reaction",
    "expected": ("on the overlay root the CASE_B library reaction has no staged asset, so the "
                 "wrapper must fail closed before any forward (contract §6.3 failure semantics)"),
    "observed": {"nodes": rec["node_execution_order"], "error": rec["state_error"],
                 "fail_closed": rec["state_fail_closed"],
                 "raised": rec["raised"],
                 "wrapper_forward_calls_in_scenario": rec["wrapper_forward_calls_in_scenario"],
                 "wrapper_runtime_initialized_after_attempt": counters()["runtime_initialized"],
                 "pool_size": rec["pool_size"]},
    "status": "OBSERVED"})
if rec["wrapper_forward_calls_in_scenario"] not in (0,):
    prob("ST3", "a forward executed on the overlay root for a base-library reaction")

# ------------------------------------------------------------------ 5. SK1-SK3 staged forwards
LLM_ABORT = "LLM API 未配置"
FROZEN = {r["reaction_task_id"]: r for r in CFG["frozen_forwards"]}


def confirm_call(reaction, pool):
    """Wrapper-level read of the *full* evidence hash, through the same public symbols the
    production client imports.  Counted, so it can never be mistaken for an untracked forward."""
    from enzymecage_wrapper import EnzymeCAGERequest, predict        # noqa: E402
    mod = sys.modules["enzymecage_wrapper"]
    req = EnzymeCAGERequest(reaction_smiles=reaction, enzyme_pool_uids=list(pool),
                            top_k=settings.ENZYMECAGE_TOP_K,
                            return_ci=settings.ENZYMECAGE_RETURN_CI)
    c0 = counters()
    resp = predict(req)
    c1 = counters()
    return {"module_file": os.path.realpath(mod.__file__),
            "public_callables": ["enzymecage_wrapper.predict", "enzymecage_wrapper.EnzymeCAGERequest"],
            "model_version": getattr(resp, "model_version", None),
            "evidence_hash": getattr(resp, "evidence_hash", None),
            "ranked": [{"uid": r.uid, "score": float(r.score), "rank": int(r.rank)}
                       for r in resp.ranked_enzymes],
            "forward_call_count_before": c0["wrapper_forward_call_count"],
            "forward_call_count_after": c1["wrapper_forward_call_count"],
            "wrapper_log_lines": []}


for i, row in enumerate(CFG["staged_reactions"], start=1):
    tid, smi, pool = row["reaction_task_id"], row["reaction_smiles"], list(row["uid_pair"])
    handlers = SH.attach_capture(["src.tools.enzymecage_client"])
    tb = None
    t0 = time.monotonic()
    started = SH.utc()
    try:
        ranked = call_enzymecage(reaction_smiles=smi, enzyme_pool_uids=pool)
    except Exception:
        tb = traceback.format_exc()
        ranked = []
    ended = SH.utc()
    ws = SH.wrapper_state()
    prefix = None
    for h in handlers:
        for line in h.lines:
            m = re.search(r"evidence_hash=([0-9a-f]{8,16})", line["msg"])
            if m:
                prefix = m.group(1)
    SH.detach_capture(handlers)
    confirm = None
    confirm_err = None
    try:
        confirm = confirm_call(smi, pool)
    except Exception:
        confirm_err = traceback.format_exc().splitlines()[-1][:300]
    frozen = FROZEN.get(tid, {})
    call_out = {"tag": "SK%d" % i, "reaction_task_id": tid, "reaction_smiles": smi,
                "reaction_sha256": hashlib.sha256(smi.encode("utf-8")).hexdigest(),
                "production_callable": "src.tools.enzymecage_client.call_enzymecage",
                "callable_file": os.path.realpath(
                    sys.modules["src.tools.enzymecage_client"].__file__),
                "started_utc": started, "ended_utc": ended,
                "wall_s": round(time.monotonic() - t0, 3),
                "request_pool_ordered": pool, "request_pool_size": len(pool),
                "ranked": [{"uid": r.uid, "score": r.score, "rank": r.rank,
                            "ensemble_ci": list(r.ensemble_ci) if r.ensemble_ci else None}
                           for r in ranked or []],
                "raised": (tb.strip().splitlines()[-1][:300] if tb else None),
                "traceback": tb,
                "evidence_hash_prefix_from_client_log": prefix,
                "wrapper_package_root": ws["package_root"],
                "wrapper_forward_call_count_after": ws["forward_call_count"],
                "wrapper_trace": ws["last_trace"],
                "client_log_lines": [l for h in handlers for l in h.lines],
                "confirmation_call": confirm, "confirmation_error": confirm_err,
                "vs_section7": {
                    "expected_evidence_hash": frozen.get("evidence_hash"),
                    "evidence_hash_matches_frozen": (
                        confirm or {}).get("evidence_hash") == frozen.get("evidence_hash"),
                    "prefix_agrees_with_confirmation": (
                        bool(prefix) and str((confirm or {}).get("evidence_hash", "")).startswith(prefix)),
                    "frozen_rank_order": frozen.get("ranked_uid_order"),
                    "observed_rank_order": [r["uid"] for r in ((confirm or {}).get("ranked") or [])],
                    "rank_order_matches_frozen": (
                        [r["uid"] for r in ((confirm or {}).get("ranked") or [])]
                        == frozen.get("ranked_uid_order")),
                    "max_abs_score_delta_vs_frozen": None,
                    "score_tolerance": CFG["repeat_tolerance"]}}
    deltas = []
    for a, b in zip(call_out["ranked"], (frozen.get("ranked_scores") or [])):
        if isinstance(b, float):
            deltas.append(abs(a["score"] - b))
    call_out["vs_section7"]["max_abs_score_delta_vs_frozen"] = (
        max(deltas) if deltas else None)
    ALL_FLOATS.extend([["forward:SK%d.ranked[%d].score" % (i, j), repr(r["score"])]
                       for j, r in enumerate(call_out["ranked"])])
    ALL_FLOATS.extend([["confirm:SK%d.ranked[%d].score" % (i, j), repr(r["score"])]
                       for j, r in enumerate((confirm or {}).get("ranked") or [])])
    if not call_out["vs_section7"]["evidence_hash_matches_frozen"]:
        prob("SK%d" % i, "staged forward evidence hash differs from the §7 frozen value",
             observed=(confirm or {}).get("evidence_hash"))
    RES["forwards"].append(call_out)
    # one byte-comparable line per forward (order + hashes only, no float)
    body = {"scenario": "SK%d_%s" % (i, tid), "request_pool_ordered": pool,
            "ranked_uid_order": [r["uid"] for r in call_out["ranked"]],
            "ranked_rank_order": [r["rank"] for r in call_out["ranked"]],
            "client_log_evidence_prefix": prefix,
            "confirmation_ranked_uid_order": [r["uid"] for r in ((confirm or {}).get("ranked") or [])],
            "evidence_hash": (confirm or {}).get("evidence_hash"),
            "wrapper_package_root": call_out["wrapper_package_root"]}
    floats2 = []
    with OUT_NORM.open("a", encoding="utf-8") as fh:
        fh.write(SH.canon(SH.scrub(body, floats2)) + "\n")
    ALL_FLOATS.extend([["norm:SK%d" % i] + f for f in floats2])
    say("  SK%d %s ranked=%s hash_match=%s" % (
        i, tid, len(call_out["ranked"]),
        call_out["vs_section7"]["evidence_hash_matches_frozen"]))

# ------------------------------------------------------------------ 6. S3-S8 smoke records
by_pair = {}
for f in RES["forwards"]:
    for r in f["ranked"]:
        by_pair[(f["reaction_task_id"], r["uid"])] = (f, r)
for rec_id in ("S3", "S4", "S5", "S6", "S7", "S8"):
    row = SMOKE.get(rec_id) or {}
    key = (row.get("reaction_task_id"), row.get("UID"))
    f, r = by_pair.get(key, (None, None))
    frozen = FROZEN.get(row.get("reaction_task_id"), {})
    RES["smoke_records"].append({
        "smoke_record_id": rec_id, "prereg": row,
        "forward_tag": (f or {}).get("tag"),
        "observed": {
            "reaction_task_id": row.get("reaction_task_id"),
            "UID": row.get("UID"),
            "preselection_rank_prereg": row.get("preselection_rank"),
            "rank_observed": (r or {}).get("rank"),
            "score_observed": (r or {}).get("score"),
            "wrapper_model_version": ((f or {}).get("confirmation_call") or {}).get(
                "model_version"),
            "forward_evidence_hash": ((f or {}).get("confirmation_call") or {}).get(
                "evidence_hash"),
            "client_log_hash_prefix": (f or {}).get("evidence_hash_prefix_from_client_log"),
            "package_root": (f or {}).get("wrapper_package_root"),
            "prereg_wrapper_model_version": row.get("wrapper_model_version"),
            "prereg_forward_evidence_hash": row.get("forward_evidence_hash")},
        "cross_check_vs_prereg": {
            "model_version_matches_prereg": (
                ((f or {}).get("confirmation_call") or {}).get("model_version")
                == row.get("wrapper_model_version")),
            "evidence_hash_matches_prereg": (
                ((f or {}).get("confirmation_call") or {}).get("evidence_hash")
                == row.get("forward_evidence_hash")),
            "rank_matches_prereg": (r or {}).get("rank") == _int_or_none(
                row.get("preselection_rank")),
            "evidence_hash_matches_section7": (
                ((f or {}).get("confirmation_call") or {}).get("evidence_hash")
                == frozen.get("evidence_hash"))},
        "status": ("PASS" if f and r and by_pair.get(key)
                   and ((f or {}).get("confirmation_call") or {}).get("evidence_hash")
                   == row.get("forward_evidence_hash") else "REVIEW")})
if any(s["status"] != "PASS" for s in RES["smoke_records"]):
    prob("smoke", "at least one staged smoke record did not reproduce its §8-A hash")


# ------------------------------------------------------------------ 7. close-out
RES["counters"]["final"] = counters()
RES["audit"] = AUDIT.dump()
RES["audit"]["opened_path_count_all_events"] = sum(v["count"] for v in AUDIT.opened.values())
RES["forward_total"] = {"client_path_forwards": len(RES["forwards"]),
                        "confirmation_calls": sum(
                            1 for f in RES["forwards"] if f.get("confirmation_call")),
                        "wrapper_forward_call_count_final": RES["counters"]["final"][
                            "wrapper_forward_call_count"]}
RES["utc_finished"] = SH.utc()
RES["exit_code_plan"] = 0 if not RES["problems"] else 1
OUT_JSON.write_text(json.dumps(RES, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
import csv as _csv                                                    # noqa: E402
with OUT_SCORES.open("w", newline="", encoding="utf-8") as fh:
    w = _csv.writer(fh)
    w.writerow(["run_label", "track", "float_path", "repr_value"])
    for row in ALL_FLOATS:
        w.writerow([RUN_LABEL, "staged"] + row)
say("PROBLEMS=%d gaps=%d forwards=%d smoke=%d" % (
    len(RES["problems"]), len(RES["gaps"]), len(RES["forwards"]), len(RES["smoke_records"])))
sys.exit(RES["exit_code_plan"])
