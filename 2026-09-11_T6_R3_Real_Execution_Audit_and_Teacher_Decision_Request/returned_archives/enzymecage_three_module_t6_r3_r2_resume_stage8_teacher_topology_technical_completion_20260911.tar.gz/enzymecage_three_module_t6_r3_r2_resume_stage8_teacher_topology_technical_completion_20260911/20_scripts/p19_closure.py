# -*- coding: utf-8 -*-
"""T6-R3-R2 p19: resume-identity recomputation, package assembly and the clean three-file
closure in the audited order (directive §9):

  package content final -> manifest N/N + N-1/N-1 -> archive -> fresh U1 -> identity
  -> validation-absent pre-write -> exclusive first write -> fresh U2 post-write -> final-readonly
"""
import csv
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

PY = "/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python"
R2 = Path("/usrdata/EnzymeCAGE_data/workspaces/"
          "enzymecage_three_module_t6_r3_r2_resume_stage8_teacher_topology_technical_completion_20260911")
ORIG = "enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910"
WORK = Path("/usrdata/EnzymeCAGE_data/workspaces") / ORIG
RET = Path("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries") / ORIG
TASK_ID = "enzymecage_three_module_t6_r3_r2_resume_stage8_teacher_topology_technical_completion_20260911"
RETURN_ROOT = Path("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries")
ARCHIVE = RETURN_ROOT / (TASK_ID + ".tar.gz")
IDENTITY = Path(str(ARCHIVE) + ".identity.txt")
VALIDATION = Path(str(ARCHIVE) + ".validation.txt")
ROOTNAME = TASK_ID
PKG = R2 / "package" / ROOTNAME
CKPT_SHA = "50efeafdc175141a947ce27be3cf5953bb8892a8b40aca4e9be3ab3e96cf4fdf"
PAYLOAD_SHA = "1ec7096aef76ebb9d777c9af252068406f043714ed50a3fba2152b07bbcde218"
LOC = "/root/.zcode/tmp/prompt-attachments/remote-ssh-e1de99f29bdf4975a875671f27feb93a71.gz14.chenyu.cn-29008-root-usrdata-/e60559f8-7b75-43e4-be8b-8e34baaa1321/01-t6_r3_r2_checkpoint_authority_and_local_audit_payload_20260911.tar.gz"


def utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha(p, chunk=1 << 20):
    h = hashlib.sha256()
    with open(str(p), "rb") as fh:
        for b in iter(lambda: fh.read(chunk), b""):
            h.update(b)
    return h.hexdigest()


def sh(cmd):
    return subprocess.run(list(map(str, cmd)), capture_output=True)


# ---------------------------------------------------------------- stage 0: resume identity recheck
def resume_identity():
    rec = {"utc": utc(), "checks": {}}
    c = rec["checks"]
    c["work_root_exists"] = WORK.is_dir()
    c["staged_repo_exists"] = (WORK / "depending_teacher_fixed_r1").is_dir()
    c["return_dir_exists"] = RET.is_dir()
    head = sh(["git", "-C", WORK / "depending_teacher_fixed_r1", "rev-parse", "HEAD"]).stdout.decode().strip()
    tree = sh(["git", "-C", WORK / "depending_teacher_fixed_r1", "rev-parse", "HEAD^{tree}"]).stdout.decode().strip()
    c["base_commit"] = {"value": head, "match": head == "2d4cc766322a6a01b8a88491aed07536b3b0a320"}
    c["base_tree"] = {"value": tree, "match": tree == "c0acb9bd30b985ad43bf969946842da97a68a400"}
    sp = sha(R2 / "raw_copies" / "SOURCE_PATCH_R1_REGENERATED.diff")
    c["source_patch"] = {"sha256": sp, "match": sp == "074f5c31d516e1f699648008ed86767244e25fb128905e119366ad346f8f027a"}
    topo = {}
    for row in csv.DictReader((CK := (R2 / "checkpoint" / "enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911" / "05_changed" / "TEACHER_TOPOLOGY_PRE_POST_SHA.csv")).read_text().splitlines()):
        live = sha(WORK / "depending_teacher_fixed_r1" / row["path"])
        topo[row["path"]] = live == row["pre_sha256_recorded_in_5_3"] == row["post_sha256_at_stop"]
    c["teacher_topology_files_unchanged_vs_checkpoint"] = topo
    gates = {"PYTHON_RUNTIME_PREFLIGHT.json": "4b70c9ed441b90dfa6e8f0fc3c71683c842ed190157542e1cb04bba866aaa7a1",
             "UNIFIED_GRAPH_RUNTIME_GATE.json": "7cb3aece572fd3e688b96cc280f12192fe55e6854ac334b3ffe24a617d75ce48",
             "COMPONENT_TESTS_GATE.json": "447de88b7a7d53878ef7585678d2b74f5ee2b508fcc38e009d432bcaa8f6da49",
             "FIXED_ASSET_IDENTITY_GATE.json": "bc58a271218999c6cc2a282a443271ed2ed6fc4a971e29a5b74cc1b3ced86a97",
             "UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json": "cbf4176994717e3135a8746bd1ec8b5f072f9d5369a1272b1fa1748e48e2fcb8",
             "T3B_BOUNDED_FORWARD_GATE.json": "b153e4cd09fc513dd5f01cbd16366ba21a278027ca17a3c1243cb2905e8d720f",
             "REAL_SMOKE_INPUTS.csv": "97e5d6d6701ac23890ae8ee4c71c9039280c4f447fe63510bb7fec76b13f8595"}
    gv = {}
    for name, want in gates.items():
        gv[name] = {"sha256": sha(RET / name), "match": sha(RET / name) == want}
    c["e0_e7_gate_files"] = gv
    with open(R2 / "raw_copies" / "GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv", newline="", encoding="utf-8") as fh:
        wrows = list(csv.DictReader(fh))
    c["workers"] = {"count": len(wrows),
                    "exits": [r["exit_code"] for r in wrows],
                    "uuid_matches": [r["uuid_matches_frozen"] for r in wrows]}
    ps = sh(["ps", "-eo", "args"]).stdout.decode()
    c["no_foreign_t6_processes"] = ("run_gpu_worker" not in ps and "p12_forward" not in ps)
    gpu = sh(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"]).stdout.decode().splitlines()
    c["gpu_compute_apps_note"] = "sampled at identity-gate time before §8-B launch"
    c["checkpoint_sha256"] = sha(RET.parent / (
        "enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911.tar.gz")) == CKPT_SHA
    c["authority_payload_sha256_local_copy"] = sha(LOC) == PAYLOAD_SHA
    rec["overall"] = all([c["work_root_exists"], c["staged_repo_exists"], c["return_dir_exists"],
                          c["base_commit"]["match"], c["base_tree"]["match"],
                          c["source_patch"]["match"],
                          all(topo.values()), all(g["match"] for g in gv.values()),
                          c["workers"]["count"] == 3 and all(x == "0" for x in c["workers"]["exits"]),
                          c["no_foreign_t6_processes"], c["checkpoint_sha256"],
                          c["authority_payload_sha256_local_copy"]])
    return rec


def build_package():
    if PKG.exists():
        import shutil
        shutil.rmtree(str(PKG.parent))
    PKG.mkdir(parents=True)
    (PKG / "00_authority").mkdir()
    src = R2 / "inputs" / "t6_r3_r2_checkpoint_authority_and_local_audit_payload_20260911"
    for p in sorted(src.iterdir()):
        (PKG / "00_authority" / p.name).write_bytes(p.read_bytes())
    (PKG / "00_authority" / "AUTHORITY_PAYLOAD_LOCAL_SOURCE.json").write_text(json.dumps({
        "payload_received_via": "user attachment (HPC_Inputs copy unavailable on host)",
        "local_path": LOC, "bytes": os.path.getsize(LOC), "sha256": sha(LOC),
        "expected_sha256": PAYLOAD_SHA, "match": sha(LOC) == PAYLOAD_SHA,
        "single_root_members": 4}, indent=1), encoding="utf-8")
    (PKG / "01_resume").mkdir()
    (PKG / "01_resume" / "RESUME_IDENTITY_GATE.json").write_text(
        json.dumps(resume_identity(), indent=1, default=str), encoding="utf-8")
    (PKG / "01_resume" / "E0_E7_FROZEN_FACTS.json").write_text(json.dumps({
        "inherited_not_rerun": True,
        "facts": {"PYTHON": PY, "PYTHON_PREFLIGHT": "PASS", "UNIFIED_GRAPH_RUNTIME": "PASS",
                  "TEACHER_FIXED_TOPOLOGY": "PASS_UNCHANGED", "COMPONENT_TESTS": "PASS_157",
                  "FIXED_ASSET_IDENTITY": "PASS", "T3B_NATIVE_LOAD": "PASS_3_OF_3",
                  "UID_SEQUENCE_GVP_POCKET_ESM": "PASS", "T3B_BOUNDED_FORWARD": "PASS_6_OF_6",
                  "REAL_SMOKE_INPUTS": "FROZEN_8_OF_8"},
        "gate_file_identities": {p: sha(RET / p) for p in (
            "PYTHON_RUNTIME_PREFLIGHT.json", "UNIFIED_GRAPH_RUNTIME_GATE.json",
            "COMPONENT_TESTS_GATE.json", "FIXED_ASSET_IDENTITY_GATE.json",
            "UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json", "T3B_BOUNDED_FORWARD_GATE.json",
            "REAL_SMOKE_INPUTS.csv")},
        "checkpoint": {"bytes": (RETURN_ROOT / (
            "enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911.tar.gz")).stat().st_size,
            "sha256": CKPT_SHA, "manifest_files": 368, "manifest_sha256_lines": 367,
            "manifest_sha_recheck": "367/367 OK at unpack (this session)"}}, indent=1), encoding="utf-8")
    (PKG / "01_resume" / "ENVIPATH_STATUS.json").write_text(json.dumps({
        "status": "NOT_ESTABLISHED_AWAITING_HUANG_TEACHER",
        "inherited_evidence_sha256": "bd8673dc0489e8d6a97aeb2f40eccf76a5075f8a0190e2876843b49927fdfd84",
        "note": "no sixth observer run; teacher fixed graph has no enviPath lookup node; Route C "
                "similarity retrieval and BioTransformer ENVMICRO fallback are NOT enviPath "
                "known-route lookup; student does not adjudicate topology",
        "observed_in_stage8b": "reaction_prediction node never executed in the 8 real smoke "
                               "chains (both smoke cases succeeded via retrieval)"}, indent=1),
        encoding="utf-8")
    (PKG / "20_scripts").mkdir()
    for sub, d in (("original", R2 / "scripts_deployed"),):
        for p in sorted(x for x in d.iterdir() if x.is_file()):
            (PKG / "20_scripts" / (sub + "_" + p.name)).write_bytes(p.read_bytes())
    rep = R2 / "task_local_repairs"
    for p in sorted(rep.iterdir()):
        (PKG / "20_scripts" / ("repair__" + p.name)).write_bytes(p.read_bytes())
    S = WORK / "scripts"
    for name in ("p15_shared.py", "p15b_chain_base.py", "p15c_chain_staged.py",
                 "p15_real_langgraph_chain.py", "r1_common.py"):
        (PKG / "20_scripts" / ("as_executed_" + name)).write_bytes((S / name).read_bytes())
    for name in ("p16_finalize.py", "p17_validator.py", "p18_mutations.py", "p19_closure.py"):
        (PKG / "20_scripts" / name).write_bytes((R2 / "scripts_finalize" / name).read_bytes())
    (PKG / "30_stage8b").mkdir()
    for lab in ("base_run1", "base_run2", "staged_run1", "staged_run2"):
        d = PKG / "30_stage8b" / lab
        d.mkdir()
        for f in ("out.json", "norm.jsonl", "floats.csv", "stdout.log", "stderr.log"):
            s = R2 / "runs" / lab / f
            if s.exists():
                (d / f).write_bytes(s.read_bytes())
    (PKG / "30_stage8b" / "configs").mkdir()
    for p in sorted(x for x in (R2 / "configs").iterdir() if x.is_file()):
        (PKG / "30_stage8b" / "configs" / p.name).write_bytes(p.read_bytes())
    (PKG / "30_stage8b" / "driver").mkdir()
    for p in sorted(x for x in (R2 / "driver").iterdir() if x.is_file()):
        (PKG / "30_stage8b" / "driver" / p.name).write_bytes(p.read_bytes())
    (PKG / "30_stage8b" / "base_package_manifest.csv").write_bytes(
        (R2 / "runtime_assets" / "v1_base" / "MANIFEST.csv").read_bytes())
    atts = sorted(d for d in (R2 / "runs").iterdir() if d.is_dir() and "_attempt" in d.name)
    for att in atts:
        d = PKG / "30_stage8b" / ("failed_attempts__" + att.name)
        d.mkdir()
        for f in ("stdout.log", "stderr.log", "out.json", "norm.jsonl"):
            if (att / f).exists():
                (d / f).write_bytes((att / f).read_bytes())
    (PKG / "40_evidence").mkdir()
    for p in sorted(x for x in (R2 / "evidence").iterdir() if x.is_file()):
        (PKG / "40_evidence" / p.name).write_bytes(p.read_bytes())
    (PKG / "40_evidence" / "raw_copies").mkdir()
    for p in sorted(x for x in (R2 / "raw_copies").iterdir() if x.is_file()):
        (PKG / "40_evidence" / "raw_copies" / p.name).write_bytes(p.read_bytes())
    (PKG / "40_evidence" / "gschema_official").mkdir()
    for p in sorted(x for x in (R2 / "gschema_official").iterdir() if x.is_file()):
        (PKG / "40_evidence" / "gschema_official" / p.name).write_bytes(p.read_bytes())
    # FINAL_STATUS
    facts = json.loads((R2 / "evidence" / "STAGE8B_FINAL_FACTS.json").read_text())
    with open(R2 / "evidence" / "TEST_CASE_MATRIX.csv", newline="", encoding="utf-8") as fh:
        tm = list(csv.DictReader(fh))
    npass = sum(1 for r in tm if r["status"] == "PASS")
    nonpass = [(r["test_id"], r["status"]) for r in tm if r["status"] != "PASS"]
    # the single tolerated non-PASS is TEST-03: the reaction_prediction node is unreachable on
    # the frozen inputs (retrieval succeeds), i.e. part of the same teacher-topology family as
    # the enviPath gap; everything else must be a real PASS
    teacher_family = (len(nonpass) == 1 and nonpass[0][0] == "TEST-03"
                      and nonpass[0][1] == "NOT_ESTABLISHED_REAL_GRAPH")
    test_line = ("PASS_20_OF_20" if npass == 20 else
                 ("PASS_%d_OF_20_WITH_%s:%s_AWAITING_HUANG_TEACHER" % (
                     npass, nonpass[0][0], nonpass[0][1]) if teacher_family else
                  "PASS_%d_OF_20_WITH_%s" % (npass, ",".join("%s:%s" % t for t in nonpass))))
    tech_ok = (facts["real_langgraph"]["invoke"] and facts["real_langgraph"]["stream_consumed_to_terminal"]
               and facts["c8_to_t5"] == "PASS" and facts["determinism"] == "PASS"
               and facts["schema"] == "PASS" and facts["persistent"] == "PASS"
               and facts["smoke_records_status"] == "PASS_8_OF_8"
               and (npass == 20 or teacher_family))
    lines = []
    lines.append("T6_R3_TECHNICAL_EXECUTION_COMPLETE_WITH_TEACHER_TOPOLOGY_LOOKUP_GAP"
                 if tech_ok else "BLOCKED_AT_" + first_blocker(facts))
    lines += ["TEACHER_FIXED_TOPOLOGY_EXECUTED=true",
              "REAL_LANGGRAPH_COMPILE_INVOKE_STREAM=PASS",
              "REAL_SMOKE_RECORDS=%s" % facts["smoke_records_status"],
              "TEST_01_TO_20=%s" % test_line,
              "C8_TO_T5_REAL_CONTINUOUS_REGRESSION=%s" % facts["c8_to_t5"],
              "DETERMINISM=%s" % facts["determinism"],
              "GSCHEMA=%s" % facts["schema"],
              "PERSISTENT_INPUT_NONMUTATION=%s" % facts["persistent"],
              "ACCESS_AUDIT=%s" % ("PASS" if _access_ok() else "REVIEW"),
              "MUTATION=%s" % ("PASS" if json.loads((R2 / "evidence" / "MUTATION_CHECK.json")
                                                    .read_text())["all_mutations_rejected"] else "FAIL"),
              "ENVIPATH_LOOKUP_THEN_DEPENDING=NOT_ESTABLISHED_AWAITING_HUANG_TEACHER",
              "TEST_03_PREDICTION_CROSSWALK=NOT_ESTABLISHED_REAL_GRAPH_AWAITING_HUANG_TEACHER"
              " (prediction node unreachable in both frozen smoke cases; see TEST_CASE_MATRIX.csv)",
              "T6_OVERALL_READY_FOR_LOCAL_AUDIT=false",
              "G7_PASSED=false",
              "RESUMED_FROM_CHECKPOINT_SHA256=" + CKPT_SHA,
              "E0_E7_RERUN=false",
              "UTC=" + utc()]
    (PKG / "FINAL_STATUS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (PKG / "README.md").write_text(
        "# T6-R3-R2 §8-B controlled resume\n\n"
        "From checkpoint `50efeafd...` (E0-E7 frozen, not re-run): real teacher-graph "
        "compile/invoke/stream, 8 frozen smoke records, C1-C4, C8->T5 continuous chain, "
        "TEST-01..20, schema/determinism/mutation/access/persistent gates and this package.\n"
        "See 01_resume/RESUME_IDENTITY_GATE.json, 30_stage8b/, 40_evidence/ and FINAL_STATUS.txt.\n",
        encoding="utf-8")
    return facts, npass, test_line, tech_ok


def _access_ok():
    acc = [json.loads(l) for l in (R2 / "evidence" / "ACCESS_AUDIT.jsonl").read_text().splitlines()]
    s = [a for a in acc if a["record_type"] == "summary"]
    return all(a["port_8001_reference_count"] == 0 and not a["distinct_network_hosts"] for a in s)


def first_blocker(facts):
    for k in ("real_langgraph", "smoke_records_status", "c8_to_t5", "determinism", "schema",
              "persistent"):
        v = facts[k]
        if v in (False, "REVIEW", "FAIL") or v == "REVIEW":
            return "STAGE8B_" + k.upper()
    return "UNKNOWN"


# ---------------------------------------------------------------- manifest + archive
def write_manifests():
    files = sorted(p for p in PKG.rglob("*") if p.is_file())
    n = len(files)
    with open(PKG / "MANIFEST.files", "w", encoding="utf-8") as fh:
        for p in files:
            fh.write(str(p.relative_to(PKG)) + "\n")
        fh.write("MANIFEST.files\n")
        fh.write("MANIFEST.sha256\n")
    with open(PKG / "MANIFEST.sha256", "w", encoding="utf-8") as fh:
        for p in files:
            fh.write("%s  %s\n" % (sha(p), p.relative_to(PKG)))
        fh.write("%s  %s\n" % (sha(PKG / "MANIFEST.files"), "MANIFEST.files"))
    # re-check per directive: files line count == N (= regular files incl both manifests),
    # sha lines == N-1 (excludes itself)
    mf = (PKG / "MANIFEST.files").read_text().splitlines()
    ms = (PKG / "MANIFEST.sha256").read_text().splitlines()
    actual = [p for p in PKG.rglob("*") if p.is_file()]
    state = {"manifest_files_equals_n": len(mf) == len(actual),
             "manifest_sha256_equals_n_minus_1": len(ms) == len(actual) - 1,
             "n_regular_files": len(actual)}
    return state


def closure():
    for p in (ARCHIVE, IDENTITY, VALIDATION):
        if p.exists() or Path(str(p) + ".tmp").exists() or Path(str(p) + ".partial").exists():
            print("BLOCKED_NONFRESH_TARGET", p)
            sys.exit(3)
    facts, npass, test_line, tech_ok = build_package()
    state = write_manifests()
    (R2 / "closure_state.json").write_text(json.dumps(state), encoding="utf-8")
    # archive with single root
    rc = sh(["tar", "-czf", str(ARCHIVE), "-C", str(PKG.parent), ROOTNAME])
    assert rc.returncode == 0, rc.stderr
    ab, ash = ARCHIVE.stat().st_size, sha(ARCHIVE)
    # fresh unpack U1
    u1 = R2 / "_u1"
    if u1.exists():
        import shutil
        shutil.rmtree(str(u1))
    u1.mkdir()
    rc = sh(["tar", "-xzf", str(ARCHIVE), "-C", str(u1)])
    names = sh(["tar", "-tzf", str(ARCHIVE)]).stdout.decode().splitlines()
    roots = sorted({n.split("/")[0] for n in names})
    unsafe = [n for n in names if n.startswith("/") or "/../" in ("/" + n) or n.count("..") > 0
              and ".." in Path(n).parts]
    members = [p for p in u1.rglob("*") if p.is_file()]
    mfiles = sorted((u1 / ROOTNAME / "MANIFEST.files").read_text().splitlines())
    msha = (u1 / ROOTNAME / "MANIFEST.sha256").read_text()
    chk = subprocess.run(["sha256sum", "-c", "--quiet", str(u1 / ROOTNAME / "MANIFEST.sha256")],
                         cwd=str(u1 / ROOTNAME), capture_output=True)
    single_root = len(roots) == 1 and roots[0] == ROOTNAME
    state.update({"single_root": single_root, "unsafe_members": len(unsafe),
                  "U1_members": len(members), "U1_manifest_files_lines": len(mfiles),
                  "U1_manifest_files_equal_members": len(mfiles) == len(members),
                  "U1_sha256sum_check_pass": chk.returncode == 0})
    # identity from the on-disk archive
    ident = ("ARCHIVE=%s\nBYTES=%d\nSHA256=%s\nSINGLE_ROOT=%s\nREGULAR_FILES=%d\n"
             "MANIFEST_FILES_LINES=%d\nMANIFEST_SHA256_LINES=%d\nSHA256SUM_CHECK=%s\n"
             "UNSAFE_MEMBERS=%d\nCREATED_UTC=%s\nRESUMED_FROM_CHECKPOINT_SHA256=%s\n") % (
        str(ARCHIVE), ab, ash, single_root, len(members), len(mfiles),
        len(msha.splitlines()), "PASS" if chk.returncode == 0 else "FAIL", len(unsafe), utc(), CKPT_SHA)
    IDENTITY.write_text(ident, encoding="utf-8")
    # validation must not exist before the exclusive first write
    pre = {"validation_exists_pre_write": VALIDATION.exists(),
           "tmp_variants_exist": any(Path(str(VALIDATION) + s).exists()
                                     for s in (".tmp", ".partial", ".failed", ".bak")),
           "archive_exists": ARCHIVE.exists(), "identity_exists": IDENTITY.exists()}
    state.update({"validation_absent_pre_write": not pre["validation_exists_pre_write"]
                  and not pre["tmp_variants_exist"]})
    (R2 / "closure_state.json").write_text(json.dumps(state), encoding="utf-8")
    assert (not pre["validation_exists_pre_write"]) and (not pre["tmp_variants_exist"]) \
        and pre["archive_exists"] and pre["identity_exists"]
    fd = os.open(str(VALIDATION), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    with os.fdopen(fd, "w") as fh:
        fh.write("VALIDATION_STATUS=PENDING_POSTWRITE\nARCHIVE_SHA256=%s\n" % ash)
    # fresh unpack U2
    u2 = R2 / "_u2"
    if u2.exists():
        import shutil
        shutil.rmtree(str(u2))
    u2.mkdir()
    sh(["tar", "-xzf", str(ARCHIVE), "-C", str(u2)])
    chk2 = subprocess.run(["sha256sum", "-c", "--quiet", str(u2 / ROOTNAME / "MANIFEST.sha256")],
                          cwd=str(u2 / ROOTNAME), capture_output=True)
    u2_members = [p for p in u2.rglob("*") if p.is_file()]
    # final validator over R2 (raw evidence + closure_state present now)
    sys.path.insert(0, str(R2 / "scripts_finalize"))
    import p17_validator as V
    ok = V.validate(R2)
    gates = {k: v["pass"] for k, v in V.GATES.items()}
    final = ("VALIDATION_STATUS=%s\n"
             "VALIDATED_UTC=%s\nARCHIVE=%s\nARCHIVE_BYTES=%d\nARCHIVE_SHA256=%s\n"
             "IDENTITY_SHA256=%s\nU1_SINGLE_ROOT=%s U1_MEMBERS=%d U1_MANIFEST_MATCH=%s "
             "U1_SHA_CHECK=%s\nU2_MEMBERS=%d U2_SHA_CHECK=%s\n"
             "ALL_GATES_PASS=%s\nGATES=%s\n"
             "FINAL_STATUS_LINE=%s\nENVIPATH_LOOKUP_THEN_DEPENDING=NOT_ESTABLISHED_AWAITING_HUANG_TEACHER\n"
             "T6_OVERALL_READY_FOR_LOCAL_AUDIT=false\nG7_PASSED=false\n"
             "CHECKPOINT_RECHECK=not rerun (E0-E7 frozen; validation is external-over-raw-evidence)\n"
             ) % ("PASS" if ok else "FAIL", utc(), str(ARCHIVE), ab, ash, sha(IDENTITY),
                  single_root, len(members), state["U1_manifest_files_equal_members"],
                  chk.returncode == 0, len(u2_members), chk2.returncode == 0, ok,
                  json.dumps(gates),
                  "T6_R3_TECHNICAL_EXECUTION_COMPLETE_WITH_TEACHER_TOPOLOGY_LOOKUP_GAP"
                  if (ok and tech_ok) else "PARTIAL_TECHNICAL_COMPLETE_WITH_DISCLOSED_GAPS")
    tmp = Path(str(VALIDATION) + ".tmp")
    tmp.write_text(final, encoding="utf-8")
    os.replace(str(tmp), str(VALIDATION))
    print("CLOSURE_DONE all_gates=%s" % ok)
    return ab, ash, ok, facts, gates


if __name__ == "__main__":
    ab, ash, ok, facts, gates = closure()
    print("ARCHIVE=%s bytes=%d SHA256=%s" % (ARCHIVE, ab, ash))
    print("ALL_GATES=%s" % ok)
