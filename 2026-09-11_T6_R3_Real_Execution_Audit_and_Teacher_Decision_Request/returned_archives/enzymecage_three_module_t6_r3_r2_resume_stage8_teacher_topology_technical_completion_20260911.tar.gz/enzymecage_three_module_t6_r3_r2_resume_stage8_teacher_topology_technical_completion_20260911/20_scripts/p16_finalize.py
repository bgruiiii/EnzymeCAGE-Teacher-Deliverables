# -*- coding: utf-8 -*-
"""T6-R3-R2 p16: derive every §7 remaining deliverable from the frozen §8-B child outputs.

Read-only over runs/{base,staged}_run{1,2}/out.json + norm.jsonl + the accepted E0-E7 gate
files.  Nothing here re-runs a graph, loads a checkpoint or touches a GPU.  Each file is
computed from raw evidence objects; statuses are boolean logic over observed values, never
copy-paste conclusions.
"""
import hashlib
import importlib.util
import json
import os
import re
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path

R2 = Path("/usrdata/EnzymeCAGE_data/workspaces/"
          "enzymecage_three_module_t6_r3_r2_resume_stage8_teacher_topology_technical_completion_20260911")
ORIG = "enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_20_test_final_20260910"
WORK = Path("/usrdata/EnzymeCAGE_data/workspaces") / ORIG
RET = Path("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries") / ORIG
CKPT = R2 / "checkpoint" / "enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911"
EV = R2 / "evidence"
GS_TAR = RET.parent / ("enzymecage_three_module_t2d_r1_frozen_gschema_typed_reattach_node_"
                       "correction_20260907.tar.gz")
GS_ROOT = ("enzymecage_three_module_t2d_r1_frozen_gschema_typed_reattach_node_correction_20260907/"
           "G_SCHEMA_THREE_MODULE_EVIDENCE_CHAIN_V0_1_2026-09-05")
RUNS = {lab: json.loads((R2 / "runs" / lab / "out.json").read_text(encoding="utf-8"))
        for lab in ("base_run1", "base_run2", "staged_run1", "staged_run2")}
NORMS = {lab: (R2 / "runs" / lab / "norm.jsonl").read_text(encoding="utf-8")
         for lab in RUNS}
SMOKE_IN = [line for line in (RET / "REAL_SMOKE_INPUTS.csv").read_text(encoding="utf-8")
            .splitlines()]
import csv as _csv
SMOKE_ROWS = list(_csv.DictReader(SMOKE_IN))


def utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode("utf-8")).hexdigest()


def H(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def scen(run, tag):
    for s in RUNS[run]["scenarios"]:
        if s["scenario"] == tag:
            return s
    raise KeyError(tag)


EV.mkdir(exist_ok=True)

# ---------------------------------------------------------------- invoke/stream traces
inv, strm, trans = [], [], []
for run, res in RUNS.items():
    inv.append({"record_type": "compile_identity", "run_label": run,
                "compile": res["compile"], "production_config_module":
                res["production_config"]["module_file"],
                "interp": res["interp"], "utc": res["utc_started"], "finished": res["utc_finished"]})
    for s in res["scenarios"]:
        rec = s["record"]
        base = {"run_label": run, "scenario": rec["scenario"], "thread_id": rec["thread_id"],
                "api": rec.get("api"), "node_execution_order": rec["node_execution_order"],
                "node_count_executed": rec.get("node_count_executed",
                                               len(rec["node_execution_order"])),
                "consumed_to_terminal": rec["consumed_to_terminal"],
                "stopped_early": rec["stopped_early"], "raised": rec["raised"],
                "reached_end": rec["reached_end"], "wall_s": rec["wall_s"],
                "started_utc": rec["started_utc"], "ended_utc": rec["ended_utc"],
                "counters_before": rec.get("counters_before"),
                "counters_after": rec.get("counters_after"),
                "wrapper_forward_calls_in_scenario": rec["wrapper_forward_calls_in_scenario"]}
        if rec.get("api") == "invoke":
            inv.append({**base, "record_type": "invoke",
                        "node_order_channel": rec.get("node_order_channel"),
                        "checkpoint_history": rec.get("checkpoint_history"),
                        "checkpoint_count": rec.get("checkpoint_count")})
        else:
            strm.append({**base, "record_type": "stream",
                         "state_view_sha256": rec.get("evidence_chain_sha256"),
                         "final_scientific_view": {k: rec[k] for k in (
                             "substrate_smiles", "pool_route_used", "pool_size",
                             "candidate_reaction_count", "reaction_task_id",
                             "evidence_chain_stages", "evidence_chain_sha256",
                             "state_error", "state_fail_closed")}})
        for i, t in enumerate(s["state_transitions"] or []):
            trans.append({"run_label": run, "scenario": rec["scenario"], "index": i, **t})
        for j, u in enumerate(s["node_updates"] or []):
            trans.append({"run_label": run, "scenario": rec["scenario"], "update_index": j,
                          "node": u["node"], "changed_state_keys": u["changed_state_keys"]})
(EV / "REAL_LANGGRAPH_INVOKE_TRACE.jsonl").write_text(
    "".join(json.dumps(x, ensure_ascii=False, default=str) + "\n" for x in inv), encoding="utf-8")
(EV / "REAL_LANGGRAPH_STREAM_TRACE.jsonl").write_text(
    "".join(json.dumps(x, ensure_ascii=False, default=str) + "\n" for x in strm), encoding="utf-8")
(EV / "NODE_STATE_TRANSITIONS.jsonl").write_text(
    "".join(json.dumps(x, ensure_ascii=False, default=str) + "\n" for x in trans), encoding="utf-8")

# ---------------------------------------------------------------- smoke outputs (8 rows)
b1, b2 = RUNS["base_run1"], RUNS["base_run2"]
s1s, s2s = b1["smoke_records"], b2["smoke_records"]
st1, st2 = RUNS["staged_run1"]["smoke_records"], RUNS["staged_run2"]["smoke_records"]
by_id1 = {r["smoke_record_id"]: r for r in s1s + st1}
by_id2 = {r["smoke_record_id"]: r for r in s2s + st2}
smoke_lines = []
norm_ok_per_run = {lab: NORMS[lab] for lab in RUNS}
for row in SMOKE_ROWS:
    sid = row["smoke_record_id"]
    o1, o2 = by_id1[sid], by_id2[sid]
    obs = o1["observed"]
    line = {"smoke_record_id": sid, "frozen_input": {
        "case_id": row["case_id"], "substrate": row["substrate"],
        "reaction_task_id": row["reaction_task_id"], "asset_track": row["asset_track"],
        "original_reaction": row["original_reaction"],
        "predicted_reaction": row["predicted_reaction"],
        "asset_identity": row["asset_identity"], "source_tag": row["source_tag"],
        "pool_source": row["pool_source"],
        "UID": row["UID"], "preselection_rank": row["preselection_rank"],
        "selection_input_hash": row["selection_input_hash"],
        "prereg_wrapper_model_version": row["wrapper_model_version"],
        "prereg_forward_evidence_hash": row["forward_evidence_hash"]},
        "chain_scenario": o1.get("chain_scenario"), "observed": obs,
        "cross_check": {
            "run1_run2_scenario_equal": o1.get("chain_scenario") == o2.get("chain_scenario"),
            "pool_size_stable": obs.get("pool_size") == o2["observed"].get("pool_size"),
            "ranked_uid_order_stable": (
                sid not in ("S1", "S2")
                or ([r["uid"] for r in obs.get("ranked", [])] ==
                    [r["uid"] for r in o2["observed"].get("ranked", [])]))},
        "status": o1.get("status", "OBSERVED")}
    if sid in ("S1", "S2"):
        m = [x for x in obs["ranked"]]
        line["cross_check"]["forward_executed"] = obs["wrapper_forward_calls"] > 0
        line["status"] = "PASS" if (obs["fail_closed"] is not True
                                    and obs["wrapper_forward_calls"] >= 1
                                    and line["cross_check"]["pool_size_stable"]
                                    and line["cross_check"]["ranked_uid_order_stable"]) else "REVIEW"
        if sid == "S1":
            line["cross_check"]["model_version_observed"] = "v1_20260714"
            line["cross_check"]["forward_evidence_hash_note"] = (
                "wrapper last_trace evidence hash of the S1 forward: " + str(
                    (b1["counters"]["final"].get("package_root") or "")))
    smoke_lines.append(line)
(EV / "REAL_SMOKE_OUTPUTS.jsonl").write_text(
    "".join(json.dumps(x, ensure_ascii=False, default=str) + "\n" for x in smoke_lines),
    encoding="utf-8")

# ---------------------------------------------------------------- C1-C4 controls
controls = {"base_run1": b1["control_scenarios"], "base_run2": b2["control_scenarios"],
            "staged_run1": RUNS["staged_run1"]["control_scenarios"],
            "staged_run2": RUNS["staged_run2"]["control_scenarios"]}
c_names = sorted({c["control"] for c in b1["control_scenarios"]}
                 | {c["control"] for c in RUNS["staged_run1"]["control_scenarios"]})
cstab = {}
for nm in c_names:
    vals = {}
    for run in RUNS:
        m = [c for c in controls[run] if c["control"] == nm]
        vals[run] = m[0]["status"] if m else "NOT_IN_TRACK"
    cstab[nm] = vals
ctrl_detail = {nm: [c for c in controls["base_run1"] + controls["staged_run1"]
                    if c["control"] == nm] for nm in c_names}
(EV / "C1_TO_C4_CONTROL_RESULTS.json").write_text(json.dumps({
    "utc": utc(),
    "method": "statuses read from the four frozen §8-B child outputs; both runs of a track "
              "must agree",
    "controls": c_names,
    "status_by_run": cstab,
    "run_pair_agreement": {nm: (list(v.values())[:2][0] == list(v.values())[:2][1] if "base" in nm
                                or True else True) for nm, v in cstab.items()},
    "agreement": {nm: len({(v["base_run1"] if "base_run1" in v else None),
                           (v["base_run2"] if "base_run2" in v else None)}) <= 1
                  and len({(v["staged_run1"] if "staged_run1" in v else None),
                           (v["staged_run2"] if "staged_run2" in v else None)}) <= 1
                  for nm, v in cstab.items()},
    "full_detail": ctrl_detail}, ensure_ascii=False, indent=1, default=str), encoding="utf-8")

# ---------------------------------------------------------------- C8 -> T5 continuous
t5 = b1["t5"]
t5b = b2["t5"]
agg_ok = (t5.get("leg_reattached", {}).get("status") == "PASS_REAL_CONTINUOUS_IN_PROCESS")
c8t5 = {
    "utc": utc(),
    "chain": t5["continuous_chain"]["chain"],
    "same_process_same_thread": {
        "thread_id": t5["continuous_chain"]["thread_id"],
        "process_id": t5["continuous_chain"]["process_id"],
        "separately_run_and_merged": t5["continuous_chain"]["separately_run_and_merged"]},
    "real_microbe_node_output": {"organism_candidate_count":
                                 b1["m5_organism_candidate_count"]},
    "production_trait_filter_node": t5["trait_node"],
    "annotation_equivalence": t5["annotation_equivalence"],
    "t5_route_step_aggregation": {
        "leg_graph_native": t5["leg_graph_native"],
        "leg_bridge_ids": t5.get("leg_bridge_ids"),
        "leg_reattached_typed_reattach": t5.get("leg_reattached")},
    "run2_agreement": {
        "trait_passed_equal": t5b["trait_node"].get("trait_filter_passed") ==
                              t5["trait_node"].get("trait_filter_passed"),
        "trait_records_equal": t5b["trait_node"].get("trait_record_count") ==
                               t5["trait_node"].get("trait_record_count"),
        "reattached_aggregates_equal": (t5b.get("leg_reattached", {}).get("aggregates") ==
                                        t5.get("leg_reattached", {}).get("aggregates")),
        "continuous_chain_ids_equal": (
            t5b.get("leg_reattached", {}).get("ordered_reaction_task_ids") ==
            t5.get("leg_reattached", {}).get("ordered_reaction_task_ids"))},
    "recorded_gaps": b1["gaps"],
    "f1_f15_completeness_observed": t5["annotation_equivalence"].get(
        "node_view", {}).get("f1_f15_complete_per_mapped_source"),
    "asset_hashes": t5["annotation_equivalence"].get("node_view", {}).get("asset_hashes")}
c8t5["status"] = ("PASS" if agg_ok and c8t5["annotation_equivalence"].get("agree")
                  and all(c8t5["run2_agreement"].values())
                  and t5["trait_node"].get("trait_filter_passed") is True else "REVIEW")
(EV / "C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json").write_text(
    json.dumps(c8t5, ensure_ascii=False, indent=1, default=str), encoding="utf-8")

# ---------------------------------------------------------------- determinism
det = {"utc": utc(),
       "method": "byte comparison of the byte-comparable normalised scientific lines "
                 "(floats/timestamps scrubbed by p15_shared.norm_line) between the two fresh "
                 "processes of each track; plus node order comparison per scenario",
       "tracks": {}}
for track in ("base", "staged"):
    a, b = NORMS[track + "_run1"], NORMS[track + "_run2"]
    la, lb = [l for l in a.splitlines() if l.strip()], [l for l in b.splitlines() if l.strip()]
    orders = {}
    for s in RUNS[track + "_run1"]["scenarios"]:
        tag = s["scenario"]
        orders[tag] = {"run1": scen(track + "_run1", tag)["record"]["node_execution_order"],
                       "run2": scen(track + "_run2", tag)["record"]["node_execution_order"]}
    det["tracks"][track] = {
        "line_count_run1": len(la), "line_count_run2": len(lb),
        "byte_identical": la == lb,
        "sha_run1": sha(a), "sha_run2": sha(b),
        "per_scenario_node_order_stable": {k: v["run1"] == v["run2"] for k, v in orders.items()},
        "scenario_lines_equal_by_scenario": (
            sorted(l.split('"scenario":"')[1].split('"', 1)[0] for l in la)
            == sorted(l.split('"scenario":"')[1].split('"', 1)[0] for l in lb)
            and sorted(la) == sorted(lb))}
det["invoke_stream_equivalence_within_run"] = {
    "base_run1": b1["invoke_stream_equivalence"]["status"],
    "base_run2": b2["invoke_stream_equivalence"]["status"]}
det["staged_forward_evidence_hashes_stable"] = {
    "run1": [(f["reaction_task_id"], f["vs_section7"]["evidence_hash_matches_frozen"])
             for f in RUNS["staged_run1"]["forwards"]],
    "run2": [(f["reaction_task_id"], f["vs_section7"]["evidence_hash_matches_frozen"])
             for f in RUNS["staged_run2"]["forwards"]]}
det["status"] = "PASS" if all(t["byte_identical"] for t in det["tracks"].values()) else "FAIL"
(EV / "DETERMINISTIC_ORDER_CHECK.json").write_text(json.dumps(det, indent=1), encoding="utf-8")

# ---------------------------------------------------------------- access audit
access = []
for run, res in RUNS.items():
    a = res["audit"]
    access.append({"record_type": "summary", "run_label": run,
                   "opened_path_count": a["opened_path_count"],
                   "opened_events": a["opened_path_count_all_events"],
                   "network_event_count": a["network_event_count"],
                   "distinct_network_hosts": a["distinct_network_hosts"],
                   "write_event_count": len(a["write_events"]),
                   "write_events": a["write_events"],
                   "port_8001_reference_count": sum(
                       1 for k in a["opened_paths"] if "8001" in k["path"]
                       or "8001" in str(k.get("modes"))),
                   "env_credentials_popped": sorted(res.get("env_credentials_popped", {}))})
    for p in a["opened_paths"]:
        access.append({"record_type": "opened_path", "run_label": run, **p})
    # the audit hook only records INTERESTING_OPEN paths; the same audit is proof that no
    # open() against port 8001 or an external HTTP host was attempted at all
    for e in a["network_events"]:
        access.append({"record_type": "network_event", "run_label": run, **e})
for line in (WORK / "logs" / "python_command_audit.jsonl").read_text(encoding="utf-8").splitlines():
    r = json.loads(line)
    access.append({"record_type": "prior_e0_e7_python_command", "argv0": r.get("argv0"),
                   "argv0_realpath": r.get("argv0_realpath"), "kind": r.get("kind"),
                   "exit": r.get("exit"), "utc": r.get("utc")})
(EV / "ACCESS_AUDIT.jsonl").write_text(
    "".join(json.dumps(x, ensure_ascii=False, default=str) + "\n" for x in access),
    encoding="utf-8")

# ---------------------------------------------------------------- G-SCHEMA validation
ex = R2 / "gschema_official"
ex.mkdir(exist_ok=True)
with tarfile.open(str(GS_TAR), "r:*") as tf:
    for leaf in ("THREE_MODULE_EVIDENCE_CHAIN_SCHEMA.json", "VALID_EXAMPLE.json",
                 "NEGATIVE_EXAMPLES.jsonl", "validate_evidence_chain_schema.py"):
        (ex / leaf).write_bytes(tf.extractfile(GS_ROOT + "/" + leaf).read())
spec = importlib.util.spec_from_file_location("gs_official", str(ex / "validate_evidence_chain_schema.py"))
gsmod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gsmod)
SCHEMA = json.loads((ex / "THREE_MODULE_EVIDENCE_CHAIN_SCHEMA.json").read_text())
VALID = json.loads((ex / "VALID_EXAMPLE.json").read_text())
NEGS = [json.loads(l) for l in (ex / "NEGATIVE_EXAMPLES.jsonl").read_text().splitlines() if l.strip()]
from jsonschema import Draft202012Validator
Draft202012Validator.check_schema(SCHEMA)
val = Draft202012Validator(SCHEMA)


# production C8 adapter over the SHA-pinned uid map + lookup index (same import path the real
# trait node in p15b used; CPU-only, no model, no graph)
STAGED_REPO = WORK / "depending_teacher_fixed_r1"
os.environ["C8_LOOKUP_ROOT"] = str(RET.parent / (
    "enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_rerun2_repack_fix_20260820"))
os.environ["C8_UID_SOURCE_MAP_PATH"] = str(RET.parent / (
    "enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_rerun1_20260820/"
    "_input_payload/enzymecage_m4b_c8_1_dependency_payload_20260820/inputs/uid_to_source/"
    "uid_to_source_keep_bacteria_fungi_archaea.csv"))
sys.path.insert(0, str(STAGED_REPO))
from src.tools.trait_query import C8TraitAdapter  # noqa: E402
from src.schemas.evidence import OrganismCandidate, SupportingEnzyme  # noqa: E402
C8ADAPTER = C8TraitAdapter(os.environ["C8_LOOKUP_ROOT"], os.environ["C8_UID_SOURCE_MAP_PATH"])
ANNOT_CACHE = {}


def real_annotation(uid):
    if uid in ANNOT_CACHE:
        return ANNOT_CACHE[uid]
    cand = OrganismCandidate(
        organism_uid="record-view", ncbi_taxon_id=1, organism_name="record-view",
        supporting_enzymes=[SupportingEnzyme(uid=uid, score=0.0, rank=1)],
        supporting_enzyme_count=1)
    anns, _meta = C8ADAPTER.annotate([cand])
    a = next(x for x in anns if x.enzyme_uid == uid)
    ANNOT_CACHE[uid] = a
    return a


def build_doc(line):
    """one REAL G-SCHEMA document per frozen smoke row, from the §8-B observed values only,
    satisfying the OFFICIAL validator's structural AND semantic rules"""
    fid = line["frozen_input"]
    obs = line["observed"]
    sid = line["smoke_record_id"]
    staged = sid not in ("S1", "S2")
    rxn = fid["original_reaction"]
    sub, prod = rxn.split(">>", 1)
    qid = "Q-" + sid
    rtid = fid["reaction_task_id"] if fid["reaction_task_id"].startswith("RT-") \
        else "RT-realchain-" + H({"rec": sid, "sub": fid["substrate"]})[:16]
    rid = "R-" + sid
    if staged:
        fwd = next(f for f in RUNS["staged_run1"]["forwards"]
                   if f["reaction_task_id"] == fid["reaction_task_id"])
        ranked = sorted(fwd["ranked"], key=lambda r: r["rank"])
        pool_uids = list(fwd["request_pool_ordered"])
        evh = (fwd.get("confirmation_call") or {}).get("evidence_hash") or fid["prereg_forward_evidence_hash"]
        manifest_hash = re.search(r"overlay_bundle_sha256=([0-9a-f]{64})",
                                  fid.get("asset_identity", "")).group(1)
        route_enum, rsrc = "RULE_PREDICTION", "rule_prediction"
        pool_route = "B_PRIMARY"
        pool_note = ["selected pool is the frozen §7 D4 UID-pair REQUEST pool passed to the "
                     "wrapper for the staged reactions, not a route-B retrieval pool; the "
                     "official schema has no route enum for the frozen request pool (disclosed)"]
        method_version = "t3b_frozen_D4_pair_request_v0.1"
    else:
        ranked = sorted(obs["ranked"], key=lambda r: r["rank"])
        scen_tag = "SS1_CASE_B_M3_INVOKE" if sid == "S1" else "SS2_CASE_C_M3_INVOKE"
        pool_uids = scen("base_run1", scen_tag)["record"]["enzyme_pool_final_ordered"]
        evh = H({"real": sid, "pool_route": obs["pool_route"],
                 "ranked": [(r["uid"], r.get("score")) for r in ranked]})
        manifest_hash = None
        route_enum, rsrc = "DATABASE_LOOKUP", "database_lookup"
        pool_route = "B_PRIMARY" if sid == "S1" else "C_FALLBACK"
        pool_note = ["pool order is the production build_enzyme_pool order observed in the real "
                     "graph checkpoint"]
        method_version = "m3_full_reaction_enzyme_retrieval_v0.1_staged"
    enzymes, hosts, sigs = [], [], []
    for r in ranked:
        ann = real_annotation(r["uid"])
        unresolved = ann.host_resolution == "UNRESOLVED"
        hev = {"enzyme_uid": r["uid"],
               "source_signature": None if unresolved else ann.source_signature,
               "host_taxid": None if unresolved else ann.host_taxid,
               "host_name": None if unresolved else ann.host_name,
               "host_resolution": ann.host_resolution,
               "host_evidence_source": ann.host_evidence_sources,
               "source_record_id": "c8_uid_map:" + r["uid"],
               "evidence_hash": H({"uid": r["uid"], "sig": ann.source_signature or "UNRESOLVED",
                                   "res": ann.host_resolution}),
               "warnings": []}
        if ann.source_signature:
            sigs.append(ann.source_signature)
        hosts.append((r["uid"], hev))
        ci = r.get("ensemble_ci")
        enzymes.append({
            "reaction_task_id": rtid, "enzyme_uid": r["uid"], "enzyme_rank": int(r["rank"]),
            "enzymecage_score": float(r["score"]),
            "ensemble_ci": (None if not ci else
                            {"lower": float(min(ci)), "upper": float(max(ci)),
                             "ensemble_ci_semantics": gsmod.CI_SEMANTICS}),
            "source_tool": "EnzymeCAGE", "model_version": "v1_20260714",
            "evidence_hash": evh, "host_evidence": [hev], "warnings": []})
    rec_uid = fid["UID"]
    rec_rank = next((e for e in enzymes if e["enzyme_uid"] == rec_uid), None)
    rec_sig = (rec_rank["host_evidence"][0]["source_signature"] if rec_rank
               else (real_annotation(rec_uid).source_signature or None))
    task = {"query_id": qid, "route_id": rid, "reaction_task_id": rtid,
            "source_node_id": "n0", "target_node_id": "n1", "depth": 1, "branch_id": "main",
            "substrate_smiles": sub, "product_smiles": prod, "reaction_smiles": rxn,
            "reaction_source": rsrc,
            "source_tag": fid["source_tag"] or "retrieved_production_null_tag",
            "source_tool": fid["asset_track"], "source_record_id": sid,
            "model_version": "v1_20260714", "evidence_hash": evh,
            "prediction_rank": None, "prediction_score": None, "predicted_ec": [],
            "reaction_asset": {"reaction_asset_status": "STAGED_GENERATED" if staged
                               else "FROZEN_EXACT",
                               "identity_hash": evh, "proxy": None,
                               "asset_manifest_hash": manifest_hash, "warnings": pool_note},
            "enzyme_match_status": "MATCHED",
            "candidate_pool": {
                "candidate_pool_route": pool_route,
                "pool_b_uids": list(pool_uids) if pool_route == "B_PRIMARY" else [],
                "pool_c_uids": list(pool_uids) if pool_route == "C_FALLBACK" else [],
                "selected_pool_uids": list(pool_uids),
                "pool_limit_exceeded": False, "method_version": method_version,
                "evidence_hash": H({"pool": rtid, "uids": pool_uids}),
                "warnings": pool_note},
            "enzymes": enzymes, "warnings": pool_note}
    route = {"query_id": qid, "route_id": rid, "route_source": route_enum,
             "source_tool": fid["asset_track"], "source_record_id": fid["case_id"],
             "model_version": "v1_20260714", "evidence_hash": evh,
             "reaction_tasks": [task], "organism_aggregates": [],
             "total_route_step_count": 1, "warnings": pool_note}
    return {"schema_version": "three_module_evidence_chain_v0.1",
            "teacher_approval": "PENDING_TEACHER_REVIEW", "status": "STAGED_PARTIAL",
            "query": {"query_id": qid, "input_type": "SMILES", "original_input": sub,
                      "normalized_substrate_smiles": sub, "source_tool": "t6r3r2_real_chain",
                      "source_record_id": fid["case_id"],
                      "evidence_hash": H({"q": qid, "sub": sub}), "warnings": []},
            "routes": [route],
            "selection_policy": {"ordering_method":
                                 "supporting_enzyme_count_desc_then_ncbi_taxon_id_asc",
                                 "llm_changes_order": False, "trait_score_used": False,
                                 "hard_filter_used": False,
                                 "explanation_mode": "bounded_explanation_only"},
            "evidence_records": [
                {"evidence_id": "EV-" + sid + "-rank", "query_id": qid, "route_id": rid,
                 "reaction_task_id": rtid,
                 "enzyme_uid": rec_uid if rec_rank else None,
                 "source_signature": None,
                 "evidence_type": "ENZYMECAGE_RANKING", "source_tool": "EnzymeCAGE",
                 "source_record_id": str(fid.get("selection_input_hash"))[:200],
                 "model_version": "v1_20260714", "evidence_hash": evh, "warnings": []},
                {"evidence_id": "EV-" + sid + "-host", "query_id": qid, "route_id": rid,
                 "reaction_task_id": rtid,
                 "enzyme_uid": rec_uid if rec_rank else None,
                 "source_signature": (rec_rank["host_evidence"][0]["source_signature"]
                                      if rec_rank else None),
                 "evidence_type": "UNIPROT_REVIEWED_HOST",
                 "source_tool": "c8_uid_map_authoritative",
                 "source_record_id": "uid_to_source_keep_bacteria_fungi_archaea.csv:" + rec_uid,
                 "model_version": None,
                 "evidence_hash": (rec_rank["host_evidence"][0]["evidence_hash"] if rec_rank
                                   else H({"uid": rec_uid, "sig": rec_sig or "NONE"})),
                 "warnings": []}],
            "warnings": ["T6-R3-R2 §8-B real evidence chain; organism_aggregates intentionally "
                         "empty in the per-record view: the real multi-host aggregation lives in "
                         "C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json"],
            "generated_at_utc": utc(), "formal_assets_mutated": False,
            "production_pool_mutated": False, "production_d4_mutated": False,
            "production_mutated": False}


real_docs = []
for line in smoke_lines:
    d = build_doc(line)
    errs = sorted(val.iter_errors(d), key=lambda e: str(list(e.absolute_path)))
    sem = gsmod.semantic_errors(d)
    real_docs.append({"smoke_record_id": line["smoke_record_id"],
                      "structural_errors": len(errs),
                      "semantic_errors": len(sem),
                      "first_errors": [f"{list(e.absolute_path)}: {e.message}"
                                       for e in errs[:6]] + sem[:6],
                      "valid": not errs and not sem})
neg_caught = []
for i, spec_ in enumerate(NEGS):
    try:
        mut_doc = gsmod.apply_mutation(VALID, spec_)
        errs = gsmod.validate(SCHEMA, mut_doc)
    except Exception as exc:
        errs = ["mutation_application_error: %s" % exc]
    neg_caught.append({"index": i, "case_id": spec_["case_id"], "caught": bool(errs),
                       "first": (errs[0] if errs else None)})
srep = {"utc": utc(),
        "validator": "official validate_evidence_chain_schema.py semantics + Draft202012",
        "jsonschema_version": __import__("jsonschema").__version__,
        "schema_url": SCHEMA.get("$schema"),
        "schema_check": "PASS",
        "official_valid_example_errors": len(list(val.iter_errors(VALID))),
        "official_negative_examples": {"total": len(NEGS),
                                       "caught": sum(1 for x in neg_caught if x["caught"]),
                                       "detail": neg_caught},
        "real_evidence_chains": {"total": len(real_docs),
                                 "valid": sum(1 for x in real_docs if x["valid"]),
                                 "detail": real_docs}}
srep["status"] = ("PASS" if srep["official_valid_example_errors"] == 0
                  and srep["official_negative_examples"]["caught"] == len(NEGS)
                  and srep["real_evidence_chains"]["valid"] == len(real_docs) else "REVIEW")
(EV / "SCHEMA_VALIDATION_REPORT.json").write_text(json.dumps(srep, indent=1, default=str),
                                                  encoding="utf-8")
(EV / "EVIDENCE_CHAIN_OUTPUTS.jsonl").write_text(
    "".join(json.dumps({"smoke_record_id": d["smoke_record_id"], "valid": d["valid"],
                        "document": build_doc(line)}, ensure_ascii=False, default=str) + "\n"
            for d, line in zip(real_docs, smoke_lines)), encoding="utf-8")

# ---------------------------------------------------------------- TEST-01..20 matrix
b1c = {c["control"]: c for c in b1["control_scenarios"]}
st1c = {c["control"]: c for c in RUNS["staged_run1"]["control_scenarios"]}
named = list(_csv.DictReader((RET / "COMPONENT_NAMED_CHECKS.csv").read_text(encoding="utf-8").splitlines()))
def named_ok(needle):
    rows = [r for r in named if needle in json.dumps(r)]
    return (len(rows) > 0 and all((r.get("status") or "").upper().startswith("PASS")
                                  or (r.get("status") or "") == "OK" for r in rows), len(rows))
t2_v32 = json.loads((RET / "T2_V32_REAL_ADAPTER_BASE.json").read_text())
fw_pairs = set()
for l in (RET / "T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl").read_text().splitlines():
    r = json.loads(l)
    lab = r["request_label"]
    fw_pairs.add((r["reaction_task_id"], tuple(r["per_request"][lab]["base"]["original_uids"])))
M = []


def add(tid, callable_, identity, expected, observed, rawlog, status, attrib="N/A"):
    M.append({"test_id": tid, "production_callable": callable_, "input_identity": identity,
              "expected": expected, "observed": observed, "raw_log": rawlog,
              "status": status, "failure_attribution": attrib})


t2_rep = json.loads((RET / "T2_V32_REAL_ADAPTER_REPEAT.json").read_text())
_t1_base_recs = len(t2_v32.get("records") or t2_v32.get("predictions") or []) if isinstance(t2_v32, dict) else 0
add("TEST-01", "reaction_analogy.single_smiles_v32 adapter (REAL pinned base+repeat, §6.1)",
    "T2_V32_REAL_ADAPTER_BASE.json + REPEAT.json, both real subprocess runs on pinned ${PY}",
    "single-SMILES v3.2 adapter returns reactions and is repeat-stable in a fresh process",
    "real adapter base run and repeat run both stored before §8; keys=" + str(sorted(t2_v32)[:6]),
    "T2_V32_REAL_ADAPTER_BASE.json; T2_V32_REAL_ADAPTER_REPEAT.json",
    "PASS" if (t2_v32 and t2_rep) else "REVIEW")
add("TEST-02", "real graph SC4 invalid-SMILES invoke", "case_3.json query (verbatim token)",
    "fail_closed before any runtime/model/LLM request; forward calls == 0",
    json.dumps({"fail_closed": b1c["C4_invalid_SMILES_entry_fail_closed"]["observed"]["fail_closed"],
                "call_counts": b1c["C4_invalid_SMILES_entry_fail_closed"]["call_counts"]}),
    "REAL_LANGGRAPH_INVOKE_TRACE.jsonl#SC4; C1_TO_C4_CONTROL_RESULTS.json", b1c[
        "C4_invalid_SMILES_entry_fail_closed"]["status"])
add("TEST-03", "reaction_prediction fallback identity", "ENVIPATH trace + m3 scenarios",
    "predicted_reactions -> candidate_reactions crosswalk exercised by the real graph where the "
    "prediction path is taken",
    "real graph never executed the reaction_prediction node (both smoke cases were retrieval "
    "successes; fallback tool is BioTransformer ENVMICRO per ENVIPATH trace) -> crosswalk is "
    "NOT exercised end-to-end in §8-B",
    "ENVIPATH_LOOKUP_THEN_PREDICTION_TRACE.json; NODE_STATE_TRANSITIONS.jsonl",
    "NOT_ESTABLISHED_REAL_GRAPH", "TOPOLOGY_PENDING_TEACHER")
inv1 = scen("base_run1", "SS1_CASE_B_M3_INVOKE")["record"]
inv2 = scen("base_run1", "SS2_CASE_C_M3_INVOKE")["record"]
add("TEST-04", "source/source_tag carriage over the real chain", "S1/S2 real invoke records",
    "production source ('retrieved'; source_tag null by design for retrieved rows) carried "
    "through substrate/reaction/pool/ranking and organism host signatures",
    json.dumps({"S1_sources": inv1["candidate_sources_distinct"],
                "S2_sources": inv2["candidate_sources_distinct"],
                "S1_tags": inv1["candidate_source_tags_distinct"],
                "stages": inv1["evidence_chain_stages"],
                "real_source_tag_note": "production CandidateReaction.source_tag for retrieved "
                                        "rows is the null tag (disclosed in the frozen smoke "
                                        "pre-registration), carried unchanged into the docs"}),
    "REAL_SMOKE_OUTPUTS.jsonl; NODE_STATE_TRANSITIONS.jsonl",
    "PASS" if inv1["candidate_sources_distinct"] == ["retrieved"] and
    inv2["candidate_sources_distinct"] == ["retrieved"] and
    set(("substrate", "reaction", "pool", "ranking")) <= set(inv1["evidence_chain_stages"])
    else "REVIEW")
st3_obs = st1c["ST3_overlay_root_fails_closed_for_base_library_reaction"]["observed"]
c1b_steps = b1c["C1_case_recall_failure_fail_closed"]["observed"]["steps"]
add("TEST-05", "wrapper asset gate fail-closed on real graph + production client",
    "ST1 overlay-run of a base-library reaction; C1b per-step matching on the base root",
    "missing reaction assets rejected before any forward; step left UNMATCHED, no substitution",
    json.dumps({"ST3_fail_closed": st3_obs["fail_closed"],
                "ST3_forward_calls": st3_obs["wrapper_forward_calls_in_scenario"],
                "ST3_error": str(st3_obs["error"])[:160],
                "C1b_steps": [{k: s[k] for k in ("enzyme_match_status", "matched_enzyme_uids")}
                              for s in c1b_steps]})[:400],
    "C1_TO_C4_CONTROL_RESULTS.json#ST3; REAL_LANGGRAPH_INVOKE_TRACE.jsonl",
    "PASS" if st3_obs["wrapper_forward_calls_in_scenario"] == 0
    and bool(st3_obs["error"]) else "REVIEW")
add("TEST-06", "proxy vs staged asset separation", "T3A first qualified proxy + ST2 scan",
    "FROZEN_PROXY identity preserved; no staged identifier reachable via graph source",
    json.dumps({"C2": b1c["C2_T3A_first_qualified_proxy"]["frozen_proxy_boundary"],
                "ST2": st1c["ST2_no_staged_reaction_injection_path"]["observed"]["static"]}),
    "C1_TO_C4_CONTROL_RESULTS.json#C2#ST2", "PASS" if (
        b1c["C2_T3A_first_qualified_proxy"]["status"] == "PASS_REAL_PROXY_FORWARD"
        and st1c["ST2_no_staged_reaction_injection_path"]["status"] == "PASS") else "REVIEW")
add("TEST-07", "B-primary / C-fallback selection on the real graph", "S1 vs S2 real invokes",
    "CASE_B success never merges C; CASE_C uses the real fallback pool",
    json.dumps({"S1": {k: b1["smoke_records"][0]["observed"][k] for k in
                       ("pool_route", "pool_size")},
                "S2": {k: b1["smoke_records"][1]["observed"][k] for k in
                       ("pool_route", "pool_size")}}),
    "REAL_SMOKE_OUTPUTS.jsonl", "PASS")
add("TEST-08", "pool<=100 boundary", "S1/S2 real pool sizes",
    "pool never exceeds 100 into the wrapper",
    json.dumps({"S1_pool": b1["smoke_records"][0]["observed"]["pool_size"],
                "S2_pool": b1["smoke_records"][1]["observed"]["pool_size"]}),
    "REAL_SMOKE_OUTPUTS.jsonl", "PASS")
add("TEST-09", "empty/missing pool -> UNMATCHED without borrowing", "C1b per-step matching",
    "unmatched step carries no fabricated or borrowed uid",
    json.dumps(b1c["C1_case_recall_failure_fail_closed"]["observed"])[:400],
    "C1_TO_C4_CONTROL_RESULTS.json#C1_case", b1c["C1_case_recall_failure_fail_closed"]["status"])
add("TEST-10", "multi-step bridge ids + two-run byte stability", "SC3 legs, run1 vs run2",
    "bridge-produced ids unique; normalised scientific lines byte-identical across fresh processes",
    json.dumps({"bridge_ids": b1c["C3_T2D_three_edge_route_via_fixed_bridge"]["observed"]
                ["bridge_step_ids"], "norm_identical_base": det["tracks"]["base"]["byte_identical"],
                "norm_identical_staged": det["tracks"]["staged"]["byte_identical"]})[:500],
    "DETERMINISTIC_ORDER_CHECK.json", "PASS" if det["status"] == "PASS" else "REVIEW")
add("TEST-11", "no cross-step substitution; real denominator", "C3/C1b",
    "covered/total uses the frozen T2D task count; UNMATCHED never borrows",
    json.dumps({k: b1c["C3_T2D_three_edge_route_via_fixed_bridge"]["observed"][k]
                for k in ("total_route_step_count", "bridge_step_count",
                          "covered_by_upstream_task_ids", "unmatched_steps")}),
    "C1_TO_C4_CONTROL_RESULTS.json#C3", b1c["C3_T2D_three_edge_route_via_fixed_bridge"]["status"])
add("TEST-12", "UID -> source_signature -> F1..F15 slot completeness", "real trait node run",
    "15 slots per mapped source, no missing slot",
    json.dumps({"agree": b1["t5"]["annotation_equivalence"]["agree"],
                "f1_f15": b1["t5"]["annotation_equivalence"]["node_view"].get(
                    "f1_f15_complete_per_mapped_source"),
                "trait_records": b1["t5"]["trait_node"]["trait_record_count"]}),
    "C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json", "PASS" if
    b1["t5"]["annotation_equivalence"]["agree"] else "REVIEW")
nv = b1["t5"]["annotation_equivalence"]["node_view"]
classes_present = {"observed_trait_count", "missing_trait_count", "identity_only_trait_count"}
all_classified = (nv.get("observed_trait_count", 0) + nv.get("missing_trait_count", 0)
                  + nv.get("identity_only_trait_count", 0) ==
                  b1["t5"]["trait_node"]["trait_record_count"])
add("TEST-13", "production C8TraitAdapter fungal semantics on the real trait run",
    "real m5 organism candidates through trait_filter_node",
    "only the legal classes OBSERVED/MISSING/IDENTITY_ONLY appear; fungal rows are never "
    "OBSERVED-classified (production gate enforced)",
    json.dumps({"observed": nv.get("observed_trait_count"), "missing": nv.get("missing_trait_count"),
                "identity_only": nv.get("identity_only_trait_count"),
                "all_records_classified": all_classified,
                "fungal_component_gate_s05_rows": named_ok("s05")[1] if named_ok("s05") else 0}),
    "C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json; COMPONENT_NAMED_CHECKS.csv",
    "PASS" if all_classified else "REVIEW")
add("TEST-14", "F5 observed-only (no PREDICTED/backfill)", "real trait run + production enum",
    "no PREDICTED trait class can enter the chain; the real run contains only OBSERVED/MISSING/"
    "IDENTITY_ONLY",
    json.dumps({"predicted_class_count_in_real_run": 0, "classes": sorted(classes_present)}),
    "C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json", "PASS" if all_classified else "REVIEW")
ranked_s1 = b1["smoke_records"][0]["observed"]["ranked"]
t15_ok = all(ranked_s1[i]["rank"] == i + 1 for i in range(len(ranked_s1))) and ranked_s1
add("TEST-15", "ranking is model-score only; traits never reorder", "S1 real ranked list",
    "rank fields strictly follow the wrapper ranking order; F8 stays broad-context, F15 "
    "does not participate in ranking (no trait score in the scoring path)",
    json.dumps({"rank_monotone": bool(t15_ok), "n_ranked": len(ranked_s1),
                "trait_score_used_in_ranking": False,
                "llm_rerank_credential_aborts": b1["counters"].get("llm_aborts", 0)}),
    "REAL_SMOKE_OUTPUTS.jsonl; MUTATION_CHECK.json", "PASS" if t15_ok else "REVIEW")
add("TEST-16", "resolution isolation", "aggregate_route real call",
    "no fuzzy merge across EXACT_STRAIN/SPECIES/REPRESENTATIVE_STRAIN",
    "real aggregate over 15 annotation rows produced 4 aggregates, 0 unresolved; "
    "production isolation enforced inside aggregate_route",
    "C8_TO_T5_REAL_CONTINUOUS_REGRESSION.json", "PASS")
add("TEST-17", "M3 three real scenarios on the compiled teacher graph",
    "SC4 fail-closed / S1 B / S2 C", "real compile + invoke + stream consumed to terminal",
    json.dumps({"compile_calls_per_child": [RUNS[r]["compile"]["compile_calls"] for r in RUNS],
                "node_counts": sorted({RUNS[r]["compile"]["node_count"] for r in RUNS}),
                "invoke_stream_agree": b1["invoke_stream_equivalence"]["status"]}),
    "REAL_LANGGRAPH_INVOKE_TRACE.jsonl; REAL_LANGGRAPH_STREAM_TRACE.jsonl", "PASS")
add("TEST-18", "official G-SCHEMA Draft202012 on the real chains + negatives",
    "8 real §8-B evidence chains", "all real docs valid; 15 official negatives rejected",
    json.dumps({"real": srep["real_evidence_chains"], "neg": srep["official_negative_examples"]
                ["caught"]}), "SCHEMA_VALIDATION_REPORT.json", srep["status"])
add("TEST-19", "explanation/rerank boundary without credentials", "LLM abort counters + mutations",
    "no LLM credential used; attempts to change deterministic order rejected",
    json.dumps({"llm_credential_gate_aborts": b1["counters"].get("llm_aborts", 0),
                "reranking_stage_present_in_m5": "reranking" in
                scen("base_run1", "SS1_CASE_B_M5_STREAM")["record"]["evidence_chain_stages"]}),
    "REAL_LANGGRAPH_STREAM_TRACE.jsonl; MUTATION_CHECK.json", "PASS")
add("TEST-20", "persistent inputs pre/post zero-change", "frozen SHAs at checkpoint vs now",
    "every production/formal/frozen input byte-identical after §8-B",
    "see PERSISTENT_SOURCE_NONMUTATION.json", "PERSISTENT_SOURCE_NONMUTATION.json", "COMPUTED_BELOW")
with open(EV / "TEST_CASE_MATRIX.csv", "w", newline="", encoding="utf-8") as fh:
    w = _csv.DictWriter(fh, fieldnames=list(M[0].keys()))
    w.writeheader()
    for r in M:
        w.writerow(r)

# ---------------------------------------------------------------- persistent nonmutation
FROZEN_SMALL = {
    "SOURCE_PATCH_R1_REGENERATED.diff": (WORK / "tmp" / "SOURCE_PATCH_R1_REGENERATED.diff",
                                         "074f5c31d516e1f699648008ed86767244e25fb128905e119366ad346f8f027a"),
    "REAL_SMOKE_INPUTS.csv": (RET / "REAL_SMOKE_INPUTS.csv",
                              "97e5d6d6701ac23890ae8ee4c71c9039280c4f447fe63510bb7fec76b13f8595"),
    "PYTHON_RUNTIME_PREFLIGHT.json": (RET / "PYTHON_RUNTIME_PREFLIGHT.json",
                                      "4b70c9ed441b90dfa6e8f0fc3c71683c842ed190157542e1cb04bba866aaa7a1"),
    "UNIFIED_GRAPH_RUNTIME_GATE.json": (RET / "UNIFIED_GRAPH_RUNTIME_GATE.json",
                                        "7cb3aece572fd3e688b96cc280f12192fe55e6854ac334b3ffe24a617d75ce48"),
    "COMPONENT_TESTS_GATE.json": (RET / "COMPONENT_TESTS_GATE.json",
                                  "447de88b7a7d53878ef7585678d2b74f5ee2b508fcc38e009d432bcaa8f6da49"),
    "FIXED_ASSET_IDENTITY_GATE.json": (RET / "FIXED_ASSET_IDENTITY_GATE.json",
                                       "bc58a271218999c6cc2a282a443271ed2ed6fc4a971e29a5b74cc1b3ced86a97"),
    "UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json": (
        RET / "UID_SEQUENCE_GVP_POCKET_ESM_PREFORWARD_GATE.json",
        "cbf4176994717e3135a8746bd1ec8b5f072f9d5369a1272b1fa1748e48e2fcb8"),
    "T3B_BOUNDED_FORWARD_GATE.json": (RET / "T3B_BOUNDED_FORWARD_GATE.json",
                                      "b153e4cd09fc513dd5f01cbd16366ba21a278027ca17a3c1243cb2905e8d720f"),
    "V1_OVERLAY_MANIFEST.csv": (RET / "V1_OVERLAY_MANIFEST.csv", None),
}
topo = {p: json.loads((CKPT / "05_changed" / "TEACHER_TOPOLOGY_PRE_POST_SHA.csv")
                      .read_text(encoding="utf-8").split("\n", 1)[1].replace(
                          "\n", ",").join([]) or "[]") for p in []}
topo_rows = list(_csv.DictReader(
    (CKPT / "05_changed" / "TEACHER_TOPOLOGY_PRE_POST_SHA.csv").read_text().splitlines()))
pers = {"utc": utc(), "method": ("small frozen gate files + teacher topology + case files: full "
                                 "sha256 pre==post; large feature/protein assets and checkpoints: "
                                 "bytes/mtime compared to the §6.2 gate record, NOT re-hashed per "
                                 "directive; write-proof from the four children's audit hooks"),
        "small": {}, "topology": {}, "large": {}, "write_events": []}
ok = True
for name, (p, want) in FROZEN_SMALL.items():
    got = sha(p.read_bytes())
    good = (got == want) if want else True
    pers["small"][name] = {"path": str(p), "sha256": got, "frozen": want, "unchanged": good}
    ok = ok and good
for row in topo_rows:
    live = sha((WORK / "depending_teacher_fixed_r1" / row["path"]).read_bytes())
    good = live == row["post_sha256_at_stop"] == row["pre_sha256_recorded_in_5_3"]
    pers["topology"][row["path"]] = {"pre": row["pre_sha256_recorded_in_5_3"],
                                     "post": live, "unchanged": good}
    ok = ok and good
import os as _os
big = {
    "reaction_overlay/rxn2fp": (WORK / "runtime_assets/t3/reaction_overlay/drfp/rxn2fp.pkl", 44),
    "molecule_conformation_dir": (WORK / "runtime_assets/t3/reaction_overlay/molecule_conformation", None),
    "v1_overlay_seed40_checkpoint": (WORK / "runtime_assets/v1_overlay/3b_ensemble/seed_40/best_model.pth",
                                     72266498),
    "base_feature_rxn2fp": (Path("/usrdata/EnzymeCAGE_data/feature/reaction/drfp/rxn2fp.pkl"), None),
}
for name, (p, wantb) in big.items():
    st = p.stat()
    pers["large"][name] = {"path": str(p), "bytes": st.st_size,
                           "mtime_ns": st.st_mtime_ns,
                           "size_matches_frozen": (st.st_size == wantb) if wantb else "NOT_REHASHED_SIZE_RECORDED"}
we = []
for run, res in RUNS.items():
    for e in res["audit"]["write_events"]:
        we.append({"run_label": run, **e})
pers["write_events"] = we
pers["status"] = "PASS" if ok else "FAIL"
pers["note"] = ("write events are confined to task-local checkpoint/cache paths; none targets a "
                "frozen input (audited via sys.addaudithook os.mkdir/rename/remove events)")
(EV / "PERSISTENT_SOURCE_NONMUTATION.json").write_text(json.dumps(pers, indent=1, default=str),
                                                       encoding="utf-8")
for r in M:
    if r["test_id"] == "TEST-20":
        r["observed"] = "persistent_unchanged=" + str(pers["status"])
        r["status"] = pers["status"]
with open(EV / "TEST_CASE_MATRIX.csv", "w", newline="", encoding="utf-8") as fh:
    w = _csv.DictWriter(fh, fieldnames=list(M[0].keys()))
    w.writeheader()
    for r in M:
        w.writerow(r)

# ---------------------------------------------------------------- test summary + final facts
stat_counts = {}
for r in M:
    stat_counts[r["status"]] = stat_counts.get(r["status"], 0) + 1
smoke_status = "PASS_8_OF_8" if all(l["status"] == "PASS" for l in smoke_lines) else "REVIEW"
summary = {"utc": utc(), "run_labels": sorted(RUNS),
           "children_exit_zero": True,
           "real_langgraph": {"compile": all(RUNS[r]["compile"]["compile_calls"] == 1 for r in RUNS),
                              "invoke": any(s["record"]["api"] == "invoke" for r in RUNS
                                            for s in RUNS[r]["scenarios"]),
                              "stream_consumed_to_terminal": all(
                                  s["record"]["consumed_to_terminal"] for r in ("base_run1", "base_run2")
                                  for s in RUNS[r]["scenarios"] if not s["record"]["stopped_early"])},
           "smoke_records_status": smoke_status,
           "smoke_detail": {l["smoke_record_id"]: l["status"] for l in smoke_lines},
           "controls_status": cstab,
           "c8_to_t5": c8t5["status"],
           "determinism": det["status"],
           "schema": srep["status"],
           "persistent": pers["status"],
           "test_status_counts": stat_counts,
           "invoke_stream_equivalence": {"run1": b1["invoke_stream_equivalence"]["status"],
                                         "run2": b2["invoke_stream_equivalence"]["status"]},
           "problems_all_children": {r: len(RUNS[r]["problems"]) for r in RUNS},
           "gaps_all_children": {r: [g["kind"] for g in RUNS[r]["gaps"]] for r in RUNS}}
(EV / "STAGE8B_FINAL_FACTS.json").write_text(json.dumps(summary, indent=1, default=str),
                                             encoding="utf-8")
print(json.dumps({"smoke": smoke_status, "c8t5": c8t5["status"], "det": det["status"],
                  "schema": srep["status"], "persistent": pers["status"],
                  "tests": stat_counts}, indent=1))
