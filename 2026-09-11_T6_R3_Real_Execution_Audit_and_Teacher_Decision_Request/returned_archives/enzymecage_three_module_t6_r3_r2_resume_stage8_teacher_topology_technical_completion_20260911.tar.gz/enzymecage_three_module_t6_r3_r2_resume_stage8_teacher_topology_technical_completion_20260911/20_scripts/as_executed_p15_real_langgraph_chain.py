# -*- coding: utf-8 -*-
"""T6-R3-R2 coordinator driver for §8-B (p15_real_langgraph_chain).

Seven responsibilities only, exactly as the resume directive §6 fixes them:

  1. materialize the task-local BASE package from the already-verified v1 archive
     (5 config originals byte-for-byte out of the tar + 5 checkpoint hard links);
  2. verify base config vs overlay config differ only in rxn_fp / mol_conformation /
     reaction_center;
  3. generate the four JSON child configs (base run1/run2, staged run1/run2);
  4. launch each with the pinned ${PY}:  base -> p15b_chain_base.py, staged -> p15c_chain_staged.py;
  5. record argv/start/end/elapsed/exit/stdout/stderr for every child;
  6. never touch the children's scientific logic and never hand-fill a final state;
  7. stop at the first real failure and keep the evidence.

Everything not listed here is out of scope by directive; no framework, no runner abstraction.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import r1_common as C                                                   # noqa: E402

R2_ROOT = Path("/usrdata/EnzymeCAGE_data/workspaces/"
               "enzymecage_three_module_t6_r3_r2_resume_stage8_teacher_topology_"
               "technical_completion_20260911")
RET = C.RETURN_DIR                                                     # original task return dir
RUNS = R2_ROOT / "runs"
CFGS = R2_ROOT / "configs"
BASE_PKG = R2_ROOT / "runtime_assets" / "v1_base"
GATE62 = RET / "FIXED_ASSET_IDENTITY_GATE.json"
OVERLAY_MANIFEST = RET / "V1_OVERLAY_MANIFEST.csv"
SMOKE_CSV = RET / "REAL_SMOKE_INPUTS.csv"
FORWARD_JSONL = RET / "T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl"
PROBE_C = C.LOGS / "probe_c_fallback.json"
CASE_B = C.STAGED_REPO / "cases" / "case_1_realrun.json"
CASE_INVALID = C.STAGED_REPO / "cases" / "case_3.json"
SEEDS = [40, 41, 42, 43, 44]
ALLOWED_CONFIG_FIELDS = {"rxn_fp", "mol_conformation", "reaction_center"}
DRIVER_LOG = {"utc_started": datetime.now(timezone.utc).isoformat(), "steps": [], "children": []}


def log(step, **kw):
    rec = {"step": step, "utc": datetime.now(timezone.utc).isoformat()}
    rec.update(kw)
    DRIVER_LOG["steps"].append(rec)
    print("[%s] %s %s" % (rec["utc"], step,
                          json.dumps({k: v for k, v in kw.items()
                                      if k not in ("detail",)}, default=str)[:400]), flush=True)
    return rec


def die(reason, **kw):
    log("FATAL", reason=reason, **kw)
    (R2_ROOT / "driver").mkdir(exist_ok=True)
    Path(R2_ROOT / "driver" / "p15_driver_log.json").write_text(
        json.dumps(DRIVER_LOG, indent=1, default=str), encoding="utf-8")
    print("BLOCKED_AT_STAGE8_DRIVER: %s" % reason, flush=True)
    sys.exit(2)


def sha_file(p, chunk=1 << 20):
    h = hashlib.sha256()
    with open(str(p), "rb") as fh:
        for blk in iter(lambda: fh.read(chunk), b""):
            h.update(blk)
    return h.hexdigest()


def cfg_yaml_fields(path):
    fields = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if ":" in line and not line.startswith((" ", "#", "-")):
            k, _, v = line.partition(":")
            k, v = k.strip(), v.strip()
            if k:
                fields[k] = v
    return fields


# ------------------------------------------------------------------ 1. base package
def materialize_base_package():
    gate = json.loads(GATE62.read_text(encoding="utf-8"))
    t2d = gate["archives"]["T2D"]
    t3a = gate["archives"]["T3A"]
    v1 = gate["archives"]["V1_ARCHIVE"]
    assets = {}
    for key, entry, frozen in (("T2D", t2d, C.ARCHIVES_SHA["T2D"]),
                               ("T3A", t3a, C.ARCHIVES_SHA["T3A"]),
                               ("V1_ARCHIVE", v1, C.V1_ARCHIVE_SHA)):
        p = Path(entry["tar"])
        st = p.stat()
        assets[key] = {"path": str(p), "bytes": st.st_size, "status": entry["status"],
                       "frozen_sha256": frozen}
        if entry["status"] != "PASS" or st.st_size <= 0:
            die("asset entry not PASS", key=key, entry=entry)
    overlay_rows = {}
    with open(str(OVERLAY_MANIFEST), newline="", encoding="utf-8") as fh:
        for r in csv_rows(OVERLAY_MANIFEST):
            overlay_rows[r["relpath"]] = r
    BASE_PKG.mkdir(parents=True, exist_ok=True)
    manifest_lines = ["relpath,bytes,sha256,source"]
    with tarfile.open(str(v1["tar"]), "r:*") as tf:
        for seed in SEEDS:
            cfg_member = C.V1_CONFIG_MEMBER % seed
            ckpt_member = C.V1_CKPT_MEMBER % seed
            cfg_dest = BASE_PKG / "3b_ensemble" / ("seed_%d" % seed) / "config.yaml"
            ckpt_dest = BASE_PKG / "3b_ensemble" / ("seed_%d" % seed) / "best_model.pth"
            if not cfg_dest.exists():
                data = tf.extractfile(cfg_member).read()
                cfg_dest.parent.mkdir(parents=True, exist_ok=True)
                cfg_dest.write_bytes(data)
            manifest_lines.append("%s,%d,%s,v1_archive_bytes" % (
                cfg_dest.relative_to(BASE_PKG), cfg_dest.stat().st_size,
                sha_file(cfg_dest)))
            src = C.V1_OVERLAY / "3b_ensemble" / ("seed_%d" % seed) / "best_model.pth"
            row = overlay_rows.get("3b_ensemble/seed_%d/best_model.pth" % seed)
            if row is None:
                die("overlay manifest lacks seed row", seed=seed)
            if int(row["bytes"]) != C.CHECKPOINT_BYTES or row["sha256"] != C.CHECKPOINT_SHA[seed]:
                die("overlay manifest row disagrees with frozen §6.2 identity", seed=seed)
            if src.stat().st_size != C.CHECKPOINT_BYTES:
                die("overlay checkpoint size drifted", seed=seed)
            if not ckpt_dest.exists():
                ckpt_dest.parent.mkdir(parents=True, exist_ok=True)
                try:
                    os.link(str(src), str(ckpt_dest))
                except OSError:
                    shutil.copyfile(str(src), str(ckpt_dest))
            manifest_lines.append("%s,%d,%s,hardlink_overlay_ino_%d" % (
                ckpt_dest.relative_to(BASE_PKG), C.CHECKPOINT_BYTES, row["sha256"],
                os.stat(src).st_ino))
    man = BASE_PKG / "MANIFEST.csv"
    man.write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")
    return assets, sha_file(man)


def csv_rows(path):
    import csv
    with open(str(path), newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


# ------------------------------------------------------------------ 2. config-field gate
def config_field_gate():
    diffs = []
    for seed in SEEDS:
        base_f = cfg_yaml_fields(BASE_PKG / "3b_ensemble" / ("seed_%d" % seed) / "config.yaml")
        over_f = cfg_yaml_fields(C.V1_OVERLAY / "3b_ensemble" / ("seed_%d" % seed) / "config.yaml")
        if set(base_f) != set(over_f):
            die("base/overlay config key sets differ", seed=seed)
        changed = {k for k in base_f if base_f[k] != over_f[k]}
        if changed != ALLOWED_CONFIG_FIELDS:
            die("config changed fields are not exactly the three allowed", seed=seed,
                changed=sorted(changed))
        for k in changed:
            if not over_f[k].startswith(str(C.REACTION_OVERLAY)):
                die("overlay field does not point inside the staged bundle", seed=seed, k=k,
                    v=over_f[k])
            if not base_f[k].startswith("/usrdata/EnzymeCAGE_data/feature/"):
                die("base field does not point at the frozen feature root", seed=seed, k=k,
                    v=base_f[k])
        diffs.append({"seed": seed, "changed_fields": sorted(changed),
                      "other_fields_identical": True})
    log("config_field_gate", seeds=len(diffs), allowed=sorted(ALLOWED_CONFIG_FIELDS))
    return diffs


# ------------------------------------------------------------------ 3. child configs
def build_configs(smoke_csv_sha):
    gate = json.loads(GATE62.read_text(encoding="utf-8"))
    env = {
        "M3_AGENT_DATA_ASSETS_ROOT": str(C.RETURN_ROOT / "m3_agent_data_assets/assets"),
        "C8_LOOKUP_ROOT": str(C.RETURN_ROOT / ("enzymecage_m4b_c8_1_lookup_index_delta_review_"
                                               "dependency_payload_rerun2_repack_fix_20260820")),
        "C8_UID_SOURCE_MAP_PATH": str(C.RETURN_ROOT / (
            "enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_rerun1_20260820/"
            "_input_payload/enzymecage_m4b_c8_1_dependency_payload_20260820/inputs/"
            "uid_to_source/uid_to_source_keep_bacteria_fungi_archaea.csv")),
        "DEPENDING_V32_RUNTIME_ROOT": str(C.V32_FROZEN_REPO),
        "D4_WRAPPER_ROOT": str(C.D4_WRAPPER_PARENT),
        "ENZYMECAGE_CODE_ROOT": C.CODE_ROOT,
        "ENZYMECAGE_DRY_RUN": "0",
        "CUDA_VISIBLE_DEVICES": "0",
        "PYTHONHASHSEED": "0",
    }
    smoke_rows = csv_rows(SMOKE_CSV)
    # frozen §7 forward identities, read from the accepted raw jsonl - never retyped
    frozen, staged_reactions = [], []
    for r in (json.loads(l) for l in FORWARD_JSONL.read_text(encoding="utf-8").splitlines()
              if l.strip()):
        lab = r["request_label"]
        base = r["per_request"][lab]["base"]
        frozen.append({"reaction_task_id": r["reaction_task_id"],
                       "reaction_smiles": r["reaction_smiles"],
                       "evidence_hash": base["evidence_hash"],
                       "ranked_uid_order": [x["uid"] for x in base["ranked_enzymes"]],
                       "ranked_scores": [x["score"] for x in base["ranked_enzymes"]]})
        staged_reactions.append({"reaction_task_id": r["reaction_task_id"],
                                 "reaction_smiles": r["reaction_smiles"],
                                 "uid_pair": list(base["original_uids"])})
    overlay_man_sha = sha_file(OVERLAY_MANIFEST)
    common = {
        "pinned_py": C.PY,
        "staged": str(C.STAGED_REPO),
        "env": env,
        "env_pop": ["DASHSCOPE_API_KEY", "OPENAI_API_KEY", "AZURE_OPENAI_API_KEY"],
        "smoke_rows": smoke_rows,
        "smoke_inputs_sha256": smoke_csv_sha,
        "case_b": str(CASE_B),
        "case_invalid": str(CASE_INVALID),
        "t2d_tar": gate["archives"]["T2D"]["tar"],
        "t2d_sha": C.ARCHIVES_SHA["T2D"],
        "t3a_tar": gate["archives"]["T3A"]["tar"],
        "t3a_sha": C.ARCHIVES_SHA["T3A"],
        "uid_map_sha256": C.UID_MAP_SHA,
        "c8_lookup_sha256": C.C8_LOOKUP_SHA,
    }
    out = {}
    for label, script in (("base_run1", "p15b_chain_base.py"), ("base_run2", "p15b_chain_base.py"),
                          ("staged_run1", "p15c_chain_staged.py"),
                          ("staged_run2", "p15c_chain_staged.py")):
        cfg = dict(common)
        cfg.update({"run_label": label, "script": script,
                    "out_json": str(RUNS / label / "out.json"),
                    "out_norm": str(RUNS / label / "norm.jsonl"),
                    "out_scores": str(RUNS / label / "floats.csv")})
        if script == "p15b_chain_base.py":
            cfg.update({"v1_base_root": str(BASE_PKG),
                        "v1_base_manifest_sha256": BASE_PKG_SHA,
                        "c_fallback_probe": str(PROBE_C)})
        else:
            cfg.update({"v1_overlay_root": str(C.V1_OVERLAY),
                        "overlay_manifest_path": str(OVERLAY_MANIFEST),
                        "overlay_manifest_sha256": overlay_man_sha,
                        "staged_reactions": staged_reactions,
                        "frozen_forwards": frozen,
                        "src_scan_roots": [str(C.STAGED_REPO / "src"),
                                           str(C.STAGED_REPO / "config"),
                                           str(C.STAGED_REPO / "cases")],
                        "repeat_tolerance": C.REPEAT_TOLERANCE})
        CFGS.mkdir(parents=True, exist_ok=True)
        p = CFGS / (label + ".json")
        p.write_text(json.dumps(cfg, indent=1), encoding="utf-8")
        out[label] = {"cfg": str(p), "script": str(HERE / script)}
    log("configs_written", labels=sorted(out), smoke_rows=len(smoke_rows))
    return out


# ------------------------------------------------------------------ 4/5. children
def run_children(configs):
    import csv
    (R2_ROOT / "driver").mkdir(exist_ok=True)
    audit_rows = []
    base_norm_files = []
    for label in ("base_run1", "base_run2", "staged_run1", "staged_run2"):
        entry = configs[label]
        RUNS.mkdir(exist_ok=True)
        workdir = RUNS / label
        workdir.mkdir(exist_ok=True)
        env = dict(os.environ)
        env.update({"PYTHONDONTWRITEBYTECODE": "1", "TMPDIR": str(C.TMPS),
                    "XDG_CACHE_HOME": str(C.CACHE), "MPLCONFIGDIR": str(C.CACHE / "mpl"),
                    "NUMBA_CACHE_DIR": str(C.CACHE / "numba"),
                    "TORCH_HOME": str(C.CACHE / "torch"),
                    "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                    "LC_ALL": "C", "TZ": "UTC",
                    # T6-R3-R2: pool order is set-iteration dependent inside production
                    # build_enzyme_pool; the hash seed only applies at process start, so it
                    # must be in the SPAWN environment (attempt-6 norm diff: same pool sets,
                    # different order).  Determinism control, no scientific change.
                    "PYTHONHASHSEED": "0"})
        for k in ("PYTHONPATH", "PYTHONHOME"):
            env.pop(k, None)
        argv = [C.PY, entry["script"], entry["cfg"]]
        out_path, err_path = workdir / "stdout.log", workdir / "stderr.log"
        t0 = time.monotonic()
        started = datetime.now(timezone.utc).isoformat()
        with open(str(out_path), "wb") as fo, open(str(err_path), "wb") as fe:
            p = subprocess.run(argv, cwd=str(HERE), env=env, stdout=fo, stderr=fe,
                               timeout=3600)
        dur = round(time.monotonic() - t0, 3)
        ended = datetime.now(timezone.utc).isoformat()
        rec = {"label": label, "argv": argv, "start_utc": started, "end_utc": ended,
               "elapsed_s": dur, "exit": p.returncode,
               "stdout": str(out_path), "stdout_sha256": sha_file(out_path),
               "stderr": str(err_path), "stderr_sha256": sha_file(err_path)}
        DRIVER_LOG["children"].append(rec)
        audit_rows.append({"command_id": "p15_" + label, "phase": "stage8B_chain",
                           "argv0": argv[0], "start_utc": started, "end_utc": ended,
                           "elapsed_s": dur, "exit": p.returncode,
                           "category": "CPU_GPU_REAL_GRAPH",
                           "stdout_sha256": rec["stdout_sha256"],
                           "stderr_sha256": rec["stderr_sha256"]})
        log("child_done", label=label, exit=p.returncode, elapsed_s=dur)
        (R2_ROOT / "driver" / "p15_command_audit.json").write_text(
            json.dumps(audit_rows, indent=1), encoding="utf-8")
        (R2_ROOT / "driver" / "p15_driver_log.json").write_text(
            json.dumps(DRIVER_LOG, indent=1, default=str), encoding="utf-8")
        if p.returncode != 0:
            die("child exited nonzero", label=label, exit=p.returncode,
                stdout=str(out_path), stderr=str(err_path))
        if label.startswith("base"):
            base_norm_files.append(workdir / "norm.jsonl")
    # determinism: identical frozen inputs across the two fresh processes must give byte-
    # identical normalised scientific lines (floats were scrubbed out of those lines)
    det = {}
    for track, files in (("base", base_norm_files),
                         ("staged", [(RUNS / "staged_run1" / "norm.jsonl"),
                                     (RUNS / "staged_run2" / "norm.jsonl")])):
        a = Path(files[0]).read_bytes()
        b = Path(files[1]).read_bytes()
        det[track] = {"equal_bytes": a == b, "sha_run1": hashlib.sha256(a).hexdigest(),
                      "sha_run2": hashlib.sha256(b).hexdigest()}
    (R2_ROOT / "driver" / "p15_norm_determinism.json").write_text(
        json.dumps(det, indent=1), encoding="utf-8")
    log("norm_compare", **{k: v["equal_bytes"] for k, v in det.items()})


if __name__ == "__main__":
    smoke_csv_sha = sha_file(SMOKE_CSV)
    if smoke_csv_sha != "97e5d6d6701ac23890ae8ee4c71c9039280c4f447fe63510bb7fec76b13f8595":
        die("REAL_SMOKE_INPUTS.csv is no longer the frozen §8-A file", observed=smoke_csv_sha)
    BASE_ASSETS, BASE_PKG_SHA = materialize_base_package()
    config_field_gate()
    configs = build_configs(smoke_csv_sha)
    run_children(configs)
    (R2_ROOT / "driver" / "p15_driver_log.json").write_text(
        json.dumps(DRIVER_LOG, indent=1, default=str), encoding="utf-8")
    print("DRIVER COMPLETE", flush=True)
