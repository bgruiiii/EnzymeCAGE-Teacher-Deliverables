# -*- coding: utf-8 -*-
"""T6-R3-R1 p15 shared harness for the real full-chain children (§8-B).

Everything in this module is *observation*: an audit hook, a real-LangGraph runner that
consumes the teacher's compiled graph to its terminal state, and a normaliser that turns a
run into (a) a byte-comparable scientific record and (b) a side list of the floating-point
measurements that §7 already proved are not bit-reproducible on GPU.

No teacher file is imported with a patched symbol, no StateGraph is built here, and no state
key is ever written by this harness - the graph produces its own output and we read it back
through ``compiled.get_state``.
"""
import hashlib
import json
import logging
import os
import re
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

FLOAT_TAG = "FLOAT_REMOVED_FROM_BYTE_COMPARISON"
FLOAT_IN_TEXT = re.compile(r"\d+\.\d+(?:[eE][-+]?\d+)?")
INTERESTING_OPEN = re.compile(
    r"(m3_agent_data_assets|/usrdata/EnzymeCAGE_data/feature|C8_METATRAITS|uid_to_source_keep|"
    r"depending_teacher_fixed_r1|runtime_assets|formal_splits|cases/|enzymecage_wrapper|"
    r"v1_base_package|v1_overlay|HPC_Inputs|HPC_Returned_Result_Summaries|reaction_overlay)", re.I)
NET_EVENTS = {"socket.connect", "socket.getaddrinfo", "create_connection",
              "urllib.Request", "http.client.connect"}


def utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------- audit hook
class Audit(object):
    """Every interesting path opened and every network touch, recorded not guessed."""

    def __init__(self):
        self.opened = {}          # path -> {"count": n, "modes": set, "first_t": t}
        self.net = []
        self.open_errors = {}
        self.installed = False

    def hook(self, event, args):
        try:
            if event == "open":
                p = args[0]
                if not isinstance(p, (str, bytes, os.PathLike)):
                    return
                sp = os.fspath(p)
                if isinstance(sp, bytes):
                    sp = sp.decode("utf-8", "replace")
                mode = args[1] if len(args) > 1 else ""
                if not isinstance(mode, (str, int)):
                    mode = ""
                if INTERESTING_OPEN.search(sp):
                    rec = self.opened.setdefault(sp, {"count": 0, "modes": [], "first_t": None})
                    rec["count"] += 1
                    m = str(mode)
                    if m and m not in rec["modes"]:
                        rec["modes"].append(m)
                    if rec["first_t"] is None:
                        rec["first_t"] = round(time.monotonic() - T0, 3)
            elif event in NET_EVENTS:
                self.net.append({"event": event, "args": repr(args)[:240],
                                 "t": round(time.monotonic() - T0, 3)})
            elif event == "os.mkdir" or event == "os.rename" or event == "os.remove":
                self.net.append({"event": "FS_WRITE_EVENT:" + event,
                                 "args": repr(args)[:240]})
        except Exception:
            pass

    def dump(self):
        hosts = set()
        for r in self.net:
            for m in re.findall(r"https?://([^/:\s'\"]+)", str(r.get("args", ""))):
                hosts.add(m)
            for m in re.findall(r"host=([^,\)\s']+)", str(r.get("args", ""))):
                hosts.add(m)
        return {
            "opened_paths": sorted(
                ({"path": k, "count": v["count"], "modes": v["modes"], "first_t": v["first_t"]}
                 for k, v in self.opened.items()),
                key=lambda r: r["path"]),
            "opened_path_count": len(self.opened),
            "write_events": [r for r in self.net if r["event"].startswith("FS_WRITE_EVENT")],
            "network_events": [r for r in self.net if not r["event"].startswith("FS_WRITE_EVENT")],
            "network_event_count": sum(1 for r in self.net
                                       if not r["event"].startswith("FS_WRITE_EVENT")),
            "distinct_network_hosts": sorted(hosts),
        }


T0 = time.monotonic()


def install_audit():
    a = Audit()
    try:
        sys.addaudithook(a.hook)
        a.installed = True
    except Exception as exc:
        a.installed = False
        a.opened["<audit-hook-failure>"] = {"count": 1, "modes": [repr(exc)], "first_t": 0.0}
    return a


# --------------------------------------------------------------------- float scrubbing
def scrub(obj, floats, path="$"):
    """Copy *obj* with every float replaced by a marker; the value goes to *floats*.

    §7 measured base/repeat score deltas up to 4.3e-07 on the same GPU, so raw scores may
    not live inside a file that is required to be byte-identical across the two runs.  The
    ordering keys (rank, pool position, count) are integers and stay.
    """
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            kp = "%s.%s" % (path, k)
            if isinstance(v, bool):
                out[k] = v
            elif isinstance(v, float):
                floats.append([kp, repr(v)])
                out[k] = FLOAT_TAG
            else:
                out[k] = scrub(v, floats, kp)
        return out
    if isinstance(obj, (list, tuple)):
        return [scrub(v, floats, "%s[%d]" % (path, i)) for i, v in enumerate(obj)]
    if isinstance(obj, float):
        floats.append([path, repr(obj)])
        return FLOAT_TAG
    return obj


def mask_floats_in_text(value):
    """Keep an error/provenance string comparable across two runs.

    A message that embeds a measured score or a wall time is masked to ``<FLOAT>`` in the
    byte-comparable record only; the raw string stays in the per-run JSON.
    """
    if not isinstance(value, str):
        return value
    return FLOAT_IN_TEXT.sub("<FLOAT>", value)


def canon(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))


def sha_obj(obj):
    return hashlib.sha256(canon(obj).encode("utf-8")).hexdigest()


def sha_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        for blk in iter(lambda: fh.read(chunk), b""):
            h.update(blk)
    return h.hexdigest()


# --------------------------------------------------------------------- state readers
def _g(obj, key, default=None):
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def ev_view(chain):
    out = []
    for e in chain or []:
        out.append({"stage": _g(e, "stage"), "action": _g(e, "action"), "data": _g(e, "data")})
    return out


def candidate_view(c):
    return {
        "reaction_smiles": _g(c, "reaction_smiles"),
        "reaction_sha256": _g(c, "reaction_sha256"),
        "source": _g(c, "source"), "source_tag": _g(c, "source_tag"),
        "source_tool": _g(c, "source_tool"), "rhea_id": _g(c, "rhea_id"),
        "ec_numbers": _g(c, "ec_numbers"), "similarity_score": _g(c, "similarity_score"),
        "prediction_rank": _g(c, "prediction_rank"),
    }


def ranked_view(rlist):
    return [{"uid": _g(r, "uid"), "score": _g(r, "score"), "rank": _g(r, "rank"),
             "ensemble_ci": _g(r, "ensemble_ci")} for r in rlist or []]


def organism_view(cands, with_provenance=True):
    out = []
    for c in cands or []:
        row = {"organism_uid": _g(c, "organism_uid"), "ncbi_taxon_id": _g(c, "ncbi_taxon_id"),
               "organism_name": _g(c, "organism_name"),
               "supporting_enzyme_count": _g(c, "supporting_enzyme_count"),
               "default_order_rank": _g(c, "default_order_rank"),
               "host_identity_source_signature": _g(c, "host_identity_source_signature"),
               "supporting_enzymes": ranked_view(_g(c, "supporting_enzymes")),
               "aggregation_notes": _g(c, "aggregation_notes")}
        if with_provenance:
            prov = []
            for p in _g(c, "per_enzyme_source_provenance") or []:
                up = _g(p, "uniprot_reviewed")
                kg = _g(p, "kegg")
                prov.append({
                    "enzyme_uid": _g(p, "enzyme_uid"),
                    "resolution_route": _g(p, "resolution_route"),
                    "host_identity_source": _g(p, "host_identity_source"),
                    "host_taxid": _g(p, "host_taxid"), "host_name": _g(p, "host_name"),
                    "host_resolution": _g(p, "host_resolution"),
                    "host_identity_source_signature": _g(p, "host_identity_source_signature"),
                    "uniprot_reviewed_present": up is not None,
                    "uniprot_entry_type": _g(up, "entry_type"),
                    "uniprot_response_sha256": _g(up, "response_sha256"),
                    "uniprot_source_url": _g(up, "source_url"),
                    "kegg_present": kg is not None,
                    "kegg_multiplicity": _g(kg, "multiplicity"),
                })
            row["per_enzyme_source_provenance"] = prov
        out.append(row)
    return out


def bridge_view(br):
    if br is None:
        return None
    return {"route_id": _g(br, "route_id"),
            "steps": [{"reaction_task_id": _g(s, "reaction_task_id"),
                       "route_id": _g(s, "route_id"),
                       "source_node_id": _g(s, "source_node_id"),
                       "target_node_id": _g(s, "target_node_id"),
                       "predicted_ec": _g(s, "predicted_ec"),
                       "depth": _g(s, "depth"), "branch_id": _g(s, "branch_id"),
                       "substrate_smiles": _g(s, "substrate_smiles"),
                       "product_smiles": _g(s, "product_smiles"),
                       "reaction_smiles": _g(s, "reaction_smiles"),
                       "reaction_source": _g(s, "reaction_source"),
                       "source_tool": _g(s, "source_tool"),
                       "reaction_asset_status": _g(s, "reaction_asset_status"),
                       "enzyme_match_status": _g(s, "enzyme_match_status"),
                       "matched_enzyme_uids": _g(s, "matched_enzyme_uids")}
                      for s in (_g(br, "steps") or [])],
            "organism_step_coverages": [
                {"organism_uid": _g(o, "organism_uid"), "organism_name": _g(o, "organism_name"),
                 "reaction_task_ids": _g(o, "reaction_task_ids"),
                 "covered_step_count": _g(o, "covered_step_count"),
                 "covered_depths": _g(o, "covered_depths")}
                for o in (_g(br, "organism_step_coverages") or [])]}


def state_view(vals):
    """Every scientific field the chain produced, in one dict."""
    cands = _g(vals, "candidate_reactions") or []
    pool = _g(vals, "enzyme_pool_final") or []
    chain = _g(vals, "evidence_chain") or []
    sub = _g(vals, "substrate_info")
    return {
        "substrate_smiles": _g(sub, "substrate_smiles"),
        "substrate_source": _g(sub, "source"),
        "substrate_provenance": _g(sub, "provenance"),
        "candidate_reaction_count": len(cands),
        "candidate_reactions_head": [candidate_view(c) for c in cands[:3]],
        "candidate_sources_distinct": sorted({str(_g(c, "source")) for c in cands}),
        "candidate_source_tags_distinct": sorted({str(_g(c, "source_tag")) for c in cands}),
        "reaction_task_id": _g(vals, "reaction_task_id"),
        "pool_route_used": _g(vals, "pool_route_used"),
        "pool_size": _g(vals, "pool_size"),
        "enzyme_pool_b_size": len(_g(vals, "enzyme_pool_b") or []),
        "enzyme_pool_c_size": len(_g(vals, "enzyme_pool_c") or []),
        "enzyme_pool_final_ordered": list(pool),
        "ranked_enzymes": ranked_view(_g(vals, "ranked_enzymes")),
        "reranked_enzymes": [_g(r, "uid") for r in (_g(vals, "reranked_enzymes") or [])],
        "microbe_candidates": [_g(m, "organism_name") for m in (_g(vals, "microbe_candidates") or [])],
        "organism_candidates": organism_view(_g(vals, "organism_candidates")),
        "organism_recommendations": [
            {"organism_uid": _g(o, "organism_uid"),
             "recommendation_status": _g(o, "recommendation_status"),
             "cited_evidence_count": len(_g(o, "cited_evidence") or [])}
            for o in (_g(vals, "organism_recommendations") or [])],
        "trait_record_count": len(_g(vals, "trait_records") or []),
        "trait_filter_passed": _g(vals, "trait_filter_passed"),
        "predicted_reactions": [_g(p, "predicted_reaction_smiles")
                                for p in (_g(vals, "predicted_reactions") or [])],
        "multistep_route": None if _g(vals, "multistep_route") is None else {
            "route_id": _g(_g(vals, "multistep_route"), "route_id"),
            "reactant_smiles": _g(_g(vals, "multistep_route"), "reactant_smiles"),
            "source_tool": _g(_g(vals, "multistep_route"), "source_tool"),
            "reaction_source": _g(_g(vals, "multistep_route"), "reaction_source"),
            "branch_id": _g(_g(vals, "multistep_route"), "branch_id")},
        "bridge_result": bridge_view(_g(vals, "bridge_result")),
        "state_error": _g(vals, "error"),
        "state_fail_closed": _g(vals, "fail_closed"),
        "uncertainty_flags": _g(vals, "uncertainty_flags") or [],
        "evidence_chain_stages": [_g(e, "stage") for e in chain],
        "evidence_chain": ev_view(chain),
        # hashed after float scrubbing, otherwise §7's 4.3e-07 GPU jitter breaks the hash
        "evidence_chain_sha256": sha_obj(scrub(ev_view(chain), [])),
    }


# --------------------------------------------------------------------- the graph runner
def run_graph(compiled, scenario, initial, thread_id, stop_node=None):
    """One real execution of the teacher's compiled graph, consumed to its terminal state.

    ``stream_mode=["updates","values"]`` is the official observation channel: every node
    event and every resulting state snapshot is recorded as it is emitted.
    """
    cfg = {"configurable": {"thread_id": thread_id}}
    order, updates, transitions = [], [], []
    floats = []
    tb, raised = None, None
    vals = {}
    t0 = time.monotonic()
    started = utc()
    stopped_early = False
    try:
        for chunk in compiled.stream(initial, cfg, stream_mode=["updates", "values"]):
            kind, body = chunk
            if kind == "updates":
                for nm, upd in (body or {}).items():
                    order.append(nm)
                    keys = sorted(upd.keys()) if isinstance(upd, dict) else []
                    updates.append({"node": nm, "changed_state_keys": keys,
                                    "update": scrub(upd if isinstance(upd, dict) else {}, floats,
                                                    "$." + nm)})
            else:
                transitions.append({
                    "after_node": order[-1] if order else "__input__",
                    "present_state_keys": sorted((body or {}).keys()),
                    "scientific_view_sha256": sha_obj(scrub(state_view(body), []))})
            if stop_node and order and order[-1] == stop_node:
                stopped_early = True
                break
        vals = _g(compiled.get_state(cfg), "values", {}) or {}
    except Exception:
        tb = traceback.format_exc()
        raised = tb.strip().splitlines()[-1][:300]
    ended = utc()
    view = state_view(vals) if vals else state_view({})
    rec = {"scenario": scenario, "thread_id": thread_id,
           "started_utc": started, "ended_utc": ended,
           "wall_s": round(time.monotonic() - t0, 3),
           "node_execution_order": order, "node_count_executed": len(order),
           "stopped_early": stopped_early,
           "consumed_to_terminal": (not stopped_early) and raised is None,
           "raised": raised, "traceback": tb,
           "reached_end": (not stopped_early) and raised is None}
    rec.update(view)
    return rec, updates, transitions, floats


# --------------------------------------------------------------------- wrapper counters
def wrapper_state():
    """Read-only look at the frozen wrapper's own singleton (None before first use)."""
    mod = sys.modules.get("enzymecage_wrapper.predictor")
    if mod is None:
        return {"wrapper_imported": False, "runtime_initialized": False,
                "forward_call_count": 0, "package_root": None}
    rt = mod._runtime_for_audit() if hasattr(mod, "_runtime_for_audit") else None
    trace = getattr(rt, "last_trace", None) if rt else None
    return {"wrapper_imported": True, "runtime_initialized": rt is not None,
            "forward_call_count": (getattr(rt, "forward_call_count", None) if rt else 0),
            "package_root": (str(rt.package_root) if rt else None),
            "last_trace": (dict(trace) if isinstance(trace, dict) else trace)}


class LogCapture(logging.Handler):
    """Real log lines emitted by the teacher's own modules during a call."""

    def __init__(self, level=logging.DEBUG):
        logging.Handler.__init__(self, level)
        self.lines = []

    def emit(self, record):
        try:
            self.lines.append({"levelname": record.levelname, "logger": record.name,
                               "msg": record.getMessage()[:600],
                               "t": round(time.monotonic() - T0, 3)})
        except Exception:
            pass

    def text(self):
        return "\n".join("%-8s %-46s %s" % (r["levelname"], r["logger"], r["msg"])
                         for r in self.lines)


def attach_capture(logger_names):
    handlers = []
    for nm in logger_names:
        lg = logging.getLogger(nm)
        h = LogCapture()
        lg.addHandler(h)
        lg.setLevel(logging.DEBUG)
        lg.propagate = True
        handlers.append((lg, h))
    return handlers


def detach_capture(handlers):
    for lg, h in handlers:
        try:
            lg.removeHandler(h)
        except Exception:
            pass


def norm_line(scenario, thread_id, rec, extras=None):
    """The byte-comparable scientific line for one scenario (no time, no float)."""
    floats = []
    body = {
        "scenario": scenario,
        "node_execution_order": rec["node_execution_order"],
        "reached_end": rec["reached_end"],
        "raised_class": (rec["raised"].split(":")[0] if rec["raised"] else None),
        "substrate_smiles": rec["substrate_smiles"],
        "substrate_source": rec["substrate_source"],
        "candidate_reaction_count": rec["candidate_reaction_count"],
        "candidate_reactions_head": scrub(rec["candidate_reactions_head"], floats),
        "candidate_sources_distinct": rec["candidate_sources_distinct"],
        "candidate_source_tags_distinct": rec["candidate_source_tags_distinct"],
        "reaction_task_id": rec["reaction_task_id"],
        "pool_route_used": rec["pool_route_used"],
        "pool_size": rec["pool_size"],
        "enzyme_pool_final_ordered": rec["enzyme_pool_final_ordered"],
        "ranked_uid_order": [r["uid"] for r in rec["ranked_enzymes"]],
        "ranked_rank_order": [r["rank"] for r in rec["ranked_enzymes"]],
        "organism_candidates": scrub(rec["organism_candidates"], floats),
        "organism_recommendations": rec["organism_recommendations"],
        "trait_record_count": rec["trait_record_count"],
        "trait_filter_passed": rec["trait_filter_passed"],
        "bridge_result": rec["bridge_result"],
        "state_error": mask_floats_in_text(rec["state_error"]),
        "state_fail_closed": rec["state_fail_closed"],
        "uncertainty_flags": sorted(rec["uncertainty_flags"]),
        "evidence_chain_stages": rec["evidence_chain_stages"],
        "evidence_chain_sha256": rec["evidence_chain_sha256"],
    }
    if extras:
        body.update(scrub(extras, floats))
    return canon(body), floats
