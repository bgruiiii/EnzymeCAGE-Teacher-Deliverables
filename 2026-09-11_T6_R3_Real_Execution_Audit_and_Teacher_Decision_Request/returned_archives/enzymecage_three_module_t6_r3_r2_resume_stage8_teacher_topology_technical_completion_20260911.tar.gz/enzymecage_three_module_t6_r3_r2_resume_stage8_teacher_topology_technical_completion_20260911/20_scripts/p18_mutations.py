# -*- coding: utf-8 -*-
"""T6-R3-R2 p18: prove the p17 gates reject the §11 mutation list.

Each mutation gets its own isolated copy of the *small* evidence tree (hardlinks for
everything unmutated, real copies only for the mutated file); the same validator code is run
over the copy; every mutation must produce a nonzero exit AND hit its expected gate.
Nothing here re-runs a model, graph or GPU - mutations act on immutable raw evidence copies.
"""
import json
import os
import shutil
import sys
from pathlib import Path

R2 = Path("/usrdata/EnzymeCAGE_data/workspaces/"
          "enzymecage_three_module_t6_r3_r2_resume_stage8_teacher_topology_technical_completion_20260911")
sys.path.insert(0, str(R2 / "scripts_finalize"))
import p17_validator as V                                        # noqa: E402

SUBTREES = ["runs", "evidence", "driver", "raw_copies"]


def fresh_copy(dst):
    if dst.exists():
        shutil.rmtree(str(dst))
    dst.mkdir(parents=True)
    for sub in SUBTREES:
        shutil.copytree(str(R2 / sub), str(dst / sub), copy_function=os.link)
    ck = R2 / "checkpoint" / ("enzymecage_three_module_t6_r3_r1_operator_checkpoint_stage8_20260911")
    (dst / "checkpoint").mkdir(exist_ok=True)
    shutil.copytree(str(ck), str(dst / "checkpoint" / ck.name), copy_function=os.link)
    return dst


def replace_file(dst, rel, new_content):
    """unlink the hardlink and write real new bytes (isolated copy only)"""
    p = dst / rel
    if p.is_symlink() or p.exists():
        os.unlink(str(p))
    p.write_text(new_content, encoding="utf-8")


def edit_json(dst, rel, fn):
    p = dst / rel
    d = json.loads(p.read_text(encoding="utf-8"))
    os.unlink(str(p))
    (R2 / rel if False else p)  # noqa
    d = fn(d)
    p.write_text(json.dumps(d), encoding="utf-8")
    return p


MUTS = []


def mut(mid, gate_expected, setup):
    MUTS.append((mid, gate_expected, setup))


def _load(dst, rel):
    return json.loads((dst / rel).read_text(encoding="utf-8"))


# M01: sys.executable of a child switched to /usr/bin/python
def m01(dst):
    def fn(d):
        d["interp"]["sys_executable"] = "/usr/bin/python"
        d["interp"]["is_pinned"] = True   # claim remains; validator recomputes against PY
        return d
    edit_json(dst, "runs/base_run1/out.json", fn)
mut("M01_executable_to_system_python", "pinned_interpreter_children", m01)

# M02: ase import failure in the accepted matrix
def m02(dst):
    p = dst / "raw_copies/PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv"
    t = p.read_text().replace("ase,EnzymeCAGE geometry (root cause of the blocked first round),true",
                              "ase,EnzymeCAGE geometry (root cause of the blocked first round),false")
    replace_file(dst, "raw_copies/PYTHON_PACKAGE_AND_IMPORT_MATRIX.csv", t)
mut("M02_ase_import_fail", "ase_import", m02)

# M03: one worker launched with bare python
def m03(dst):
    p = dst / "raw_copies/GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv"
    t = p.read_text().replace("/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python,python",
                              "python,python", 1)
    t = t.replace(",/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python,/usr/bin/python3.12,",
                  ",/usr/bin/python,/usr/bin/python3.12,", 1)
    replace_file(dst, "raw_copies/GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv", t)
mut("M03_worker_bare_python", "worker_argv_pinned", m03)

# M04: one worker GPU uuid wrong
def m04(dst):
    p = dst / "raw_copies/GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv"
    t = p.read_text().replace("GPU-74f9ec77-8678-5c1d-2051-586647300e90,",
                              "GPU-ffffffff-8678-5c1d-2051-586647300e90,", 1)
    replace_file(dst, "raw_copies/GPU_WORKER_ASSIGNMENT_AND_ISOLATION.csv", t)
mut("M04_worker_gpu_uuid_wrong", "worker_gpu_uuid", m04)

# M05: one UID's ESM feature all-zero
def m05(dst):
    p = dst / "raw_copies/NATIVE_LOAD_PER_ROW_TENSORS.csv"
    t = p.read_text().replace(",True,127.19587707519531,2560,False", ",True,0.0,0,True", 1)
    replace_file(dst, "raw_copies/NATIVE_LOAD_PER_ROW_TENSORS.csv", t)
mut("M05_esm_all_zero", "esm_nonzero_per_row", m05)

# M06: one forward_executed=false
def m06(dst):
    def fn(lines):
        out = []
        for i, l in enumerate(lines):
            if i == 0:
                l = l.replace('"forward_executed": true', '"forward_executed": false', 1)
                l = l.replace('"forward_executed":true', '"forward_executed":false', 1)
            out.append(l)
        return out
    p = dst / "raw_copies/T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl"
    t = "\n".join(fn(p.read_text().splitlines())) + "\n"
    replace_file(dst, "raw_copies/T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl", t)
mut("M06_forward_executed_false", "unique_forward_pairs_6", m06)

# M07: one unique reaction x UID pair missing
def m07(dst):
    p = dst / "raw_copies/T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl"
    lines = [l for l in p.read_text().splitlines() if l.strip()]
    out = []
    for i, l in enumerate(lines):
        r = json.loads(l)
        if i == 0:
            lab = r["request_label"]
            b = r["per_request"][lab]["base"]
            b["original_uids"] = b["original_uids"][:1]      # drop the second UID of RT-1a7b
            l = json.dumps(r)
        out.append(l)
    replace_file(dst, "raw_copies/T3B_NATIVE_LOAD_AND_FORWARD_RESULTS.jsonl",
                 "\n".join(out) + "\n")
mut("M07_missing_unique_pair", "unique_forward_pairs_6", m07)

# M08: a PASS_COMPONENT_ONLY row counted as a real PASS
def m08(dst):
    p = dst / "evidence/TEST_CASE_MATRIX.csv"
    t = p.read_text()
    assert 'TEST-19' in t
    t = t.replace("REAL_LANGGRAPH_STREAM_TRACE.jsonl; MUTATION_CHECK.json,PASS",
                  "REAL_LANGGRAPH_STREAM_TRACE.jsonl; MUTATION_CHECK.json,PASS_COMPONENT_ONLY", 1)
    replace_file(dst, "evidence/TEST_CASE_MATRIX.csv", t)
mut("M08_component_only_counted", "test_matrix_no_component_only_pass", m08)

# M09: manifest missing itself (closure-state flag flipped in an isolated copy)
def m09(dst):
    (dst / "closure_state.json").write_text(json.dumps({
        "validation_absent_pre_write": True, "manifest_files_equals_n": False,
        "manifest_sha256_equals_n_minus_1": True, "single_root": True, "unsafe_members": 0,
        "mutated": "manifest_files_missing_self"}))
mut("M09_manifest_missing_self", "closure_order", m09)

# M10: validation pre-created
def m10(dst):
    (dst / "closure_state.json").write_text(json.dumps({
        "validation_absent_pre_write": False, "manifest_files_equals_n": True,
        "manifest_sha256_equals_n_minus_1": True, "single_root": True, "unsafe_members": 0,
        "mutated": "validation_precreated"}))
mut("M10_validation_precreated", "closure_order", m10)

# M11: staged smoke evidence hash differs from the §7 frozen one
def m11(dst):
    def fn(d):
        d["forwards"][0]["vs_section7"]["evidence_hash_matches_frozen"] = False
        return d
    edit_json(dst, "runs/staged_run1/out.json", fn)
mut("M11_staged_hash_vs_frozen_break", "staged_hash_vs_section7_frozen", m11)

# M12: node order differs between the two fresh base processes
def m12(dst):
    p = dst / "runs/base_run2/norm.jsonl"
    lines = p.read_text().splitlines()
    l0 = json.loads(lines[0])
    l0["node_execution_order"] = list(reversed(l0["node_execution_order"]))
    lines[0] = json.dumps(l0, sort_keys=True, separators=(",", ":"))
    replace_file(dst, "runs/base_run2/norm.jsonl", "\n".join(lines) + "\n")
mut("M12_run_order_differs", "determinism_two_runs", m12)

# M13: stream not consumed to terminal
def m13(dst):
    def fn(d):
        for s in d["scenarios"]:
            if s["record"].get("api") == "stream":
                s["record"]["consumed_to_terminal"] = False
        return d
    edit_json(dst, "runs/base_run1/out.json", fn)
mut("M13_stream_not_terminal", "real_stream_to_terminal", m13)


def main():
    results = []
    base_ok = V.validate(R2)
    base_gates = {k: v["pass"] for k, v in V.GATES.items()}
    results.append({"mutation_id": "__BASELINE_REAL_EVIDENCE__",
                    "exit_expected": 0, "gate_expected": None,
                    "exit": 0 if base_ok else 1, "hit_gates": [k for k, g in base_gates.items()
                                                               if not g], "correct": base_ok})
    for mid, expected_gate, setup in MUTS:
        dst = fresh_copy(R2 / "mutations" / mid)
        setup(dst)
        ok = V.validate(dst)
        failed = [k for k, v in V.GATES.items() if not v["pass"]]
        correct = (not ok) and expected_gate in failed
        results.append({"mutation_id": mid, "exit_expected": 1, "gate_expected": expected_gate,
                        "exit": 0 if ok else 1, "hit_gates": failed, "correct": correct})
        print("%s %s -> %s (failed gates: %s)" % ("PASS " if correct else "WRONG", mid,
                                                  "rejected" if not ok else "ACCEPTED(!)",
                                                  ",".join(failed[:4]) or "-"), flush=True)
    allr = all(r["correct"] for r in results)
    out = {"utc": V.__dict__.get("sha_file") and __import__("datetime").datetime.now(
        __import__("datetime").timezone.utc).isoformat(),
        "baseline_all_pass": base_ok, "baseline_gate_values": base_gates,
        "total": len(MUTS), "all_mutations_rejected": allr, "results": results}
    (R2 / "evidence" / "MUTATION_CHECK.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
    print("MUTATION_CHECK all_rejected=%s baseline=%s" % (allr, base_ok))
    raise SystemExit(0 if (allr and base_ok) else 1)


if __name__ == "__main__":
    main()
