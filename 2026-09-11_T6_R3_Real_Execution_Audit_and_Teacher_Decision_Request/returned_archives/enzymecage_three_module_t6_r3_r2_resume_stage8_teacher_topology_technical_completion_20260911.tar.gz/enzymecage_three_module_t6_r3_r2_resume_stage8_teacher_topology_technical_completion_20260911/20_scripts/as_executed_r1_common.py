# -*- coding: utf-8 -*-
"""T6-R3-R1 shared infrastructure: pinned interpreter, command audit, safe unpack, identities.

Every Python command of this task is launched through run_py() with the absolute ${PY}
interpreter, and every launch is recorded in logs/python_command_audit.jsonl so that
§12's PYTHON_COMMAND_AUDIT.csv can be generated from real argv rather than asserted.
"""
import ctypes
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

# ---------------------------------------------------------------- pinned paths
TASK_ID = ("enzymecage_three_module_t6_r3_r1_pinned_python_forward_real_langgraph_"
           "20_test_final_20260910")
PY = "/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python"
ROOT = Path("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master")
CODE_ROOT = "/root/projects/EnzymeCAGE-master"          # §4.2 allowed sys.path entry
WORK_ROOT = Path("/usrdata/EnzymeCAGE_data/workspaces") / TASK_ID
STAGED_REPO = WORK_ROOT / "depending_teacher_fixed_r1"
INPUT_ROOT = WORK_ROOT / "inputs"
RUNTIME_ASSETS = WORK_ROOT / "runtime_assets"
LOGS = WORK_ROOT / "logs"
TMPS = WORK_ROOT / "tmp"
CACHE = WORK_ROOT / "cache"
SCRIPTS_SRC = ROOT / "t6r3r1_tmp"
RETURN_ROOT = ROOT / "HPC_Returned_Result_Summaries"
RETURN_DIR = RETURN_ROOT / TASK_ID
ARCHIVE = RETURN_ROOT / (TASK_ID + ".tar.gz")
IDENTITY = Path(str(ARCHIVE) + ".identity.txt")
VALIDATION = Path(str(ARCHIVE) + ".validation.txt")
AUDIT_JSONL = LOGS / "python_command_audit.jsonl"
SHELL_CMD_LOG = LOGS / "command_log.jsonl"

AUTHORITY_PAYLOAD = ROOT / ("HPC_Inputs/t6_r3_r1_teacher_authority_r3_blocked_audit_and_"
                            "successful_forward_runtime_payload_20260910.tar.gz")
AUTH_ROOTNAME = "t6_r3_r1_teacher_authority_r3_blocked_audit_and_successful_forward_runtime_payload_20260910"
AUTH_SHA = "18e59c90d5f44d97cd05d02013593c0ba653e46f495a3335b0e9de3d025c5a95"
AUTH_BYTES = 28415

FAILED_R3 = RETURN_ROOT / ("enzymecage_three_module_t6_r3_teacher_fixed_topology_real_"
                           "langgraph_20_test_final_20260910.tar.gz")
FAILED_R3_ID = Path(str(FAILED_R3) + ".identity.txt")
FAILED_R3_SHA = "74b5a2bf22673a3644cbb55bb5cded64e2cbea84a4d4cdbfc3f59eac8168e2f4"
FAILED_R3_BYTES = 154506
FAILED_R3_ID_SHA = "4a86bdb7a5547e74e8306c8bd496a3afe8ba23f20e6d793a54ed2111141e8abb"
FAILED_R3_TASK = ("enzymecage_three_module_t6_r3_teacher_fixed_topology_real_langgraph_"
                  "20_test_final_20260910")
FAILED_R3_WS = Path("/usrdata/EnzymeCAGE_data/workspaces") / FAILED_R3_TASK

HISTORICAL_FORWARD = RETURN_ROOT / ("enzymecage_three_module_t6_r1_two_to_three_single_gpu_"
                                    "worker_parallel_forward_recovery_20260908.tar.gz")
HISTORICAL_TASK = ("enzymecage_three_module_t6_r1_two_to_three_single_gpu_worker_parallel_"
                   "forward_recovery_20260908")
PRER3 = RETURN_ROOT / ("enzymecage_three_module_t6_r3a_r2a_r3_clean_external_validation_order_"
                       "three_file_final_20260910.tar.gz")
PRER3_TASK = ("enzymecage_three_module_t6_r3a_r2a_r3_clean_external_validation_order_"
              "three_file_final_20260910")

D4_WRAPPER_DIR = RETURN_ROOT / ("d4b1a_wrapper_hash_relative_path_final_package_correction_"
                                "20260716/enzymecage_wrapper")
D4_WRAPPER_PARENT = D4_WRAPPER_DIR.parent      # the only sys.path entry §4.2 allows for it

# operator ruling of 2026-09-10: the frozen, read-only T2B environment carries the real
# LightGBM 4.7.0 capability.  It is appended at the END of sys.path only, so that nothing
# installed under ${PY} can ever be shadowed by it.
T2B_ENV = Path("/usrdata/EnzymeCAGE_envs/"
               "enzymecage_three_module_t2b_v32_single_smiles_runtime_adapter_staged_20260907")
T2B_SITES = (str(sorted(T2B_ENV.glob("lib/python3.*/site-packages"))[0])
              if sorted(T2B_ENV.glob("lib/python3.*/site-packages")) else "")
V32_FROZEN_REPO = Path("/usrdata/EnzymeCAGE_data/workspaces/"
                       "enzymecage_three_module_t2b_v32_single_smiles_runtime_adapter_"
                       "staged_20260907/repo")
V32_ENTRY = V32_FROZEN_REPO / "reaction_analogy" / "single_smiles_v32.py"

BASE_COMMIT = "2d4cc766322a6a01b8a88491aed07536b3b0a320"
BASE_TREE = "c0acb9bd30b985ad43bf969946842da97a68a400"
TEACHER_REMOTE = ("git@github.com:Water-Quality-Risk-Control-Engineering/"
                  "depending.git")

# §1 authority payload membership: name -> (bytes, sha256)
AUTH_MEMBERS = {
    "TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md":
        (5995, "953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4"),
    ("ENZYMECAGE_THREE_MODULE_T6_R3A_R2A_R3_CLEAN_EXTERNAL_VALIDATION_ORDER_THREE_FILE_"
     "FINAL_RETURN_LOCAL_AUDIT_2026-09-10.md"):
        (4974, "30c9711042daf0e5ddfff53ddf3bb3af0827d46bcae7cefde5d575c00904ba80"),
    ("ENZYMECAGE_THREE_MODULE_T6_R3_TEACHER_FIXED_TOPOLOGY_REAL_LANGGRAPH_20_TEST_FINAL_"
     "RETURN_LOCAL_AUDIT_2026-09-10.md"):
        (9636, "279ec84158b481aa664de18ddc13ef6c536f540a53f7014f37420dbb9de47634"),
    ("HPC_ENZYMECAGE_THREE_MODULE_T6_R3_TEACHER_FIXED_TOPOLOGY_REAL_LANGGRAPH_20_TEST_"
     "FINAL_EXECUTOR_ONLY_PROMPT_2026-09-10.md"):
        (12392, "0dd2c83d203b936a44640e5c33820377b9979cb7d0cd2d000aed16ebae1aa763"),
    ("HPC_ENZYMECAGE_THREE_MODULE_T6_REAL_LANGGRAPH_20_TEST_EIGHT_RECORD_END_TO_END_"
     "SMOKE_EXECUTOR_ONLY_PROMPT_2026-09-08.md"):
        (20806, "ab4aa93d174fdf33e198c4f70abdd8c220523a60d0ded26964e2988a12901b38"),
    "ENZYMECAGE_THREE_MODULE_T6_R1_MULTI_GPU_FORWARD_RECOVERY_RETURN_LOCAL_AUDIT_2026-09-08.md":
        (8362, "6059a95858936b3e2cd980451654b6d310cbd1350aa0f65d4521ddb1d6f1271b"),
    ("enzymecage_three_module_t6_r3_teacher_fixed_topology_real_langgraph_20_test_final_"
     "20260910.tar.gz.identity.txt"):
        (470, "4a86bdb7a5547e74e8306c8bd496a3afe8ba23f20e6d793a54ed2111141e8abb"),
}

# §5.1 frozen reuse from the blocked first round
SOURCE_PATCH_SHA = "074f5c31d516e1f699648008ed86767244e25fb128905e119366ad346f8f027a"
SOURCE_PATCH_BYTES = 381120
T6_INCREMENTAL_SHA = "c718f8d7df2b670b057122060e16d8c703d168234409602080437346f1d6154d"
T6_INCREMENTAL_BYTES = 120528
RUN_GPU_WORKER_SHA = "79fb9ba2f5ec8ec33ca4bc86441f8ff4ab0ff1d4eedf7d549704aa1994fb5fdd"
RUN_GPU_WORKER_BYTES = 13037

# §4.2 wrapper identity
WRAPPER_FILES = {
    "predictor.py": (7616, "b9877649deea4f929778331453a0f1f4eb73d72529e3f1c4b95d0a56c4ab82d3"),
    "schema.py": (1310, "a27f33adf78bb2c7a9961d4372cfea0f7728ca91eb89e3b0a6cc7a1e6488fc35"),
    "utils.py": (2046, "732fb1ca4ba19c0a2238b9b7fb7a551d29893c518890199156521af7ba68cfc2"),
}

# §7 fixed GPU assignment (physical index -> frozen UUID -> reaction)
GPU_ASSIGNMENT = {
    0: ("GPU-c5b417ae-284e-8385-262f-57faf35e3771", "R1"),
    1: ("GPU-74f9ec77-8678-5c1d-2051-586647300e90", "R2"),
    2: ("GPU-355dac3b-3ce2-4e25-5247-a913ca688d9e", "R3"),
}
FORMAL_UIDS = ["A0A011QK89", "A0A017SP50"]          # enzyme_pool_uids / top_k=2
THIRD_UID = "A0A017SR40"                            # asset identity only
SEEDS = [40, 41, 42, 43, 44]
CHECKPOINT_BYTES = 72266498
CHECKPOINT_SHA = {
    40: "a95d4687e2cadad1c12f7c1defd21dbdf43db3cce96aa9caace39dbcc226586d",
    41: "c429a98bc265e20d415c3d6f479e0f0d6c47d81c13135c589e2a5e173978dbef",
    42: "cc54be33a23b78fb89c183f0bca6f87b442a5be4dad9666428d05a72a9b7f7a3",
    43: "3eb80be83cb41574204239c80f11008f728029dd9e4ba14c639749d8176b5220",
    44: "b9547d3ba17725a5910cf243d33af9367abb12b3215f4b526405f8bdb14acd16",
}
UID_MAP_SHA = "7b92e8e625cb73f070c8e902687ea5bbdbf749f04a19828e550e3fe205684fe6"
C8_LOOKUP_SHA = "d51a540db2f9798d65e25b46f22960ba29ae2d4b288be218c83c299f24f5d5af"
D4_WRAPPER_TAR_SHA = "12df378964793561c2d193d92c16276739b14df1761ff34c0e46f426e5cad0f7"
V1_ARCHIVE_SHA = "cc2103e17389baca02ec11df150a413350c09bacad87b7de59ffdfd644a73893"
MODEL_VERSION = "v1_20260714"
REPEAT_TOLERANCE = 1e-5

# §6.2: the seven module archives whose SHA256 the T6-R3 first-round prompt §4 pins and which
# this round must keep using.  They are *located by hashing*, never by name or mtime.
ARCHIVES_SHA = {
    "T2D": "0ef31f7ab29bf15f0b18ab59c6b6f6c9d7f3c7498e96bb31c8d91672c94fe4af",
    "T3A": "3836180271f372a2ea3612333f4429b17039f0524346d09bd3f3b85eb66ebfaa",
    "T3B": "f8f9d8e0b85ef7d5fe8c0b7a617575b9a9cc5cfc27a9b9a2515340dc88d84201",
    "T3B_R1": "eb434860397e8c2110fbcc5087622aa5cc924f177c968c3ac2e78f8cd1ddc805",
    "T5A_R2": "051c80d9d04c1a240e902163ef75bd1bd90e8b52d65d6ea1f25972d64ffa6085",
    "T5B_R2": "444589018e84912338604e210642b901c72db0f0e42c284573e44be7bacf1694",
    "T5C_R2": "a02ee942c9ee4fa6c790ddb2253ec175cd129a1a6cd27a961c2bc2bcdba8ff26",
}
# read-only frozen protein assets shared by all three UIDs (original contract §4: the expected
# SHA of each file is parsed out of the SHA-verified T3B-R1 archive, not asserted here)
PROTEIN_ASSETS = {
    "GVP": Path("/usrdata/EnzymeCAGE_data/feature/protein/gvp/gvp_protein_feature_flat.pt"),
    "ESM_NODE": Path("/usrdata/EnzymeCAGE_data/feature/protein/ESM2_3B_corrected_107705/"
                     "pocket_node_feature/esm_node_feature.torch.pt"),
    "ESM_MEAN": Path("/usrdata/EnzymeCAGE_data/feature/protein/ESM2_3B_corrected_107705/"
                     "protein_level/seq2feature.pkl"),
}
D4_WHITELIST = (RETURN_ROOT / "m3_agent_data_assets/assets/d4/uid_asset_availability.csv.gz")
# the SHA-verified member of the authority payload that records the frozen sequence identity
AUTH_R1_AUDIT = ("ENZYMECAGE_THREE_MODULE_T6_R1_MULTI_GPU_FORWARD_RECOVERY_RETURN_LOCAL_"
                 "AUDIT_2026-09-08.md")
# §6.3 / §7 frozen reaction registry and frozen UID order (original contract §4 and §5)
REACTIONS = [("RT-1a7bea59ede1acf0", "c1ccc2[nH]nnc2c1>>Nc1ccccc1C(=O)[O-]"),
             ("RT-f00e98d322e2380e", "Nc1ccccc1C(=O)[O-]>>Oc1ccccc1O"),
             ("RT-bbb9dc4b010674c1",
              "Nc1ccccc1C(=O)[O-]>>C=C(OC1C=C(C(=O)[O-])C=CC1O)C(=O)[O-]")]
THREE_UIDS = ["A0A011QK89", "A0A017SP50", "A0A017SR40"]
REACTION_OVERLAY = RUNTIME_ASSETS / "t3/reaction_overlay"
REACTION_OVERLAY_REBUILD = RUNTIME_ASSETS / "t3/reaction_overlay_rebuild"
V1_OVERLAY = RUNTIME_ASSETS / "v1_overlay"
V1_CKPT_MEMBER = "enzymecage_v1_20260714/3b_ensemble/seed_%d/best_model.pth"
V1_CONFIG_MEMBER = "enzymecage_v1_20260714/3b_ensemble/seed_%d/config.yaml"
# the three config fields a task-local copy may re-point; everything else stays byte-identical
OVERLAY_CONFIG_FIELDS = ("rxn_fp", "mol_conformation", "reaction_center")

# §4.2 probe inventory
PROBE_MODULES = ["ase", "torch", "torch_geometric", "rdkit", "numpy", "pandas", "yaml",
                 "pydantic", "langgraph", "jsonschema", "sklearn", "lightgbm", "joblib",
                 "scipy", "xgboost"]
# the operator correction of 2026-09-10: lightgbm is not a teacher-contract requirement and
# not a runtime dependency of this chain; it is still probed, its traceback kept, and a
# zero-reference audit must hold, otherwise the round blocks.
NOT_APPLICABLE_MODULES = {"lightgbm": ("LIGHTGBM_IMPORT", "LIGHTGBM_REFERENCE_COUNT",
                                        "LIGHTGBM_GATE")}
HARD_GATE_MODULES = ["ase", "torch", "torch_geometric", "rdkit", "numpy", "pandas", "yaml",
                     "pydantic", "langgraph", "jsonschema", "sklearn", "joblib", "scipy",
                     "xgboost"]
TOPOLOGY_FILES = ["src/graph.py", "src/state.py", "src/nodes/multi_step_bridge_node.py",
                  "src/schemas/bridge.py"]
FINAL_STATUS_LINES = [
    "T6_R3_R1_PINNED_PYTHON_TEACHER_FIXED_TOPOLOGY_FINAL_READY_FOR_LOCAL_AUDIT",
    "PYTHON_ENVIRONMENT_PREFLIGHT=PASS",
    "PYTHON_EXECUTABLE=" + PY,
    "ASE_IMPORT=PASS",
    "UNIFIED_GRAPH_RUNTIME=PASS",
    "TEACHER_FIXED_TOPOLOGY=PASS_UNCHANGED",
    "COMPONENT_TESTS=PASS_157",
    "T3B_NATIVE_LOAD=PASS_3_OF_3",
    "UID_SEQUENCE_GVP_POCKET_ESM=PASS",
    "T3B_BOUNDED_FORWARD=PASS_6_OF_6",
    "REAL_LANGGRAPH_COMPILE_INVOKE_STREAM=PASS",
    "REAL_SMOKE_RECORDS=PASS_8_OF_8",
    "TEST_01_TO_20=PASS_20_OF_20",
    "C8_TO_T5_REAL_CONTINUOUS_REGRESSION=PASS",
    "GSCHEMA=PASS",
    "DETERMINISM=PASS",
    "MUTATION=PASS",
    "ACCESS_AUDIT=PASS",
    "PERSISTENT_INPUT_NONMUTATION=PASS",
    "ARCHIVE_MANIFEST=PASS_COMPLETE",
    "EXTERNAL_THREE_FILE_DELIVERY=PASS",
    "T6_OVERALL_READY_FOR_LOCAL_AUDIT=true",
    "G7_PASSED=AWAITING_LOCAL_AUDIT",
]


# ---------------------------------------------------------------- helpers
def now_utc():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sha256_stream(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(str(path), "rb") as fh:
        for block in iter(lambda: fh.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def base_env(extra=None):
    env = dict(os.environ)
    env.update({
        "PYTHONDONTWRITEBYTECODE": "1",
        "TMPDIR": str(TMPS),
        "XDG_CACHE_HOME": str(CACHE),
        "MPLCONFIGDIR": str(CACHE / "mpl"),
        "NUMBA_CACHE_DIR": str(CACHE / "numba"),
        "TORCH_HOME": str(CACHE / "torch"),
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
        "LC_ALL": "C",
        "TZ": "UTC",
    })
    if extra:
        env.update(extra)
    return env


def interp_identity():
    """What the *running* interpreter says about itself (§12 audit column)."""
    return {
        "sys_executable": sys.executable,
        "realpath": os.path.realpath(sys.executable),
        "argv0": sys.argv[0] if sys.argv else "",
        "prefix": sys.prefix,
        "base_prefix": sys.base_prefix,
        "version": sys.version.split()[0],
        "equals_pinned_py": sys.executable == PY,
        "venv_prefix_ok": sys.prefix == str(Path(PY).parent.parent),
    }


def log_command(kind, argv, cwd, exit_code, note="", stdout_sha="", stderr_sha="",
                child=None, utc=None, duration=None):
    LOGS.mkdir(parents=True, exist_ok=True)
    rec = {"utc": utc or now_utc(), "kind": kind, "argv": list(map(str, argv)),
           "argv0": str(argv[0]) if argv else "",
           "argv0_realpath": os.path.realpath(str(argv[0])) if argv else "",
           "cwd": str(cwd), "exit": exit_code, "note": note,
           "stdout_sha256": stdout_sha, "stderr_sha256": stderr_sha,
           "duration_s": duration}
    if child:
        rec["child"] = child
    with open(str(AUDIT_JSONL), "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


def run(cmd, cwd=None, env=None, label=None, note="", timeout=None, shell_log=True):
    """Run a non-Python system command (tar/git/sha256sum/nvidia-smi) with logging."""
    import time as _t
    t0 = _t.monotonic()
    p = subprocess.run(list(map(str, cmd)), cwd=str(cwd) if cwd else None, env=env,
                       capture_output=True, timeout=timeout)
    rec = {"utc": now_utc(), "kind": "system", "argv": list(map(str, cmd)),
           "cwd": str(cwd or Path.cwd()), "exit": p.returncode, "note": note,
           "duration_s": round(_t.monotonic() - t0, 3)}
    if shell_log:
        _append(SHELL_CMD_LOG, rec)
    return p.returncode, p.stdout.decode("utf-8", "replace"), \
        p.stderr.decode("utf-8", "replace")


def _append(path, rec):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(str(path), "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")


def run_py(script_or_args, args=(), cwd=None, env=None, note="", timeout=None,
           capture=True, label=None):
    """Launch a Python command with the pinned ${PY} absolute path and audit it.

    argv[0] is always ${PY} itself; a bare python/python3//usr/bin/python is refused.
    The child must emit ``R1_INTERP {...}`` (r1_common.emit_interp) so that the audit row
    carries the in-process sys.executable, not an assertion made by this parent.
    """
    import time as _t
    argv = [PY] + ([script_or_args] if isinstance(script_or_args, (str, Path))
                   else list(script_or_args)) + list(args)
    for forbidden in ("python", "python3", "/usr/bin/python", "/usr/bin/python3"):
        if argv[0] == forbidden:
            raise AssertionError("bare interpreter invocation refused: %r" % argv[0])
    e = base_env(env)
    t0 = _t.monotonic()
    p = subprocess.run([str(a) for a in argv], cwd=str(cwd) if cwd else None, env=e,
                       capture_output=capture, timeout=timeout)
    out = p.stdout.decode("utf-8", "replace") if capture else ""
    err = p.stderr.decode("utf-8", "replace") if capture else ""
    child = None
    for line in out.splitlines():
        if line.startswith("R1_INTERP "):
            child = json.loads(line[len("R1_INTERP "):])
    dur = round(_t.monotonic() - t0, 3)
    log_command("python", argv, cwd or (cwd if cwd else Path.cwd()), p.returncode, note,
                hashlib.sha256(out.encode()).hexdigest() if capture else "",
                hashlib.sha256(err.encode()).hexdigest() if capture else "", child,
                duration=dur)
    if label:
        (LOGS / (label + ".stdout.log")).write_text(out, encoding="utf-8")
        (LOGS / (label + ".stderr.log")).write_text(err, encoding="utf-8")
    if capture:
        return p.returncode, out, err
    return p.returncode, "", ""


def emit_interp():
    """Called inside every child process so the audit can read the real sys.executable."""
    print("R1_INTERP " + json.dumps(interp_identity()))
    sys.stdout.flush()


def self_audit(script_path, exit_code, note=""):
    """A step driver is launched by the shell with the absolute ${PY}; it records its own row
    (argv[0]=${PY}, in-process sys.executable) so that no Python command is missing from the
    §12 audit table."""
    log_command("python", [PY, script_path], Path(script_path).parent, exit_code, note,
                child=interp_identity())


# ---------------------------------------------------------------- safe unpack
def safe_extract(tar_path, dest, exclude_prefixes=()):
    """Extract with tarfile, refusing absolute paths, '..' traversal, symlinks, hardlinks,
    devices and FIFOs. Returns an inventory of what was actually written."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    rejected, written = [], []
    with tarfile.open(str(tar_path), "r:*") as tf:
        for m in tf.getmembers():
            name = m.name
            parts = Path(name).parts
            if name.startswith("/") or ".." in parts:
                rejected.append({"member": name, "reason": "unsafe path"})
                continue
            if not (m.isfile() or m.isdir()):
                rejected.append({"member": name, "reason": "not regular/dir: %s" % m.type})
                continue
            if m.issym() or m.islnk():
                rejected.append({"member": name, "reason": "symlink/hardlink member"})
                continue
            if any(str(name).startswith(p) for p in exclude_prefixes):
                continue
            target = (dest / name).resolve()
            if not str(target).startswith(str(dest.resolve())):
                rejected.append({"member": name, "reason": "escapes destination"})
                continue
            if m.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with tf.extractfile(m) as src, open(str(target), "wb") as out:
                shutil.copyfileobj(src, out)
            os.chmod(str(target), 0o644)
            written.append({"member": name, "bytes": m.size})
    return {"tar": str(tar_path), "dest": str(dest), "written": len(written),
            "rejected": rejected, "members": written}


def read_libc_soname_check():
    """Informational: confirm ctypes works (used by the xgboost shared-library probe)."""
    try:
        ctypes.CDLL(None)
        return True
    except Exception:
        return False
