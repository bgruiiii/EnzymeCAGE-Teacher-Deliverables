# -*- coding: utf-8 -*-
"""T6-R3-R1 p15b — the real full-chain child on the BASE V1 package root (§8-B).

One process, one compiled teacher graph, one frozen wrapper runtime, and inside it the
contract's §8 scenarios, in this order:

  SC4   invalid SMILES entry                      -> fail-closed before any model/LLM request
  SC1   T2D root substrate under the base track   -> whatever the fixed topology really does
  SS1m3 CASE_B primary, pipeline_mode=m3, invoke  -> real GPU forward, real enzyme pool
  SS1m5 CASE_B primary, pipeline_mode=m5, stream  -> consumed to the real terminal state,
                                                     then the *same* real state is pushed
                                                     through the production trait node and
                                                     the production T5 route-step aggregator
  SS2   CASE_C fallback substrate, m3 invoke      -> real MISSING_REACTION_ASSET, no swap
  SC2   T3A first qualified proxy, real forward   -> FROZEN_PROXY track, no staged score
  SC1b  per-step enzyme matching on the real route-> production apply_step_enzyme_matches
  SC3   two real bridge legs of the T2D route     -> step re-attach, denominator, unmatched

Teacher source is imported read-only and never patched; every number written here is either
observed from the graph state, from the wrapper's own trace, or read out of a SHA-pinned
archive member.
"""
import hashlib
import json
import os
import re
import sys
import time
import tarfile
import traceback
import logging
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import p15_shared as SH                                              # noqa: E402

CFG = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
OUT_JSON = Path(CFG["out_json"])
OUT_NORM = Path(CFG["out_norm"])
OUT_SCORES = Path(CFG["out_scores"])
RUN_LABEL = CFG["run_label"]

RES = {"run_label": RUN_LABEL, "track": "base", "utc_started": SH.utc(),
       "problems": [], "scenarios": [], "control_scenarios": [], "smoke_records": [],
       "t5": {}, "gaps": [], "assets": {}, "counters": {}}
ALL_FLOATS = []
# the *raw* state object each scenario left behind, kept so that a production callable can be
# fed the graph's own pydantic output instead of a re-typed dict (never reconstructed by hand)
RAW_VALS = {}


def prob(kind, msg, **kw):
    RES["problems"].append(dict(kind=kind, message=str(msg)[:500], **kw))


def gap(kind, msg, **kw):
    RES["gaps"].append(dict(kind=kind, message=str(msg)[:500], **kw))


def say(line):
    print("[%s][%s] %s" % (RUN_LABEL, SH.utc(), line), flush=True)


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


# ------------------------------------------------------------------ 0. interpreter gate
RES["interp"] = {"sys_executable": sys.executable, "realpath": os.path.realpath(sys.executable),
                 "version": sys.version.split()[0], "argv0": sys.argv[0],
                 "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
                 "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
                 "is_pinned": os.path.realpath(sys.executable)
                 == os.path.realpath(CFG["pinned_py"])}
if not RES["interp"]["is_pinned"]:
    prob("interpreter", "child is not on the pinned interpreter")
print("R1_INTERP " + json.dumps(RES["interp"]), flush=True)
AUDIT = SH.install_audit()

ENV_PRE = {}
for k, v in CFG["env"].items():
    ENV_PRE[k] = os.environ.get(k)
    os.environ[k] = v
RES["env_pre_existing"] = ENV_PRE
RES["env_set_by_child"] = dict(CFG["env"])
RES["env_credentials_popped"] = {}
for k in CFG.get("env_pop", []):
    RES["env_credentials_popped"][k] = os.environ.pop(k, None)
# the child must run the *production* wrapper path, never the mock
os.environ["ENZYMECAGE_V1_PACKAGE_ROOT"] = CFG["v1_base_root"]
RES["package_root_under_test"] = CFG["v1_base_root"]

STAGED = CFG["staged"]
sys.path.insert(0, STAGED)
RES["sys_path_head"] = sys.path[:4]

# ------------------------------------------------------------------ 1. teacher graph, once
from src.graph import build_graph, compile_graph                      # noqa: E402
from src.state import EnzymeCrewState                                 # noqa: E402
from src.nodes.trait_filter_node import trait_filter_node             # noqa: E402
from src.tools.trait_query import build_trait_annotations             # noqa: E402
from src.tools.enzymecage_client import call_enzymecage               # noqa: E402
from src.schemas.bridge import MultistepRouteInput                    # noqa: E402
from src.nodes.multi_step_bridge_node import apply_step_enzyme_matches  # noqa: E402
from src.utils.route_step_organism_aggregator import (aggregate_route,
                                                      RouteAggregationError)  # noqa: E402
from src.schemas.evidence import RouteAggregationInput, RouteStepHostAnnotation  # noqa: E402
from rdkit import Chem  # T6-R3-R2 repair B: kekulised serialisation of the SAME molecule
import langgraph.graph as lgg                                         # noqa: E402
import config.settings as settings                                    # noqa: E402
# ``enzymecage_wrapper`` is deliberately NOT imported here: the production client loads it
# through src.tools.enzymecage_client._load_wrapper(), which is what puts D4_WRAPPER_ROOT on
# sys.path.  SH.wrapper_state() reads that same singleton back, so this child never gets to
# bypass the production loader.

workflow = build_graph()
compiled = compile_graph()
RES["compile"] = {"compile_calls": 1, "graph_builder": "src.graph.build_graph",
                  "compiler": "src.graph.compile_graph",
                  "stategraph_class": str(lgg.StateGraph),
                  "stategraph_from_langgraph": "langgraph" in os.path.realpath(lgg.__file__),
                  "workflow_nodes": sorted(workflow.nodes), "node_count": len(workflow.nodes),
                  "compiled_type": type(compiled).__name__}
say("compiled the teacher graph: %d nodes" % len(workflow.nodes))
RES["production_config"] = {
    "module_file": os.path.realpath(settings.__file__),
    "redaction_rule": ("any key containing KEY/TOKEN/SECRET/PASSWORD is written as <REDACTED>, "
                       "never a credential value"),
    "values": {(k if not any(s in k for s in ("KEY", "TOKEN", "SECRET", "PASSWORD"))
               else k + "<REDACTED>"):
               ("<REDACTED>" if any(s in k for s in ("KEY", "TOKEN", "SECRET", "PASSWORD"))
                else (str(v) if not isinstance(v, (int, float, bool, type(None), str)) else v))
               for k, v in sorted(vars(settings).items())
               if k.isupper() and any(s in k for s in (
                   "ENZYMECAGE", "D4_WRAPPER", "C8_", "M3_AGENT", "DEPENDING", "TOP_K",
                   "MICROBE", "TRAIT", "LLM", "PORTRAITS", "ROUTES", "POOL"))}}

LLM_ABORT = "LLM API 未配置"


def counters():
    ws = SH.wrapper_state()
    return {"wrapper_forward_call_count": ws["forward_call_count"],
            "runtime_initialized": ws["runtime_initialized"],
            "package_root": ws["package_root"],
            "wrapper_module_loaded": ws["wrapper_imported"],
            "network_events_so_far": len(AUDIT.net),
            "llm_credential_gate_aborts_so_far": RES["counters"].get("llm_aborts", 0)}


# ------------------------------------------------------------------ 2. frozen input identity
def read_tar_member(tar_path, name_contains):
    with tarfile.open(str(tar_path), "r:*") as tf:
        for m in tf.getmembers():
            if m.isfile() and name_contains in m.name:
                return m.name, tf.extractfile(m).read()
    raise KeyError("%s not in %s" % (name_contains, tar_path))


def archive_identity(path, want_sha):
    got = SH.sha_file(path)
    if got != want_sha:
        prob("archive_identity", "SHA-pinned archive changed: %s" % path, observed=got)
    return {"path": str(path), "bytes": os.path.getsize(str(path)), "sha256": got,
            "expected_sha256": want_sha, "matches": got == want_sha}


RES["assets"]["t2d_archive"] = archive_identity(CFG["t2d_tar"], CFG["t2d_sha"])
RES["assets"]["t3a_archive"] = archive_identity(CFG["t3a_tar"], CFG["t3a_sha"])
RES["assets"]["v1_base_package"] = {"root": CFG["v1_base_root"],
                                    "manifest_sha256": CFG["v1_base_manifest_sha256"]}
RES["assets"]["uid_map"] = {"path": CFG["env"]["C8_UID_SOURCE_MAP_PATH"],
                            "sha256": SH.sha_file(CFG["env"]["C8_UID_SOURCE_MAP_PATH"]),
                            "expected_sha256": CFG["uid_map_sha256"]}
RES["assets"]["c8_lookup_index"] = {
    "path": os.path.join(CFG["env"]["C8_LOOKUP_ROOT"], "C8_METATRAITS_LOOKUP_INDEX.jsonl"),
    "sha256": SH.sha_file(os.path.join(CFG["env"]["C8_LOOKUP_ROOT"],
                                       "C8_METATRAITS_LOOKUP_INDEX.jsonl")),
    "expected_sha256": CFG["c8_lookup_sha256"]}
for key in ("uid_map", "c8_lookup_index"):
    if RES["assets"][key]["sha256"] != RES["assets"][key]["expected_sha256"]:
        prob("c8_asset", "%s identity mismatch" % key)

# T2D route rows (real multi-step route, never re-typed)
_t2d_name, _t2d_raw = read_tar_member(CFG["t2d_tar"], "ROUTE_TO_REACTION_TASK_RESULTS.jsonl")
ROUTE_ROWS = [json.loads(l) for l in _t2d_raw.decode("utf-8").splitlines() if l.strip()]
RES["assets"]["t2d_route_member"] = {"member": _t2d_name, "bytes": len(_t2d_raw),
                                     "sha256": sha_bytes(_t2d_raw), "rows": len(ROUTE_ROWS)}
ROUTE_ID = sorted({r["route_id"] for r in ROUTE_ROWS})
if len(ROUTE_ID) != 1:
    prob("t2d_route", "expected exactly one route_id, found %r" % ROUTE_ID)
ROUTE_ID = ROUTE_ID[0]
RT_BY_REACTION = {r["reaction_smiles"]: r for r in ROUTE_ROWS}
say("T2D route %s with %d real reaction tasks" % (ROUTE_ID, len(ROUTE_ROWS)))

# T3A proxy rows (frozen proxy track for C2)
_t3a_name, _t3a_raw = read_tar_member(CFG["t3a_tar"], "PROXY_SELECTION_RESULTS.csv")
import csv as _csv
import io as _io
PROXY_ROWS = list(_csv.DictReader(_io.StringIO(_t3a_raw.decode("utf-8"))))
RES["assets"]["t3a_proxy_member"] = {"member": _t3a_name, "bytes": len(_t3a_raw),
                                     "sha256": sha_bytes(_t3a_raw), "rows": len(PROXY_ROWS)}
_pn, _praw = read_tar_member(CFG["t3a_tar"], "PROXY_ENZYMECAGE_RESULTS.jsonl")
PROXY_FWD = [json.loads(l) for l in _praw.decode("utf-8").splitlines() if l.strip()]
RES["assets"]["t3a_proxy_forward_member"] = {"member": _pn, "bytes": len(_praw),
                                             "sha256": sha_bytes(_praw), "rows": len(PROXY_FWD)}

# §8-A frozen smoke rows drive the two live-case inputs and the smoke record ids; nothing here
# is hand-typed - the substrates are read back out of the frozen CSV and cross-checked against
# the teacher case file / the §8-A route-C probe they were selected from.
SMOKE = {r["smoke_record_id"]: r for r in CFG["smoke_rows"]}

CASE_B = json.loads(Path(CFG["case_b"]).read_text(encoding="utf-8"))
CASE_INVALID = json.loads(Path(CFG["case_invalid"]).read_text(encoding="utf-8"))
PROBE_C = json.loads(Path(CFG["c_fallback_probe"]).read_text(encoding="utf-8"))
RES["assets"]["case_b"] = {"path": CFG["case_b"], "sha256": SH.sha_file(CFG["case_b"]),
                           "case_id": CASE_B.get("case_id"),
                           "substrate": CASE_B["expected"]["substrate"]["smiles"]}
RES["assets"]["case_invalid"] = {"path": CFG["case_invalid"],
                                 "sha256": SH.sha_file(CFG["case_invalid"]),
                                 "case_id": CASE_INVALID.get("case_id"),
                                 "query": CASE_INVALID.get("query"),
                                 "expected": CASE_INVALID.get("expected")}
RES["assets"]["c_fallback_probe"] = {"path": CFG["c_fallback_probe"],
                                     "sha256": SH.sha_file(CFG["c_fallback_probe"]),
                                     "entries": len(PROBE_C.get("candidates_with_route_C") or [])}
B_SUBSTRATE = SMOKE["S1"]["substrate"]
C_SUBSTRATE = SMOKE["S2"]["substrate"]
if B_SUBSTRATE != CASE_B["expected"]["substrate"]["smiles"]:
    prob("smoke_input", "S1 substrate no longer equals the teacher B-primary case substrate")
PROBE_C_ENTRY = next((e for e in (PROBE_C.get("candidates_with_route_C") or [])
                      if e.get("substrate") == C_SUBSTRATE), None)
if PROBE_C_ENTRY is None:
    prob("smoke_input", "S2 substrate is not an entry of the §8-A route-C probe file")
else:
    RES["assets"]["c_fallback_probe"]["s2_entry"] = {
        "substrate": C_SUBSTRATE, "route_used": PROBE_C_ENTRY.get("route_used"),
        "pool_size": PROBE_C_ENTRY.get("pool_size"),
        "candidate_count": PROBE_C_ENTRY.get("candidate_count"),
        "top_reaction_sha256": PROBE_C_ENTRY.get("top_reaction_sha256")}
# the invalid token is lifted verbatim out of the teacher's own case file, never hand-typed
INVALID_TOKEN = re.search(r"([A-Za-z_]*INVALID[A-Za-z_]*)", CASE_INVALID.get("query") or "")
INVALID_QUERY = CASE_INVALID["query"]
if not INVALID_TOKEN:
    prob("smoke_input", "no INVALID token found inside the teacher case_3 query")


# ------------------------------------------------------------------ 3. scenario helpers
def run_scenario(tag, payload, api="stream", stop_node=None):
    thread = "%s-%s-%s" % (RUN_LABEL, tag, re.sub(r"[^A-Za-z0-9]", "", payload.get(
        "user_query", "")[:12]))
    c0 = counters()
    if api == "invoke":
        t0 = time.monotonic()
        started = SH.utc()
        err_tb = None
        try:
            vals = compiled.invoke(payload, {"configurable": {"thread_id": thread}})
        except Exception:
            err_tb = traceback.format_exc()
            vals = SH._g(compiled.get_state({"configurable": {"thread_id": thread}}),
                         "values", {}) or {}
        view = SH.state_view(vals or {})
        # ``invoke`` returns only the final state, so the per-node evidence for this API is
        # taken from the official durable checkpoint history: StateSnapshot.next names the
        # node the graph was about to run at that superstep.
        chrono = []
        hist_error = None
        try:
            for snap in compiled.get_state_history({"configurable": {"thread_id": thread}}):
                chrono.append({"step": (snap.metadata or {}).get("step"),
                               "source": (snap.metadata or {}).get("source"),
                               "next_nodes": list(snap.next or ()),
                               "present_state_keys": sorted((snap.values or {}).keys()),
                               "scientific_view_sha256": SH.sha_obj(
                                   SH.scrub(SH.state_view(snap.values or {}), []))})
        except Exception:
            hist_error = traceback.format_exc().splitlines()[-1][:250]
        chrono.reverse()                                        # -> chronological
        derived = [c["next_nodes"][0] for c in chrono[:-1] if len(c["next_nodes"]) == 1]
        rec = dict({"scenario": tag, "thread_id": thread, "api": "invoke",
                    "started_utc": started, "ended_utc": SH.utc(),
                    "wall_s": round(time.monotonic() - t0, 3),
                    "node_execution_order": derived,
                    "node_order_channel": "compiled.get_state_history()[i].next (official)"
                    if derived else "no single-successor checkpoint pairs observed",
                    "checkpoint_history": chrono, "checkpoint_history_error": hist_error,
                    "checkpoint_count": len(chrono),
                    "stopped_early": False,
                    "raised": (err_tb.strip().splitlines()[-1][:300] if err_tb else None),
                    "traceback": err_tb, "consumed_to_terminal": err_tb is None,
                    "reached_end": err_tb is None}, **view)
        updates, transitions, floats = [], [], []
        RAW_VALS[tag] = vals or {}
    else:
        rec, updates, transitions, floats = SH.run_graph(compiled, tag, payload, thread,
                                                        stop_node=stop_node)
        rec["api"] = "stream"
        RAW_VALS[tag] = SH._g(compiled.get_state({"configurable": {"thread_id": thread}}),
                              "values", {}) or {}
    c1 = counters()
    rec["counters_before"] = c0
    rec["counters_after"] = c1
    rec["wrapper_forward_calls_in_scenario"] = (
        (c1["wrapper_forward_call_count"] or 0) - (c0["wrapper_forward_call_count"] or 0)
        if c1["wrapper_forward_call_count"] is not None else 0)
    if rec.get("state_error") and LLM_ABORT in str(rec.get("state_error")):
        RES["counters"]["llm_aborts"] = RES["counters"].get("llm_aborts", 0) + 1
        rec["llm_abort_observed"] = True
    norm, nfloats = SH.norm_line(tag, thread, rec)
    ALL_FLOATS.extend([["scenario:" + tag] + f for f in floats + nfloats])
    RES["scenarios"].append({"scenario": tag, "record": rec,
                             "node_updates": updates, "state_transitions": transitions})
    with OUT_NORM.open("a", encoding="utf-8") as fh:
        fh.write(norm + "\n")
    say("%-12s nodes=%s end=%s err=%s fwd=%s" % (
        tag, ">".join(rec["node_execution_order"]) or "(none recorded)",
        rec["reached_end"], str(rec["state_error"])[:60],
        rec["wrapper_forward_calls_in_scenario"]))
    return rec


def client_call(tag, reaction, pool, expect_ok=True):
    """One call of the *production* client callable the enzymecage node itself uses."""
    handlers = SH.attach_capture(["src.tools.enzymecage_client", "src.tools.enzymecage_wrapper",
                                  "enzymecage_wrapper"])
    c0 = counters()
    t0 = time.monotonic()
    started = SH.utc()
    tb = ranked = None
    try:
        ranked = call_enzymecage(reaction_smiles=reaction, enzyme_pool_uids=list(pool))
    except Exception:
        tb = traceback.format_exc()
    ended = SH.utc()
    c1 = counters()
    ws = SH.wrapper_state()
    out = {"tag": tag, "started_utc": started, "ended_utc": ended,
           "wall_s": round(time.monotonic() - t0, 3),
           "production_callable": "src.tools.enzymecage_client.call_enzymecage",
           "callable_file": os.path.realpath(
               sys.modules["src.tools.enzymecage_client"].__file__),
           "reaction_smiles": reaction,
           "reaction_sha256": hashlib.sha256(reaction.encode("utf-8")).hexdigest(),
           "request_pool_size": len(list(pool)), "request_pool_ordered": list(pool),
           "ranked": [{"uid": r.uid, "score": r.score, "rank": r.rank,
                       "ensemble_ci": list(r.ensemble_ci) if r.ensemble_ci else None}
                      for r in (ranked or [])],
           "raised": (tb.strip().splitlines()[-1][:400] if tb else None),
           "traceback": tb,
           "wrapper_trace": ws["last_trace"],
           "wrapper_forward_call_count_before": c0["wrapper_forward_call_count"],
           "wrapper_forward_call_count_after": c1["wrapper_forward_call_count"],
           "forward_executed": (ws["last_trace"] or {}).get("forward_executed"),
           "missing_reaction_assets": (ws["last_trace"] or {}).get("missing_reaction_assets"),
           # T6-R3-R2 repair C: attach_capture returns (logger, handler) pairs
           "client_log_lines": [l for _lg, h in handlers for l in h.lines],
           "evidence_hash_observed_in_client_log": None}
    SH.detach_capture(handlers)
    for line in out["client_log_lines"]:
        m = re.search(r"evidence_hash=([0-9a-f]{8,16})", line["msg"])
        if m:
            out["evidence_hash_observed_in_client_log"] = m.group(1)
            break
    ALL_FLOATS.extend([["client:" + tag + ".ranked[%d].score" % i, repr(r["score"])]
                       for i, r in enumerate(out["ranked"])])
    RES["counters"]["client_calls"] = RES["counters"].get("client_calls", 0) + 1
    say("  client %-26s fwd_delta=%s ranked=%d err=%s" % (
        tag, (out["wrapper_forward_call_count_after"] or 0)
        - (out["wrapper_forward_call_count_before"] or 0)
        if out["wrapper_forward_call_count_after"] is not None else "n/a",
        len(out["ranked"]), (out["raised"] or "")[:60]))
    return out


# ------------------------------------------------------------------ 4. SC4 / SC1 (pre-model)
sc4 = run_scenario("SC4_INVALID_SMILES", {"user_query": INVALID_QUERY, "pipeline_mode": "m3"})
RES["control_scenarios"].append({
    "control": "C4_invalid_SMILES_entry_fail_closed",
    "input_identity": {"case_file": CFG["case_invalid"],
                       "case_file_sha256": RES["assets"]["case_invalid"]["sha256"],
                       "case_id": CASE_INVALID.get("case_id"),
                       "user_query": INVALID_QUERY,
                       "invalid_token": (INVALID_TOKEN.group(1) if INVALID_TOKEN else None)},
    "expected": CASE_INVALID.get("expected"),
    "observed": {"fail_closed": sc4["state_fail_closed"], "error": sc4["state_error"],
                 "nodes": sc4["node_execution_order"],
                 "evidence_chain_stages": sc4["evidence_chain_stages"]},
    "call_counts": {"enzymecage_wrapper_runtime_initialized":
                    sc4["counters_after"]["runtime_initialized"],
                    "enzymecage_forward_calls": sc4["wrapper_forward_calls_in_scenario"],
                    "asset_loader_initialized": sc4["counters_after"]["runtime_initialized"],
                    "llm_http_requests": sc4["counters_after"]["network_events_so_far"]
                    - sc4["counters_before"]["network_events_so_far"],
                    "llm_credential_gate_abort_in_state_error":
                    bool(sc4.get("llm_abort_observed"))},
    "status": ("PASS" if sc4["state_fail_closed"]
               and not sc4["counters_after"]["runtime_initialized"]
               and sc4["wrapper_forward_calls_in_scenario"] == 0 else "FAIL")})
if sc4["state_fail_closed"] is not True:
    prob("C4", "invalid SMILES did not fail closed")

sc1 = run_scenario("SC1_T2D_ROOT_SUBSTRATE_BASE_TRACK",
                   {"user_query": ROUTE_ROWS[0]["substrate_smiles"], "pipeline_mode": "m3"})
step1_pool = list(sc1["enzyme_pool_final_ordered"])
RES["pools"] = {"SC1_root_substrate_pool_size": len(step1_pool),
                "SC1_pool_ordered_head": step1_pool[:12]}
RES["control_scenarios"].append({
    "control": "C1_recall_failure_fail_closed",
    "mechanism": ("real m3 invoke on the frozen T2D route root substrate under the base asset "
                  "track; the outcome below is whatever the fixed topology really produced - "
                  "no sample was substituted"),
    "input_identity": {"reaction_task_id_upstream": ROUTE_ROWS[0]["reaction_task_id"],
                       "reaction_smiles_upstream": ROUTE_ROWS[0]["reaction_smiles"],
                       "t2d_member": RES["assets"]["t2d_route_member"],
                       "substrate": ROUTE_ROWS[0]["substrate_smiles"]},
    "observed": {"nodes": sc1["node_execution_order"], "route_used": sc1["pool_route_used"],
                 "pool_size": sc1["pool_size"], "candidate_count":
                 sc1["candidate_reaction_count"], "error": sc1["state_error"],
                 "fail_closed": sc1["state_fail_closed"],
                 "enzymecage_forward_calls": sc1["wrapper_forward_calls_in_scenario"]},
    "status": ("OBSERVED" if sc1["state_fail_closed"] is not None else "INCOMPLETE")})

# ------------------------------------------------------------------ 5. S1 (CASE_B) m3 invoke
s1m3 = run_scenario("SS1_CASE_B_M3_INVOKE",
                    {"user_query": B_SUBSTRATE, "pipeline_mode": "m3"}, api="invoke")
RES["invoke_api"] = {"used": s1m3["api"], "scenarios_using_invoke": [s1m3["scenario"]]}
s1m3_pool = list(s1m3["enzyme_pool_final_ordered"])
# the identical payload through the *other* public API, so invoke/stream agreement on one input
# is measured inside one process instead of being asserted
s1m3s = run_scenario("SS1_CASE_B_M3_STREAM_SAME_INPUT",
                     {"user_query": B_SUBSTRATE, "pipeline_mode": "m3"})
s1m3s_pool = list(s1m3s["enzyme_pool_final_ordered"])
_cmp_keys = ["substrate_smiles", "candidate_reaction_count", "reaction_task_id",
             "pool_route_used", "pool_size", "enzyme_pool_final_ordered",
             "evidence_chain_stages", "evidence_chain_sha256", "state_fail_closed"]
_agree = {k: [s1m3.get(k), s1m3s.get(k), s1m3.get(k) == s1m3s.get(k)] for k in _cmp_keys}
RES["invoke_stream_equivalence"] = {
    "why": ("contract asks for at least one invoke and at least one stream; running the same "
            "input through both in the same process also measures whether the two entry points "
            "agree on the state the graph ends in"),
    "input": {"user_query": B_SUBSTRATE, "pipeline_mode": "m3"},
    "invoke_scenario": s1m3["scenario"], "stream_scenario": s1m3s["scenario"],
    "invoke_node_order_channel": s1m3["node_order_channel"],
    "invoke_node_order": s1m3["node_execution_order"],
    "stream_node_order": s1m3s["node_execution_order"],
    "fields_compared": _cmp_keys,
    "field_agreement": _agree,
    "pool_size_invoke": len(s1m3_pool), "pool_size_stream": len(s1m3s_pool),
    "ranked_uid_order_invoke": [r["uid"] for r in s1m3["ranked_enzymes"]],
    "ranked_uid_order_stream": [r["uid"] for r in s1m3s["ranked_enzymes"]],
    "wrapper_forward_calls": [s1m3["wrapper_forward_calls_in_scenario"],
                              s1m3s["wrapper_forward_calls_in_scenario"]],
    "status": ("PASS" if all(v[2] for v in _agree.values()) else "DIFFERS")}
if RES["invoke_stream_equivalence"]["status"] != "PASS":
    gap("INVOKE_VS_STREAM", "invoke and stream on the same input did not agree on the final "
                            "state; the differing fields are listed in the record")
RES["smoke_records"].append({"smoke_record_id": "S1", "chain_scenario": s1m3["scenario"],
                             "prereg": SMOKE.get("S1"), "observed": {
        "substrate": s1m3["substrate_smiles"], "pool_route": s1m3["pool_route_used"],
        "pool_size": s1m3["pool_size"], "ranked": s1m3["ranked_enzymes"],
        "candidate_head": s1m3["candidate_reactions_head"][:1],
        "wrapper_forward_calls": s1m3["wrapper_forward_calls_in_scenario"],
        "fail_closed": s1m3["state_fail_closed"], "error": s1m3["state_error"]}})

# ------------------------------------------------------------------ 6. S1 m5 stream to terminal
s1m5 = run_scenario("SS1_CASE_B_M5_STREAM",
                    {"user_query": B_SUBSTRATE, "pipeline_mode": "m5"})
thread_m5 = s1m5["thread_id"]
vals_m5 = SH._g(compiled.get_state({"configurable": {"thread_id": thread_m5}}), "values", {}) or {}
RES["m5_checkpoint_keys"] = sorted((vals_m5 or {}).keys())
organism_candidates = SH._g(vals_m5, "organism_candidates") or []
RES["m5_organism_candidate_count"] = len(organism_candidates)

# 6a. the production trait node, fed by the real checkpointed state of this very run
trait_out = None
trait_floats = []
try:
    st_in = EnzymeCrewState(**vals_m5)
    t0 = time.monotonic()
    trait_out = trait_filter_node(st_in)
    RES["t5"]["trait_node"] = {
        "callable": "src.nodes.trait_filter_node.trait_filter_node",
        "input": "EnzymeCrewState rebuilt from compiled.get_state(thread=%s).values" % thread_m5,
        "wall_s": round(time.monotonic() - t0, 3),
        "trait_filter_passed": trait_out.get("trait_filter_passed"),
        "error": trait_out.get("error"), "fail_closed": trait_out.get("fail_closed"),
        "trait_record_count": len(trait_out.get("trait_records") or []),
        "node_evidence": SH.scrub(SH.ev_view(trait_out.get("evidence_chain"))[-1:], trait_floats),
        "uncertainty_flags": trait_out.get("uncertainty_flags")}
    ALL_FLOATS.extend(trait_floats)
except Exception:
    RES["t5"]["trait_node"] = {"raised": traceback.format_exc().splitlines()[-1][:300],
                               "traceback": traceback.format_exc()}
    prob("trait_node", "production trait node raised unexpectedly")

# 6b. the same production annotation function the node itself calls, to obtain the
#     HostTraitAnnotation objects (trait_records flatten uid/traits away)
annotations, anno_meta = None, None
try:
    annotations, anno_meta = build_trait_annotations(organism_candidates)
    node_ev = (RES["t5"].get("trait_node", {}).get("node_evidence") or [{}])
    node_data = (node_ev[0].get("data") if node_ev and isinstance(node_ev, list) else {}) or {}
    recomputed = {"observed_trait_count": sum(
        1 for a in annotations for ev in a.traits.values()
        if ev.trait_evidence_class == "OBSERVED"),
        "missing_trait_count": sum(1 for a in annotations for ev in a.traits.values()
                                   if ev.trait_evidence_class == "MISSING"),
        "identity_only_trait_count": sum(1 for a in annotations for ev in a.traits.values()
                                         if ev.trait_evidence_class == "IDENTITY_ONLY"),
        "unique_enzyme_uids": anno_meta.get("unique_enzyme_uids"),
        "mapped_uids": anno_meta.get("mapped_uids")}
    RES["t5"]["annotation_equivalence"] = {
        "why": ("trait_filter_node returns flattened TraitRecord rows; the route-step "
                "aggregator consumes HostTraitAnnotation, so the same production function the "
                "node calls (src.tools.trait_query.build_trait_annotations) is invoked on the "
                "same real organism_candidates and the two views are compared field by field"),
        "node_view": node_data, "annotation_view": recomputed,
        "agree": all(str(node_data.get(k)) == str(v) for k, v in recomputed.items()
                     if k in node_data),
        "asset_hashes": anno_meta.get("asset_hashes")}
    if RES["t5"]["annotation_equivalence"]["node_view"] and \
            not RES["t5"]["annotation_equivalence"]["agree"]:
        prob("annotation_equivalence", "node view and annotation view disagree")
except Exception:
    RES["t5"]["annotation_equivalence"] = {"raised": traceback.format_exc()[-600:]}
    prob("annotations", "build_trait_annotations raised")

# T6-R3-R2 minimal task-local repair A: the raw checkpoint stores RankedEnzyme pydantic
# objects which are not subscriptable (attempt-1 TypeError, base_run1_attempt1_stderr.log).
# s1m5["ranked_enzymes"] is the same real state read through SH.state_view/ranked_view.
# before: ranked_by_uid = {r["uid"]: r for r in (SH._g(vals_m5, "ranked_enzymes") or [])}
ranked_by_uid = {r["uid"]: r for r in s1m5["ranked_enzymes"]}


def step_annotations(task_id_pairs):
    """RouteStepHostAnnotation rows; every value comes from the real chain."""
    rows = []
    for ann in annotations or []:
        rk = ranked_by_uid.get(ann.enzyme_uid)
        for reaction_task_id, _ in task_id_pairs:
            rows.append(RouteStepHostAnnotation(
                reaction_task_id=reaction_task_id, enzyme_uid=ann.enzyme_uid,
                enzyme_rank=(rk["rank"] if rk else 1), source_signature=ann.source_signature,
                host_taxid=ann.host_taxid, host_name=ann.host_name,
                host_resolution=ann.host_resolution,
                host_taxonomy_group=ann.host_taxonomy_group,
                host_evidence_sources=list(ann.host_evidence_sources),
                traits=dict(ann.traits)))
    return rows


leg_ids_native = [(s1m5["reaction_task_id"] or "NONE_SINGLE_STEP_M5", "graph-native")]
RES["t5"]["leg_graph_native"] = {"reaction_task_ids": [i for i, _ in leg_ids_native],
                                 "annotation_rows": len(step_annotations(leg_ids_native))}
try:
    agg_native = aggregate_route(RouteAggregationInput(
        route_id=ROUTE_ID, ordered_reaction_task_ids=[i for i, _ in leg_ids_native],
        step_host_annotations=step_annotations(leg_ids_native)))
    RES["t5"]["leg_graph_native"]["result"] = {"aggregates": len(agg_native["aggregates"]),
                                               "unresolved": len(agg_native["unresolved_ledger"])}
except RouteAggregationError as exc:
    RES["t5"]["leg_graph_native"]["raised"] = {
        "type": "RouteAggregationError", "message": str(exc)[:400]}
    gap("T5_TASK_ID_SHAPE", "the fixed topology's own reaction_task_id cannot enter the T5 "
                            "route-step aggregator: %s" % str(exc)[:200])
except Exception:
    RES["t5"]["leg_graph_native"]["raised"] = {
        "type": "Exception", "message": traceback.format_exc().splitlines()[-1][:300]}

# bridge-produced ids (real graph output of SC3 below) are aggregated in the SC3 section.

# ------------------------------------------------------------------ 7. S2 (CASE_C) real invoke
s2 = run_scenario("SS2_CASE_C_M3_INVOKE",
                  {"user_query": C_SUBSTRATE, "pipeline_mode": "m3"})
RES["smoke_records"].append({"smoke_record_id": "S2", "chain_scenario": s2["scenario"],
                             "prereg": SMOKE.get("S2"), "input_source": {
        "frozen_smoke_row": "REAL_SMOKE_INPUTS.csv#S2",
        "c_fallback_probe_entry": RES["assets"]["c_fallback_probe"].get("s2_entry")}, "observed": {
        "substrate": s2["substrate_smiles"], "pool_route": s2["pool_route_used"],
        "pool_size": s2["pool_size"], "ranked": s2["ranked_enzymes"],
        "candidate_head": s2["candidate_reactions_head"][:1],
        "wrapper_forward_calls": s2["wrapper_forward_calls_in_scenario"],
        "fail_closed": s2["state_fail_closed"], "error": s2["state_error"],
        "missing_reaction_assets": (SH.wrapper_state()["last_trace"] or {}).get(
            "missing_reaction_assets")}})
if s2["state_fail_closed"]:
    say("S2 failed closed as the frozen asset audit predicted (recorded, no sample swap)")

# ------------------------------------------------------------------ 8. C2 real proxy forward
qual = [r for r in PROXY_ROWS if r.get("reaction_asset_status") == "FROZEN_PROXY"
        and r.get("evidence_type") == "PROXY_REACTION_RANKING" and r.get("proxy_reaction_smiles")]
first = qual[0] if qual else None
c2 = {"control": "C2_T3A_first_qualified_proxy", "status": "MISSING_INPUT"}
if first:
    fwd_row = next((r for r in PROXY_FWD
                    if r.get("reaction_task_id") == first["reaction_task_id"]), {})
    pool = list(fwd_row.get("pool") or [])
    call = client_call("C2_PROXY_" + first["reaction_task_id"], first["proxy_reaction_smiles"],
                       pool)
    c2.update({
        "mechanism": ("first qualified row of the SHA-pinned T3A PROXY_SELECTION_RESULTS.csv, "
                      "forwarded through the production client callable on the base package "
                      "root; the FROZEN_PROXY boundary is preserved and no staged score is "
                      "borrowed"),
        "input_identity": {"t3a_archive": RES["assets"]["t3a_archive"],
                           "proxy_member": RES["assets"]["t3a_proxy_member"],
                           "proxy_forward_member": RES["assets"]["t3a_proxy_forward_member"],
                           "row": first, "pool_from_archive": pool},
        "frozen_proxy_boundary": {"reaction_task_id": first["reaction_task_id"],
                                  "predicted_reaction": first["predicted_reaction"],
                                  "proxy_rhea_id": first["proxy_rhea_id"],
                                  "proxy_similarity": first["proxy_similarity"],
                                  "direction_mode": first["direction_mode"],
                                  "reaction_asset_status": first["reaction_asset_status"],
                                  "evidence_type": first["evidence_type"],
                                  "staged_score_borrowed": False,
                                  "identity_preserved": (
                                      first["reaction_asset_status"] == "FROZEN_PROXY"
                                      and first["evidence_type"] == "PROXY_REACTION_RANKING")},
        "forward": call,
        "status": ("PASS_REAL_PROXY_FORWARD" if call["forward_executed"]
                   else ("MISSING_REACTION_ASSET" if call["missing_reaction_assets"]
                         else "PROXY_RANKING_UNAVAILABLE"))})
    if call["raised"] and not call["missing_reaction_assets"]:
        prob("C2", "proxy forward raised unexpectedly: %s" % call["raised"])
RES["control_scenarios"].append(c2)

# ------------------------------------------------------------------ 9. C3 real bridge legs
# The frozen T2D route branches (two depth-2 tasks share one parent), and MultistepRouteInput
# is a linear reactant list, so the route is replayed as the two real linear legs it contains.
def leg_rows(reactants, branch_id):
    return MultistepRouteInput(route_id=ROUTE_ID, reactant_smiles=reactants,
                               reaction_source="retrieved", branch_id=branch_id)


LEGS = []
seen = {r["reaction_smiles"]: r for r in ROUTE_ROWS}
for a, b, c, bid in [(ROUTE_ROWS[0]["substrate_smiles"], ROUTE_ROWS[0]["product_smiles"],
                      ROUTE_ROWS[1]["product_smiles"], ROUTE_ROWS[1]["branch_id"]),
                     (ROUTE_ROWS[0]["substrate_smiles"], ROUTE_ROWS[0]["product_smiles"],
                      ROUTE_ROWS[2]["product_smiles"], ROUTE_ROWS[2]["branch_id"])]:
    r0 = seen.get("%s>>%s" % (a, b))
    r1 = seen.get("%s>>%s" % (b, c))
    if not (r0 and r1):
        prob("C3_leg", "leg edge not present in the frozen T2D rows")
        continue
    LEGS.append((leg_rows([a, b, c], bid), [r0, r1]))

c3_steps, c3_reattach, c3_bridge_ids = [], [], []
for li, (route, rows) in enumerate(LEGS):
    # T6-R3-R2 repair B: a lower-case-canonical SMILES fails the substrate node's
    # detect-SMILES regex (observed live for SC1 in attempt 1: orchestrator>substrate ->
    # LLM fail-closed), which would starve the bridge test.  Feed the Kekul'ised upper-
    # case serialisation of the SAME molecule; parse_substrate re-canonicalises it back to
    # route.reactant_smiles[0] byte-identically.  No science, topology or edge changed.
    _leg_q = Chem.MolToSmiles(Chem.MolFromSmiles(route.reactant_smiles[0]),
                             kekuleSmiles=True)
    assert Chem.MolToSmiles(Chem.MolFromSmiles(_leg_q)) == route.reactant_smiles[0]
    payload = {"user_query": _leg_q, "pipeline_mode": "m5",
               "multistep_route": route}
    rec = run_scenario("SC3_BRIDGE_LEG_%d" % li, payload, stop_node="enzyme_pool")
    br = rec["bridge_result"]
    if not br:
        prob("C3", "the bridge produced no steps for leg %d" % li)
        continue
    for si, step in enumerate(br["steps"]):
        uid_step = step["reaction_task_id"]
        c3_bridge_ids.append(uid_step)
        src_row = seen.get(step["reaction_smiles"])
        c3_reattach.append({"bridge_reaction_task_id": uid_step,
                            "bridge_step_reaction_smiles": step["reaction_smiles"],
                            "upstream_reaction_task_id": (src_row or {}).get("reaction_task_id"),
                            "matched_by": "reaction_smiles equality against the T2D member",
                            "reattached": bool(src_row)})
        # real single-step evidence for this step's substrate, under the base asset track
        step_pool = list(rec["enzyme_pool_final_ordered"]) if si == 0 else []
        call = client_call("SC3_STEP_%d_%d" % (li, si), step["reaction_smiles"], step_pool)
        c3_steps.append({"leg": li, "depth": step["depth"], "branch_id": step["branch_id"],
                         "bridge_reaction_task_id": uid_step,
                         "step_substrate": step["substrate_smiles"],
                         "step_reaction": step["reaction_smiles"],
                         "graph_pool_size_for_this_leg": len(step_pool),
                         "graph_pool_ordered_head": step_pool[:12],
                         "enzyme_match": call,
                         "upstream_asset_status": (src_row or {}).get(
                             "reaction_asset_status", {}).get("reaction_asset_status")
                         if isinstance((src_row or {}).get("reaction_asset_status"), dict)
                         else (src_row or {}).get("enzyme_match_status")})

# production re-attach over the real bridge steps: a step only carries enzymes its own
# reaction+pool produced, so UNMATCHED_ENZYME cannot borrow from a neighbour step.
bridge_for_match = []
for item in c3_steps:
    ok = item["enzyme_match"]["forward_executed"] is True
    bridge_for_match.append({
        "reaction_task_id": item["bridge_reaction_task_id"],
        "uids_if_matched": ([r["uid"] for r in item["enzyme_match"]["ranked"]] if ok else []),
        "forward_executed": ok})
step_enzymes = {b["reaction_task_id"]: b["uids_if_matched"] for b in bridge_for_match}
real_bridge = None
real_bridge_scenario = None
for li in range(len(LEGS)):
    br = RAW_VALS.get("SC3_BRIDGE_LEG_%d" % li, {}).get("bridge_result")
    if br is not None and getattr(br, "steps", None):
        real_bridge, real_bridge_scenario = br, "SC3_BRIDGE_LEG_%d" % li
        break
matched_view, c1b = None, {}
if real_bridge is not None:
    real_bridge = apply_step_enzyme_matches(real_bridge, step_enzymes)
    matched_view = [{"reaction_task_id": s.reaction_task_id, "depth": s.depth,
                     "branch_id": s.branch_id, "reaction_smiles": s.reaction_smiles,
                     "enzyme_match_status": s.enzyme_match_status,
                     "matched_enzyme_uids": list(s.matched_enzyme_uids)}
                    for s in real_bridge.steps]
c1b = {
    "control": "C1_case_recall_failure_fail_closed",
    "mechanism": ("per-step enzyme matching of the real T2D route steps through the production "
                  "client callable and the production apply_step_enzyme_matches; a step whose "
                  "reaction has no asset on this package root cannot borrow a neighbour's "
                  "enzyme (裁定 5)"),
    "input_identity": {"t2d_member": RES["assets"]["t2d_route_member"],
                       "bridge_result_object": ("the real MultistepBridgeResult left in the "
                                                "checkpoint of %s (type %s), not rebuilt by hand"
                                                % (real_bridge_scenario, type(real_bridge).__name__)),
                       "step_enzyme_inputs": bridge_for_match},
    "observed": {"steps": matched_view,
                 "unmatched": [m["reaction_task_id"] for m in (matched_view or [])
                               if m["enzyme_match_status"] == "UNMATCHED_ENZYME"],
                 "fabricated_uid": False,
                 "cross_step_borrow": any(
                     m["matched_enzyme_uids"] and m["enzyme_match_status"] == "UNMATCHED_ENZYME"
                     for m in (matched_view or []))},
    "status": ("PASS" if matched_view and all(
        (m["enzyme_match_status"] == "MATCHED") == bool(m["matched_enzyme_uids"])
        for m in matched_view) else "FAIL")}
RES["control_scenarios"].append(c1b)

# the T5 route-step aggregation over the *bridge-produced* ids and the real trait annotations
if c3_bridge_ids and annotations:
    pairs = [(bid, "bridge") for bid in c3_bridge_ids]
    try:
        agg = aggregate_route(RouteAggregationInput(
            route_id=ROUTE_ID, ordered_reaction_task_ids=c3_bridge_ids,
            step_host_annotations=step_annotations(pairs)))
        RES["t5"]["leg_bridge_ids"] = {"reaction_task_ids": c3_bridge_ids,
                                       "aggregates": len(agg["aggregates"])}
    except RouteAggregationError as exc:
        RES["t5"]["leg_bridge_ids"] = {"reaction_task_ids": c3_bridge_ids,
                                       "raised": {"type": "RouteAggregationError",
                                                  "message": str(exc)[:400]}}
        gap("T5_TASK_ID_SHAPE", "bridge-produced ids are rejected by the T5 aggregator: %s"
            % str(exc)[:200])

# T6-R3-R2 repair E: the frozen T2D typed re-attach is exactly the channel through which the
# route's steps enter the T5 route-step aggregator (native/bridge id formats were rejected by the
# production RT- guard above - recorded as gaps).  Same process, same real checkpoint-derived
# annotations; nothing hand-filled.
reattached_ids = []
for x in c3_reattach:
    rid = x["upstream_reaction_task_id"]
    if x["reattached"] and rid and rid not in reattached_ids:
        reattached_ids.append(rid)
if reattached_ids and annotations:
    _pairs = [(rid, "reattached") for rid in reattached_ids]
    try:
        _agg = aggregate_route(RouteAggregationInput(
            route_id=ROUTE_ID, ordered_reaction_task_ids=reattached_ids,
            step_host_annotations=step_annotations(_pairs)))
        RES["t5"]["leg_reattached"] = {
            "ordered_reaction_task_ids": reattached_ids,
            "annotation_rows": len(step_annotations(_pairs)),
            "aggregates": len(_agg["aggregates"]),
            "unresolved": len(_agg["unresolved_ledger"]),
            "status": "PASS_REAL_CONTINUOUS_IN_PROCESS"}
    except RouteAggregationError as exc:
        RES["t5"]["leg_reattached"] = {"reaction_task_ids": reattached_ids,
                                       "raised": {"type": "RouteAggregationError",
                                                  "message": str(exc)[:400]}}
        gap("T5_REATTACHED_REJECT", "reattached RT ids were also rejected: %s" % str(exc)[:200])

c3 = {"control": "C3_T2D_three_edge_route_via_fixed_bridge",
      "mechanism": ("the same real route is replayed through the teacher's multi_step_bridge "
                    "node in the real graph; steps are re-attached to the upstream T2D task ids "
                    "by reaction_smiles equality, and the coverage denominator is the frozen "
                    "T2D task count"),
      "input_identity": {"route_id": ROUTE_ID, "t2d_member": RES["assets"]["t2d_route_member"],
                         "legs": [[r.route_id, r.reactant_smiles, r.branch_id]
                                  for r, _ in LEGS]},
      "observed": {"bridge_step_ids": c3_reattach,
                   "total_route_step_count": len(ROUTE_ROWS),
                   "bridge_step_count": len(c3_steps),
                   "covered_by_upstream_task_ids": sum(
                       1 for x in c3_reattach if x["reattached"]),
                   "unmatched_steps": [x["reaction_task_id"] for x in (matched_view or [])
                                       if x["enzyme_match_status"] == "UNMATCHED_ENZYME"],
                   "per_step_asset_status": {x["bridge_reaction_task_id"]:
                                             x["upstream_asset_status"] for x in c3_steps}},
      "status": ("PASS" if c3_steps and len(c3_reattach) == len(c3_steps) else "INCOMPLETE")}
RES["control_scenarios"].append(c3)

# ------------------------------------------------------------------ 10. C8 -> T5 continuous
RES["t5"]["continuous_chain"] = {
    "chain": ("real graph m5 stream -> real enzymecage forward -> real microbe node "
              "(production map_enzyme_hosts + OrganismAggregator) -> real checkpointed state "
              "-> production trait_filter_node -> build_trait_annotations -> production "
              "aggregate_route, all in this one process on this one thread"),
    "thread_id": thread_m5, "process_id": os.getpid(),
    "organism_candidate_count": len(organism_candidates),
    "annotation_count": len(annotations or []),
    "separately_run_and_merged": False}
RES["counters"]["final"] = counters()
RES["audit"] = AUDIT.dump()
RES["audit"]["opened_path_count_all_events"] = sum(v["count"] for v in AUDIT.opened.values())
RES["utc_finished"] = SH.utc()
RES["exit_code_plan"] = 0 if not RES["problems"] else 1

OUT_JSON.write_text(json.dumps(RES, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
with OUT_SCORES.open("w", newline="", encoding="utf-8") as fh:
    w = _csv.writer(fh)
    w.writerow(["run_label", "track", "float_path", "repr_value"])
    for row in ALL_FLOATS:
        w.writerow([RUN_LABEL, "base"] + row)
say("PROBLEMS=%d gaps=%d scenarios=%d" % (len(RES["problems"]), len(RES["gaps"]),
                                          len(RES["scenarios"])))
sys.exit(RES["exit_code_plan"])
