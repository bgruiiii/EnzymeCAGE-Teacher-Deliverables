# BIOSYSMOdb150 G1审阅与G2-G6条件批量授权申请

> **READY_FOR_TEACHER_REVIEW：** G1-R3-R1已完成独立审计。发现的2条S4R1辅助解析错绑均未污染G1 occurrence/gold；root-cause分布已更新，详见第三节和R3-R1证据目录。

日期：2026-09-27  
提交人：学生侧  
请黄老师一次性裁决：G1内容处置 + G2-G6条件执行授权

## 一、这次请老师决定什么

本次不请老师逐个审批每一个工程步骤，而是申请一次完成两类批示：

1. 审核G1题库/gold处置建议，并签署G1内容裁决；
2. 在G1按批示完成、G2/G3离线门通过的前提下，条件批准连续执行G2-G6。

所有阶段仍保留硬门，任何门失败立即停止，不因批量授权而跳门。G7预算回签、G8正式全量和G9评分不包含在本次授权中。

## 二、G1已经完成的工作

原始150个case经过S4-R2和G1审计：

- 已隔离24个矛盾case：16个断链/方向未决、6个真实cycle、1个side permutation、1个compound身份未决；
- 当前formal候选为126个case；
- BSY-c14673全局问题映射到125个case、290次participant，0次位于计分主底物/主产物；
- 已冻结reaction、enzyme、organism、trait gold及证据定位；
- MetaTraits observed/predicted分开，F2/F3/F4已按minimum/optimum/maximum子字段审计；
- 四项反向mutation均被语义检查捕获；
- 未调用任何商业模型API。

独立验收：

    G1 validator：73454 / 73454 PASS
    mutation：4 / 4语义检测PASS
    G1-R3 SMILES恢复validator：354 / 354 PASS
    G1-R3-R1身份回溯validator：103 / 103 PASS

当前G1仍为READY_FOR_REVIEW，next_stage_allowed=false，尚未自签PASS。

## 三、G1-R3缺失SMILES回溯结果

对32个无SMILES compound逐个回到BIOSYSMOdb原始Reactions表核对participant列和Complete Name。R3-R1将根因修正为：

- SOURCE_DATA_MISSING_STRUCTURE：27个；
- EXTRACTION_OR_MAPPING_ERROR：2个（BSY-c18918、BSY-c18932）；
- NORMALIZED_NAME_VARIANT：1个（BSY-c18728）；
- EXTERNAL_NAME_ADAPTER_BUT_OCCURRENCE_CONSISTENT：2个（BSY-c18914、BSY-c18934）。

两条错绑只存在S4R1的compound-level辅助解析表：c18918被错写成dioxygen，c18932被错写成H2O；原始Reactions participant和G1 occurrence均正确，G1 canonical未污染。S4R1是冻结只读文件，本轮只记录后续adapter修复建议，不修改G1 gold。

- 公开检索14次，PubChem、ChEBI、KEGG均未找到可确证结构，MetaCyc页面受许可/账户墙限制；
- 0个结构候选被写入gold，canonical G1未修改。

分类结果：

- 23个只出现在被mask的currency/redox辅助位置，不进入主链SMILES分母，不影响case保留；
- 9个主链位置涉及5个case，原库无法提供唯一、可核验的结构：
  - BIOPATH150_040：nylon-6 polymer/linear oligomer；
  - BIOPATH150_115：4个苦味酸降解Meisenheimer中间体，无公开权威结构记录；
  - BIOPATH150_116：heparin；
  - BIOPATH150_117：dermatan sulfate；
  - BIOPATH150_118：heparan sulfate。

考虑主实验含10% SMILES结构分，且这些主链实体无法形成统一可复算结构gold，学生侧建议将上述5个case转入quarantine，不采用“名称答对但结构不可判”的例外规则。

## 四、请老师裁决的G1项目

### 1. 正式题目数量

学生建议：

    原150题
    - 原S4-R2/G1 quarantine 24题
    - 主链结构gold不可确定 5题
    = 正式主实验121题

- [ ] 同意：正式集冻结为121题，新增5题进入quarantine（推荐）
- [ ] 不同意：保留126题，对上述5题仅评分名称层，SMILES结构层记GOLD_UNAVAILABLE
- [ ] 其他：________________________________

### 2. BSY-c14673

- [ ] 同意程序结论：该问题只位于被mask辅助角色，不影响计分主链，相关其他case可保留（推荐）
- [ ] 不同意，需进一步隔离：________________________________

### 3. MetaTraits与C7_1映射

学生建议接受MetaTraits no_predictions作为observed来源；MetaTraits all中的预测记录只作背景，不进入observed准确率分母。接受C7_1 rerun2作为F1-F15映射输入。

- [ ] 同意（推荐）
- [ ] 不同意/修改：________________________________

### 4. 温度、pH、盐度范围

学生建议：

- minimum等于maximum且来源一致的标量进入精确准确率分母；
- minimum不等于maximum或多值记录保留审计，但暂不进入精确准确率分母；
- 不取中点，不用区间重叠替代精确匹配；
- optimum没有observed来源时，其准确率分母为空，但15项完整率分母不变。

- [ ] 同意（推荐）
- [ ] 范围端点均作为accepted exact values
- [ ] 其他：________________________________

### 5. F5保藏编号

模型只返回一个首选编号，gold保留同一菌株的全部本地可信编号；模型匹配任意一个accepted编号即算正确。gold无编号时不进入准确率分母，但非法编号、本地查无或错绑菌株记录为幻觉/错误。

- [ ] 同意（推荐）
- [ ] 不同意/修改：________________________________

### 6. quarantine探索实验

- [ ] 本阶段不运行quarantine子实验，先完成主实验（推荐）
- [ ] 后续另立预算运行，不进入主排名

## 五、申请一次性条件批准G2-G6

若老师同意上述G1处置，学生侧将先机械落实裁决、重建G1表和哈希，并以本文件的签署版本作为approval_source。只有G1重新验证通过后，才进入后续阶段。

### G2：生成题面并检查泄漏

- 按最终formal case生成统一中文题面和JSON空模板；
- 不向模型泄露gold步数、终产物、酶、菌、EC、数据库答案ID或SMILES；
- 扫描最终system/user messages，而不仅是case表；
- 固定随机种子抽ceil(10% × final_n)题进行人工题面审计；
- 任一未解释泄漏命中即停止，不能进入G3。

G2为离线阶段，商业API调用数为0。

### G3：冻结评分器

- 冻结步骤对齐、SMILES、酶菌、微生物身份、15项性状和证据校验规则；
- 使用全对、全错、部分正确三个手工mock验收；
- 额外验证null、overclaim、DATABASE_DIRECT lookup、分支隔离和额外JSON字段；
- 评分器hash冻结后才允许接触新的真实模型输出。

G3为离线阶段，商业API调用数为0。

### G4：搜索对称性探针

- 五个模型每个最多3条时效性探针；
- 最大调用数15；
- 五模型全部真实返回搜索metadata，主实验才允许enable_search=true；
- 任一模型不支持或静默忽略，则后续主实验五模型统一enable_search=false，不允许混用。

### G5：三题smoke

- 5模型 × 3题，共15次调用；
- 只检查请求发送、原始返回保存、JSON可解析和截断，不做正式科学排名；
- JSON有效必须15/15，否则停止，修复后不得在本次授权下自动重跑。

### G6：十题pilot

- 5模型 × 10题，共50次调用；
- JSON有效至少49/50；
- 截断率不高于10%；
- 每模型抽2题检查答案形态；
- 统计token、耗时、单case成本和并发参数；
- pilot不进入正式评分，任何门失败立即停止。

### 本次API授权上限

    G4最多15次
    G5固定15次
    G6固定50次
    合计最多80次新的商业模型API调用

本授权不包含失败后的自动重跑；不包含quarantine实验；不包含G8正式全量。

- [ ] 条件批准G2-G6，商业API硬上限80次（推荐）
- [ ] 只批准G2-G3离线准备
- [ ] 不批准/修改调用上限：________________________________

五个模型固定为：

    qwen3.8-flash
    qwen3.8-max
    deepseek-v4-pro-0813
    deepseek-v4.1-flash
    ZHIPU/GLM-5.3

## 六、硬停止条件

即使老师批准G2-G6，出现以下任一情况仍必须停止：

1. G1落实老师裁决后validator不全过；
2. G2出现未解释泄漏或case身份不唯一；
3. G3三个mock或最小变异门不全过；
4. G4执行异常未形成五模型对称结论；
5. G5 JSON有效率不是15/15；
6. G6不满足49/50、截断率或答案形态门；
7. 实际请求将超过80次；
8. prompt、schema、gold、评分器或模型参数发生未授权变化。

所有失败原始响应仍保留，不修理模型答案，不用第二个模型改写第一个模型的输出。

## 七、本次不申请的权限

本次明确不申请：

- G7全量预算回签；
- G8正式全量调用；
- G9正式评分和排名发布；
- quarantine子实验；
- 自由路线探索实验。

G6完成后提交token、耗时、价格和并发实测，黄老师只需再进行一次G7预算确认，之后才可能启动G8。若最终formal_n=121，则G8预计为5 × 121 = 605次正式调用，但实际预算必须以G6实测为准。

## 八、证据定位

G1执行根目录：

    25_BIOSYSMODB_TEACHER_ALIGNED_EXECUTION_2026-09-26/

关键证据：

    G1_gold/teacher_gold_review.md
    G1_gold/G1_gold.manifest.json
    G1_gold/G1_evidence.manifest.json
    G1_smiles_recovery/local_audit_report.md
    G1_smiles_recovery/local_audit_summary.json
    G1_smiles_recovery/source_registry.tsv
    G1_smiles_recovery_r1/identity_traceback.tsv
    G1_smiles_recovery_r1/identity_adapter_mismatches.tsv
    G1_smiles_recovery_r1/local_audit_report.md
    quarantine/cases.tsv
    gates/G1_gold.stage_gate.json

当前哈希：

    G1_inputs.content_manifest.json
    SHA256=b5b4d9dfaac4d3fc6f79d702a6f0a865940127ebbc09b673f52872aff61cc946

    G1_gold/G1_gold.manifest.json
    SHA256=54c3839b66158919b0f56b497c184b6faec550c5bd8e14765059ce61eb4ec455

    G1_gold/G1_evidence.manifest.json
    SHA256=45af8ea3a070e2060a3a673cced300196bf24b1d26511e7d5383b68dde475912

    G1_smiles_recovery/SHA256SUMS
    SHA256=b3a7e30a69a1ef071dca2a3f8bccba2e78a276a4601fcd69a3aeb6b075b24d9d

    G1_smiles_recovery_r1/SHA256SUMS
    SHA256=97967ecb4c2dd20e1a2d605fda4aab8c88eb817e612846daee25d45e9eae667a

## 九、老师一次性批示

请老师在上述选项中勾选或直接写修改意见。本文件经老师确认后的版本将计算SHA256，并作为G1内容裁决和G2-G6条件授权的唯一approval source。

老师姓名/签名：________________

批示日期：________________

补充意见：

____________________________________________________________

____________________________________________________________
