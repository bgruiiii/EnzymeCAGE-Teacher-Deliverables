# BIOSYSMOdb 150 条污染物完整降解路径 × 5 个大模型 API 基准主执行合同

日期：2026-09-23  
状态：`PLANNED_MASTER_CONTRACT_V1`  
执行分工：本地负责标准答案、审计与评分；Chenyu 负责筛选资产构建和 API 调度

## 0. 一句话路线

```text
冻结 BIOSYSMOdb 原始表
-> 筛出每一步均有酶和微生物证据的真实污染物降解路径
-> 人工/程序联合确认路径方向、连续性与去重
-> 冻结 150 条盲题和本地隐藏 gold
-> 5 个 API 做连接、并发、3 题 smoke、10 题 pilot
-> 5 个模型并行完成同一套 150 题
-> 本地按反应、酶、微生物、性状和证据逐项评分
```

本轮是一个单轨 benchmark：每个模型只回答 150 题一次，不再拆成“联网版”和“非联网版”两套。若某个官方 API 原生支持联网/检索，可作为该产品能力的一部分启用；必须记录是否请求、是否实际调用、工具调用与引用。最终结论只能表述为“API 产品模式能力比较”，不能偷换成纯基座模型能力比较。

## 1. 规模与最快耗时

正式规模：

```text
150 cases × 5 models = 750 model-case calls
```

按已观察到的单题耗时 `15 min 19 s = 919 s` 估算。五家 API 同时运行，且每家内部并发为 `c` 时：

```text
理论墙钟时间 = ceil(150 / c) × 919 s
```

| 每个 API 内部并发 | 理论墙钟时间 | 建议预留后的实际窗口 |
|---:|---:|---:|
| 1 | 38 小时 18 分 | 42–50 小时 |
| 2 | 19 小时 9 分 | 22–26 小时 |
| 3 | 12 小时 46 分 | 15–18 小时 |
| 5 | 7 小时 40 分 | 9–12 小时 |
| 10 | 3 小时 50 分 | 5–8 小时 |

实际总时长由最慢供应商决定，并受 RPM、TPM、并发连接、联网搜索、长回答、重试和服务波动影响。当前推荐目标为每家并发 `3–5`，不在未测限流前承诺并发 10。

Smoke 和 pilot 必须从最终 150 题中取子集。若模型版本、提示词、参数和工具模式均未改变且本地审计通过，其回答直接计入正式 150 题，不重复付费；若任何一项改变，只重跑受影响的模型/题目。

## 2. Authority 与已知容量

### 2.1 BIOSYSMOdb 本地来源

```text
00_Authority_Teacher_Plan/BIOSYSMOdb v2/
```

核心表：

```text
BIOSYSMOdb_Pathways_v1.0.csv
BIOSYSMOdb_Reactions_v1.0.csv
BIOSYSMOdb_Enzymes_v1.0.csv
BIOSYSMOdb_Organisms_v1.0.csv
BIOSYSMOdb_Compounds_chemical_info_v1.0.csv
BIOSYSMOdb_Compounds_chemical_iden_v1.0.csv
```

来源审计：

```text
04_Local_Review_Audits/BIOSYSMODB_V2_LOCAL_SCHEMA_SOURCE_AND_BENCHMARK_FEASIBILITY_AUDIT_2026-09-20.md
```

冻结 SHA256：

```text
Pathways=656688a703954550cc919fb60f75f3eb7da685d31e0c6bcf67a1f10076a3c05e
Reactions=43394879e02a6d4987baddce34b8c7879490fb26c30210a1c590bef0a817a847
Enzymes=dda287d19d2e9f0130da0acb4f63928515c69a5267687fa851bd399ff44b65af
Organisms=15410b327e87f636baa4806d66283d97cf498e273b15e40ea3a60d8137172f22
Compound info=2586ad50343bfe3c3a776e8390c791bb376801630f1d320dbc7f70b15b76d189
Compound identifiers=3875ad3e74afa69cff31d2fa0bc1f26529c4cc82983f5c9a8c4b6b7549ec2ab0
```

### 2.2 本地零模型容量预检

现有程序化初筛结果：

```text
Pathway 表中 Reactions included 非空                          1,061
其中所有引用 reaction ID 均可在 Reactions 表解析              1,021
每一步均可连接至少一个 enzyme                                 510
每一步均有具名 enzyme 且 enzyme 关联至少一个 organism          510
并且至少有一个 Pathway complete=TRUE 的 pathway-level organism 507
并且去重后路径长度为 3..15 步                                 267
267 条中至少一步 Sequence availability=TRUE                  250
267 条中每一步 Sequence availability=TRUE                     89
```

因此“逐步有酶和微生物”的原始容量足以支持 150 题。但 267 条中包含普通氨基酸、糖和中心代谢路径；在污染物范围审定完成前，禁止直接随机抽 150 条。

`Sequence availability=TRUE` 不是本次大模型路径问答的硬条件，因为本 benchmark 评分对象是酶名/EC 和微生物，不是特定蛋白 accession；该字段保留作分层信息。

## 3. 150 条路径的硬性入选条件

一条路径只有同时满足以下条件才可进入候选池：

```text
1. 去除重复 reaction ID 后含 3..15 个反应步骤；
2. 每个 reaction ID 均存在于 Reactions 表；
3. 每一步主要底物与主要产物均可解析到 compound；
4. 反应可按底物-产物连接成连续主链或有明确分支的有向图；
5. 每一步至少关联 1 个具名 enzyme；
6. 每一步至少关联 1 个具名 microorganism；
7. 至少有 1 条 Organisms 记录对该 pathway 标记 Pathway complete=TRUE；
8. 起始母体或路径有明确的污染物/外源物/环境污染物降解证据；
9. 不是普通生物合成、中心代谢或仅因某个中间体被标作 contaminant 而误收；
10. 主降解方向能够确定；数据库若用逆箭头表示，必须在 gold 中显式纠正并保留原始记录。
```

污染物身份不能只靠名称猜测。至少保留一种可核查依据：

```text
BIOSYSMO compound Source 含 Contaminant，且根化合物身份可解析；或
路径名称/来源数据库明确标记污染物降解；或
权威数据库/论文明确描述该化合物的环境降解路径。
```

若严格审定后不足 150 条，必须报告真实数量和缺口原因并停止，不得用普通代谢路径凑数。

## 4. 去重与多样性规则

### 4.1 去重

```text
同一 Unique Pathway ID 的重复记录只保留一份；
相同有向 reaction-ID 序列只保留一份；
同一根污染物的同义词、盐型和 ID 映射先归一；
高度重叠的 superpathway/subpathway 不得同时大量入选；
原则上每个根污染物保留 1 条主路径，确有好氧/厌氧或实质不同分支时最多 2 条并显式标注；
所有路径两两记录 reaction-step Jaccard 和起始化合物 identity。
```

### 4.2 多样性

最终 150 条应尽量覆盖：

```text
BTEX 与芳香溶剂
多环芳烃
卤代脂肪族/卤代芳香族
农药与除草剂
硝基芳烃与炸药相关物
药物和个人护理品
塑化剂、单体和塑料添加剂
染料与表面活性剂
有机磷/膦酸类
其他工业污染物
```

不得为满足类别数而降低第 3 节的硬条件。任何单一大类原则上不超过 45/150；若数据库真实容量导致超限，须在选择报告中解释。应同时报告好氧、厌氧、混合/未知路径数量和 3–5、6–10、11–15 步长度分布。

## 5. Gold 的最低结构

每条题目的隐藏 gold 至少包含：

```text
case_id
BIOSYSMO pathway ID/name
root pollutant identity, synonyms, structure IDs
aerobic/anaerobic status
ordered main-chain steps and explicit branches
for every step:
  reaction ID
  substrate/product BIOSYSMO IDs and accepted names
  degradative direction
  reaction type
  all accepted enzyme IDs/names/ECs
  all accepted step-level organisms and TaxIDs when available
pathway-level complete organisms
source IDs and evidence text
uncertainty/adjudication notes
```

不能像早期酶排序评分那样只保留一个答案。每一步所有数据库支持的酶名、EC 变体和微生物替代答案都必须进入 accepted set；模型命中任一合格答案即算该字段正确。

## 6. 微生物性状 gold

BIOSYSMO Organisms 表主要给名称、TaxID、基因组和完整路径标志，不能单独支撑全部形态性状。性状 gold 另建证据层：

```text
Gram stain
cell shape
spore formation
motility
oxygen relationship / terminal electron acceptor
typical habitat or growth environment
```

优先来源：现有 MetaTraits 资产、BacDive、DSMZ/ATCC 物种说明、NCBI/UniProt taxonomy 及可定位原文。禁止仅根据门/纲推断 Gram、芽孢或运动性。

每个性状事实必须标记：

```text
OBSERVED
CURATED_AUTHORITATIVE
IDENTITY_ONLY
NOT_OBSERVED
```

`NOT_OBSERVED` 不进入“答错”分母；模型若无证据编造具体性状，则计 hallucination。

## 7. 盲题与泄漏隔离

冻结两套物理分离的资产：

```text
PUBLIC_EXECUTION_PACKAGE:
  case_id、污染物题面、统一输出 schema、统一运行参数

LOCAL_HIDDEN_GOLD:
  pathway/reaction IDs、逐步答案、accepted sets、性状证据、评分规则
```

Chenyu API 调度目录只允许出现盲题，不得包含 hidden gold、BIOSYSMO pathway ID、参考反应顺序或标准酶/菌答案。盲题的提示词模板、系统提示、输出 schema、temperature、最大输出长度、工具模式在 5 个模型间保持一致；仅允许供应商 API 必需的协议差异。

## 8. API 密钥与配置安全

API key 只能从 Chenyu 机器的环境变量或权限为 `0600` 的本地 secrets 文件读取：

```text
不得写入 prompt
不得写入 models.yaml
不得提交 Git
不得写入日志、traceback、request dump 或回传压缩包
不得在报告中显示 key 的前缀或后缀
```

版本控制中的 `models.yaml` 只保存：

```text
anonymous_model_id
provider adapter
exact model/version
base URL name, not secret query parameters
environment variable name
tool/web mode
temperature/top_p/max tokens
timeout and concurrency limits
```

对外汇报时模型可去敏为 `Model-A` 至 `Model-E`；本地密封映射表单独保存。原始结果目录和压缩包创建前必须扫描常见 key 模式及实际 key 值，命中即阻断打包。

## 9. 单窗口 API 调度器要求

Chenyu 的一个执行窗口运行一个 Python 异步调度器，不让五个模型各自管理子智能体。逻辑单位始终是独立、可重放的 `(model_id, case_id)`。

建议入口：

```bash
python run_llm_benchmark.py \
  --models models.yaml \
  --cases blind_cases.jsonl \
  --output runs/<run_id> \
  --resume
```

必须实现：

```text
每个 provider 独立 semaphore
RPM/TPM token bucket 或供应商等价限流
连接/读取/总时长 timeout
429、5xx、网络中断的指数退避和 jitter
尊重 Retry-After
幂等的 model_id + case_id + prompt_sha256
原子写临时文件后 rename
断点续跑，只补失败/缺失项
全局任务可中断，不丢已完成回答
失败达到阈值时自动降并发，不无限重试
```

禁止让“子智能体汇总后只返回摘要”。必须保存每个 API 的原始响应和规范化正文，后续评分才可复核。

## 10. 每次调用必须记录的证据

```text
case_id
anonymous_model_id
provider and exact model/version in sealed manifest
prompt SHA256 and request-body SHA256
provider request ID
start, first-token, end timestamps
TTFT and wall time
input/output/reasoning tokens when exposed
HTTP status and terminal status
retry count and retry reasons
web/tool requested, supported, and actually used
tool calls and citations
raw provider response
normalized answer Markdown/JSON
finish reason and truncation flag
estimated/actual cost when available
```

缺少 first-token 但供应商不支持流式时间戳时，可记 `NOT_EXPOSED`，不得伪造为总时长。

## 11. 分阶段执行与硬门

### S0：冻结源文件和 schema

产出：源文件 inventory、SHA256、列名、行数、解析规则、运行环境。  
PASS：全部核心 SHA 与第 2 节一致，关键 ID 唯一性和外键检查通过。

### S1：完整性 census

产出：所有 pathway 的步数、缺 reaction/compound/enzyme/organism、complete-organism 状态及排除原因。  
PASS：逐项复算第 2.2 节容量；任何差异必须先解释，不能直接沿用 267。

### S2：污染物范围与路径图审定

产出：逐路径 `INCLUDE/EXCLUDE/REVIEW`、污染物证据、主链/分支图、方向纠正和重复簇。  
PASS：所有入选候选满足第 3 节，`REVIEW` 不得静默进入。

### S3：冻结 150 条

产出：`selected_150.tsv`、类别/氧条件/长度分布、重复矩阵、排除表和选择算法。  
PASS：恰好 150 个 case ID；若严格合格不足 150，按硬停止返回，不凑数。

### S4：构建逐步 reaction/enzyme/organism gold

产出：路径表、step 表、accepted enzyme 长表、accepted organism 长表、证据表。  
PASS：150/150 路径、100% 步骤同时有反应、酶和微生物 accepted set；主链连续性由程序检查并人工抽审。

### S5：构建性状 gold

产出：物种归一表、trait long table、证据 URL/文献定位、证据等级和缺失矩阵。  
PASS：所有已有事实可追溯；未知保持 `NOT_OBSERVED`，不得推断填充。

### S6：冻结盲题和评分器输入

产出：`blind_cases.jsonl`、统一 prompt、JSON schema、`hidden_gold`、SHA manifest。  
PASS：盲包扫描为零 gold 泄漏；本地用甲苯已审案例做评分器回归。

### S7：实现五供应商异步调度器

产出：脚本、adapter、无密钥配置模板、单元测试、resume 测试和输出 schema。  
PASS：mock API 下完成成功、429、5xx、timeout、断点续跑、原子写入及密钥扫描测试。

### S8：连接和并发探测

先用非计分短请求验证 5 个 key、endpoint、模型名和权限；再进入真实题。每家并发从 1 起，按 `1 -> 2 -> 3 -> 5` 提升，出现持续 429/timeout 即退回最近稳定值。

PASS：五家均能返回；确定每家独立的稳定并发、RPM/TPM、timeout 和重试策略。不得用一家供应商的限流值套给其他四家。

### S9：3 题 smoke

从最终 150 中固定选择短、中、长各 1 条，5 个模型共 15 个回答。可用每家并发 3 同时提交。

PASS：15/15 有完整原始响应；无鉴权错误、无 gold 泄漏、无静默截断；规范化和计时字段齐全。失败项可 resume 补齐，不重跑成功项。

### S10：10 题 pilot

固定覆盖不同污染物类别、氧条件和路径长度的 10 题，5 个模型共 50 个回答；测试目标并发 5 或各供应商在 S8 确定的上限。

PASS：50/50 终态成功；本地评分器能输出逐题正确反应/酶/菌/性状数；成本、耗时、引用和失败表完整。若改 prompt 或 schema，S9/S10 受影响结果作废后重跑。

### S11：150 × 5 全量

五家供应商并行，各自按稳定并发处理同一份 150 题。先复用已通过且配置完全相同的 S9/S10 项，再补齐其余项。

PASS：completion matrix 为 750/750；每项 request/response/timing 均存在且 SHA 可核。持续失败的项单列并暂停最终排名，不能把失败当零分。

### S12：本地独立评分与报告

Chenyu 只返回盲答和运行证据；本地加载 hidden gold 评分，形成逐题、逐模型、逐字段统计和 bootstrap 置信区间。

PASS：评分可从原始回答重放；机器评分争议项有人工盲审记录；报告明确产品模式、联网差异、失败率和证据边界。

## 12. 最终必须回答的统计问题

对每个模型，不能只给总分，必须给原始分子/分母：

```text
完整路径选择正确：x / 150
gold reaction steps 总数：N
化学转化正确：x / N
方向正确：x / N
酶名/功能正确：x / N
EC 正确或合格限定：x / N
每步至少一个正确微生物：x / N
完整路径代表菌正确：x / 150
可评分性状事实正确：x / T
性状错误：x / T
无证据编造性状：x 条
可核查引用支持：x / C
混入其他分支：x / 150
完整回答成功：x / 150
中位/P90 总时长、TTFT、tokens、成本、重试率
```

reaction、enzyme 和 organism 以步骤为单位分别评分。模型多报错误实体不能因同时报出一个正确实体而完全免责，另计 precision/unsupported claims。路径步骤数不同于 gold 时，先按标准化底物-产物和反应功能做一对一对齐，再统计漏步、错步和额外步；同义词由冻结 synonym 表处理，禁止评分时临时放宽某个模型。

## 13. 建议返回目录

```text
run_id/
  run_manifest.json
  source_inventory.tsv
  blind_cases.jsonl
  models/
    model_a/<case_id>/
      request.json
      response_raw.json
      answer.md
      timing.json
      tool_calls.json
  normalized/
    model_a.jsonl
    model_b.jsonl
    model_c.jsonl
    model_d.jsonl
    model_e.jsonl
  failures/
    failed_requests.jsonl
  summaries/
    completion_matrix.tsv
    timing_summary.tsv
    token_cost_summary.tsv
    concurrency_probe.tsv
  manifests/
    SHA256SUMS
```

本地隐藏目录另存，不进入 Chenyu 包：

```text
hidden_gold/
  pathway_gold.tsv
  step_gold.tsv
  accepted_enzymes.tsv
  accepted_organisms.tsv
  organism_traits.tsv
  evidence.tsv
  model_identity_sealed.tsv
```

## 14. 禁止事项

```text
禁止先发 750 个请求再发现 prompt/schema 错误；
禁止把 ordinary metabolism 填进 150 题凑数；
禁止只保留一个酶或一个菌作为唯一答案；
禁止把 Pathway complete organism 与 step-level organism 混为一类；
禁止依据高阶 taxonomy 猜微生物形态；
禁止让 API 看见 BIOSYSMO pathway ID 或 hidden gold；
禁止在某个模型回答后修改 gold 或同义词表；
禁止按“哪个结果更好看”选择是否联网、评分口径或报告子集；
禁止把失败/限流直接计为模型科学错误；
禁止在回传包中包含任何 API key。
```

## 15. 当前最近一步

先只执行 `S0 + S1`，产出可复算的全库完整性 census；本地审计 PASS 后再发 `S2 + S3` 的污染物审定和 150 条冻结提示词。此时不调用任何大模型 API，也不消耗正式 benchmark 配额。
