# G1 gold teacher review material (G1-R1 repaired)

- date: 2026-09-27 (G1-R1 trait sub-field + mutation repair over the 2026-09-26 candidate)
- builder: LOCAL_AI_G1_EXECUTOR (local implementation AI; no teacher authority)
- status: **READY_FOR_REVIEW** -- G1 becomes PASS only after the teacher's gold content audit; nothing in this build self-signs.

## 1. What was frozen

Inputs (read-only, hashed in `G1_inputs.manifest.json`): S4-R2 case status / pathway & step gold overlays / per-occurrence compound roles / the 26-row remaining-review queue; S4 accepted enzymes & step organisms & complete pathway organisms; S3 selected-150; BIOSYSMOdb source CSVs; MetaTraits species summaries; BacDive full closure 2478; the frozen C7_1 rerun2 long-form mapping.

## 2. Quarantine (teacher adjudication section 3)

- quarantined cases: **24 / 150 (16.0%)**, every one carrying an unresolved S4-R2 record reproduced verbatim in `quarantine/cases.tsv` (source locator included). Release requires a case-level teacher audit, never code.

- reason distribution: `{"UNRESOLVED_GRAPH_OR_DIRECTION": 16, "UNRESOLVED_CYCLE": 6, "DATA_CONTRADICTION_SIDE_PERMUTATION": 1, "UNRESOLVED_COMPOUND_IDENTITY": 1}`

- final_n is therefore **126** (not 150, and not preset: it is the count that survives quarantine).

## 3. The global BSY-c14673 ALL record

- mapped to **125 cases, 290 participant occurrences** (see `quarantine/global_issue_impact.tsv`); every occurrence is a masked currency / redox participant and **0 occurrences sit in a scored main substrate/product position**.

- program-level assessment: the contradiction (DB name 'Uranium(2+);dihydroxide' vs water-like reaction role) does not touch the scored main chain of any case, because the S4-R2 occurrence mask keeps it out of the main-chain gold. **This assessment needs teacher confirmation**: if the teacher judges the mapping itself unacceptable, the affected formal cases move to quarantine and final_n drops accordingly.

## 4. Trait gold status (teacher adjudication section 5)

- profile count: **834** (case-level organism profiles, strain variants NOT merged); 15-item summary scoreable cells: **5499**.

- per-item observed / predicted / unknown rows: `{"F1": {"observed_rows": 554, "predicted_rows": 488, "unknown_rows": 342, "scoreable_profile_traits": 455}, "F2": {"observed_rows": 1892, "predicted_rows": 1164, "unknown_rows": 331, "scoreable_profile_traits": 431}, "F3": {"observed_rows": 543, "predicted_rows": 1406, "unknown_rows": 345, "scoreable_profile_traits": 0}, "F4": {"observed_rows": 897, "predicted_rows": 1267, "unknown_rows": 345, "scoreable_profile_traits": 189}, "F5": {"observed_rows": 337, "predicted_rows": 0, "unknown_rows": 497, "scoreable_profile_traits": 337}, "F6": {"observed_rows": 863, "predicted_rows": 8274, "unknown_rows": 344, "scoreable_profile_traits": 275}, "F7": {"observed_rows": 2636, "predicted_rows": 16773, "unknown_rows": 342, "scoreable_profile_traits": 428}, "F8": {"observed_rows": 1835, "predicted_rows": 6060, "unknown_rows": 345, "scoreable_profile_traits": 393}, "F9": {"observed_rows": 6980, "predicted_rows": 3343, "unknown_rows": 350, "scoreable_profile_traits": 437}, "F10": {"observed_rows": 523, "predicted_rows": 19, "unknown_rows": 342, "scoreable_profile_traits": 457}, "F11": {"observed_rows": 534, "predicted_rows": 0, "unknown_rows": 355, "scoreable_profile_traits": 428}, "F12": {"observed_rows": 543, "predicted_rows": 482, "unknown_rows": 341, "scoreable_profile_traits": 490}, "F13": {"observed_rows": 383, "predicted_rows": 106, "unknown_rows": 345, "scoreable_profile_traits": 372}, "F14": {"observed_rows": 4217, "predicted_rows": 53, "unknown_rows": 27, "scoreable_profile_traits": 807}, "F15": {"observed_rows": 0, "predicted_rows": 121, "unknown_rows": 713, "scoreable_profile_traits": 0}}`

## 5. F2 / F3 / F4 numeric sub-field audit (G1-R1)

- the MetaTraits minimum/maximum columns are cross-database consensus bounds: **minimum == maximum means every contributing database reports the same number** (an exact observed scalar), minimum != maximum means the databases disagree (a range of reported values). The earlier build read only the `value` column and wrongly reported F3 as unscoreable; the sub-field audit now recomputes from the bound columns. **F3 is NOT an empty denominator**: it has unanimous scalars for minimum / maximum.

- **F2** observed source rows 1892; predicted-only profiles 332; adjudication rows `{"SCALAR_SCOREABLE": 240, "RANGE_REQUIRES_TEACHER_ADJUDICATION": 1952, "MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION": 82, "TEXT_NOT_NUMERIC": 361, "NO_USABLE_OBSERVED_VALUE": 0}`;
  per sub-field: `{"minimum_c": {"profiles_total": 834, "profiles_scoreable_scalar": 118, "profiles_pending_adjudication": 383}, "optimum_c": {"profiles_total": 834, "profiles_scoreable_scalar": 0, "profiles_pending_adjudication": 0}, "maximum_c": {"profiles_total": 834, "profiles_scoreable_scalar": 122, "profiles_pending_adjudication": 379}, "preference": {"profiles_total": 834, "profiles_scoreable_scalar": 0, "profiles_pending_adjudication": 0}}`

- **F3** observed source rows 543; predicted-only profiles 612; adjudication rows `{"SCALAR_SCOREABLE": 326, "RANGE_REQUIRES_TEACHER_ADJUDICATION": 363, "MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION": 0, "TEXT_NOT_NUMERIC": 0, "NO_USABLE_OBSERVED_VALUE": 0}`;
  per sub-field: `{"minimum": {"profiles_total": 834, "profiles_scoreable_scalar": 162, "profiles_pending_adjudication": 60}, "optimum": {"profiles_total": 834, "profiles_scoreable_scalar": 0, "profiles_pending_adjudication": 0}, "maximum": {"profiles_total": 834, "profiles_scoreable_scalar": 164, "profiles_pending_adjudication": 58}}`

- **F4** observed source rows 897; predicted-only profiles 465; adjudication rows `{"SCALAR_SCOREABLE": 339, "RANGE_REQUIRES_TEACHER_ADJUDICATION": 443, "MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION": 0, "TEXT_NOT_NUMERIC": 1121, "NO_USABLE_OBSERVED_VALUE": 0}`;
  per sub-field: `{"minimum": {"profiles_total": 834, "profiles_scoreable_scalar": 241, "profiles_pending_adjudication": 68}, "optimum": {"profiles_total": 834, "profiles_scoreable_scalar": 0, "profiles_pending_adjudication": 0}, "maximum": {"profiles_total": 834, "profiles_scoreable_scalar": 98, "profiles_pending_adjudication": 213}, "unit": {"profiles_total": 834, "profiles_scoreable_scalar": 0, "profiles_pending_adjudication": 0}, "category": {"profiles_total": 834, "profiles_scoreable_scalar": 0, "profiles_pending_adjudication": 0}}`

- authoritative accuracy denominator for F2/F3/F4 lives in `trait_subfield_scoreability_mask.tsv` (G3 must read this file, never the 15-item summary boolean). Current totals: scoreable sub-field cells **905**, pending-teacher-adjudication cells **1161** of 10008 cells.

- explicit mapping decisions (growth ranges, BacDive ranges, preference words) are in `trait_numeric_subfield_mapping.tsv` (trait_numeric_subfield_mapping_v1); every ambiguous mapping stays a teacher decision -- no midpoints, no endpoint promotion, no category-to-number inference, no predicted promotion.

- source coverage: MetaTraits observed taxids 183 / 305 profile taxids; BacDive closure 111 / 305.

- F15 habitat_generalism still has no observed local source (predicted background only); F14 genome size / GC partial; genome_size_bp has no local source.

## 6. Compound structures

- formal-case compounds without any SMILES in the frozen source: **32** (ids in counts.json; mostly blank-name carrier species like ferredoxins). Per teacher section 9.2 these are flagged here in G1 for排查, not silently dropped.

## 7. final_n decision for the teacher

- Option A: freeze **n=126** (降额, disclosed on the report front page).

- Option B: 补选 from **117 structurally eligible, currently unused candidates** (`G1_gold/supplementary_candidates.tsv`). Promotion requires the same scientific flow (S4 -> S4R1 -> S4R2 graph/role/audit pipeline) run on the new pathways plus teacher audit; this build promotes **0** candidates and final_n does not assume any.

- smoke=3题 / pilot=10题 need enough formal cases; at n=126 this holds.

## 8. Mutation evidence (G1-R1)

- four adversarial mutations (quarantine case reinserted / cross-case enzyme contamination / predicted trait promoted to observed / step organism deleted) are executed against temporary copies by `scripts/run_g1_mutation_tests.py`; the independent validator must fail each one through a SEMANTIC check (not a hash mismatch). Evidence: `G1_gold/mutation_validation_report.json`.

## 9. Open items the teacher must decide

1. Confirm the BSY-c14673 program-level no-main-impact assessment (or move the mapped cases to quarantine).

2. Choose Option A / Option B for final_n.

3. Confirm the C7_1 rerun2 DRAFT trait-name mapping as the frozen G3 input.

4. Confirm the F5 rule: model returns one best accession; gold holds every observed BacDive number (G3 freezes the matching rule).

5. **Confirm the F2/F3/F4 sub-field mapping** (`trait_numeric_subfield_mapping.tsv`): bound rows minimum/maximum -> minimum_c/maximum_c & pH/salinity minimum/maximum; growth ranges and BacDive temperature ranges kept as pending endpoints; preference / category words as text only.

6. **Decide the aggregated range records**: rows where contributing databases disagree (minimum != maximum) and multi-value BacDive strings are currently RANGE / MULTI_VALUE pending adjudication. Options: treat the endpoints as multiple accepted exact values, keep them non-scored, or supply another frozen rule. No midpoint is ever taken.

7. Confirm whether the 32 no-SMILES compound ids stay scoreable at the name layer only (SMILES layer then scores as miss for those steps).

8. The 24 quarantined cases remain available for the separate quarantine sub-run (same pipeline, separate budget) per teacher adjudication section 3.

## 10. Evidence-chain seal (G1-R2)

- frozen input manifest (historical, preserved byte-for-byte): `5845dd356c902064b8beebc7138a51f8d19b7b799e42d8a7a65c1ff24bc5b54b`

- stable input content manifest `b5b4d9dfaac4d3fc6f79d702a6f0a865940127ebbc09b673f52872aff61cc946` over 18 files (no utc / operator / machine paths; byte-identical across rebuilds; two-generation check in the builder, recompute check in the validator).

- historical relation: the historical manifest lists the same 18 files with identical sha256 values (program-verified); the two manifests are not byte-identical (the historical one carries generated_utc / operator / absolute paths); transition verified, not assumed.

- mutation evidence manifest `45af8ea3a070e2060a3a673cced300196bf24b1d26511e7d5383b68dde475912` binds the mutation report, the summary, the four logs and the three scripts (validate_g1_gold.py, run_g1_mutation_tests.py, build_g1_gold.py); the manifest never lists itself.

- SHA256SUMS covers the canonical gold data files only; the evidence manifest covers the validation evidence chain.


## 11. Gate

`gates/G1_gold.stage_gate.json` carries status READY_FOR_REVIEW with input/output manifest hashes; `next_stage_allowed=false` until the teacher signs the gold audit. G2 remains blocked.
