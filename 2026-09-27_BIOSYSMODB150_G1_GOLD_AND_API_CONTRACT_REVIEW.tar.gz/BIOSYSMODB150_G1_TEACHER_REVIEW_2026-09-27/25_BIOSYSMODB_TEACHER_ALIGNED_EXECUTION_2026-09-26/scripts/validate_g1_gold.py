#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_g1_gold.py -- independent recomputation of the G1 build.

Nothing here imports build_g1_gold.py: every number is recomputed from the
frozen inputs and compared against the shipped G1 artifacts. A mismatch is a
FAIL and a non-zero exit; there is no constant-PASS path.

Checks:
  1. input manifest hashes still match the files on disk (G1 invalidation trip-wire);
  2. quarantine set recomputed from the 26-row queue == quarantine/cases.tsv;
  3. formal set == ORDER_PASS minus quarantine == formal_cases.tsv;
  4. reaction_gold == per-occurrence roles of formal cases, every formal step
     covered, no BSY-c14673 main-position occurrence, currency rows preserved;
  5. enzyme/organism gold == filtered S4 tables, all formal steps covered;
  6. root/terminal identity and SMILES columns match the source overlay + CSV;
  7. trait_gold completeness (every profile x 15 items has >= 1 row) and the
     scoreability mask recomputed from value_status/value;
  8. counts.json recomputed;
  9. SHA256SUMS / gold manifest / stage gate integrity;
 10. supplementary candidates == structurally eligible minus selected, 0 promoted.
"""

import collections
import csv
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
STAGE = os.path.abspath(os.path.join(HERE, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
BENCH = os.path.join(TASK_ROOT, "23_BIOSYSMODB_150_PATHWAY_FIVE_LLM_API_BENCHMARK_2026-09-24")
S4R2 = os.path.join(BENCH, "S4R2_reviewed_gold")
S4G = os.path.join(BENCH, "S4_gold")
S3 = os.path.join(BENCH, "S3_selected_150")
S1 = os.path.join(BENCH, "S1_census")
G1 = os.path.join(STAGE, "G1_gold")
QUAR = os.path.join(STAGE, "quarantine")
GATES = os.path.join(STAGE, "gates")
COMPOUND_INFO_CSV = os.path.join(TASK_ROOT, "00_Authority_Teacher_Plan", "BIOSYSMOdb v2",
                                 "BIOSYSMOdb_Compounds_chemical_info_v1.0.csv")

TRAIT_IDS = ["F%d" % i for i in range(1, 16)]

# same rule as the builder: NA / No robust majority is not a usable value
EMPTY_VALUE_TOKENS = {"", "na", "n/a", "no robust majority"}

# Independent re-declaration of the sub-field target vocabulary (never imported
# from the builder): the validator must be able to catch a builder drift here.
SUBFIELD_TARGETS = {
    "F2": ("minimum_c", "optimum_c", "maximum_c", "preference"),
    "F3": ("minimum", "optimum", "maximum"),
    "F4": ("minimum", "optimum", "maximum", "unit", "category"),
}
SOURCE_STATUS_EXPECTED = {
    "METATRAITS_all": "PREDICTED",
    "METATRAITS_no_predictions": "OBSERVED",
    "BACDIVE": "OBSERVED",
    "BIOSYSMOdb_Organisms": "OBSERVED",
    "NCBI_TAXONOMY": "OBSERVED",
}

# mutation-evidence files live inside G1_gold but are validation output, not
# gold content; they are excluded from the SHA256SUMS coverage equality.
G1_EVIDENCE_FILES = {"mutation_validation_report.json",
                     "mutation_validation_summary.tsv",
                     "G1_evidence.manifest.json"}
G1_EVIDENCE_DIRS = {"mutation_logs"}


def is_empty_trait_value(value):
    return (value or "").strip().lower() in EMPTY_VALUE_TOKENS

FAILURES = []
CHECKS = 0


def check(name, ok, detail=""):
    global CHECKS
    CHECKS += 1
    if not ok:
        FAILURES.append({"check": name, "detail": str(detail)[:500]})
        print("  [FAIL] %s %s" % (name, detail))
    return ok


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def main(argv=None):
    import argparse
    global STAGE, G1, QUAR, GATES
    parser = argparse.ArgumentParser(description="independent G1 recomputation")
    parser.add_argument("--stage-root", default=STAGE,
                        help="the 25_* stage directory to validate (mutation tests "
                             "point this at a temporary mutated copy)")
    parser.add_argument("--report", default=None,
                        help="optional JSON report path "
                             "({overall, checks, failures})")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args(argv)
    STAGE = os.path.abspath(args.stage_root)
    G1 = os.path.join(STAGE, "G1_gold")
    QUAR = os.path.join(STAGE, "quarantine")
    GATES = os.path.join(STAGE, "gates")
    print("[1] input manifest integrity")
    manifest = json.load(open(os.path.join(STAGE, "G1_inputs.manifest.json"),
                              encoding="utf-8"))
    for entry in manifest["files"]:
        check("input_sha_%s" % entry["name"],
              os.path.isfile(entry["path"])
              and sha256_file(entry["path"]) == entry["sha256"],
              entry["path"])

    print("[2] quarantine recomputation")
    queue = read_tsv(os.path.join(S4R2, "S4R2_manual_review_queue_remaining.tsv"))
    case_status = read_tsv(os.path.join(S4R2, "S4R2_case_review_status.tsv"))
    quar_expected = set(r["case_id"] for r in queue
                        if r["case_id"] != "ALL" and r["case_id"])
    quar_rows = read_tsv(os.path.join(QUAR, "cases.tsv"))
    quar_actual = set(r["original_case_id"] for r in quar_rows)
    check("quarantine_set", quar_expected == quar_actual,
          "expected %d, got %d, diff %s" % (len(quar_expected), len(quar_actual),
                                            sorted(quar_expected ^ quar_actual)))
    for row in quar_rows:
        check("quarantine_release_condition_%s" % row["original_case_id"],
              "teacher" in (row.get("release_condition") or ""),
              "release condition must route to teacher audit")
        check("quarantine_reason_%s" % row["original_case_id"],
              bool((row.get("reason") or "").strip())
              and bool((row.get("source_locator") or "").strip())
              and bool((row.get("excluded_at") or "").strip())
              and bool((row.get("operator") or "").strip()),
              "contract-mandated columns must be non-empty")

    print("[3] formal set recomputation")
    formal_expected = set(r["case_id"] for r in case_status
                          if r["final_case_status"] == "ORDER_PASS")
    formal_rows = read_tsv(os.path.join(G1, "formal_cases.tsv"))
    formal_actual = set(r["case_id"] for r in formal_rows)
    check("formal_set", formal_expected == formal_actual,
          "expected %d got %d diff %s" % (len(formal_expected), len(formal_actual),
                                          sorted(formal_expected ^ formal_actual)))
    check("formal_quarantine_disjoint", not (formal_actual & quar_actual))
    check("formal_covers", len(formal_actual) + len(quar_actual) == len(case_status))

    print("[4] reaction gold recomputation")
    roles = read_tsv(os.path.join(S4R2, "S4R2_compound_role_by_occurrence.tsv"))
    steps = read_tsv(os.path.join(S4R2, "S4R2_step_gold_overlay.tsv"))
    steps_by_id = {r["step_occurrence_id"]: r for r in steps}
    expected_reaction = [r for r in roles if r["case_id"] in formal_actual]
    reaction_rows = read_tsv(os.path.join(G1, "reaction_gold.tsv"))
    check("reaction_row_count", len(reaction_rows) == len(expected_reaction),
          "expected %d got %d" % (len(expected_reaction), len(reaction_rows)))
    expected_keys = [(r["case_id"], r["participant_occurrence_id"]) for r in expected_reaction]
    actual_keys = []
    for r in reaction_rows:
        actual_keys.append((r["case_id"],
                            "%s::%s%s" % (r["step_occurrence_id"],
                                          r["participant_source_side"],
                                          r["participant_position"])))
    check("reaction_row_keys", sorted(expected_keys) == sorted(actual_keys),
          "participant occurrence identity mismatch")
    formal_steps = set(r["step_occurrence_id"] for r in steps
                       if r["case_id"] in formal_actual)
    gold_steps = set(r["step_occurrence_id"] for r in reaction_rows)
    check("reaction_step_coverage", formal_steps == gold_steps,
          "missing %s" % sorted(formal_steps - gold_steps)[:5])
    main_positions = [r for r in expected_reaction
                      if r["compound_id"] == "BSY-c14673"
                      and r["role_label"] in ("MAIN_SUBSTRATE", "MAIN_PRODUCT", "BYPRODUCT")]
    check("bsy_c14673_main_positions", len(main_positions) == 0)
    currency_kept = sum(1 for r in reaction_rows if r["s4r2_occurrence_mask"] == "TRUE")
    currency_expected = sum(1 for r in expected_reaction if r["s4r2_occurrence_mask"] == "TRUE")
    check("currency_rows_preserved", currency_kept == currency_expected,
          "expected %d masked rows, got %d" % (currency_expected, currency_kept))
    side_mismatch = 0
    for r in reaction_rows:
        if r["role_label"] in ("MAIN_SUBSTRATE", "MAIN_PRODUCT"):
            overlay_step = steps_by_id.get(r["step_occurrence_id"], {})
            side_ids = (overlay_step.get("gold_substrates") or "").split("|") \
                if r["participant_side"] == "SUBSTRATE" else \
                (overlay_step.get("gold_products") or "").split("|")
            if r["compound_id"] not in side_ids:
                side_mismatch += 1
    check("main_participant_side_consistency", side_mismatch == 0,
          "%d main participants sit on the wrong gold side" % side_mismatch)

    print("[5] enzyme / organism gold recomputation")
    enzymes = read_tsv(os.path.join(S4G, "accepted_enzymes.tsv"))
    step_orgs = read_tsv(os.path.join(S4G, "accepted_step_organisms.tsv"))
    complete_orgs = read_tsv(os.path.join(S4G, "complete_pathway_organisms.tsv"))
    enzyme_rows = read_tsv(os.path.join(G1, "enzyme_gold.tsv"))
    expected_enzymes = [r for r in enzymes if r["case_id"] in formal_actual]
    check("enzyme_row_count", len(enzyme_rows) == len(expected_enzymes),
          "expected %d got %d" % (len(expected_enzymes), len(enzyme_rows)))
    check("enzyme_step_coverage",
          set(r["step_occurrence_id"] for r in enzyme_rows) == formal_steps)
    organism_rows = read_tsv(os.path.join(G1, "organism_gold.tsv"))
    expected_step_orgs = [r for r in step_orgs if r["case_id"] in formal_actual]
    expected_complete = [r for r in complete_orgs if r["case_id"] in formal_actual]
    got_step = [r for r in organism_rows if r["scope"] == "STEP"]
    got_complete = [r for r in organism_rows if r["scope"] == "PATHWAY_COMPLETE"]
    check("organism_step_rows", len(got_step) == len(expected_step_orgs),
          "expected %d got %d" % (len(expected_step_orgs), len(got_step)))
    check("organism_complete_rows", len(got_complete) == len(expected_complete),
          "expected %d got %d" % (len(expected_complete), len(got_complete)))

    print("[5b] case/step foreign keys and per-step organism coverage (G1-R1)")
    fk_errors = []
    for table_name, table_rows in (("enzyme_gold", enzyme_rows),
                                   ("organism_gold_STEP", got_step),
                                   ("reaction_gold", reaction_rows)):
        for r in table_rows:
            case_id = r["case_id"]
            step_id = r.get("step_occurrence_id") or ""
            if not step_id.startswith(case_id + "__"):
                fk_errors.append((table_name, case_id, step_id))
            elif step_id not in formal_steps:
                fk_errors.append((table_name, case_id, step_id))
    check("enzyme_case_step_fk", not fk_errors,
          "%d rows whose step_occurrence_id does not belong to their case, e.g. %s"
          % (len(fk_errors), fk_errors[:3]))
    pathway_scope_leak = [r for r in got_complete
                          if (r.get("step_occurrence_id") or "").strip()]
    check("pathway_complete_rows_have_no_step_id", not pathway_scope_leak,
          "PATHWAY_COMPLETE rows must not carry step ids")
    steps_with_organism = set(r["step_occurrence_id"] for r in got_step)
    missing_organism_steps = sorted(formal_steps - steps_with_organism)
    check("step_organism_coverage_per_step", not missing_organism_steps,
          "%d formal steps without any step-level organism, e.g. %s"
          % (len(missing_organism_steps), missing_organism_steps[:5]))
    steps_with_enzyme = set(r["step_occurrence_id"] for r in enzyme_rows)
    check("step_enzyme_coverage_per_step",
          not (formal_steps - steps_with_enzyme))

    print("[6] root identity and SMILES")
    pathway_overlay = read_tsv(os.path.join(S4R2, "S4R2_pathway_gold_overlay.tsv"))
    root_rows = read_tsv(os.path.join(G1, "case_root_identity.tsv"))
    overlay_by_case = {r["case_id"]: r for r in pathway_overlay}
    check("root_identity_rows", len(root_rows) == len(formal_actual))
    csv.field_size_limit(1 << 27)
    needed = set()
    for row in root_rows:
        needed.update(c for c in row["root_compound_ids"].split("|") if c)
        needed.update(c for c in row["terminal_compound_ids"].split("|") if c)
    for r in reaction_rows:
        needed.add(r["compound_id"])
    compound_info = {}
    with open(COMPOUND_INFO_CSV, encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            cid = (row.get("BIOSYSMO ID") or "").strip()
            if cid in needed and cid not in compound_info:
                compound_info[cid] = row
    for row in root_rows:
        overlay = overlay_by_case.get(row["case_id"], {})
        check("root_ids_%s" % row["case_id"],
              row["root_compound_ids"] == overlay.get("root_compound_ids", "")
              and row["terminal_compound_ids"] == overlay.get("terminal_compound_ids", ""))
        root_ids = [c for c in row["root_compound_ids"].split("|") if c]
        expected_iso = "|".join((compound_info.get(c, {}).get("isosmiles") or "").strip()
                                for c in root_ids)
        check("root_smiles_%s" % row["case_id"], row["root_isosmiles"] == expected_iso)

    print("[7] trait gold and scoreability mask")
    trait_rows = read_tsv(os.path.join(G1, "trait_gold.tsv"))
    mask_rows = read_tsv(os.path.join(G1, "trait_scoreability_mask.tsv"))
    profiles = set((r["case_id"], r["ncbi_taxid"], r["organism_name"], r["organism_scope"])
                   for r in mask_rows)
    expected_cells = set((p[0], p[1], p[2], t) for p in profiles for t in TRAIT_IDS)
    got_cells = set((r["case_id"], r["ncbi_taxid"], r["organism_name"], r["trait_id"])
                    for r in mask_rows)
    check("trait_mask_cell_coverage", expected_cells == got_cells,
          "missing %d extra %d" % (len(expected_cells - got_cells),
                                   len(got_cells - expected_cells)))
    observed_recomputed = set()
    for r in trait_rows:
        if r["value_status"] == "OBSERVED" and not is_empty_trait_value(r["value"]):
            observed_recomputed.add((r["case_id"], r["ncbi_taxid"], r["organism_name"],
                                     r["trait_id"]))
    mask_scoreable = set((r["case_id"], r["ncbi_taxid"], r["organism_name"], r["trait_id"])
                         for r in mask_rows if r["scoreable"] == "TRUE")
    check("mask_matches_observed", observed_recomputed == mask_scoreable,
          "observed %d vs scoreable %d" % (len(observed_recomputed),
                                           len(mask_scoreable)))
    trait_cell_rows = set((r["case_id"], r["ncbi_taxid"], r["organism_name"], r["trait_id"])
                          for r in trait_rows)
    check("trait_rows_cover_mask", trait_cell_rows == got_cells)
    for r in trait_rows:
        check_status = r["value_status"]
        check("trait_status_vocab_%s" % check_status,
              check_status in ("OBSERVED", "PREDICTED", "UNKNOWN"))
        if check_status == "UNKNOWN":
            check("unknown_row_is_empty", not (r["value"] or "").strip()
                  and not (r["source_database"] or "").strip())

    print("[7b] trait source/status consistency (G1-R1)")
    status_mismatch = []
    for r in trait_rows:
        expected = SOURCE_STATUS_EXPECTED.get(r["source_database"])
        if expected and r["value_status"] != expected:
            status_mismatch.append((r["case_id"], r["ncbi_taxid"], r["trait_id"],
                                    r["source_database"], r["value_status"]))
    check("trait_source_status_consistency", not status_mismatch,
          "%d rows whose value_status disagrees with their source scope, e.g. %s"
          % (len(status_mismatch), status_mismatch[:3]))

    print("[7c] numeric sub-field mapping / audit / mask consistency (G1-R1)")
    mapping_rows = read_tsv(os.path.join(G1, "trait_numeric_subfield_mapping.tsv"))
    audit_rows = read_tsv(os.path.join(G1, "trait_numeric_subfield_audit.tsv"))
    subfield_mask = read_tsv(os.path.join(G1, "trait_subfield_scoreability_mask.tsv"))
    for m in mapping_rows:
        check("subfield_mapping_vocab_%s_%s" % (m["trait_id"], m["target_subfield"]),
              m["target_subfield"] in SUBFIELD_TARGETS.get(m["trait_id"], ())
              or "+" in m["target_subfield"]
              and all(t in SUBFIELD_TARGETS.get(m["trait_id"], ())
                      for t in m["target_subfield"].split("+")),
              "target outside the frozen vocabulary")
    # scalar / range classification recomputed from the raw columns
    import re as _re
    num_re = _re.compile(r"^-?\d+(?:\.\d+)?$")

    def num(text):
        text = (text or "").strip()
        return float(text) if num_re.match(text) else None

    bad_classification = []
    for r in audit_rows:
        field = r["source_field"]
        low = num(r["raw_minimum"])
        high = num(r["raw_maximum"])
        if r["target_subfield"] == "unit":
            expected = "TEXT_NOT_NUMERIC"
        elif r["source_database"] == "BACDIVE" and field == "temperature_range":
            tokens = [t.strip() for t in (r["raw_value"] or "").split(";") if t.strip()]
            expected = ("RANGE_REQUIRES_TEACHER_ADJUDICATION" if len(tokens) == 1
                        else "MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION")
        elif field.endswith(" growth"):
            expected = "RANGE_REQUIRES_TEACHER_ADJUDICATION"
        elif field.endswith(" preference"):
            expected = "TEXT_NOT_NUMERIC"
        elif field.endswith(" minimum") or field.endswith(" maximum"):
            if low is None and high is None:
                expected = "NO_USABLE_OBSERVED_VALUE"
            elif low is not None and high is not None and low == high:
                expected = "SCALAR_SCOREABLE"
            else:
                expected = "RANGE_REQUIRES_TEACHER_ADJUDICATION"
        else:
            expected = None
        if expected is not None and r["adjudication_status"] != expected:
            bad_classification.append((r["case_id"], r["trait_id"],
                                       r["target_subfield"], field,
                                       r["adjudication_status"], expected))
    check("subfield_classification_consistency", not bad_classification,
          "%d mis-classified audit rows, e.g. %s"
          % (len(bad_classification), bad_classification[:3]))

    # mask cell coverage: every profile x F2/F3/F4 x target sub-field
    expected_subfield_cells = set()
    mask_cells = set((r["case_id"], r["ncbi_taxid"], r["organism_name"],
                      r["organism_scope"], r["trait_id"], r["target_subfield"])
                     for r in subfield_mask)
    profile_keys = set((r["case_id"], r["ncbi_taxid"], r["organism_name"],
                        r["organism_scope"]) for r in subfield_mask)
    for pk in profile_keys:
        for trait_id in ("F2", "F3", "F4"):
            for target in SUBFIELD_TARGETS[trait_id]:
                expected_subfield_cells.add(pk + (trait_id, target))
    check("subfield_mask_cell_coverage", mask_cells == expected_subfield_cells,
          "expected %d cells, got %d" % (len(expected_subfield_cells),
                                         len(mask_cells)))

    # mask accepted scalars recomputed straight from trait_gold bound rows
    recomputed_scalars = collections.defaultdict(set)
    for r in trait_rows:
        if r["trait_id"] not in SUBFIELD_TARGETS or r["value_status"] != "OBSERVED":
            continue
        field = r["source_field"]
        if not (field.endswith(" minimum") or field.endswith(" maximum")):
            continue
        low, high = num(r["minimum"]), num(r["maximum"])
        if low is None or high is None or low != high:
            continue  # only unanimous rows produce scalars
        if field.endswith(" minimum"):
            target = "minimum_c" if r["trait_id"] == "F2" else "minimum"
        else:
            target = "maximum_c" if r["trait_id"] == "F2" else "maximum"
        value = ("%g" % low)
        recomputed_scalars[(r["case_id"], r["ncbi_taxid"], r["organism_name"],
                            r["organism_scope"], r["trait_id"], target)].add(value)
    bad_accepted = []
    for r in subfield_mask:
        key = (r["case_id"], r["ncbi_taxid"], r["organism_name"], r["organism_scope"],
               r["trait_id"], r["target_subfield"])
        got = [v for v in (r["accepted_gold_values"] or "").split("|") if v]
        expected = sorted(recomputed_scalars.get(key, set()))
        if sorted(got) != expected:
            bad_accepted.append((key, got, expected))
        if r["scoreable"] == "TRUE" and not got:
            bad_accepted.append((key, "scoreable without accepted values", ""))
        if r["scoreable"] == "FALSE" and got:
            bad_accepted.append((key, "accepted values but not scoreable", ""))
    check("subfield_mask_accepted_values", not bad_accepted,
          "%d cells disagree with the trait_gold bound rows, e.g. %s"
          % (len(bad_accepted), bad_accepted[:3]))
    # pending cells must never carry accepted values
    check("subfield_pending_never_scoreable",
          all(not (r["accepted_gold_values"] or "").strip()
              for r in subfield_mask
              if r["pending_teacher_adjudication"] == "TRUE"))

    # summary rollups recomputed from the sub-field mask
    summary_mask = read_tsv(os.path.join(G1, "trait_scoreability_mask.tsv"))
    rollup = collections.defaultdict(lambda: {"scoreable": 0, "pending": set()})
    for r in subfield_mask:
        key = (r["case_id"], r["ncbi_taxid"], r["organism_name"], r["trait_id"])
        if r["scoreable"] == "TRUE":
            rollup[key]["scoreable"] += 1
        if r["pending_teacher_adjudication"] == "TRUE":
            rollup[key]["pending"].add(r["target_subfield"])
    bad_rollup = []
    for r in summary_mask:
        key = (r["case_id"], r["ncbi_taxid"], r["organism_name"], r["trait_id"])
        stats = rollup.get(key, {"scoreable": 0, "pending": set()})
        if (int(r["scoreable_subfield_count"] or 0) != stats["scoreable"]
                or int(r["pending_adjudication_subfield_count"] or 0) != len(stats["pending"])
                or sorted((r["subfields_pending"] or "").split("|") if r["subfields_pending"] else [])
                != sorted(stats["pending"])):
            bad_rollup.append(key)
    check("summary_mask_subfield_rollup", not bad_rollup,
          "%d summary rows disagree with the sub-field mask" % len(bad_rollup))
    counts = json.load(open(os.path.join(G1, "counts.json"), encoding="utf-8"))
    counts_sub = counts.get("trait_numeric_subfield", {})
    check("counts_subfield_mask_rows",
          counts_sub.get("subfield_mask_rows_total") == len(subfield_mask))
    check("counts_subfield_scoreable",
          counts_sub.get("subfield_mask_scoreable_cells")
          == sum(1 for r in subfield_mask if r["scoreable"] == "TRUE"))
    check("counts_subfield_pending",
          counts_sub.get("subfield_mask_pending_cells")
          == sum(1 for r in subfield_mask
                 if r["pending_teacher_adjudication"] == "TRUE"))
    check("counts_subfield_audit_rows",
          counts_sub.get("audit_rows_total") == len(audit_rows))
    for trait_id in ("F2", "F3", "F4"):
        block = (counts_sub.get("per_trait") or {}).get(trait_id) or {}
        expected_rows = block.get("observed_source_rows")
        actual_rows = sum(1 for r in trait_rows
                          if r["trait_id"] == trait_id
                          and r["value_status"] == "OBSERVED")
        check("counts_subfield_observed_rows_%s" % trait_id,
              expected_rows == actual_rows,
              "counts.json %r vs trait_gold %d" % (expected_rows, actual_rows))

    print("[8] counts.json recomputation")
    recomputed = {
        "final_n": len(formal_actual),
        "quarantine_case_count": len(quar_actual),
        "step_occurrence_total": len(formal_steps),
        "participant_occurrence_rows": len(reaction_rows),
        "unique_directed_reactions": len(set(r["reaction_id"] for r in reaction_rows)),
        "enzyme_records": len(enzyme_rows),
        "unique_enzyme_ids": len(set(r["enzyme_id"] for r in enzyme_rows)),
        "step_organism_link_rows": len(got_step),
        "unique_taxids": len(set(r["taxid"] for r in got_step if r["taxid"])),
        "trait_profiles": len(profiles),
        "trait_scoreable_profile_traits": len(mask_scoreable),
        "supplementary_candidate_count": len(read_tsv(
            os.path.join(G1, "supplementary_candidates.tsv"))),
    }
    for key, value in recomputed.items():
        check("counts_%s" % key, counts.get(key) == value,
              "expected %r got %r" % (value, counts.get(key)))

    print("[8b] evidence-chain seal (G1-R2)")
    content_manifest_path = os.path.join(STAGE, "G1_inputs.content_manifest.json")
    check("content_manifest_exists", os.path.isfile(content_manifest_path),
          content_manifest_path)
    if os.path.isfile(content_manifest_path):
        # recompute the stable content manifest straight from the frozen inputs
        # (independent of the builder) and compare bytes: this proves both the
        # correctness and the run-to-run stability of the fingerprint
        entries = []
        for entry in sorted(manifest["files"], key=lambda e: e["name"]):
            p = entry["path"]
            entries.append({"name": entry["name"], "bytes": os.path.getsize(p),
                            "sha256": sha256_file(p)})
        recomputed = json.dumps(
            {"manifest_version": "G1_inputs_content_v1", "files": entries},
            ensure_ascii=False, indent=2) + "\n"
        shipped = open(content_manifest_path, encoding="utf-8").read()
        check("content_manifest_matches_inputs", shipped == recomputed,
              "content manifest differs from a fresh recomputation over the 18 "
              "frozen inputs")
        content_sha = sha256_file(content_manifest_path)
        gold_manifest_doc = json.load(open(os.path.join(G1, "G1_gold.manifest.json"),
                                           encoding="utf-8"))
        check("gold_manifest_binds_content_manifest",
              (gold_manifest_doc.get("input_content_manifest") or {}).get("sha256")
              == content_sha)
        gate_doc_cm = json.load(open(os.path.join(GATES, "G1_gold.stage_gate.json"),
                                     encoding="utf-8"))
        check("gate_binds_content_manifest",
              (gate_doc_cm.get("input_content_manifest") or {}).get("sha256")
              == content_sha)
        # the historical (legacy) input manifest must be preserved byte-for-byte
        # since the seal: its current sha must equal the sha the gold manifest
        # recorded at seal time
        check("historical_input_manifest_preserved",
              sha256_file(os.path.join(STAGE, "G1_inputs.manifest.json"))
              == gold_manifest_doc.get("input_manifest_sha256"),
              "the frozen input manifest drifted after the seal")

    evidence_manifest_path = os.path.join(G1, "G1_evidence.manifest.json")
    check("evidence_manifest_exists", os.path.isfile(evidence_manifest_path),
          evidence_manifest_path)
    if os.path.isfile(evidence_manifest_path):
        ev = json.load(open(evidence_manifest_path, encoding="utf-8"))
        entries = ev.get("files") or []
        check("evidence_manifest_self_not_listed",
              all(e["relpath"] != "G1_evidence.manifest.json" for e in entries))
        missing_entries = [e["relpath"] for e in entries
                           if not os.path.isfile(os.path.join(G1, e["relpath"]))]
        check("evidence_manifest_entries_exist", not missing_entries,
              "missing: %s" % missing_entries)
        bad_hashes = [e["relpath"] for e in entries
                      if os.path.isfile(os.path.normpath(os.path.join(G1, e["relpath"])))
                      and sha256_file(os.path.normpath(
                          os.path.join(G1, e["relpath"]))) != e["sha256"]]
        check("evidence_manifest_hashes_match", not bad_hashes,
              "hash mismatch: %s" % bad_hashes)
        script_count = sum(1 for e in entries if e["relpath"].startswith("../scripts/"))
        evidence_file_count = len(entries) - script_count
        check("evidence_manifest_covers_expected_set",
              script_count == 3 and evidence_file_count == 6,
              "expected 3 scripts + 6 evidence files, got %d+%d"
              % (script_count, evidence_file_count))
        report_doc = json.load(open(
            os.path.join(G1, "mutation_validation_report.json"), encoding="utf-8"))
        mutations = report_doc.get("mutations") or []
        detected = [m for m in mutations if m.get("detected")]
        check("evidence_manifest_mutation_count",
              len(mutations) == 4 and len(detected) == 4,
              "expected 4/4 detected mutations, got %d/%d"
              % (len(detected), len(mutations)))
        check("evidence_manifest_canonical_unchanged",
              report_doc.get("canonical_unchanged") is True)
        gold_manifest_doc2 = json.load(open(os.path.join(G1, "G1_gold.manifest.json"),
                                            encoding="utf-8"))
        check("gold_manifest_binds_evidence_manifest",
              (gold_manifest_doc2.get("evidence_manifest") or {}).get("sha256")
              == sha256_file(evidence_manifest_path))
        gate_doc = json.load(open(os.path.join(GATES, "G1_gold.stage_gate.json"),
                                  encoding="utf-8"))
        check("gate_binds_evidence_manifest",
              (gate_doc.get("evidence_manifest") or {}).get("sha256")
              == sha256_file(evidence_manifest_path))
        # SHA256SUMS scope must be explicit in the gold manifest
        with open(os.path.join(G1, "SHA256SUMS"), encoding="utf-8") as fh:
            sums_names = [line.rstrip("\n").split("  ", 1)[1]
                          for line in fh if line.strip()]
        scope = (gold_manifest_doc2.get("sha256sums_scope") or {}).get("covers") or []
        check("sha256sums_scope_declared", sorted(scope) == sorted(sums_names),
              "scope mismatch")

    print("[9] SHA256SUMS / gold manifest / stage gate")
    sums = {}
    with open(os.path.join(G1, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, name = line.rstrip("\n").split("  ", 1)
                sums[name] = digest
    listed = set(os.listdir(G1)) - {"SHA256SUMS", "G1_gold.manifest.json"} \
        - G1_EVIDENCE_FILES - G1_EVIDENCE_DIRS
    check("sha256sums_coverage", set(sums) == listed,
          "sums %s vs files %s" % (sorted(set(sums)), sorted(listed)))
    for name, digest in sums.items():
        check("sha256_%s" % name, sha256_file(os.path.join(G1, name)) == digest)
    gold_manifest = json.load(open(os.path.join(G1, "G1_gold.manifest.json"),
                                   encoding="utf-8"))
    for key, name in (("reaction_gold", "reaction_gold.tsv"),
                      ("enzyme_gold", "enzyme_gold.tsv"),
                      ("organism_gold", "organism_gold.tsv"),
                      ("trait_gold", "trait_gold.tsv")):
        check("manifest_hash_%s" % key,
              gold_manifest["hidden_gold_hashes"][key] == sums[name])
    check("manifest_input_sha", gold_manifest["input_manifest_sha256"]
          == sha256_file(os.path.join(STAGE, "G1_inputs.manifest.json")))
    gate = json.load(open(os.path.join(GATES, "G1_gold.stage_gate.json"),
                          encoding="utf-8"))
    check("gate_status", gate["status"] == "READY_FOR_REVIEW", gate["status"])
    check("gate_next_stage_allowed", gate["next_stage_allowed"] is False)
    check("gate_output_manifest_sha",
          gate["output_manifest"]["sha256"]
          == sha256_file(os.path.join(G1, "G1_gold.manifest.json")))
    check("gate_input_manifest_sha",
          gate["input_manifest"]["sha256"]
          == sha256_file(os.path.join(STAGE, "G1_inputs.manifest.json")))
    check("gate_counts_final_n", gate["counts"]["final_n"] == len(formal_actual))

    print("[10] supplementary candidates")
    selected = read_tsv(os.path.join(S3, "selected_150.tsv"))
    eligible = read_tsv(os.path.join(S1, "structurally_eligible_3_15.tsv"))
    expected_candidates = set(r["pathway_id"] for r in eligible
                              if r["pathway_id"] not in set(
                                  s["pathway_id"] for s in selected))
    supp = read_tsv(os.path.join(G1, "supplementary_candidates.tsv"))
    got_candidates = set(r["candidate_pathway_id"] for r in supp)
    check("supplementary_set", expected_candidates == got_candidates,
          "expected %d got %d" % (len(expected_candidates), len(got_candidates)))
    check("supplementary_none_promoted",
          all("NOT counted in final_n" in (r.get("status") or "") for r in supp))
    check("formal_n_excludes_candidates",
          counts["final_n"] == len(formal_actual))

    # TSV hygiene: no cell carries a tab or newline (round-trip safe)
    print("[11] TSV hygiene")
    for name in ("formal_cases.tsv", "case_root_identity.tsv", "reaction_gold.tsv",
                 "enzyme_gold.tsv", "organism_gold.tsv", "trait_gold.tsv",
                 "trait_scoreability_mask.tsv", "supplementary_candidates.tsv",
                 "trait_numeric_subfield_mapping.tsv",
                 "trait_numeric_subfield_audit.tsv",
                 "trait_subfield_scoreability_mask.tsv"):
        path = os.path.join(G1, name)
        with open(path, encoding="utf-8", newline="") as fh:
            header = fh.readline().rstrip("\n").split("\t")
            width = len(header)
            bad = 0
            for line in fh:
                if line.count("\t") != width - 1:
                    bad += 1
        check("tsv_width_%s" % name, bad == 0, "%d malformed lines" % bad)

    print()
    report = {
        "overall": "FAIL" if FAILURES else "PASS",
        "checks": CHECKS,
        "failures": FAILURES,
        "stage_root": STAGE,
    }
    if args.report:
        report_path = os.path.abspath(args.report)
        os.makedirs(os.path.dirname(report_path) or ".", exist_ok=True)
        with open(report_path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(report, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
    if FAILURES:
        print("G1 VALIDATION: FAIL (%d failures of %d checks)"
              % (len(FAILURES), CHECKS))
        for failure in FAILURES[:20]:
            print("  -", failure["check"], failure["detail"][:200])
        return 1
    print("G1 VALIDATION: PASS (%d checks, 0 failures)" % CHECKS)
    return 0


if __name__ == "__main__":
    sys.exit(main())
