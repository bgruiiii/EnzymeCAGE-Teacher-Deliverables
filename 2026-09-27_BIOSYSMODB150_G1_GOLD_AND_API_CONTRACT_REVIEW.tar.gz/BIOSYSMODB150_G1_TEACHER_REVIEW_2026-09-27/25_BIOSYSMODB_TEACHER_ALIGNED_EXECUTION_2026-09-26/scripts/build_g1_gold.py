#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_g1_gold.py -- G1: quarantine the contradicted cases, freeze the formal gold.

Authority:
  * TEACHER_ADJUDICATION_BIOSYSMODB150_FIVE_LLM_DESIGN_2026-09-26.md section 3
    (cycle / contradictory cases never enter the scored question bank) and
    section 5 (observed-gold trait denominators).
  * BIOSYSMODB150_API_ANSWER_COLLECTION_EXECUTION_PLAN_2026-09-26.md
    (TEACHER_ALIGNED_R1) section 6 (G1) and section 19 (stage layout).

Hard boundaries enforced here:
  * S4 / S4R1 / S4R2 and every other existing table is READ ONLY. All G1
    outputs land under 25_BIOSYSMODB_TEACHER_ALIGNED_EXECUTION_2026-09-26/.
  * No database contradiction is "resolved" by this script. Cases carrying an
    unresolved S4-R2 issue (real cycle, disconnected graph, side permutation,
    unresolved compound identity) are moved to quarantine VERBATIM with the
    source locator; only the teacher's content audit can release them.
  * The global BSY-c14673 ALL record is mapped to every affected case and
    participant -- it never silently disappears from per-case gates.
  * final_n is a RESULT of the quarantine mapping (not a preset target).
  * G1 never self-signs PASS: the stage gate ships as READY_FOR_REVIEW.

Inputs (frozen, read only):
  23_BIOSYSMODB_150_PATHWAY_FIVE_LLM_API_BENCHMARK_2026-09-24/
    S3_selected_150/selected_150.tsv
    S4R2_reviewed_gold/{S4R2_case_review_status,S4R2_pathway_gold_overlay,
                        S4R2_step_gold_overlay,S4R2_compound_role_by_occurrence,
                        S4R2_manual_review_queue_remaining,
                        S4R2_source_evidence,S4R2_order_edges_overlay}.tsv
    S4_gold/{accepted_enzymes,accepted_step_organisms,
             complete_pathway_organisms}.tsv
    S1_census/structurally_eligible_3_15.tsv
  00_Authority_Teacher_Plan/BIOSYSMOdb v2/BIOSYSMOdb_Compounds_chemical_info_v1.0.csv
  16_MetaTraits_Integration_Research_2026-07-15/01_Extracted/
    ncbi_species_summary_all.tsv, ncbi_species_summary_no_predictions.tsv
  16_.../bacdive_metatraits_hybrid_probe_2026-08-12/bacdive_full_closure_2478_2026-08-12/
    bacdive_full_closure_results.jsonl
  /tmp-extracted C7_1 rerun2 mapping CSV (copied to 25/authority/ on first run)

Outputs: see G1_DIR / QUAR_DIR / GATES_DIR below.
"""

import argparse
import collections
import csv
import datetime
import hashlib
import json
import os
import re
import shutil
import sys

TASK_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                         os.pardir, os.pardir))

BENCH = os.path.join(TASK_ROOT, "23_BIOSYSMODB_150_PATHWAY_FIVE_LLM_API_BENCHMARK_2026-09-24")
S4R2 = os.path.join(BENCH, "S4R2_reviewed_gold")
S4G = os.path.join(BENCH, "S4_gold")
S3 = os.path.join(BENCH, "S3_selected_150")
S1 = os.path.join(BENCH, "S1_census")
STAGE25 = os.path.join(TASK_ROOT, "25_BIOSYSMODB_TEACHER_ALIGNED_EXECUTION_2026-09-26")
G1_DIR = os.path.join(STAGE25, "G1_gold")
QUAR_DIR = os.path.join(STAGE25, "quarantine")
GATES_DIR = os.path.join(STAGE25, "gates")
AUTH_DIR = os.path.join(STAGE25, "authority")
INPUT_MANIFEST = os.path.join(STAGE25, "G1_inputs.manifest.json")

SOURCE_CSV_DIR = os.path.join(TASK_ROOT, "00_Authority_Teacher_Plan", "BIOSYSMOdb v2")
COMPOUND_INFO_CSV = os.path.join(SOURCE_CSV_DIR, "BIOSYSMOdb_Compounds_chemical_info_v1.0.csv")

METATRAITS_DIR = os.path.join(TASK_ROOT, "16_MetaTraits_Integration_Research_2026-07-15",
                              "01_Extracted")
METATRAITS_ALL = os.path.join(METATRAITS_DIR, "ncbi_species_summary_all.tsv")
METATRAITS_OBS = os.path.join(METATRAITS_DIR, "ncbi_species_summary_no_predictions.tsv")
BACDIVE_JSONL = os.path.join(
    TASK_ROOT, "16_MetaTraits_Integration_Research_2026-07-15",
    "bacdive_metatraits_hybrid_probe_2026-08-12",
    "bacdive_full_closure_2478_2026-08-12", "bacdive_full_closure_results.jsonl")
C7_1_MAPPING_TAR = os.path.join(
    TASK_ROOT, "03_HPC_Returned_Result_Summaries",
    "metatraits_c7_1_long_form_mapping_rerun2_false_positive_fix_20260819.tar.gz")
C7_1_MAPPING_MEMBER = ("metatraits_c7_1_long_form_mapping_rerun2_false_positive_fix_20260819/"
                       "C7_1_TRAIT_PANEL_METATRAITS_LONG_FORM_MAPPING_RERUN2.csv")
C7_1_MAPPING_LOCAL = os.path.join(AUTH_DIR, "C7_1_TRAIT_PANEL_METATRAITS_LONG_FORM_MAPPING_RERUN2.csv")

OPERATOR = "LOCAL_AI_G1_EXECUTOR"
RUN_TAG = "2026-09-26"

TRAIT_IDS = ["F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10",
             "F11", "F12", "F13", "F14", "F15"]

# A MetaTraits consensus of "NA" / "No robust majority" means the source had no
# usable value. Such rows are PRESERVED as audit material, but they never count
# as an observed value for the scoreability mask.
EMPTY_VALUE_TOKENS = {"", "na", "n/a", "no robust majority"}


def is_empty_trait_value(value):
    return (value or "").strip().lower() in EMPTY_VALUE_TOKENS


# ---------------------------------------------------------------------------
# G1-R1 repair A: F2/F3/F4 numeric sub-field audit (teacher min/opt/max rules)
# ---------------------------------------------------------------------------

# Versioned, explicit source_field -> target_subfield mapping. Nothing here is
# inferred from string similarity alone: every row carries its authority
# locator, and every ambiguous mapping stays a teacher decision (never a
# silent endpoint promotion, never a midpoint, never a category -> number).
SUBFIELD_MAPPING_VERSION = "trait_numeric_subfield_mapping_v1"
SUBFIELD_MAPPING = [
    # F2 temperature (unit Celsius)
    {"trait_id": "F2", "source_field_pattern": "trait_name=temperature minimum",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "minimum_c",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "minimum==maximum (both numeric) -> unanimous scalar; "
                        "minimum!=maximum -> cross-database disagreement range",
     "ambiguity_policy": "unanimous -> SCALAR_SCOREABLE; disagreement -> "
                         "RANGE_REQUIRES_TEACHER_ADJUDICATION (both endpoints kept)",
     "authority_locator": "C7_1 rerun2 F2 (group_2=Temperature); MetaTraits long-form "
                          "field label; consensus minimum/maximum column semantics"},
    {"trait_id": "F2", "source_field_pattern": "trait_name=temperature maximum",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "maximum_c",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "same as temperature minimum",
     "ambiguity_policy": "same as temperature minimum",
     "authority_locator": "C7_1 rerun2 F2 (group_2=Temperature)"},
    {"trait_id": "F2", "source_field_pattern": "trait_name=temperature growth",
     "source_database": "METATRAITS_no_predictions",
     "target_subfield": "minimum_c+maximum_c",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "preserve both endpoints verbatim",
     "ambiguity_policy": "ALWAYS RANGE_REQUIRES_TEACHER_ADJUDICATION: a growth range is "
                         "not automatically a physiological tolerance bound; mapping "
                         "growth endpoints (or a unanimous growth value) onto "
                         "minimum_c/maximum_c/optimum_c is a teacher decision",
     "authority_locator": "teacher adjudication section 5 (statistical min/max is not "
                          "the biological tolerance limit); C7_1 rerun2 F2"},
    {"trait_id": "F2", "source_field_pattern": "trait_name=temperature preference",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "preference",
     "source_value_columns": "value", "value_status_required": "OBSERVED",
     "conversion_rule": "keep the category word verbatim",
     "ambiguity_policy": "TEXT_NOT_NUMERIC: category words (mesophilic etc.) never "
                         "infer a number and never enter the numeric denominator",
     "authority_locator": "teacher adjudication section 5 (no category -> value "
                          "inference); C7_1 rerun2 F2"},
    {"trait_id": "F2", "source_field_pattern": "BACDIVE:temperature_range",
     "source_database": "BACDIVE", "target_subfield": "minimum_c+maximum_c",
     "source_value_columns": "value", "value_status_required": "OBSERVED",
     "conversion_rule": "split ';' tokens; 'a-b' -> endpoints (a,b); single numeric "
                        "token n -> endpoints (n,n); multi-token -> all tokens kept "
                        "in raw_value, endpoints empty",
     "ambiguity_policy": "ALWAYS RANGE/MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION: the "
                         "BacDive field is a growth-temperature range, not a "
                         "physiological bound; no endpoint is auto-promoted",
     "authority_locator": "BacDive closure trait_summary field label; teacher "
                          "adjudication section 5"},
    {"trait_id": "F2", "source_field_pattern": "BACDIVE:temperature_optimum",
     "source_database": "BACDIVE", "target_subfield": "optimum_c",
     "source_value_columns": "value", "value_status_required": "OBSERVED",
     "conversion_rule": "single numeric token -> scalar",
     "ambiguity_policy": "SCALAR_SCOREABLE (the field is literally an optimum)",
     "authority_locator": "BacDive closure trait_summary field label"},
    # F3 pH (unit pH)
    {"trait_id": "F3", "source_field_pattern": "trait_name=pH minimum",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "minimum",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "minimum==maximum (both numeric) -> unanimous scalar; "
                        "otherwise disagreement range",
     "ambiguity_policy": "unanimous -> SCALAR_SCOREABLE; disagreement -> "
                         "RANGE_REQUIRES_TEACHER_ADJUDICATION",
     "authority_locator": "C7_1 rerun2 F3 (group_2=pH)"},
    {"trait_id": "F3", "source_field_pattern": "trait_name=pH maximum",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "maximum",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "same as pH minimum",
     "ambiguity_policy": "same as pH minimum",
     "authority_locator": "C7_1 rerun2 F3"},
    {"trait_id": "F3", "source_field_pattern": "trait_name=pH growth",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "minimum+maximum",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "preserve both endpoints verbatim",
     "ambiguity_policy": "ALWAYS RANGE_REQUIRES_TEACHER_ADJUDICATION (growth range is "
                         "not a physiological bound)",
     "authority_locator": "teacher adjudication section 5; C7_1 rerun2 F3"},
    # F4 salinity (units '% NaCl (w/v)' / 'factor')
    {"trait_id": "F4", "source_field_pattern": "trait_name=salinity minimum",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "minimum",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "minimum==maximum (both numeric) -> unanimous scalar; "
                        "otherwise disagreement range",
     "ambiguity_policy": "unanimous -> SCALAR_SCOREABLE; disagreement -> "
                         "RANGE_REQUIRES_TEACHER_ADJUDICATION",
     "authority_locator": "C7_1 rerun2 F4 (group_2=Salinity)"},
    {"trait_id": "F4", "source_field_pattern": "trait_name=salinity maximum",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "maximum",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "same as salinity minimum",
     "ambiguity_policy": "same as salinity minimum",
     "authority_locator": "C7_1 rerun2 F4"},
    {"trait_id": "F4", "source_field_pattern": "trait_name=salinity growth",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "minimum+maximum",
     "source_value_columns": "minimum,maximum", "value_status_required": "OBSERVED",
     "conversion_rule": "preserve both endpoints verbatim",
     "ambiguity_policy": "ALWAYS RANGE_REQUIRES_TEACHER_ADJUDICATION (growth range is "
                         "not a physiological bound)",
     "authority_locator": "teacher adjudication section 5; C7_1 rerun2 F4"},
    {"trait_id": "F4", "source_field_pattern": "trait_name=salinity preference",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "category",
     "source_value_columns": "value", "value_status_required": "OBSERVED",
     "conversion_rule": "keep the category word verbatim",
     "ambiguity_policy": "TEXT_NOT_NUMERIC: category words (halophile etc.) never "
                         "infer a number",
     "authority_locator": "teacher adjudication section 5; C7_1 rerun2 F4"},
    {"trait_id": "F4", "source_field_pattern": "OBSERVED_UNIT_COLUMN",
     "source_database": "METATRAITS_no_predictions", "target_subfield": "unit",
     "source_value_columns": "unit", "value_status_required": "OBSERVED",
     "conversion_rule": "keep the unit string verbatim",
     "ambiguity_policy": "TEXT_NOT_NUMERIC: completeness material only",
     "authority_locator": "MetaTraits unit column semantics"},
]

SUBFIELD_TARGETS = {
    "F2": ("minimum_c", "optimum_c", "maximum_c", "preference"),
    "F3": ("minimum", "optimum", "maximum"),
    "F4": ("minimum", "optimum", "maximum", "unit", "category"),
}

_NUMERIC_RE = re.compile(r"^-?\d+(?:\.\d+)?$")


def _num(text):
    text = (text or "").strip()
    return float(text) if _NUMERIC_RE.match(text) else None


def _fmt(value):
    if value is None:
        return ""
    if float(value).is_integer():
        return str(int(value))
    return repr(value) if not isinstance(value, float) else ("%g" % value)


def parse_bacdive_range_tokens(raw_value):
    """Split a BacDive range string into (endpoints, token_count)."""
    tokens = [t.strip() for t in (raw_value or "").split(";") if t.strip()]
    if len(tokens) == 1:
        m = re.match(r"^(-?\d+(?:\.\d+)?)\s*[-–]\s*(-?\d+(?:\.\d+)?)$", tokens[0])
        if m:
            return (float(m.group(1)), float(m.group(2))), 1
        single = _num(tokens[0])
        if single is not None:
            return (single, single), 1
        return None, 1
    if len(tokens) == 2:
        a, b = _num(tokens[0]), _num(tokens[1])
        if a is not None and b is not None:
            return (a, b), 2
    return None, len(tokens)


def build_numeric_subfield_audit(trait_rows):
    """F2/F3/F4 observed rows -> per-target-subfield audit rows.

    Status vocabulary (explicit, never silent):
      SCALAR_SCOREABLE                        -- unanimous sourced scalar
      RANGE_REQUIRES_TEACHER_ADJADICATION  -> see constant below
      MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION
      TEXT_NOT_NUMERIC
      NO_USABLE_OBSERVED_VALUE
    Predicted rows are never promoted; range endpoints are never mid-pointed.
    """
    status_range = "RANGE_REQUIRES_TEACHER_ADJUDICATION"
    status_multi = "MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION"
    audit_rows = []
    for row in trait_rows:
        trait_id = row["trait_id"]
        if trait_id not in SUBFIELD_TARGETS:
            continue
        if row["value_status"] != "OBSERVED":
            continue
        field = row["source_field"]
        database = row["source_database"]
        base = {
            "case_id": row["case_id"], "ncbi_taxid": row["ncbi_taxid"],
            "organism_name": row["organism_name"],
            "organism_scope": row["organism_scope"],
            "trait_id": trait_id, "source_database": database,
            "source_record": row["source_record"], "source_field": field,
            "unit": row.get("unit", ""), "value_status": "OBSERVED",
        }
        if database == "BACDIVE" and field == "temperature_range":
            endpoints, token_count = parse_bacdive_range_tokens(row.get("value"))
            status = status_range if token_count == 1 else status_multi
            for target in ("minimum_c", "maximum_c"):
                audit_rows.append(dict(base, target_subfield=target,
                    raw_value=row.get("value", ""),
                    raw_minimum=_fmt(endpoints[0]) if endpoints else "",
                    raw_maximum=_fmt(endpoints[1]) if endpoints else "",
                    adjudication_status=status,
                    scoreable_scalar="FALSE",
                    reason=("BacDive growth-temperature range (%s); endpoints kept "
                            "verbatim; mapping onto minimum_c/maximum_c/optimum_c is "
                            "a teacher decision" % ("single value" if token_count == 1
                                                    else "%d tokens" % token_count))))
            continue
        if database == "BACDIVE" and field == "temperature_optimum":
            value = _num(row.get("value"))
            audit_rows.append(dict(base, target_subfield="optimum_c",
                raw_value=row.get("value", ""), raw_minimum="", raw_maximum="",
                adjudication_status="SCALAR_SCOREABLE" if value is not None
                                    else "NO_USABLE_OBSERVED_VALUE",
                scoreable_scalar="TRUE" if value is not None else "FALSE",
                reason="BacDive temperature_optimum"))
            continue
        # F4 unit material: one audit row per observed F4 row that carries a unit
        if trait_id == "F4" and database == "METATRAITS_no_predictions" \
                and (row.get("unit") or "").strip() \
                and field in ("trait_name=salinity minimum",
                              "trait_name=salinity maximum",
                              "trait_name=salinity growth",
                              "trait_name=salinity preference"):
            audit_rows.append(dict(base, target_subfield="unit",
                raw_value=(row.get("unit") or "").strip(),
                raw_minimum="", raw_maximum="",
                adjudication_status="TEXT_NOT_NUMERIC", scoreable_scalar="FALSE",
                reason="observed unit string from the source row"))
        if field in ("trait_name=temperature preference", "trait_name=salinity preference"):
            target = "preference" if trait_id == "F2" else "category"
            value = (row.get("value") or "").strip()
            audit_rows.append(dict(base, target_subfield=target,
                raw_value=value, raw_minimum="", raw_maximum="",
                adjudication_status="TEXT_NOT_NUMERIC", scoreable_scalar="FALSE",
                reason="category word; never converted to a number"))
            continue
        if field.endswith(" growth"):
            targets = SUBFIELD_TARGETS[trait_id]
            low, high = ("minimum_c", "maximum_c") if trait_id == "F2" \
                else ("minimum", "maximum")
            for target in (low, high):
                audit_rows.append(dict(base, target_subfield=target,
                    raw_value=row.get("value", ""),
                    raw_minimum=(row.get("minimum") or "").strip(),
                    raw_maximum=(row.get("maximum") or "").strip(),
                    adjudication_status=status_range, scoreable_scalar="FALSE",
                    reason="growth range endpoints; not auto-promoted to "
                           "physiological bounds (teacher decision)"))
            continue
        if field.endswith(" minimum") or field.endswith(" maximum"):
            target = ("minimum_c" if field.endswith(" minimum") else "maximum_c") \
                if trait_id == "F2" else \
                ("minimum" if field.endswith(" minimum") else "maximum")
            low = _num(row.get("minimum"))
            high = _num(row.get("maximum"))
            if low is None and high is None:
                audit_rows.append(dict(base, target_subfield=target,
                    raw_value=row.get("value", ""), raw_minimum=row.get("minimum", ""),
                    raw_maximum=row.get("maximum", ""),
                    adjudication_status="NO_USABLE_OBSERVED_VALUE",
                    scoreable_scalar="FALSE",
                    reason="no numeric bound in the source row"))
            elif low is not None and high is not None and low == high:
                audit_rows.append(dict(base, target_subfield=target,
                    raw_value=_fmt(low), raw_minimum=_fmt(low), raw_maximum=_fmt(high),
                    adjudication_status="SCALAR_SCOREABLE", scoreable_scalar="TRUE",
                    reason="unanimous across contributing databases "
                           "(minimum==maximum)"))
            else:
                audit_rows.append(dict(base, target_subfield=target,
                    raw_value=row.get("value", ""),
                    raw_minimum=_fmt(low) if low is not None else (row.get("minimum") or ""),
                    raw_maximum=_fmt(high) if high is not None else (row.get("maximum") or ""),
                    adjudication_status=status_range, scoreable_scalar="FALSE",
                    reason="contributing databases disagree (minimum!=maximum); both "
                           "endpoints kept, no midpoint, teacher adjudication"))
    return audit_rows


def build_subfield_mask(audit_rows, profiles):
    """One row per (profile, F2/F3/F4, target sub-field) -- the authoritative
    accuracy denominator input for G3. Scalars enter accepted_gold_values;
    ranges stay pending; text sub-fields are completeness-only."""
    by_cell = collections.defaultdict(list)
    for row in audit_rows:
        key = (row["case_id"], row["ncbi_taxid"], row["organism_name"],
               row["organism_scope"], row["trait_id"], row["target_subfield"])
        by_cell[key].append(row)
    mask_rows = []
    for profile in profiles:
        for trait_id in ("F2", "F3", "F4"):
            for target in SUBFIELD_TARGETS[trait_id]:
                key = (profile["case_id"], profile["taxid"], profile["organism_name"],
                       profile.get("scope", "STEP"), trait_id, target)
                rows = by_cell.get(key) or []
                scalars = []
                pending = []
                texts = []
                locators = []
                units = set()
                for row in rows:
                    locator = "%s:%s" % (row["source_database"], row["source_field"])
                    if locator not in locators:
                        locators.append(locator)
                    if row.get("unit"):
                        units.add(row["unit"])
                    if row["adjudication_status"] == "SCALAR_SCOREABLE":
                        scalars.append(row["raw_value"])
                    elif row["adjudication_status"] in (
                            "RANGE_REQUIRES_TEACHER_ADJUDICATION",
                            "MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION"):
                        pending.append(row)
                    elif row["adjudication_status"] == "TEXT_NOT_NUMERIC":
                        texts.append(row)
                # dedupe scalars preserving order
                scalars = list(dict.fromkeys(scalars))
                if scalars:
                    mask_rows.append({
                        "case_id": key[0], "ncbi_taxid": key[1],
                        "organism_name": key[2], "organism_scope": key[3],
                        "trait_id": trait_id, "target_subfield": target,
                        "observed_scalar_present": "TRUE", "scoreable": "TRUE",
                        "pending_teacher_adjudication": "FALSE",
                        "accepted_gold_values": "|".join(scalars),
                        "unit": "|".join(sorted(units)),
                        "source_locators": "|".join(locators),
                        "denominator_role": "observed_accuracy",
                        "reason": "unanimous sourced scalar(s); exact match, no "
                                  "tolerance (multiple sources all kept)",
                    })
                elif pending:
                    mask_rows.append({
                        "case_id": key[0], "ncbi_taxid": key[1],
                        "organism_name": key[2], "organism_scope": key[3],
                        "trait_id": trait_id, "target_subfield": target,
                        "observed_scalar_present": "FALSE", "scoreable": "FALSE",
                        "pending_teacher_adjudication": "TRUE",
                        "accepted_gold_values": "",
                        "unit": "|".join(sorted(units)),
                        "source_locators": "|".join(locators),
                        "denominator_role": "pending_teacher_adjudication",
                        "reason": "range/multi-value records only: endpoints kept "
                                  "verbatim in the audit table; not scoreable until "
                                  "the teacher freezes the range policy",
                    })
                elif texts:
                    mask_rows.append({
                        "case_id": key[0], "ncbi_taxid": key[1],
                        "organism_name": key[2], "organism_scope": key[3],
                        "trait_id": trait_id, "target_subfield": target,
                        "observed_scalar_present": "FALSE", "scoreable": "FALSE",
                        "pending_teacher_adjudication": "FALSE",
                        "accepted_gold_values": "",
                        "unit": "|".join(sorted(units)),
                        "source_locators": "|".join(locators),
                        "denominator_role": "completeness_only",
                        "reason": "text/category material only; never a numeric "
                                  "accuracy denominator",
                    })
                else:
                    mask_rows.append({
                        "case_id": key[0], "ncbi_taxid": key[1],
                        "organism_name": key[2], "organism_scope": key[3],
                        "trait_id": trait_id, "target_subfield": target,
                        "observed_scalar_present": "FALSE", "scoreable": "FALSE",
                        "pending_teacher_adjudication": "FALSE",
                        "accepted_gold_values": "", "unit": "",
                        "source_locators": "",
                        "denominator_role": "completeness_only",
                        "reason": "no observed source for this sub-field in the "
                                  "frozen local inputs",
                    })
    return mask_rows
TRAIT_LABELS = {
    "F1": "oxygen_tolerance", "F2": "temperature", "F3": "pH", "F4": "salinity",
    "F5": "culture_collection", "F6": "respiration_electron_acceptor",
    "F7": "carbon_substrate_utilization", "F8": "degradation_capacity_broad",
    "F9": "enzyme_activity", "F10": "motility", "F11": "cell_morphology",
    "F12": "gram_cell_envelope", "F13": "sporulation", "F14": "genome_basic",
    "F15": "habitat_generalism",
}

# BacDive closure trait_summary fields, mapped once to the frozen F-items.
# Only fields whose semantics match the F-item definition are mapped here.
BACDIVE_FIELD_MAP = {
    "F1": ("oxygen_tolerance",),
    "F2": ("temperature_range", "temperature_optimum"),
    "F5": ("__culture_collection__",),
    "F7": ("metabolite_utilization",),
    "F9": ("enzyme_activity",),
    "F10": ("motility",),
    "F11": ("cell_shape",),
    "F12": ("gram_stain",),
}


def now_utc():
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def write_tsv(path, rows, columns):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, delimiter="\t",
                                lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({c: ("" if row.get(c) is None else str(row.get(c)))
                             for c in columns})


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2, sort_keys=False)
        fh.write("\n")


# --------------------------------------------------------------------------
# inputs manifest (frozen, hashed)
# --------------------------------------------------------------------------

def input_files():
    return [
        ("S4R2_case_review_status.tsv", os.path.join(S4R2, "S4R2_case_review_status.tsv")),
        ("S4R2_pathway_gold_overlay.tsv", os.path.join(S4R2, "S4R2_pathway_gold_overlay.tsv")),
        ("S4R2_step_gold_overlay.tsv", os.path.join(S4R2, "S4R2_step_gold_overlay.tsv")),
        ("S4R2_compound_role_by_occurrence.tsv",
         os.path.join(S4R2, "S4R2_compound_role_by_occurrence.tsv")),
        ("S4R2_manual_review_queue_remaining.tsv",
         os.path.join(S4R2, "S4R2_manual_review_queue_remaining.tsv")),
        ("S4R2_source_evidence.tsv", os.path.join(S4R2, "S4R2_source_evidence.tsv")),
        ("S4R2_order_edges_overlay.tsv", os.path.join(S4R2, "S4R2_order_edges_overlay.tsv")),
        ("S4_accepted_enzymes.tsv", os.path.join(S4G, "accepted_enzymes.tsv")),
        ("S4_accepted_step_organisms.tsv", os.path.join(S4G, "accepted_step_organisms.tsv")),
        ("S4_complete_pathway_organisms.tsv", os.path.join(S4G, "complete_pathway_organisms.tsv")),
        ("S3_selected_150.tsv", os.path.join(S3, "selected_150.tsv")),
        ("S1_structurally_eligible_3_15.tsv", os.path.join(S1, "structurally_eligible_3_15.tsv")),
        ("BIOSYSMOdb_Compounds_chemical_info_v1.0.csv", COMPOUND_INFO_CSV),
        ("metatraits_ncbi_species_summary_all.tsv", METATRAITS_ALL),
        ("metatraits_ncbi_species_summary_no_predictions.tsv", METATRAITS_OBS),
        ("bacdive_full_closure_results.jsonl", BACDIVE_JSONL),
        ("C7_1_long_form_mapping_rerun2.tar.gz", C7_1_MAPPING_TAR),
    ]


def ensure_c7_1_mapping():
    """Copy the frozen rerun2 mapping out of its tar into authority/ (read-only copy)."""
    if os.path.isfile(C7_1_MAPPING_LOCAL):
        return C7_1_MAPPING_LOCAL
    os.makedirs(AUTH_DIR, exist_ok=True)
    import tarfile
    with tarfile.open(C7_1_MAPPING_TAR, "r:gz") as tar:
        member = tar.getmember(C7_1_MAPPING_MEMBER)
        extracted = tar.extractfile(member).read()
    with open(C7_1_MAPPING_LOCAL, "wb") as fh:
        fh.write(extracted)
    return C7_1_MAPPING_LOCAL


CONTENT_MANIFEST_VERSION = "G1_inputs_content_v1"
EVIDENCE_MANIFEST_VERSION = "G1_evidence_manifest_v1"


def content_manifest_path():
    return os.path.join(STAGE25, "G1_inputs.content_manifest.json")


def evidence_manifest_path():
    return os.path.join(G1_DIR, "G1_evidence.manifest.json")


def input_entry(name, path):
    return {"name": name, "path": path, "bytes": os.path.getsize(path),
            "sha256": sha256_file(path)}


def verify_or_create_input_manifest():
    """Freeze the legacy input manifest (G1-R2 repair A).

    * existing file: every entry is re-hashed; any real input change is a HARD
      STOP (never auto-updated); when all match, the file is left byte-for-byte
      untouched;
    * missing file: first creation only.
    The legacy file carries generated_utc / operator / absolute paths and is
    therefore NOT a stable fingerprint -- the stable one is the content
    manifest written next.
    """
    entries = [input_entry(name, path) for name, path in input_files()]
    mapping_path = ensure_c7_1_mapping()
    entries.append(input_entry("C7_1_long_form_mapping_rerun2.csv", mapping_path))
    if os.path.isfile(INPUT_MANIFEST):
        existing = json.load(open(INPUT_MANIFEST, encoding="utf-8"))
        existing_by_name = {e["name"]: e for e in existing.get("files", [])}
        mismatches = []
        for entry in entries:
            prior = existing_by_name.get(entry["name"])
            if prior is None or prior["sha256"] != entry["sha256"] \
                    or prior.get("bytes") != entry["bytes"]:
                mismatches.append(entry["name"])
        if mismatches:
            raise SystemExit("FROZEN INPUT CHANGED, refusing to rebuild: %s"
                             % sorted(mismatches))
        existing_sha = sha256_file(INPUT_MANIFEST)
        print("input manifest frozen (not overwritten): %s" % existing_sha)
        return existing, existing_sha
    manifest = {
        "manifest_version": "G1_inputs_v1",
        "generated_utc": now_utc(),
        "operator": OPERATOR,
        "note": "read-only frozen inputs; any change here invalidates G1 (contract "
                "section 17); created once, never rewritten (G1-R2)",
        "files": entries,
    }
    write_json(INPUT_MANIFEST, manifest)
    return manifest, sha256_file(INPUT_MANIFEST)


def build_content_manifest():
    """Stable input content fingerprint (G1-R2 repair A).

    Depends ONLY on the frozen file list and content: no generated_utc, no
    operator, no machine paths. Written in a canonical JSON form so that
    regenerating it over unchanged inputs is byte-identical; the builder
    self-checks this by generating the document twice and comparing bytes.
    """
    entries = []
    for name, path in sorted(
            [(name, path) for name, path in input_files()]
            + [("C7_1_long_form_mapping_rerun2.csv", ensure_c7_1_mapping())],
            key=lambda item: item[0]):
        entries.append({"name": name, "bytes": os.path.getsize(path),
                        "sha256": sha256_file(path)})
    doc = {"manifest_version": CONTENT_MANIFEST_VERSION, "files": entries}
    text = json.dumps(doc, ensure_ascii=False, indent=2) + "\n"
    # two-generation stability self-check on unchanged inputs
    doc2 = {"manifest_version": CONTENT_MANIFEST_VERSION, "files": entries}
    text2 = json.dumps(doc2, ensure_ascii=False, indent=2) + "\n"
    assert text == text2, "content manifest serialization is not deterministic"
    with open(content_manifest_path(), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    return sha256_file(content_manifest_path()), len(entries)


EVIDENCE_FILES = (
    ("mutation_validation_report.json", "G1-R1/R2 mutation run report (JSON)"),
    ("mutation_validation_summary.tsv", "G1-R1/R2 mutation run summary (TSV)"),
    ("mutation_logs/QUARANTINE_CASE_REINSERTED.log", "mutation log"),
    ("mutation_logs/CROSS_CASE_ENZYME_CONTAMINATION.log", "mutation log"),
    ("mutation_logs/PREDICTED_TRAIT_PROMOTED_TO_OBSERVED.log", "mutation log"),
    ("mutation_logs/STEP_ORGANISM_DELETED.log", "mutation log"),
    ("../scripts/build_g1_gold.py", "G1 builder script (evidence chain)"),
    ("../scripts/validate_g1_gold.py", "G1 independent validator script (evidence chain)"),
    ("../scripts/run_g1_mutation_tests.py", "G1 mutation runner script (evidence chain)"),
)


def build_evidence_manifest():
    """Bind the mutation evidence and the three scripts (G1-R2 repair B).

    Only binds when the full evidence set exists AND the mutation report shows
    all_pass + canonical_unchanged; otherwise the gold manifest records the
    evidence binding as pending. The manifest never lists itself.
    """
    missing = []
    entries = []
    for relpath, role in EVIDENCE_FILES:
        path = os.path.normpath(os.path.join(G1_DIR, relpath))
        if not os.path.isfile(path):
            missing.append(relpath)
            continue
        entries.append({"relpath": relpath, "bytes": os.path.getsize(path),
                        "sha256": sha256_file(path), "role": role})
    if missing:
        return None, missing
    report_path = os.path.join(G1_DIR, "mutation_validation_report.json")
    report = json.load(open(report_path, encoding="utf-8"))
    if not (report.get("all_pass") and report.get("canonical_unchanged")):
        return None, ["mutation report not all_pass/canonical_unchanged"]
    doc = {
        "manifest_version": EVIDENCE_MANIFEST_VERSION,
        "files": entries,
        "note": ("validation evidence for the G1 candidate: mutation reports, logs "
                 "and the three scripts that produced/verified the gold. Not part "
                 "of the scored gold data; SHA256SUMS covers the canonical gold "
                 "files, this manifest covers the evidence chain."),
    }
    write_json(evidence_manifest_path(), doc)
    return sha256_file(evidence_manifest_path()), []


# --------------------------------------------------------------------------
# quarantine mapping (contract section 6.1)
# --------------------------------------------------------------------------

ISSUE_REASON = {
    "CYCLE_REVIEW_REQUIRED": "UNRESOLVED_CYCLE",
    "DISCONNECTED_REVIEW_REQUIRED": "UNRESOLVED_GRAPH_OR_DIRECTION",
    "COMPOUND_ROLE_SIDE_PERMUTATION": "DATA_CONTRADICTION_SIDE_PERMUTATION",
    "COMPOUND_NAME_UNRESOLVED": "UNRESOLVED_COMPOUND_IDENTITY",
}


def build_quarantine(case_status, queue, pathway_overlay, root_entity_of):
    """Map every remaining-review record back to cases. Nothing is resolved here."""
    cases = collections.OrderedDict()
    all_row = None
    for row in queue:
        if row["case_id"] == "ALL":
            all_row = row
            continue
        case_id = row["case_id"]
        entry = cases.setdefault(case_id, {
            "original_case_id": case_id,
            "pathway_id": row.get("pathway_id", ""),
            "root_entity": root_entity_of.get(case_id, ""),
            "issue_ids": [],
            "reasons": [],
            "source_locators": [],
            "affected_step_ids": [],
            "issue_types": [],
        })
        issue_id = row.get("step_occurrence_id") or "CASE_LEVEL"
        entry["issue_ids"].append(issue_id)
        entry["reasons"].append(row.get("decision_status", "UNRESOLVED"))
        entry["source_locators"].append(row.get("evidence_locator", ""))
        entry["issue_types"].append(row.get("issue_type", ""))
        if row.get("step_occurrence_id"):
            entry["affected_step_ids"].append(row["step_occurrence_id"])

    quarantine_rows = []
    for case_id in sorted(cases):
        entry = cases[case_id]
        graph_status = case_status_by_id(case_status, case_id).get("final_graph_status", "")
        primary = entry["issue_types"][0] if entry["issue_types"] else "UNKNOWN"
        quarantine_rows.append({
            "original_case_id": case_id,
            "pathway_id": entry["pathway_id"],
            "root_entity": entry["root_entity"],
            "issue_ids": "|".join(entry["issue_ids"]),
            "issue_types": "|".join(entry["issue_types"]),
            "reason": ISSUE_REASON.get(primary, primary),
            "reason_detail": "|".join(entry["reasons"]),
            "source_locator": "|".join(entry["source_locators"]),
            "affected_step_ids": "|".join(entry["affected_step_ids"]),
            "final_graph_status": graph_status,
            "excluded_at": RUN_TAG,
            "operator": OPERATOR,
            "release_condition": ("teacher case-level content audit only; this record is "
                                  "never auto-released by code"),
        })
    return quarantine_rows, all_row


def case_status_by_id(case_status, case_id):
    for row in case_status:
        if row["case_id"] == case_id:
            return row
    return {}


def build_global_issue_impact(all_row, role_rows, quarantine_ids):
    """BSY-c14673: enumerate every affected case and participant occurrence."""
    impact = collections.OrderedDict()
    for row in role_rows:
        if row.get("compound_id") != "BSY-c14673":
            continue
        case_id = row["case_id"]
        entry = impact.setdefault(case_id, {
            "case_id": case_id,
            "pathway_id": row.get("pathway_id", ""),
            "occurrences": 0,
            "role_labels": collections.Counter(),
            "occurrence_ids": [],
            "main_position_occurrences": 0,
            "quarantined_for_other_issues": case_id in quarantine_ids,
        })
        entry["occurrences"] += 1
        entry["role_labels"][row.get("role_label", "UNKNOWN")] += 1
        entry["occurrence_ids"].append(row.get("participant_occurrence_id", ""))
        if row.get("role_label") in ("MAIN_SUBSTRATE", "MAIN_PRODUCT", "BYPRODUCT"):
            entry["main_position_occurrences"] += 1

    rows = []
    for case_id in sorted(impact):
        entry = impact[case_id]
        rows.append({
            "case_id": case_id,
            "pathway_id": entry["pathway_id"],
            "global_issue_compound_id": "BSY-c14673",
            "global_issue_source": "S4R2_manual_review_queue_remaining.tsv ALL row",
            "occurrence_count": entry["occurrences"],
            "role_label_distribution": json.dumps(
                dict(entry["role_labels"]), ensure_ascii=False),
            "main_position_occurrences": entry["main_position_occurrences"],
            "occurrence_ids": "|".join(entry["occurrence_ids"]),
            "case_quarantined_for_other_issues": entry["quarantined_for_other_issues"],
            "program_level_assessment": (
                "NO_MAIN_CHAIN_IMPACT: every occurrence is a masked currency/redox "
                "participant, never a scored main substrate/product"
                if entry["main_position_occurrences"] == 0 else
                "MAIN_POSITION_PRESENT: case must be quarantined"),
            "teacher_confirmation_required": "TRUE",
        })
    return rows, all_row


# --------------------------------------------------------------------------
# compound identity (names + SMILES from the frozen source CSV)
# --------------------------------------------------------------------------

def load_compound_info(needed_ids):
    """One streaming scan of the 86 MB compound table; keep only needed ids."""
    csv.field_size_limit(1 << 27)  # some annotation fields exceed the 128k default
    found = {}
    with open(COMPOUND_INFO_CSV, encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            cid = (row.get("BIOSYSMO ID") or "").strip()
            if cid in needed_ids and cid not in found:
                found[cid] = {
                    "cmpdname": (row.get("cmpdname") or "").strip(),
                    "isosmiles": (row.get("isosmiles") or "").strip(),
                    "canonicalsmiles": (row.get("canonicalsmiles") or "").strip(),
                }
    return found


# --------------------------------------------------------------------------
# trait sources
# --------------------------------------------------------------------------

def load_c7_1_mapping():
    with open(C7_1_MAPPING_LOCAL, encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))  # comma-separated, not TSV
    mapping = {}
    for row in rows:
        trait_id = (row.get("trait_id") or "").strip()
        patterns = [p.strip() for p in (row.get("candidate_trait_name_patterns") or "").split(";")
                    if p.strip()]
        mapping[trait_id] = {
            "trait_name": row.get("trait_name", ""),
            "patterns": patterns,
            "group_1_patterns": [p.strip() for p in (row.get("candidate_group_1_patterns") or "").split(";")
                                 if p.strip()],
            "mapping_status": row.get("mapping_status", ""),
        }
    missing = [t for t in TRAIT_IDS if t not in mapping]
    if missing:
        raise SystemExit("C7_1 mapping missing F-items: %s" % missing)
    return mapping


def scan_metatraits(taxids, mapping):
    """Stream both species summaries; keep rows for case taxids whose trait_name
    matches a frozen F-item pattern. Record OBSERVED (no_predictions file) vs
    PREDICTED (only in the all file)."""
    compiled = {}
    for trait_id, spec in mapping.items():
        pats = [re.compile(re.escape(p), re.IGNORECASE) for p in spec["patterns"]]
        if trait_id == "F14":  # genome GC comes from the exact long-form name
            pats.append(re.compile(r"^GC percentage$", re.IGNORECASE))
        compiled[trait_id] = pats

    def matches(trait_name):
        hit = []
        for trait_id, pats in compiled.items():
            for pat in pats:
                if pat.search(trait_name):
                    hit.append(trait_id)
                    break
        return hit

    observed = collections.defaultdict(list)   # (taxid, trait_id) -> rows
    predicted = collections.defaultdict(list)
    observed_keys = set()                      # (taxid, trait_name): OBSERVED rows
    stats = {"observed_rows": 0, "predicted_rows": 0,
             "taxids_with_any": set(), "taxids_with_observed": set()}

    for path, bucket, status in ((METATRAITS_OBS, observed, "OBSERVED"),
                                 (METATRAITS_ALL, predicted, "PREDICTED")):
        with open(path, encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh, delimiter="\t"):
                taxid = (row.get("taxon_id") or "").strip()
                if taxid not in taxids:
                    continue
                if status == "PREDICTED" and (taxid, row.get("trait_name") or "") \
                        in observed_keys:
                    continue  # the same consensus row exists in the observed scope
                for trait_id in matches(row.get("trait_name") or ""):
                    rec = {
                        "taxid": taxid,
                        "trait_name": row.get("trait_name", ""),
                        "consensus_value": row.get("consensus_value", ""),
                        "unit": row.get("unit", ""),
                        "minimum": row.get("minimum", ""),
                        "median": row.get("median", ""),
                        "maximum": row.get("maximum", ""),
                        "database_count": row.get("database_count", ""),
                        "total_observations": row.get("total_observations", ""),
                        "databases": row.get("databases", ""),
                        "ontology_ids": row.get("ontology_ids", ""),
                        "value_status": status,
                    }
                    if status == "OBSERVED":
                        observed[(taxid, trait_id)].append(rec)
                        observed_keys.add((taxid, row.get("trait_name") or ""))
                        stats["observed_rows"] += 1
                        stats["taxids_with_observed"].add(taxid)
                    else:
                        predicted[(taxid, trait_id)].append(rec)
                        stats["predicted_rows"] += 1
                    stats["taxids_with_any"].add(taxid)
    return observed, predicted, stats


def load_bacdive(taxids):
    """BacDive closure records for the case taxids."""
    out = {}
    with open(BACDIVE_JSONL, encoding="utf-8") as fh:
        for line in fh:
            rec = json.loads(line)
            taxid = str(rec.get("TaxID") or "").strip()
            if taxid in taxids:
                out[taxid] = rec
    return out


def build_trait_gold(profiles, observed, predicted, bacdive, mapping):
    """Long-format trait gold: one row per (profile, F-item, source record).

    value_status: OBSERVED (observed-scope source), PREDICTED (prediction /
    soft-fill source, background only), UNKNOWN (no source at all -> one row
    with empty value so the completeness denominator stays explicit).
    """
    rows = []
    for profile in profiles:
        taxid = profile["taxid"]
        case_id = profile["case_id"]
        organism_name = profile["organism_name"]
        per_trait_records = collections.defaultdict(list)

        for trait_id in TRAIT_IDS:
            for rec in observed.get((taxid, trait_id), []):
                per_trait_records[trait_id].append(self_row(trait_id, "METATRAITS_OBSERVED", rec))
            for rec in predicted.get((taxid, trait_id), []):
                per_trait_records[trait_id].append(self_row(trait_id, "METATRAITS_PREDICTED", rec))

        bd = bacdive.get(taxid)
        if bd:
            summary = bd.get("trait_summary") or {}
            for trait_id, fields in BACDIVE_FIELD_MAP.items():
                for field in fields:
                    if field == "__culture_collection__":
                        values = bd.get("bacdive_culture_collection_numbers") or []
                        text = "|".join(str(v) for v in values) if values else ""
                        if text:
                            per_trait_records[trait_id].append({
                                "source_database": "BACDIVE",
                                "source_record": str(bd.get("primary_bacdive_id") or ""),
                                "source_field": "bacdive_culture_collection_numbers",
                                "value": text, "unit": "", "minimum": "", "maximum": "",
                                "value_status": "OBSERVED",
                                "raw_text": text,
                            })
                        continue
                    value = (summary.get(field) or "").strip()
                    if value:
                        per_trait_records[trait_id].append({
                            "source_database": "BACDIVE",
                            "source_record": str(bd.get("primary_bacdive_id") or ""),
                            "source_field": field,
                            "value": value, "unit": "", "minimum": "", "maximum": "",
                            "value_status": "OBSERVED",
                            "raw_text": value,
                        })

        # F14 genome basics: accession from BIOSYSMOdb organisms, GC from MetaTraits
        if profile.get("genome_id"):
            per_trait_records["F14"].append({
                "source_database": "BIOSYSMOdb_Organisms",
                "source_record": profile.get("genome_id", ""),
                "source_field": "Genome ID",
                "value": profile.get("genome_id", ""), "unit": "", "minimum": "",
                "maximum": "", "value_status": "OBSERVED",
                "raw_text": "Genome ID %s" % profile.get("genome_id", ""),
            })
        if profile.get("taxid"):
            per_trait_records["F14"].append({
                "source_database": "NCBI_TAXONOMY",
                "source_record": taxid,
                "source_field": "OrganismTaxID",
                "value": taxid, "unit": "", "minimum": "", "maximum": "",
                "value_status": "OBSERVED",
                "raw_text": "TaxID %s" % taxid,
            })

        for trait_id in TRAIT_IDS:
            recs = per_trait_records.get(trait_id)
            if not recs:
                rows.append({
                    "case_id": case_id, "ncbi_taxid": taxid,
                    "organism_name": organism_name,
                    "organism_scope": profile.get("scope", "STEP"),
                    "trait_id": trait_id,
                    "trait_name": TRAIT_LABELS[trait_id],
                    "source_database": "", "source_record": "", "source_field": "",
                    "value": "", "unit": "", "minimum": "", "maximum": "",
                    "value_status": "UNKNOWN", "raw_text": "",
                })
                continue
            for rec in recs:
                rows.append({
                    "case_id": case_id, "ncbi_taxid": taxid,
                    "organism_name": organism_name,
                    "organism_scope": profile.get("scope", "STEP"),
                    "trait_id": trait_id,
                    "trait_name": TRAIT_LABELS[trait_id],
                    "source_database": rec["source_database"],
                    "source_record": rec["source_record"],
                    "source_field": rec["source_field"],
                    "value": rec["value"], "unit": rec.get("unit", ""),
                    "minimum": rec.get("minimum", ""), "maximum": rec.get("maximum", ""),
                    "value_status": rec["value_status"],
                    "raw_text": rec.get("raw_text", ""),
                })
    return rows


def self_row(trait_id, source, rec):
    field = "trait_name=%s" % rec["trait_name"]
    if source == "METATRAITS_OBSERVED":
        db = "METATRAITS_no_predictions"
    else:
        db = "METATRAITS_all"
    return {
        "source_database": db,
        "source_record": rec["taxid"],
        "source_field": field,
        "value": rec["consensus_value"],
        "unit": rec.get("unit", ""),
        "minimum": rec.get("minimum", ""), "maximum": rec.get("maximum", ""),
        "value_status": rec["value_status"],
        "raw_text": "%s=%s (databases=%s, observations=%s)" % (
            rec["trait_name"], rec["consensus_value"], rec.get("databases", ""),
            rec.get("total_observations", "")),
    }


def build_scoreability_mask(trait_rows):
    """scoreable=1 only where an OBSERVED record with a usable value exists.

    'NA' / 'No robust majority' consensus values are preserved in trait_gold as
    audit material but do NOT count as observed values here.
    """
    observed = set()
    predicted_keys = set()
    for row in trait_rows:
        key = (row["case_id"], row["ncbi_taxid"], row["organism_name"], row["trait_id"])
        if row["value_status"] == "OBSERVED" and not is_empty_trait_value(row.get("value")):
            observed.add(key)
        if row["value_status"] == "PREDICTED":
            predicted_keys.add(key)
    seen = set()
    mask_rows = []
    for row in trait_rows:
        key = (row["case_id"], row["ncbi_taxid"], row["organism_name"], row["trait_id"])
        if key in seen:
            continue
        seen.add(key)
        mask_rows.append({
            "case_id": row["case_id"], "ncbi_taxid": row["ncbi_taxid"],
            "organism_name": row["organism_name"],
            "organism_scope": row["organism_scope"],
            "trait_id": row["trait_id"], "trait_name": row["trait_name"],
            "observed_value_present": "TRUE" if key in observed else "FALSE",
            "scoreable": "TRUE" if key in observed else "FALSE",
            "denominator_role": "observed_accuracy" if key in observed
                                else "completeness_only",
            "predicted_background_only": "TRUE" if key in predicted_keys else "FALSE",
        })
    return mask_rows


# --------------------------------------------------------------------------
# main build
# --------------------------------------------------------------------------

def main(argv=None):
    global STAGE25
    parser = argparse.ArgumentParser(description="build G1 quarantine + formal gold")
    parser.add_argument("--stage-root", default=STAGE25)
    args = parser.parse_args(argv)
    global G1_DIR, QUAR_DIR, GATES_DIR, AUTH_DIR, INPUT_MANIFEST
    STAGE25 = os.path.abspath(args.stage_root)
    G1_DIR = os.path.join(args.stage_root, "G1_gold")
    QUAR_DIR = os.path.join(args.stage_root, "quarantine")
    GATES_DIR = os.path.join(args.stage_root, "gates")
    AUTH_DIR = os.path.join(args.stage_root, "authority")
    INPUT_MANIFEST = os.path.join(args.stage_root, "G1_inputs.manifest.json")

    print("[1/9] freezing input manifest ...")
    input_manifest, input_manifest_sha = verify_or_create_input_manifest()
    content_manifest_sha, content_manifest_count = build_content_manifest()
    print("content manifest: %s (%d files, stable two-generation check passed)"
          % (content_manifest_sha, content_manifest_count))
    evidence_manifest_sha, evidence_missing = build_evidence_manifest()
    if evidence_manifest_sha is None:
        print("evidence manifest: PENDING (%s)" % "; ".join(evidence_missing))
    evidence_binding = ({"path": evidence_manifest_path(),
                         "sha256": evidence_manifest_sha}
                        if evidence_manifest_sha is not None else
                        {"path": evidence_manifest_path(), "sha256": None,
                         "status": "PENDING_EVIDENCE",
                         "note": "mutation evidence not yet bound (run "
                                 "run_g1_mutation_tests.py, then rebuild)"})

    case_status = read_tsv(os.path.join(S4R2, "S4R2_case_review_status.tsv"))
    pathway_overlay = read_tsv(os.path.join(S4R2, "S4R2_pathway_gold_overlay.tsv"))
    step_overlay = read_tsv(os.path.join(S4R2, "S4R2_step_gold_overlay.tsv"))
    role_rows = read_tsv(os.path.join(S4R2, "S4R2_compound_role_by_occurrence.tsv"))
    queue = read_tsv(os.path.join(S4R2, "S4R2_manual_review_queue_remaining.tsv"))
    enzymes = read_tsv(os.path.join(S4G, "accepted_enzymes.tsv"))
    step_orgs = read_tsv(os.path.join(S4G, "accepted_step_organisms.tsv"))
    complete_orgs = read_tsv(os.path.join(S4G, "complete_pathway_organisms.tsv"))
    selected = read_tsv(os.path.join(S3, "selected_150.tsv"))
    eligible = read_tsv(os.path.join(S1, "structurally_eligible_3_15.tsv"))

    root_entity_of = {}
    for r in pathway_overlay:
        # fall back to the pathway name when the overlay carries no root names
        root_entity_of[r["case_id"]] = (r.get("root_compound_names")
                                        or r.get("pathway_name") or "")

    print("[2/9] mapping quarantine (S4-R2 remaining review -> cases) ...")
    quarantine_rows, all_row = build_quarantine(case_status, queue, pathway_overlay,
                                                root_entity_of)
    quarantine_ids = set(r["original_case_id"] for r in quarantine_rows)
    formal_rows_status = [r for r in case_status if r["final_case_status"] == "ORDER_PASS"]
    formal_by_status = set(r["case_id"] for r in formal_rows_status)
    formal_ids = formal_by_status - quarantine_ids
    # cross-check the two independent signals: the remaining-review queue and
    # final_case_status must partition the 150 cases identically.
    if formal_by_status & quarantine_ids:
        raise SystemExit("cases both ORDER_PASS and quarantined: %s"
                         % sorted(formal_by_status & quarantine_ids))
    if len(formal_by_status | quarantine_ids) != len(case_status):
        raise SystemExit("ORDER_PASS + quarantine does not cover all %d cases (covers %d)"
                         % (len(case_status), len(formal_by_status | quarantine_ids)))
    print("       quarantined %d cases; formal candidates %d"
          % (len(quarantine_ids), len(formal_ids)))

    print("[3/9] BSY-c14673 global issue -> per-case impact ...")
    impact_rows, all_row = build_global_issue_impact(all_row, role_rows, quarantine_ids)
    main_position_cases = [r["case_id"] for r in impact_rows
                           if r["main_position_occurrences"] > 0]
    if main_position_cases:
        raise SystemExit("BSY-c14673 appears in a scored main position in: %s"
                         % main_position_cases)
    print("       %d formal+quarantine cases carry the ALL record; 0 main-position "
          "occurrences" % len(impact_rows))

    print("[4/9] compound identity / SMILES from the frozen source CSV ...")
    needed = set()
    for row in role_rows:
        if row["case_id"] in formal_ids:
            needed.add(row["compound_id"])
    for row in pathway_overlay:
        if row["case_id"] in formal_ids:
            needed.update((row.get("root_compound_ids") or "").split("|"))
            needed.update((row.get("terminal_compound_ids") or "").split("|"))
    needed.discard("")
    compound_info = load_compound_info(needed)
    missing_smiles = sorted(cid for cid in needed
                            if not compound_info.get(cid, {}).get("isosmiles")
                            and not compound_info.get(cid, {}).get("canonicalsmiles"))
    print("       %d compound ids needed; %d without any SMILES"
          % (len(needed), len(missing_smiles)))

    print("[5/9] writing formal case set / root identity / gold tables ...")
    selected_by_case = {r["case_id"]: r for r in selected}
    formal_case_rows = []
    for row in sorted(formal_rows_status, key=lambda r: r["case_id"]):
        case_id = row["case_id"]
        sel = selected_by_case.get(case_id, {})
        formal_case_rows.append({
            "case_id": case_id,
            "pathway_id": row.get("pathway_id", ""),
            "pathway_name": sel.get("pathway_name", ""),
            "selection_tier": sel.get("selection_tier", ""),
            "broad_category": sel.get("broad_category", ""),
            "aerobic_or_anaerobic": sel.get("aerobic_or_anaerobic", ""),
            "final_graph_status": row.get("final_graph_status", ""),
            "ordered_step_count": "",  # filled below
            "s4r2_order_pass": row.get("s4r2_order_pass", ""),
            "quarantined": "FALSE",
        })
    write_tsv(os.path.join(G1_DIR, "formal_cases.tsv"), formal_case_rows,
              ["case_id", "pathway_id", "pathway_name", "selection_tier", "broad_category",
               "aerobic_or_anaerobic", "final_graph_status", "ordered_step_count",
               "s4r2_order_pass", "quarantined"])

    root_rows = []
    for row in pathway_overlay:
        if row["case_id"] not in formal_ids:
            continue
        root_ids = [c for c in (row.get("root_compound_ids") or "").split("|") if c]
        terminal_ids = [c for c in (row.get("terminal_compound_ids") or "").split("|") if c]
        root_rows.append({
            "case_id": row["case_id"], "pathway_id": row.get("pathway_id", ""),
            "pathway_name": row.get("pathway_name", ""),
            "root_compound_ids": row.get("root_compound_ids", ""),
            "root_compound_names": row.get("root_compound_names", ""),
            "root_isosmiles": "|".join(
                compound_info.get(c, {}).get("isosmiles", "") for c in root_ids),
            "root_canonicalsmiles": "|".join(
                compound_info.get(c, {}).get("canonicalsmiles", "") for c in root_ids),
            "terminal_compound_ids": row.get("terminal_compound_ids", ""),
            "terminal_compound_names": row.get("terminal_compound_names", ""),
            "terminal_isosmiles": "|".join(
                compound_info.get(c, {}).get("isosmiles", "") for c in terminal_ids),
            "terminal_canonicalsmiles": "|".join(
                compound_info.get(c, {}).get("canonicalsmiles", "") for c in terminal_ids),
            "broad_category": selected_by_case.get(row["case_id"], {}).get("broad_category", ""),
            "aerobic_or_anaerobic": selected_by_case.get(row["case_id"], {}).get(
                "aerobic_or_anaerobic", ""),
        })
    write_tsv(os.path.join(G1_DIR, "case_root_identity.tsv"), root_rows,
              ["case_id", "pathway_id", "pathway_name", "root_compound_ids",
               "root_compound_names", "root_isosmiles", "root_canonicalsmiles",
               "terminal_compound_ids", "terminal_compound_names", "terminal_isosmiles",
               "terminal_canonicalsmiles", "broad_category", "aerobic_or_anaerobic"])

    step_overlay_by_id = {r["step_occurrence_id"]: r for r in step_overlay}
    reaction_rows = []
    for row in role_rows:
        if row["case_id"] not in formal_ids:
            continue
        step = step_overlay_by_id.get(row["step_occurrence_id"], {})
        cid = row["compound_id"]
        info = compound_info.get(cid, {})
        reaction_rows.append({
            "case_id": row["case_id"],
            "pathway_id": row.get("pathway_id", ""),
            "step_occurrence_id": row["step_occurrence_id"],
            "reaction_id": row["reaction_id"],
            "linear_display_order": step.get("linear_display_order", ""),
            "topological_level": step.get("topological_level", ""),
            "branch_id": step.get("branch_id", ""),
            "predecessor_step_ids": step.get("predecessor_step_ids", ""),
            "successor_step_ids": step.get("successor_step_ids", ""),
            "gold_orientation": step.get("gold_orientation", ""),
            "arrow_class": step.get("arrow_class", ""),
            "participant_side": row.get("gold_side", ""),
            "participant_source_side": row.get("source_side", ""),
            "participant_position": row.get("source_position", ""),
            "compound_id": cid,
            "db_cmpdname": info.get("cmpdname", ""),
            "identity_name": row.get("identity_name", ""),
            "identity_source": row.get("identity_source", ""),
            "isosmiles": info.get("isosmiles", ""),
            "canonicalsmiles": info.get("canonicalsmiles", ""),
            "role_label": row.get("role_label", ""),
            "role_confidence": row.get("role_confidence", ""),
            "is_currency_for_ordering": row.get("is_currency_for_ordering", ""),
            "is_main_chain_candidate": row.get("is_main_chain_candidate", ""),
            "s4r2_occurrence_mask": row.get("s4r2_occurrence_mask", ""),
            "aligned_token": row.get("aligned_token", ""),
            "role_evidence_locator": row.get("role_evidence_locator", ""),
            "reactions_csv_row": row.get("reactions_csv_row", ""),
        })
    write_tsv(os.path.join(G1_DIR, "reaction_gold.tsv"), reaction_rows, [
        "case_id", "pathway_id", "step_occurrence_id", "reaction_id",
        "linear_display_order", "topological_level", "branch_id",
        "predecessor_step_ids", "successor_step_ids", "gold_orientation", "arrow_class",
        "participant_side", "participant_source_side", "participant_position",
        "compound_id", "db_cmpdname",
        "identity_name", "identity_source", "isosmiles", "canonicalsmiles", "role_label",
        "role_confidence", "is_currency_for_ordering", "is_main_chain_candidate",
        "s4r2_occurrence_mask", "aligned_token", "role_evidence_locator",
        "reactions_csv_row"])

    enzyme_rows = [r for r in enzymes if r["case_id"] in formal_ids]
    write_tsv(os.path.join(G1_DIR, "enzyme_gold.tsv"), enzyme_rows, [
        "case_id", "pathway_id", "step_occurrence_id", "reaction_id", "enzyme_id",
        "enzyme_name", "ec_number_raw", "ec_number_normalized", "eawag_enzyme_id",
        "metacyc_enzyme_id", "mibpop_enzyme_id", "kegg_enzyme_id",
        "sequence_availability", "rule", "license", "source_row_number"])

    organism_rows = []
    for row in step_orgs:
        if row["case_id"] not in formal_ids:
            continue
        organism_rows.append(dict(row, scope="STEP"))
    for row in complete_orgs:
        if row["case_id"] not in formal_ids:
            continue
        organism_rows.append(dict(row, scope="PATHWAY_COMPLETE"))
    write_tsv(os.path.join(G1_DIR, "organism_gold.tsv"), organism_rows, [
        "scope", "case_id", "pathway_id", "step_occurrence_id", "reaction_id",
        "enzyme_id", "enzyme_name", "organism_name_raw", "organism_name_normalized",
        "organism_match_status", "matched_organism_name", "taxid", "genome_id", "kingdom",
        "source_enzyme_row_number", "matched_organism_row_number", "download_available",
        "pathway_complete", "license", "source_row_number"])

    # ordered step count per formal case (from the step overlay)
    steps_by_case = collections.Counter(
        r["case_id"] for r in step_overlay if r["case_id"] in formal_ids)
    for row in formal_case_rows:
        row["ordered_step_count"] = str(steps_by_case.get(row["case_id"], 0))
    write_tsv(os.path.join(G1_DIR, "formal_cases.tsv"), formal_case_rows,
              ["case_id", "pathway_id", "pathway_name", "selection_tier", "broad_category",
               "aerobic_or_anaerobic", "final_graph_status", "ordered_step_count",
               "s4r2_order_pass", "quarantined"])

    print("[6/9] trait gold (MetaTraits + BacDive + BIOSYSMOdb genome) ...")
    profiles = []
    seen_profiles = set()
    for row in organism_rows:
        if row["scope"] != "STEP":
            continue
        key = (row["case_id"], row["taxid"], row["matched_organism_name"])
        if key in seen_profiles:
            continue
        seen_profiles.add(key)
        profiles.append({
            "case_id": row["case_id"], "taxid": row["taxid"],
            "organism_name": row["matched_organism_name"],
            "genome_id": row.get("genome_id", ""), "scope": "STEP",
        })
    for row in complete_orgs:
        if row["case_id"] not in formal_ids:
            continue
        key = (row["case_id"], row["taxid"], row["organism_name"])
        if key in seen_profiles:
            continue
        seen_profiles.add(key)
        profiles.append({
            "case_id": row["case_id"], "taxid": row["taxid"],
            "organism_name": row["organism_name"],
            "genome_id": row.get("genome_id", ""), "scope": "PATHWAY_COMPLETE",
        })
    mapping = load_c7_1_mapping()
    taxids = set(p["taxid"] for p in profiles if p["taxid"])
    observed, predicted, mt_stats = scan_metatraits(taxids, mapping)
    bacdive = load_bacdive(taxids)
    print("       profiles: %d (taxids %d); metatraits observed rows %d / predicted rows %d; "
          "bacdive covered taxids %d" % (len(profiles), len(taxids),
                                          mt_stats["observed_rows"],
                                          mt_stats["predicted_rows"], len(bacdive)))
    trait_rows = build_trait_gold(profiles, observed, predicted, bacdive, mapping)
    write_tsv(os.path.join(G1_DIR, "trait_gold.tsv"), trait_rows, [
        "case_id", "ncbi_taxid", "organism_name", "organism_scope", "trait_id",
        "trait_name", "source_database", "source_record", "source_field", "value",
        "unit", "minimum", "maximum", "value_status", "raw_text"])
    mask_rows = build_scoreability_mask(trait_rows)

    # G1-R1 repair A: F2/F3/F4 numeric sub-field audit + authoritative sub-field mask
    write_tsv(os.path.join(G1_DIR, "trait_numeric_subfield_mapping.tsv"),
              SUBFIELD_MAPPING, ["trait_id", "source_field_pattern", "source_database",
                                 "target_subfield", "source_value_columns",
                                 "value_status_required", "conversion_rule",
                                 "ambiguity_policy", "authority_locator"])
    audit_rows = build_numeric_subfield_audit(trait_rows)
    write_tsv(os.path.join(G1_DIR, "trait_numeric_subfield_audit.tsv"), audit_rows, [
        "case_id", "ncbi_taxid", "organism_name", "organism_scope", "trait_id",
        "target_subfield", "source_database", "source_record", "source_field",
        "raw_value", "raw_minimum", "raw_maximum", "unit", "value_status",
        "adjudication_status", "scoreable_scalar", "reason"])
    subfield_mask_rows = build_subfield_mask(audit_rows, profiles)
    write_tsv(os.path.join(G1_DIR, "trait_subfield_scoreability_mask.tsv"),
              subfield_mask_rows, [
        "case_id", "ncbi_taxid", "organism_name", "organism_scope", "trait_id",
        "target_subfield", "observed_scalar_present", "scoreable",
        "pending_teacher_adjudication", "accepted_gold_values", "unit",
        "source_locators", "denominator_role", "reason"])
    # enrich the 15-item summary mask with sub-field rollups
    subfield_stats = collections.defaultdict(lambda: {"scoreable": 0, "pending": [],
                                                      "total": 0})
    for row in subfield_mask_rows:
        key = (row["case_id"], row["ncbi_taxid"], row["organism_name"], row["trait_id"])
        stats = subfield_stats[key]
        stats["total"] += 1
        if row["scoreable"] == "TRUE":
            stats["scoreable"] += 1
        if row["pending_teacher_adjudication"] == "TRUE":
            stats["pending"].append(row["target_subfield"])
    for row in mask_rows:
        key = (row["case_id"], row["ncbi_taxid"], row["organism_name"], row["trait_id"])
        stats = subfield_stats.get(key, {"scoreable": 0, "pending": [], "total": 0})
        row["scoreable_subfield_count"] = str(stats["scoreable"])
        row["pending_adjudication_subfield_count"] = str(len(set(stats["pending"])))
        row["subfields_pending"] = "|".join(sorted(set(stats["pending"])))
    write_tsv(os.path.join(G1_DIR, "trait_scoreability_mask.tsv"), mask_rows, [
        "case_id", "ncbi_taxid", "organism_name", "organism_scope", "trait_id",
        "trait_name", "observed_value_present", "scoreable", "denominator_role",
        "predicted_background_only", "scoreable_subfield_count",
        "pending_adjudication_subfield_count", "subfields_pending"])

    print("[7/9] supplementary candidate list (no promotion) ...")
    selected_pathway_ids = set(r["pathway_id"] for r in selected)
    supp_rows = []
    for row in eligible:
        if row["pathway_id"] in selected_pathway_ids:
            continue
        supp_rows.append({
            "candidate_pathway_id": row["pathway_id"],
            "pathway_name": row["pathway_name"],
            "aerobic_or_anaerobic": row["aerobic_or_anaerobic"],
            "raw_reaction_count": row["raw_reaction_count"],
            "unique_reaction_count": row["unique_reaction_count"],
            "path_length_3_15": row["path_length_3_15"],
            "structural_eligibility_3_15": row["structural_eligibility_3_15"],
            "every_step_has_named_enzyme_and_organism":
                row["every_step_has_named_enzyme_and_organism"],
            "has_complete_pathway_organism": row["has_complete_pathway_organism"],
            "status": ("CANDIDATE_STRUCTURALLY_ELIGIBLE_ONLY; promotion requires the full "
                       "scientific flow (S4 -> S4R1 -> S4R2) and teacher audit; NOT counted "
                       "in final_n"),
            "listed_at": RUN_TAG,
        })
    write_tsv(os.path.join(G1_DIR, "supplementary_candidates.tsv"), supp_rows, [
        "candidate_pathway_id", "pathway_name", "aerobic_or_anaerobic",
        "raw_reaction_count", "unique_reaction_count", "path_length_3_15",
        "structural_eligibility_3_15", "every_step_has_named_enzyme_and_organism",
        "has_complete_pathway_organism", "status", "listed_at"])

    print("[8/9] quarantine tables, counts, lookup manifest, review doc ...")
    write_tsv(os.path.join(QUAR_DIR, "cases.tsv"), quarantine_rows, [
        "original_case_id", "pathway_id", "root_entity", "issue_ids", "issue_types",
        "reason", "reason_detail", "source_locator", "affected_step_ids",
        "final_graph_status", "excluded_at", "operator", "release_condition"])
    write_tsv(os.path.join(QUAR_DIR, "global_issue_impact.tsv"), impact_rows, [
        "case_id", "pathway_id", "global_issue_compound_id", "global_issue_source",
        "occurrence_count", "role_label_distribution", "main_position_occurrences",
        "occurrence_ids", "case_quarantined_for_other_issues", "program_level_assessment",
        "teacher_confirmation_required"])
    reason_counts = collections.Counter(r["reason"] for r in quarantine_rows)
    reasons_summary = {
        "generated_utc": now_utc(),
        "quarantine_case_count": len(quarantine_rows),
        "quarantine_rate": round(len(quarantine_rows) / 150.0, 4),
        "reason_distribution": dict(reason_counts),
        "issue_type_distribution": dict(collections.Counter(
            t for r in quarantine_rows for t in r["issue_types"].split("|") if t)),
        "global_issue": {
            "compound_id": "BSY-c14673",
            "affected_case_count": len(impact_rows),
            "total_occurrences": sum(r["occurrence_count"] for r in impact_rows),
            "main_position_occurrences_total": sum(
                r["main_position_occurrences"] for r in impact_rows),
            "mapping_policy": ("every occurrence enumerated per case; program-level "
                               "assessment recorded; release/quarantine decision on this "
                               "issue belongs to the teacher audit"),
        },
        "policy": ("real cycles and unresolved contradictions never enter the formal "
                   "scored bank; release requires teacher case-level content audit"),
    }
    write_json(os.path.join(QUAR_DIR, "reasons_summary.json"), reasons_summary)

    counts = compute_counts(formal_case_rows, root_rows, reaction_rows, enzyme_rows,
                            organism_rows, trait_rows, mask_rows, quarantine_rows,
                            supp_rows, missing_smiles, profiles, mt_stats, bacdive,
                            audit_rows, subfield_mask_rows)
    write_json(os.path.join(G1_DIR, "counts.json"), counts)

    lookup_manifest = build_lookup_manifest()
    write_json(os.path.join(G1_DIR, "evidence_lookup_index_manifest.json"),
               lookup_manifest)

    review_md = build_review_md(counts, quarantine_rows, impact_rows, missing_smiles,
                                mapping, mt_stats, supp_rows, subfield_mask_rows,
                                audit_rows, input_manifest_sha, content_manifest_sha,
                                content_manifest_count, evidence_binding)
    with open(os.path.join(G1_DIR, "teacher_gold_review.md"), "w",
              encoding="utf-8", newline="\n") as fh:
        fh.write(review_md)

    print("[9/9] SHA256SUMS + gold manifest + stage gate ...")
    g1_files = ["formal_cases.tsv", "case_root_identity.tsv", "reaction_gold.tsv",
                "enzyme_gold.tsv", "organism_gold.tsv", "trait_gold.tsv",
                "trait_scoreability_mask.tsv", "trait_numeric_subfield_mapping.tsv",
                "trait_numeric_subfield_audit.tsv",
                "trait_subfield_scoreability_mask.tsv",
                "supplementary_candidates.tsv",
                "counts.json", "evidence_lookup_index_manifest.json",
                "teacher_gold_review.md"]
    sums = []
    for name in g1_files:
        sums.append((sha256_file(os.path.join(G1_DIR, name)), name))
    with open(os.path.join(G1_DIR, "SHA256SUMS"), "w", encoding="utf-8",
              newline="\n") as fh:
        for digest, name in sorted(sums, key=lambda x: x[1]):
            fh.write("%s  %s\n" % (digest, name))

    sums_by_name = {name: digest for digest, name in sums}
    gold_manifest = {
        "manifest_version": "G1_gold_manifest_v2",
        "generated_utc": now_utc(),
        "hidden_gold_hashes": {
            "reaction_gold": sums_by_name["reaction_gold.tsv"],
            "enzyme_gold": sums_by_name["enzyme_gold.tsv"],
            "organism_gold": sums_by_name["organism_gold.tsv"],
            "trait_gold": sums_by_name["trait_gold.tsv"],
        },
        "input_manifest_sha256": input_manifest_sha,
        "input_content_manifest": {
            "path": content_manifest_path(),
            "sha256": content_manifest_sha,
            "file_count": content_manifest_count,
            "note": ("stable content fingerprint: no generated_utc / operator / "
                     "machine paths; byte-identical across rebuilds while the "
                     "frozen inputs are unchanged (two-generation check in the "
                     "builder, recompute check in the validator)"),
        },
        "historical_input_manifest": {
            "path": INPUT_MANIFEST,
            "sha256": input_manifest_sha,
            "preserved_unmodified": True,
            "relation": ("the historical manifest file is preserved byte-for-byte "
                         "(never overwritten since G1-R2); it lists the same %d "
                         "files with identical sha256 values as the content "
                         "manifest (program-verified); the two manifests are NOT "
                         "byte-identical because the historical one carries "
                         "generated_utc / operator / absolute paths" % content_manifest_count),
            "historical_manifest_transition_unverified": False,
        },
        "evidence_manifest": evidence_binding,
        "sha256sums_scope": {
            "covers": sorted(name for _d, name in sums),
            "note": ("SHA256SUMS covers the canonical gold data files ONLY; the "
                     "mutation evidence and the three scripts are covered by "
                     "G1_evidence.manifest.json instead"),
        },
        "final_n": counts["final_n"],
        "stage": "G1_gold",
        "status": "READY_FOR_REVIEW",
        "note": "hidden gold stays local; external packages carry hashes only",
    }
    write_json(os.path.join(G1_DIR, "G1_gold.manifest.json"), gold_manifest)

    gate = {
        "stage": "G1_gold",
        "status": "READY_FOR_REVIEW",
        "generated_utc": now_utc(),
        "input_manifest": {"path": INPUT_MANIFEST, "sha256": input_manifest_sha},
        "input_content_manifest": {"path": content_manifest_path(),
                                   "sha256": content_manifest_sha},
        "output_manifest": {"path": os.path.join(G1_DIR, "G1_gold.manifest.json"),
                            "sha256": sha256_file(os.path.join(G1_DIR, "G1_gold.manifest.json"))},
        "evidence_manifest": evidence_binding,
        "tests": {"builder": "build_g1_gold.py exit 0",
                  "independent_validator": "validate_g1_gold.py (run separately)",
                  "mutation_runner": "run_g1_mutation_tests.py 4/4 semantic detection"},
        "counts": {"final_n": counts["final_n"],
                   "quarantine_cases": counts["quarantine_case_count"],
                   "supplementary_candidates": counts["supplementary_candidate_count"]},
        "reviewer": None,
        "approval_source": None,
        "review_due": "teacher gold content audit (contract section 6.3)",
        "next_stage_allowed": False,
        "next_stage": "G2_questions (blocked until teacher G1 sign-off)",
    }
    write_json(os.path.join(GATES_DIR, "G1_gold.stage_gate.json"), gate)

    # the invalidation ledger is curated per repair round (contract section 17);
    # the builder only guarantees the header exists and never auto-appends.
    ledger = os.path.join(args.stage_root, "invalidation_ledger.tsv")
    if not os.path.isfile(ledger):
        with open(ledger, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("old_sha256\tnew_sha256\treason\ttimestamp\tstages_affected\t"
                     "operator\tnew_approval_path\n")
    print("G1 build complete. final_n=%d quarantine=%d candidates=%d"
          % (counts["final_n"], counts["quarantine_case_count"],
             counts["supplementary_candidate_count"]))
    return 0


def compute_counts(formal_case_rows, root_rows, reaction_rows, enzyme_rows,
                   organism_rows, trait_rows, mask_rows, quarantine_rows, supp_rows,
                   missing_smiles, profiles, mt_stats, bacdive, audit_rows,
                   subfield_mask_rows):
    formal_ids = set(r["case_id"] for r in formal_case_rows)
    step_ids = set(r["step_occurrence_id"] for r in reaction_rows)
    directed_reactions = set(r["reaction_id"] for r in reaction_rows)
    enzyme_step_links = set((r["step_occurrence_id"], r["enzyme_id"]) for r in enzyme_rows)
    org_step_links = set((r["step_occurrence_id"], r["enzyme_id"], r["taxid"])
                         for r in organism_rows if r["scope"] == "STEP")
    step_org_rows = [r for r in organism_rows if r["scope"] == "STEP"]
    trait_status = collections.Counter(
        (r["trait_id"], r["value_status"]) for r in trait_rows if r["trait_id"] in TRAIT_IDS)
    per_trait = {}
    for trait_id in TRAIT_IDS:
        per_trait[trait_id] = {
            "observed_rows": trait_status.get((trait_id, "OBSERVED"), 0),
            "predicted_rows": trait_status.get((trait_id, "PREDICTED"), 0),
            "unknown_rows": trait_status.get((trait_id, "UNKNOWN"), 0),
            "scoreable_profile_traits": sum(
                1 for m in mask_rows
                if m["trait_id"] == trait_id and m["scoreable"] == "TRUE"),
        }
    root_ids = set()
    for r in root_rows:
        root_ids.update(c for c in r["root_compound_ids"].split("|") if c)

    # G1-R1: F2/F3/F4 numeric sub-field statistics (all recomputed, never copied
    # from the repair prompt's regression hints)
    subfield_audit_status = collections.Counter(
        (r["trait_id"], r["adjudication_status"]) for r in audit_rows)
    subfield_profile_counts = {}
    for trait_id in ("F2", "F3", "F4"):
        per_target = {}
        for target in SUBFIELD_TARGETS[trait_id]:
            cells = [r for r in subfield_mask_rows
                     if r["trait_id"] == trait_id and r["target_subfield"] == target]
            per_target[target] = {
                "profiles_total": len(cells),
                "profiles_scoreable_scalar": sum(1 for r in cells if r["scoreable"] == "TRUE"),
                "profiles_pending_adjudication": sum(
                    1 for r in cells if r["pending_teacher_adjudication"] == "TRUE"),
            }
        observed_trait_rows = sum(
            1 for r in trait_rows
            if r["trait_id"] == trait_id and r["value_status"] == "OBSERVED")
        predicted_only = 0
        per_profile = collections.defaultdict(lambda: {"obs": False, "pred": False})
        for r in trait_rows:
            if r["trait_id"] != trait_id:
                continue
            key = (r["case_id"], r["ncbi_taxid"], r["organism_name"])
            per_profile[key]["obs" if r["value_status"] == "OBSERVED" else "pred"] = True
        predicted_only = sum(1 for v in per_profile.values() if v["pred"] and not v["obs"])
        subfield_profile_counts[trait_id] = {
            "observed_source_rows": observed_trait_rows,
            "predicted_only_profiles": predicted_only,
            "by_target_subfield": per_target,
            "adjudication_status_rows": {
                status: subfield_audit_status.get((trait_id, status), 0)
                for status in ("SCALAR_SCOREABLE",
                               "RANGE_REQUIRES_TEACHER_ADJUDICATION",
                               "MULTI_VALUE_REQUIRES_TEACHER_ADJUDICATION",
                               "TEXT_NOT_NUMERIC",
                               "NO_USABLE_OBSERVED_VALUE")
            },
        }
    return {
        "generated_utc": now_utc(),
        "operator": OPERATOR,
        "final_n": len(formal_ids),
        "selected_pool_size": 150,
        "independent_root_substances": len(root_ids),
        "branch_cases": sum(1 for r in formal_case_rows
                            if r["final_graph_status"] == "BRANCHED_DAG"),
        "linear_unique_cases": sum(1 for r in formal_case_rows
                                   if r["final_graph_status"] == "LINEAR_UNIQUE"),
        "step_occurrence_total": len(step_ids),
        "participant_occurrence_rows": len(reaction_rows),
        "unique_directed_reactions": len(directed_reactions),
        "unique_case_reaction_pairs": len(set(
            (r["case_id"], r["reaction_id"]) for r in reaction_rows)),
        "enzyme_records": len(enzyme_rows),
        "unique_enzyme_ids": len(set(r["enzyme_id"] for r in enzyme_rows)),
        "unique_enzyme_names": len(set(r["enzyme_name"] for r in enzyme_rows)),
        "unique_ec_numbers_normalized": len(set(
            r["ec_number_normalized"] for r in enzyme_rows if r["ec_number_normalized"])),
        "enzyme_step_links": len(enzyme_step_links),
        "step_organism_link_rows": len(step_org_rows),
        "step_organism_links": len(org_step_links),
        "complete_pathway_organism_rows": sum(
            1 for r in organism_rows if r["scope"] == "PATHWAY_COMPLETE"),
        "unique_species_matched": len(set(
            r["matched_organism_name"] for r in step_org_rows)),
        "unique_organism_raw_names": len(set(
            r["organism_name_raw"] for r in step_org_rows)),
        "unique_taxids": len(set(r["taxid"] for r in step_org_rows if r["taxid"])),
        "trait_profiles": len(profiles),
        "trait_gold_rows": len(trait_rows),
        "trait_mask_rows": len(mask_rows),
        "trait_scoreable_profile_traits": sum(
            1 for m in mask_rows if m["scoreable"] == "TRUE"),
        "trait_per_item": per_trait,
        "trait_numeric_subfield": {
            "mapping_version": SUBFIELD_MAPPING_VERSION,
            "audit_rows_total": len(audit_rows),
            "subfield_mask_rows_total": len(subfield_mask_rows),
            "subfield_mask_scoreable_cells": sum(
                1 for r in subfield_mask_rows if r["scoreable"] == "TRUE"),
            "subfield_mask_pending_cells": sum(
                1 for r in subfield_mask_rows
                if r["pending_teacher_adjudication"] == "TRUE"),
            "per_trait": subfield_profile_counts,
            "note": ("scalar rows enter the exact-match accuracy denominator; range / "
                     "multi-value rows stay pending teacher adjudication (endpoints "
                     "kept verbatim, no midpoint); text sub-fields are completeness "
                     "material only; predicted rows never promote"),
        },
        "trait_source_coverage": {
            "metatraits_taxids_with_observed": len(mt_stats["taxids_with_observed"]),
            "metatraits_taxids_with_any": len(mt_stats["taxids_with_any"]),
            "bacdive_taxids_covered": len(bacdive),
            "profile_taxids": len(set(p["taxid"] for p in profiles if p["taxid"])),
        },
        "quarantine_case_count": len(quarantine_rows),
        "quarantine_rate": round(len(quarantine_rows) / 150.0, 4),
        "quarantine_reason_distribution": dict(collections.Counter(
            r["reason"] for r in quarantine_rows)),
        "supplementary_candidate_count": len(supp_rows),
        "supplementary_promoted": 0,
        "compounds_without_any_smiles": len(missing_smiles),
        "compounds_without_any_smiles_ids": missing_smiles[:200],
        "counting_keys_note": {
            "unique_species_matched": "matched_organism_name of STEP-scope rows",
            "unique_organism_raw_names": ("organism_name_raw incl. strain variants; "
                                          "same-species different strains are NOT merged"),
            "unique_directed_reactions": "distinct BSY-r ids across formal cases",
        },
    }


def build_lookup_manifest():
    def entry(name, path, role):
        return {"name": name, "path": path, "bytes": os.path.getsize(path),
                "sha256": sha256_file(path), "role": role}
    entries = [
        entry("BIOSYSMOdb_Compounds_chemical_info_v1.0.csv", COMPOUND_INFO_CSV,
              "compound names + SMILES (DATABASE_DIRECT lookup for BSY-c* ids)"),
        entry("BIOSYSMOdb_Pathways_v1.0.csv",
              os.path.join(SOURCE_CSV_DIR, "BIOSYSMOdb_Pathways_v1.0.csv"),
              "pathway membership and names"),
        entry("BIOSYSMOdb_Reactions_v1.0.csv",
              os.path.join(SOURCE_CSV_DIR, "BIOSYSMOdb_Reactions_v1.0.csv"),
              "reaction records incl. Complete Name (BSY-r* lookup)"),
        entry("BIOSYSMOdb_Enzymes_v1.0.csv",
              os.path.join(SOURCE_CSV_DIR, "BIOSYSMOdb_Enzymes_v1.0.csv"),
              "enzyme records incl. EC (BSY-e* lookup)"),
        entry("BIOSYSMOdb_Organisms_v1.0.csv",
              os.path.join(SOURCE_CSV_DIR, "BIOSYSMOdb_Organisms_v1.0.csv"),
              "organism TaxID / Genome ID (lookup)"),
        entry("S4R2_source_evidence.tsv",
              os.path.join(S4R2, "S4R2_source_evidence.tsv"),
              "per-step external evidence rows (KEGG/MetaCyc etc.)"),
        entry("metatraits_ncbi_species_summary_no_predictions.tsv", METATRAITS_OBS,
              "observed-scope trait consensus (OBSERVED status)"),
        entry("metatraits_ncbi_species_summary_all.tsv", METATRAITS_ALL,
              "all-scope trait consensus incl. predictions (PREDICTED background)"),
        entry("bacdive_full_closure_results.jsonl", BACDIVE_JSONL,
              "BacDive closure records (F1/F2/F5/F7/F9-F12 observed fields)"),
        entry("C7_1_long_form_mapping_rerun2.csv", C7_1_MAPPING_LOCAL,
              "frozen trait-name -> F-item mapping used by the trait build"),
    ]
    cache_dir = os.path.join(S4R2, "evidence_cache")
    for name in sorted(os.listdir(cache_dir)):
        path = os.path.join(cache_dir, name)
        if os.path.isfile(path):
            entries.append(entry("S4R2_evidence_cache/" + name, path,
                                 "cached raw evidence page (LITERATURE/DATABASE snapshot)"))
    return {
        "manifest_version": "G1_evidence_lookup_index_v1",
        "generated_utc": now_utc(),
        "policy": ("G3's evidence_lookup_spec will resolve DATABASE_DIRECT record ids "
                   "against these frozen local snapshots only; anything not resolvable "
                   "here counts as an evidence hallucination per teacher section 7.3"),
        "sources": entries,
    }


def build_review_md(counts, quarantine_rows, impact_rows, missing_smiles, mapping,
                    mt_stats, supp_rows, subfield_mask_rows, audit_rows,
                    input_manifest_sha, content_manifest_sha,
                    content_manifest_count, evidence_binding):
    lines = []
    add = lines.append
    add("# G1 gold teacher review material (G1-R1 repaired)\n")
    add("- date: 2026-09-27 (G1-R1 trait sub-field + mutation repair over the "
        "2026-09-26 candidate)")
    add("- builder: %s (local implementation AI; no teacher authority)" % OPERATOR)
    add("- status: **READY_FOR_REVIEW** -- G1 becomes PASS only after the teacher's "
        "gold content audit; nothing in this build self-signs.\n")
    add("## 1. What was frozen\n")
    add("Inputs (read-only, hashed in `G1_inputs.manifest.json`): S4-R2 case status / "
        "pathway & step gold overlays / per-occurrence compound roles / the 26-row "
        "remaining-review queue; S4 accepted enzymes & step organisms & complete "
        "pathway organisms; S3 selected-150; BIOSYSMOdb source CSVs; MetaTraits "
        "species summaries; BacDive full closure 2478; the frozen C7_1 rerun2 "
        "long-form mapping.\n")
    add("## 2. Quarantine (teacher adjudication section 3)\n")
    add("- quarantined cases: **%d / 150 (%.1f%%)**, every one carrying an unresolved "
        "S4-R2 record reproduced verbatim in `quarantine/cases.tsv` (source locator "
        "included). Release requires a case-level teacher audit, never code.\n"
        % (counts["quarantine_case_count"], 100.0 * counts["quarantine_rate"]))
    add("- reason distribution: `%s`\n"
        % json.dumps(counts["quarantine_reason_distribution"], ensure_ascii=False))
    add("- final_n is therefore **%d** (not 150, and not preset: it is the count that "
        "survives quarantine).\n" % counts["final_n"])
    add("## 3. The global BSY-c14673 ALL record\n")
    total_occ = sum(r["occurrence_count"] for r in impact_rows)
    add("- mapped to **%d cases, %d participant occurrences** "
        "(see `quarantine/global_issue_impact.tsv`); every occurrence is a masked "
        "currency / redox participant and **0 occurrences sit in a scored main "
        "substrate/product position**.\n"
        % (len(impact_rows), total_occ))
    add("- program-level assessment: the contradiction (DB name "
        "'Uranium(2+);dihydroxide' vs water-like reaction role) does not touch the "
        "scored main chain of any case, because the S4-R2 occurrence mask keeps it "
        "out of the main-chain gold. **This assessment needs teacher confirmation**: "
        "if the teacher judges the mapping itself unacceptable, the affected formal "
        "cases move to quarantine and final_n drops accordingly.\n")
    add("## 4. Trait gold status (teacher adjudication section 5)\n")
    add("- profile count: **%d** (case-level organism profiles, strain variants NOT "
        "merged); 15-item summary scoreable cells: **%d**.\n"
        % (counts["trait_profiles"], counts["trait_scoreable_profile_traits"]))
    add("- per-item observed / predicted / unknown rows: `%s`\n"
        % json.dumps(counts["trait_per_item"], ensure_ascii=False))
    add("## 5. F2 / F3 / F4 numeric sub-field audit (G1-R1)\n")
    sub = counts["trait_numeric_subfield"]
    add("- the MetaTraits minimum/maximum columns are cross-database consensus "
        "bounds: **minimum == maximum means every contributing database reports the "
        "same number** (an exact observed scalar), minimum != maximum means the "
        "databases disagree (a range of reported values). The earlier build read "
        "only the `value` column and wrongly reported F3 as unscoreable; the "
        "sub-field audit now recomputes from the bound columns. **F3 is NOT an "
        "empty denominator**: it has unanimous scalars for minimum / maximum.\n")
    for trait_id in ("F2", "F3", "F4"):
        block = sub["per_trait"][trait_id]
        add("- **%s** observed source rows %d; predicted-only profiles %d; "
            "adjudication rows `%s`;\n  per sub-field: `%s`\n"
            % (trait_id, block["observed_source_rows"],
               block["predicted_only_profiles"],
               json.dumps(block["adjudication_status_rows"]),
               json.dumps(block["by_target_subfield"])))
    add("- authoritative accuracy denominator for F2/F3/F4 lives in "
        "`trait_subfield_scoreability_mask.tsv` (G3 must read this file, never the "
        "15-item summary boolean). Current totals: scoreable sub-field cells "
        "**%d**, pending-teacher-adjudication cells **%d** of %d cells.\n"
        % (sub["subfield_mask_scoreable_cells"], sub["subfield_mask_pending_cells"],
           sub["subfield_mask_rows_total"]))
    add("- explicit mapping decisions (growth ranges, BacDive ranges, preference "
        "words) are in `trait_numeric_subfield_mapping.tsv` (%s); every ambiguous "
        "mapping stays a teacher decision -- no midpoints, no endpoint promotion, "
        "no category-to-number inference, no predicted promotion.\n"
        % sub["mapping_version"])
    add("- source coverage: MetaTraits observed taxids %d / %d profile taxids; BacDive "
        "closure %d / %d.\n"
        % (counts["trait_source_coverage"]["metatraits_taxids_with_observed"],
           counts["trait_source_coverage"]["profile_taxids"],
           counts["trait_source_coverage"]["bacdive_taxids_covered"],
           counts["trait_source_coverage"]["profile_taxids"]))
    add("- F15 habitat_generalism still has no observed local source (predicted "
        "background only); F14 genome size / GC partial; genome_size_bp has no "
        "local source.\n")
    add("## 6. Compound structures\n")
    add("- formal-case compounds without any SMILES in the frozen source: **%d** "
        "(ids in counts.json; mostly blank-name carrier species like ferredoxins). "
        "Per teacher section 9.2 these are flagged here in G1 for排查, not silently "
        "dropped.\n" % counts["compounds_without_any_smiles"])
    add("## 7. final_n decision for the teacher\n")
    add("- Option A: freeze **n=%d** (降额, disclosed on the report front page).\n"
        % counts["final_n"])
    add("- Option B: 补选 from **%d structurally eligible, currently unused "
        "candidates** (`G1_gold/supplementary_candidates.tsv`). Promotion requires the "
        "same scientific flow (S4 -> S4R1 -> S4R2 graph/role/audit pipeline) run on "
        "the new pathways plus teacher audit; this build promotes **0** candidates "
        "and final_n does not assume any.\n" % len(supp_rows))
    add("- smoke=3题 / pilot=10题 need enough formal cases; at n=%d this holds.\n"
        % counts["final_n"])
    add("## 8. Mutation evidence (G1-R1)\n")
    add("- four adversarial mutations (quarantine case reinserted / cross-case "
        "enzyme contamination / predicted trait promoted to observed / step "
        "organism deleted) are executed against temporary copies by "
        "`scripts/run_g1_mutation_tests.py`; the independent validator must fail "
        "each one through a SEMANTIC check (not a hash mismatch). Evidence: "
        "`G1_gold/mutation_validation_report.json`.\n")
    add("## 9. Open items the teacher must decide\n")
    add("1. Confirm the BSY-c14673 program-level no-main-impact assessment (or move "
        "the mapped cases to quarantine).\n")
    add("2. Choose Option A / Option B for final_n.\n")
    add("3. Confirm the C7_1 rerun2 DRAFT trait-name mapping as the frozen G3 input.\n")
    add("4. Confirm the F5 rule: model returns one best accession; gold holds every "
        "observed BacDive number (G3 freezes the matching rule).\n")
    add("5. **Confirm the F2/F3/F4 sub-field mapping** (`trait_numeric_subfield_"
        "mapping.tsv`): bound rows minimum/maximum -> minimum_c/maximum_c & pH/salinity "
        "minimum/maximum; growth ranges and BacDive temperature ranges kept as "
        "pending endpoints; preference / category words as text only.\n")
    add("6. **Decide the aggregated range records**: rows where contributing "
        "databases disagree (minimum != maximum) and multi-value BacDive strings "
        "are currently RANGE / MULTI_VALUE pending adjudication. Options: treat the "
        "endpoints as multiple accepted exact values, keep them non-scored, or "
        "supply another frozen rule. No midpoint is ever taken.\n")
    add("7. Confirm whether the %d no-SMILES compound ids stay scoreable at the name "
        "layer only (SMILES layer then scores as miss for those steps).\n"
        % counts["compounds_without_any_smiles"])
    add("8. The 24 quarantined cases remain available for the separate quarantine "
        "sub-run (same pipeline, separate budget) per teacher adjudication section 3.\n")
    add("## 10. Evidence-chain seal (G1-R2)\n")
    add("- frozen input manifest (historical, preserved byte-for-byte): "
        "`%s`\n" % input_manifest_sha)
    add("- stable input content manifest `%s` over %d files (no utc / operator / "
        "machine paths; byte-identical across rebuilds; two-generation check in "
        "the builder, recompute check in the validator).\n"
        % (content_manifest_sha, content_manifest_count))
    add("- historical relation: the historical manifest lists the same %d files "
        "with identical sha256 values (program-verified); the two manifests are "
        "not byte-identical (the historical one carries generated_utc / operator "
        "/ absolute paths); transition verified, not assumed.\n"
        % content_manifest_count)
    if (evidence_binding or {}).get("sha256"):
        add("- mutation evidence manifest `%s` binds the mutation report, the "
            "summary, the four logs and the three scripts (validate_g1_gold.py, "
            "run_g1_mutation_tests.py, build_g1_gold.py); the manifest never "
            "lists itself.\n" % evidence_binding["sha256"])
    else:
        add("- mutation evidence manifest: PENDING (mutation rerun required before "
            "the final seal).\n")
    add("- SHA256SUMS covers the canonical gold data files only; the evidence "
        "manifest covers the validation evidence chain.\n")
    add("\n## 11. Gate\n")
    add("`gates/G1_gold.stage_gate.json` carries status READY_FOR_REVIEW with input/"
        "output manifest hashes; `next_stage_allowed=false` until the teacher signs "
        "the gold audit. G2 remains blocked.\n")
    return "\n".join(lines)


if __name__ == "__main__":
    sys.exit(main())
