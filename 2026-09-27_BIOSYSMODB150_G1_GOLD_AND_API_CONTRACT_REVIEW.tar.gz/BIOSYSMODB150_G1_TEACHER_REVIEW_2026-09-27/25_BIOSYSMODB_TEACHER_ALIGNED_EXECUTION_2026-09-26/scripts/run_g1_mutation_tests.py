#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_g1_mutation_tests.py -- G1-R1 repair B: four adversarial mutation tests.

Every mutation:
  * starts from a byte copy of the CANONICAL stage tree in a temp directory;
  * injects exactly ONE change into exactly ONE file;
  * runs the independent validator (validate_g1_gold.py --stage-root <copy>);
  * must FAIL (non-zero exit) AND must hit the expected SEMANTIC check -- a
    hash-only failure is not accepted as detection;
  * leaves the canonical tree untouched (verified by re-hashing afterwards).

Outputs (inside G1_gold/, excluded from SHA256SUMS as validation evidence):
  mutation_validation_report.json
  mutation_validation_summary.tsv
  mutation_logs/<mutation_id>.log
"""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
STAGE = os.path.abspath(os.path.join(HERE, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")
VALIDATOR = os.path.join(HERE, "validate_g1_gold.py")
LOG_DIR = os.path.join(G1, "mutation_logs")

MUTATIONS = [
    ("QUARANTINE_CASE_REINSERTED", "formal_cases.tsv", "formal_set"),
    ("CROSS_CASE_ENZYME_CONTAMINATION", "enzyme_gold.tsv", "enzyme_case_step_fk"),
    ("PREDICTED_TRAIT_PROMOTED_TO_OBSERVED", "trait_gold.tsv",
     "trait_source_status_consistency"),
    ("STEP_ORGANISM_DELETED", "organism_gold.tsv", "step_organism_coverage_per_step"),
]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_lines(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return fh.read().split("\n")


def write_lines(path, lines):
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write("\n".join(lines))


def column_index(header_line, name):
    return header_line.split("\t").index(name)


# --------------------------------------------------------------------------
# one mutation per function: single change, documented locator
# --------------------------------------------------------------------------

def mutate_quarantine_reinserted(g1_dir, quar_dir):
    header = read_lines(os.path.join(g1_dir, "formal_cases.tsv"))[0]
    columns = header.split("\t")
    quar = read_lines(os.path.join(quar_dir, "cases.tsv"))
    quar_header = quar[0].split("\t")
    case_id = quar[1].split("\t")[column_index("\t".join(quar_header),
                                                "original_case_id")]
    row = []
    for name in columns:
        if name == "case_id":
            row.append(case_id)
        elif name == "pathway_id":
            row.append(quar[1].split("\t")[column_index("\t".join(quar_header),
                                                        "pathway_id")])
        elif name == "quarantined":
            row.append("FALSE")
        else:
            row.append("MUTATED")
    path = os.path.join(g1_dir, "formal_cases.tsv")
    lines = read_lines(path)
    while lines and lines[-1] == "":
        lines.pop()
    lines.append("\t".join(row))
    write_lines(path, lines)
    return "appended formal_cases.tsv row case_id=%s (a quarantined case)" % case_id


def mutate_cross_case_enzyme(g1_dir):
    path = os.path.join(g1_dir, "enzyme_gold.tsv")
    lines = read_lines(path)
    header = lines[0]
    case_col = column_index(header, "case_id")
    source_case = lines[1].split("\t")[case_col]
    target_case = None
    for line in lines[1:]:
        if line.strip():
            candidate = line.split("\t")[case_col]
            if candidate != source_case:
                target_case = candidate
                break
    cells = lines[1].split("\t")
    cells[case_col] = target_case
    lines[1] = "\t".join(cells)
    write_lines(path, lines)
    return ("rewrote enzyme_gold.tsv data line 1 case_id %s -> %s while keeping "
            "step_occurrence_id of %s" % (source_case, target_case, source_case))


def mutate_predicted_promoted(g1_dir):
    path = os.path.join(g1_dir, "trait_gold.tsv")
    lines = read_lines(path)
    header = lines[0]
    db_col = column_index(header, "source_database")
    status_col = column_index(header, "value_status")
    for i in range(1, len(lines)):
        cells = lines[i].split("\t")
        if len(cells) == len(header.split("\t")) \
                and cells[db_col] == "METATRAITS_all" \
                and cells[status_col] == "PREDICTED":
            cells[status_col] = "OBSERVED"
            lines[i] = "\t".join(cells)
            write_lines(path, lines)
            return ("rewrote trait_gold.tsv line %d value_status PREDICTED -> "
                    "OBSERVED (source_database=METATRAITS_all)" % (i + 1))
    raise SystemExit("no PREDICTED METATRAITS_all row found to mutate")


def mutate_step_organism_deleted(g1_dir):
    org_path = os.path.join(g1_dir, "organism_gold.tsv")
    org_lines = read_lines(org_path)
    header = org_lines[0]
    scope_col = column_index(header, "scope")
    step_col = column_index(header, "step_occurrence_id")
    target_step = None
    for line in org_lines[1:]:
        cells = line.split("\t")
        if len(cells) > max(scope_col, step_col) and cells[scope_col] == "STEP" \
                and cells[step_col]:
            target_step = cells[step_col]
            break
    kept = [org_lines[0]]
    removed = 0
    for line in org_lines[1:]:
        cells = line.split("\t")
        if len(cells) > max(scope_col, step_col) and cells[scope_col] == "STEP" \
                and cells[step_col] == target_step:
            removed += 1
            continue
        kept.append(line)
    write_lines(org_path, kept)
    return ("deleted %d STEP-scope organism rows for step %s"
            % (removed, target_step))


MUTATORS = {
    "QUARANTINE_CASE_REINSERTED": lambda stage: mutate_quarantine_reinserted(
        os.path.join(stage, "G1_gold"), os.path.join(stage, "quarantine")),
    "CROSS_CASE_ENZYME_CONTAMINATION": lambda stage: mutate_cross_case_enzyme(
        os.path.join(stage, "G1_gold")),
    "PREDICTED_TRAIT_PROMOTED_TO_OBSERVED": lambda stage: mutate_predicted_promoted(
        os.path.join(stage, "G1_gold")),
    "STEP_ORGANISM_DELETED": lambda stage: mutate_step_organism_deleted(
        os.path.join(stage, "G1_gold")),
}


def copy_stage(destination):
    """Copy the canonical stage tree: gold + quarantine + gates + both input
    manifests + the scripts directory (the evidence manifest binds the three
    scripts, so a mutated copy must carry them for the validator to re-check)."""
    for name in ("G1_gold", "quarantine", "gates", "scripts",
                 "G1_inputs.manifest.json", "G1_inputs.content_manifest.json"):
        source = os.path.join(STAGE, name)
        target = os.path.join(destination, name)
        if not os.path.exists(source):
            continue
        if os.path.isdir(source):
            shutil.copytree(source, target)
        else:
            shutil.copyfile(source, target)


def main():
    os.makedirs(LOG_DIR, exist_ok=True)
    print("baseline: hashing canonical G1_gold ...")
    baseline = {}
    for dirpath, dirnames, filenames in os.walk(G1):
        dirnames[:] = [d for d in dirnames if d != "mutation_logs"]
        for name in filenames:
            path = os.path.join(dirpath, name)
            baseline[os.path.relpath(path, G1)] = sha256_file(path)
    print("  %d files hashed" % len(baseline))

    results = []
    for mutation_id, target_file, expected_check in MUTATIONS:
        print("mutation %s ..." % mutation_id)
        tmp = tempfile.mkdtemp(prefix="g1r1_mut_")
        try:
            stage_copy = os.path.join(tmp, "stage")
            os.makedirs(stage_copy)
            copy_stage(stage_copy)
            target_path = os.path.join(stage_copy, "G1_gold", target_file)
            baseline_sha = sha256_file(target_path)
            locator = MUTATORS[mutation_id](stage_copy)
            report_path = os.path.join(tmp, "report.json")
            proc = subprocess.run(
                [sys.executable, VALIDATOR, "--stage-root", stage_copy,
                 "--report", report_path],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout = proc.stdout.decode("utf-8", "replace")
            failures = []
            if os.path.isfile(report_path):
                failures = [f.get("check") for f in
                            json.load(open(report_path, encoding="utf-8"))["failures"]]
            hit_expected = expected_check in failures
            detected = proc.returncode != 0 and hit_expected
            results.append({
                "mutation_id": mutation_id,
                "baseline_file_sha256": baseline_sha,
                "modified_file": "G1_gold/%s" % target_file,
                "mutation_locator": locator,
                "expected_check": expected_check,
                "validator_exit_code": proc.returncode,
                "actual_checks_hit": failures,
                "semantic_detection": hit_expected,
                "detected": detected,
                "canonical_unchanged": None,   # filled after the re-hash below
            })
            with open(os.path.join(LOG_DIR, "%s.log" % mutation_id), "w",
                      encoding="utf-8", newline="\n") as fh:
                fh.write("mutation_id: %s\n" % mutation_id)
                fh.write("expected_check: %s\n" % expected_check)
                fh.write("locator: %s\n" % locator)
                fh.write("validator_exit_code: %d\n" % proc.returncode)
                fh.write("failures (%d):\n" % len(failures))
                for name in failures:
                    fh.write("  - %s\n" % name)
                fh.write("\n--- validator stdout (tail) ---\n")
                fh.write("\n".join(stdout.splitlines()[-40:]))
            print("  exit=%d expected_hit=%s (%d total failures)"
                  % (proc.returncode, hit_expected, len(failures)))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    print("post-check: canonical G1_gold unchanged ...")
    canonical_ok = True
    for rel, sha in baseline.items():
        if sha256_file(os.path.join(G1, rel)) != sha:
            canonical_ok = False
            print("  CHANGED: %s" % rel)
    for result in results:
        result["canonical_unchanged"] = canonical_ok

    detected_count = sum(1 for r in results if r["detected"])
    report = {
        "report_version": "G1_mutation_validation_v1",
        "generated_utc": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "operator": "LOCAL_AI_G1R1_MUTATION_RUNNER",
        "policy": ("each mutation starts from a clean copy, injects one change, and "
                   "must be caught by a SEMANTIC validator check; hash-only "
                   "failures do not count as detection"),
        "mutations": results,
        "detected_count": detected_count,
        "mutation_count": len(results),
        "canonical_unchanged": canonical_ok,
        "all_pass": detected_count == len(results) and canonical_ok,
    }
    with open(os.path.join(G1, "mutation_validation_report.json"), "w",
              encoding="utf-8", newline="\n") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    with open(os.path.join(G1, "mutation_validation_summary.tsv"), "w",
              encoding="utf-8", newline="\n") as fh:
        fh.write("mutation_id\tmodified_file\texpected_check\tvalidator_exit_code\t"
                 "semantic_detection\tdetected\tcanonical_unchanged\n")
        for r in results:
            fh.write("%s\t%s\t%s\t%d\t%s\t%s\t%s\n" % (
                r["mutation_id"], r["modified_file"], r["expected_check"],
                r["validator_exit_code"], r["semantic_detection"], r["detected"],
                r["canonical_unchanged"]))
    print("mutation tests: %d/%d detected; canonical unchanged: %s"
          % (detected_count, len(results), canonical_ok))
    return 0 if report["all_pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
