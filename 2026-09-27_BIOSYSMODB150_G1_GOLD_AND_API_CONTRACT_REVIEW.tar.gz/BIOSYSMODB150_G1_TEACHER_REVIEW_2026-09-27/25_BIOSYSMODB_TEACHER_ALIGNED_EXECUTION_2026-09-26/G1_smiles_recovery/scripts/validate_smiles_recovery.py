#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_smiles_recovery.py -- G1-R3 independent audit of the recovery outputs.

Independent of build_smiles_recovery.py (no shared imports): recomputes the
target set, re-derives the A.1 trace-back straight from BIOSYSMOdb
Reactions.csv, and re-checks every registry/candidate invariant. No network,
no LLM, no gold writes. The report this validator writes is timestamp-free so
that repeated runs are byte-identical (G1-R3 prompt section 7.12).
"""

import collections
import csv
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RECOVERY = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(RECOVERY, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")
REACTIONS_CSV = os.path.join(TASK_ROOT, "00_Authority_Teacher_Plan", "BIOSYSMOdb v2",
                             "BIOSYSMOdb_Reactions_v1.0.csv")

FINAL_STATUSES = {"RECOVERED_EXACT_LOCAL", "RECOVERED_EXACT_EXTERNAL", "CONFLICT_REVIEW",
                  "IDENTITY_AMBIGUOUS", "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE",
                  "UNRESOLVED_NO_AUTHORITATIVE_RECORD"}
ROOT_CAUSES = {"SOURCE_DATA_MISSING_STRUCTURE", "EXTRACTION_OR_MAPPING_ERROR"}

PARTICIPANT_COLUMNS = {
    ("SUBSTRATE", 1): "Substrate 1 ID Biosysmo", ("SUBSTRATE", 2): "Substrate 2 ID Biosysmo",
    ("SUBSTRATE", 3): "Substrate 3 ID Biosysmo", ("SUBSTRATE", 4): "Substrate 4 ID Biosysmo",
    ("PRODUCT", 1): "Product 1 ID Biosysmo", ("PRODUCT", 2): "Product 2 ID Biosysmo",
    ("PRODUCT", 3): "Product 3 ID Biosysmo", ("PRODUCT", 4): "Product 4 ID Biosysmo",
}

FAILURES = []
CHECKS = 0


def check(name, ok, detail=""):
    global CHECKS
    CHECKS += 1
    if not ok:
        FAILURES.append({"check": name, "detail": str(detail)[:400]})
        print("  [FAIL] %s %s" % (name, str(detail)[:200]))
    return ok


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", default=None)
    parser.add_argument("--recovery-root", default=RECOVERY)
    args = parser.parse_args(argv)
    root = os.path.abspath(args.recovery_root)

    print("[1] target set equality with counts.json")
    counts = json.load(open(os.path.join(G1, "counts.json"), encoding="utf-8"))
    expected_ids = list(counts["compounds_without_any_smiles_ids"])
    targets = read_tsv(os.path.join(root, "targets.tsv"))
    decisions = read_tsv(os.path.join(root, "recovery_decisions.tsv"))
    unresolved = read_tsv(os.path.join(root, "unresolved_items.tsv"))
    candidates = read_tsv(os.path.join(root, "recovery_candidates.tsv"))
    registry = read_tsv(os.path.join(root, "source_registry.tsv"))
    summary = json.load(open(os.path.join(root, "local_audit_summary.json"),
                             encoding="utf-8"))
    check("targets_count_32", len(targets) == 32, len(targets))
    check("targets_set_equals_counts",
          sorted(r["biosysmo_id"] for r in targets) == sorted(expected_ids))

    print("[2] one decision per target, nothing dropped or duplicated")
    decision_ids = [r["biosysmo_id"] for r in decisions]
    check("decision_count_32", len(decisions) == 32, len(decisions_ids := decision_ids))
    check("decision_ids_unique", len(set(decision_ids)) == 32)
    check("decision_set_equals_targets",
          sorted(set(decision_ids)) == sorted(expected_ids))
    check("targets_ids_unique", len(set(r["biosysmo_id"] for r in targets)) == 32)
    unresolved_ids = [r["biosysmo_id"] for r in unresolved]
    recovered = {r["biosysmo_id"] for r in decisions
                 if r["final_status"] in ("RECOVERED_EXACT_LOCAL",
                                          "RECOVERED_EXACT_EXTERNAL")}
    check("unresolved_covers_all_non_recovered",
          sorted(unresolved_ids) == sorted(set(expected_ids) - recovered),
          "unresolved=%d expected=%d" % (len(unresolved_ids),
                                         len(set(expected_ids) - recovered)))

    print("[3] trace-back evidence per target")
    for r in targets:
        check("trace_rows_recorded_%s" % r["biosysmo_id"],
              int(r["trace_back_checks"] or 0) >= int(r["occurrence_count"] or 0)
              or int(r["trace_back_checks"] or 0) > 0,
              "checks=%s occ=%s" % (r["trace_back_checks"], r["occurrence_count"]))
        check("trace_reactions_recorded_%s" % r["biosysmo_id"],
              bool((r["trace_back_reaction_ids"] or "").strip()))

    print("[4] independent A.1 trace-back recomputation")
    reaction_gold = read_tsv(os.path.join(G1, "reaction_gold.tsv"))
    target_set = set(expected_ids)
    rows_needed = {}
    for r in reaction_gold:
        if r["compound_id"] in target_set and r["reactions_csv_row"]:
            rows_needed[int(r["reactions_csv_row"])] = r["reaction_id"]
    csv.field_size_limit(1 << 27)
    reactions = {}
    with open(REACTIONS_CSV, encoding="utf-8-sig", newline="") as fh:
        for row_index, row in enumerate(csv.DictReader(fh), start=1):
            if row_index in rows_needed:
                reactions[row_index] = row
    missing_rows = [n for n in rows_needed if n not in reactions]
    check("all_referenced_source_rows_loaded", not missing_rows, missing_rows[:5])
    mismatches = []
    for r in reaction_gold:
        if r["compound_id"] not in target_set or not r["reactions_csv_row"]:
            continue
        source = reactions.get(int(r["reactions_csv_row"]))
        if source is None:
            mismatches.append((r["biosysmo_id"] if 'biosysmo_id' in r else
                               r["compound_id"], "row absent"))
            continue
        if (source.get("Reaction unique ID") or "").strip() != r["reaction_id"]:
            mismatches.append((r["compound_id"], "id mismatch"))
            continue
        column = PARTICIPANT_COLUMNS.get(
            ((r.get("participant_source_side") or "").strip().upper(),
             int(r["participant_position"] or 0)))
        if column and (source.get(column) or "").strip() != r["compound_id"]:
            mismatches.append((r["compound_id"], "participant mismatch"))
            continue
        token = (r.get("aligned_token") or "").strip()
        if token and token.lower() not in (source.get("Complete Name") or "").lower():
            mismatches.append((r["compound_id"], "token missing"))
    check("independent_trace_consistent", not mismatches, mismatches[:5])
    for r in decisions:
        check("root_cause_vocab_%s" % r["biosysmo_id"],
              r["root_cause"] in ROOT_CAUSES)
        check("root_cause_matches_independent_%s" % r["biosysmo_id"],
              (r["root_cause"] == "SOURCE_DATA_MISSING_STRUCTURE")
              == (r["trace_back_status"] == "CONSISTENT"),
              "root_cause=%s trace=%s" % (r["root_cause"], r["trace_back_status"]))
        check("final_status_vocab_%s" % r["biosysmo_id"],
              r["final_status"] in FINAL_STATUSES, r["final_status"])

    print("[5] candidates and proposed gold invariants")
    for r in candidates:
        check("candidate_has_source_%s" % r["biosysmo_id"],
              bool((r.get("source_id") or "").strip()))
    if candidates:
        try:
            from rdkit import Chem
            from rdkit.Chem import inchi as _inchi
            for r in candidates:
                mol = Chem.MolFromSmiles(r["smiles_raw"]) if r["smiles_raw"] else None
                check("candidate_rdkit_parse_%s" % r["biosysmo_id"], mol is not None)
        except ImportError:
            check("rdkit_available_for_candidates", False, "rdkit not installed")
    else:
        print("  (no candidate structures: all conditional candidate checks vacuous)")
    for r in decisions:
        if r["final_status"] in ("IDENTITY_AMBIGUOUS", "CONFLICT_REVIEW",
                                 "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE",
                                 "UNRESOLVED_NO_AUTHORITATIVE_RECORD"):
            check("no_proposed_smiles_%s" % r["biosysmo_id"],
                  not (r["proposed_smiles"] or "").strip(),
                  "status %s must not propose a SMILES" % r["final_status"])
        check("no_fake_smiles_for_not_applicable_%s" % r["biosysmo_id"],
              not (r["final_status"] == "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE"
                   and (r["proposed_smiles"] or "").strip()))

    print("[6] source registry integrity")
    check("registry_rows_present", len(registry) >= 10, len(registry))
    for r in registry:
        check("registry_url_%s" % r["source_id"], bool((r["request_url"] or "").strip()))
        check("registry_utc_%s" % r["source_id"], bool((r["retrieval_utc"] or "").strip()))
        check("registry_sha_%s" % r["source_id"],
              len(r["response_sha256"] or "") == 64)
        snapshot = os.path.join(root, r["raw_snapshot_path"] or "")
        check("registry_snapshot_exists_%s" % r["source_id"],
              os.path.isfile(snapshot), snapshot)
        if os.path.isfile(snapshot):
            check("registry_snapshot_hash_%s" % r["source_id"],
                  sha256_file(snapshot) == r["response_sha256"])
        if (r["returned_smiles"] or "").strip():
            check("registry_smiles_has_inchikey_%s" % r["source_id"],
                  bool((r["returned_inchikey"] or "").strip()))
    recovered_registry = [r for r in registry
                          if (r["returned_smiles"] or "").strip()]
    for r in decisions:
        if r["final_status"] == "RECOVERED_EXACT_EXTERNAL":
            check("recovered_has_registry_row_%s" % r["biosysmo_id"],
                  any(x["biosysmo_id"] == r["biosysmo_id"]
                      for x in recovered_registry))

    print("[7] summary consistency")
    check("summary_total_targets", summary["total_targets"] == 32)
    status_counter = collections.Counter(r["final_status"] for r in decisions)
    for status in FINAL_STATUSES:
        key = {"RECOVERED_EXACT_LOCAL": "recovered_exact_local",
               "RECOVERED_EXACT_EXTERNAL": "recovered_exact_external",
               "CONFLICT_REVIEW": "conflict_review",
               "IDENTITY_AMBIGUOUS": "identity_ambiguous",
               "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE":
                   "not_applicable_non_unique_structure",
               "UNRESOLVED_NO_AUTHORITATIVE_RECORD":
                   "unresolved_no_authoritative_record"}[status]
        check("summary_%s" % key, summary.get(key) == status_counter.get(status, 0),
              "%s: summary=%s actual=%s" % (key, summary.get(key),
                                            status_counter.get(status, 0)))
    root_counter = collections.Counter(r["root_cause"] for r in decisions)
    check("summary_root_causes", summary["root_cause_distribution"] == dict(root_counter))
    impact_counter = collections.Counter(r["g1_impact"] for r in decisions)
    check("summary_impacts", summary["g1_impact_distribution"] == dict(impact_counter))

    print("[8] canonical G1 gold untouched")
    with open(os.path.join(G1, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, name = line.rstrip("\n").split("  ", 1)
                path = os.path.join(G1, name)
                check("canonical_gold_unchanged_%s" % name,
                      os.path.isfile(path) and sha256_file(path) == digest, name)

    print("[9] SHA256SUMS coverage of the recovery directory")
    listed = {}
    with open(os.path.join(root, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, rel = line.rstrip("\n").split("  ", 1)
                listed[rel] = digest
    actual = {}
    for dirpath, dirnames, filenames in os.walk(root):
        for name in filenames:
            if name == "SHA256SUMS":
                continue
            path = os.path.join(dirpath, name)
            actual[os.path.relpath(path, root)] = sha256_file(path)
    check("sha256sums_covers_all_files", sorted(listed) == sorted(actual),
          "missing=%s extra=%s" % (sorted(set(actual) - set(listed))[:5],
                                   sorted(set(listed) - set(actual))[:5]))
    for rel, digest in listed.items():
        check("sha256sums_digest_%s" % rel, actual.get(rel) == digest, rel)

    print()
    report = {
        "overall": "FAIL" if FAILURES else "PASS",
        "checks": CHECKS,
        "failures": FAILURES,
        "recovery_root": root,
    }
    if args.report:
        path = os.path.abspath(args.report)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(report, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")
    if FAILURES:
        print("G1-R3 RECOVERY VALIDATION: FAIL (%d failures of %d checks)"
              % (len(FAILURES), CHECKS))
        return 1
    print("G1-R3 RECOVERY VALIDATION: PASS (%d checks, 0 failures)" % CHECKS)
    return 0


if __name__ == "__main__":
    sys.exit(main())
