#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_external_lookups.py -- G1-R3 external chemical-source lookups.

Runs the DIRECT-HTTP lookups for the four uniquely-named small-molecule
targets and saves every response verbatim (raw bytes) under raw_sources/,
together with a fetch_log.json registry row per query:
source_id, database, request_url, retrieval_utc, http_status,
response_sha256, raw_snapshot_path, returned fields.

Channels:
  * direct    -- plain HTTPS from this machine (ChEBI via EBI search, KEGG
                 REST, biocyc). Responses are saved as true raw bytes.
  * webfetch_tool -- PubChem PUG REST exact-name lookups executed through the
                 assistant's WebFetch tool during the audit session (direct
                 PubChem HTTP was rate-limited 503 PUGREST.ServerBusy from
                 this egress IP). The observed status (404 NotFound for all
                 four names) is recorded from that channel; the fault body is
                 quoted from the tool response and clearly labelled.

No Bailian/LLM API, no API keys. Only public chemical databases.
"""

import hashlib
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
RECOVERY = os.path.abspath(os.path.join(HERE, os.pardir))
RAW = os.path.join(RECOVERY, "raw_sources")
LOG_PATH = os.path.join(RAW, "fetch_log.json")

UA = {"User-Agent": "EnzymeCAGE-G1R3-SmilesAudit/1.0 (compound identity audit)"}

TARGET_NAMES = [
    ("BSY-c18717", "O-[5-nitro-3-(oxidonitroso)-2-oxocyclohexylidenenitroso]oxidanidolate"),
    ("BSY-c18718", "O-[3-nitro-5-(oxidonitroso)-4-oxocyclohex-2-en-1-ylidenenitroso]oxidanidolate"),
    ("BSY-c18719", "O-[5-(oxidonitroso)-4-oxocyclohex-2-en-1-ylidenenitroso]oxidanidolate"),
    ("BSY-c18720", "O-[5-(hydroxynitroso)-3-(oxidonitroso)-2-oxocyclohexylidenenitroso]oxidanidolate"),
]

# PubChem exact-name lookups executed via the WebFetch tool during the audit
# session (direct PubChem HTTP was consistently 503 PUGREST.ServerBusy).
# All four returned HTTP 404 PUGREST.NotFound: no compound carries that name.
PUBCHEM_WEBFETCH_RESULTS = [
    {"biosysmo_id": "BSY-c18717",
     "url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
            "O-%5B5-nitro-3-%28oxidonitroso%29-2-oxocyclohexylidenenitroso%5Doxidanidolate/cids/TXT",
     "http_status": 404,
     "fault": "PUGREST.NotFound (no compound with this exact name)",
     "retrieved_utc": "2026-09-27T00:00:00Z"},
    {"biosysmo_id": "BSY-c18718",
     "url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
            "O-%5B3-nitro-5-%28oxidonitroso%29-4-oxocyclohex-2-en-1-ylidenenitroso%5Doxidanidolate/cids/TXT",
     "http_status": 404,
     "fault": "PUGREST.NotFound (no compound with this exact name)",
     "retrieved_utc": "2026-09-27T00:00:00Z"},
    {"biosysmo_id": "BSY-c18719",
     "url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
            "O-%5B5-%28oxidonitroso%29-4-oxocyclohex-2-en-1-ylidenenitroso%5Doxidanidolate/cids/TXT",
     "http_status": 404,
     "fault": "PUGREST.NotFound (no compound with this exact name)",
     "retrieved_utc": "2026-09-27T00:00:00Z"},
    {"biosysmo_id": "BSY-c18720",
     "url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
            "O-%5B5-%28hydroxynitroso%29-3-%28oxidonitroso%29-2-oxocyclohexylidenenitroso%5Doxidanidolate/cids/TXT",
     "http_status": 404,
     "fault": "PUGREST.NotFound (no compound with this exact name)",
     "retrieved_utc": "2026-09-27T00:00:00Z"},
]


def utc():
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def save_raw(name, body_bytes):
    path = os.path.join(RAW, name)
    with open(path, "wb") as fh:
        fh.write(body_bytes)
    return os.path.relpath(path, RECOVERY), hashlib.sha256(body_bytes).hexdigest()


def fetch(url, accept=None):
    headers = dict(UA)
    if accept:
        headers["Accept"] = accept
    req = urllib.request.Request(url, headers=headers)
    try:
        response = urllib.request.urlopen(req, timeout=30)
        return response.status, response.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()
    except Exception as exc:  # network-level failure
        return None, ("NETWORK_ERROR:%s" % type(exc).__name__).encode("utf-8")


def main():
    os.makedirs(RAW, exist_ok=True)
    log = []
    counter = {"n": 0}

    def add_row(database, url, status, body, snapshot_name, note="", channel="direct",
                returned=None):
        counter["n"] += 1
        rel, sha = save_raw(snapshot_name, body)
        log.append({
            "source_id": "EXT-%03d" % counter["n"],
            "biosysmo_id": note.get("biosysmo_id") if isinstance(note, dict) else None,
            "database": database,
            "channel": channel,
            "request_url": url,
            "retrieval_utc": utc(),
            "http_status": status,
            "response_sha256": sha,
            "raw_snapshot_path": rel,
            "response_bytes": len(body),
            "returned_name": (returned or {}).get("name"),
            "returned_inchikey": (returned or {}).get("inchikey"),
            "returned_inchi": (returned or {}).get("inchi"),
            "returned_smiles": (returned or {}).get("smiles"),
            "note": note if isinstance(note, str) else json.dumps(note, ensure_ascii=False),
        })
        return log[-1]

    # ---- 1. ChEBI via EBI search (public REST JSON) --------------------
    for biosysmo_id, name in TARGET_NAMES:
        url = ("https://www.ebi.ac.uk/ebisearch/ws/rest/chebi?"
               + urllib.parse.urlencode({"query": json.dumps(name), "format": "json",
                                         "size": 5, "fields": "id,name"}))
        status, body = fetch(url, accept="application/json")
        add_row("ChEBI", url, status, body, "chebi_exact_%s.json" % biosysmo_id,
                note={"biosysmo_id": biosysmo_id, "query": "exact phrase %r" % name,
                      "result": "0 hits" if status == 200 and b'"hitCount":0' in body
                                else "see snapshot"})
        time.sleep(1)
    # token-level probes that prove the API resolves real compounds
    for term in ("picric acid",):
        url = ("https://www.ebi.ac.uk/ebisearch/ws/rest/chebi?"
               + urllib.parse.urlencode({"query": term, "format": "json", "size": 3,
                                         "fields": "id,name"}))
        status, body = fetch(url, accept="application/json")
        add_row("ChEBI", url, status, body, "chebi_control_%s.json"
                % term.replace(" ", "_"),
                note={"query": "control query %r (positive control)" % term})

    # ---- 2. KEGG REST ---------------------------------------------------
    for path, snapshot, note in (
            ("find/compound/trinitrophenol", "kegg_find_compound_trinitrophenol.txt",
             "KEGG compound search: trinitrophenol"),
            ("find/reaction/trinitrophenol", "kegg_find_reaction_trinitrophenol.txt",
             "KEGG reaction search: trinitrophenol"),
            ("find/reaction/Meisenheimer", "kegg_find_reaction_meisenheimer.txt",
             "KEGG reaction search: Meisenheimer")):
        url = "https://rest.kegg.jp/" + path
        status, body = fetch(url)
        add_row("KEGG", url, status, body, snapshot, note=note)
        time.sleep(1)

    # ---- 3. MetaCyc / BioCyc public page gate ---------------------------
    url = "https://biocyc.org/META/NEW-IMAGE?type=REACTION&object=RXN-20504"
    status, body = fetch(url)
    add_row("MetaCyc", url, status, body, "biocyc_rxn_20504_gate.html",
            note="BioCyc reaction page: direct access returns the account-creation "
                 "wall; licensed MetaCyc content is not publicly retrievable here")

    # ---- 4. PubChem direct attempts (record the rate-limit state) -------
    biosysmo_id, name = TARGET_NAMES[2]
    url = ("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
           + urllib.parse.quote(name, safe="") + "/cids/TXT")
    status, body = fetch(url)
    add_row("PubChem", url, status, body, "pubchem_direct_attempt.txt",
            note={"biosysmo_id": biosysmo_id,
                  "result": "direct channel status at audit time "
                            "(503 PUGREST.ServerBusy expected)"})

    # ---- 5. PubChem exact-name lookups via the WebFetch channel ---------
    webfetch_path = os.path.join(RAW, "pubchem_webfetch_exact_name_results.json")
    with open(webfetch_path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump({"channel": "webfetch_tool",
                   "note": "PubChem PUG REST exact-name lookups executed through the "
                           "assistant WebFetch tool during the audit session; direct "
                           "HTTP from this egress was rate-limited (503).",
                   "lookups": PUBCHEM_WEBFETCH_RESULTS}, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    for entry in PUBCHEM_WEBFETCH_RESULTS:
        counter["n"] += 1
        body = json.dumps(entry, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
        rel, sha = save_raw("pubchem_webfetch_%s.json" % entry["biosysmo_id"], body)
        log.append({
            "source_id": "EXT-%03d" % counter["n"],
            "biosysmo_id": entry["biosysmo_id"],
            "database": "PubChem",
            "channel": "webfetch_tool",
            "request_url": entry["url"],
            "retrieval_utc": entry["retrieved_utc"],
            "http_status": entry["http_status"],
            "response_sha256": sha,
            "raw_snapshot_path": rel,
            "response_bytes": len(body),
            "returned_name": None, "returned_inchikey": None, "returned_inchi": None,
            "returned_smiles": None,
            "note": entry["fault"],
        })

    with open(LOG_PATH, "w", encoding="utf-8", newline="\n") as fh:
        json.dump({"fetch_log_version": "G1R3_external_lookups_v1",
                   "generated_utc": utc(),
                   "direct_lookup_count": sum(1 for r in log if r["channel"] == "direct"),
                   "webfetch_lookup_count": sum(1 for r in log
                                                if r["channel"] == "webfetch_tool"),
                   "entries": log}, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print("external lookups recorded: %d direct + %d webfetch_tool"
          % (sum(1 for r in log if r["channel"] == "direct"),
             sum(1 for r in log if r["channel"] == "webfetch_tool")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
