#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_smiles_recovery.py -- G1-R3 SMILES recovery audit (offline builder).

Consumes only frozen local inputs plus the already-saved external lookup
evidence (raw_sources/fetch_log.json produced by fetch_external_lookups.py);
this script itself performs zero network calls.

Pipeline (G1-R3 prompt):
  A.1  trace every one of the 32 SMILES-less compounds back to the ORIGINAL
       BIOSYSMOdb Reactions.csv: same participant id in the recorded
       participant column + the aligned Complete-Name token present. This
       separates SOURCE_DATA_MISSING_STRUCTURE from EXTRACTION_OR_MAPPING_ERROR.
  A.2  classify per name semantics (generic carriers / polymers / proteins
       never get a fabricated SMILES) and per main-chain vs auxiliary impact
       (AUXILIARY_STRUCTURE_UNAVAILABLE / CASE_IMPACT_REVIEW /
       MAPPING_REPAIR_REQUIRED).
  §4   the four uniquely-named small molecules carry the recorded external
       lookup evidence; no authoritative record was found -> UNRESOLVED.

The canonical G1 gold is never written to. Everything lands in
G1_smiles_recovery/ only.
"""

import collections
import csv
import datetime
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RECOVERY = os.path.abspath(os.path.join(HERE, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(RECOVERY, os.pardir, os.pardir))
STAGE = os.path.abspath(os.path.join(RECOVERY, os.pardir))

G1 = os.path.join(STAGE, "G1_gold")
BENCH = os.path.join(TASK_ROOT, "23_BIOSYSMODB_150_PATHWAY_FIVE_LLM_API_BENCHMARK_2026-09-24")
S4R1 = os.path.join(BENCH, "S4R1_reviewed_gold")
SOURCE_DIR = os.path.join(TASK_ROOT, "00_Authority_Teacher_Plan", "BIOSYSMOdb v2")
COMPOUND_CSV = os.path.join(SOURCE_DIR, "BIOSYSMOdb_Compounds_chemical_info_v1.0.csv")
REACTIONS_CSV = os.path.join(SOURCE_DIR, "BIOSYSMOdb_Reactions_v1.0.csv")
FETCH_LOG = os.path.join(RECOVERY, "raw_sources", "fetch_log.json")

OPERATOR = "LOCAL_AI_G1R3_EXECUTOR"
RUN_TAG = "2026-09-27"

FINAL_STATUSES = ("RECOVERED_EXACT_LOCAL", "RECOVERED_EXACT_EXTERNAL", "CONFLICT_REVIEW",
                  "IDENTITY_AMBIGUOUS", "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE",
                  "UNRESOLVED_NO_AUTHORITATIVE_RECORD")
ROOT_CAUSES = ("SOURCE_DATA_MISSING_STRUCTURE", "EXTRACTION_OR_MAPPING_ERROR")
IMPACTS = ("AUXILIARY_STRUCTURE_UNAVAILABLE", "CASE_IMPACT_REVIEW",
           "MAPPING_REPAIR_REQUIRED", "MAIN_STRUCTURE_UNRESOLVED_PENDING_REVIEW")

# deterministic name-semantics classification (documented, no guessing):
AMBIGUOUS_NAMES = {
    "BSY-c18820": "NAD(P)+ deliberately denotes NAD+ OR NADP+ (two structures)",
    "BSY-c18831": "NAD(P)H deliberately denotes NADH OR NADPH (two structures)",
    "BSY-c18758": "factor 420 is a cofactor family (F420-0/1/2 glutamate variants)",
    "BSY-c18845": "factor 420 is a cofactor family (F420-0/1/2 glutamate variants)",
}
AMBIGUOUS_MARKERS = ("NAD(P)", "factor 420")
NA_MARKERS = ("ferredoxin", "putidaredoxin", "cytochrome", "flavoprotein",
              "two electron carrier", "iron-sulfur", "MadF", "corrinoid",
              "E2 protein", "acyl-carrier", "nylon", "heparin", "heparan",
              "dermatan", "electron-transfer quinol", "electron-transfer quinone",
              "a quinol", "a quinone", "electron carrier")
EXTERNAL_NAME_PREFIX = "O-["


def utc():
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def write_tsv(path, rows, columns):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, delimiter="\t",
                                lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({c: ("" if row.get(c) is None else str(row.get(c)))
                             for c in columns})


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)
        fh.write("\n")


# --------------------------------------------------------------------------
# load inputs
# --------------------------------------------------------------------------

def load_targets():
    counts = json.load(open(os.path.join(G1, "counts.json"), encoding="utf-8"))
    ids = list(counts["compounds_without_any_smiles_ids"])
    if len(ids) != counts["compounds_without_any_smiles"]:
        raise SystemExit("counts.json id list disagrees with its own count")
    return ids


def load_compound_rows(ids):
    csv.field_size_limit(1 << 27)
    found = {}
    with open(COMPOUND_CSV, encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            cid = (row.get("BIOSYSMO ID") or "").strip()
            if cid in ids and cid not in found:
                found[cid] = row
    missing = [i for i in ids if i not in found]
    if missing:
        raise SystemExit("targets missing from the compound CSV: %s" % missing)
    return found


def load_reaction_rows(ids):
    """Reactions.csv rows referenced by the gold, indexed by csv row number.

    utf-8-sig: the file carries a BOM glued to the first header cell; without
    it the "Reaction unique ID" lookups silently return None and every trace
    check would false-fail.
    """
    rows_needed = {}
    for r in read_tsv(os.path.join(G1, "reaction_gold.tsv")):
        if r["compound_id"] in ids and r["reactions_csv_row"]:
            rows_needed[int(r["reactions_csv_row"])] = r["reaction_id"]
    csv.field_size_limit(1 << 27)
    reactions = {}
    with open(REACTIONS_CSV, encoding="utf-8-sig", newline="") as fh:
        # reactions_csv_row counts 1-based DATA rows (BSY-r00001 is data row 1),
        # so enumerate starts at 1; utf-8-sig strips the BOM on the header.
        for row_index, row in enumerate(csv.DictReader(fh), start=1):
            if row_index in rows_needed:
                reactions[row_index] = row
    return rows_needed, reactions


PARTICIPANT_COLUMNS = {
    ("SUBSTRATE", 1): "Substrate 1 ID Biosysmo", ("SUBSTRATE", 2): "Substrate 2 ID Biosysmo",
    ("SUBSTRATE", 3): "Substrate 3 ID Biosysmo", ("SUBSTRATE", 4): "Substrate 4 ID Biosysmo",
    ("PRODUCT", 1): "Product 1 ID Biosysmo", ("PRODUCT", 2): "Product 2 ID Biosysmo",
    ("PRODUCT", 3): "Product 3 ID Biosysmo", ("PRODUCT", 4): "Product 4 ID Biosysmo",
}


def trace_back(ids, reaction_gold, reactions):
    """A.1: verify each occurrence against the original reaction row."""
    evidence = collections.defaultdict(lambda: {
        "reaction_ids": set(), "rows": set(), "checks": 0, "mismatches": [],
        "tokens": set(), "complete_names": set(),
    })
    for r in reaction_gold:
        cid = r["compound_id"]
        if cid not in ids:
            continue
        row_no = r.get("reactions_csv_row")
        if not row_no:
            evidence[cid]["mismatches"].append(
                "%s: no reactions_csv_row in gold" % r["step_occurrence_id"])
            continue
        row_no = int(row_no)
        source = reactions.get(row_no)
        ev = evidence[cid]
        ev["reaction_ids"].add(r["reaction_id"])
        ev["rows"].add(row_no)
        if source is None:
            ev["mismatches"].append("row %d absent from source" % row_no)
            continue
        if source.get("Reaction unique ID", "").strip() != r["reaction_id"]:
            ev["mismatches"].append(
                "row %d reaction id %s != gold %s"
                % (row_no, source.get("Reaction unique ID"), r["reaction_id"]))
        column = PARTICIPANT_COLUMNS.get(
            ((r.get("participant_source_side") or "").strip().upper(),
             int(r["participant_position"] or 0)))
        participant_value = (source.get(column) or "").strip() if column else None
        if participant_value != cid:
            ev["mismatches"].append(
                "row %d %s=%r != %s" % (row_no, column, participant_value, cid))
        complete_name = (source.get("Complete Name") or "")
        token = (r.get("aligned_token") or "").strip()
        ev["complete_names"].add(complete_name[:200])
        if token and token.lower() not in complete_name.lower():
            ev["mismatches"].append(
                "row %d complete name lacks token %r" % (row_no, token[:60]))
        else:
            ev["tokens"].add(token)
        ev["checks"] += 1
    return evidence


def classify(cid, name):
    if cid in AMBIGUOUS_NAMES or any(m in name for m in AMBIGUOUS_MARKERS):
        return "IDENTITY_AMBIGUOUS", AMBIGUOUS_NAMES.get(
            cid, "name denotes a family of distinct structures")
    lowered = name.lower()
    if any(m in lowered for m in (s.lower() for s in NA_MARKERS)):
        return "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE", (
            "generic carrier / protein-bound cluster / polymer / mixture / class "
            "name: no unique small-molecule structure exists to encode")
    if name.startswith(EXTERNAL_NAME_PREFIX):
        return "PENDING_EXTERNAL", "uniquely named small molecule: external lookup"
    return "PENDING_EXTERNAL", "name not covered by the local rule table; external lookup"


def main():
    print("[1] loading frozen inputs ...")
    ids = load_targets()
    compound_rows = load_compound_rows(ids)
    reaction_gold = read_tsv(os.path.join(G1, "reaction_gold.tsv"))
    resolution = read_tsv(os.path.join(S4R1, "compound_resolution.tsv"))
    adapters = read_tsv(os.path.join(S4R1, "compound_identity_adapters.tsv"))
    res_by = {r["compound_id"]: r for r in resolution}
    ada_by = {r["compound_id"]: r for r in adapters}
    fetch_log = json.load(open(FETCH_LOG, encoding="utf-8"))
    external_by_target = collections.defaultdict(list)
    for entry in fetch_log["entries"]:
        if entry.get("biosysmo_id"):
            external_by_target[entry["biosysmo_id"]].append(entry)

    print("[2] A.1 source trace-back over Reactions.csv ...")
    rows_needed, reactions = load_reaction_rows(ids)
    evidence = trace_back(ids, reaction_gold, reactions)

    print("[3] classification + A.2 impact ...")
    occurrences = collections.defaultdict(lambda: {
        "occ": 0, "cases": [], "steps": [], "names": collections.Counter(),
        "roles": collections.Counter(), "main_positions": [],
        "masked_only": True,
    })
    for r in reaction_gold:
        cid = r["compound_id"]
        if cid not in ids:
            continue
        occ = occurrences[cid]
        occ["occ"] += 1
        if r["case_id"] not in occ["cases"]:
            occ["cases"].append(r["case_id"])
        if r["step_occurrence_id"] not in occ["steps"]:
            occ["steps"].append(r["step_occurrence_id"])
        occ["names"][r["identity_name"]] += 1
        occ["roles"][r["role_label"]] += 1
        if r["role_label"] in ("MAIN_SUBSTRATE", "MAIN_PRODUCT", "BYPRODUCT"):
            occ["main_positions"].append((r["case_id"], r["step_occurrence_id"],
                                          r["role_label"]))
            occ["masked_only"] = False

    target_rows = []
    decision_rows = []
    unresolved_rows = []
    candidate_rows = []
    status_counter = collections.Counter()
    root_cause_counter = collections.Counter()
    impact_counter = collections.Counter()
    case_impact = collections.defaultdict(set)
    rdkit_candidates = 0

    for cid in ids:
        compound = compound_rows[cid]
        occ = occurrences[cid]
        name = occ["names"].most_common(1)[0][0] if occ["names"] else ""
        ev = evidence[cid]
        trace_consistent = not ev["mismatches"]
        root_cause = "SOURCE_DATA_MISSING_STRUCTURE" if trace_consistent \
            else "EXTRACTION_OR_MAPPING_ERROR"
        root_cause_counter[root_cause] += 1

        final_status, applicability_note = classify(cid, name)
        if final_status == "PENDING_EXTERNAL":
            entries = external_by_target.get(cid, [])
            found = [e for e in entries
                     if e.get("http_status") == 200 and e.get("returned_smiles")]
            if found:
                final_status = "RECOVERED_EXACT_EXTERNAL"
            else:
                final_status = "UNRESOLVED_NO_AUTHORITATIVE_RECORD"
        status_counter[final_status] += 1

        # A.2 impact
        if root_cause == "EXTRACTION_OR_MAPPING_ERROR":
            impact = "MAPPING_REPAIR_REQUIRED"
        elif occ["masked_only"]:
            impact = "AUXILIARY_STRUCTURE_UNAVAILABLE"
        elif final_status in ("RECOVERED_EXACT_LOCAL", "RECOVERED_EXACT_EXTERNAL"):
            impact = "MAIN_STRUCTURE_RECOVERED_PENDING_REVIEW"
        else:
            impact = "CASE_IMPACT_REVIEW"
            for case_id, step_id, role in occ["main_positions"]:
                case_impact[case_id].add((cid, step_id, role))
        impact_counter[impact] += 1

        external_note = ""
        if cid in external_by_target:
            external_note = "; ".join(
                "%s(%s) status=%s" % (e["database"], e["channel"], e["http_status"])
                for e in external_by_target[cid])

        target_rows.append({
            "biosysmo_id": cid,
            "occurrence_count": occ["occ"],
            "case_ids": "|".join(occ["cases"]),
            "step_occurrence_ids": "|".join(occ["steps"]),
            "original_cmpdname": compound.get("cmpdname", ""),
            "original_synonym": compound.get("cmpdsynonym", ""),
            "original_inchi": compound.get("inchi", ""),
            "original_inchikey": compound.get("inchikey", ""),
            "original_formula": compound.get("mf", ""),
            "original_isosmiles": compound.get("isosmiles", ""),
            "original_canonicalsmiles": compound.get("canonicalsmiles", ""),
            "derived_identity_name": name,
            "role_distribution": json.dumps(dict(occ["roles"]), ensure_ascii=False),
            "s4r1_resolved_name": (res_by.get(cid, {}) or {}).get("resolved_name", ""),
            "s4r1_resolution_status": (res_by.get(cid, {}) or {}).get("resolution_status", ""),
            "trace_back_checks": ev["checks"],
            "trace_back_reaction_ids": "|".join(sorted(ev["reaction_ids"])),
        })

        decision_rows.append({
            "biosysmo_id": cid,
            "original_name": name,
            "final_status": final_status,
            "proposed_smiles": "",
            "proposed_source_id": "",
            "proposed_record_id": "",
            "identity_status": ("exact name token present in the source reaction "
                                "Complete Name (trace-back consistent)"
                                if trace_consistent else "trace-back mismatch"),
            "structure_applicability": applicability_note,
            "local_lookup_status": "S4R1_RESOLVED_NAME_ONLY_NO_STRUCTURE"
            if cid in res_by else "NO_LOCAL_STRUCTURE",
            "external_lookup_status": external_note or "NOT_ATTEMPTED_NOT_A_UNIQUE_SMALL_MOLECULE",
            "root_cause": root_cause,
            "g1_impact": impact,
            "main_position_case_ids": "|".join(sorted(set(
                c for c, _s, _r in occ["main_positions"]))),
            "main_position_occurrence_count": len(occ["main_positions"]),
            "trace_back_status": "CONSISTENT" if trace_consistent else "MISMATCH",
            "trace_back_mismatch_detail": " | ".join(ev["mismatches"][:5]),
            "conflict_count": 0,
            "reviewer": OPERATOR,
            "review_notes": ("root cause %s; impact %s; %s"
                             % (root_cause, impact, applicability_note)),
        })

        if final_status != "RECOVERED_EXACT_LOCAL" and final_status != "RECOVERED_EXACT_EXTERNAL":
            unresolved_rows.append({
                "biosysmo_id": cid,
                "original_name": name,
                "final_status": final_status,
                "root_cause": root_cause,
                "g1_impact": impact,
                "reason": applicability_note if final_status in (
                    "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE", "IDENTITY_AMBIGUOUS") else (
                    "no authoritative public record found: PubChem exact name 404, "
                    "ChEBI 0 hits, KEGG pathway absent, MetaCyc gated (see "
                    "source_registry.tsv)" if final_status == "UNRESOLVED_NO_AUTHORITATIVE_RECORD"
                    else ""),
            })

    print("[4] writing outputs ...")
    write_tsv(os.path.join(RECOVERY, "targets.tsv"), target_rows, [
        "biosysmo_id", "occurrence_count", "case_ids", "step_occurrence_ids",
        "original_cmpdname", "original_synonym", "original_inchi", "original_inchikey",
        "original_formula", "original_isosmiles", "original_canonicalsmiles",
        "derived_identity_name", "role_distribution", "s4r1_resolved_name",
        "s4r1_resolution_status", "trace_back_checks", "trace_back_reaction_ids"])
    # no candidate structure was recovered from an authoritative source; the
    # file ships header-only with the fact documented in the summary/report.
    write_tsv(os.path.join(RECOVERY, "recovery_candidates.tsv"), candidate_rows, [
        "biosysmo_id", "candidate_id", "candidate_name", "smiles_raw",
        "smiles_isomeric_canonical", "smiles_achiral_canonical", "inchi", "inchikey",
        "source_id", "source_type", "source_record_id", "identity_match_basis",
        "rdkit_parse_ok", "decision_status", "confidence", "notes"])
    write_tsv(os.path.join(RECOVERY, "recovery_decisions.tsv"), decision_rows, [
        "biosysmo_id", "original_name", "final_status", "proposed_smiles",
        "proposed_source_id", "proposed_record_id", "identity_status",
        "structure_applicability", "local_lookup_status", "external_lookup_status",
        "root_cause", "g1_impact", "main_position_case_ids",
        "main_position_occurrence_count", "trace_back_status",
        "trace_back_mismatch_detail", "conflict_count", "reviewer", "review_notes"])
    write_tsv(os.path.join(RECOVERY, "unresolved_items.tsv"), unresolved_rows, [
        "biosysmo_id", "original_name", "final_status", "root_cause", "g1_impact",
        "reason"])

    registry_rows = []
    for entry in fetch_log["entries"]:
        registry_rows.append({
            "source_id": entry["source_id"],
            "biosysmo_id": entry.get("biosysmo_id") or "",
            "database": entry["database"],
            "channel": entry["channel"],
            "request_url": entry["request_url"],
            "retrieval_utc": entry["retrieval_utc"],
            "http_status": entry["http_status"],
            "response_sha256": entry["response_sha256"],
            "raw_snapshot_path": entry["raw_snapshot_path"],
            "response_bytes": entry["response_bytes"],
            "returned_name": entry.get("returned_name") or "",
            "returned_inchikey": entry.get("returned_inchikey") or "",
            "returned_inchi": entry.get("returned_inchi") or "",
            "returned_smiles": entry.get("returned_smiles") or "",
            "note": entry["note"] if isinstance(entry["note"], str)
                    else json.dumps(entry["note"], ensure_ascii=False),
        })
    write_tsv(os.path.join(RECOVERY, "source_registry.tsv"), registry_rows, [
        "source_id", "biosysmo_id", "database", "channel", "request_url",
        "retrieval_utc", "http_status", "response_sha256", "raw_snapshot_path",
        "response_bytes", "returned_name", "returned_inchikey", "returned_inchi",
        "returned_smiles", "note"])

    rdkit_version = ""
    try:
        import rdkit
        rdkit_version = rdkit.__version__
    except ImportError:
        rdkit_version = "NOT_INSTALLED"

    summary = {
        "audit_version": "G1R3_smiles_recovery_v1",
        "generated_utc": utc(),
        "operator": OPERATOR,
        "total_targets": len(ids),
        "status_distribution": dict(status_counter),
        "root_cause_distribution": dict(root_cause_counter),
        "g1_impact_distribution": dict(impact_counter),
        "recovered_exact_local": status_counter.get("RECOVERED_EXACT_LOCAL", 0),
        "recovered_exact_external": status_counter.get("RECOVERED_EXACT_EXTERNAL", 0),
        "conflict_review": status_counter.get("CONFLICT_REVIEW", 0),
        "identity_ambiguous": status_counter.get("IDENTITY_AMBIGUOUS", 0),
        "not_applicable_non_unique_structure":
            status_counter.get("NOT_APPLICABLE_NON_UNIQUE_STRUCTURE", 0),
        "unresolved_no_authoritative_record":
            status_counter.get("UNRESOLVED_NO_AUTHORITATIVE_RECORD", 0),
        "external_lookup_count": len(registry_rows),
        "external_lookup_channels": dict(collections.Counter(
            r["channel"] for r in registry_rows)),
        "rdkit_version": rdkit_version,
        "rdkit_candidates_validated": 0,
        "rdkit_candidates_total": 0,
        "case_impact_review_cases": sorted(case_impact.keys()),
        "case_impact_detail": {
            case: ["%s@%s(%s)" % (cid, step, role)
                   for cid, step, role in sorted(items)]
            for case, items in sorted(case_impact.items())},
        "auxiliary_only_target_count": sum(
            1 for d in decision_rows if d["g1_impact"] == "AUXILIARY_STRUCTURE_UNAVAILABLE"),
        "canonical_g1_gold_modified": False,
        "proposed_for_g1_review_count": 0,
        "note": ("zero candidates are proposed for gold: the four uniquely named "
                 "small molecules have no authoritative public record (PubChem "
                 "404, ChEBI 0, KEGG absent, MetaCyc gated), and every other "
                 "target is a generic carrier / polymer / protein / ambiguous "
                 "family for which no unique SMILES may be fabricated"),
    }
    write_json(os.path.join(RECOVERY, "local_audit_summary.json"), summary)

    report = build_report(summary, decision_rows, case_impact, registry_rows)
    with open(os.path.join(RECOVERY, "local_audit_report.md"), "w",
              encoding="utf-8", newline="\n") as fh:
        fh.write(report)

    print("[5] SHA256SUMS ...")
    sums = []
    for dirpath, dirnames, filenames in os.walk(RECOVERY):
        dirnames[:] = sorted(d for d in dirnames)
        for name in sorted(filenames):
            if name == "SHA256SUMS":
                continue
            path = os.path.join(dirpath, name)
            rel = os.path.relpath(path, RECOVERY)
            sums.append((sha256_file(path), rel))
    with open(os.path.join(RECOVERY, "SHA256SUMS"), "w", encoding="utf-8",
              newline="\n") as fh:
        for digest, rel in sorted(sums, key=lambda x: x[1]):
            fh.write("%s  %s\n" % (digest, rel))
    print("G1-R3 recovery audit complete: %d targets, %d registry rows, "
          "%d case-impact cases" % (len(ids), len(registry_rows), len(case_impact)))
    return 0


def build_report(summary, decision_rows, case_impact, registry_rows):
    lines = []
    add = lines.append
    add("# G1-R3 SMILES recovery audit (local + external)\n")
    add("- date: %s | operator: %s | status cap: READY_FOR_REVIEW\n"
        % (RUN_TAG, OPERATOR))
    add("- canonical G1 gold untouched: every result lives in G1_smiles_recovery/ "
        "only; nothing is merged without a teacher decision.\n")
    add("\n## 1. Target set\n")
    add("- total_targets = **%d** (read from G1_gold/counts.json "
        "compounds_without_any_smiles_ids; no id added or dropped).\n"
        % summary["total_targets"])
    add("\n## 2. A.1 source trace-back (root cause)\n")
    add("- every occurrence was traced back to the original "
        "BIOSYSMOdb_Reactions_v1.0.csv row: participant id at the recorded "
        "Substrate/Product column + the aligned Complete-Name token.\n")
    add("- root-cause distribution: `%s`\n"
        % json.dumps(summary["root_cause_distribution"]))
    add("- all 32 are **SOURCE_DATA_MISSING_STRUCTURE**: the original Compounds "
        "rows themselves are blank (cmpdname / inchi / inchikey / smiles all "
        "empty) while the reaction participant references are perfectly "
        "consistent -- this is a database content gap, NOT an extraction or "
        "mapping error on our side. No MAPPING_REPAIR_REQUIRED item exists.\n"
        if summary["root_cause_distribution"].get("EXTRACTION_OR_MAPPING_ERROR", 0) == 0
        else "- see decisions for mismatch details.\n")
    add("\n## 3. Final status distribution\n")
    add("```json\n%s\n```\n" % json.dumps(summary["status_distribution"], indent=2))
    add("\n## 4. What the 32 actually are\n")
    add("- 24 generic species (ferredoxin / putidaredoxin / cytochrome / "
        "flavoprotein / two-electron carrier / quinol / quinone / nylon / "
        "heparin / heparan / dermatan polymers): no unique small-molecule "
        "structure exists -> NOT_APPLICABLE_NON_UNIQUE_STRUCTURE.\n")
    add("- 4 ambiguous notations (NAD(P)+, NAD(P)H, factor 420 oxidized/reduced): "
        "each denotes a family of distinct structures -> IDENTITY_AMBIGUOUS.\n")
    add("- 4 uniquely named small molecules (the 2,4,6-trinitrophenol degradation "
        "Meisenheimer-complex intermediates of case BIOPATH150_115): external "
        "lookup executed, **no authoritative public record found** -> "
        "UNRESOLVED_NO_AUTHORITATIVE_RECORD.\n")
    add("\n## 5. External lookup evidence (source_registry.tsv / raw_sources/)\n")
    add("- %d lookups recorded (%s).\n"
        % (summary["external_lookup_count"],
           json.dumps(summary["external_lookup_channels"])))
    add("- PubChem PUG REST exact-name: HTTP 404 NotFound for all four names "
        "(channel webfetch_tool; direct HTTP was rate-limited 503 "
        "PUGREST.ServerBusy from this egress, also recorded).\n")
    add("- ChEBI via EBI search: exact-phrase 0 hits for all four names; "
        "positive control 'picric acid' resolves (CHEBI:46149) proving the "
        "channel works.\n")
    add("- KEGG REST: no trinitrophenol / Meisenheimer compounds or reactions "
        "at all (the pathway is absent from KEGG).\n")
    add("- MetaCyc / BioCyc: the referenced reaction pages (e.g. RXN-20504) sit "
        "behind the account wall; licensed content cannot be cited as a public "
        "snapshot.\n")
    add("\n## 6. A.2 impact on G1 (per case and step)\n")
    add("- auxiliary-only (masked currency/redox positions, never in the scored "
        "main chain): **%d targets** -> AUXILIARY_STRUCTURE_UNAVAILABLE; their "
        "cases stay untouched and they never enter the main-chain SMILES "
        "denominator.\n" % summary["auxiliary_only_target_count"])
    add("- main-chain species without a determinable unique structure: "
        "**CASE_IMPACT_REVIEW** in %d cases:\n"
        % len(summary["case_impact_review_cases"]))
    for case, items in sorted(case_impact.items()):
        add("  - %s: %s\n" % (case, ", ".join(
            sorted("%s@%s(%s)" % (cid, step, role) for cid, step, role in items))))
    add("- teacher options for those cases: (a) keep the case and score the "
        "affected steps at the name layer only (SMILES layer scores as miss), "
        "(b) quarantine the case, (c) supply a licensed structure source "
        "(e.g. MetaCyc) for teacher-side review. No option is taken by this "
        "audit.\n")
    add("\n## 7. Proposed for G1 review\n")
    add("- **0 candidates** are proposed: no recovered structure exists. "
        "recovery_candidates.tsv ships header-only. Nothing invalidates the "
        "current reaction_gold / counts / manifest hashes; the only G1 change "
        "this round could eventually trigger (after teacher decisions) is the "
        "CASE_IMPACT_REVIEW outcome for the 5 listed cases.\n")
    add("- RDKit %s available; %d/%d candidates validated (no candidates).\n"
        % (summary["rdkit_version"], summary["rdkit_candidates_validated"],
           summary["rdkit_candidates_total"]))
    add("\n## 8. Gate\n")
    add("- G1 remains READY_FOR_REVIEW; G2 not started; zero Bailian/LLM API "
        "calls; the G1 canonical gold files were not modified.\n")
    return "\n".join(lines)


if __name__ == "__main__":
    sys.exit(main())
