# G1-R3 SMILES recovery audit (local + external)

- date: 2026-09-27 | operator: LOCAL_AI_G1R3_EXECUTOR | status cap: READY_FOR_REVIEW

- canonical G1 gold untouched: every result lives in G1_smiles_recovery/ only; nothing is merged without a teacher decision.


## 1. Target set

- total_targets = **32** (read from G1_gold/counts.json compounds_without_any_smiles_ids; no id added or dropped).


## 2. A.1 source trace-back (root cause)

- every occurrence was traced back to the original BIOSYSMOdb_Reactions_v1.0.csv row: participant id at the recorded Substrate/Product column + the aligned Complete-Name token.

- root-cause distribution: `{"SOURCE_DATA_MISSING_STRUCTURE": 32}`

- all 32 are **SOURCE_DATA_MISSING_STRUCTURE**: the original Compounds rows themselves are blank (cmpdname / inchi / inchikey / smiles all empty) while the reaction participant references are perfectly consistent -- this is a database content gap, NOT an extraction or mapping error on our side. No MAPPING_REPAIR_REQUIRED item exists.


## 3. Final status distribution

```json
{
  "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE": 24,
  "UNRESOLVED_NO_AUTHORITATIVE_RECORD": 4,
  "IDENTITY_AMBIGUOUS": 4
}
```


## 4. What the 32 actually are

- 24 generic species (ferredoxin / putidaredoxin / cytochrome / flavoprotein / two-electron carrier / quinol / quinone / nylon / heparin / heparan / dermatan polymers): no unique small-molecule structure exists -> NOT_APPLICABLE_NON_UNIQUE_STRUCTURE.

- 4 ambiguous notations (NAD(P)+, NAD(P)H, factor 420 oxidized/reduced): each denotes a family of distinct structures -> IDENTITY_AMBIGUOUS.

- 4 uniquely named small molecules (the 2,4,6-trinitrophenol degradation Meisenheimer-complex intermediates of case BIOPATH150_115): external lookup executed, **no authoritative public record found** -> UNRESOLVED_NO_AUTHORITATIVE_RECORD.


## 5. External lookup evidence (source_registry.tsv / raw_sources/)

- 14 lookups recorded ({"direct": 10, "webfetch_tool": 4}).

- PubChem PUG REST exact-name: HTTP 404 NotFound for all four names (channel webfetch_tool; direct HTTP was rate-limited 503 PUGREST.ServerBusy from this egress, also recorded).

- ChEBI via EBI search: exact-phrase 0 hits for all four names; positive control 'picric acid' resolves (CHEBI:46149) proving the channel works.

- KEGG REST: no trinitrophenol / Meisenheimer compounds or reactions at all (the pathway is absent from KEGG).

- MetaCyc / BioCyc: the referenced reaction pages (e.g. RXN-20504) sit behind the account wall; licensed content cannot be cited as a public snapshot.


## 6. A.2 impact on G1 (per case and step)

- auxiliary-only (masked currency/redox positions, never in the scored main chain): **23 targets** -> AUXILIARY_STRUCTURE_UNAVAILABLE; their cases stay untouched and they never enter the main-chain SMILES denominator.

- main-chain species without a determinable unique structure: **CASE_IMPACT_REVIEW** in 5 cases:

  - BIOPATH150_040: BSY-c18709@BIOPATH150_040__S06__BSY-r03792(MAIN_PRODUCT), BSY-c18709@BIOPATH150_040__S07__BSY-r03803(MAIN_SUBSTRATE), BSY-c18777@BIOPATH150_040__S06__BSY-r03792(MAIN_SUBSTRATE)

  - BIOPATH150_115: BSY-c18717@BIOPATH150_115__S07__BSY-r03730(MAIN_PRODUCT), BSY-c18718@BIOPATH150_115__S05__BSY-r03498(MAIN_PRODUCT), BSY-c18718@BIOPATH150_115__S06__BSY-r03499(MAIN_SUBSTRATE), BSY-c18719@BIOPATH150_115__S02__BSY-r02564(MAIN_PRODUCT), BSY-c18719@BIOPATH150_115__S03__BSY-r03315(MAIN_PRODUCT), BSY-c18719@BIOPATH150_115__S04__BSY-r03331(MAIN_SUBSTRATE), BSY-c18720@BIOPATH150_115__S02__BSY-r02564(MAIN_SUBSTRATE), BSY-c18720@BIOPATH150_115__S06__BSY-r03499(MAIN_PRODUCT), BSY-c18720@BIOPATH150_115__S07__BSY-r03730(MAIN_SUBSTRATE)

  - BIOPATH150_116: BSY-c18698@BIOPATH150_116__S05__BSY-r03731(MAIN_SUBSTRATE)

  - BIOPATH150_117: BSY-c18728@BIOPATH150_117__S01__BSY-r01522(MAIN_PRODUCT), BSY-c18728@BIOPATH150_117__S01__BSY-r01522(MAIN_SUBSTRATE), BSY-c18728@BIOPATH150_117__S02__BSY-r01523(MAIN_SUBSTRATE)

  - BIOPATH150_118: BSY-c18795@BIOPATH150_118__S03__BSY-r03732(MAIN_SUBSTRATE)

- teacher options for those cases: (a) keep the case and score the affected steps at the name layer only (SMILES layer scores as miss), (b) quarantine the case, (c) supply a licensed structure source (e.g. MetaCyc) for teacher-side review. No option is taken by this audit.


## 7. Proposed for G1 review

- **0 candidates** are proposed: no recovered structure exists. recovery_candidates.tsv ships header-only. Nothing invalidates the current reaction_gold / counts / manifest hashes; the only G1 change this round could eventually trigger (after teacher decisions) is the CASE_IMPACT_REVIEW outcome for the 5 listed cases.

- RDKit 2026.03.5 available; 0/0 candidates validated (no candidates).


## 8. Gate

- G1 remains READY_FOR_REVIEW; G2 not started; zero Bailian/LLM API calls; the G1 canonical gold files were not modified.
