#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_identity_traceback.py -- independent validator for the G1-R3-R1 audit.

Independent of the builder: recomputes the per-occurrence trace-back straight
from BIOSYSMOdb Reactions.csv, re-derives the adapter-mismatch classification,
re-hashes the G1 canonical gold and the reused R3 external evidence. No
network, no LLM, no writes outside its optional report path. The report is
timestamp-free and deterministic: repeated runs are byte-identical.
"""

import collections
import csv
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
R1 = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(R1, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")
R3 = os.path.join(STAGE, "G1_smiles_recovery")
S4R1 = os.path.join(TASK_ROOT, "23_BIOSYSMODB_150_PATHWAY_FIVE_LLM_API_BENCHMARK_"
                               "2026-09-24", "S4R1_reviewed_gold")
REACTIONS_CSV = os.path.join(TASK_ROOT, "00_Authority_Teacher_Plan", "BIOSYSMOdb v2",
                             "BIOSYSMOdb_Reactions_v1.0.csv")

PARTICIPANT_COLUMNS = {
    ("SUBSTRATE", 1): "Substrate 1 ID Biosysmo", ("SUBSTRATE", 2): "Substrate 2 ID Biosysmo",
    ("SUBSTRATE", 3): "Substrate 3 ID Biosysmo", ("SUBSTRATE", 4): "Substrate 4 ID Biosysmo",
    ("PRODUCT", 1): "Product 1 ID Biosysmo", ("PRODUCT", 2): "Product 2 ID Biosysmo",
    ("PRODUCT", 3): "Product 3 ID Biosysmo", ("PRODUCT", 4): "Product 4 ID Biosysmo",
}

FAILURES = []
CHECKS = 0


def check(name, ok, detail=""):
    global CHECKS
    CHECKS += 1
    if not ok:
        FAILURES.append({"check": name, "detail": str(detail)[:400]})
        print("  [FAIL] %s %s" % (name, str(detail)[:200]))
    return ok


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", default=None)
    args = parser.parse_args(argv)

    print("[1] target set complete and unique")
    counts = json.load(open(os.path.join(G1, "counts.json"), encoding="utf-8"))
    expected_ids = list(counts["compounds_without_any_smiles_ids"])
    decisions = read_tsv(os.path.join(R1, "recovery_decisions.tsv"))
    trace = read_tsv(os.path.join(R1, "identity_traceback.tsv"))
    mismatches = read_tsv(os.path.join(R1, "identity_adapter_mismatches.tsv"))
    summary = json.load(open(os.path.join(R1, "local_audit_summary.json"),
                             encoding="utf-8"))
    decision_ids = [r["biosysmo_id"] for r in decisions]
    check("decision_count_32", len(decisions) == 32, len(decisions))
    check("decision_ids_unique", len(set(decision_ids)) == 32)
    check("decision_set_equals_counts",
          sorted(decision_ids) == sorted(expected_ids))

    print("[2] every G1 occurrence traceable to source row + participant column")
    reaction_gold = read_tsv(os.path.join(G1, "reaction_gold.tsv"))
    target_set = set(expected_ids)
    occurrences = [r for r in reaction_gold if r["compound_id"] in target_set]
    check("trace_rows_cover_all_occurrences", len(trace) == len(occurrences),
          "trace=%d occurrences=%d" % (len(trace), len(occurrences)))
    trace_keys = set((r["case_id"], r["step_occurrence_id"], r["compound_id"],
                      r["participant_side"], r["participant_position"])
                     for r in trace)
    expected_keys = set((r["case_id"], r["step_occurrence_id"], r["compound_id"],
                         (r.get("participant_source_side") or "").strip().upper(),
                         r["participant_position"])
                        for r in occurrences)
    check("trace_keys_match_occurrences", trace_keys == expected_keys)

    # independent re-derivation from Reactions.csv
    rows_needed = {}
    for r in occurrences:
        if r["reactions_csv_row"]:
            rows_needed[int(r["reactions_csv_row"])] = r["reaction_id"]
    csv.field_size_limit(1 << 27)
    reactions = {}
    with open(REACTIONS_CSV, encoding="utf-8-sig", newline="") as fh:
        for row_index, row in enumerate(csv.DictReader(fh), start=1):
            if row_index in rows_needed:
                reactions[row_index] = row
    check("all_source_rows_loaded",
          all(n in reactions for n in rows_needed))

    print("[3] identity evidence per occurrence (independent recomputation)")
    resolution = {r["compound_id"]: r for r in read_tsv(
        os.path.join(S4R1, "compound_resolution.tsv"))}
    adapters = {r["compound_id"]: r for r in read_tsv(
        os.path.join(S4R1, "compound_identity_adapters.tsv"))}
    bad_evidence = []
    for r in occurrences:
        cid = r["compound_id"]
        source = reactions.get(int(r["reactions_csv_row"]))
        if source is None:
            bad_evidence.append((cid, "row absent"))
            continue
        side = (r.get("participant_source_side") or "").strip().upper()
        column = PARTICIPANT_COLUMNS.get((side, int(r["participant_position"] or 0)))
        if not column or (source.get(column) or "").strip() != cid:
            bad_evidence.append((cid, "participant mismatch"))
            continue
        complete_name = (source.get("Complete Name") or "").lower()
        g1_name = (r["identity_name"] or "")
        token = (r.get("aligned_token") or "").strip()
        resolved_name = (resolution.get(cid, {}) or {}).get("resolved_name") or ""
        adapter_row = adapters.get(cid)
        ok = (token and token.lower() in complete_name) \
            or (g1_name and g1_name.lower() in complete_name) \
            or (adapter_row and adapter_row.get("decision_status")
                == "RESOLVED_WITH_SOURCE_ADAPTER" and resolved_name == g1_name) \
            or (resolved_name and resolved_name == g1_name)
        if not ok:
            bad_evidence.append((cid, r["step_occurrence_id"]))
    check("identity_evidence_recomputed", not bad_evidence,
          bad_evidence[:5])
    check("all_trace_rows_consistent",
          all(r["occurrence_consistent"] == "TRUE" for r in trace))

    print("[4] the two known adapter mismatches are detected")
    mismatch_ids = sorted(r["biosysmo_id"] for r in mismatches)
    check("mismatch_count_2", len(mismatches) == 2, mismatch_ids)
    check("mismatch_ids_exact", mismatch_ids == ["BSY-c18918", "BSY-c18932"],
          mismatch_ids)
    for r in mismatches:
        check("mismatch_type_%s" % r["biosysmo_id"],
              r["mismatch_type"] == "S4R1_RESOLUTION_BOUND_ANOTHER_PARTICIPANT_TOKEN")
        check("mismatch_not_contaminated_%s" % r["biosysmo_id"],
              r["g1_canonical_contaminated"] == "FALSE")
    # independent proof: the S4R1 resolved name is another participant's token
    for cid, wrong_name in (("BSY-c18918", "dioxygen"), ("BSY-c18932", "H2O")):
        own_rows = [r for r in occurrences if r["compound_id"] == cid]
        resolved = (resolution.get(cid, {}) or {}).get("resolved_name") or ""
        check("s4r1_resolved_name_%s" % cid, resolved == wrong_name,
              "resolved=%r expected=%r" % (resolved, wrong_name))
        ok_wrong = all((resolved.lower() != r["identity_name"].lower())
                       for r in own_rows)
        in_cn = any(wrong_name.lower()
                    in (reactions[int(r["reactions_csv_row"])]
                        .get("Complete Name") or "").lower()
                    for r in own_rows)
        check("wrong_name_is_foreign_token_%s" % cid, ok_wrong and in_cn)

    print("[5] BSY-c18728 is a normalized variant, not a mismatch")
    check("c18728_not_in_mismatches", "BSY-c18728" not in mismatch_ids)
    c18728 = [r for r in decisions if r["biosysmo_id"] == "BSY-c18728"]
    check("c18728_normalized_variant",
          c18728 and c18728[0]["root_cause"] == "NORMALIZED_NAME_VARIANT",
          c18728[0]["root_cause"] if c18728 else "missing")
    resolved_28 = (resolution.get("BSY-c18728", {}) or {}).get("resolved_name") or ""
    own_tokens_28 = set((r.get("aligned_token") or "").strip()
                        for r in occurrences if r["compound_id"] == "BSY-c18728")
    check("c18728_umbrella_is_substring_of_variants",
          resolved_28 and all(resolved_28.lower() in token.lower()
                              for token in own_tokens_28 if token),
          "resolved=%r tokens=%s" % (resolved_28, sorted(own_tokens_28)))

    print("[6] G1 canonical gold unchanged")
    with open(os.path.join(G1, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, name = line.rstrip("\n").split("  ", 1)
                path = os.path.join(G1, name)
                check("canonical_gold_unchanged_%s" % name,
                      os.path.isfile(path) and sha256_file(path) == digest, name)

    print("[7] R3 external lookup evidence intact (14 lookups)")
    fetch_log = json.load(open(os.path.join(R3, "raw_sources", "fetch_log.json"),
                               encoding="utf-8"))
    check("r3_lookup_count_14", len(fetch_log["entries"]) == 14,
          len(fetch_log["entries"]))
    for entry in fetch_log["entries"]:
        snapshot = os.path.join(R3, entry["raw_snapshot_path"])
        check("r3_snapshot_exists_%s" % entry["source_id"], os.path.isfile(snapshot))
        if os.path.isfile(snapshot):
            check("r3_snapshot_hash_%s" % entry["source_id"],
                  sha256_file(snapshot) == entry["response_sha256"])
    with open(os.path.join(R3, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, rel = line.rstrip("\n").split("  ", 1)
                path = os.path.join(R3, rel)
                check("r3_file_unchanged_%s" % rel,
                      os.path.isfile(path) and sha256_file(path) == digest, rel)

    print("[8] summary consistency")
    root_counter = collections.Counter(r["root_cause"] for r in decisions)
    check("summary_root_causes", summary["root_cause_distribution"] == dict(root_counter))
    status_counter = collections.Counter(r["final_recovery_status"] for r in decisions)
    check("summary_recovery_statuses",
          summary["recovery_status_distribution"] == dict(status_counter))
    impact_counter = collections.Counter(r["g1_impact"] for r in decisions)
    check("summary_impacts", summary["g1_impact_distribution"] == dict(impact_counter))
    check("summary_contamination_false", summary["g1_canonical_contaminated"] is False)
    check("summary_mismatch_ids",
          sorted(summary["identity_adapter_mismatches"]) == ["BSY-c18918", "BSY-c18932"])

    print("[9] SHA256SUMS coverage")
    listed = {}
    with open(os.path.join(R1, "SHA256SUMS"), encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                digest, rel = line.rstrip("\n").split("  ", 1)
                listed[rel] = digest
    actual = {}
    for dirpath, dirnames, filenames in os.walk(R1):
        for name in filenames:
            if name == "SHA256SUMS":
                continue
            path = os.path.join(dirpath, name)
            actual[os.path.relpath(path, R1)] = sha256_file(path)
    check("sha256sums_covers_all_files", sorted(listed) == sorted(actual),
          "missing=%s extra=%s" % (sorted(set(actual) - set(listed))[:5],
                                   sorted(set(listed) - set(actual))[:5]))
    for rel, digest in sorted(listed.items()):
        check("sha256sums_digest_%s" % rel, actual.get(rel) == digest, rel)

    print()
    report = {
        "overall": "FAIL" if FAILURES else "PASS",
        "checks": CHECKS,
        "failures": FAILURES,
        "recovery_root": R1,
    }
    if args.report:
        path = os.path.abspath(args.report)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(report, fh, ensure_ascii=False, indent=2, sort_keys=True)
            fh.write("\n")
    if FAILURES:
        print("G1-R3-R1 VALIDATION: FAIL (%d failures of %d checks)"
              % (len(FAILURES), CHECKS))
        return 1
    print("G1-R3-R1 VALIDATION: PASS (%d checks, 0 failures)" % CHECKS)
    return 0


if __name__ == "__main__":
    sys.exit(main())
