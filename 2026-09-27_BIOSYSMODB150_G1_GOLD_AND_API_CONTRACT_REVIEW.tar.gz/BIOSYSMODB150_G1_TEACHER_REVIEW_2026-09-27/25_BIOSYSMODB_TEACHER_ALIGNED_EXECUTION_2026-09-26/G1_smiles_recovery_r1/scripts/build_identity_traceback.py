#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_identity_traceback.py -- G1-R3-R1 identity-adapter mismatch repair audit.

Deterministic (no timestamps in outputs): two runs produce byte-identical
files. Consumes only frozen inputs; zero network; zero LLM; writes only under
G1_smiles_recovery_r1/ (the original G1_smiles_recovery/ is preserved).

Per-occurrence trace-back with the 5-way root cause vocabulary:
  SOURCE_DATA_MISSING_STRUCTURE
  EXTRACTION_OR_MAPPING_ERROR             (S4R1 resolution bound another
                                           participant's Complete-Name token,
                                           e.g. BSY-c18918 'dioxygen' /
                                           BSY-c18932 'H2O')
  NORMALIZED_NAME_VARIANT                 (BSY-c18728: occurrence names carry
                                           (n)/(n-1)/substitution variants, the
                                           resolution name is an umbrella label)
  EXTERNAL_NAME_ADAPTER_BUT_OCCURRENCE_CONSISTENT
                                          (BSY-c18914/c18934: the name comes
                                           from a frozen KEGG adapter and G1
                                           occurrences match it)

G1 canonical contamination is evaluated occurrence by occurrence; the
expected verdict is FALSE (the mis-bindings live ONLY in the S4R1 resolution
table). If contamination were TRUE the build stops and reports
G1_CANONICAL_REPAIR_REQUIRED without touching anything.
"""

import collections
import csv
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
R1 = os.path.abspath(os.path.join(HERE, os.pardir))
STAGE = os.path.abspath(os.path.join(R1, os.pardir))
TASK_ROOT = os.path.abspath(os.path.join(STAGE, os.pardir))
G1 = os.path.join(STAGE, "G1_gold")
R3 = os.path.join(STAGE, "G1_smiles_recovery")
BENCH = os.path.join(TASK_ROOT, "23_BIOSYSMODB_150_PATHWAY_FIVE_LLM_API_BENCHMARK_2026-09-24")
S4R1 = os.path.join(BENCH, "S4R1_reviewed_gold")
SOURCE_DIR = os.path.join(TASK_ROOT, "00_Authority_Teacher_Plan", "BIOSYSMOdb v2")
REACTIONS_CSV = os.path.join(SOURCE_DIR, "BIOSYSMOdb_Reactions_v1.0.csv")

RUN_TAG = "2026-09-27"
OPERATOR = "LOCAL_AI_G1R3R1_EXECUTOR"

PARTICIPANT_COLUMNS = {
    ("SUBSTRATE", 1): "Substrate 1 ID Biosysmo", ("SUBSTRATE", 2): "Substrate 2 ID Biosysmo",
    ("SUBSTRATE", 3): "Substrate 3 ID Biosysmo", ("SUBSTRATE", 4): "Substrate 4 ID Biosysmo",
    ("PRODUCT", 1): "Product 1 ID Biosysmo", ("PRODUCT", 2): "Product 2 ID Biosysmo",
    ("PRODUCT", 3): "Product 3 ID Biosysmo", ("PRODUCT", 4): "Product 4 ID Biosysmo",
}

ROOT_CAUSES = ("SOURCE_DATA_MISSING_STRUCTURE", "EXTRACTION_OR_MAPPING_ERROR",
               "NORMALIZED_NAME_VARIANT",
               "EXTERNAL_NAME_ADAPTER_BUT_OCCURRENCE_CONSISTENT")

# recovery-status name rules (identical semantics to the R3 audit)
AMBIGUOUS_MARKERS = ("NAD(P)", "factor 420")
NA_MARKERS = ("ferredoxin", "putidaredoxin", "cytochrome", "flavoprotein",
              "two electron carrier", "iron-sulfur", "MadF", "corrinoid",
              "E2 protein", "acyl-carrier", "nylon", "heparin", "heparan",
              "dermatan", "electron-transfer quinol", "electron-transfer quinone",
              "a quinol", "a quinone", "electron carrier")
EXTERNAL_NAME_PREFIX = "O-["


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_tsv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def write_tsv(path, rows, columns):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, delimiter="\t",
                                lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({c: ("" if row.get(c) is None else str(row.get(c)))
                             for c in columns})


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2, sort_keys=True)
        fh.write("\n")


def load_reactions(rows_needed):
    csv.field_size_limit(1 << 27)
    reactions = {}
    with open(REACTIONS_CSV, encoding="utf-8-sig", newline="") as fh:
        for row_index, row in enumerate(csv.DictReader(fh), start=1):
            if row_index in rows_needed:
                reactions[row_index] = row
    return reactions


def participant_tokens(source, exclude_id):
    """All participant ids of a source reaction row except exclude_id."""
    others = []
    for key, column in PARTICIPANT_COLUMNS.items():
        value = (source.get(column) or "").strip()
        if value and value != exclude_id:
            others.append((key, value))
    return others


def main():
    print("[1] loading frozen inputs ...")
    counts = json.load(open(os.path.join(G1, "counts.json"), encoding="utf-8"))
    target_ids = list(counts["compounds_without_any_smiles_ids"])
    target_set = set(target_ids)
    reaction_gold = read_tsv(os.path.join(G1, "reaction_gold.tsv"))
    resolution = {r["compound_id"]: r for r in read_tsv(
        os.path.join(S4R1, "compound_resolution.tsv"))}
    adapters = {r["compound_id"]: r for r in read_tsv(
        os.path.join(S4R1, "compound_identity_adapters.tsv"))}
    r3_summary = json.load(open(os.path.join(R3, "local_audit_summary.json"),
                                encoding="utf-8"))

    occurrences = [r for r in reaction_gold if r["compound_id"] in target_set]
    rows_needed = {}
    for r in occurrences:
        if r["reactions_csv_row"]:
            rows_needed[int(r["reactions_csv_row"])] = r["reaction_id"]
    reactions = load_reactions(rows_needed)
    missing = [n for n in rows_needed if n not in reactions]
    if missing:
        raise SystemExit("source reaction rows not found: %s" % missing[:5])

    print("[2] per-occurrence trace-back ...")
    trace_rows = []
    contamination = []
    per_target = collections.defaultdict(lambda: {
        "own_tokens": set(), "resolved_name": "", "adapter": None,
        "complete_names": set(), "reaction_ids": set(), "columns": set(),
        "g1_names": set(), "occurrence_count": 0, "occ_consistent": 0,
        "roles": collections.Counter(), "main_positions": [],
        "cases": set(), "steps": set(),
    })

    for r in occurrences:
        cid = r["compound_id"]
        t = per_target[cid]
        t["occurrence_count"] += 1
        t["cases"].add(r["case_id"])
        t["steps"].add(r["step_occurrence_id"])
        t["g1_names"].add(r["identity_name"])
        t["roles"][r["role_label"]] += 1
        if r["role_label"] in ("MAIN_SUBSTRATE", "MAIN_PRODUCT", "BYPRODUCT"):
            t["main_positions"].append((r["case_id"], r["step_occurrence_id"],
                                        r["role_label"]))
        row_index = int(r["reactions_csv_row"])
        source = reactions[row_index]
        t["reaction_ids"].add(r["reaction_id"])
        side = (r.get("participant_source_side") or "").strip().upper()
        position = int(r["participant_position"] or 0)
        column = PARTICIPANT_COLUMNS.get((side, position))
        t["columns"].add("%s %d" % (side, position))
        participant_value = (source.get(column) or "").strip() if column else ""
        complete_name = (source.get("Complete Name") or "")
        t["complete_names"].add(complete_name)
        token = (r.get("aligned_token") or "").strip()
        if token:
            t["own_tokens"].add(token)
        g1_name = r["identity_name"]
        token_in_cn = token and token.lower() in complete_name.lower()
        g1_in_cn = g1_name and g1_name.lower() in complete_name.lower()
        # external-adapter case: the name is not in the Complete Name at all,
        # but a frozen external adapter supplied it and G1 matches it
        adapter_row = adapters.get(cid)
        external_ok = bool(
            adapter_row
            and adapter_row.get("decision_status") == "RESOLVED_WITH_SOURCE_ADAPTER"
            and (resolution.get(cid, {}) or {}).get("resolved_name") == g1_name)
        # blank-name case: the Complete Name does not name this participant at
        # all (align_method UNALIGNED); the identity is the FROZEN S4-derived
        # name (S4R1 resolution), so matching it is consistent, not pollution
        resolved_name = (resolution.get(cid, {}) or {}).get("resolved_name") or ""
        derived_ok = bool(resolved_name and resolved_name == g1_name
                          and not token_in_cn and not g1_in_cn)
        if token_in_cn or g1_in_cn:
            evidence = "COMPLETE_NAME_TOKEN"
        elif external_ok:
            evidence = "FROZEN_EXTERNAL_ADAPTER"
        elif derived_ok:
            evidence = "S4_FROZEN_DERIVED_NAME"
        else:
            evidence = "NO_IDENTITY_EVIDENCE"
        occurrence_consistent = bool(participant_value == cid and
                                     evidence != "NO_IDENTITY_EVIDENCE")
        if participant_value != cid:
            contamination.append((cid, r["step_occurrence_id"], "participant mismatch"))
        elif evidence == "NO_IDENTITY_EVIDENCE":
            contamination.append((cid, r["step_occurrence_id"],
                                  "no identity evidence in source or frozen tables"))
        else:
            t["occ_consistent"] += 1
        trace_rows.append({
            "case_id": r["case_id"],
            "step_occurrence_id": r["step_occurrence_id"],
            "reaction_id": r["reaction_id"],
            "reactions_csv_row": row_index,
            "participant_side": side,
            "participant_position": position,
            "participant_column": column or "",
            "participant_id_in_source": participant_value,
            "participant_id_matches": "TRUE" if participant_value == cid else "FALSE",
            "compound_id": cid,
            "aligned_token": token,
            "g1_identity_name": g1_name,
            "complete_name_excerpt": complete_name[:200],
            "identity_evidence": evidence,
            "occurrence_consistent": "TRUE" if occurrence_consistent else "FALSE",
        })

    if contamination:
        # never auto-repair: report and stop (prompt section 4)
        write_json(os.path.join(R1, "G1_CANONICAL_REPAIR_REQUIRED.json"), {
            "contaminated_occurrences": ["%s@%s(%s)" % c for c in contamination],
            "action": "STOP: G1 canonical reaction_gold is polluted; teacher "
                      "decision required on the rebuild scope",
        })
        raise SystemExit("G1_CANONICAL_REPAIR_REQUIRED: %d contaminated occurrences"
                         % len(contamination))

    print("[3] root-cause classification ...")
    mismatch_rows = []
    decision_rows = []
    root_counter = collections.Counter()
    for cid in target_ids:
        t = per_target[cid]
        resolved_name = (resolution.get(cid, {}) or {}).get("resolved_name") or ""
        t["resolved_name"] = resolved_name
        adapter_row = adapters.get(cid)
        own_tokens = sorted(t["own_tokens"])
        g1_names = sorted(t["g1_names"])
        complete_names = sorted(t["complete_names"])
        rl = resolved_name.lower()

        if adapter_row and adapter_row.get("decision_status") == "RESOLVED_WITH_SOURCE_ADAPTER" \
                and resolved_name and resolved_name in g1_names \
                and not any(rl in cn.lower() for cn in complete_names):
            root_cause = "EXTERNAL_NAME_ADAPTER_BUT_OCCURRENCE_CONSISTENT"
            mismatch_type = ""
        elif own_tokens and resolved_name and rl != own_tokens[0].lower() \
                and all(rl in token.lower() for token in own_tokens):
            root_cause = "NORMALIZED_NAME_VARIANT"
            mismatch_type = ""
        elif resolved_name and own_tokens and all(
                rl != token.lower() for token in own_tokens) \
                and any(rl in cn.lower() for cn in complete_names):
            root_cause = "EXTRACTION_OR_MAPPING_ERROR"
            mismatch_type = "S4R1_RESOLUTION_BOUND_ANOTHER_PARTICIPANT_TOKEN"
        else:
            root_cause = "SOURCE_DATA_MISSING_STRUCTURE"
            mismatch_type = ""
        root_counter[root_cause] += 1

        # recovery status layer (same semantics as R3)
        name = g1_names[0] if g1_names else ""
        if any(m in name for m in AMBIGUOUS_MARKERS):
            final_status = "IDENTITY_AMBIGUOUS"
        elif any(m in name.lower() for m in (s.lower() for s in NA_MARKERS)):
            final_status = "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE"
        elif name.startswith(EXTERNAL_NAME_PREFIX):
            final_status = "UNRESOLVED_NO_AUTHORITATIVE_RECORD"
        else:
            final_status = "UNRESOLVED_NO_AUTHORITATIVE_RECORD"

        masked_only = not t["main_positions"]
        if masked_only:
            # masked currency/redox position: the case stays untouched; the
            # S4R1 repair requirement (if any) lives in the mismatch table
            impact = "AUXILIARY_STRUCTURE_UNAVAILABLE"
        else:
            impact = "CASE_IMPACT_REVIEW"

        decision_rows.append({
            "biosysmo_id": cid,
            "g1_identity_names": "|".join(g1_names),
            "s4r1_resolved_name": resolved_name,
            "root_cause": root_cause,
            "final_recovery_status": final_status,
            "occurrence_count": t["occurrence_count"],
            "occurrence_consistent_count": t["occ_consistent"],
            "g1_canonical_contaminated": "FALSE",
            "g1_impact": impact,
            "main_position_case_ids": "|".join(sorted(set(
                c for c, _s, _r in t["main_positions"]))),
            "reviewer": OPERATOR,
            "review_notes": "root cause %s; recovery status %s; impact %s"
                            % (root_cause, final_status, impact),
        })

        if root_cause == "EXTRACTION_OR_MAPPING_ERROR":
            mismatch_rows.append({
                "biosysmo_id": cid,
                "s4r1_resolved_name": resolved_name,
                "g1_identity_names": "|".join(g1_names),
                "raw_reaction_identity_names": "|".join(own_tokens),
                "mismatch_type": mismatch_type,
                "source_reaction_ids": "|".join(sorted(t["reaction_ids"])),
                "source_columns": "|".join(sorted(t["columns"])),
                "source_locators": "|".join(
                    "BIOSYSMOdb_Reactions_v1.0.csv data-row %d" % n
                    for n in sorted(rows_needed)
                    if rows_needed[n] in t["reaction_ids"]),
                "g1_canonical_contaminated": "FALSE",
                "recommended_action": "S4R1_ADAPTER_REPAIR_REQUIRED (record only: "
                                      "S4R1 is frozen read-only; G1 occurrences are "
                                      "already correct; no gold change needed)",
            })

    print("[4] writing products ...")
    write_tsv(os.path.join(R1, "identity_traceback.tsv"), trace_rows, [
        "case_id", "step_occurrence_id", "reaction_id", "reactions_csv_row",
        "participant_side", "participant_position", "participant_column",
        "participant_id_in_source", "participant_id_matches", "compound_id",
        "aligned_token", "g1_identity_name", "complete_name_excerpt",
        "identity_evidence", "occurrence_consistent"])
    write_tsv(os.path.join(R1, "identity_adapter_mismatches.tsv"), mismatch_rows, [
        "biosysmo_id", "s4r1_resolved_name", "g1_identity_names",
        "raw_reaction_identity_names", "mismatch_type", "source_reaction_ids",
        "source_columns", "source_locators", "g1_canonical_contaminated",
        "recommended_action"])
    write_tsv(os.path.join(R1, "recovery_decisions.tsv"), decision_rows, [
        "biosysmo_id", "g1_identity_names", "s4r1_resolved_name", "root_cause",
        "final_recovery_status", "occurrence_count", "occurrence_consistent_count",
        "g1_canonical_contaminated", "g1_impact", "main_position_case_ids",
        "reviewer", "review_notes"])

    status_counter = collections.Counter(d["final_recovery_status"] for d in decision_rows)
    impact_counter = collections.Counter(d["g1_impact"] for d in decision_rows)
    summary = {
        "audit_version": "G1R3R1_identity_traceback_v1",
        "run_tag": RUN_TAG,
        "operator": OPERATOR,
        "total_targets": len(target_ids),
        "traceback_rows": len(trace_rows),
        "root_cause_distribution": dict(root_counter),
        "recovery_status_distribution": dict(status_counter),
        "g1_impact_distribution": dict(impact_counter),
        "identity_adapter_mismatch_count": len(mismatch_rows),
        "identity_adapter_mismatches": [m["biosysmo_id"] for m in mismatch_rows],
        "g1_canonical_contaminated": False,
        "normalized_name_variant_ids": [d["biosysmo_id"] for d in decision_rows
                                        if d["root_cause"] == "NORMALIZED_NAME_VARIANT"],
        "external_adapter_consistent_ids": [d["biosysmo_id"] for d in decision_rows
                                            if d["root_cause"]
                                            == "EXTERNAL_NAME_ADAPTER_BUT_OCCURRENCE_CONSISTENT"],
        "case_impact_review_cases": sorted(set(
            d["main_position_case_ids"] for d in decision_rows
            if d["g1_impact"] == "CASE_IMPACT_REVIEW" and d["main_position_case_ids"])),
        "auxiliary_only_target_count": impact_counter.get(
            "AUXILIARY_STRUCTURE_UNAVAILABLE", 0),
        "external_lookup_evidence": {
            "reused_from": "G1_smiles_recovery/raw_sources/fetch_log.json",
            "lookup_count": r3_summary.get("external_lookup_count", 0),
            "recovered_external": 0,
            "note": "R3 evidence reused verbatim; nothing re-queried; no "
                    "structure recovered (c18918/c18932 are name-binding "
                    "errors, not recoveries)"},
        "canonical_g1_gold_modified": False,
        "determinism": "outputs carry no timestamps; two runs are byte-identical",
    }
    write_json(os.path.join(R1, "local_audit_summary.json"), summary)

    report = build_report(summary, decision_rows, mismatch_rows)
    with open(os.path.join(R1, "local_audit_report.md"), "w",
              encoding="utf-8", newline="\n") as fh:
        fh.write(report)

    print("[5] SHA256SUMS ...")
    sums = []
    for dirpath, dirnames, filenames in os.walk(R1):
        for name in sorted(filenames):
            if name == "SHA256SUMS":
                continue
            path = os.path.join(dirpath, name)
            sums.append((sha256_file(path), os.path.relpath(path, R1)))
    with open(os.path.join(R1, "SHA256SUMS"), "w", encoding="utf-8",
              newline="\n") as fh:
        for digest, rel in sorted(sums, key=lambda x: x[1]):
            fh.write("%s  %s\n" % (digest, rel))
    print("G1-R3-R1 complete: %d targets, %d trace rows, %d adapter mismatches, "
          "contamination=FALSE" % (len(target_ids), len(trace_rows), len(mismatch_rows)))
    return 0


def build_report(summary, decision_rows, mismatch_rows):
    lines = []
    add = lines.append
    add("# G1-R3-R1 identity adapter mismatch repair audit\n")
    add("- run tag: %s | operator: %s | status cap: READY_FOR_REVIEW\n"
        % (RUN_TAG, OPERATOR))
    add("- the R3 directory is preserved untouched; this audit lives in "
        "G1_smiles_recovery_r1/ and modifies nothing (S4/S4R1/S4R2 and G1 "
        "canonical gold all read-only).\n")
    add("\n## 1. Root-cause distribution (32 targets)\n")
    add("```json\n%s\n```\n"
        % json.dumps(summary["root_cause_distribution"], indent=2, sort_keys=True))
    add("\n## 2. Identity adapter mismatches (S4R1 resolution table)\n")
    for m in mismatch_rows:
        add("- **%s**: S4R1 resolved_name `%s` bound another participant's "
            "Complete-Name token; the raw reaction identity is `%s`; "
            "reactions `%s` (columns %s). G1 canonical contamination: "
            "**FALSE** (G1 occurrences carry the correct token). "
            "Recommended: S4R1 adapter repair (record-only; S4R1 frozen).\n"
            % (m["biosysmo_id"], m["s4r1_resolved_name"],
               m["raw_reaction_identity_names"][:60],
               m["source_reaction_ids"], m["source_columns"]))
    add("\n## 3. BSY-c18728 normalized name variant\n")
    add("- S4R1 resolved_name `dermatan sulfate` is an umbrella label; the "
        "original reactions carry occurrence-level variants "
        "(dermatan sulfate(n), dermatan sulfate(n-1), substituted forms) and "
        "G1 preserves those occurrence names. NOT a mis-binding; no canonical "
        "repair required.\n")
    add("\n## 4. External adapter names\n")
    add("- BSY-c18914 (Ferrocytochrome c) and BSY-c18934 (Ferricytochrome c): "
        "the original Complete Names do not name these participants; the names "
        "come from the frozen KEGG external adapter "
        "(RESOLVED_FROM_AUTHORITATIVE_EXTERNAL_ID / RESOLVED_WITH_SOURCE_ADAPTER) "
        "and the G1 occurrences match the adapter names exactly -> "
        "EXTERNAL_NAME_ADAPTER_BUT_OCCURRENCE_CONSISTENT.\n")
    add("\n## 5. G1 canonical contamination\n")
    add("- every one of the %d G1 occurrences traced back to the original "
        "reaction row: participant id column match + Complete-Name token (or "
        "frozen external adapter) all consistent. Contamination verdict: "
        "**FALSE**; G1 reaction_gold / counts / manifest untouched.\n"
        % summary["traceback_rows"])
    add("\n## 6. Recovery status (unchanged from R3; evidence reused)\n")
    add("```json\n%s\n```\n"
        % json.dumps(summary["recovery_status_distribution"], indent=2, sort_keys=True))
    add("\n## 7. Impact distribution\n")
    add("```json\n%s\n```\n"
        % json.dumps(summary["g1_impact_distribution"], indent=2, sort_keys=True))
    add("- CASE_IMPACT_REVIEW cases: %s\n" % ", ".join(
        summary["case_impact_review_cases"]))
    add("\n## 8. Correction to the R3 conclusion\n")
    add("- R3 said 32/32 SOURCE_DATA_MISSING_STRUCTURE. The corrected split: "
        "%d source-missing, %d S4R1 extraction/mapping errors "
        "(BSY-c18918, BSY-c18932), 1 normalized name variant (BSY-c18728), "
        "2 external-adapter-consistent (BSY-c18914, BSY-c18934).\n"
        % (summary["root_cause_distribution"].get("SOURCE_DATA_MISSING_STRUCTURE", 0),
           summary["identity_adapter_mismatch_count"]))
    add("\n## 9. Gate\n")
    add("- G1 stays READY_FOR_REVIEW; the teacher review draft stays "
        "DRAFT_BLOCKED until the corrected numbers are integrated; no G2.\n")
    return "\n".join(lines)


if __name__ == "__main__":
    sys.exit(main())
