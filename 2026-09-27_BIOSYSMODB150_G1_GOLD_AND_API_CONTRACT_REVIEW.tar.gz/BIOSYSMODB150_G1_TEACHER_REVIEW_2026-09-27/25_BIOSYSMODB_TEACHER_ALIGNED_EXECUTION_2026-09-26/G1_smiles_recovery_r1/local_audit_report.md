# G1-R3-R1 identity adapter mismatch repair audit

- run tag: 2026-09-27 | operator: LOCAL_AI_G1R3R1_EXECUTOR | status cap: READY_FOR_REVIEW

- the R3 directory is preserved untouched; this audit lives in G1_smiles_recovery_r1/ and modifies nothing (S4/S4R1/S4R2 and G1 canonical gold all read-only).


## 1. Root-cause distribution (32 targets)

```json
{
  "EXTERNAL_NAME_ADAPTER_BUT_OCCURRENCE_CONSISTENT": 2,
  "EXTRACTION_OR_MAPPING_ERROR": 2,
  "NORMALIZED_NAME_VARIANT": 1,
  "SOURCE_DATA_MISSING_STRUCTURE": 27
}
```


## 2. Identity adapter mismatches (S4R1 resolution table)

- **BSY-c18918**: S4R1 resolved_name `dioxygen` bound another participant's Complete-Name token; the raw reaction identity is `a reduced putidaredoxin [iron-sulfur] cluster`; reactions `BSY-r00594|BSY-r00597` (columns SUBSTRATE 3). G1 canonical contamination: **FALSE** (G1 occurrences carry the correct token). Recommended: S4R1 adapter repair (record-only; S4R1 frozen).

- **BSY-c18932**: S4R1 resolved_name `H2O` bound another participant's Complete-Name token; the raw reaction identity is `an oxidized cytochrome`; reactions `BSY-r02583` (columns SUBSTRATE 3). G1 canonical contamination: **FALSE** (G1 occurrences carry the correct token). Recommended: S4R1 adapter repair (record-only; S4R1 frozen).


## 3. BSY-c18728 normalized name variant

- S4R1 resolved_name `dermatan sulfate` is an umbrella label; the original reactions carry occurrence-level variants (dermatan sulfate(n), dermatan sulfate(n-1), substituted forms) and G1 preserves those occurrence names. NOT a mis-binding; no canonical repair required.


## 4. External adapter names

- BSY-c18914 (Ferrocytochrome c) and BSY-c18934 (Ferricytochrome c): the original Complete Names do not name these participants; the names come from the frozen KEGG external adapter (RESOLVED_FROM_AUTHORITATIVE_EXTERNAL_ID / RESOLVED_WITH_SOURCE_ADAPTER) and the G1 occurrences match the adapter names exactly -> EXTERNAL_NAME_ADAPTER_BUT_OCCURRENCE_CONSISTENT.


## 5. G1 canonical contamination

- every one of the 144 G1 occurrences traced back to the original reaction row: participant id column match + Complete-Name token (or frozen external adapter) all consistent. Contamination verdict: **FALSE**; G1 reaction_gold / counts / manifest untouched.


## 6. Recovery status (unchanged from R3; evidence reused)

```json
{
  "IDENTITY_AMBIGUOUS": 4,
  "NOT_APPLICABLE_NON_UNIQUE_STRUCTURE": 24,
  "UNRESOLVED_NO_AUTHORITATIVE_RECORD": 4
}
```


## 7. Impact distribution

```json
{
  "AUXILIARY_STRUCTURE_UNAVAILABLE": 23,
  "CASE_IMPACT_REVIEW": 9
}
```

- CASE_IMPACT_REVIEW cases: BIOPATH150_040, BIOPATH150_115, BIOPATH150_116, BIOPATH150_117, BIOPATH150_118


## 8. Correction to the R3 conclusion

- R3 said 32/32 SOURCE_DATA_MISSING_STRUCTURE. The corrected split: 27 source-missing, 2 S4R1 extraction/mapping errors (BSY-c18918, BSY-c18932), 1 normalized name variant (BSY-c18728), 2 external-adapter-consistent (BSY-c18914, BSY-c18934).


## 9. Gate

- G1 stays READY_FOR_REVIEW; the teacher review draft stays DRAFT_BLOCKED until the corrected numbers are integrated; no G2.
