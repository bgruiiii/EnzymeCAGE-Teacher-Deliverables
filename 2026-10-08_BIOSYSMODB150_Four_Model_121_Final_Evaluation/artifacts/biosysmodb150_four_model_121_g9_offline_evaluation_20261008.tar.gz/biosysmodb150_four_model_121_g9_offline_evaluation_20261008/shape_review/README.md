# shape_review/ 材料说明（G9四模型121题正式结果形态审阅）

TASK_ID：`biosysmodb150_g9_four_model_121_formal_offline_score_20261008`，API_CALLS=0。

## 文件清单

```text
sampling_manifest.json   固定种子抽样清单：Python版本、平台、算法、seed=20261006、
                         模型顺序、8个(model, case)样本及其SHA。抽样仅读取排序后的
                         121个case ID（G2 main_cases.jsonl），先于任何答案内容读取；
                         抽到失败/held槽不换样。
samples/                 8份原始visible逐字节导出（.visible_answer.txt）；若抽到
                         非可用槽则导出.STATUS_NOTE.txt状态说明（本轮无）。
checklist.tsv            客观检查表（脚本计算，无人工判断）。
SHA256SUMS               8份导出+checklist+sampling_manifest的SHA256。
AI_PRE_REVIEW.md         AI预审（OK/OBSERVATION/CONCERN）；人工字段保持
                         PENDING_LOCAL_HUMAN_REVIEW，不冒充人工PASS。
```

## checklist.tsv 字段定义

| 字段 | 定义 |
|---|---|
| json_load_ok | 对导出原始字节直接`json.load`且顶层为dict（不剥围栏、不修复） |
| schema_errors_n / schema_warnings_n | 冻结G3 `validators.schema_validate`输出计数（extra字段只计warning） |
| n_steps / n_organism_profiles / n_evidence_registry | 顶层数组元素数 |
| traits_15F_profiles | traits字典恰含F1–F15全部15键的profile数 |
| null_leaf_ratio | JSON全部叶子节点中null占比 |
| question_echo_chunks | 题面文本200字符滑窗（步长100）在答案中逐字出现的块数/总块数 |
| template_shell_suspect | 启发式：steps=0 或 profiles=0 或 evidence=0 或 null占比≥0.9 记Y |
| receiver_degenerate_flag / receiver_schema_flag | 采集端completion_matrix的degenerate/schema原判 |

## 人工审阅流程

人工审阅人逐份打开`samples/`导出件对照`checklist.tsv`与`AI_PRE_REVIEW.md`，在下方登记：

```text
HUMAN_REVIEWER=<姓名/标识>
HUMAN_REVIEW_DATE=<UTC日期>
HUMAN_PER_SAMPLE_VERDICTS=<8份逐份 PASS/FAIL 及理由>
HUMAN_OVERALL=<PASS/FAIL>
```

在真实人工记录填入并通过之前，整体状态只能为
`G9_SCORED_PENDING_LOCAL_HUMAN_SHAPE_REVIEW`，任何标题/状态不得写最终发布PASS。
