# BIOSYSMOdb150 G2/G3集中裁决与G4-G9离线就绪报告

日期：2026-09-28  
提交目的：请黄老师一次性完成G2内容回签和G3六项评分口径裁决；后续G4-G9离线工程准备一并汇报，不逐项打扰老师。

## 一、当前状态

```text
G1：PASS，formal_n=121，quarantine=29
G2：READY_FOR_REVIEW，121题已生成，未解释泄漏=0
G3：PREPARED_PENDING_G2_SIGNOFF，评分器未冻结
G4-G6：PREPARED_NOT_AUTHORIZED_TO_RUN
G7：TEMPLATE_ONLY_NOT_APPROVED
G8-G9：OFFLINE_ONLY_NOT_AUTHORIZED
真实商业API调用：0
真实派发：0
```

本报告不重新申请G2-G6总授权。老师已于2026-09-27条件批准G2-G6；本次只完成合同要求的G2内容回签和G3实现细节冻结。

## 二、G2结果和请老师裁决的两项口径

### 2.1 程序结果

```text
formal cases=121
rendered messages=121
G2 validator=199/199 PASS
unexplained leakage hits=0
teacher sample=13（seed=20260927）
API calls=0
```

最终消息实际为单条user message，无独立system message；完整user message已经包含题目、规则、空JSON模板和compact Schema，泄漏扫描覆盖实际派发字节。

### 2.2 14个ROUTE_GOLD_COLLISION

14个case的路线限定词同时也是该case的主链中间体或终点：

```text
BIOPATH150_009, 016, 019, 020, 041, 054, 068,
079, 082, 094, 106, 141, 143, 144
```

学生建议：**保留这些最小路线限定词，用于指定路线和分支消歧；但在路径评分时，将题面已经直接披露的名称标记为CONTROLLED_INPUT，不把“复述该名称”计为模型自主recall。其余上下游步骤、方向、连接、酶菌和结构仍照常评分。**

- [ ] 同意上述“保留题面、披露原子不计自主recall”规则（推荐）
- [ ] 删除路线限定中的碰撞词，再重新生成G2和G3
- [ ] 保留且仍按普通gold计分
- [ ] 其他：________________________________

### 2.3 93个无可靠氧条件case

源库无可靠氧条件时，题面使用：

```text
oxygen_condition=null
PENDING_OXYGEN_REVIEW
```

未猜测Aerobic/Anaerobic，五模型收到相同输入。

- [ ] 接受null，表示题目不限定氧条件（推荐）
- [ ] 这93题暂不进入主实验
- [ ] 要求补充氧条件来源后再生成题面
- [ ] 其他：________________________________

### 2.4 13题人工抽审

抽审case：

```text
009, 016, 019, 020, 041, 054, 068,
079, 082, 094, 106, 141, 143
```

第14个碰撞case 144在全量碰撞表中单列。完整题面和抽审表已在G2教师包中提供。

- [ ] 13题名称唯一、路线限定和题面均通过；BIOPATH150_144按同一碰撞政策处理
- [ ] 需修改的case：________________________________

若G2题面因此发生任何字节变化，G2及依赖的G3/G4预案hash全部重新验证。

## 三、G3六项实现口径

科学五层权重45/10/20/15/10已经固定，本节不重新讨论层级权重。以下建议仅基于all_correct/all_wrong/partial三个手工mock，未读取真实模型答案。

### D1 性状10%组合

建议：数值准确率只统计明确数值子字段；mesophilic/non-halophilic等word-preference格移出数值准确率分母，另报TEXT_COVERAGE。这样all_correct按明确可评分集合归一为100，不靠调权凑分。

- [ ] 同意（推荐）
- [ ] word-preference有accepted文本时独立精确匹配
- [ ] 其他：________________________________

### D2 层内子项与酶菌pair

建议：species、strain、TaxID、genome独立计分；酶名、EC、酶-微生物pair独立等权。pair要求微生物名称/菌株与accepted step organism一致；若模型主动填写错误TaxID，则判IDENTITY_CONFLICT并使pair错误；若TaxID为null，则pair可按正确名称计分，但TaxID子项记miss。

- [ ] 同意（推荐）
- [ ] pair必须TaxID也正确，null同样不通过
- [ ] 其他权重/规则：________________________________

### D3 步骤对齐

建议：Jaccard阈值0.5；方向必须一致；稳定ID tie-break；一对多/多对一最多匹配一个gold step，其余按漏步/多步，不设人工宽免。

- [ ] 同意（推荐）
- [ ] 阈值改为：________
- [ ] split/merge其他规则：________________________________

### D4 overclaim

老师已经固定“证据独立成轴”。建议overclaim只独立报告，不从科学分扣分；证据不可核验、错误高置信和幻觉在证据轴统计。null是recall miss但不是overclaim。

- [ ] 同意，仅报告/证据轴统计（推荐）
- [ ] 从证据轴另扣，封顶：________
- [ ] 从科学分扣，规则：________________________________

### D5 F14字段路径

建议：genome accession只以`traits.F14.value.genome_accession`为正式来源；profile级兼容字段如存在必须一致，否则CONFLICT。

- [ ] 同意（推荐）
- [ ] 其他：________________________________

### D6 achiral结构参考

建议：主SMILES分只使用isomeric canonical；achiral结果作为附表和敏感性参考，不进入主分。

- [ ] 同意（推荐）
- [ ] 作为SMILES层次级子指标
- [ ] 其他：________________________________

老师回签后，学生侧用选定口径重跑三个mock；all_correct必须按冻结可评分集合为100、all_wrong核心recall为0、partial与手算一致，才允许G3=PASS。

## 四、G4-G9已经离线准备的内容

### 4.1 G4-G7

- G4：3个搜索生效探针、15槽任务矩阵、metadata验收和全开/全关决议已准备；真实执行前即时冻结anchor UTC和3个authority URL快照/hash。
- G5：固定3题（BIOPATH150_008/001/002），5×3=15槽，全部NOT_DISPATCHED。
- G6：固定10题，5×10=50槽，全部NOT_DISPATCHED；包含G5三题的超集方案为建议，未冻结。
- G7：token、时延、成本和hash绑定模板已完成，但预算仍等待G6实测和老师单独回签。

### 4.2 Chenyu与故障演练

```text
Chenyu离线示例包validator：27/27 PASS
故障演练：39/39 PASS，mutation 5/5
覆盖429/503/timeout/半截SSE/length/坏JSON/空正文/重复chunk/断点恢复
密钥扫描：0命中
```

真实阶段包目前均`live_disabled=true`、授权请求数0，尚未上传Chenyu。

### 4.3 G8-G9

```text
G8正式矩阵：121×5=605行，全部NOT_DISPATCHED，API calls=0
G8 validator：27/27 PASS，mutation 5/5
G9 synthetic报告：30/30 PASS，mutation 5/5
±5pp敏感性：10组权重均程序归一为100
全链拒绝路径：23/23 PASS，mutation 5/5
总装validator：337/337 PASS
D0：143/143 PASS
```

G8/G9仍未获授权，不会因离线准备完成而启动。

## 五、老师本次一次性回签后的动作

如果老师完成第二、三节裁决，且没有要求修改题面：

```text
G2 -> PASS
按裁决重生成/复验G3 mock -> G3冻结并PASS
即时冻结G4 anchor和authority快照
本地审核正式G4 Chenyu包
学生上传Chenyu执行最多15次真实搜索探针
```

G4-G6仍受老师已批准的商业API总上限80次约束；G5失败后的重跑不在原授权内。G7预算、G8正式605次和G9发布仍按原批复另行处理。

## 六、证据哈希

```text
G2 gate:
5637967785b5ae1620ac1787fb9196a75de4d4d446da848dfd2dfd825b8a3b52

G3 preparation gate:
235c2484fbf1076b6964c7c361aa6545a85f3ed1cbfbb2e464d9157fa52c3e3c

G4-G9 offline rehearsal gate:
a2f6b828fed4864885868c6f338d25e3565bcc0b07924e079945745aaedb0d88

G2 questions manifest:
16de9e6219e642f3b154e84c94483ea41827c3b02971b2633a7ae93b8548dfe9

G3 preparation manifest:
62f4094ad69a1d43b5aed248889cb96e992549f99480a84a99bafba9a222afdf

G3 open decisions card:
259772e0d729216dad6b654351f73d1163783dc0e37fc8b0446e266863e8aec7

G4-G9 round report:
50006311a01f4d6b3e19fafc5323b358377ee7e2b116334614595923ec679b7f
```

## 七、老师批示

请直接勾选第二、三节的选项或写修改意见。本文件回签版本将作为G2 PASS、G3正式冻结和G4 Chenyu阶段包的共同approval source。

老师姓名/签名：________________  日期：________________

补充意见：

____________________________________________________________

____________________________________________________________
