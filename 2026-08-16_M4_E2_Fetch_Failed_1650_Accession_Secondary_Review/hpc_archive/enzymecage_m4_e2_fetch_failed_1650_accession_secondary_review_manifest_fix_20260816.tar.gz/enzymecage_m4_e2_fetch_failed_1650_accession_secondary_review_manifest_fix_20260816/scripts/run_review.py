#!/usr/bin/env python3
"""M4 E2 1,650 fetch-failed accession secondary review (table-only).

Read-only second-pass accession review for the 1,650 BLOCKED_AFDB_STRUCTURE_FETCH_FAILED
UIDs from the teacher-accepted M4 E2 full 4,681 staged status package.
"""

import os, sys, csv, json, hashlib, time, datetime, socket, subprocess, tarfile, io, shutil
from pathlib import Path
from collections import Counter

import requests

# ========================= constants =========================

TASK_ID = "enzymecage_m4_e2_fetch_failed_1650_accession_secondary_review_20260815"
RUN_TYPE = "m4_e2_fetch_failed_accession_secondary_review_table_only"
REVIEW_DENOMINATOR = 1650

PROJECT_REPO = Path("/root/projects/EnzymeCAGE-master")
RETURN_ROOT = PROJECT_REPO / "HPC_Returned_Result_Summaries"
RETURN_DIR = RETURN_ROOT / "enzymecage_m4_e2_fetch_failed_1650_accession_secondary_review_20260815"
ARCHIVE = RETURN_ROOT / "enzymecage_m4_e2_fetch_failed_1650_accession_secondary_review_20260815.tar.gz"
IDENTITY = RETURN_ROOT / "enzymecage_m4_e2_fetch_failed_1650_accession_secondary_review_20260815.tar.gz.identity.txt"
WORK_ROOT = Path("/tmp/enzymecage_m4_e2_fetch_failed_1650_accession_secondary_review_20260815")

SOURCE_ARCHIVE = RETURN_ROOT / "enzymecage_m4_e2_full_4681_4gpu_sharded_continuation_final_20260814.tar.gz"
SOURCE_ARCHIVE_SHA256 = "b01e717139f6eb48739e0861f82b339cdc0132ee4777acdd18354ee9da38bdd4"
SOURCE_ARCHIVE_BYTES = 689316623
SOURCE_EXTRACTED = RETURN_ROOT / "enzymecage_m4_e2_full_4681_4gpu_sharded_continuation_final_20260814"

STATUS_TABLE_CSV = SOURCE_EXTRACTED / "FULL_4681_STAGED_STATUS_TABLE.csv"
ACCESSION_REVIEW_CSV = SOURCE_EXTRACTED / "FULL_4681_ACCESSION_REVIEW_TABLE.csv"
UID_MANIFEST_CSV = SOURCE_EXTRACTED / "FULL_4681_UID_MANIFEST.csv"

UNIPROT_DIRECT = "https://rest.uniprot.org/uniprotkb/{acc}.json"
UNIPROT_SEARCH = "https://rest.uniprot.org/uniprotkb/search?query=accession:{acc}&format=json&size=5"
AFDB_V6_URL = "https://alphafold.ebi.ac.uk/files/AF-{acc}-F1-model_v6.pdb"

TIMEOUT_SEC = 20
RETRIES = 3
SLEEP_BETWEEN = 0.2

FINAL_STATUS_COMPLETE = "M4_E2_FETCH_FAILED_1650_ACCESSION_SECONDARY_REVIEW_COMPLETE_TABLE_ONLY"

REVIEW_TABLE_COLUMNS = [
    "original_uid",
    "original_final_status",
    "original_sequence_length",
    "original_sequence_sha256",
    "original_afdb_http_status_from_source_package",
    "uniprot_lookup_status",
    "uniprot_http_status",
    "uniprot_primary_accession",
    "uniprot_secondary_accessions_json",
    "uniprot_entry_type",
    "uniprot_id",
    "organism",
    "canonical_sequence_length",
    "canonical_sequence_sha256",
    "primary_differs_from_original",
    "candidate_accessions_probed_json",
    "afdb_v6_probe_results_json",
    "afdb_v6_available_accessions_json",
    "reviewed_accession_candidate",
    "reviewed_accession_action",
    "candidate_reason",
    "replacement_performed",
    "asset_generation_started",
    "formal_assets_mutated",
    "production_pool_mutated",
    "production_d4_mutated",
    "retryable",
    "review_notes",
]

# Build forbidden strings from parts so they never appear as contiguous
# literals in this source file.
def _fb(*parts):
    return "".join(parts)

_FORBIDDEN_STRINGS = [
    _fb("M4", "_", "PRODUCTION", "_D4_", "BACKFILL", "_COMPLETE"),
    _fb("M4", "_", "ALL", "_4681_", "UIDS", "_BACKFILLED"),
    _fb("PASS", "_", "FULL", "_D4_", "LOADER"),
    _fb("REPLACED", "_", "ORIGINAL", "_UID"),
    _fb("ASSET", "_", "GENERATION", "_", "COMPLETE"),
    _fb("PRODUCTION", "_POOL_", "MUTATED"),
    _fb("PRODUCTION", "_D4_", "MUTATED"),
]

# ========================= helpers =========================

_started_at = datetime.datetime.now(datetime.timezone.utc)

def log(msg):
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def sha256_str(s):
    return hashlib.sha256(s.encode()).hexdigest()

# ========================= preflight =========================

def preflight():
    log("=== PREFLIGHT ===")

    # Check source archive
    if not SOURCE_ARCHIVE.exists():
        log("BLOCKED: source archive missing")
        sys.exit(1)
    actual_sha = sha256_file(SOURCE_ARCHIVE)
    if actual_sha != SOURCE_ARCHIVE_SHA256:
        log(f"BLOCKED: source archive sha256 mismatch: {actual_sha}")
        sys.exit(1)
    actual_bytes = SOURCE_ARCHIVE.stat().st_size
    if actual_bytes != SOURCE_ARCHIVE_BYTES:
        log(f"BLOCKED: source archive bytes mismatch: {actual_bytes}")
        sys.exit(1)
    log(f"Source archive verified: sha256={actual_sha}, bytes={actual_bytes}")

    # Check extracted source dir
    if not SOURCE_EXTRACTED.exists():
        log("BLOCKED: source extracted dir missing")
        sys.exit(1)

    # Check output paths don't have key files from a previous run
    key_files = [
        RETURN_DIR / "FULL_1650_ACCESSION_SECONDARY_REVIEW_TABLE.csv",
        RETURN_DIR / "FINAL_STATUS.txt",
        RETURN_DIR / "MANIFEST.sha256",
        ARCHIVE,
        IDENTITY,
    ]
    for kf in key_files:
        if kf.exists():
            log(f"BLOCKED: output path already exists: {kf}")
            print(f"FINAL_STATUS=M4_E2_FETCH_FAILED_1650_ACCESSION_REVIEW_BLOCKED_OUTPUT_PATH_EXISTS")
            sys.exit(1)
    log("Output paths clear")

    # Validate source tables
    checks = {}

    # Status table
    with open(STATUS_TABLE_CSV) as f:
        reader = csv.DictReader(f)
        status_rows = list(reader)
    checks["status_table_exists"] = STATUS_TABLE_CSV.exists()
    checks["status_table_rows"] = len(status_rows)
    assert checks["status_table_rows"] == 4681, f"Expected 4681, got {checks['status_table_rows']}"

    uids_status = [r["UniprotID"] for r in status_rows]
    checks["status_table_uids_unique"] = len(set(uids_status)) == 4681
    assert checks["status_table_uids_unique"]

    sc = Counter(r["final_status"] for r in status_rows)
    checks["count_blocked_afdb_structure_fetch_failed"] = sc.get("BLOCKED_AFDB_STRUCTURE_FETCH_FAILED", 0)
    assert checks["count_blocked_afdb_structure_fetch_failed"] == 1650

    # Accession review table
    with open(ACCESSION_REVIEW_CSV) as f:
        reader = csv.DictReader(f)
        acc_rows = list(reader)
    checks["accession_review_table_exists"] = ACCESSION_REVIEW_CSV.exists()
    checks["accession_review_table_rows"] = len(acc_rows)
    assert checks["accession_review_table_rows"] == 1650

    # Every accession-review UID is in the fetch-failed set
    ff_uids = {r["UniprotID"] for r in status_rows if r["final_status"] == "BLOCKED_AFDB_STRUCTURE_FETCH_FAILED"}
    acc_uids = {r["UniprotID"] for r in acc_rows}
    checks["all_accession_review_in_fetch_failed"] = acc_uids.issubset(ff_uids)
    assert checks["all_accession_review_in_fetch_failed"]

    # UID manifest
    with open(UID_MANIFEST_CSV) as f:
        reader = csv.DictReader(f)
        manifest_rows = list(reader)
    checks["uid_manifest_rows"] = len(manifest_rows)
    assert checks["uid_manifest_rows"] == 4681

    # Source table sha256
    checks["source_status_table_sha256"] = sha256_file(STATUS_TABLE_CSV)
    checks["source_accession_review_table_sha256"] = sha256_file(ACCESSION_REVIEW_CSV)

    log(f"Preflight checks: {json.dumps(checks, indent=2)}")

    # Network preflight sample
    try:
        r = requests.get(UNIPROT_DIRECT.format(acc="P00533"), timeout=15)
        checks["network_uniprot_sample"] = r.status_code
        assert r.status_code == 200
    except Exception as e:
        log(f"BLOCKED: UniProt network unreachable: {e}")
        print("FINAL_STATUS=M4_E2_FETCH_FAILED_1650_ACCESSION_REVIEW_BLOCKED_NETWORK_OR_API_UNAVAILABLE")
        sys.exit(1)

    try:
        r = requests.head(AFDB_V6_URL.format(acc="P00533"), timeout=15, allow_redirects=True)
        checks["network_afdb_sample"] = r.status_code
        assert r.status_code == 200
    except Exception as e:
        log(f"BLOCKED: AFDB network unreachable: {e}")
        print("FINAL_STATUS=M4_E2_FETCH_FAILED_1650_ACCESSION_REVIEW_BLOCKED_NETWORK_OR_API_UNAVAILABLE")
        sys.exit(1)

    log("Network preflight passed")

    # Write validation report
    write_preflight_report(checks)

    return status_rows, ff_uids

def write_preflight_report(checks):
    # JSON
    with open(RETURN_DIR / "INPUT_SOURCE_VALIDATION_REPORT.json", "w") as f:
        json.dump({
            "task_id": TASK_ID,
            "source_archive_path": str(SOURCE_ARCHIVE),
            "source_archive_sha256": SOURCE_ARCHIVE_SHA256,
            "source_archive_bytes": SOURCE_ARCHIVE_BYTES,
            "source_extracted_dir": str(SOURCE_EXTRACTED),
            "checks": checks,
            "overall_pass": True,
            "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }, f, indent=2)

    # Markdown
    with open(RETURN_DIR / "INPUT_SOURCE_VALIDATION_REPORT.md", "w") as f:
        f.write("# Input Source Validation Report\n\n")
        f.write(f"**Task ID:** {TASK_ID}\n\n")
        f.write(f"**Source archive:** `{SOURCE_ARCHIVE}`\n\n")
        f.write(f"**Source archive SHA256:** `{SOURCE_ARCHIVE_SHA256}`\n\n")
        f.write(f"**Source archive bytes:** {SOURCE_ARCHIVE_BYTES}\n\n")
        f.write(f"**Source extracted dir:** `{SOURCE_EXTRACTED}`\n\n")
        f.write("## Checks\n\n")
        for k, v in checks.items():
            f.write(f"- **{k}**: {v}\n")
        f.write(f"\n**Overall pass:** True\n")

# ========================= per-UID review =========================

def http_get_with_retry(url, method="get", max_retries=RETRIES):
    """Make an HTTP request with retries. Returns (status_code, body_or_None, error_or_None, retries_used)."""
    last_error = None
    for attempt in range(max_retries):
        try:
            if method == "head":
                r = requests.head(url, timeout=TIMEOUT_SEC, allow_redirects=True)
                return r.status_code, None, None, attempt
            else:
                r = requests.get(url, timeout=TIMEOUT_SEC, allow_redirects=True)
                return r.status_code, r.text, None, attempt
        except requests.exceptions.Timeout:
            last_error = "timeout"
        except requests.exceptions.ConnectionError as e:
            last_error = f"connection_error: {str(e)[:100]}"
        except Exception as e:
            last_error = f"error: {str(e)[:100]}"
        if attempt < max_retries - 1:
            time.sleep(1.0)
    return None, None, last_error, max_retries - 1

def review_single_uid(uid, source_row, api_log_rows):
    """Review a single UID. Returns a dict matching REVIEW_TABLE_COLUMNS."""
    review = {col: "" for col in REVIEW_TABLE_COLUMNS}
    review["original_uid"] = uid
    review["original_final_status"] = source_row.get("final_status", "")
    review["original_sequence_length"] = source_row.get("sequence_length", "")
    review["original_sequence_sha256"] = source_row.get("sequence_sha256", "")
    review["original_afdb_http_status_from_source_package"] = source_row.get("afdb_http_status", "")
    review["replacement_performed"] = "False"
    review["asset_generation_started"] = "False"
    review["formal_assets_mutated"] = "False"
    review["production_pool_mutated"] = "False"
    review["production_d4_mutated"] = "False"
    review["retryable"] = "False"

    notes_parts = []

    # Step 1: UniProt direct lookup
    direct_url = UNIPROT_DIRECT.format(acc=uid)
    status, body, error, retries_used = http_get_with_retry(direct_url, method="get")

    ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
    api_log_rows.append({
        "timestamp_utc": ts,
        "uid": uid,
        "url_kind": "uniprot_direct",
        "accession": uid,
        "url": direct_url,
        "http_status": str(status) if status else "",
                "retry_count": retries_used,
        "final_outcome": "success" if status == 200 else ("not_found" if status == 404 else (f"error:{error}" if error else f"status_{status}")),
    })
    time.sleep(SLEEP_BETWEEN)

    uniprot_entry = None
    uniprot_lookup_status = ""
    uniprot_http_status = ""

    if status == 200 and body:
        uniprot_lookup_status = "DIRECT_LOOKUP_SUCCESS"
        uniprot_http_status = "200"
        try:
            uniprot_entry = json.loads(body)
        except json.JSONDecodeError:
            uniprot_entry = None
            uniprot_lookup_status = "DIRECT_LOOKUP_JSON_PARSE_FAILED"
            notes_parts.append("UniProt direct lookup returned 200 but JSON parse failed")
    elif status == 404:
        uniprot_http_status = "404"
        # Try search fallback
        search_url = UNIPROT_SEARCH.format(acc=uid)
        s_status, s_body, s_error, s_retries = http_get_with_retry(search_url, method="get")

        ts2 = datetime.datetime.now(datetime.timezone.utc).isoformat()
        api_log_rows.append({
            "timestamp_utc": ts2,
            "uid": uid,
            "url_kind": "uniprot_search",
            "accession": uid,
            "url": search_url,
            "http_status": str(s_status) if s_status else "",
            "retry_count": s_retries,
            "final_outcome": "success" if s_status == 200 else (f"error:{s_error}" if s_error else f"status_{s_status}"),
        })
        time.sleep(SLEEP_BETWEEN)

        if s_status == 200 and s_body:
            try:
                sd = json.loads(s_body)
                results = sd.get("results", [])
                if results:
                    uniprot_entry = results[0]
                    uniprot_lookup_status = "SEARCH_FALLBACK_SUCCESS"
                    uniprot_http_status = "200"
                    notes_parts.append("UniProt direct lookup returned 404; search fallback found entry")
                else:
                    uniprot_lookup_status = "ENTRY_NOT_FOUND"
                    notes_parts.append("UniProt direct lookup 404 and search returned 0 results")
            except json.JSONDecodeError:
                uniprot_lookup_status = "SEARCH_JSON_PARSE_FAILED"
                notes_parts.append("UniProt direct lookup 404 and search JSON parse failed")
        elif s_status == 404:
            uniprot_lookup_status = "ENTRY_NOT_FOUND"
            notes_parts.append("UniProt entry not found via direct or search")
        else:
            uniprot_lookup_status = "API_RETRY_EXHAUSTED"
            review["retryable"] = "True"
            notes_parts.append(f"UniProt API retry exhausted (direct={status}, search={s_status})")
    elif status is None:
        uniprot_lookup_status = "API_RETRY_EXHAUSTED"
        review["retryable"] = "True"
        notes_parts.append(f"UniProt API retry exhausted: {error}")
    else:
        uniprot_http_status = str(status)
        uniprot_lookup_status = f"UNEXPECTED_STATUS_{status}"
        notes_parts.append(f"UniProt direct lookup returned unexpected status {status}")

    review["uniprot_lookup_status"] = uniprot_lookup_status
    review["uniprot_http_status"] = uniprot_http_status

    # Parse UniProt fields
    primary_acc = ""
    secondary_accs = []
    entry_type = ""
    uniprot_id = ""
    organism_name = ""
    canonical_seq = ""
    canonical_seq_len = ""
    canonical_seq_sha256 = ""

    if uniprot_entry:
        primary_acc = uniprot_entry.get("primaryAccession", "")
        secondary_accs = uniprot_entry.get("secondaryAccessions", []) or []
        entry_type = uniprot_entry.get("entryType", "")
        uniprot_id = uniprot_entry.get("uniProtkbId", "")
        organism_name = uniprot_entry.get("organism", {}).get("scientificName", "")
        seq_obj = uniprot_entry.get("sequence", {})
        canonical_seq = seq_obj.get("value", "")
        canonical_seq_len = str(seq_obj.get("length", "")) if seq_obj.get("length") else ""
        if canonical_seq:
            canonical_seq_sha256 = sha256_str(canonical_seq)

        # Describe relationship
        if primary_acc == uid:
            notes_parts.append("same_uniprot_entry_primary_secondary_relationship")
        elif uid in secondary_accs:
            notes_parts.append(f"original_uid_is_secondary_accession_of_primary_{primary_acc}")

    review["uniprot_primary_accession"] = primary_acc
    review["uniprot_secondary_accessions_json"] = json.dumps(secondary_accs)
    review["uniprot_entry_type"] = entry_type
    review["uniprot_id"] = uniprot_id
    review["organism"] = organism_name
    review["canonical_sequence_length"] = canonical_seq_len
    review["canonical_sequence_sha256"] = canonical_seq_sha256
    review["primary_differs_from_original"] = str(primary_acc != uid and primary_acc != "")

    # Step 2: Build candidate accession probe list
    candidates = [uid]
    if primary_acc and primary_acc not in candidates:
        candidates.append(primary_acc)
    for sa in secondary_accs:
        if sa not in candidates:
            candidates.append(sa)

    review["candidate_accessions_probed_json"] = json.dumps(candidates)

    # Step 3: Probe AFDB v6 for each candidate
    probe_results = {}
    available_accs = []

    for cand in candidates:
        afdb_url = AFDB_V6_URL.format(acc=cand)
        a_status, _, a_error, a_retries = http_get_with_retry(afdb_url, method="head")

        ts3 = datetime.datetime.now(datetime.timezone.utc).isoformat()
        api_log_rows.append({
            "timestamp_utc": ts3,
            "uid": uid,
            "url_kind": "afdb_v6_probe",
            "accession": cand,
            "url": afdb_url,
            "http_status": str(a_status) if a_status else "",
            "retry_count": a_retries,
            "final_outcome": "available" if a_status == 200 else ("not_found" if a_status == 404 else (f"error:{a_error}" if a_error else f"status_{a_status}")),
        })
        time.sleep(SLEEP_BETWEEN)

        if a_status is not None:
            probe_results[cand] = a_status
        else:
            probe_results[cand] = f"ERROR:{a_error}" if a_error else "ERROR"

        if a_status == 200:
            available_accs.append(cand)

    review["afdb_v6_probe_results_json"] = json.dumps(probe_results)
    review["afdb_v6_available_accessions_json"] = json.dumps(available_accs)

    # Step 4: Record result
    if available_accs:
        first_available = available_accs[0]
        review["reviewed_accession_candidate"] = first_available
        review["reviewed_accession_action"] = "RECORD_ONLY_NO_REPLACEMENT"
        review["candidate_reason"] = "AFDB_V6_STRUCTURE_EXISTS_FOR_CANDIDATE_ACCESSION"
        notes_parts.append(f"AFDB v6 structure found for candidate accession {first_available}")
    else:
        review["reviewed_accession_candidate"] = ""
        review["reviewed_accession_action"] = "NO_AVAILABLE_AFDB_V6_ACCESSION_CANDIDATE_FOUND"
        review["candidate_reason"] = ""
        notes_parts.append("No AFDB v6 structure found for any candidate accession")

    review["review_notes"] = "; ".join(notes_parts)
    return review

# ========================= output =========================

def write_review_table(reviews):
    path = RETURN_DIR / "FULL_1650_ACCESSION_SECONDARY_REVIEW_TABLE.csv"
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=REVIEW_TABLE_COLUMNS)
        writer.writeheader()
        for r in reviews:
            writer.writerow(r)
    log(f"Wrote {path.name}: {len(reviews)} rows")

def write_candidate_table(reviews):
    path = RETURN_DIR / "ACCESSION_CANDIDATE_ONLY_TABLE.csv"
    candidate_rows = [r for r in reviews if r["reviewed_accession_candidate"]]
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=REVIEW_TABLE_COLUMNS)
        writer.writeheader()
        for r in candidate_rows:
            writer.writerow(r)
    log(f"Wrote {path.name}: {len(candidate_rows)} rows")

def write_api_log(api_log_rows):
    path = RETURN_DIR / "API_REQUEST_LOG.csv"
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["timestamp_utc", "uid", "url_kind", "accession", "url", "http_status", "retry_count", "final_outcome"])
        writer.writeheader()
        for r in api_log_rows:
            writer.writerow(r)
    log(f"Wrote {path.name}: {len(api_log_rows)} rows")

def write_summary(reviews, api_log_rows):
    path = RETURN_DIR / "ACCESSION_REVIEW_SUMMARY.json"
    sc = Counter(r["reviewed_accession_action"] for r in reviews)
    ul = Counter(r["uniprot_lookup_status"] for r in reviews)
    total_api_calls = len(api_log_rows)
    candidate_count = sum(1 for r in reviews if r["reviewed_accession_candidate"])
    no_candidate_count = sum(1 for r in reviews if not r["reviewed_accession_candidate"])
    api_retry_exhausted = sum(1 for r in reviews if r["uniprot_lookup_status"] == "API_RETRY_EXHAUSTED")
    primary_differs = sum(1 for r in reviews if r["primary_differs_from_original"] == "True")

    summary = {
        "task_id": TASK_ID,
        "run_type": RUN_TYPE,
        "review_denominator": REVIEW_DENOMINATOR,
        "total_uids_reviewed": len(reviews),
        "candidate_found_count": candidate_count,
        "no_candidate_found_count": no_candidate_count,
        "api_retry_exhausted_count": api_retry_exhausted,
        "primary_differs_from_original_count": primary_differs,
        "total_api_calls": total_api_calls,
        "uniprot_lookup_status_counts": dict(ul),
        "reviewed_accession_action_counts": dict(sc),
        "replacement_performed_any": False,
        "asset_generation_started_any": False,
        "formal_assets_mutated_any": False,
        "production_pool_mutated_any": False,
        "production_d4_mutated_any": False,
        "summary_counts_sum_to_denominator": (candidate_count + no_candidate_count) == REVIEW_DENOMINATOR,
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }

    with open(path, "w") as f:
        json.dump(summary, f, indent=2)

    # Markdown
    md_path = RETURN_DIR / "ACCESSION_REVIEW_SUMMARY.md"
    with open(md_path, "w") as f:
        f.write("# Accession Review Summary\n\n")
        f.write(f"**Task ID:** {TASK_ID}\n\n")
        f.write(f"**Run type:** {RUN_TYPE}\n\n")
        f.write(f"**Review denominator:** {REVIEW_DENOMINATOR}\n\n")
        f.write(f"**Total UIDs reviewed:** {len(reviews)}\n\n")
        f.write(f"**Candidate accessions found:** {candidate_count}\n\n")
        f.write(f"**No candidate found:** {no_candidate_count}\n\n")
        f.write(f"**API retry exhausted:** {api_retry_exhausted}\n\n")
        f.write(f"**Primary differs from original:** {primary_differs}\n\n")
        f.write(f"**Total API calls:** {total_api_calls}\n\n")
        f.write("## UniProt lookup status counts\n\n")
        for k, v in sorted(ul.items()):
            f.write(f"- {k}: {v}\n")
        f.write("\n## Reviewed accession action counts\n\n")
        for k, v in sorted(sc.items()):
            f.write(f"- {k}: {v}\n")
        f.write(f"\n**Summary counts sum to denominator:** {summary['summary_counts_sum_to_denominator']}\n")
        f.write(f"\n**Replacement performed (any):** False\n")
        f.write(f"**Asset generation started (any):** False\n")
        f.write(f"**Formal assets mutated (any):** False\n")
        f.write(f"**Production pool mutated (any):** False\n")
        f.write(f"**Production D4 mutated (any):** False\n")

    log(f"Wrote {path.name} and {md_path.name}")
    return summary

def write_no_mutation_check():
    path = RETURN_DIR / "NO_MUTATION_CHECK.json"
    with open(path, "w") as f:
        json.dump({
            "formal_assets_mutated": False,
            "production_pool_mutated": False,
            "production_d4_mutated": False,
            "replacement_performed": False,
            "asset_generation_started": False,
        }, f, indent=2)
    log(f"Wrote {path.name}")

def write_command_log():
    path = RETURN_DIR / "COMMAND_LOG.txt"
    with open(path, "w") as f:
        f.write(f"task_id={TASK_ID}\n")
        f.write(f"run_type={RUN_TYPE}\n")
        f.write(f"started_utc={_started_at.isoformat()}\n")
        f.write(f"source_archive={SOURCE_ARCHIVE}\n")
        f.write(f"source_archive_sha256={SOURCE_ARCHIVE_SHA256}\n")
        f.write(f"source_archive_bytes={SOURCE_ARCHIVE_BYTES}\n")
        f.write(f"network_timeout_sec={TIMEOUT_SEC}\n")
        f.write(f"network_retries={RETRIES}\n")
        f.write(f"network_sleep_between_sec={SLEEP_BETWEEN}\n")
        f.write(f"python_version={sys.version}\n")
        f.write(f"hostname={socket.gethostname()}\n")
        f.write(f"completed_utc={datetime.datetime.now(datetime.timezone.utc).isoformat()}\n")
    log(f"Wrote {path.name}")

# ========================= validation =========================

def validate(reviews, summary):
    log("=== VALIDATION ===")
    checks = {}

    checks["review_table_rows"] = len(reviews)
    assert checks["review_table_rows"] == 1650, f"Expected 1650, got {len(reviews)}"

    uids = [r["original_uid"] for r in reviews]
    checks["original_uid_unique"] = len(set(uids)) == 1650
    assert checks["original_uid_unique"]

    # All from fetch-failed set
    checks["all_from_fetch_failed"] = all(r["original_final_status"] == "BLOCKED_AFDB_STRUCTURE_FETCH_FAILED" for r in reviews)
    assert checks["all_from_fetch_failed"]

    # No replacement
    checks["no_replacement"] = all(r["replacement_performed"] == "False" for r in reviews)
    assert checks["no_replacement"]

    # No asset generation
    checks["no_asset_generation"] = all(r["asset_generation_started"] == "False" for r in reviews)
    assert checks["no_asset_generation"]

    # No mutation
    checks["no_formal_mutation"] = all(r["formal_assets_mutated"] == "False" for r in reviews)
    assert checks["no_formal_mutation"]
    checks["no_pool_mutation"] = all(r["production_pool_mutated"] == "False" for r in reviews)
    assert checks["no_pool_mutation"]
    checks["no_d4_mutation"] = all(r["production_d4_mutated"] == "False" for r in reviews)
    assert checks["no_d4_mutation"]

    # Candidate table is subset
    candidate_path = RETURN_DIR / "ACCESSION_CANDIDATE_ONLY_TABLE.csv"
    with open(candidate_path) as f:
        reader = csv.DictReader(f)
        cand_rows = list(reader)
    cand_uids = {r["original_uid"] for r in cand_rows}
    full_uids = {r["original_uid"] for r in reviews}
    checks["candidate_subset"] = cand_uids.issubset(full_uids)
    assert checks["candidate_subset"]

    # Summary counts sum
    checks["summary_counts_sum"] = (summary["candidate_found_count"] + summary["no_candidate_found_count"]) == 1650
    assert checks["summary_counts_sum"]

    # Forbidden string scan
    forbidden_found = []
    scan_dir = RETURN_DIR
    for item in scan_dir.rglob("*"):
        if item.is_file():
            try:
                content = item.read_text(errors="replace")
            except Exception:
                continue
            for fb in _FORBIDDEN_STRINGS:
                if fb in content:
                    forbidden_found.append(str(item))
                    break
    checks["forbidden_strings_absent"] = len(forbidden_found) == 0
    if forbidden_found:
        log(f"FORBIDDEN STRINGS FOUND in: {forbidden_found}")
        assert False, f"Forbidden strings found in: {forbidden_found}"

    checks["overall_pass"] = True
    log(f"Validation checks: {json.dumps(checks, indent=2)}")

    with open(RETURN_DIR / "VALIDATION_REPORT.json", "w") as f:
        json.dump(checks, f, indent=2)

    return checks

# ========================= packaging =========================

def create_manifests():
    """Create MANIFEST.files and MANIFEST.sha256 for all files in RETURN_DIR.
    Exclude MANIFEST.files and MANIFEST.sha256 themselves from the listing."""
    files_dir = RETURN_DIR
    file_list = []
    hash_list = []
    skip_names = {"MANIFEST.files", "MANIFEST.sha256"}

    for item in sorted(files_dir.rglob("*")):
        if item.is_file() and item.name not in skip_names:
            rel = item.relative_to(files_dir)
            sha = sha256_file(item)
            size = item.stat().st_size
            file_list.append({"path": str(rel), "sha256": sha, "bytes": size})
            hash_list.append(f"{sha}  {rel}")

    # MANIFEST.files
    with open(RETURN_DIR / "MANIFEST.files", "w") as f:
        for entry in file_list:
            f.write(f"{entry['path']}\t{entry['sha256']}\t{entry['bytes']}\n")

    # MANIFEST.sha256
    with open(RETURN_DIR / "MANIFEST.sha256", "w") as f:
        for line in hash_list:
            f.write(line + "\n")

    log(f"Wrote MANIFEST.files ({len(file_list)} entries) and MANIFEST.sha256")

def create_archive_and_identity(source_checks, validation_checks, summary):
    # Create archive
    single_root_name = RETURN_DIR.name

    with tarfile.open(ARCHIVE, "w:gz") as tar:
        tar.add(RETURN_DIR, arcname=single_root_name)

    archive_sha = sha256_file(ARCHIVE)
    archive_bytes = ARCHIVE.stat().st_size

    # Create identity sidecar
    with open(IDENTITY, "w") as f:
        f.write(f"task_id={TASK_ID}\n")
        f.write(f"run_type={RUN_TYPE}\n")
        f.write(f"created_at_utc={datetime.datetime.now(datetime.timezone.utc).isoformat()}\n")
        f.write(f"hostname={socket.gethostname()}\n")
        f.write(f"source_archive_path={SOURCE_ARCHIVE}\n")
        f.write(f"source_archive_sha256_if_used={SOURCE_ARCHIVE_SHA256}\n")
        f.write(f"source_status_table_sha256={source_checks.get('source_status_table_sha256', '')}\n")
        f.write(f"source_accession_review_table_sha256={source_checks.get('source_accession_review_table_sha256', '')}\n")
        f.write(f"archive_path={ARCHIVE}\n")
        f.write(f"archive_sha256={archive_sha}\n")
        f.write(f"archive_bytes={archive_bytes}\n")
        f.write(f"single_root_dir={single_root_name}\n")
        f.write(f"manifest_sha256={sha256_file(RETURN_DIR / 'MANIFEST.sha256')}\n")
        f.write(f"final_status={FINAL_STATUS_COMPLETE}\n")
        f.write(f"review_denominator=1650\n")
        f.write(f"replacement_performed_any=False\n")
        f.write(f"asset_generation_started_any=False\n")
        f.write(f"formal_assets_mutated_any=False\n")
        f.write(f"production_pool_mutated_any=False\n")
        f.write(f"production_d4_mutated_any=False\n")

    log(f"Created archive: {ARCHIVE}")
    log(f"  sha256={archive_sha}")
    log(f"  bytes={archive_bytes}")
    log(f"Created identity: {IDENTITY}")

    return archive_sha, archive_bytes

# ========================= main =========================

def main():
    log(f"Starting {TASK_ID}")

    # Preflight
    status_rows, ff_uids = preflight()

    # Build source lookup
    status_by_uid = {r["UniprotID"]: r for r in status_rows}

    # Get fetch-failed UIDs in manifest order
    ff_uid_list = [r["UniprotID"] for r in status_rows if r["final_status"] == "BLOCKED_AFDB_STRUCTURE_FETCH_FAILED"]

    log(f"Fetch-failed UIDs to review: {len(ff_uid_list)}")

    # Review each UID
    reviews = []
    api_log_rows = []

    for i, uid in enumerate(ff_uid_list):
        if i % 100 == 0:
            log(f"Progress: {i}/{len(ff_uid_list)}")
        source_row = status_by_uid[uid]
        review = review_single_uid(uid, source_row, api_log_rows)
        reviews.append(review)

    log(f"Completed review of {len(reviews)} UIDs")

    # Write outputs
    write_review_table(reviews)
    write_candidate_table(reviews)
    write_api_log(api_log_rows)
    summary = write_summary(reviews, api_log_rows)
    write_no_mutation_check()
    write_command_log()

    # Validate
    validation_checks = validate(reviews, summary)

    # Create manifests
    create_manifests()

    # Create archive and identity
    source_checks = {
        "source_status_table_sha256": sha256_file(STATUS_TABLE_CSV),
        "source_accession_review_table_sha256": sha256_file(ACCESSION_REVIEW_CSV),
    }
    archive_sha, archive_bytes = create_archive_and_identity(source_checks, validation_checks, summary)

    # Final status
    with open(RETURN_DIR / "FINAL_STATUS.txt", "w") as f:
        f.write(FINAL_STATUS_COMPLETE + "\n")

    # Re-run forbidden string scan on archive contents (re-validate after FINAL_STATUS)
    # Re-create manifests and archive to include FINAL_STATUS.txt
    create_manifests()
    with tarfile.open(ARCHIVE, "w:gz") as tar:
        tar.add(RETURN_DIR, arcname=RETURN_DIR.name)
    archive_sha = sha256_file(ARCHIVE)
    archive_bytes = ARCHIVE.stat().st_size

    # Update identity
    with open(IDENTITY, "w") as f:
        f.write(f"task_id={TASK_ID}\n")
        f.write(f"run_type={RUN_TYPE}\n")
        f.write(f"created_at_utc={datetime.datetime.now(datetime.timezone.utc).isoformat()}\n")
        f.write(f"hostname={socket.gethostname()}\n")
        f.write(f"source_archive_path={SOURCE_ARCHIVE}\n")
        f.write(f"source_archive_sha256_if_used={SOURCE_ARCHIVE_SHA256}\n")
        f.write(f"source_status_table_sha256={sha256_file(STATUS_TABLE_CSV)}\n")
        f.write(f"source_accession_review_table_sha256={sha256_file(ACCESSION_REVIEW_CSV)}\n")
        f.write(f"archive_path={ARCHIVE}\n")
        f.write(f"archive_sha256={archive_sha}\n")
        f.write(f"archive_bytes={archive_bytes}\n")
        f.write(f"single_root_dir={RETURN_DIR.name}\n")
        f.write(f"manifest_sha256={sha256_file(RETURN_DIR / 'MANIFEST.sha256')}\n")
        f.write(f"final_status={FINAL_STATUS_COMPLETE}\n")
        f.write(f"review_denominator=1650\n")
        f.write(f"replacement_performed_any=False\n")
        f.write(f"asset_generation_started_any=False\n")
        f.write(f"formal_assets_mutated_any=False\n")
        f.write(f"production_pool_mutated_any=False\n")
        f.write(f"production_d4_mutated_any=False\n")

    # Final forbidden string scan on all return files
    forbidden_found = []
    for item in RETURN_DIR.rglob("*"):
        if item.is_file():
            try:
                content = item.read_text(errors="replace")
            except Exception:
                continue
            for fb in _FORBIDDEN_STRINGS:
                if fb in content:
                    forbidden_found.append(str(item))
                    break
    if forbidden_found:
        log(f"BLOCKED: forbidden strings found in: {forbidden_found}")
        print("FINAL_STATUS=M4_E2_FETCH_FAILED_1650_ACCESSION_REVIEW_BLOCKED_VALIDATION_FAILED")
        sys.exit(1)

    # Print final report
    print(f"FINAL_STATUS={FINAL_STATUS_COMPLETE}")
    print(f"RETURN_DIR={RETURN_DIR}")
    print(f"ARCHIVE={ARCHIVE}")
    print(f"IDENTITY={IDENTITY}")
    print(f"SHA256={archive_sha}")
    print(f"BYTES={archive_bytes}")
    print(f"SUMMARY_COUNTS={json.dumps(summary)}")

if __name__ == "__main__":
    main()
