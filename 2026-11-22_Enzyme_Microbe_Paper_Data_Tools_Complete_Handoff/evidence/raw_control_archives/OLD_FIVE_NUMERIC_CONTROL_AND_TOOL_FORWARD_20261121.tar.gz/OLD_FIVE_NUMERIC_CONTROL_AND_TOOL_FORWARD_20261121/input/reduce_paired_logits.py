#!/usr/bin/env python3
"""CPU-only reducer for explicitly bound five-seed paired-control vectors.
Run: python reduce_paired_logits.py --input-dir RAW --out-dir METRICS
Not a GPU runner; no torch/pickle imports, no threshold exemptions.
"""
import argparse,hashlib,json,math
from pathlib import Path
SEEDS=['40','41','42','43','44']
def sigmoid(x):
 if x>=0:return 1.0/(1.0+math.exp(-x))
 ex=math.exp(x);return ex/(1.0+ex)
def reduce_record(r):
 uids=r['pool_uids'];shas=r['pool_shas'];n=len(uids)
 assert n>0 and len(shas)==n and len(set(uids))==n
 assert all(len(s)==64 for s in shas)
 assert hashlib.sha256(r['model_reaction'].encode()).hexdigest()==r['model_key_sha256']
 assert r['seeds']==SEEDS and set(r['checkpoint_shas'])==set(SEEDS)
 assert all(len(s)==64 for s in r['checkpoint_shas'].values())
 assert len(r['gold_flags'])==n
 # Every condition must explicitly describe input identity/protocol before
 # comparisons can be interpreted as route effects vs batch effects.
 assert set(r['condition_metadata'])==set(r['conditions'])
 for name,meta in r['condition_metadata'].items():
  assert meta['protocol'] and len(meta['input_identity_sha256'])==64
  assert meta['candidate_identity'] in ['same_original_order','explicit_permutation_restored','same_original_order_after_split']
 out={'arm':r['arm'],'ctx':r['ctx'],'step_id':r['step_id'],'conditions':{},'pairs':{}}
 rankings={};means={}
 for name,vectors in r['conditions'].items():
  assert set(vectors)==set(SEEDS)
  for values in vectors.values():assert len(values)==n and all(isinstance(x,(float,int)) and math.isfinite(x) for x in values)
  p=[sum(sigmoid(float(vectors[s][i])) for s in SEEDS)/5 for i in range(n)]
  order=sorted(range(n),key=lambda i:(-p[i],hashlib.sha256(uids[i].encode()).hexdigest()))
  pos={idx:rank for rank,idx in enumerate(order,1)}
  goldranks=[pos[i] for i,g in enumerate(r['gold_flags']) if g]
  best=min(goldranks) if goldranks else None
  out['conditions'][name]={'ensemble_formula':'mean(sigmoid(logit_seed))','probabilities':p,'rank_uids':[uids[i] for i in order],
   'best_gold_rank':best,'hits':{str(k):None if best is None else int(best<=k) for k in [1,3,5,10]},'mrr':None if best is None else 1.0/best,'input_metadata':r['condition_metadata'][name]}
  means[name]=p;rankings[name]=pos
 baseline=r['baseline_condition'];assert baseline in means
 for name in means:
  if name==baseline:continue
  diffs=[abs(a-b) for a,b in zip(means[baseline],means[name])]
  ad=[abs(r['conditions'][baseline][s][i]-r['conditions'][name][s][i]) for s in SEEDS for i in range(n)]
  aa=rankings[baseline];bb=rankings[name]
  out['pairs'][baseline+'__vs__'+name]={'max_abs_logit_delta':max(ad),'max_abs_probability_delta':max(diffs),'changed_candidate_ranks':sum(aa[i]!=bb[i] for i in range(n)),
   'changed_gold_ranks':sum(aa[i]!=bb[i] for i,g in enumerate(r['gold_flags']) if g),'top1_agree':min(aa,key=aa.get)==min(bb,key=bb.get),
   'hit_changes':{str(k):out['conditions'][baseline]['hits'][str(k)]!=out['conditions'][name]['hits'][str(k)] for k in [1,3,5,10]},
   'comparison_scope':{'baseline':r['condition_metadata'][baseline],'variant':r['condition_metadata'][name]}}
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input-dir',required=True);ap.add_argument('--out-dir',required=True);args=ap.parse_args()
 dest=Path(args.out_dir);dest.mkdir(parents=True,exist_ok=True);index=[]
 for p in sorted(Path(args.input_dir).glob('*.json')):
  r=json.loads(p.read_text());rr=reduce_record(r);q=dest/p.name;q.write_text(json.dumps(rr,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
  index.append({'source_file':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'result_file':str(q),'result_sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
 assert index,'no paired raw records'
 (dest/'REDUCTION_MANIFEST.json').write_text(json.dumps(index,indent=2)+'\n');print('paired_records_reduced',len(index))
if __name__=='__main__':main()
