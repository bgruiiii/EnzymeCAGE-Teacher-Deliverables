#!/usr/bin/env python3
"""R4 numerical control NC2 (per-problem): consumer-side impact of TODAY's
generation batch (RESCUE_GENERATED_NODE_20261103) evaluated ON THE ACTUAL 382
PROBLEM POOLS — per step (each problem's FULL candidate pool), per seed 40-44,
and on the 5-seed ensemble rank. This replaces the criticized cross-256-row
aggregate Top10 metric with per-problem evidence (prompt: 按每道题完整池、
逐seed/集成rank评估影响，不把跨256行总排序Top10当逐题证明).

Arm: new_esmc600m (largest today-batch consumption: 4950 rows). S8 stack +
NewArmIndexV3 chain = the scoring consumer itself.

Method: for every gated step row whose value is currently consumed from a
STORE layer (pocket CORRECTED_JULY/S10_SEPT/S11_SEPT; global FORMAL_JULY/
S10_SEPT/S11_SEPT) AND a today-batch regeneration exists (node cache: global
= mean(0); pocket = node[registered indices of the same route] when rows
match), forward the step twice per seed: baseline (store) vs substituted
(today), whole-step pure batch. Per step records: |Δlogit| distributions on
substituted rows, containment on non-substituted rows, per-seed rank changes
WITHIN the step, gold-row rank changes, top1/3/10 membership changes within
the step, and ensemble-rank changes. Rescue-consumed rows (no store
counterpart) cannot be counterfactually substituted — they inherit the
measured delta class, disclosed with counts.
Output: runtime/pc_perstep/NC2_PERSTEP_IMPACT.json + NC2_PERSTEP_ROWS.tsv.
"""
import csv, glob, hashlib, json, os, pickle, sys, time
from collections.abc import Mapping
from pathlib import Path

import numpy as np

_NEWROOT = str(Path(__file__).resolve().parents[1])
_PKG = _NEWROOT + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, _PKG + "/sources")
import r3_paths as P
sys.path.insert(0, _PKG + "/scripts")
import recovery_helpers as RH
import r2_lib as L2
import r3_consumer as C3

POOL = P.NEWROOT + "/runtime/pool"
OUT = P.NEWROOT + "/runtime/pc_perstep"
os.makedirs(OUT, exist_ok=True)
RH.require_scoring_gate(POOL)

os.environ.setdefault("ENZYMECAGE_SHARD_CACHE_SIZE", "all")
sys.path.insert(0, P.S8CODE)
import pandas as pd
import torch
import enzymecage.dataset.geometric as geom
import torch_geometric.data as pyg_data
from torch_geometric.loader import DataLoader
from enzymecage.model import EnzymeCAGE

t0 = time.time()
def log(*a): print(f"[{time.time()-t0:7.1f}s]", *a, flush=True)
sha_text = lambda s: hashlib.sha256(s.encode()).hexdigest()
DEV = torch.device("cuda:0")
FOLLOW = ["protein", "reaction_feature", "esm_feature", "substrates", "products"]
DIM = 1152
SEEDS = [40, 41, 42, 43, 44]
CKPT_SHA = {40: "bf1cf1d3ec717d7e162ccae763ca5415eb97410b64acc50864afb2c45ae9dc42",
            41: "979e08d769b3abe6dd128617f1f074501abba751256519209e45e597f952dd00",
            42: "6f86e3bf4416b38d730716fc6c505f020d4a90e959395152df40cb38e86da32a",
            43: "91ef971b289d5a3914bf3ca246ffa1ac872c358a6cee7fc49929a0b050982b97",
            44: "d57f50bb25acd797999099c3f2291df5cb60444e17dbacc9b49f5391bbcc05b7"}

# ---- chain (the scoring consumer) ----
overlays = C3.load_overlays()
core = C3.NewArmIndexV3("main", pd, torch, overlays)
log("chain overlays:", {k: len(v) for k, v in overlays.items() if k != "_manifest"})

# ---- today-batch node cache ----
CACHE = P.NEWROOT + "/runtime/extraction/cache_nodes"
node_shas = {fn[:-4] for fn in os.listdir(CACHE) if fn.endswith(".npy")}
log("node cache:", len(node_shas))
node_memo = {}
def node_of(sha):
    if sha not in node_memo:
        node_memo[sha] = np.load(f"{CACHE}/{sha}.npy")
    return node_memo[sha]

# ---- registered indices for pocket substitution (same routes as stores) ----
corr_idx = {}
with open(P.CORR_JSONL) as f:
    for line in f:
        if line.strip():
            j = json.loads(line); corr_idx[j["UniprotID"]] = [int(x) for x in j["corrected_untrimmed_indices"]]
carrier_idx = {}
cdf = pd.read_parquet(P.CARRIER_PARQUET)
for r in cdf.itertuples(index=False):
    carrier_idx.setdefault(str(r.UniprotID), [int(x) for x in str(r.pocket_indices_1based).split(",") if x != ""])

STORE_P_TAGS = {"CORRECTED_JULY", "S10_SEPT", "S11_SEPT"}
STORE_G_TAGS = {"FORMAL_JULY", "S10_SEPT", "S11_SEPT"}

class OverrideView(Mapping):
    def __init__(self, base, over): self.base, self.over = base, over
    def __getitem__(self, k): return self.over[k] if k in self.over else self.base[k]
    def __contains__(self, k): return k in self.over or k in self.base
    def __iter__(self):
        seen = set()
        for k in list(self.over) + list(self.base):
            if k not in seen: seen.add(k); yield k
    def __len__(self): return len(list(iter(self)))
    def source_of(self, k): return "TODAY_SUBSTITUTED" if k in self.over else (self.base.source_of(k) if hasattr(self.base, "source_of") else None)

def build_ds(s, auids, pocket_map, global_map, m2i_cache):
    fr = geom.pd.DataFrame({"UniprotID": auids, "CANO_RXN_SMILES": [s["model_reaction"]] * len(auids),
                            "sequence": list(s["pool_seqs"]), "Label": [0] * len(auids)})
    ds = geom.GeometricDataset.__new__(geom.GeometricDataset); pyg_data.Dataset.__init__(ds)
    ds.df_data = fr; ds.pocket_node_feature = pocket_map; ds.esm_dim = DIM
    ds.protein_dict = core.gvp_store; ds.esm_feat_dict = global_map; ds.rxn_feat_dict = core.rxn_fp
    ds.uniprot_ids = list(auids); ds.rxns = [s["model_reaction"]] * len(auids)
    ds.targets = [0] * len(auids); ds.seqs = list(s["pool_seqs"]); ds.weights = torch.ones(len(auids))
    ds.mol_to_index = m2i_cache
    ds.mol_to_data = core.molecule_graphs
    ds.reacting_center_map = core.reaction_centers
    return ds

def fwd(m, ds):
    b = next(iter(DataLoader(ds, batch_size=len(ds.uniprot_ids), shuffle=False, follow_batch=FOLLOW))).to(DEV)
    with torch.no_grad():
        o = m.forward(b)
    if isinstance(o, tuple): o = o[0]
    v = o.detach().cpu().to(torch.float64).numpy().reshape(-1)
    assert np.isfinite(v).all()
    return v

def make_model(seed):
    p = P.CKPT["new_esmc600m"].format(seed=seed)
    h = L2.sha_file(p)
    assert h == CKPT_SHA[seed], f"ckpt sha {seed}"
    torch.manual_seed(seed)
    m = EnzymeCAGE(use_esm=True, use_structure=True, use_drfp=True, use_prods_info=False,
                   plm_model="esmc600m", plm_dim=DIM, interaction_method="geo-enhanced-interaction",
                   rxn_inner_interaction=True, pocket_inner_interaction=True, device=str(DEV)).to(DEV)
    ck = torch.load(p, map_location="cpu", weights_only=False)
    m.load_state_dict(ck["model_state_dict"], strict=True); m.eval()
    assert getattr(m, "sigmoid_readout", None) is False
    return m

report_rows = []
summary_steps = {"eligible": 0, "processed": 0, "skipped_no_substitutable": 0}
rank_changes_hist = []
gold_rank_changes = []
topk_changes = {"top1": 0, "top3": 0, "top10": 0}
ens_rank_changes = []
ens_gold_rank_changes = []
sub_deltas = []
unsub_max = []
rescue_only_rows_total = 0

models = {}
ROW_COLS = ["ctx", "step_id", "n_rows", "n_substituted", "n_sub_global", "n_sub_pocket",
            "n_rescue_consumed_rows", "sub_delta_max", "sub_delta_median", "unsub_delta_max",
            "per_seed_rank_changes_mean", "gold_rank_changes_seeds", "ensemble_rank_changes",
            "ensemble_gold_rank_changes", "top1_changed"]
rows_f = open(OUT + "/NC2_PERSTEP_ROWS.tsv", "w")
rows_f.write("\t".join(ROW_COLS) + "\n")
for ctx in P.CTXS:
    log(f"===== ctx {ctx} =====")
    # bind reaction per ctx (chain object reuse like gf)
    rx = P.RXN[ctx]
    with open(rx + "/rxn2fp_merged.pkl", "rb") as f: core.rxn_fp = pickle.load(f)
    with open(rx + "/reacting_center_merged.pkl", "rb") as f: core.reaction_centers = pickle.load(f)
    mdir = Path(rx + "/mol_conformation")
    mtab = pd.read_csv(mdir / "mol2id.csv")
    core.molecule_index = frozenset(mtab["SMILES"].astype(str))
    m2i = dict(zip(mtab.SMILES.astype(str), mtab.ID))
    core.molecule_graphs = torch.load(mdir / "mol_graph_dict.pt", map_location="cpu", weights_only=False)
    core.ctx = ctx
    steps = json.load(open(f"{POOL}/UNIFIED_STEP_TABLE_{ctx}.json"))
    core.set_sha_map([(sq, sh) for s in steps for sq, sh in zip(s["pool_seqs"], s["pool_shas"])])
    for s in steps:
        auids = s["asset_uids_new"]
        seqs, shas = s["pool_seqs"], s["pool_shas"]
        # substitution plan for this step
        over_pocket, over_global, sub_mask, rescue_rows = {}, {}, [], 0
        for i, (au, sq, sh) in enumerate(zip(auids, seqs, shas)):
            is_sub = False
            if sh in node_shas:
                n = node_of(sh)
                g_tag = core.global_source_of(sq)
                if g_tag in STORE_G_TAGS:
                    over_global[sq] = np.ascontiguousarray(n.mean(0), dtype=np.float32)
                    is_sub = True
                p_tag = core.pocket_store.source_of(au)
                if p_tag in STORE_P_TAGS:
                    idxs = corr_idx.get(au) if p_tag == "CORRECTED_JULY" else carrier_idx.get(au)
                    if idxs:
                        try:
                            sp = np.asarray(core.pocket_store[au])
                            if sp.shape[0] == len(idxs) and max(idxs) < n.shape[0] and min(idxs) >= 0:
                                over_pocket[au] = np.ascontiguousarray(n[list(idxs)], dtype=np.float32)
                                is_sub = True
                        except Exception:
                            pass
            sub_mask.append(is_sub)
            pr = core.pocket_store.source_of(au) if au in core.pocket_store else ""
            if pr == "RESCUE_R3D":
                rescue_rows += 1
        if not any(sub_mask):
            summary_steps["skipped_no_substitutable"] += 1
            continue
        summary_steps["eligible"] += 1
        rescue_only_rows_total += rescue_rows
        # datasets built ONCE per step and reused across seeds (model-independent)
        ds_b = build_ds(s, auids, core.pocket_store, core.sequence_esm, m2i)
        ds_s = build_ds(s, auids, OverrideView(core.pocket_store, over_pocket),
                        OverrideView(core.sequence_esm, over_global), m2i)
        Ls_base, Ls_sub = [], []
        for seed in SEEDS:
            if seed not in models:
                models[seed] = make_model(seed)
                log(f"  model seed {seed} loaded")
            m = models[seed]
            Ls_base.append(fwd(m, ds_b))
            Ls_sub.append(fwd(m, ds_s))
        sub_mask = np.array(sub_mask)
        d_all = np.abs(Ls_sub[0] - Ls_base[0])
        d_sub = d_all[sub_mask]; d_unsub = d_all[~sub_mask]
        sub_deltas.extend(d_sub.tolist())
        if len(d_unsub): unsub_max.append(float(d_unsub.max()))
        # per-seed rank changes within the step
        n_sub_rank = 0; gold_moved = []
        for k, seed in enumerate(SEEDS):
            rb = np.argsort(-Ls_base[k], kind="stable"); rs = np.argsort(-Ls_sub[k], kind="stable")
            pos_b = np.empty(len(rb), dtype=int); pos_b[rb] = np.arange(len(rb))
            pos_s = np.empty(len(rs), dtype=int); pos_s[rs] = np.arange(len(rs))
            moved = int((pos_b != pos_s).sum())
            n_sub_rank += moved
            for gi, g in enumerate(s["gold_flags"]):
                if g and pos_b[gi] != pos_s[gi]:
                    gold_moved.append({"seed": seed, "row": gi, "rank_base": int(pos_b[gi]), "rank_sub": int(pos_s[gi])})
            if k == 0:
                for kk in (1, 3, 10):
                    if len(rb) >= kk:
                        topk_changes[f"top{kk}"] += int(set(rb[:kk].tolist()) != set(rs[:kk].tolist()))
        # ensemble
        eb = np.mean(Ls_base, axis=0); es = np.mean(Ls_sub, axis=0)
        rb = np.argsort(-eb, kind="stable"); rs = np.argsort(-es, kind="stable")
        pos_b = np.empty(len(rb), dtype=int); pos_b[rb] = np.arange(len(rb))
        pos_s = np.empty(len(rs), dtype=int); pos_s[rs] = np.arange(len(rs))
        ens_moved = int((pos_b != pos_s).sum())
        ens_rank_changes.append(ens_moved)
        ens_gold = [{"row": gi, "rank_base": int(pos_b[gi]), "rank_sub": int(pos_s[gi])}
                    for gi, g in enumerate(s["gold_flags"]) if g and pos_b[gi] != pos_s[gi]]
        ens_gold_rank_changes.extend([{"step_id": s["step_id"], **x} for x in ens_gold])
        rank_changes_hist.append(n_sub_rank // len(SEEDS))
        row = {"ctx": ctx, "step_id": s["step_id"], "n_rows": len(auids),
               "n_substituted": int(sub_mask.sum()), "n_sub_global": len(over_global), "n_sub_pocket": len(over_pocket),
               "n_rescue_consumed_rows": rescue_rows,
               "sub_delta_max": float(d_sub.max()) if len(d_sub) else None,
               "sub_delta_median": float(np.median(d_sub)) if len(d_sub) else None,
               "unsub_delta_max": float(d_unsub.max()) if len(d_unsub) else 0.0,
               "per_seed_rank_changes_mean": round(n_sub_rank / len(SEEDS), 2),
               "gold_rank_changes_seeds": len(gold_moved),
               "ensemble_rank_changes": ens_moved, "ensemble_gold_rank_changes": len(ens_gold),
               "top1_changed": int(set(np.argsort(-Ls_base[0])[:1].tolist()) != set(np.argsort(-Ls_sub[0])[:1].tolist()))}
        report_rows.append(row)
        rows_f.write("\t".join(str(row[k]) for k in ROW_COLS) + "\n"); rows_f.flush()
        summary_steps["processed"] += 1
        if summary_steps["processed"] % 25 == 0:
            log(f"  steps processed {summary_steps['processed']} ({time.time()-t0:.0f}s)")

d_sub_arr = np.array(sub_deltas)
report = {
    "nc": "NC2_PERSTEP_SUBSTITUTION_IMPACT_new_esmc600m",
    "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "gate_sha": json.load(open(f"{POOL}/ALL_MODELS_ASSETS_READY.json"))["consumer_ledger_sha256"],
    "arm": "new_esmc600m", "seeds": SEEDS, "protocol": "WHOLE_STEP_PURE_BATCH per problem",
    "steps": summary_steps,
    "substituted_rows_total": int(len(d_sub_arr)),
    "rescue_consumed_rows_not_substitutable": rescue_only_rows_total,
    "sub_delta": {"min": float(d_sub_arr.min()) if len(d_sub_arr) else None,
                   "median": float(np.median(d_sub_arr)) if len(d_sub_arr) else None,
                   "p90": float(np.percentile(d_sub_arr, 90)) if len(d_sub_arr) else None,
                   "max": float(d_sub_arr.max()) if len(d_sub_arr) else None},
    "unsub containment: per-step max over non-substituted rows": {"max": max(unsub_max) if unsub_max else 0.0},
    "per_seed_rank_changes_per_step": {"mean": float(np.mean(rank_changes_hist)) if rank_changes_hist else None,
                                         "max": int(np.max(rank_changes_hist)) if rank_changes_hist else None},
    "ensemble_rank_changes_per_step": {"mean": float(np.mean(ens_rank_changes)) if ens_rank_changes else None,
                                         "max": int(np.max(ens_rank_changes)) if ens_rank_changes else None},
    "steps_with_gold_rank_change_per_seed": sum(1 for r in report_rows if r["gold_rank_changes_seeds"] > 0),
    "steps_with_gold_rank_change_ensemble": sum(1 for r in report_rows if r["ensemble_gold_rank_changes"] > 0),
    "gold_rank_change_events_ensemble": len(ens_gold_rank_changes),
    "topk_membership_step_changes_seed40": topk_changes,
    "steps_processed": len(report_rows),
}
tmp = OUT + "/NC2_PERSTEP_IMPACT.json.tmp"
json.dump(report, open(tmp, "w"), indent=1)
os.replace(tmp, OUT + "/NC2_PERSTEP_IMPACT.json")
rows_f.close()
with open(OUT + "/NC2_PERSTEP_ROWS.tsv.tmp", "w") as f:
    w = csv.DictWriter(f, fieldnames=list(report_rows[0].keys()) if report_rows else [], delimiter="\t")
    w.writeheader()
    for r in report_rows: w.writerow(r)
os.replace(OUT + "/NC2_PERSTEP_ROWS.tsv.tmp", OUT + "/NC2_PERSTEP_ROWS.tsv")
log("NC2 DONE", json.dumps({k: report[k] for k in ("steps", "substituted_rows_total", "sub_delta",
    "steps_with_gold_rank_change_ensemble", "topk_membership_step_changes_seed40")}, default=str))
