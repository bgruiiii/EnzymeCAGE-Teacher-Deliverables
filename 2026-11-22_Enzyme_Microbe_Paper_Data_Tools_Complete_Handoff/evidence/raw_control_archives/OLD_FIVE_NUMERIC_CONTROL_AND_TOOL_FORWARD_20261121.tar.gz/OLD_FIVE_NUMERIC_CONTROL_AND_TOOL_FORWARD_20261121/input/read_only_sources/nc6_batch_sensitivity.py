#!/usr/bin/env python3
"""NC6: batch-composition rank sensitivity of the two EnzGFM arms, quantified
on the actual gated problem pools. Context: the new_enzgfm650m seed41 main
smoke showed V2 (split-half counterfactual batch) moving 2 adjacent ranks at
max delta 0.013 with top1 stable and V1 (production same-batch
reproducibility) perfect at <=1e-5. This probe classifies the effect:

For each arm x seed(40-44) x step sample (both ctx smoke steps + the 30
largest gated steps): whole-step forward vs split-half forward; record max
|delta|, rank flips, top1 flips, and the minimal whole-batch adjacent logit
gap among flipped pairs (near-tie evidence). The PRODUCTION protocol is
whole-step uniform for every scored row; the split is a counterfactual probe
only — results are disclosure inputs, never a substitution route.

Output: runtime/pc_enzgfm/NC6_BATCH_COMPOSITION_SENSITIVITY.json (+ per-row TSV)
"""
import csv, hashlib, json, os, pickle, sys, time
from pathlib import Path
import numpy as np

_NEWROOT = str(Path(__file__).resolve().parents[1])
_PKG = _NEWROOT + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, _PKG + "/sources")
import r3_paths as P
sys.path.insert(0, _PKG + "/scripts")
import recovery_helpers as RH
sys.path.insert(0, _NEWROOT + "/scripts_node")
POOL = P.NEWROOT + "/runtime/pool"
OUT = P.NEWROOT + "/runtime/pc_enzgfm"
os.makedirs(OUT, exist_ok=True)
RH.require_scoring_gate(POOL)
os.environ.setdefault("ENZYMECAGE_SHARD_CACHE_SIZE", "all")
sys.path.insert(0, P.S8CODE)
import pandas as pd
import torch
import enzymecage.dataset.geometric as geom
import torch_geometric.data as pyg_data
from torch_geometric.loader import DataLoader
from enzymecage.model import EnzymeCAGE
import enzgfm_chains as EC

t0 = time.time()
def log(*a): print(f"[{time.time()-t0:6.1f}s]", *a, flush=True)
DEV = torch.device("cuda:0")
FOLLOW = ["protein", "reaction_feature", "esm_feature", "substrates", "products"]
DIM = 2048
SEEDS = [40, 41, 42, 43, 44]
ARMS = {"current_e0_enzgfm650m": ("EnzGFM-650M", {40: 9, 41: 5, 42: 5, 43: 7, 44: 3}),
        "new_enzgfm650m": ("enzgfm650m", None)}
CK = {}
with open(_PKG + "/MODEL_IDENTITIES_27.tsv") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        if r["inventory_role"] == "PRIMARY_COMPARISON" and r["arm"] in ARMS:
            CK[(r["arm"], int(r["seed"]))] = (r["path"], r["sha256"])

from enzymecage.dataset.sharded_protein import _load_sharded_mapping, load_protein_gvp_data
chains = EC.R1Chains(_load_sharded_mapping, load_protein_gvp_data)
e0_lanes = {}
e0_views, e0_seq, e0_sha, e0_closure = EC.build_e0_lane()
log("chains + E0 lane ready")

def resolve(arm, uid, sh, seq):
    if arm == "current_e0_enzgfm650m":
        seq_a = e0_seq.get(uid)
        if seq_a is not None and e0_sha.get(uid) == sh and seq_a == seq:
            e0g, e0p, e0gv = e0_views["global"], e0_views["pocket"], e0_views["gvp"]
            if uid in e0gv and uid in e0p and seq_a in e0g:
                pk = np.asarray(e0p[uid], dtype=np.float32); gv = e0gv[uid]; gl = np.asarray(e0g[seq_a], dtype=np.float32)
                if 0 < int(np.asarray(gv[0]).shape[0]) == int(pk.shape[0]) <= len(seq):
                    return (uid, pk, gv, gl)
    aun = uid
    pk, _ = chains.pocket_get(aun); gv, _ = chains.gvp_get(aun)
    if pk is None or gv is None:
        ru = chains.route_uid(uid, sh)
        if ru:
            pk2, _2 = chains.pocket_get(ru); gv2, _3 = chains.gvp_get(ru)
            if pk2 is not None and gv2 is not None: aun, pk, gv = ru, pk2, gv2
    gl, _4, _5 = chains.global_get(seq)
    if pk is None or gv is None or gl is None: return None
    return (aun, pk, gv, gl)

RXN = {}
def bind(ctx):
    if ctx not in RXN:
        rx = P.RXN[ctx]
        fp = pickle.load(open(rx + "/rxn2fp_merged.pkl", "rb"))
        ce = pickle.load(open(rx + "/reacting_center_merged.pkl", "rb"))
        mtab = pd.read_csv(rx + "/mol_conformation/mol2id.csv")
        mg = torch.load(rx + "/mol_conformation/mol_graph_dict.pt", map_location="cpu", weights_only=False)
        RXN[ctx] = (fp, ce, dict(zip(mtab.SMILES.astype(str), mtab.ID)), mg)
    return RXN[ctx]

def build_ds(ctx, rxn, seqs, res):
    fp, ce, m2i, mg = bind(ctx)
    uids = [r[0] for r in res]
    fr = pd.DataFrame({"UniprotID": uids, "CANO_RXN_SMILES": [rxn] * len(uids),
                       "sequence": list(seqs), "Label": [0] * len(uids)})
    ds = geom.GeometricDataset.__new__(geom.GeometricDataset); pyg_data.Dataset.__init__(ds)
    ds.df_data = fr; ds.pocket_node_feature = {u: r[1] for u, r in zip(uids, res)}; ds.esm_dim = DIM
    ds.protein_dict = {u: r[2] for u, r in zip(uids, res)}
    ds.esm_feat_dict = {sq: r[3] for sq, r in zip(seqs, res)}
    ds.rxn_feat_dict = fp; ds.uniprot_ids = uids; ds.rxns = [rxn] * len(uids)
    ds.targets = [0] * len(uids); ds.seqs = list(seqs); ds.weights = torch.ones(len(uids))
    ds.mol_to_index = m2i; ds.mol_to_data = mg; ds.reacting_center_map = ce
    return ds

def fwd(m, ds):
    b = next(iter(DataLoader(ds, batch_size=len(ds.uniprot_ids), shuffle=False, follow_batch=FOLLOW))).to(DEV)
    with torch.no_grad():
        o = m.forward(b)
    if isinstance(o, tuple): o = o[0]
    v = o.detach().cpu().to(torch.float64).numpy().reshape(-1)
    assert np.isfinite(v).all()
    return v

def make_model(arm, seed):
    plm, _ = ARMS[arm]
    p, want = CK[(arm, seed)]
    assert hashlib.sha256(open(p, "rb").read()).hexdigest() == want
    torch.manual_seed(seed)
    m = EnzymeCAGE(use_esm=True, use_structure=True, use_drfp=True, use_prods_info=False,
                   plm_model=plm, plm_dim=DIM, interaction_method="geo-enhanced-interaction",
                   rxn_inner_interaction=True, pocket_inner_interaction=True, device=str(DEV)).to(DEV)
    ck = torch.load(p, map_location="cpu", weights_only=False)
    m.load_state_dict(ck["model_state_dict"], strict=True)
    return m.eval()

# step sample: both ctx smoke (largest) + 30 largest overall
sample = []
for ctx in P.CTXS:
    steps = json.load(open(f"{POOL}/UNIFIED_STEP_TABLE_{ctx}.json"))
    biggest = max(steps, key=lambda s: len(s["pool_uids"]))
    sample.append((ctx, biggest))
    rest = sorted((s for s in steps if s["step_id"] != biggest["step_id"]),
                  key=lambda s: -len(s["pool_uids"]))[:15]
    sample.extend((ctx, s) for s in rest)
log("sample steps:", len(sample))

rows_out = []
summary = {}
for arm in ARMS:
    srec = {"flips_total": 0, "top1_flips_total": 0, "steps_probed": 0, "max_v2": 0.0,
            "flip_pair_min_gaps": [], "by_seed": {}}
    for seed in SEEDS:
        m = make_model(arm, seed)
        sf = {"flips": 0, "top1": 0, "steps": 0, "max_v2": 0.0}
        for ctx, s in sample:
            res = [resolve(arm, u, sh, sq) for u, sh, sq in zip(s["pool_uids"], s["pool_shas"], s["pool_seqs"])]
            if any(r is None for r in res):
                rows_out.append({"arm": arm, "seed": seed, "ctx": ctx, "step_id": s["step_id"], "status": "RESOLVE_MISS_SKIPPED"})
                continue
            L = fwd(m, build_ds(ctx, s["model_reaction"], s["pool_seqs"], res))
            half = len(L) // 2
            la = fwd(m, build_ds(ctx, s["model_reaction"], s["pool_seqs"][:half], res[:half]))
            lb = fwd(m, build_ds(ctx, s["model_reaction"], s["pool_seqs"][half:], res[half:]))
            split = np.concatenate([la, lb])
            dmax = float(np.max(np.abs(split - L)))
            ra = np.argsort(-L, kind="stable"); rb = np.argsort(-split, kind="stable")
            pa = np.empty(len(ra), int); pa[ra] = np.arange(len(ra))
            pb = np.empty(len(rb), int); pb[rb] = np.arange(len(rb))
            flipped = np.where(pa != pb)[0]
            top1_flip = int(ra[0] != rb[0])
            gaps = []
            for i in flipped:
                r = pa[i]
                if r + 1 < len(L):
                    gaps.append(float(abs(L[ra[r]] - L[ra[r + 1]])))
            srec["steps_probed"] += 1; sf["steps"] += 1
            srec["flips_total"] += len(flipped); sf["flips"] += len(flipped)
            srec["top1_flips_total"] += top1_flip; sf["top1"] += top1_flip
            srec["max_v2"] = max(srec["max_v2"], dmax); sf["max_v2"] = max(sf["max_v2"], dmax)
            srec["flip_pair_min_gaps"].extend(gaps)
            rows_out.append({"arm": arm, "seed": seed, "ctx": ctx, "step_id": s["step_id"], "status": "PROBED",
                             "n_rows": len(L), "v2_max_abs": dmax, "rank_flips": len(flipped),
                             "top1_flip": top1_flip, "flipped_pair_gaps": ";".join("%.4g" % g for g in gaps),
                             "logit_abs_median": float(np.median(np.abs(L)))})
        srec["by_seed"][str(seed)] = sf
        log(f"{arm} seed{seed}: steps {sf['steps']} flips {sf['flips']} top1 {sf['top1']} maxV2 {sf['max_v2']:.2e}")
        del m; torch.cuda.empty_cache()
    gaps = srec["flip_pair_min_gaps"]
    srec["flip_pair_gap_stats"] = {"n": len(gaps), "max": max(gaps) if gaps else None,
                                    "median": float(np.median(gaps)) if gaps else None}
    del srec["flip_pair_min_gaps"]
    summary[arm] = srec
with open(OUT + "/NC6_ROWS.tsv.tmp", "w") as f:
    w = csv.DictWriter(f, fieldnames=list(rows_out[0].keys()), delimiter="\t", extrasaction="ignore")
    w.writeheader()
    for r in rows_out: w.writerow(r)
os.replace(OUT + "/NC6_ROWS.tsv.tmp", OUT + "/NC6_ROWS.tsv")
rep = {"nc": "NC6_BATCH_COMPOSITION_SENSITIVITY_enzgfm_arms",
       "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
       "protocol_note": "production scoring = WHOLE_STEP_PURE_BATCH uniform for all rows/seeds/steps; split-half is a counterfactual probe only",
       "sample": {"steps_per_ctx": 16, "seeds": SEEDS},
       "arms": summary}
tmp = OUT + "/NC6_BATCH_COMPOSITION_SENSITIVITY.json.tmp"
json.dump(rep, open(tmp, "w"), indent=1)
os.replace(tmp, OUT + "/NC6_BATCH_COMPOSITION_SENSITIVITY.json")
log("NC6 DONE", json.dumps(summary, default=str)[:600])
