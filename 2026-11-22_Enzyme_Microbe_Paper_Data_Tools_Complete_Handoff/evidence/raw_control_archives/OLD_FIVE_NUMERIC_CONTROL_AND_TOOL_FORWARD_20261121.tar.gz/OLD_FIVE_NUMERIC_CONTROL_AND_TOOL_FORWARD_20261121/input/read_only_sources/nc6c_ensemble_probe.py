"""NC6c: ensemble-level (5-seed mean, the evaluation statistic) batch-composition
sensitivity on the two ctx smoke steps for both EnzGFM arms. Complements NC6
(per-seed) with the decision-relevant ensemble number."""
import csv, hashlib, json, os, pickle, sys, time
from pathlib import Path
import numpy as np
_NEWROOT = str(Path(__file__).resolve().parents[1])
_PKG = _NEWROOT + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, _PKG + "/sources"); sys.path.insert(0, _PKG + "/scripts"); sys.path.insert(0, _NEWROOT + "/scripts_node")
import r3_paths as P, recovery_helpers as RH
POOL = P.NEWROOT + "/runtime/pool"; OUT = P.NEWROOT + "/runtime/pc_enzgfm"
RH.require_scoring_gate(POOL)
os.environ.setdefault("ENZYMECAGE_SHARD_CACHE_SIZE", "all")
sys.path.insert(0, P.S8CODE)
import pandas as pd, torch
import enzymecage.dataset.geometric as geom, torch_geometric.data as pyg_data
from torch_geometric.loader import DataLoader
from enzymecage.model import EnzymeCAGE
import enzgfm_chains as EC
from enzymecage.dataset.sharded_protein import _load_sharded_mapping, load_protein_gvp_data
t0=time.time()
def log(*a): print(f"[{time.time()-t0:6.1f}s]", *a, flush=True)
DEV = torch.device("cuda:0"); FOLLOW = ["protein","reaction_feature","esm_feature","substrates","products"]; DIM=2048; SEEDS=[40,41,42,43,44]
ids={}
with open(_PKG+"/MODEL_IDENTITIES_27.tsv") as f:
    for r in csv.DictReader(f,delimiter="\t"):
        if r["inventory_role"]=="PRIMARY_COMPARISON" and r["arm"] in ("current_e0_enzgfm650m","new_enzgfm650m"): ids[(r["arm"],int(r["seed"]))]=(r["path"],r["sha256"])
chains = EC.R1Chains(_load_sharded_mapping, load_protein_gvp_data)
e0_views, e0_seq, e0_sha, _ = EC.build_e0_lane()
def resolve(arm,uid,sh,seq):
    if arm=="current_e0_enzgfm650m":
        sa=e0_seq.get(uid)
        if sa is not None and e0_sha.get(uid)==sh and sa==seq:
            e0g,e0p,e0gv=e0_views["global"],e0_views["pocket"],e0_views["gvp"]
            if uid in e0gv and uid in e0p and sa in e0g:
                pk=np.asarray(e0p[uid],dtype=np.float32);gv=e0gv[uid];gl=np.asarray(e0g[sa],dtype=np.float32)
                if 0<int(np.asarray(gv[0]).shape[0])==int(pk.shape[0])<=len(seq): return (uid,pk,gv,gl)
    aun=uid; pk,_=chains.pocket_get(aun); gv,_=chains.gvp_get(aun)
    if pk is None or gv is None:
        ru=chains.route_uid(uid,sh)
        if ru:
            pk2,_2=chains.pocket_get(ru); gv2,_3=chains.gvp_get(ru)
            if pk2 is not None and gv2 is not None: aun,pk,gv=ru,pk2,gv2
    gl,_4,_5=chains.global_get(seq)
    if pk is None or gv is None or gl is None: return None
    return (aun,pk,gv,gl)
RXN={}
def bind(ctx):
    if ctx not in RXN:
        rx=P.RXN[ctx]; mtab=pd.read_csv(rx+"/mol_conformation/mol2id.csv")
        RXN[ctx]=(pickle.load(open(rx+"/rxn2fp_merged.pkl","rb")),pickle.load(open(rx+"/reacting_center_merged.pkl","rb")),
                  dict(zip(mtab.SMILES.astype(str),mtab.ID)),torch.load(rx+"/mol_conformation/mol_graph_dict.pt",map_location="cpu",weights_only=False))
    return RXN[ctx]
def build_ds(ctx,rxn,seqs,res):
    fp,ce,m2i,mg=bind(ctx); uids=[r[0] for r in res]
    fr=pd.DataFrame({"UniprotID":uids,"CANO_RXN_SMILES":[rxn]*len(uids),"sequence":list(seqs),"Label":[0]*len(uids)})
    ds=geom.GeometricDataset.__new__(geom.GeometricDataset); pyg_data.Dataset.__init__(ds)
    ds.df_data=fr; ds.pocket_node_feature={u:r[1] for u,r in zip(uids,res)}; ds.esm_dim=DIM
    ds.protein_dict={u:r[2] for u,r in zip(uids,res)}; ds.esm_feat_dict={sq:r[3] for sq,r in zip(seqs,res)}
    ds.rxn_feat_dict=fp; ds.uniprot_ids=uids; ds.rxns=[rxn]*len(uids); ds.targets=[0]*len(uids)
    ds.seqs=list(seqs); ds.weights=torch.ones(len(uids)); ds.mol_to_index=m2i; ds.mol_to_data=mg; ds.reacting_center_map=ce
    return ds
def fwd(m,ds):
    b=next(iter(DataLoader(ds,batch_size=len(ds.uniprot_ids),shuffle=False,follow_batch=FOLLOW))).to(DEV)
    with torch.no_grad(): o=m.forward(b)
    if isinstance(o,tuple): o=o[0]
    v=o.detach().cpu().to(torch.float64).numpy().reshape(-1); assert np.isfinite(v).all(); return v
def make_model(arm,seed):
    plm="EnzGFM-650M" if arm=="current_e0_enzgfm650m" else "enzgfm650m"
    p,want=ids[(arm,seed)]; assert hashlib.sha256(open(p,"rb").read()).hexdigest()==want
    torch.manual_seed(seed)
    m=EnzymeCAGE(use_esm=True,use_structure=True,use_drfp=True,use_prods_info=False,plm_model=plm,plm_dim=DIM,
                 interaction_method="geo-enhanced-interaction",rxn_inner_interaction=True,pocket_inner_interaction=True,device=str(DEV)).to(DEV)
    ck=torch.load(p,map_location="cpu",weights_only=False); m.load_state_dict(ck["model_state_dict"],strict=True); return m.eval()
rep={"utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"statistic":"5-seed mean logits (evaluation ensemble)","arms":{}}
for arm in ("current_e0_enzgfm650m","new_enzgfm650m"):
    rep["arms"][arm]={}
    for ctx in P.CTXS:
        steps=json.load(open(f"{POOL}/UNIFIED_STEP_TABLE_{ctx}.json"))
        smoke=max(steps,key=lambda s:len(s["pool_uids"]))
        res=[resolve(arm,u,sh,sq) for u,sh,sq in zip(smoke["pool_uids"],smoke["pool_shas"],smoke["pool_seqs"])]
        assert all(r is not None for r in res)
        seqs=smoke["pool_seqs"]; half=len(res)//2
        Ws=[];Ss=[]
        for seed in SEEDS:
            m=make_model(arm,seed)
            Ws.append(fwd(m,build_ds(ctx,smoke["model_reaction"],seqs,res)))
            la=fwd(m,build_ds(ctx,smoke["model_reaction"],seqs[:half],res[:half]))
            lb=fwd(m,build_ds(ctx,smoke["model_reaction"],seqs[half:],res[half:]))
            Ss.append(np.concatenate([la,lb]))
            del m; torch.cuda.empty_cache()
        EW=np.mean(Ws,axis=0); ES=np.mean(Ss,axis=0)
        rk=lambda v: np.argsort(np.argsort(-v,kind="stable"),kind="stable")
        gold=[i for i,g in enumerate(smoke["gold_flags"]) if g]
        rep["arms"][arm][ctx]={"step_id":smoke["step_id"],"pool":len(res),
            "ens_max_abs_delta":float(np.max(np.abs(EW-ES))),"ens_median_abs_delta":float(np.median(np.abs(EW-ES))),
            "ens_rank_changes":int((rk(EW)!=rk(ES)).sum()),"ens_top1_agree":int(np.argmax(EW)==np.argmax(ES)),
            "gold_rank_changes":int(sum(1 for g in gold if rk(EW)[g]!=rk(ES)[g])),"n_golds":len(gold),
            "logit_abs_median":float(np.median(np.abs(EW)))}
        log(arm,ctx,json.dumps(rep["arms"][arm][ctx]))
tmp=OUT+"/NC6C_ENSEMBLE_SENSITIVITY.json.tmp"; json.dump(rep,open(tmp,"w"),indent=1); os.replace(tmp,OUT+"/NC6C_ENSEMBLE_SENSITIVITY.json")
log("NC6C DONE")
