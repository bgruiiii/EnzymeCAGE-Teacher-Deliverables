# 晨羽接续：原五组数值缺口与独立工具真实forward补证（不重训）

2026-11-21。TASK_ID=`OLD_FIVE_NUMERIC_GATES_AND_STANDALONE_FORWARD_20261121`。

用户已授权：能本地做先做，确需GPU可写卡到晨羽执行，但**不重训**。本卡是补有界推理/证据，不覆盖新3B行序修复，不改depending main。先向用户说明“师姐要资料/证据链，本卡数值补证是审计发现”，不能把所有补测说成师姐要求重跑全部模型。

## 0. 两条线隔离、只一张已有空闲GPU

新3B已有`CHENYU_NEW3B_CURRENT95_ALIGNMENT_R1_START_WITH_EVIDENCE_20261121.md`在另一窗口。**不得接管该窗口、不修改其R1目录/代码/权重/共享tensor，不把它的新3B perm套给原五臂。** 本卡可以先CPU；GPU阶段只用确认空闲的一张现有卡，若与该任务/其它任务冲突就等待释放，不kill、不调显存、不租卡。记录GPU UUID/环境/进程、持有专用排他锁，worker自身持锁贯穿子进程，不靠手动touch锁。

原科学成绩/原raw/原COMMON/原admission/原脚本保持只读。所有新增代码与结果用独立根：

```
BASE=/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031
OLD=$BASE/five_model_complete_20261103
OUT=$BASE/old_five_numeric_control_20261121
```

主GPU用现有`/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python`及原消费者环境，ESM编码器若仅查元数据不可加载；不重提ESM特征、不生成新结构、不改asset carrier、不换PLM/seed/checkpoint、不fine-tune、不train()/backward()/optimizer、不新付费API。库/feature/package只读，不pip改既有环境。

## 1. 起步包与先读范围

小包由协调端提供：`OLD_FIVE_NUMERIC_CONTROL_EVIDENCE_20261121.tar.gz`，旁置.sha256。上传位置见启动卡或协调端汇报，先核外SHA，安全解包到OUT/input；拒绝绝对路径/..、重名、链接和设备，不异内容覆盖。核包内SHA256SUMS。

包内CONTROL_REQUESTS.json锁定原5臂×5checkpoint SHA，219个NC2步骤、31个NC6步骤的明确成员清单及旧失败值；read_only_sources是**阅读证据，不可直接import执行**（历史脚本顶层会load模型/写原OUT）。standalone_tool是复审R3代码；B1表压缩件解到OUT/input并核**解压后**原字节SHA。

包内每个step的membership是集合证书，不是模型输入顺序。**评分必须取原POOL/raw的冻结顺序**；严禁使用已发表rank顺序作为候选batch顺序。完整query/model key/科学UID/SHA/asset UID/特征recipe/checkpoint/context需逐项绑定。

历史源位置：OLD下的`current95_five_model_complete_prep_20261103/{sources,scripts}`、`scripts_node`、`runtime/{pool,pc_perstep,pc_enzgfm,pc_genimpact,pc_remedy}`与`gf_out/<arm>/<ctx>`。若缺某项先在同一登记工作区的原同名回包内读，不全盘扫描、不读.env/key/history，不靠猜路径替换代码。

**先完成CPU阶段，不因“有GPU”跳过输入/有序配对/协议门。**

## 2. CPU阶段：明确能测什么，冻结后才跑

1. 核25个实际所用checkpoint，至少消费前完整SHA；不可把预训练ESM2权重当ranker。只加载本卡需要的固定best，一卡顺序。冻结本次worker源码、启动manifest/expected副本、实际消费文件SHA；结束复验同一启动root，不用届时可变manifest重新自证。
2. 给原normal生产配置与原存档reference建精确表：dtype/device/matmul/TF32/autocast/CUBLAS/torch/PyG/batch_size/全步padding/bounded helper源码。默认保持各臂原协议：3B及新600M=已核bounded16，旧600M/两EnzGFM=原whole-step。COMMON/源文件为权威；不同就停相关项，不硬套本卡概述。
3. 核科学序列、PDB/目标GVP有序残基与PLM切片对应，不能只看UID/行数/finite。能复用已审映射就复用；未知来源不得标CLOSED。若发现输入真实错误，记录并停受影响项，交主审决定修复范围，不能在本卡静默改原科学特征再声称replay通过。
4. 查指定旧控制目录是否已有完整A/B逐seed logits。协调端已只读核：常见JSON/TSV保留统计量，未找到全向量；别反复全盘找。原目录有chunk_000000.pt等payload，其schema与身份必须先核，不能因有tensor就冒称是paired logits。若确为已有同对象控制向量，可CPU复算替代对应新forward，记录来源SHA。
5. 输出固定CONTROL_EXECUTION_PLAN.json，列全部组/step/seed/condition/原门/输入SHA/协议。禁止看新得分后挑题或降低阈值。不以测得max×1.5定义新的“原门”。CPU工程检查通过后继续本卡GPU阶段，授权已给，不再只回READY。

## 3. GPU A：旧600M严格replay缺口（有限固定案例）

原NC3见input/LEGACY600_HISTORICAL_REPLAY_GATE.tsv：4个冻结poll298控制案例×seed40–44×5repeat=100记录，原max=1.52587890625e-5，高于历史**绝对差1e-5**；失败集中poll298-380cb0329f8c seed41。原文件/失败不删。

使用实际历史`PC_LEGACY_REMEDY.json`对应scorer和原reference向量，不仅挑seed41。原normal设置、原whole-step、原候选顺序、相同权重/asset/反应，重做同4案例全部5seed、固定5repeat；每个repeat保存逐候选原logit及绑定身份。分别报：vs历史冻结reference、vs本次首run，max/分位数与原1e-5门。**不反复重跑直到碰巧PASS**，不把相对容差/allclose默认替代绝对1e-5。

原reference完整向量无法找回就报REFERENCE_NOT_RETAINED，该vs历史项不伪PASS。仍可做本次run-to-run，但含义单列。

若normal未过，可做**独立附录**的固定确定性诊断，明确环境变量必须进程启动前设置，记录torch deterministic/CUBLAS等。它不能替代原normal、不能覆盖历史失败，也不能追认为原成绩在原门下复现。不要重新冻结/覆盖原25checkpoint或382步成绩。

## 4. GPU B：新600M路线影响，正确概率集成

原NC1替换特征影响界**0.05 logit绝对差**失败（max0.43217）；原NC2 219步的“ensemble”用mean(logit)，不等于正式mean(sigmoid)。不能只改输出字段名。

- 固定input中原NC2的219步骤，每步**完整原候选池**、相同query/权重/顺序。A=原实际消费的feature视图；B=只在有明确同recipe反事实材料的行，用已存在today node缓存按原索引/route替换；其它所有输入不动。不得重提全序列、修饰token/BOS/EOS/pooling、换GVP或用同名不同序列。rescue-only无旧counterpart的行明确NON_SUBSTITUTABLE，不造反事实、不拿991行代表全部3237行。
- **主要控制采用实际新600M生产bounded16及固定全步padding**，A/B同协议；baseline A与对应原raw比较，基线不符须记录，不用后续结果掩盖。
- 原NC2是whole-step对照。另对原6个Gold rank变化步骤做whole-step A/B，作为复核历史控制的独立层；不要将其结果冒充bounded16生产证明，也不将两个协议平均。
- 保存每步5seed A/B原logit全向量，科学UID/SHA/asset UID/query/key/seed权重SHA、每行baseline/substituted特征摘要、route/PDB/ordered-index身份、substitution mask及协议。
- CPU计算各seed sigmoid，再五概率均值，比较全部候选rank、top1/3/5/10、Gold rank/每步MRR变化。使用原冻结评价同分规则（科学UID SHA），不是wrapper的UID词典序。按原0.05门分别标失败/通过；不根据“Top1不变”自签原门PASS。
- 无法构成同recipe替换的行/步单列原因；实际完成少于219则按实际覆盖交，不删未完成记录凑“219通过”。改变科学表示/索引定义的需求交主审，不自行定新规则。

## 5. GPU C：两EnzGFM的batch影响，保存正确ensemble证据

取input明确的原NC6 **31个context×step**，不是另挑最好表现的31步。两臂×5seed；同一完整冻结池：

1. A：生产whole-step normal；A_repeat：同配置另一次；
2. REVERSE：候选整体逆序同一batch，按UID恢复到原顺序后比较；
3. SPLIT：原序列切半分别forward再拼回。它是反事实诊断，**不能当生产改为分批的许可**。保存每个子batch实际padding/最大图/形状，不把改变padding混说为纯顺序效应。

全部条件保存逐seed全向量，按mean(sigmoid)计算。优先回答生产相同协议repeat是否稳定，再报逆序/拆批如何影响probability与rank。原“measured max×1.5”报警界只是旧报告的数据依赖范围，不签成原严格门。原NC6b某样本E0逆序max9.54e-6，不能写“全部≤1e-6”；原NC6 max5.335不等于每一步或五seed概率均有同等变化。

确定性模式如运行另名分层，不替代normal；不换seed/epoch/dtype、不中途调阈值，不做全382×5臂重测，也不把新3B的训练确定性结果挪过来。

## 6. GPU D：独立工具真实forward小验收（可独立成功，不混入原C2）

包内standalone_tool R3已做真实R0 parquet+完整C8 CPU验证，不是仅桩测。真实R0列没有production_retrieval_eligible，R3已按原b2a/b2b模式修复；exact/repr/undirected归组与原算法做了3查询独立对账。库为R0，与最终策展CAP100池不同，不能强求新检索候选数等于13/31。

- 用wrapper原生三根配置（wrapper代码、EnzymeCAGE源码、v1权重包），不patch depending节点。不升级环境。
- 先以最终已审S02/S03的精确目标model_reaction及原固定pool，调用R3实际scoring adapter+真实runtime（不runtime_factory、不test double）。对每UID先核资产序列SHA。保留last_trace的5seed全分、原响应TopK、R3全量分/TopK，核一次真实调用中公式和排序一致、原目标query不被召回top1替换。raw/正控身份和actual_model_forward_calls有记录。
- 这是wrapper whole-step真实调用；原C2的3B为bounded16，不能声称与旧C2所有值必逐字节相同。若另做原protocol对比，明确协议差异并保留实际差值，不更换旧raw。
- 再做**1个真实Top10检索→构池→目标评分→来源→C8/SCNET读取**的有限串联（默认选S02，同一target）：缺反应资产/蛋白资产/表外来源逐条类型化，不能为了得到整链SUCCESS删候选/补零/换目标/借用另一step。真实返回15个候选并不自动等于冻结评价13个；B1仅固定7468队列，表外UID如实未覆盖。
- 完整C8已在节点原路径，需核SHA=d51a540db2f9798d65e25b46f22960ba29ae2d4b288be218c83c299f24f5d5af；B1固定表只读，不新增NCBI/BacDive查询或SCNET作业。本卡不把现有性状改成筛选规则。

## 7. 向量格式、验收和停止

包内reduce_paired_logits.py是CPU减算器，验5seed/UID唯一/SHA/query-key/finite/condition身份并计算mean(sigmoid)，不是GPU runner。worker可薄适配到所需JSON schema：

```text
arm, ctx, step_id, model_reaction, model_key_sha256
pool_uids, pool_shas, gold_flags, seeds=["40",...,"44"], checkpoint_shas
baseline_condition="A"
conditions={"A":{"40":[...],...},"B":{...},...}
condition_metadata={condition:{protocol,input_identity_sha256,candidate_identity,...}}
```

candidate_identity只可为same_original_order/explicit_permutation_restored/same_original_order_after_split。input_identity_sha256须对应实际保存的条件输入清单正文，不造占位64hex。各condition均按原顺序，非有限立即typed失败。减算器有合成公式反例/NaN负控，不冒称模型实验通过。

最终新增回包`OLD_FIVE_NUMERIC_CONTROL_AND_TOOL_FORWARD_20261121.tar.gz`：

- 开始/结束原件与源/权重/环境/实际tensor身份；不可只hash目录清单字符串。
- 原门对账表：历史失败、现在normal/确定性/反事实分层，不能统称“全部闭合”。
- 全A/B/repeat/reverse/split逐seed向量及所消费特征/候选/反应/权重绑定，CPU重算报告和缺失覆盖表；输出与所有失败都保存。
- 实际运行脚本（版本冻结）、API调用/forward计数、wall/RAM/GPU记录、源码diff和输入/输出manifest；大feature/模型权重不打包。
- 工具真实forward与1步有限串联单列，ENV/ASSET缺项诚实记录；depending未改。
- 一页白话结果：哪些证据补齐、哪些门仍失败、分数/排名影响什么、不能据此下什么结论。若仍有科学身份/规则冲突，给具体证据等用户确认，不为拿PASS自行改科学合同。

先CPU小控制，再按A→B→C→D顺序（一窗口、一卡、checkpoint尽量顺序复用）。同任务已有产物先校验后续缺项；固定次数完成即停，不挑“最好一次”。新forward是独立验证实验，不覆盖历史结果或反签历史PASS。GPU计费预算若显示明显超出这组有界控制、发生OOM需改变批协议/大资产缺失，停相关子项交证据，其余独立子项可继续。

**阶段状态以实测为准，主审复审前不给五组解除全部限制。** 不发师姐/黄老师、不上传GitHub、不部署main、不启动训练。

