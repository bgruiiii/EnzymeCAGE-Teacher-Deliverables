#!/bin/bash
# sequential single-card driver: waits for stage B completion, then C, then D
O=/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121
PY=/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python
while ! grep -q STAGE_B_DONE $O/logs/stage_b.log 2>/dev/null; do
  if ! pgrep -f stage_b.py >/dev/null; then echo "$(date +%H:%M) stage B process gone without DONE marker; ABORT chain"; exit 1; fi
  sleep 60
done
echo "$(date +%H:%M) B done; starting C"
$PY -B -X faulthandler $O/worker/stage_c.py >> $O/logs/stage_c.log 2>&1
RC=$?
echo "$(date +%H:%M) C exit $RC"
if ! grep -q STAGE_C_DONE $O/logs/stage_c.log; then echo "C FAILED; still attempting D (independent subitem per plan)"; fi
CUDA_VISIBLE_DEVICES=0 $PY -B -X faulthandler $O/worker/stage_d.py >> $O/logs/stage_d.log 2>&1
echo "$(date +%H:%M) D exit $?"
