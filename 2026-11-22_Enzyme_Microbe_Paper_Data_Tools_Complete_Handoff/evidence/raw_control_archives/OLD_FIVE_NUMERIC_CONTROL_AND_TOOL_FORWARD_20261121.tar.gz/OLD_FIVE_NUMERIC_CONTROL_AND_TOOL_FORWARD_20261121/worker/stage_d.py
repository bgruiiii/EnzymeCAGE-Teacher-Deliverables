#!/usr/bin/env python3
"""GPU D: standalone tool REAL forward acceptance. Wrapper native three-root
config only (wrapper code snapshot roots, EnzymeCAGE source root, v1 weights
package); the real enzyme_cage_wrapper scoring adapter + real initialize_runtime
(no runtime_factory, no test doubles). D1: the final-reviewed pathway
BIOPATH150_001 steps S02/S03 scored on the frozen original pool with per-UID
asset sequence SHA verification by the backend; one real call saved with the
5-seed last_trace full vectors, the original response TopK, the R3 full
scores/TopK, and internal formula/ordering consistency (wrapper rule =
mean-of-5-seed-logits + quantile CI, order (-score, uid); the OFFICIAL
mean(sigmoid) formula is recomputed separately for disclosure and NOT claimed
equal). D2: one bounded real chain Top10 retrieval -> pool -> target scoring
-> sources -> C8 trait read (SCNET/DEHP audited package is not on this node ->
recorded missing, no new BacDive/SCNET jobs). No depending node patched; no
env upgrades."""
import hashlib, json, math, os, sys, time

OUT = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
BASE = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
REPO_OLD = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
TOOL = OUT + "/input/standalone_tool"
WS = "/usrdata/EnzymeCAGE_data/workspaces"
CENSUS_R0 = WS + "/enzymecage_pollutant_biodegradation_category_capacity_census_r0_20260920/01_funnel"
C8_PATH = "/usrdata/EnzymeCAGE_data/data/releases/20260915_microbial_traits_v1/microbial_traits/base/C8_METATRAITS_LOOKUP_INDEX.jsonl"
WRAP_ROOT = WS + "/path_enzyme_microbe_code_review_20261110/review_payload/src_snapshot"

os.environ.setdefault("PYTHONHASHSEED", "0")
sys.path.insert(0, OUT + "/worker")
import gpu_lock
sys.path.insert(0, TOOL)
t0 = time.time()
log = lambda *a: print(f"[{time.time()-t0:7.1f}s]", *a, flush=True)
fd = gpu_lock.acquire("stageD")
VD = OUT + "/stageD"; os.makedirs(VD, exist_ok=True)

from enzyme_host_tool.config import ToolConfig, RetrievalCfg, PoolCfg, ScoringCfg, SourcesCfg, TraitsCfg
from enzyme_host_tool.scoring_backends import EnzymeCAGEWrapperBackend
from enzyme_host_tool.predict import predict_reaction

def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()

env_rec = {"python": sys.version.split()[0], "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
           "PYTHONHASHSEED": os.environ.get("PYTHONHASHSEED"), "gpu_uuid": gpu_lock.GPU_UUID,
           "three_roots": {"wrapper_code_root": WRAP_ROOT, "enzymecage_source_root": REPO_OLD,
                           "weights_package_root": REPO_OLD + "/HPC_Returned_Result_Summaries/enzymecage_v1_20260714"},
           "wrapper_predictor_sha256": sha(WRAP_ROOT + "/wrapper/predictor.py"),
           "wrapper_utils_sha256": sha(WRAP_ROOT + "/wrapper/utils.py"),
           "c8_index_sha256_expected": "d51a540db2f9798d65e25b46f22960ba29ae2d4b288be218c83c299f24f5d5af",
           "c8_index_sha256_actual": sha(C8_PATH),
           "scnet_dehp_package": "ALL_SIX_SOURCES_PREDICTED_TRAITS_LONG.tsv.gz NOT FOUND on node -> SCNET backend not configured, recorded missing; no new SCNET/BacDive jobs"}
assert env_rec["c8_index_sha256_actual"] == env_rec["c8_index_sha256_expected"], "C8 identity drift"

sig = ScoringCfg(backend="enzyme_cage_wrapper", wrapper_code_root=WRAP_ROOT,
                 enzymecage_source_root=REPO_OLD,
                 weights_package_root=REPO_OLD + "/HPC_Returned_Result_Summaries/enzymecage_v1_20260714",
                 top_k=10, return_ci=True)

POOL = BASE + "/runtime/pool"
steps_main = {s["step_id"]: s for s in json.load(open(f"{POOL}/UNIFIED_STEP_TABLE_main.json"))}
# final-reviewed pathway BIOPATH150_001 consecutive steps S02/S03 (the 13-candidate
# frozen pool matches the review example); S03 is the same pathway's next step.
D1_STEPS = ["BIOPATH150_001__S02__BSY-r00595", "BIOPATH150_001__S03__BSY-r00596"]
sigmoid = lambda x: 1.0 / (1.0 + math.exp(-x)) if x >= 0 else math.exp(x) / (1.0 + math.exp(x))
d1_out = {}
for sid in D1_STEPS:
    s = steps_main[sid]
    pairs = list(zip(s["pool_uids"], s["pool_shas"]))
    backend = EnzymeCAGEWrapperBackend(sig)
    outcome = backend.score(s["model_reaction"], pairs)
    rt = backend._rt
    trace = getattr(rt, "last_trace", None) or {}
    per_seed = trace.get("per_seed_scores") or []
    valid = trace.get("valid_uids") or []
    # internal consistency of THIS real call: response scores == wrapper aggregate
    # recomputed from the saved 5-seed trace; Top-K is a display prefix; order (-score, uid).
    checks = {}
    if outcome.status == "OK" and len(per_seed) == 5 and per_seed and len(per_seed[0]) == len(valid):
        mean_logit = {u: sum(row[i] for row in per_seed) / 5.0 for i, u in enumerate(valid)}
        recomputed = sorted(valid, key=lambda u: (-mean_logit[u], u))
        wrapper_order = [c.uid for c in outcome.all_scored]
        checks["scores_match_wrapper_aggregate"] = all(
            next(c for c in outcome.all_scored if c.uid == u).score == mean_logit[u] for u in valid[:5])
        checks["ordering_matches_recomputed_rule"] = wrapper_order == recomputed
        checks["topk_is_prefix_slice"] = [c.uid for c in outcome.all_scored if c.display_rank is not None] == wrapper_order[:min(sig.top_k, len(wrapper_order))]
        mean_sig = {u: sum(sigmoid(row[i]) for row in per_seed) / 5.0 for i, u in enumerate(valid)}
        checks["official_mean_sigmoid_disclosure"] = {
            "top5_sigmoid_order": sorted(valid, key=lambda u: (-mean_sig[u], u))[:5],
            "differs_from_wrapper_rule": sorted(valid, key=lambda u: (-mean_sig[u], u)) != wrapper_order}
        checks["note"] = "wrapper rule is mean-of-five-seed-logits + quantile CI (v1 HPC artifact); official current95 ensemble formula mean(sigmoid) kept separate, not claimed equal"
    d1_out[sid] = {
        "step_id": sid, "model_reaction": s["model_reaction"], "model_key_sha256": s["model_key_sha256"],
        "pool_uids": s["pool_uids"], "pool_shas": s["pool_shas"], "frozen_order_note": "scoring order = frozen pool order",
        "query_binding": {"query_sent_to_scoring": s["model_reaction"], "target_not_replaced": True},
        "scoring_status": outcome.status,
        "not_evaluated": [vars(n) for n in outcome.not_evaluated],
        "not_disclosed": outcome.not_disclosed,
        "response_topk": [{"uid": c.uid, "score": c.score, "rank": c.rank, "display_rank": c.display_rank} for c in outcome.all_scored[:10]],
        "full_scores": [{"uid": c.uid, "score": c.score, "rank": c.rank} for c in outcome.all_scored],
        "last_trace_forward_executed": trace.get("forward_executed"),
        "last_trace_batch": {"batch_count": trace.get("batch_count"), "batch_size": trace.get("batch_size"),
                             "protocol": "wrapper whole-step pure batch (batch_size=len(valid)); NOT byte-comparable with old C2 bounded16 by construction"},
        "five_seed_full_vectors": {u: [per_seed[k][i] for k in range(5)] for i, u in enumerate(valid)} if valid else {},
        "consistency_checks": checks,
        "model_version": outcome.model_version, "evidence_hash": outcome.evidence_hash,
        "actual_model_forward_calls_total_so_far": getattr(rt, "forward_call_count", None)}
    log(sid, "status", outcome.status, "valid", len(valid))

with open(VD + "/D1_real_calls_S02_S03.json", "w") as f:
    json.dump(d1_out, f, indent=1)

# ---- D2: one bounded real chain on S02 (same target) ----
cfg2 = ToolConfig(
    retrieval=RetrievalCfg(backend="fixed_r3",
                           master_parquet=CENSUS_R0 + "/REACTION_MASTER_POOL.parquet",
                           pairs_parquet=CENSUS_R0 + "/ALL_SCIENTIFIC_PAIRS.parquet",
                           mode="PRODUCTION_INCLUDE_EXACT"),
    pool=PoolCfg(max_size=None),
    scoring=sig,
    sources=SourcesCfg(backend="b1_revision1_table", b1_table=OUT + "/input/B1_UID_SOURCE_MAP_7468.tsv"),
    traits=TraitsCfg(c8_lookup_index=C8_PATH))
res = predict_reaction(steps_main[D1_STEPS[0]]["model_reaction"],
                       step_id=D1_STEPS[0], pathway_id="BIOPATH150_001", config=cfg2,
                       model_reaction=steps_main[D1_STEPS[0]]["model_reaction"], recall_topk=10)
payload = {"step_id": D1_STEPS[0], "model_reaction": steps_main[D1_STEPS[0]]["model_reaction"],
           "model_key_sha256": steps_main[D1_STEPS[0]]["model_key_sha256"],
           "query_representation_source": res.query_representation_source,
           "target_query_not_replaced_by_recall_top1": bool(res.model_query_reaction == steps_main[D1_STEPS[0]]["model_reaction"]
                                                            and res.query_representation_source == "caller_model_reaction"),
           "retrieval_status": res.retrieval_status, "retrieval_mode": res.retrieval_mode,
           "recall_repr_used": res.recall_repr_used,
           "n_groups": len(res.groups), "pool_candidates": len(res.pool_candidates),
           "pool_status": res.pool_status, "scoring_status": res.scoring_status,
           "n_full_scores": len(res.all_candidate_scores),
           "topk": [vars(c) if hasattr(c, "__dict__") else c for c in res.ranked[:10]],
           "not_evaluated": [vars(n) for n in res.not_evaluated][:200],
           "scores_not_disclosed": res.scores_not_disclosed[:200],
           "n_hosts": len(res.hosts),
           "hosts_status_dist": {},
           "frozen_eval_pool_n": len(steps_main[D1_STEPS[0]]["pool_uids"]),
           "note": "R0 library pool differs from final curated CAP100 pool; candidate counts not forced equal",
           "environment": env_rec}
from collections import Counter
hosts_status = Counter(h.status for h in res.hosts)
traits_status = Counter(getattr(t, "status", "") for t in res.traits)
payload["hosts_status_dist"] = dict(hosts_status)
payload["traits_status_dist"] = dict(traits_status)
payload["traits_full"] = [vars(t) if hasattr(t, "__dict__") else t for t in res.traits][:40]
payload["step_error"] = getattr(res, "step_error", None)
payload["raw_all_scores"] = [{"uid": c.uid, "sha": c.sequence_sha256, "score": c.score, "rank": c.rank,
                              "display_rank": c.display_rank} for c in res.all_candidate_scores]
payload["groups_top10"] = [{"rank": g.rank, "cd": g.reaction_cd, "similarity": g.similarity,
                            "n_pairs": g.associated_pairs} for g in res.groups[:10]]
with open(VD + "/D2_chain_S02.json", "w") as f:
    json.dump(payload, f, indent=1)
log("D2 chain scoring", payload["scoring_status"], "pool", payload["pool_candidates"],
    "retrieval", payload["retrieval_status"])
json.dump({"d1": {k: v["scoring_status"] for k, v in d1_out.items()},
           "d2": payload["scoring_status"]}, open(VD + "/STATUS.json", "w"), indent=1)
print("STAGE_D_DONE", flush=True)
