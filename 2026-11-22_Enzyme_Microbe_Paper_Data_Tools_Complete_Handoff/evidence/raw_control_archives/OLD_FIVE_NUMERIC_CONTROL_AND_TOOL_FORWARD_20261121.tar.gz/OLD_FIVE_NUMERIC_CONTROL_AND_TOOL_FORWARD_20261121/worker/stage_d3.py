#!/usr/bin/env python3
"""GPU D3 positive-control appendix: the SAME real wrapper runtime (same native
three-root config) is invoked on a reaction + candidate pool that lies inside
the v1 weights package's own delivered scope (from its 3b_ensemble test_result
rows, e.g. RHEA 83435). Purpose: demonstrate the real-adapter path executes a
true 5-seed forward with formula/ordering consistency, and compare against the
ORIGINAL v1 delivered per-row pred values (identity disclosed, semantics
differences stated). This is NOT the S02/S03 pair and is labelled as an
in-scope positive control; it does not re-sign or replace the typed
REACTION/ENZYME_ASSET_MISSING findings for the out-of-scope targets."""
import csv, hashlib, json, os, sys, time
from collections import Counter

OUT = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
REPO_OLD = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
V1 = REPO_OLD + "/HPC_Returned_Result_Summaries/enzymecage_v1_20260714"
TOOL = OUT + "/input/standalone_tool"
WRAP_ROOT = "/usrdata/EnzymeCAGE_data/workspaces/path_enzyme_microbe_code_review_20261110/review_payload/src_snapshot"
os.environ.setdefault("PYTHONHASHSEED", "0")
sys.path.insert(0, OUT + "/worker")
import gpu_lock
sys.path.insert(0, TOOL)
from enzyme_host_tool.config import ScoringCfg
from enzyme_host_tool.scoring_backends import EnzymeCAGEWrapperBackend

t0 = time.time()
log = lambda *a: print(f"[{time.time()-t0:7.1f}s]", *a, flush=True)
fd = gpu_lock.acquire("stageD3")

rows = list(csv.DictReader(open(V1 + "/3b_ensemble/seed_40/test_result.csv")))
rxn_counts = Counter(r["RHEA_ID"] for r in rows)
# fixed documented rule (no pass-seeking): the delivered-test reaction with
# 30-60 rows, most rows first, ties by ascending RHEA id.
elig = sorted([k for k, v in rxn_counts.items() if 30 <= v <= 60], key=lambda k: (-rxn_counts[k], k))
target_rhea = elig[0]
log("selection rule elig head:", elig[:6], "chosen:", target_rhea, "rows:", rxn_counts[target_rhea])
sub = [r for r in rows if r["RHEA_ID"] == target_rhea]
rxn = sub[0]["CANO_RXN_SMILES"]
uids, seen = [], set()
pred = {}
for r in sub:
    if r["UniprotID"] not in seen:
        seen.add(r["UniprotID"]); uids.append(r["UniprotID"]); pred[r["UniprotID"]] = float(r["pred"])
log("positive control RHEA", target_rhea, "rows", len(sub), "uids", len(uids))

import math
sigmoid = lambda x: 1.0/(1.0+math.exp(-x)) if x >= 0 else math.exp(x)/(1.0+math.exp(x))
sig_cfg = ScoringCfg(backend="enzyme_cage_wrapper", wrapper_code_root=WRAP_ROOT,
                     enzymecage_source_root=REPO_OLD, weights_package_root=V1, top_k=10, return_ci=True)
backend = EnzymeCAGEWrapperBackend(sig_cfg)
# verify enzyme sequence identity against the v1 asset store itself
rt = backend._runtime()
csv_seq = {}
for r in sub:
    csv_seq.setdefault(r["UniprotID"], r["sequence"])
pairs = []
ne_pre = []
for u in uids:
    if not rt.asset_index.has_enzyme(u):
        ne_pre.append((u, "ENZYME_ASSET_MISSING")); continue
    s = str(rt.asset_index.sequence_for(u))
    sha_store = hashlib.sha256(s.encode()).hexdigest()
    sha_csv = hashlib.sha256(str(csv_seq.get(u, "")).encode()).hexdigest() if csv_seq.get(u) else None
    if sha_csv is not None and sha_csv != sha_store:
        ne_pre.append((u, "SEQUENCE_IDENTITY_CONFLICT_csv_vs_store")); continue
    pairs.append((u, sha_store if sha_csv is None else sha_csv))
outcome = backend.score(rxn, pairs)
trace = getattr(rt, "last_trace", None) or {}
per_seed = trace.get("per_seed_scores") or []
valid = trace.get("valid_uids") or []
checks = {}
if outcome.status == "OK" and per_seed:
    mean_logit = {u: sum(row[i] for row in per_seed)/5.0 for i, u in enumerate(valid)}
    order_w = [c.uid for c in outcome.all_scored]
    recomputed = sorted(valid, key=lambda u: (-mean_logit[u], u))
    checks["scores_match_wrapper_aggregate"] = all(
        next(c for c in outcome.all_scored if c.uid == u).score == mean_logit[u] for u in valid)
    checks["ordering_matches_recomputed_rule"] = order_w == recomputed
    checks["topk_prefix"] = [c.uid for c in outcome.all_scored if c.display_rank][:sig_cfg.top_k] == order_w[:sig_cfg.top_k]
    mean_sig = {u: sum(sigmoid(row[i]) for row in per_seed)/5.0 for i, u in enumerate(valid)}
    checks["official_mean_sigmoid_disclosure"] = {u: mean_sig[u] for u in valid}
    # comparison to original delivered v1 per-row pred (single ensemble value per row)
    deltas = {u: {"our_mean_logit": mean_logit[u], "our_mean_sigmoid": mean_sig[u],
                  "v1_original_pred": pred.get(u),
                  "abs_delta_vs_mean_sigmoid": abs(mean_sig[u]-pred[u]) if u in pred else None,
                  "abs_delta_vs_mean_logit": abs(mean_logit[u]-pred[u]) if u in pred else None} for u in valid}
    ds = [v["abs_delta_vs_mean_sigmoid"] for v in deltas.values() if v["abs_delta_vs_mean_sigmoid"] is not None]
    dl = [v["abs_delta_vs_mean_logit"] for v in deltas.values() if v["abs_delta_vs_mean_logit"] is not None]
    rec = {"kind": "POSITIVE_CONTROL_INSIDE_V1_SCOPE_appendix_not_S02_S03",
           "selection_rule": "delivered-test reaction with 30-60 rows, most rows first, ties by ascending RHEA id (fixed; no pass-seeking)",
           "rhea_id": target_rhea, "reaction": rxn, "pool_uids_order": uids,
           "scoring_status": outcome.status, "n_valid": len(valid),
           "not_evaluated_pre": ne_pre,
           "not_evaluated": [vars(n) for n in outcome.not_evaluated],
           "response_topk": [{"uid": c.uid, "score": c.score, "rank": c.rank} for c in outcome.all_scored[:10]],
           "full_scores": [{"uid": c.uid, "score": c.score, "rank": c.rank} for c in outcome.all_scored],
           "last_trace": {"forward_executed": trace.get("forward_executed"),
                          "batch_count": trace.get("batch_count"), "batch_size": trace.get("batch_size"),
                          "protocol": "wrapper whole-step pure batch on THIS node"},
           "five_seed_full_vectors_logit": {u: [per_seed[k][i] for k in range(5)] for i, u in enumerate(valid)},
           "formula_ordering_checks": checks,
           "comparison_to_original_v1_pred": deltas,
           "summary_deltas": {"prob_semantics": {"max": max(ds) if ds else None, "median": (sorted(ds)[len(ds)//2] if ds else None)},
                              "logit_semantics": {"max": max(dl) if dl else None},
                              "note": "v1 delivered pred semantics vs recomputed ensembles disclosed, not claimed equal; differences not hidden and not reinterpreted"},
           "model_version": outcome.model_version, "evidence_hash": outcome.evidence_hash,
           "actual_model_forward_calls_total": getattr(rt, "forward_call_count", None),
           "environment": {"CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES"),
                           "gpu_uuid": gpu_lock.GPU_UUID}}
    json.dump(rec, open(OUT + "/stageD/D3_positive_control.json", "w"), indent=1)
    log("D3", outcome.status, "n_valid", len(valid), "forward calls", rec["actual_model_forward_calls_total"])
else:
    json.dump({"kind": "POSITIVE_CONTROL_FAILED", "status": outcome.status,
               "not_evaluated": [vars(n) for n in outcome.not_evaluated]},
              open(OUT + "/stageD/D3_positive_control.json", "w"), indent=1)
    log("D3 typed", outcome.status)
print("STAGE_D3_DONE", flush=True)
