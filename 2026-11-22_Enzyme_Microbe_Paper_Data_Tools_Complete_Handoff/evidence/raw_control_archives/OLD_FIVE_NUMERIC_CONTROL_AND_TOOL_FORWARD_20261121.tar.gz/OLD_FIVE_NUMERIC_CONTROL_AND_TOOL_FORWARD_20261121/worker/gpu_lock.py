#!/usr/bin/env python3
"""Exclusive GPU lock for this card's window. The worker process holds the
flock on OUT/gpu.lock for its whole lifetime; child subprocesses inherit the
descriptor and therefore the lock. Refuses to start if the lock is held and
verifies no foreign GPU compute process on the selected card."""
import atexit, fcntl, json, os, subprocess, sys, time

OUT = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
GPU_INDEX = 0
GPU_UUID = "GPU-9d62b8ed-5672-c816-5d5c-6cf0186b192c"

def gpu_procs():
    r = subprocess.run(["nvidia-smi", "--query-compute-apps=pid,gpu_uuid,process_name,used_memory",
                        "--format=csv,noheader"], capture_output=True, text=True)
    return [line for line in r.stdout.strip().splitlines() if line.strip()]

def acquire(tag):
    fd = os.open(OUT + "/gpu.lock", os.O_CREAT | os.O_RDWR)
    waited = False
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if not waited:
                print(f"GPU_LOCK_BUSY ({tag}); waiting for the same card's owner to release (policy: wait, never kill)", flush=True)
                waited = True
            time.sleep(60)
    atexit.register(lambda: (fcntl.flock(fd, fcntl.LOCK_UN), os.close(fd)))
    own = {str(os.getpid())}
    foreign = [l for l in gpu_procs() if l.split(",")[0].strip() not in own]
    if foreign:
        print("FOREIGN_GPU_PROCESS_PRESENT:", *foreign, sep="\n  ", flush=True)
        print("policy: wait for release, do not kill; aborting stage start", flush=True)
        sys.exit(76)
    rec = {"tag": tag, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "pid": os.getpid(), "gpu_index": GPU_INDEX, "gpu_uuid": GPU_UUID,
           "compute_apps_at_start": gpu_procs(),
           "query": subprocess.run(["nvidia-smi", "--query-gpu=index,uuid,name,memory.used,utilization.gpu",
                                    "--format=csv,noheader"], capture_output=True, text=True).stdout.strip()}
    os.makedirs(OUT + "/logs", exist_ok=True)
    print("GPU_LOCK_ACQUIRED", json.dumps(rec, indent=1), flush=True)
    return fd

def check(tag):
    own = {str(os.getpid())}
    foreign = [l for l in gpu_procs() if l.split(",")[0].strip() not in own]
    if foreign:
        print(f"GPU_CONFLICT_DETECTED ({tag}):", *foreign, sep="\n  ", flush=True)
        return False
    return True
