#!/usr/bin/env python3
"""GPU A: strict original-protocol replay of the 4 frozen legacy-600M control
cases, 5 seeds x 5 repeats, whole-step pure batch, same weights/assets/
reactions/candidate order as the historical PC_LEGACY_REMEDY run. Saves full
per-candidate logits for every repeat (reducer-schema records) and reports
both vs-historical-frozen and vs-this-card-run-to-run distributions against
the original absolute 1e-5 gate. Historical failure is preserved as-is.
Adapted from read-only historical evidence r3_pc_legacy_remedy.py (build/
make_model/whole_step_logits kept verbatim in protocol; only the case list is
restricted to the 4 frozen cases and outputs go to this OUT, never OLD)."""
import csv, hashlib, json, os, sys, time
import numpy as np, torch, yaml

OUT = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
BASE = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
PKG = BASE + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, OUT + "/worker")
import gpu_lock
sys.path.insert(0, PKG + "/sources")
import r3_paths as P
sys.path.insert(0, P.REPO_OLD)
sys.path.insert(0, P.WRAP)
from enzymecage_wrapper.asset_index import PrecomputedAssetIndex
import enzymecage.dataset.geometric as geom
import torch_geometric.data as pyg_data
from torch_geometric.loader import DataLoader
from enzymecage.model import EnzymeCAGE

t0 = time.time()
log = lambda *a: print(f"[{time.time()-t0:7.1f}s]", *a, flush=True)
REG = json.load(open(OUT + "/input/CONTROL_REQUESTS.json"))
CASES = REG["legacy_frozen_cases"]
SEEDS = [40, 41, 42, 43, 44]
K = 5
REFDIR = "/usrdata/EnzymeCAGE_data/training_runs/enzymecage_v6_298_rhea142_brenda_enzgfm650m_retrain_20260922/s11_r1_self_included_four_model_20260927/inputs/legacy/pollutant291_p2rank_legacy600m_model_matched_dual5seed_rerun_20260922/results/raw_logits_600m"
CKPT = {int(s): (v["path"], v["sha256"]) for s, v in REG["models"]["legacy_esmc600m"].items()}

fd = gpu_lock.acquire("stageA")
VA = OUT + "/stageA/vectors"; os.makedirs(VA, exist_ok=True)

cfg = yaml.safe_load(open(P.P291 + "/runtime/NEW/config.yaml"))
idx = PrecomputedAssetIndex(cfg)
dev = torch.device("cuda:0")
FOLLOW = ["protein", "reaction_feature", "esm_feature", "substrates", "products"]

def build(rxn, uids):
    fr = geom.pd.DataFrame({"UniprotID": uids, "CANO_RXN_SMILES": [rxn] * len(uids),
                            "sequence": [idx.sequence_for(u) for u in uids], "Label": [0] * len(uids)})
    ds = geom.GeometricDataset.__new__(geom.GeometricDataset); pyg_data.Dataset.__init__(ds)
    ds.df_data = fr; ds.pocket_node_feature = idx.pocket_node; ds.esm_dim = 1152
    ds.protein_dict = idx.gvp; ds.esm_feat_dict = idx.sequence_esm; ds.rxn_feat_dict = idx.rxn_fp
    ds.uniprot_ids = list(uids); ds.rxns = [rxn] * len(uids); ds.targets = [0] * len(uids)
    ds.seqs = [idx.sequence_for(u) for u in uids]; ds.weights = torch.ones(len(uids))
    ds.mol_to_index = {k: i for i, k in enumerate(idx.molecule_index)}; ds.mol_to_data = idx.molecule_graphs
    ds.reacting_center_map = idx.reaction_centers
    return ds

def make_model(seed, device):
    p, want = CKPT[seed]
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(8 << 20), b""): h.update(b)
    assert h.hexdigest() == want, f"ckpt sha mismatch seed{seed}"
    m = EnzymeCAGE(use_esm=cfg["use_esm"], use_structure=cfg["use_structure"], use_drfp=cfg["use_drfp"],
                   use_prods_info=cfg["use_prods_info"], esm_model=cfg["esm_model"],
                   interaction_method=cfg["interaction_method"], rxn_inner_interaction=cfg["rxn_inner_interaction"],
                   pocket_inner_interaction=cfg["pocket_inner_interaction"], device=str(device))
    m.load_state_dict(torch.load(p, map_location="cpu", weights_only=False), strict=True)
    return m.to(device).eval()

def whole_step_logits(m, ds, device):
    b = next(iter(DataLoader(ds, batch_size=len(ds.uniprot_ids), shuffle=False, follow_batch=FOLLOW))).to(device)
    with torch.no_grad():
        o = m.forward(b)
    if isinstance(o, tuple): o = o[0]
    return o.detach().cpu().to(torch.float64).numpy().reshape(-1)

pools = json.load(open("/usrdata/EnzymeCAGE_data/workspaces/p298_tc_20260922/T2_case_pools.json"))
summary = {"stage": "A", "arm": "legacy_esmc600m", "protocol": "WHOLE_STEP_PURE_BATCH_ORIGINAL",
           "repeats": K, "gate_original": 1e-5,
           "environment": {"torch": torch.__version__, "cuda": torch.version.cuda,
                           "allow_tf32_matmul": bool(torch.backends.cuda.matmul.allow_tf32),
                           "allow_tf32_cudnn": bool(torch.backends.cudnn.allow_tf32),
                           "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
                           "gpu": gpu_lock.GPU_UUID, "normal_no_determinism_env_preset": True},
           "cases": {}}
counts = {"forward_calls": 0}
for seed in SEEDS:
    m = make_model(seed, dev)
    assert getattr(m, "sigmoid_readout", None) is False
    for c in CASES:
        rp = f"{REFDIR}/{c}.json"
        raw = open(rp, "rb").read()
        rsha = hashlib.sha256(raw).hexdigest()
        fj = json.loads(raw)
        rxn = fj["model_cano_rxn_smiles"]; pool = fj["pool_uids"]
        assert pool == pools[c], f"pool drift {c}"
        ds = build(rxn, pool)
        seqs = [idx.sequence_for(u) for u in pool]
        runs = []
        for k in range(K):
            runs.append(whole_step_logits(m, ds, dev)); counts["forward_calls"] += 1
        rec = {"arm": "legacy_esmc600m", "ctx": "legacy_poll298_frozen", "step_id": c,
               "model_reaction": rxn, "model_key_sha256": hashlib.sha256(rxn.encode()).hexdigest(),
               "pool_uids": pool, "pool_shas": [hashlib.sha256(s.encode()).hexdigest() for s in seqs],
               "gold_flags": [False] * len(pool),
               "gold_flags_note": "these control pools carry no gold labels; ranks/hits are disclosure only, the gate is the per-candidate absolute logit delta",
               "seeds": [str(s) for s in SEEDS],
               "checkpoint_shas": {str(s): CKPT[s][1] for s in SEEDS},
               "baseline_condition": "A",
               "conditions": {"A": {str(s): [float(x) for x in runs[0]] for s in [seed]}},
               "condition_metadata": {"A": {"protocol": "WHOLE_STEP_PURE_BATCH_ORIGINAL normal repeat r0",
                                            "input_identity_sha256": hashlib.sha256(json.dumps(
                                                {"case": c, "rxn": rxn, "pool": pool, "seqs": seqs},
                                                sort_keys=True).encode()).hexdigest(),
                                            "candidate_identity": "same_original_order"}}}
        for k in range(1, K):
            rec["conditions"][f"A_repeat{k}"] = {str(seed): [float(x) for x in runs[k]]}
            rec["condition_metadata"][f"A_repeat{k}"] = rec["condition_metadata"]["A"] | {"protocol": f"WHOLE_STEP_PURE_BATCH_ORIGINAL normal repeat r{k}"}
        rec["conditions"]["REF_FROZEN"] = {str(seed): [float(x) for x in fj["raw_logits"][str(seed)]]}
        rec["condition_metadata"]["REF_FROZEN"] = {"protocol": "historical frozen reference (dual5seed rerun 20260922, original whole-step)",
                                                  "input_identity_sha256": rsha, "candidate_identity": "same_original_order"}
        ref = np.array(fj["raw_logits"][str(seed)])
        d_frz = [float(np.max(np.abs(r - ref))) for r in runs]
        d_r2r = [float(np.max(np.abs(runs[i] - runs[0]))) for i in range(1, K)]
        summary["cases"].setdefault(c, {})[str(seed)] = {
            "rows": len(pool), "delta_vs_frozen": d_frz, "delta_run_to_run": d_r2r,
            "max_delta_vs_frozen": max(d_frz), "gate_1e-5_pass_all_repeats": bool(max(d_frz) <= 1e-5),
            "reference_file_sha256": rsha}
        # per-seed slice merged into the record file
        fp = f"{VA}/stageA_{c}.json"
        if os.path.exists(fp):
            prev = json.load(open(fp))
            prev["conditions"]["A"][str(seed)] = rec["conditions"]["A"][str(seed)]
            for k in range(1, K):
                prev["conditions"][f"A_repeat{k}"][str(seed)] = [float(x) for x in runs[k]]
            prev["conditions"]["REF_FROZEN"][str(seed)] = rec["conditions"]["REF_FROZEN"][str(seed)]
            json.dump(prev, open(fp + ".tmp", "w"), indent=1); os.replace(fp + ".tmp", fp)
        else:
            json.dump(rec, open(fp + ".tmp", "w"), indent=1); os.replace(fp + ".tmp", fp)
    del m; torch.cuda.empty_cache()
    log(f"seed {seed} done; forwards so far", counts["forward_calls"])

all_frz = [x for c in CASES for s in SEEDS for x in summary["cases"][c][str(s)]["delta_vs_frozen"]]
all_r2r = [x for c in CASES for s in SEEDS for x in summary["cases"][c][str(s)]["delta_run_to_run"]]
summary["max_delta_vs_frozen_overall"] = max(all_frz)
summary["quantiles_vs_frozen"] = {q: float(np.percentile(all_frz, q)) for q in (50, 90, 95, 99, 100)}
summary["run_to_run"] = {"max": max(all_r2r), "quantiles": {q: float(np.percentile(all_r2r, q)) for q in (50, 90, 100)}}
summary["gate_1e-5_all_repeats_vs_frozen"] = bool(max(all_frz) <= 1e-5)
summary["failed_case_seeds_vs_frozen"] = [f"{c}/seed{s}" for c in CASES for s in SEEDS
                                          if summary["cases"][c][str(s)]["max_delta_vs_frozen"] > 1e-5]
summary["historical_failure_preserved_note"] = "historical N_OLD600 max 1.52587890625e-05 remains FAILED; this replay neither erases nor re-passes it; reruns counted fixed at K=5 per case-seed, no pass-seeking"
summary["forward_calls"] = counts["forward_calls"]
json.dump(summary, open(OUT + "/stageA/STAGE_A_SUMMARY.json.tmp", "w"), indent=1)
os.replace(OUT + "/stageA/STAGE_A_SUMMARY.json.tmp", OUT + "/stageA/STAGE_A_SUMMARY.json")
log("STAGE_A_DONE", "max_vs_frozen", summary["max_delta_vs_frozen_overall"],
    "run2run_max", summary["run_to_run"]["max"])
print("STAGE_A_DONE", flush=True)
