#!/usr/bin/env python3
"""GPU C: two EnzGFM arms on the fixed 31 registry NC6 steps, 5 seeds, four
conditions: A (production whole-step normal), A_repeat (same config second
time), REVERSE (whole candidate order reversed, restored by frozen position
before comparison), SPLIT (halves forwarded separately and re-concatenated;
counterfactual diagnostic, NOT a production batching permission). Full
per-seed vectors saved in reducer schema; split sub-batch actual sizes/padding
disclosed. Protocol semantics and feature-chain resolution mirror the
read-only historical nc6_batch_sensitivity evidence (production whole-step,
E0 lane + R1 chains). No 1.5x envelope adoption, no threshold changes."""
import csv, hashlib, json, os, pickle, sys, time
from pathlib import Path
import numpy as np

OUT = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
BASE = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
PKG = BASE + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, OUT + "/worker")
import gpu_lock
sys.path.insert(0, PKG + "/sources")
import r3_paths as P
sys.path.insert(0, BASE + "/scripts_node")
sys.path.insert(0, P.S8CODE)
import pandas as pd
import torch
import enzymecage.dataset.geometric as geom
import torch_geometric.data as pyg_data
from torch_geometric.loader import DataLoader
from enzymecage.model import EnzymeCAGE
import enzgfm_chains as EC

t0 = time.time()
log = lambda *a: print(f"[{time.time()-t0:7.1f}s]", *a, flush=True)
DEV = torch.device("cuda:0")
FOLLOW = ["protein", "reaction_feature", "esm_feature", "substrates", "products"]
DIM = 2048
SEEDS = [40, 41, 42, 43, 44]
REG = json.load(open(OUT + "/input/CONTROL_REQUESTS.json"))
PLAN = json.load(open(OUT + "/CONTROL_EXECUTION_PLAN.json"))
NC6 = PLAN["stageC_nc6_steps"]
ARMS = ("current_e0_enzgfm650m", "new_enzgfm650m")
PLM = {"current_e0_enzgfm650m": "EnzGFM-650M", "new_enzgfm650m": "enzgfm650m"}
CKPT = {arm: {int(s): (v["path"], v["sha256"]) for s, v in REG["models"][arm].items()} for arm in ARMS}

fd = gpu_lock.acquire("stageC")
VC = OUT + "/stageC/vectors"; VS = OUT + "/stageC/split_shapes"
os.makedirs(VC, exist_ok=True); os.makedirs(VS, exist_ok=True)
os.environ.setdefault("ENZYMECAGE_SHARD_CACHE_SIZE", "all")
from enzymecage.dataset.sharded_protein import _load_sharded_mapping, load_protein_gvp_data
chains = EC.R1Chains(_load_sharded_mapping, load_protein_gvp_data)
e0_views, e0_seq, e0_sha, e0_closure = EC.build_e0_lane()
log("chains + E0 lane ready")

def resolve(arm, uid, sh, seq):
    if arm == "current_e0_enzgfm650m":
        seq_a = e0_seq.get(uid)
        if seq_a is not None and e0_sha.get(uid) == sh and seq_a == seq:
            e0g, e0p, e0gv = e0_views["global"], e0_views["pocket"], e0_views["gvp"]
            if uid in e0gv and uid in e0p and seq_a in e0g:
                pk = np.asarray(e0p[uid], dtype=np.float32); gv = e0gv[uid]; gl = np.asarray(e0g[seq_a], dtype=np.float32)
                if 0 < int(np.asarray(gv[0]).shape[0]) == int(pk.shape[0]) <= len(seq):
                    return (uid, pk, gv, gl)
    aun = uid
    pk, _ = chains.pocket_get(aun); gv, _ = chains.gvp_get(aun)
    if pk is None or gv is None:
        ru = chains.route_uid(uid, sh)
        if ru:
            pk2, _2 = chains.pocket_get(ru); gv2, _3 = chains.gvp_get(ru)
            if pk2 is not None and gv2 is not None: aun, pk, gv = ru, pk2, gv2
    gl, _4, _5 = chains.global_get(seq)
    if pk is None or gv is None or gl is None: return None
    return (aun, pk, gv, gl)

RXN = {}
def bind(ctx):
    if ctx not in RXN:
        rx = P.RXN[ctx]
        fp = pickle.load(open(rx + "/rxn2fp_merged.pkl", "rb"))
        ce = pickle.load(open(rx + "/reacting_center_merged.pkl", "rb"))
        mtab = pd.read_csv(rx + "/mol_conformation/mol2id.csv")
        mg = torch.load(rx + "/mol_conformation/mol_graph_dict.pt", map_location="cpu", weights_only=False)
        RXN[ctx] = (fp, ce, dict(zip(mtab.SMILES.astype(str), mtab.ID)), mg)
    return RXN[ctx]

def build_ds(ctx, rxn, seqs, res):
    fp, ce, m2i, mg = bind(ctx)
    uids = [r[0] for r in res]
    fr = pd.DataFrame({"UniprotID": uids, "CANO_RXN_SMILES": [rxn] * len(uids),
                       "sequence": list(seqs), "Label": [0] * len(uids)})
    ds = geom.GeometricDataset.__new__(geom.GeometricDataset); pyg_data.Dataset.__init__(ds)
    ds.df_data = fr; ds.pocket_node_feature = {u: r[1] for u, r in zip(uids, res)}; ds.esm_dim = DIM
    ds.protein_dict = {u: r[2] for u, r in zip(uids, res)}
    ds.esm_feat_dict = {sq: r[3] for sq, r in zip(seqs, res)}
    ds.rxn_feat_dict = fp; ds.uniprot_ids = uids; ds.rxns = [rxn] * len(uids)
    ds.targets = [0] * len(uids); ds.seqs = list(seqs); ds.weights = torch.ones(len(uids))
    ds.mol_to_index = m2i; ds.mol_to_data = mg; ds.reacting_center_map = ce
    return ds

def fwd(m, ds):
    b = next(iter(DataLoader(ds, batch_size=len(ds.uniprot_ids), shuffle=False, follow_batch=FOLLOW))).to(DEV)
    with torch.no_grad():
        o = m.forward(b)
    if isinstance(o, tuple): o = o[0]
    v = o.detach().cpu().to(torch.float64).numpy().reshape(-1)
    assert np.isfinite(v).all()
    return v

def make_model(arm, seed):
    p, want = CKPT[arm][seed]
    assert hashlib.sha256(open(p, "rb").read()).hexdigest() == want
    torch.manual_seed(seed)
    m = EnzymeCAGE(use_esm=True, use_structure=True, use_drfp=True, use_prods_info=False,
                   plm_model=PLM[arm], plm_dim=DIM, interaction_method="geo-enhanced-interaction",
                   rxn_inner_interaction=True, pocket_inner_interaction=True, device=str(DEV)).to(DEV)
    ck = torch.load(p, map_location="cpu", weights_only=False)
    m.load_state_dict(ck["model_state_dict"], strict=True)
    return m.eval()

POOL = P.NEWROOT + "/runtime/pool"
steps_by = {ctx: {s["step_id"]: s for s in json.load(open(f"{POOL}/UNIFIED_STEP_TABLE_{ctx}.json"))}
            for ctx in ("main", "delta15")}
coverage = {"steps": len(NC6), "arms": list(ARMS), "forward_calls": 0, "typed_miss": [], "typed_fail": [],
            "completed": 0}
for arm in ARMS:
    for seed in SEEDS:
        m = make_model(arm, seed)
        assert getattr(m, "sigmoid_readout", None) is False
        for t in NC6:
            ctx, sid = t["ctx"], t["step_id"]
            fp = f"{VC}/{arm}_{ctx}_{sid}.json"
            if os.path.exists(fp):
                d0 = json.load(open(fp))
                if all(set(d0["conditions"][c]) == {str(x) for x in SEEDS} for c in ("A", "A_repeat", "REVERSE", "SPLIT")):
                    continue
            s = steps_by[ctx][sid]
            res = [resolve(arm, u, sh, sq) for u, sh, sq in zip(s["pool_uids"], s["pool_shas"], s["pool_seqs"])]
            if any(r is None for r in res):
                coverage["typed_miss"].append({"arm": arm, "seed": seed, "ctx": ctx, "step_id": sid, "reason": "RESOLVE_MISS"}); continue
            rxn = s["model_reaction"]
            try:
                L = fwd(m, build_ds(ctx, rxn, s["pool_seqs"], res)); coverage["forward_calls"] += 1
                L2 = fwd(m, build_ds(ctx, rxn, s["pool_seqs"], res)); coverage["forward_calls"] += 1
                n = len(L)
                Lr = fwd(m, build_ds(ctx, rxn, list(reversed(s["pool_seqs"])), list(reversed(res))))
                Lr_restored = [float(Lr[n - 1 - i]) for i in range(n)]; coverage["forward_calls"] += 1
                half = n // 2
                la = fwd(m, build_ds(ctx, rxn, s["pool_seqs"][:half], res[:half]))
                lb = fwd(m, build_ds(ctx, rxn, s["pool_seqs"][half:], res[half:])); coverage["forward_calls"] += 2
                Lsp = np.concatenate([la, lb])
                json.dump({"arm": arm, "seed": seed, "ctx": ctx, "step_id": sid,
                           "n_rows": n, "split_half1": half, "split_half2": n - half,
                           "note": "SPLIT sub-batches use their own natural whole-sub-batch padding; disclosure only, never a production batching permission"},
                          open(f"{VS}/{arm}_{ctx}_{sid}_seed{seed}.json", "w"), indent=1)
                idm = hashlib.sha256(json.dumps({"arm": arm, "ctx": ctx, "sid": sid, "n": n}, sort_keys=True).encode()).hexdigest()
                rec = {"arm": arm, "ctx": ctx, "step_id": sid,
                       "model_reaction": rxn, "model_key_sha256": s["model_key_sha256"],
                       "pool_uids": s["pool_uids"], "pool_shas": s["pool_shas"], "gold_flags": s["gold_flags"],
                       "seeds": [str(x) for x in SEEDS],
                       "checkpoint_shas": {str(x): CKPT[arm][x][1] for x in SEEDS},
                       "baseline_condition": "A",
                       "conditions": {"A": {}, "A_repeat": {}, "REVERSE": {}, "SPLIT": {}},
                       "condition_metadata": {
                           "A": {"protocol": "WHOLE_STEP_PURE_BATCH production normal r0", "input_identity_sha256": idm, "candidate_identity": "same_original_order"},
                           "A_repeat": {"protocol": "WHOLE_STEP_PURE_BATCH production normal r1 same config", "input_identity_sha256": idm, "candidate_identity": "same_original_order"},
                           "REVERSE": {"protocol": "WHOLE_STEP counterfactual reversed candidate order restored by frozen position before comparison", "input_identity_sha256": idm, "candidate_identity": "explicit_permutation_restored"},
                           "SPLIT": {"protocol": "counterfactual diagnostic: two sub-batches (halves) re-concatenated; NOT a production batching permission", "input_identity_sha256": idm, "candidate_identity": "same_original_order_after_split"}}}
                if os.path.exists(fp):
                    rec = json.load(open(fp))
                rec["conditions"]["A"][str(seed)] = [float(x) for x in L]
                rec["conditions"]["A_repeat"][str(seed)] = [float(x) for x in L2]
                rec["conditions"]["REVERSE"][str(seed)] = Lr_restored
                rec["conditions"]["SPLIT"][str(seed)] = [float(x) for x in Lsp]
                json.dump(rec, open(fp + ".tmp", "w"), indent=1); os.replace(fp + ".tmp", fp)
            except (RuntimeError, AssertionError) as exc:
                coverage["typed_fail"].append({"arm": arm, "seed": seed, "ctx": ctx, "step_id": sid,
                                               "error": type(exc).__name__ + ": " + str(exc)[:200]})
                log("TYPED FAIL", arm, seed, sid, exc)
        del m; torch.cuda.empty_cache()
        log(f"{arm} seed{seed} done; forwards {coverage['forward_calls']}")
        json.dump(coverage, open(OUT + "/stageC/COVERAGE.json", "w"), indent=1)
coverage["completed"] = len([f for f in os.listdir(VC) if f.endswith(".json")])
log("STAGE_C_DONE", json.dumps({k: v for k, v in coverage.items() if k in ("forward_calls", "completed", "typed_miss", "typed_fail")}))
print("STAGE_C_DONE", flush=True)
