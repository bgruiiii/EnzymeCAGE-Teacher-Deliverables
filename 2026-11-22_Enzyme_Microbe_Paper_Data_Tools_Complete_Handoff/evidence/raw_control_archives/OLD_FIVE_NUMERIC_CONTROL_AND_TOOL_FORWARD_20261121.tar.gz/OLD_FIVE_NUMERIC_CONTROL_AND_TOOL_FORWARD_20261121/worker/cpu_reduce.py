#!/usr/bin/env python3
"""CPU reduction pass: run the package reducer (mean(sigmoid), frozen tie rule
on scientific UID SHA) over every saved control-vector set, then gate
accounting with the ORIGINAL thresholds only:
- stage A: absolute 1e-5 vs frozen (logit level, all repeats).
- stage B: original 0.05 absolute substituted-row logit delta gate on the
  mean(sigmoid) probability level AND the original logit-delta semantics,
  reported separately; rank/topk/gold/MRR deltas from the official formula.
- stage C: production repeat stability first, then reverse/split disclosure.
No envelope->gate conversions, no threshold changes, no pass-seeking.
"""
import json, math, os, subprocess, sys, glob
import numpy as np

OUT = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
PY = "/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python"
RES = OUT + "/reduced"; os.makedirs(RES, exist_ok=True)
REPORT = {}

def run_reducer(indir, tag):
    files = glob.glob(indir + "/*.json")
    if not files:
        return {"error": "NO_INPUT_FILES", "dir": indir}
    r = subprocess.run([PY, OUT + "/input/reduce_paired_logits.py", "--input-dir", indir,
                        "--out-dir", f"{RES}/{tag}"], capture_output=True, text=True)
    return {"rc": r.returncode, "stdout": r.stdout.strip(), "stderr": r.stderr.strip()[:2000], "n_files": len(files)}

REPORT["stageA_reducer"] = run_reducer(OUT + "/stageA/vectors", "stageA")
REPORT["stageB_reducer_bounded16"] = run_reducer(OUT + "/stageB/vectors", "stageB_bounded16")
REPORT["stageB_reducer_wholestep_layer"] = run_reducer(OUT + "/stageB/vectors_wholestep", "stageB_wholestep")
REPORT["stageC_reducer"] = run_reducer(OUT + "/stageC/vectors", "stageC")

sigmoid = lambda x: 1.0/(1.0+math.exp(-x)) if x >= 0 else math.exp(x)/(1.0+math.exp(x))

def reduce_record_gate(rec_path, pair_names, tag):
    r = json.load(open(rec_path))
    from hashlib import sha256
    n = len(r["pool_uids"])
    def probs(cond):
        return [sum(sigmoid(v) for v in [r["conditions"][cond][s][i] for s in ["40","41","42","43","44"]])/5 for i in range(n)]
    def rank_by(p):
        order = sorted(range(n), key=lambda i: (-p[i], sha256(r["pool_uids"][i].encode()).hexdigest()))
        pos = [0]*n
        for rk, i in enumerate(order): pos[i] = rk+1
        return pos, order
    out = {"step": os.path.basename(rec_path), "tag": tag, "pairs": {}}
    for p in pair_names:
        a, b = p
        pb, ob = rank_by(probs(a)); ps, os_ = rank_by(probs(b))
        gold = [i for i, g in enumerate(r["gold_flags"]) if g]
        best_b = min(pb[i] for i in gold) if gold else None
        best_s = min(ps[i] for i in gold) if gold else None
        # logit-level max delta per seed over ALL candidates and over substituted-only where mask known
        allmax = max(abs(float(r["conditions"][a][s][i]) - float(r["conditions"][b][s][i]))
                     for s in ["40","41","42","43","44"] for i in range(n))
        pmax = max(abs(pb[i]-ps[i]) for i in range(n))
        out["pairs"][a+"__vs__"+b] = {
            "max_abs_logit_delta_all_candidates_per_seed": allmax,
            "max_abs_probability_delta_mean_sigmoid": pmax,
            "changed_candidate_ranks": sum(pb[i] != ps[i] for i in range(n)),
            "gold_rank_base": best_b, "gold_rank_variant": best_s,
            "mrr_base": None if best_b is None else 1.0/best_b,
            "mrr_variant": None if best_s is None else 1.0/best_s,
            "top1_agree": ob[0] == os_[0],
            "topk_hits_base": [None if best_b is None else int(best_b <= k) for k in (1,3,5,10)],
            "topk_hits_variant": [None if best_s is None else int(best_s <= k) for k in (1,3,5,10)]}
    return out

# ---- stage B gate accounting (0.05 original gate, substituted-row logit semantics
# reproduced at logit level exactly as original NC2, plus probability-level disclosure)
def stage_b_gate():
    res = {"gate_original_0.05_substituted_logit_delta": {}, "probability_official_ensemble": {},
           "n_records": 0, "coverage": {}}
    subs_fail = 0; probs_fail = 0; worst_sub = 0.0; worst_prob = 0.0
    for fp in sorted(glob.glob(OUT + "/stageB/vectors/*.json")):
        r = json.load(open(fp))
        inp = OUT + "/stageB/inputs/" + os.path.basename(fp)
        mask = None
        if os.path.exists(inp):
            body = json.load(open(inp))
            sub_i = set(x[0] for x in body["manifest_B"].get("substituted", []))
            mask = [i in sub_i for i in range(len(r["pool_uids"]))]
        n = len(r["pool_uids"])
        # logit-level delta on substituted rows only (original NC2 semantics)
        dl = []
        for s in ["40","41","42","43","44"]:
            for i in range(n):
                if mask is None or mask[i]:
                    dl.append(abs(r["conditions"]["A"][s][i] - r["conditions"]["B"][s][i]))
        mx = max(dl)
        worst_sub = max(worst_sub, mx)
        if mx > 0.05: subs_fail += 1
        res["n_records"] += 1
    res["gate_original_0.05_substituted_logit_delta"] = {
        "steps": res["n_records"], "steps_over_gate": subs_fail, "worst_substituted_row_logit_max": worst_sub,
        "note": "original 0.05 gate applied on substituted-row per-seed ABS logit delta (exact original NC2 semantics); pass/fail per step disclosed, not averaged with probability level"}
    # probability level from reducer output
    for fp in sorted(glob.glob(RES + "/stageB_bounded16/*.json")):
        if fp.endswith("REDUCTION_MANIFEST.json"): continue
        rr = json.load(open(fp))
        key = [k for k in rr["pairs"] if "B" in k][0]
        pm = rr["pairs"][key]["max_abs_probability_delta"]
        worst_prob = max(worst_prob, pm)
        if pm > 0.05: probs_fail += 1
    res["probability_official_ensemble"] = {"worst_mean_sigmoid_prob_delta": worst_prob,
                                            "steps_over_0.05_at_probability_level": probs_fail,
                                            "note": "mean(sigmoid(logit_seed)) official formula; probability delta compared separately from the original logit gate; not substituted for it"}
    return res

REPORT["stageB_gate"] = stage_b_gate()

# ---- stage C: repeat stability first, then reverse/split ----
def stage_c_stats():
    out = {}
    for fp in sorted(glob.glob(RES + "/stageC/*.json")):
        if fp.endswith("REDUCTION_MANIFEST.json"): continue
        rr = json.load(open(fp))
        base = os.path.basename(fp)
        keyr = "A__vs__A_repeat"; keyv = "A__vs__REVERSE"; keys = "A__vs__SPLIT"
        d = out.setdefault(base, {})
        for k in (keyr, keyv, keys):
            if k in rr["pairs"]:
                p = rr["pairs"][k]
                d[k] = {"max_abs_logit_delta": p["max_abs_logit_delta"],
                        "max_abs_probability_delta": p["max_abs_probability_delta"],
                        "changed_candidate_ranks": p["changed_candidate_ranks"],
                        "top1_agree": p["top1_agree"]}
        for c in rr["conditions"]:
            d.setdefault(c, {})["best_gold_rank"] = rr["conditions"][c]["best_gold_rank"]
        d["_arm"] = rr["arm"]
    agg = {}
    for base, d in out.items():
        arm = d.pop("_arm")
        for k, v in d.items():
            if "__vs__" in k:
                g = agg.setdefault(arm, {}).setdefault(k, {"max_logit": 0.0, "max_prob": 0.0, "n_rank_changed": 0,
                                                           "steps": 0, "top1_disagree": 0})
                g["max_logit"] = max(g["max_logit"], v["max_abs_logit_delta"])
                g["max_prob"] = max(g["max_prob"], v["max_abs_probability_delta"])
                g["n_rank_changed"] += v["changed_candidate_ranks"]
                g["steps"] += 1
                g["top1_disagree"] += int(not v["top1_agree"])
    return {"per_arm_summary": agg, "n_step_files": len(out),
            "note": "repeat stability (production same protocol) reported FIRST; reverse/split are counterfactual disclosures; the historical measured envelopes (E0 1.664, S10 5.335 logit max; NC6b 9.54e-6 single-sample E0 reverse) are NOT restated as original gates"}

REPORT["stageC_stats"] = stage_c_stats()

# ---- stage A gate at logit level from the vector records ----
def stage_a_gate():
    worst = 0.0; fail = []
    import hashlib
    for fp in sorted(glob.glob(OUT + "/stageA/vectors/*.json")):
        r = json.load(open(fp))
        for s in ["40","41","42","43","44"]:
            ref = r["conditions"]["REF_FROZEN"][s]
            for c in ["A", "A_repeat1", "A_repeat2", "A_repeat3", "A_repeat4"]:
                mx = max(abs(a-b) for a, b in zip(r["conditions"][c][s], ref))
                worst = max(worst, mx)
                if mx > 1e-5: fail.append(f"{r['step_id']}/{s}/{c}")
    return {"worst_repeat_vs_frozen": worst, "n_gt_1e-5": len(fail), "failures": fail,
            "gate": 1e-5, "historical_failure_retained": "N_OLD600 historical 1.52587890625e-05 remains on record as FAILED; this card's replay on THIS hardware is disclosed separately"}

REPORT["stageA_gate"] = stage_a_gate()

# coverage table
cov = {}
try: cov["stageB"] = json.load(open(OUT + "/stageB/COVERAGE.json"))
except Exception: pass
try: cov["stageC"] = json.load(open(OUT + "/stageC/COVERAGE.json"))
except Exception: pass
try: cov["stageA_forward_calls"] = json.load(open(OUT + "/stageA/STAGE_A_SUMMARY.json"))["forward_calls"]
except Exception: pass
REPORT["coverage"] = cov

json.dump(REPORT, open(OUT + "/CPU_REDUCTION_GATE_REPORT.json", "w"), indent=1)
print("CPU_REDUCTION_DONE")
print(json.dumps({k: REPORT[k] for k in ("stageA_gate", "stageB_gate", "stageC_stats")}, indent=1)[:4000])
