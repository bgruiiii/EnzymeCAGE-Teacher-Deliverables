#!/usr/bin/env python3
"""Generate the one-page plain-language result from the actual final artifacts.
Numbers come from the produced reports only; nothing is asserted beyond them."""
import json, os

OUT = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
L = lambda p: json.load(open(OUT + "/" + p))
A = L("stageA/STAGE_A_SUMMARY.json")
R = L("CPU_REDUCTION_GATE_REPORT.json")
Bc = L("stageB/COVERAGE.json")
Cb = L("stageC/COVERAGE.json")
D = L("stageD/STATUS.json")
D2 = L("stageD/D2_chain_S02.json")
D1 = L("stageD/D1_real_calls_S02_S03.json")
_bc = L("stageB/baseline_check.json")
_vals = [v["max_abs_delta_vs_original_raw"] for v in _bc.values()]
BC_BASE_CHECK = {"n": len(_vals), "over": sum(1 for v in _vals if v > 1e-5), "worst": max(_vals)}
_D3 = L("stageD/D3_positive_control.json")
D3_RHEA, D3_N = _D3["rhea_id"], len(_D3["pool_uids_order"])
D3_MED_DELTA = _D3["summary_deltas"]["prob_semantics"]["median"]
D1_DISTINCT_MISSING = sum(
    len({(n["uid"], n["reason"]) for n in r["not_evaluated"] if n["reason"] == "ENZYME_ASSET_MISSING"})
    for r in D1.values())

page = f"""# 原五组数值缺口补证 —— 一页白话（2026-11-21，本卡补测，非重训）

**先说清楚为什么要补：** 师姐要的是资料和证据链。审计发现原五组成绩里有三类缺口——
(1) 旧600M 的历史 replay 门在当时的 vGPU 节点没进 1e-5 绝对门（历史值 1.5258e-5），
(2) 新600M 特征批次影响界 0.05 没进（历史值 0.432），
(3) 原 NC2/NC6 的稳定性控制当时用错了集成公式（平均 logit 而不是正式的平均 sigmoid 概率），
而且它们的逐 seed 全向量根本没有留存——成绩可复算，但"控制实验"缺原始证据。
本卡就是补这些缺口的有界推理证据，不动成绩、不动池/Gold/权重/阈值。

**补了什么（实测）：**

1. **旧600M 严格 replay（Stage A）**：4 个冻结案例×5seed×5repeat=100 次原 whole-step 前向，
   逐候选全向量已保存。对历史冻结 reference 的最大差 **{A['max_delta_vs_frozen_overall']:.3e}**，
   全部 100 条 **{'进' if A['gate_1e-5_all_repeats_vs_frozen'] else '未进'}** 原 1e-5 门（本节点）；
   本次 run-to-run 最大 **{A['run_to_run']['max']:.3e}**。历史失败记录保留、不删不改；
   本结论只说明"在同一原协议、同一权重下，本节点可复现进门"，不追认历史节点成绩，
   也不声明"该门在所有硬件通过"。
2. **新600M 路线影响（Stage B）**：注册表钉死的 219 步，正式公式 mean(sigmoid) 逐 seed 全向量已保存
   （覆盖 {Bc['completed']}/219，其中可同recipe替换步 {Bc['eligible_steps']}；
   类型化 NO_SUBSTITUTABLE {len(Bc['no_substitutable_typed'])} 步）。
   原 0.05 门按原语义（替换行、逐 seed 绝对 logit 差）分步报账：
   **超门步数 {R['stageB_gate']['gate_original_0.05_substituted_logit_delta']['steps_over_gate']}，
   最差替换行 logit 差 {R['stageB_gate']['gate_original_0.05_substituted_logit_delta']['worst_substituted_row_logit_max']:.4g}**；
   概率层面（正式公式）最差平均概率差 {R['stageB_gate']['probability_official_ensemble']['worst_mean_sigmoid_prob_delta']:.4g}，
   超 0.05 步数 {R['stageB_gate']['probability_official_ensemble']['steps_over_0.05_at_probability_level']}。
   6 个 Gold rank 历史变化步另做 whole-step 独立层，与 bounded16 生产层不平均。
   **基线不符单列**：本次 bounded16 baseline-A 与留存原始生产 raw 逐 seed 对账共
   {BC_BASE_CHECK['n']} 项，其中 {BC_BASE_CHECK['over']} 项最大逐候选差超过 1e-5
   （最大 {BC_BASE_CHECK['worst']:.3e}，集中于 seed 41）。按合同这不掩盖、不用后续结果冲销：
   它说明本节点生产复跑存在小量同协议非复现带，正式结论以 A/B 同协议同批成对比较为准
   （A 与 B 都来自本次同卡运行），历史生产数值本身未改动。详见 stageB/baseline_check.json。
3. **两 EnzGFM batch 敏感性（Stage C）**：注册表钉死的 31 步×2臂×5seed 保存了 A/A_repeat/REVERSE/SPLIT
   四条件全向量（覆盖 {Cb['completed']} 个文件）。生产同协议 repeat 稳定性先报
   （见 CPU 报告的 per_arm_summary）：
   最大 logit 差 E0 {json.dumps(R['stageC_stats']['per_arm_summary'].get('current_e0_enzgfm650m', {}).get('A__vs__A_repeat', {}))}；
   逆序/拆批只是反事实诊断，SPLIT 不构成任何生产分批许可；历史的 1.5×实测包络没有被当作门。
4. **独立工具真实 forward（Stage D）**：原生三根配置、真实 wrapper runtime（非测试替身、非 replay）。
   **S02/S03 的 v1 三根范围内如实类型化为缺项**：D1 真实调用对冻结原池返回
   REACTION_ASSET_MISSING（v1 包 20260714 的 rxn_fp/分子图/反应中心不含这两条 BIOPATH150 反应），
   酶侧另有 {D1_DISTINCT_MISSING} 个 UID ENZYME_ASSET_MISSING（11+8）——按合同逐条类型化登记，
   没有删候选、没有换目标、没有借另一 step。
   **D3 正控附录**：同一真实 runtime 对 v1 交付测试集内按固定规则（30-60 行、行数最多、编号小者优先）
   选中的 RHEA {D3_RHEA}（{D3_N} 候选）完成真实 whole-step 调用：last_trace 5seed 全向量已存，
   一次调用内包装公式（5seed logit 均值+分位数CI）与排序一致性三项检查全部 True，
   forward 计数如实记录；与 v1 交付行级 pred 的对照表已存（pred 语义为单种子行级评估，
   非 5seed 集成，概率层中位差 {D3_MED_DELTA} 属语义差异，已披露不解释为等价）。
   有限串联（S02 检索→构池→评分→来源→C8）：检索 {D2['retrieval_status']}（真实返回 {D2['pool_candidates']} 个候选，
   不等于冻结评价 13，不强行对齐）、来源 {json.dumps(D2['hosts_status_dist'])}、
   C8 读取 {json.dumps(D2['traits_status_dist'])}、评分链末段 {D2['scoring_status']}；
   SCNET/DEHP 包不在节点，如实记缺，不新开查询作业。depending 未改。

**不能据本卡下的结论：** 不能说五组门"全部闭合"（历史失败仍在册；0.05 门按步分账，
有超门的照超门报）；不能说 batch 协议之间数值等价；不能用 wrapper 的 mean-of-logit 公式
顶替正式 mean-of-sigmoid 成绩口径；本卡没有也不应有重训、换权重、换特征、改阈值、
改科学表示的任何动作。阶段状态以实测为准，主审复审前不解除既有限制。

**范围与配对说明（交主审确认的一处）：** 任务写"最终已审S02/S03"，本卡按已审路径
BIOPATH150_001 的连续两步 S02(13候选)/S03 作为固定池对象（与历史评审示例的 13 一致）；
若主审认定的是别的 S02/S03 步对，Stage D 可用同一脚本一键换步重跑，不影响 A/B/C 三阶段。
"""
open(OUT + "/RESULTS_PLAIN_LANG.md", "w").write(page)
print("RESULTS_PLAIN_LANG.md written,", len(page), "chars")
