#!/usr/bin/env python3
"""CPU source-lock step: reconcile the 232 registry targets against the frozen
step tables (identity + set membership, frozen order authoritative), assemble
the per-arm protocol table from retained COMMON_CONTEXT + registry SHAs, locate
the retained full-vector evidence vs missing control vectors, and emit
CONTROL_EXECUTION_PLAN.json. Read-only over OLD; writes only under OUT."""
import hashlib, json, os, sys
from collections import Counter

WS = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031"
BASE = WS + "/five_model_complete_20261103"
P = BASE + "/current95_five_model_complete_prep_20261103"
OUT = WS + "/old_five_numeric_control_20261121"
IN = OUT + "/input"

sha_file = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()

REG = json.load(open(IN + "/CONTROL_REQUESTS.json"))
GATE = open(IN + "/NUMERIC_GATE_STATUS.tsv").read()
pool = {}
for ctx in ("main", "delta15"):
    steps = json.load(open(f"{BASE}/runtime/pool/UNIFIED_STEP_TABLE_{ctx}.json"))
    pool[ctx] = {s["step_id"]: s for s in steps}

ASSET_COLS = {"legacy_esm2_3b": "asset_uids_3b", "legacy_esmc600m": "asset_uids_legacy",
              "new_esmc600m": "asset_uids_new", "current_e0_enzgfm650m": "asset_uids_e0",
              "new_enzgfm650m": "asset_uids_new_enzgfm"}

recon = {"targets": 0, "step_found": 0, "set_match": 0,
         "order_semantics": "membership is a set certificate; scoring order = frozen pool_uids/pool_shas/pool_seqs order in UNIFIED_STEP_TABLE",
         "failures": [], "asset_uid_observations": []}
nc2_steps, nc6_steps = [], []
for t in REG["targets"]:
    recon["targets"] += 1
    key = (t["ctx"], t["step_id"])
    s = pool[t["ctx"]].get(t["step_id"])
    if s is None:
        recon["failures"].append({"step_id": t["step_id"], "ctx": t["ctx"], "reason": "STEP_NOT_IN_FROZEN_TABLE"}); continue
    recon["step_found"] += 1
    # reaction and key identity
    if s["model_reaction"] != t["model_reaction"] or s["model_key_sha256"] != t["model_key_sha256"]:
        recon["failures"].append({"step_id": t["step_id"], "ctx": t["ctx"], "reason": "REACTION_OR_KEY_MISMATCH"}); continue
    reg_pairs = sorted((m["uid"], m["sha256"]) for m in t["membership"])
    table_pairs = sorted(zip(s["pool_uids"], s["pool_shas"]))
    aset_pairs = {arm: sorted(zip(s[col], s["pool_shas"])) for arm, col in ASSET_COLS.items()}
    if reg_pairs == table_pairs or any(reg_pairs == v for v in aset_pairs.values()):
        recon["set_match"] += 1
        which = "pool_uids" if reg_pairs == table_pairs else [a for a, v in aset_pairs.items() if reg_pairs == v][0]
        if which != "pool_uids":
            recon["asset_uid_observations"].append({"step_id": t["step_id"], "matched_column": which})
    else:
        # allow per-arm asset uid mapping: compare uid-sha as multiset ignoring uid identity drift? NO - typed fail, disclose.
        recon["failures"].append({"step_id": t["step_id"], "ctx": t["ctx"], "reason": "MEMBERSHIP_SET_MISMATCH",
                                  "n_reg": len(reg_pairs), "n_table": len(table_pairs)})
        continue
    if t.get("NC2_route_control"):
        nc2_steps.append({"ctx": t["ctx"], "step_id": t["step_id"], "n": t["candidate_count"]})
    if t.get("NC6_batch_control"):
        nc6_steps.append({"ctx": t["ctx"], "step_id": t["step_id"], "n": t["candidate_count"]})
recon["nc2"] = {"count": len(nc2_steps), "by_ctx": dict(Counter(x["ctx"] for x in nc2_steps))}
recon["nc6"] = {"count": len(nc6_steps), "by_ctx": dict(Counter(x["ctx"] for x in nc6_steps))}

# ---- protocol table from retained COMMON_CONTEXT (read-only) ----
proto = {}
for arm in ASSET_COLS:
    for ctx in ("main", "delta15"):
        d = f"{BASE}/gf_out/{arm}/{ctx}"
        f = d + "/COMMON_CONTEXT.json"
        if os.path.exists(f):
            cc = json.load(open(f))
            proto[f"{arm}/{ctx}"] = {
                "common_context_sha256": sha_file(f),
                "batch_contract": cc.get("batch_contract"),
                "output_contract": cc.get("output_contract"),
                "stack_root": (cc.get("sources") or {}).get("stack_root"),
                "weights_locked_ckpt_shas": (cc.get("weights") or {}).get("locked_ckpt_shas"),
            }

# ---- gold-shift step list from original whole-step NC2 (independent layer) ----
goldshift = json.load(open(BASE + "/runtime/pc_perstep/NC2B_GOLD_SHIFT_DETAIL.json"))["targets"]

# ---- vector inventory: retained vs missing ----
def count_raw(arm, ctx):
    d = f"{BASE}/gf_out/{arm}/{ctx}/raw_logits_{arm}"
    return len([f for f in os.listdir(d) if f.endswith(".json")]) if os.path.isdir(d) else 0
inv = {
    "A_production_per_seed_full_vectors": {f"{arm}/{ctx}": count_raw(arm, ctx)
        for arm in ASSET_COLS for ctx in ("main", "delta15")},
    "legacy_reference_vectors": {
        "dir": "/usrdata/EnzymeCAGE_data/training_runs/enzymecage_v6_298_rhea142_brenda_enzgfm650m_retrain_20260922/s11_r1_self_included_four_model_20260927/inputs/legacy/pollutant291_p2rank_legacy600m_model_matched_dual5seed_rerun_20260922/results/raw_logits_600m",
        "frozen_cases_present": [c + ".json" for c in REG["legacy_frozen_cases"]],
        "case_shas": {"poll298-0071fb3b965d": "e422df3ba38b87a3634e87eba80fad96483cf2119fb3a3284d838a32cf208b32",
                      "poll298-0d9dfc1ae6df": "601573bbb9e3e32d3ece82fd23c723c79872c2806a1bfc965bc36aa54ab81994",
                      "poll298-1ffa150889a1": "1c413c7599036a2b202a808cae8e7ea98921757d39e91049fcda7de940895de5",
                      "poll298-380cb0329f8c": "76549ec9f6c6e38e0b317aabb35c1018e8c88130766e15736e3b1a63714716c4"},
        "retains": "full per-seed raw_logits vectors per candidate (schema verified)",
    },
    "B_substituted_vectors_NC2": "MISSING - original nc2_perstep retained statistics only (NC2_PERSTEP_ROWS.tsv); requires new forward",
    "NC6_vectors": "MISSING - original NC6_ROWS.tsv statistics only; requires new forward",
    "chunk_payload_identification": {
        "enzgfm_extraction_chunks": "enzgfm650m_extraction_shard_v1 PLM FEATURE chunks (hidden 2048), NOT paired logits",
        "pc_enzgfm_extract_pc_chunk": "same feature-extraction format",
        "CHUNK0_TODAY_VALUES.pkl": "256-row today-batch global/pocket INPUT cache (phase2 material), not logits",
    },
}

plan = {
    "task": REG["task"],
    "utc": __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ", __import__("time").gmtime()),
    "input_registry_sha256": sha_file(IN + "/CONTROL_REQUESTS.json"),
    "retraining": False,
    "gpu_policy": {"selected": "index 0 NVIDIA GeForce RTX 4090 D GPU-9d62b8ed-5672-c816-5d5c-6cf0186b192c",
                   "rationale": "both GPUs idle 2026-11-21 ~08:4x UTC; single card, sequential stages A->B->C->D in one window; exclusive lock OUT/gpu.lock held by worker across subprocesses",
                   "new3b_conflict": "no GPU compute processes observed at lock time; worker re-checks lock+process list before each stage"},
    "checkpoint_reverify": {"file": "CHECKPOINT_REVERIFY_20261121.json", "total": 25, "sha_ok": "see file; launched 08:4x"},
    "numeric_gates_original": {
        "N_OLD600": {"gate": "max|delta| vs frozen <= 1e-5 every repeat, whole-step", "historical": REG["historical_failures_must_remain"]["legacy_max_abs_delta_vs_frozen"], "status": "HISTORICAL_STRICT_GATE_FAILED"},
        "N_ESMC_ROUTE": {"gate": "substituted logit delta <= 0.05", "historical_max": REG["historical_failures_must_remain"]["esmc_route_observed_max"], "status": "HISTORICAL_ROUTE_EFFECT_GATE_FAILED"},
        "N_NC2_FORMULA": {"official_ensemble": "mean(sigmoid(logit_seed)) over seeds 40-44", "status": "MISSING_CORRECT_FORMULA_CONTROL_VECTORS"},
        "N_NC6_FORMULA": {"protocol": "production whole-step; reverse/split are counterfactual probes only; 1.5x measured envelope is NOT an original gate", "status": "SENSITIVITY_OBSERVED_AND_CORRECT_FORMULA_CONTROL_MISSING"},
        "N_METADATA": {"status": "NOT_RETAINED_SUPERSEDED_IN_PLACE", "note": "documented historical gap; no model experiment can recreate past approval bodies"},
    },
    "protocol_default_per_arm": {"legacy_esmc600m": "original whole-step", "current_e0_enzgfm650m": "original whole-step",
                                 "new_enzgfm650m": "original whole-step", "new_esmc600m": "production bounded16 + FROZEN_WHOLE_STEP_MAXIMA padding (main NC2 control); original whole-step for the 6-step gold-shift independent layer",
                                 "legacy_esm2_3b": "not exercised by this card"},
    "environment": {"python": "/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python", "torch": "2.7.1+cu126",
                    "tf32_deterministic": "original production recorded NO allow_tf32/deterministic/matmul_precision settings; defaults retained; empirical invariance/determinism receipts are the historical control evidence"},
    "reconciliation": recon,
    "stageA_cases": REG["legacy_frozen_cases"],
    "stageB_nc2_steps": nc2_steps,
    "stageC_nc6_steps": nc6_steps,
    "stageB_whole_step_layer_from_NC2B_goldshift": [{"ctx": g["ctx"], "step_id": g["step_id"]} for g in goldshift],
    "stageD": {"tool": "input/standalone_tool (R3 reviewed code)", "targets": "S02/S03 exact model_reaction with original fixed pool",
               "c8_expected_sha256": "d51a540db2f9798d65e25b46f22960ba29ae2d4b288be218c83c299f24f5d5af",
               "b1_uncompressed_sha256": REG["b1_table_uncompressed_sha256"]},
    "vector_inventory": inv,
    "gate_status_raw_copy_sha256": sha_file(IN + "/NUMERIC_GATE_STATUS.tsv"),
    "no_pass_selection": "fixed counts per plan; no rerun-until-pass; failures retained",
}
os.makedirs(OUT, exist_ok=True)
tmp = OUT + "/CONTROL_EXECUTION_PLAN.json.tmp"
json.dump(plan, open(tmp, "w"), indent=1)
os.replace(tmp, OUT + "/CONTROL_EXECUTION_PLAN.json")
print("recon:", recon["targets"], "targets;", recon["set_match"], "set-match;", len(recon["failures"]), "failures")
for f in recon["failures"][:8]:
    print("FAIL", f)
print("NC2 steps:", plan["stageB_nc2_steps"] and len(nc2_steps), "NC6:", len(nc6_steps),
      "goldshift steps:", len(goldshift))
print("asset_uid observations:", len(recon["asset_uid_observations"]),
      dict(Counter(x["matched_column"] for x in recon["asset_uid_observations"])))
