#!/usr/bin/env python3
"""GPU B: new_esmc600m paired-route control on the fixed 219 NC2 steps.
A = the original-consumed store feature view; B = same frame with today-batch
node cache substituted ONLY on rows that have explicit same-recipe store
counterparts (identical membership/index rules as the audited historical
nc2_perstep_impact logic, which is read as evidence and NOT imported/executed).
Main control runs the ACTUAL production bounded16 protocol with frozen
whole-step padding for A and B; baseline A is additionally compared against the
retained original production raw logits and any baseline drift is recorded,
never hidden. An independent whole-step A/B layer reproduces the historical
control only on the 6 NC2B gold-shift steps; the two protocols are never
averaged. Full per-seed vectors are saved in reducer schema. Rescue-only rows
are typed NON_SUBSTITUTABLE. No retraining, no new features, no PLM calls.
Adapted from the read-only evidence script for build_ds/substitution rules;
outputs are written only under OUT."""
import csv, hashlib, json, os, pickle, sys, time
from collections.abc import Mapping
from pathlib import Path
import numpy as np

OUT = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
BASE = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
PKG = BASE + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, OUT + "/worker")
import gpu_lock
sys.path.insert(0, PKG + "/sources")
import r3_paths as P
sys.path.insert(0, PKG + "/scripts")
import r2_lib as L2
import r3_consumer as C3
POOL = P.NEWROOT + "/runtime/pool"
sys.path.insert(0, P.S8CODE)
import pandas as pd
import torch
import enzymecage.dataset.geometric as geom
import torch_geometric.data as pyg_data
from torch_geometric.loader import DataLoader
from enzymecage.model import EnzymeCAGE
import enzymecage.model as _emodel
BUNDLE = P.BUNDLE
sys.path.insert(0, BUNDLE + "/historical/a109")
from c95_bounded_forward import forward_dataset, step_caps

t0 = time.time()
log = lambda *a: print(f"[{time.time()-t0:7.1f}s]", *a, flush=True)
DEV = torch.device("cuda:0")
FOLLOW = ["protein", "reaction_feature", "esm_feature", "substrates", "products"]
DIM = 1152
SEEDS = [40, 41, 42, 43, 44]
REG = json.load(open(OUT + "/input/CONTROL_REQUESTS.json"))
CKPT = {int(s): (v["path"], v["sha256"]) for s, v in REG["models"]["new_esmc600m"].items()}
PLAN = json.load(open(OUT + "/CONTROL_EXECUTION_PLAN.json"))
NC2 = PLAN["stageB_nc2_steps"]
WS_STEPS = PLAN["stageB_whole_step_layer_from_NC2B_goldshift"]

fd = gpu_lock.acquire("stageB")
VB = OUT + "/stageB/vectors"; VW = OUT + "/stageB/vectors_wholestep"; VI = OUT + "/stageB/inputs"
for d in (VB, VW, VI): os.makedirs(d, exist_ok=True)
BC = OUT + "/stageB/baseline_check.json"
baseline_check = json.load(open(BC)) if os.path.exists(BC) else {}

overlays = C3.load_overlays()
core = C3.NewArmIndexV3("main", pd, torch, overlays)
log("chain overlays:", {k: len(v) for k, v in overlays.items() if k != "_manifest"})
CACHE = P.NEWROOT + "/runtime/extraction/cache_nodes"
node_shas = {fn[:-4] for fn in os.listdir(CACHE) if fn.endswith(".npy")}
RECIPES = json.load(open(OUT + "/NODE_RECEIPT_DIGEST.json")) if os.path.exists(OUT + "/NODE_RECEIPT_DIGEST.json") else None
# receipts: seq_sha -> {node_value_sha256, recipe, seqlen} (read-only identity of the cache material)
node_receipts = {}
with open(P.NEWROOT + "/runtime/extraction/NODE_RECEIPTS.jsonl") as f:
    for line in f:
        if line.strip():
            j = json.loads(line)
            node_receipts[j["seq_sha256"]] = j
corr_idx = {}
with open(P.CORR_JSONL) as f:
    for line in f:
        if line.strip():
            j = json.loads(line); corr_idx[j["UniprotID"]] = [int(x) for x in j["corrected_untrimmed_indices"]]
carrier_idx = {}
cdf = pd.read_parquet(P.CARRIER_PARQUET)
for r in cdf.itertuples(index=False):
    carrier_idx.setdefault(str(r.UniprotID), [int(x) for x in str(r.pocket_indices_1based).split(",") if x != ""])
STORE_P_TAGS = {"CORRECTED_JULY", "S10_SEPT", "S11_SEPT"}
STORE_G_TAGS = {"FORMAL_JULY", "S10_SEPT", "S11_SEPT"}

class OverrideView(Mapping):
    def __init__(self, base, over): self.base, self.over = base, over
    def __getitem__(self, k): return self.over[k] if k in self.over else self.base[k]
    def __contains__(self, k): return k in self.over or k in self.base
    def __iter__(self):
        seen = set()
        for k in list(self.over) + list(self.base):
            if k not in seen: seen.add(k); yield k
    def __len__(self): return len(list(iter(self)))
    def source_of(self, k): return "TODAY_SUBSTITUTED" if k in self.over else (self.base.source_of(k) if hasattr(self.base, "source_of") else None)

def build_ds(s, auids, pocket_map, global_map, m2i):
    fr = geom.pd.DataFrame({"UniprotID": auids, "CANO_RXN_SMILES": [s["model_reaction"]] * len(auids),
                            "sequence": list(s["pool_seqs"]), "Label": [0] * len(auids)})
    ds = geom.GeometricDataset.__new__(geom.GeometricDataset); pyg_data.Dataset.__init__(ds)
    ds.df_data = fr; ds.pocket_node_feature = pocket_map; ds.esm_dim = DIM
    ds.protein_dict = core.gvp_store; ds.esm_feat_dict = global_map; ds.rxn_feat_dict = core.rxn_fp
    ds.uniprot_ids = list(auids); ds.rxns = [s["model_reaction"]] * len(auids)
    ds.targets = [0] * len(auids); ds.seqs = list(s["pool_seqs"]); ds.weights = torch.ones(len(auids))
    ds.mol_to_index = m2i; ds.mol_to_data = core.molecule_graphs; ds.reacting_center_map = core.reaction_centers
    return ds

def fwd_ws(m, ds):
    b = next(iter(DataLoader(ds, batch_size=len(ds.uniprot_ids), shuffle=False, follow_batch=FOLLOW))).to(DEV)
    with torch.no_grad():
        o = m.forward(b)
    if isinstance(o, tuple): o = o[0]
    v = o.detach().cpu().to(torch.float64).numpy().reshape(-1)
    assert np.isfinite(v).all()
    return v

def fwd_b16(m, ds):
    caps = step_caps(ds)
    v = forward_dataset(m, ds, DataLoader, FOLLOW, DEV, _emodel, max_candidates=16, caps=caps)
    assert np.isfinite(v).all() and len(v) == len(ds.uniprot_ids)
    return v, caps

models = {}
def make_model(seed):
    p, want = CKPT[seed]
    h = L2.sha_file(p)
    assert h == want, f"ckpt sha {seed}"
    torch.manual_seed(seed)
    m = EnzymeCAGE(use_esm=True, use_structure=True, use_drfp=True, use_prods_info=False,
                   plm_model="esmc600m", plm_dim=DIM, interaction_method="geo-enhanced-interaction",
                   rxn_inner_interaction=True, pocket_inner_interaction=True, device=str(DEV)).to(DEV)
    ck = torch.load(p, map_location="cpu", weights_only=False)
    m.load_state_dict(ck["model_state_dict"], strict=True); m.eval()
    assert getattr(m, "sigmoid_readout", None) is False
    return m

def upsert(fp, key, seed, value):
    if os.path.exists(fp):
        rec = json.load(open(fp))
    else:
        return None
    rec["conditions"][key][seed] = value
    return rec

coverage = {"eligible_steps": 0, "completed": 0, "no_substitutable_typed": [], "forward_calls": 0,
            "nonfinite_typed": [], "baseline_mismatch_recorded": []}
node_memo = {}
def node_of(sha):
    if sha not in node_memo:
        node_memo[sha] = np.load(f"{CACHE}/{sha}.npy")
        if len(node_memo) > 120:
            node_memo.pop(next(iter(node_memo)))
    return node_memo[sha]

for ctx in P.CTXS:
    log(f"===== ctx {ctx} =====")
    want = [t for t in NC2 if t["ctx"] == ctx]
    rx = P.RXN[ctx]
    with open(rx + "/rxn2fp_merged.pkl", "rb") as f: core.rxn_fp = pickle.load(f)
    with open(rx + "/reacting_center_merged.pkl", "rb") as f: core.reaction_centers = pickle.load(f)
    mdir = Path(rx + "/mol_conformation")
    mtab = pd.read_csv(mdir / "mol2id.csv")
    core.molecule_index = frozenset(mtab["SMILES"].astype(str))
    m2i = dict(zip(mtab.SMILES.astype(str), mtab.ID))
    core.molecule_graphs = torch.load(mdir / "mol_graph_dict.pt", map_location="cpu", weights_only=False)
    core.ctx = ctx
    steps = {s["step_id"]: s for s in json.load(open(f"{POOL}/UNIFIED_STEP_TABLE_{ctx}.json"))}
    core.set_sha_map([(sq, sh) for s in steps.values() for sq, sh in zip(s["pool_seqs"], s["pool_shas"])])
    for t in want:
        sid = t["step_id"]
        fpB = f"{VB}/{ctx}_{sid}.json"
        if os.path.exists(fpB) and set(json.load(open(fpB))["conditions"]["A"]) == {str(x) for x in SEEDS}:
            coverage["completed"] += 1; continue
        s = steps[sid]
        auids, seqs, shas = s["asset_uids_new"], s["pool_seqs"], s["pool_shas"]
        over_pocket, over_global, sub_mask, rows_plan, rescue_rows = {}, {}, [], [], 0
        for i, (au, sq, sh, uid) in enumerate(zip(auids, seqs, shas, s["pool_uids"])):
            entry = {"i": i, "uid": uid, "asset_uid": au, "seq_sha": sh}
            is_sub = False
            if sh in node_shas:
                n = node_of(sh)
                g_tag = core.global_source_of(sq)
                entry["global_tag"] = g_tag
                if g_tag in STORE_G_TAGS:
                    over_global[sq] = np.ascontiguousarray(n.mean(0), dtype=np.float32)
                    is_sub = True; entry["sub_global"] = True
                p_tag = core.pocket_store.source_of(au)
                entry["pocket_tag"] = p_tag
                if p_tag in STORE_P_TAGS:
                    idxs = corr_idx.get(au) if p_tag == "CORRECTED_JULY" else carrier_idx.get(au)
                    entry["pocket_route"] = "CORRECTED_JULY_idx" if p_tag == "CORRECTED_JULY" else "CARRIER_idx"
                    entry["pocket_idxs_n"] = len(idxs) if idxs else 0
                    if idxs:
                        try:
                            sp = np.asarray(core.pocket_store[au])
                            if sp.shape[0] == len(idxs) and max(idxs) < n.shape[0] and min(idxs) >= 0:
                                over_pocket[au] = np.ascontiguousarray(n[list(idxs)], dtype=np.float32)
                                is_sub = True; entry["sub_pocket"] = True
                        except Exception:
                            entry["pocket_sub_error"] = True
            elif "global_tag" not in entry:
                entry["global_tag"] = core.global_source_of(sq)
                entry["pocket_tag"] = core.pocket_store.source_of(au) if au in core.pocket_store else ""
            if sh in node_receipts:
                entry["node_value_sha256"] = node_receipts[sh]["node_value_sha256"]
                entry["node_recipe"] = node_receipts[sh]["recipe"]
            sub_mask.append(is_sub)
            if not is_sub:
                if entry.get("pocket_tag") == "RESCUE_R3D": rescue_rows += 1; entry["class"] = "NON_SUBSTITUTABLE_RESCUE_ONLY"
                else: entry["class"] = "NON_SUBSTITUTABLE_NO_SAME_RECIPE"
            else:
                entry["class"] = "SUBSTITUTED"
            rows_plan.append(entry)
        if not any(sub_mask):
            coverage["no_substitutable_typed"].append({"ctx": ctx, "step_id": sid, "reason": "NO_SUBSTITUTABLE_ROW"})
            json.dump({"status": "NO_SUBSTITUTABLE_ROW", "ctx": ctx, "step_id": sid,
                       "n_rows": len(auids), "rescue_rows": rescue_rows}, open(f"{VI}/{ctx}_{sid}.json", "w"), indent=1)
            continue
        coverage["eligible_steps"] += 1
        # condition input manifests (body actually saved; identity = its sha)
        manA = {"ctx": ctx, "step_id": sid, "condition": "A", "protocol": "PRODUCTION_BOUNDED16_FROZEN_WHOLE_STEP_MAXIMA",
                "pool_order": "frozen", "rows": rows_plan}
        manB = {"ctx": ctx, "step_id": sid, "condition": "B", "protocol": "PRODUCTION_BOUNDED16_FROZEN_WHOLE_STEP_MAXIMA",
                "substituted": [[e["i"], e["uid"], e.get("sub_global", False), e.get("sub_pocket", False),
                                 e.get("node_value_sha256")] for e in rows_plan if e["class"] == "SUBSTITUTED"],
                "non_substitutable_classes": [[e["i"], e["class"]] for e in rows_plan if e["class"] != "SUBSTITUTED"]}
        body = {"manifest_A": manA, "manifest_B": manB, "over_global_keys": len(over_global), "over_pocket_keys": len(over_pocket)}
        tmp = f"{VI}/{ctx}_{sid}.json"
        json.dump(body, open(tmp + ".tmp", "w"), indent=1, sort_keys=True); os.replace(tmp + ".tmp", tmp)
        man_text = open(tmp, "rb").read()
        idA = hashlib.sha256(json.dumps(manA, sort_keys=True).encode()).hexdigest()
        idB = hashlib.sha256(json.dumps(manB, sort_keys=True).encode()).hexdigest()
        ds_b = build_ds(s, auids, core.pocket_store, core.sequence_esm, m2i)
        ds_s = build_ds(s, auids, OverrideView(core.pocket_store, over_pocket),
                        OverrideView(core.sequence_esm, over_global), m2i)
        capsA = step_caps(ds_b); capsB = step_caps(ds_s)
        if not os.path.exists(fpB):
            rec = {"arm": "new_esmc600m", "ctx": ctx, "step_id": sid,
                   "model_reaction": s["model_reaction"], "model_key_sha256": s["model_key_sha256"],
                   "pool_uids": s["pool_uids"], "pool_shas": s["pool_shas"], "gold_flags": s["gold_flags"],
                   "asset_uids": auids, "seeds": [str(x) for x in SEEDS],
                   "checkpoint_shas": {str(x): CKPT[x][1] for x in SEEDS},
                   "baseline_condition": "A",
                   "conditions": {"A": {}, "B": {}},
                   "condition_metadata": {
                       "A": {"protocol": "PRODUCTION_BOUNDED16_FROZEN_WHOLE_STEP_MAXIMA caps=" + json.dumps({k: (int(v) if hasattr(v, "__int__") else v) for k, v in capsA.items()} if isinstance(capsA, dict) else str(capsA)),
                             "input_identity_sha256": idA, "candidate_identity": "same_original_order"},
                       "B": {"protocol": "PRODUCTION_BOUNDED16_FROZEN_WHOLE_STEP_MAXIMA same-caps-as-A where shapes allow",
                             "input_identity_sha256": idB, "candidate_identity": "same_original_order"}}}
            json.dump(rec, open(fpB + ".tmp", "w"), indent=1); os.replace(fpB + ".tmp", fpB)
        try:
            for seed in SEEDS:
                if seed not in models:
                    models[seed] = make_model(seed); log("  model seed", seed)
                m = models[seed]
                LA, _ = fwd_b16(m, ds_b); LB, _ = fwd_b16(m, ds_s)
                coverage["forward_calls"] += 2
                rec = json.load(open(fpB))
                rec["conditions"]["A"][str(seed)] = [float(x) for x in LA]
                rec["conditions"]["B"][str(seed)] = [float(x) for x in LB]
                json.dump(rec, open(fpB + ".tmp", "w"), indent=1); os.replace(fpB + ".tmp", fpB)
                # baseline A vs retained original production raw (bounded16 same protocol)
                orig_p = f"{BASE}/gf_out/new_esmc600m/{ctx}/raw_logits_new_esmc600m/{sid}.json"
                if os.path.exists(orig_p):
                    og = json.load(open(orig_p))
                    ov = og["raw_logits"].get(str(seed))
                    if ov and len(ov) == len(LA):
                        d = float(np.max(np.abs(np.array(ov) - LA)))
                        e = baseline_check.setdefault(f"{ctx}/{sid}/{seed}", {"max_abs_delta_vs_original_raw": d,
                              "original_common_context_sha256": og.get("common_context_sha256")})
                        if d > 1e-5: e["baseline_drift_gt_1e-5"] = True; coverage["baseline_mismatch_recorded"].append(f"{ctx}/{sid}/{seed}")
        except (RuntimeError, AssertionError) as exc:
            coverage["nonfinite_typed"].append({"ctx": ctx, "step_id": sid, "error": type(exc).__name__ + ": " + str(exc)[:200]})
            log("  TYPED FAIL", sid, exc)
            continue
        coverage["completed"] += 1
        if coverage["completed"] % 20 == 0:
            log(f"  steps done {coverage['completed']}/{len(NC2)} ({time.time()-t0:.0f}s)")
    json.dump(baseline_check, open(BC + ".tmp", "w"), indent=1); os.replace(BC + ".tmp", BC)

# ---- independent whole-step layer: the 6 NC2B gold-shift steps ----
log("===== whole-step independent layer =====")
for t in WS_STEPS:
    ctx, sid = t["ctx"], t["step_id"]
    fpW = f"{VW}/{ctx}_{sid}.json"
    if os.path.exists(fpW) and set(json.load(open(fpW))["conditions"]["A"]) == {str(x) for x in SEEDS}:
        continue
    rx = P.RXN[ctx]
    with open(rx + "/rxn2fp_merged.pkl", "rb") as f: core.rxn_fp = pickle.load(f)
    with open(rx + "/reacting_center_merged.pkl", "rb") as f: core.reaction_centers = pickle.load(f)
    mdir = Path(rx + "/mol_conformation")
    mtab = pd.read_csv(mdir / "mol2id.csv")
    core.molecule_index = frozenset(mtab["SMILES"].astype(str))
    m2i = dict(zip(mtab.SMILES.astype(str), mtab.ID))
    core.molecule_graphs = torch.load(mdir / "mol_graph_dict.pt", map_location="cpu", weights_only=False)
    core.ctx = ctx
    steps = {s["step_id"]: s for s in json.load(open(f"{POOL}/UNIFIED_STEP_TABLE_{ctx}.json"))}
    core.set_sha_map([(sq, sh) for s in steps.values() for sq, sh in zip(s["pool_seqs"], s["pool_shas"])])
    s = steps[sid]
    auids, seqs, shas = s["asset_uids_new"], s["pool_seqs"], s["pool_shas"]
    over_pocket, over_global, sub_mask = {}, {}, []
    for au, sq, sh in zip(auids, seqs, shas):
        is_sub = False
        if sh in node_shas:
            n = node_of(sh)
            if core.global_source_of(sq) in STORE_G_TAGS:
                over_global[sq] = np.ascontiguousarray(n.mean(0), dtype=np.float32); is_sub = True
            p_tag = core.pocket_store.source_of(au)
            if p_tag in STORE_P_TAGS:
                idxs = corr_idx.get(au) if p_tag == "CORRECTED_JULY" else carrier_idx.get(au)
                if idxs:
                    try:
                        sp = np.asarray(core.pocket_store[au])
                        if sp.shape[0] == len(idxs) and max(idxs) < n.shape[0] and min(idxs) >= 0:
                            over_pocket[au] = np.ascontiguousarray(n[list(idxs)], dtype=np.float32); is_sub = True
                    except Exception: pass
        sub_mask.append(is_sub)
    if not any(sub_mask):
        continue
    ds_b = build_ds(s, auids, core.pocket_store, core.sequence_esm, m2i)
    ds_s = build_ds(s, auids, OverrideView(core.pocket_store, over_pocket), OverrideView(core.sequence_esm, over_global), m2i)
    idW = hashlib.sha256(json.dumps({"ctx": ctx, "sid": sid, "sub": sub_mask, "protocol": "WHOLE_STEP_PURE_BATCH"}, sort_keys=True).encode()).hexdigest()
    rec = {"arm": "new_esmc600m", "ctx": ctx, "step_id": sid, "layer": "NC2B_independent_whole_step",
           "model_reaction": s["model_reaction"], "model_key_sha256": s["model_key_sha256"],
           "pool_uids": s["pool_uids"], "pool_shas": s["pool_shas"], "gold_flags": s["gold_flags"],
           "seeds": [str(x) for x in SEEDS], "checkpoint_shas": {str(x): CKPT[x][1] for x in SEEDS},
           "baseline_condition": "A",
           "conditions": {"A": {str(seed): [float(x) for x in fwd_ws(models[seed], ds_b)] for seed in SEEDS},
                          "B": {str(seed): [float(x) for x in fwd_ws(models[seed], ds_s)] for seed in SEEDS}},
           "condition_metadata": {"A": {"protocol": "WHOLE_STEP_PURE_BATCH (historical NC2 protocol, independent layer)",
                                        "input_identity_sha256": idW, "candidate_identity": "same_original_order"},
                                  "B": {"protocol": "WHOLE_STEP_PURE_BATCH substituted",
                                        "input_identity_sha256": idW, "candidate_identity": "same_original_order"}}}
    json.dump(rec, open(fpW + ".tmp", "w"), indent=1); os.replace(fpW + ".tmp", fpW)
    coverage["forward_calls"] += 2 * len(SEEDS)

json.dump(coverage, open(OUT + "/stageB/COVERAGE.json.tmp", "w"), indent=1)
os.replace(OUT + "/stageB/COVERAGE.json.tmp", OUT + "/stageB/COVERAGE.json")
log("STAGE_B_DONE", json.dumps({k: v for k, v in coverage.items() if k != "baseline_mismatch_recorded"}))
print("STAGE_B_DONE", flush=True)
