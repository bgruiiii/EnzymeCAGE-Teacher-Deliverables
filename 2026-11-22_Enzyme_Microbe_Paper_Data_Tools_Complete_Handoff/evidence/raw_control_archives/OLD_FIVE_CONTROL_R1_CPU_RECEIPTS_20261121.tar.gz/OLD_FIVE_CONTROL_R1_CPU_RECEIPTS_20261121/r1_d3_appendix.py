#!/usr/bin/env python3
"""R1 §1: corrected D3 probability appendix, CPU-only, from the ORIGINAL saved
first-package trace (bytes unmodified; alias fields added here). Facts adopted
from live source evidence: the REAL wrapper path is predictor.py(SHA b9877649..)
-> model.evaluate() -> enzymecage/base.py(SHA abdfe787..) line 36-37 applies
torch.sigmoid when sigmoid_readout=False. Therefore trace per-seed values are
PROBABILITIES and the wrapper aggregate is the five-PROBABILITY mean. The first
package's second sigmoid (median ~0.5 delta) is WITHDRAWN here.
Also: v1 delivery ships frozen_test_replay.py = a REPLAY over packaged frozen
per-seed test predictions; the ORIGINAL script that produced test_result rows
and its actual DataLoader batch context are NOT in the delivery -> original
batch context remains NOT_VERIFIED (config batch_size=256 proves config only).
No model load, no GPU."""
import csv, hashlib, json, math, os, statistics, sys
from collections import OrderedDict

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
V1 = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries/enzymecage_v1_20260714"
REVIEW = R1 + "/evidence/OLD_FIVE_CONTROL_R1_REVIEW_EVIDENCE_20261121"
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()

src = json.load(open(O + "/stageD/D3_positive_control.json"))
trace = src["five_seed_full_vectors_logit"]  # original first-package field name; ACTUAL SEMANTICS: per-seed probabilities
uids = src["pool_uids_order"]
orig_pred = {u: v["v1_original_pred"] for u, v in src["comparison_to_original_v1_pred"].items()}
response_scores = {c["uid"]: c["score"] for c in src["full_scores"]}
response_rank = {c["uid"]: c["rank"] for c in src["full_scores"]}

def linear_quantile(sv, q):
    n = len(sv); pos = q * (n - 1); lo = math.floor(pos); hi = math.ceil(pos)
    if lo == hi: return sv[int(pos)]
    return sv[lo] + (sv[hi] - sv[lo]) * (pos - lo)

rows = []
for i, u in enumerate(uids):
    if u not in trace: continue
    per_seed = [float(x) for x in trace[u]]
    assert len(per_seed) == 5 and all(0.0 <= x <= 1.0 for x in per_seed), (u, per_seed[:2])
    mean5 = sum(per_seed) / 5.0
    sv = sorted(per_seed)
    ci = [linear_quantile(sv, 0.025), linear_quantile(sv, 0.975)]
    d_seed40 = abs(per_seed[0] - orig_pred[u])
    d_mean = abs(mean5 - orig_pred[u])
    rows.append(OrderedDict(uid=u,
        seed40_probability=per_seed[0], ensemble_probability=mean5,
        original_seed40_pred=orig_pred[u],
        abs_seed40_delta=d_seed40, abs_ensemble_vs_seed40=d_mean,
        wrapper_response_score=response_scores.get(u),
        wrapper_score_matches_recomputed_mean=abs(response_scores[u] - mean5) < 1e-12,
        wrapper_response_rank=response_rank.get(u),
        ci_recomputed_cpu=ci))
rows.sort(key=lambda r: (-r["wrapper_response_score"], r["uid"]))
top10_prefix = [r["uid"] for r in rows[:10]]
order_ok = top10_prefix == [c["uid"] for c in src["full_scores"]][:10]
med_s40 = statistics.median(r["abs_seed40_delta"] for r in rows)
med_en = statistics.median(r["abs_ensemble_vs_seed40"] for r in rows)
mx_s40 = max(r["abs_seed40_delta"] for r in rows)
mx_en = max(r["abs_ensemble_vs_seed40"] for r in rows)

# cross-check against the reviewer's CPU adopted table, row by row
rev = {x["uid"]: x for x in json.load(open(REVIEW + "/D3_CORRECTED_PROBABILITIES.json"))}
mismatch = []
for r in rows:
    rv = rev.get(r["uid"])
    if rv is None: mismatch.append((r["uid"], "NOT_IN_REVIEWER_TABLE")); continue
    for k, kk in (("seed40_probability", "seed40_probability"), ("ensemble_probability", "ensemble_probability"),
                  ("abs_seed40_delta", "abs_seed40_delta"), ("abs_ensemble_vs_seed40", "abs_ensemble_vs_seed40")):
        if abs(r[k] - rv[kk]) > 1e-12: mismatch.append((r["uid"], k, r[k], rv[kk]))

replay_path = V1 + "/scripts/frozen_test_replay.py"
batch_ctx = {
    "delivery_replay_script": {"path": replay_path, "sha256": sha(replay_path),
        "semantics": "frozen_test_replay.py: 'Deterministic ranking replay over packaged frozen test predictions only' - reads each seed's test_result.csv pred column and averages; NOT the original forward driver"},
    "original_pred_semantics": "test_result rows are per-seed (seed_40 file) probabilities written by the HPC run; wrapper trace values are per-seed probabilities after base.py sigmoid",
    "config_batch_size_256": "3b_ensemble/seed_40/config.yaml batch_size=256 proves CONFIG ONLY",
    "actual_original_dataloader_batch": "NOT_VERIFIED: the generating script and per-forward batch context are not retained in the delivery; no new model run was done",
    "unattributed_seed40_max_delta_0.199": "NOT_VERIFIED attribution: same-seed max abs delta 0.199 cannot be fully explained by single-seed vs ensemble; candidates (hardware/padding/float-conversion timing/original batch) remain undifferentiated without the original input identity",
}

out = {
    "kind": "D3_CORRECTED_PROBABILITY_APPENDIX_R1",
    "utc": __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ", __import__("time").gmtime()),
    "source_trace_file": O + "/stageD/D3_positive_control.json",
    "source_trace_sha256": sha(O + "/stageD/D3_positive_control.json"),
    "semantic_correction": {
        "wrapper_predictor_sha256": sha("/usrdata/EnzymeCAGE_data/workspaces/path_enzyme_microbe_code_review_20261110/review_payload/src_snapshot/wrapper/predictor.py"),
        "matches_claimed_b9877649": sha("/usrdata/EnzymeCAGE_data/workspaces/path_enzyme_microbe_code_review_20261110/review_payload/src_snapshot/wrapper/predictor.py") == "b9877649deea4f929778331453a0f1f4eb73d72529e3f1c4b95d0a56c4ab82d3",
        "base_py_sha256": sha("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/enzymecage/base.py"),
        "matches_claimed_abdfe787": sha("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/enzymecage/base.py") == "abdfe7875a2b0c49032031dbc54915c435ed0bda895e0cce14c92be0be7421de",
        "evaluate_sigmoid_lines": "base.py L36-37: if not self.sigmoid_readout: pred = torch.sigmoid(pred)",
        "conclusion": "trace per-seed values ARE probabilities; wrapper aggregate = mean of five probabilities; 'wrapper averages logits' WITHDRAWN; second sigmoid WITHDRAWN (the ~0.5 median delta came from that error)",
        "field_alias_note": "first-package key five_seed_full_vectors_logit contains probabilities under a wrong name; original package left unmodified"},
    "per_uid_rows": rows,
    "aggregates": {
        "n": len(rows),
        "wrapper_score_equals_recomputed_mean_of_trace": all(r["wrapper_score_matches_recomputed_mean"] for r in rows),
        "ordering_minus_score_uid_and_top10_prefix_consistent": bool(order_ok),
        "seed40_vs_original_pred": {"median_abs_delta": med_s40, "max_abs_delta": mx_s40},
        "five_probability_mean_vs_original_pred": {"median_abs_delta": med_en, "max_abs_delta": mx_en},
        "ci_status": "CPU-recomputed linear-quantile CI (2.5/97.5 per utils); original response CI was not saved in the first package; independent comparison against the original response CI NOT POSSIBLE"},
    "reviewer_table_crosscheck": {"reviewer_file_sha256": sha(REVIEW + "/D3_CORRECTED_PROBABILITIES.json"),
                                   "n_mismatched_fields": len(mismatch), "mismatches": mismatch[:20]},
    "positive_control_still_valid": "the real wrapper call itself produced consistent aggregate/ordering/topk on probabilities; it remains a valid in-scope positive control and does NOT replace target S02/S03",
    "batch_input_context": batch_ctx,
}
json.dump(out, open(R1 + "/D3_CORRECTED_PROBABILITY_APPENDIX.json", "w"), indent=1)
with open(R1 + "/D3_CORRECTED_PROBABILITY_APPENDIX.tsv", "w") as f:
    f.write("uid\tseed40_probability\tensemble_probability\toriginal_seed40_pred\tabs_seed40_delta\tabs_ensemble_vs_seed40\twrapper_response_score\twrapper_response_rank\tci_recomputed_2_5\tci_recomputed_97_5\n")
    for r in rows:
        f.write(f"{r['uid']}\t{r['seed40_probability']}\t{r['ensemble_probability']}\t{r['original_seed40_pred']}\t{r['abs_seed40_delta']}\t{r['abs_ensemble_vs_seed40']}\t{r['wrapper_response_score']}\t{r['wrapper_response_rank']}\t{r['ci_recomputed_cpu'][0]}\t{r['ci_recomputed_cpu'][1]}\n")
print("rows", len(rows), "| reviewer mismatches", len(mismatch))
print("median seed40", med_s40, "max", mx_s40)
print("median ensemble", med_en, "max", mx_en)
print("aggregate checks:", out["aggregates"]["wrapper_score_equals_recomputed_mean_of_trace"], order_ok)
