#!/usr/bin/env python3
"""R1 close-out: plain-language page + four-class checks.
RECOMPUTATION_CORRECT / REAL_INPUT_IDENTITY_PROVEN / HISTORICAL_RECEIPT_MISSING /
RECONSTRUCTED_AFTER_RUN_ONLY are reported as SEPARATE lists — never one green."""
import json, os, sys, time

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
L = lambda p: json.load(open(R1 + "/" + p))
D3 = L("D3_CORRECTED_PROBABILITY_APPENDIX.json")
LED = L("S02_S03_ASSET_LEDGER.json")
CNT = L("COUNTS_BY_UNIT.json")
STATS_B = L("B_NODE_REVERIFY_STATS.json")
STATS_A = L("A_IDENTITY_STATS.json")
try: STATS_C = L("C_IDENTITY_STATS.json")
except Exception: STATS_C = None

green = {"recomputation_correct": [], "real_input_identity_proven": [],
         "historical_receipt_missing": [], "reconstructed_after_run_only": []}
g = green["recomputation_correct"]
g.append({"item": "R1 D3 appendix vs reviewer table", "detail": f"60/60 UIDs, 0 field mismatches; median seed40 {D3['aggregates']['seed40_vs_original_pred']['median_abs_delta']:.3e}, median 5-prob-mean {D3['aggregates']['five_probability_mean_vs_original_pred']['median_abs_delta']:.3e}; wrapper-score-equals-trace-mean=True; order/top10=True"})
g.append({"item": "R1 S02/S03 boundary vs frozen registry", "detail": "44/44 rows order+candidate SHA+model key match UNIFIED_STEP_TABLE/CONTROL_REQUESTS"})
g.append({"item": "B node-array revalue vs receipts", "detail": f"{STATS_B['receipt_value_sha_ok']}/991 value digests match; manifests {STATS_B['manifest_sha_recomputed_ok']}/219 recomputable; A seq {STATS_A['seq_sha_matches']}/{STATS_A['rows']}"})
r = green["real_input_identity_proven"]
r.append({"item": "B substituted-row actual tensors", "detail": "991 node arrays re-read with receipt-aligned digests + 991 global + 640 pocket ordered-slice component digests; index source files SHA-bound"})
r.append({"item": "A sequence identities", "detail": "35/35 UIDs rehashed from the same p291 index (CPU)"})
m = green["historical_receipt_missing"]
m.append({"item": "START receipt vs A/B start", "detail": "START=11:03:27Z > A=10:41:45Z, B=10:43:26Z: pre-execution freeze for A/B NOT_RETAINED; kept, never backfilled"})
m.append({"item": "wrapper original response CI + first-package D per-candidate CI", "detail": "NOT_RETAINED; CI column in R1 appendix is CPU-recomputed, independent comparison impossible"})
m.append({"item": "original v1 test_result batch context", "detail": "frozen_test_replay.py replays frozen preds only; generating script/runtime identity NOT_VERIFIED; same-seed max delta 0.19909606173225403 unattributed"})
m.append({"item": "admission v0/v1 bodies", "detail": "NOT_RETAINED_SUPERSEDED_IN_PLACE (unchanged from first package)"})
x = green["reconstructed_after_run_only"]
x.append({"item": "C per-condition manifests/padding/split shapes", "detail": ("rebuilt from same chain code paths; status: " + (json.dumps(STATS_C) if STATS_C else "PENDING")) })
x.append({"item": "B WS-layer manifests", "detail": "6 steps rebuilt as WS_manifests/*.json; first-package descriptive hash kept separately; NOT runtime-saved"})
x.append({"item": "C coverage adopted numbers", "detail": "62 files / 310 seed-records (first-package COVERAGE.json completed=0 is a write-order defect; original files untouched)"})
x.append({"item": "counts units", "detail": "B physical-forward 7600 = SOURCE_DERIVED_EXPECTATION (7540 bounded + 60 whole-step); no runtime counter"})

page = f"""# 原五组补证 R1（仅CPU收据收口）—— 白话一页

**这轮不重跑任何模型。** 只把首包（数值复算已被主审独立核对通过）的三类证据边界收口：

1. **D 的公式说法纠正**：真实 wrapper 调用的 `model.evaluate()` 在 base.py L36-37 已经
   sigmoid——trace 里本来就是每 seed 概率，聚合是五概率均值。首包把"~0.5 中位差"解释为
   logit vs 概率公式不同是**错的**，那是二次 sigmoid 造成的，已撤回。修正后：
   本次 seed40 vs 原交付 seed40 pred 中位差 {D3['aggregates']['seed40_vs_original_pred']['median_abs_delta']:.3e}
   （最大 {D3['aggregates']['seed40_vs_original_pred']['max_abs_delta']:.6g}，同 seed 差仍未归因，保持 NOT_VERIFIED，
   不拿配置 batch=256 顶替实际 batch 证据）；五概率均值 vs 原 pred 中位 {D3['aggregates']['five_probability_mean_vs_original_pred']['median_abs_delta']:.3e}
   （最大 {D3['aggregates']['five_probability_mean_vs_original_pred']['max_abs_delta']:.6g}）。
   正控调用本身（均值/排序/TopK 一致）仍成立；CI 本卡无原响应可比（CPU 重建单列）。
2. **S03 按冻结登记收口**：合同 S03 是 BIOPATH150_013__S03__BSY-r00201（31 候选），不是首包误测的
   001__S03（9 候选，降为附录）。本卡对主审边界表 44/44 行验证与冻结池一致：
   S02=2 可用/11 缺（且反应缺 DRFP+分子图）；S03=18 可用/13 缺（反应齐）。
   正确 S03 的真实调用（18 酶评分、完整 5seed 概率 trace、10 项核对全过）采用主审节点追加实物；
   第一次保存失败的记录同时入账。"44 个去重 UID、无跨步重复"——11+8=19 只是跨步关联数。
   缺的 13 个不能跳过后称完整 31 排名；S02 的评分仍是资产边界。
3. **输入收据能回源多少写多少**：B 的 991 条替换数组本卡全部重读并与 receipt 值摘要 100% 对齐；
   A 的 35 条序列 SHA 全等；C 的"实际张量身份"首包只有描述哈希——本卡用同一链路径重建
   62 份条件清单（含 padding/最大图/split 子批形状），全部标 RECONSTRUCTED_AFTER_RUN，
   不冒充运行时快照。首包 START 收据晚于 A/B 启动、无运行时 forward 计数器、原响应 CI 未保存、
   旧准入正文缺失——这些都作为"历史收据缺失"保留，不倒写、不为补绿重跑。

**影响**：原五组成绩、旧失败、阈值、方法限制全部不动。数值复算部分本可放心引用；
"输入身份"现在分层可审计；D 的目标 S03 从"整步缺资产"更正为"18/31 真实已测、13 缺资产是边界"；
S02 因反应资产缺失不能在本工具路线评分。下一步若要工具覆盖 CURRENT95 反应，需要先列资产生成入口
——属于范围设计决定，不在本卡静默变更。
"""
open(R1 + "/RESULTS_PLAIN_LANG.md", "w").write(page)
json.dump(green, open(R1 + "/R1_CHECKS.json", "w"), indent=1)
print("plain page + checks written")
