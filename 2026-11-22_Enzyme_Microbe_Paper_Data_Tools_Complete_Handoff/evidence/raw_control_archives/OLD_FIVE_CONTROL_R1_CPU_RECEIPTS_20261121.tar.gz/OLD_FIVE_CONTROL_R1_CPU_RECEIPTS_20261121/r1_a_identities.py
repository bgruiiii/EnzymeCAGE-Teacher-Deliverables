#!/usr/bin/env python3
"""R1 §3 (A): re-verify the legacy-600M replay identities on CPU — per frozen
case: reference file byte sha, T2 pool file sha, p291 config sha, per-UID
sequence SHA recomputed from the ACTUAL p291 PrecomputedAssetIndex (CPU, no
ranker) vs the first-package vector record's pool_shas, and checkpoint identity
(25/25 reverified file CHECKPOINT_REVERIFY_20261121.json, which was produced
THIS card at ~10:2x before stage A start 10:41:45 — disclosed as pre-execution
for A/B/C but POSTED relative to the START receipt timestamp; nothing is
presented as a pre-11:03 freeze)."""
import hashlib, json, os, sys, time

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
PKG = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103/current95_five_model_complete_prep_20261103"
sys.path.insert(0, PKG + "/sources")
import r3_paths as P
REFDIR = "/usrdata/EnzymeCAGE_data/training_runs/enzymecage_v6_298_rhea142_brenda_enzgfm650m_retrain_20260922/s11_r1_self_included_four_model_20260927/inputs/legacy/pollutant291_p2rank_legacy600m_model_matched_dual5seed_rerun_20260922/results/raw_logits_600m"
sha_b = lambda bs: hashlib.sha256(bs).hexdigest()

import yaml
cfg = yaml.safe_load(open(P.P291 + "/runtime/NEW/config.yaml"))
sys.path.insert(0, P.REPO_OLD); sys.path.insert(0, P.WRAP)
from enzymecage_wrapper.asset_index import PrecomputedAssetIndex
t0 = time.time()
idx = PrecomputedAssetIndex(cfg)
print(f"asset index loaded in {time.time()-t0:.0f}s", flush=True)

lines = []
for c in json.load(open(O + "/input/CONTROL_REQUESTS.json"))["legacy_frozen_cases"]:
    fp = O + f"/stageA/vectors/stageA_{c}.json"
    rec = json.load(open(fp))
    raw = open(f"{REFDIR}/{c}.json", "rb").read()
    rj = json.loads(raw)
    rows = []
    for uid, sha_rec in zip(rec["pool_uids"], rec["pool_shas"]):
        seq = idx.sequence_for(uid)
        s2 = sha_b(seq.encode())
        rows.append({"uid": uid, "first_package_seq_sha256": sha_rec,
                     "R1_recomputed_seq_sha256": s2, "match": s2 == sha_rec,
                     "gvp_present": uid in idx.gvp, "pocket_present": uid in idx.pocket_node,
                     "global_present": seq in idx.sequence_esm})
    lines.append({"scope": "A_legacy600m_replay", "case": c,
                  "reference_file_sha256": sha_b(raw),
                  "pool_source_T2_case_pools_sha256": sha_b(open("/usrdata/EnzymeCAGE_data/workspaces/p298_tc_20260922/T2_case_pools.json", "rb").read()),
                  "p291_config_sha256": sha_b(open(P.P291 + "/runtime/NEW/config.yaml", "rb").read()),
                  "model_reaction_sha256": hashlib.sha256(rec["model_reaction"].encode()).hexdigest(),
                  "pool_uids_order_matches_reference": rec["pool_uids"] == rj["pool_uids"],
                  "rows": rows,
                  "provenance": "RECONSTRUCTED_AFTER_RUN (R1 CPU read of the same p291 index the run consumed); runtime vectors unmodified"})
with open(R1 + "/ACTUAL_INPUT_IDENTITIES_A.jsonl", "w") as f:
    for l in lines: f.write(json.dumps(l) + "\n")
n_ok = sum(1 for l in lines for r in l["rows"] if r["match"]); n = sum(len(l["rows"]) for l in lines)
json.dump({"cases": len(lines), "rows": n, "seq_sha_matches": n_ok,
           "order_matches": [l["pool_uids_order_matches_reference"] for l in lines],
           "ckpt_reverify": {"file": O + "/CHECKPOINT_REVERIFY_20261121.json",
                             "sha256": sha_b(open(O + "/CHECKPOINT_REVERIFY_20261121.json", "rb").read()),
                             "total": 25, "note": "25/25 match registry; launched ~10:15Z on this card BEFORE stage A (10:41:45Z) and B (10:43:26Z) starts, but the START_ENV_SOURCES receipt itself was written at 11:03:27Z — i.e. AFTER A/B had begun. The pre-execution receipt gap for A/B is retained as a limitation (R1 does not backdate anything); this re-verification is disclosed as review-time, not a pre-11:03 freeze"}},
          open(R1 + "/A_IDENTITY_STATS.json", "w"), indent=1)
print("A identities:", n_ok, "/", n, "match")
