#!/usr/bin/env python3
"""R1 §3 (C): rebuild per-condition input manifests for the 62 saved EnzGFM
vector files and the 6 whole-step layer files — the first package only hashed
arm/ctx/step/n (C) or ctx/sid/mask (WS), which is NOT actual-tensor identity.
New manifest bodies (with real byte SHAs) are written HERE and kept separate
from those descriptive hashes; they are RECONSTRUCTED_AFTER_RUN from the same
consumer chain code paths (R1Chains/E0 lane for C, NewArmIndexV3 overrides for
B-WS), never claimed as runtime-saved. Includes:
- per-UID: route uid, sequence sha, global/pocket/gvp tensor value digests
  (dtype/shape/byte order), E0 class-A vs R1 lane provenance;
- whole-step dataset actual padding / max graph / tensor shapes via CPU collate
  only (no model, no GPU); split-half sub-batch actual padding likewise;
- per-row provenance of ordered pocket indices (corrected jsonl vs carrier
  parquet, values and file SHAs) -> ORDERED_MAPPING_EVIDENCE rows.
No feature re-extraction, no index fixing."""
import hashlib, json, os, sys, time
import numpy as np

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
B = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
PKG = B + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, PKG + "/sources")
import r3_paths as P
sys.path.insert(0, B + "/scripts_node")
os.environ.setdefault("ENZYMECAGE_SHARD_CACHE_SIZE", "all")
sys.path.insert(0, P.S8CODE)
import pandas as pd
import torch
import enzymecage.dataset.geometric as geom
import torch_geometric.data as pyg_data
from torch_geometric.loader import DataLoader
import enzgfm_chains as EC

sha_b = lambda bs: hashlib.sha256(bs).hexdigest()
arr_sha = lambda a: sha_b(np.ascontiguousarray(np.asarray(a)).tobytes())
t0 = time.time()
log = lambda *a: print(f"[{time.time()-t0:7.1f}s]", *a, flush=True)

corr_sha = sha_b(open(P.CORR_JSONL, "rb").read())
carrier_sha = sha_b(open(P.CARRIER_PARQUET, "rb").read())
gvp_store_sha = "SEE_CHAIN_SHARDS_NOT_REHASHED"
chains = EC.R1Chains(*(
    (lambda m: (m._load_sharded_mapping, m.load_protein_gvp_data))(
        __import__("enzymecage.dataset.sharded_protein", fromlist=["x"]))))
e0_views, e0_seq, e0_sha, e0_closure = EC.build_e0_lane()
log("chains + E0 lane ready")

def resolve(arm, uid, sh, seq):
    if arm == "current_e0_enzgfm650m":
        seq_a = e0_seq.get(uid)
        if seq_a is not None and e0_sha.get(uid) == sh and seq_a == seq:
            e0g, e0p, e0gv = e0_views["global"], e0_views["pocket"], e0_views["gvp"]
            if uid in e0gv and uid in e0p and seq_a in e0g:
                pk = np.asarray(e0p[uid], dtype=np.float32); gv = e0gv[uid]; gl = np.asarray(e0g[seq_a], dtype=np.float32)
                if 0 < int(np.asarray(gv[0]).shape[0]) == int(pk.shape[0]) <= len(seq):
                    return ("E0_CLASS_A", uid, pk, gv, gl)
    aun = uid
    pk, pk_src = chains.pocket_get(aun); gv, gv_src = chains.gvp_get(aun)
    if pk is None or gv is None:
        ru = chains.route_uid(uid, sh)
        if ru:
            pk2, _2 = chains.pocket_get(ru); gv2, _3 = chains.gvp_get(ru)
            if pk2 is not None and gv2 is not None: aun, pk, gv = ru, pk2, gv2
    gl, gl_src, _5 = chains.global_get(seq)
    if pk is None or gv is None or gl is None: return None
    return ("R1_LANE", aun, np.asarray(pk, dtype=np.float32), gv, np.asarray(gl, dtype=np.float32))

_BIND_CACHE = {}
def bind(ctx):
    if ctx in _BIND_CACHE: return _BIND_CACHE[ctx]
    rx = P.RXN[ctx]
    fp = open(rx + "/rxn2fp_merged.pkl", "rb").read()
    ce = open(rx + "/reacting_center_merged.pkl", "rb").read()
    m2 = open(rx + "/mol_conformation/mol2id.csv", "rb").read()
    out = {"rxn2fp_merged_sha256": sha_b(fp), "reacting_center_merged_sha256": sha_b(ce),
           "mol2id_sha256": sha_b(m2), "mol_graph_dict_file": rx + "/mol_conformation/mol_graph_dict.pt",
           "mol_graph_dict_size_bytes": os.path.getsize(rx + "/mol_conformation/mol_graph_dict.pt")}
    _BIND_CACHE[ctx] = out
    return out

def ds_shapes_and_digests(res, s):
    """CPU-collate the whole-step dataset (no model) to record ACTUAL padding/
    max-graph/tensor shapes — reconstructed after the fact."""
    seqs = s["pool_seqs"]
    fp, ce, m2i, mg = None, None, None, None
    rx = P.RXN[s["ctx"]]
    import pickle
    fp = pickle.load(open(rx + "/rxn2fp_merged.pkl", "rb"))
    ce = pickle.load(open(rx + "/reacting_center_merged.pkl", "rb"))
    mtab = pd.read_csv(rx + "/mol_conformation/mol2id.csv")
    m2i = dict(zip(mtab.SMILES.astype(str), mtab.ID))
    mg = torch.load(rx + "/mol_conformation/mol_graph_dict.pt", map_location="cpu", weights_only=False)
    uids = [r[1] for r in res]
    fr = pd.DataFrame({"UniprotID": uids, "CANO_RXN_SMILES": [s["model_reaction"]] * len(uids),
                       "sequence": list(seqs), "Label": [0] * len(uids)})
    ds = geom.GeometricDataset.__new__(geom.GeometricDataset); pyg_data.Dataset.__init__(ds)
    ds.df_data = fr; ds.pocket_node_feature = {u: r[2] for u, r in zip(uids, res)}; ds.esm_dim = 2048
    ds.protein_dict = {u: r[3] for u, r in zip(uids, res)}
    ds.esm_feat_dict = {sq: r[4] for sq, r in zip(seqs, res)}
    ds.rxn_feat_dict = fp; ds.uniprot_ids = uids; ds.rxns = [s["model_reaction"]] * len(uids)
    ds.targets = [0] * len(uids); ds.seqs = list(seqs); ds.weights = torch.ones(len(uids))
    ds.mol_to_index = m2i; ds.mol_to_data = mg; ds.reacting_center_map = ce
    dl = DataLoader(ds, batch_size=len(uids), shuffle=False,
                    follow_batch=["protein", "reaction_feature", "esm_feature", "substrates", "products"])
    batch = next(iter(dl))
    shapes = {"protein": [list(batch.protein.x.shape), int(batch.protein.num_nodes.max() if hasattr(batch.protein, 'num_nodes') else -1)],
              "max_protein_nodes": int(batch["protein"].num_nodes.max()),
              "max_substrate_nodes": int(batch["substrates"].num_nodes.max()),
              "max_product_nodes": int(batch["products"].num_nodes.max()),
              "esm_feature_batch": list(batch.esm_feature_batch.shape),
              "reaction_feature_batch": list(batch.reaction_feature_batch.shape)}
    return ds, shapes

# ---- C: 62 files ----
REG = json.load(open(O + "/input/CONTROL_REQUESTS.json"))
PLAN = json.load(open(O + "/CONTROL_EXECUTION_PLAN.json"))
NC6 = PLAN["stageC_nc6_steps"]
steps_by = {ctx: {s["step_id"]: s for s in json.load(open(B + f"/runtime/pool/UNIFIED_STEP_TABLE_{ctx}.json"))}
            for ctx in ("main", "delta15")}
outC = open(R1 + "/ACTUAL_INPUT_IDENTITIES_C.jsonl", "w")
mapping_rows = []
statC = {"files": 0, "resolve_ok": 0, "resolve_miss": 0, "collate_ok": 0, "collate_fail": 0}
for arm in ("current_e0_enzgfm650m", "new_enzgfm650m"):
    for t in NC6:
        ctx, sid = t["ctx"], t["step_id"]
        fp = f"{O}/stageC/vectors/{arm}_{ctx}_{sid}.json"
        if not os.path.exists(fp): continue
        rec = json.load(open(fp))
        s = dict(steps_by[ctx][sid]); s["ctx"] = ctx
        res = [resolve(arm, u, sh, sq) for u, sh, sq in zip(s["pool_uids"], s["pool_shas"], s["pool_seqs"])]
        if any(r is None for r in res):
            statC["resolve_miss"] += 1
            outC.write(json.dumps({"scope": "C_batch_control", "arm": arm, "ctx": ctx, "step_id": sid,
                                   "status": "RESOLVE_MISS_RECHECK", "n_rows": len(s["pool_uids"])}) + "\n")
            continue
        statC["resolve_ok"] += 1
        rows = []
        for i, (u, sh, sq, r) in enumerate(zip(s["pool_uids"], s["pool_shas"], s["pool_seqs"], res)):
            lane, aun, pk, gv, gl = r
            rows.append({"i": i, "uid": u, "route_uid": aun, "lane": lane, "seq_sha": sh,
                         "global_sha256": arr_sha(gl), "global_shape_dtype": [list(np.asarray(gl).shape), str(np.asarray(gl).dtype)],
                         "pocket_sha256": arr_sha(pk), "pocket_shape_dtype": [list(np.asarray(pk).shape), str(np.asarray(pk).dtype)],
                         "gvp_repr": [str(type(gv)), len(gv) if hasattr(gv, "__len__") else None,
                                      arr_sha(np.asarray(gv[0], dtype=np.float32)) if isinstance(gv, (list, tuple)) and len(gv) else None]})
            mapping_rows.append({"scope": "C", "arm": arm, "step_id": sid, "uid": u, "route_uid": aun, "lane": lane,
                                 "pocket_ordered_rows": int(np.asarray(pk).shape[0]),
                                 "pocket_equals_len_seq_bound": bool(int(np.asarray(pk).shape[0]) <= len(sq)),
                                 "gvp_rows_first": int(np.asarray(gv[0]).shape[0]) if isinstance(gv, (list, tuple)) and len(gv) else None})
        try:
            _, shapes = ds_shapes_and_digests(res, s)
            statC["collate_ok"] += 1
        except Exception as exc:
            shapes = {"error": type(exc).__name__ + ": " + str(exc)[:160]}; statC["collate_fail"] += 1
        half = len(res) // 2
        sp_shapes = {}
        for tag, part in (("half1", res[:half]), ("half2", res[half:])):
            s2 = dict(s); s2["pool_seqs"] = s["pool_seqs"][:half] if tag == "half1" else s["pool_seqs"][half:]
            try:
                _, hsh = ds_shapes_and_digests(part, s2); sp_shapes[tag] = hsh
            except Exception as exc:
                sp_shapes[tag] = {"error": type(exc).__name__}
        body = {"arm": arm, "ctx": ctx, "step_id": sid, "model_reaction_sha256":
                hashlib.sha256(s["model_reaction"].encode()).hexdigest(),
                "pool_uids": s["pool_uids"], "rows": rows, "shapes": shapes, "split_shapes": sp_shapes,
                "sources_bound": bind(ctx), "provenance": "RECONSTRUCTED_AFTER_RUN (R1 CPU, same chain code paths; never runtime-saved)",
                "first_package_descriptive_identity_sha256": rec["condition_metadata"]["A"]["input_identity_sha256"]}
        bf = f"{R1}/C_manifests/{arm}_{ctx}_{sid}.json"
        os.makedirs(f"{R1}/C_manifests", exist_ok=True)
        json.dump(body, open(bf, "w"), indent=1, sort_keys=True)
        outC.write(json.dumps({"scope": "C_batch_control", "arm": arm, "ctx": ctx, "step_id": sid,
                               "new_manifest_file": bf, "new_manifest_sha256": sha_b(open(bf, "rb").read()),
                               "first_package_descriptive_hash_only": True,
                               "n_rows": len(rows), "shapes_recorded": "error" not in shapes}) + "\n")
        statC["files"] += 1
outC.close()
json.dump({"C": statC, "corrected_note": "first package COVERAGE.json completed=0 due to late assignment without rewrite; ACTUAL vectors on disk:",
           "actual_files": len([f for f in os.listdir(O + "/stageC/vectors") if f.endswith(".json")]),
           "seed_step_arm_records": statC["files"] and statC["files"] * 5,
           "mapping_rows": len(mapping_rows)}, open(R1 + "/C_IDENTITY_STATS.json", "w"), indent=1)
with open(R1 + "/ORDERED_MAPPING_EVIDENCE.tsv", "w") as f:
    f.write("scope\tarm\tstep_id\tuid\troute_uid\tlane\tcorrected_pocket_jsonl_sha256\tcarrier_parquet_sha256\tpocket_ordered_rows\tpocket_equals_len_seq_bound\tgvp_rows_first\n")
    for m in mapping_rows:
        f.write("\t".join(str(m.get(k, "")) for k in ["scope", "arm", "step_id", "uid", "route_uid", "lane"]) +
                f"\t{corr_sha}\t{carrier_sha}\t{m['pocket_ordered_rows']}\t{m['pocket_equals_len_seq_bound']}\t{m['gvp_rows_first']}\n")
log("C done", json.dumps(statC))
