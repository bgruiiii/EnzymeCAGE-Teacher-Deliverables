#!/usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python
"""R1 §3 shapes fix (CPU, no chain reload): compute the frozen-padding caps the
first-package runs actually used — step_caps semantics: protein=max ordered-
pocket rows across the step's candidates (from the saved value digests/
shapes), substrates/products = the reaction's merged molecule-graph node totals
(read from the node-counted mol_graph_dict once per ctx, identical values every
row), esm/reaction feature dims per arm. Split-half shapes from half-row
maxima. Every number tagged RECONSTRUCTED_FROM_STORED_ROWS_AND_MOL_GRAPHS
(RECONSTRUCTED_AFTER_RUN); not a runtime observation."""
import hashlib, json, os, pickle, sys, time
import pandas as pd

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
B = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
PKG = B + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, PKG + "/sources")
import r3_paths as P
import torch
SKIP_MOL = ["[*H2]"]
t0 = time.time()
MOL = {}
for ctx in ("main", "delta15"):
    rx = P.RXN[ctx]
    mg = torch.load(rx + "/mol_conformation/mol_graph_dict.pt", map_location="cpu", weights_only=False)
    MOL[ctx] = {k: (int(v.x.shape[0]) if hasattr(v, "x") else None) for k, v in mg.items()}
    print(ctx, "mols:", len(MOL[ctx]), flush=True)

def mol_totals(rxn):
    subs = [m.replace("*", "C") for m in rxn.split(">>")[0].split(".") if m not in SKIP_MOL]
    prods = [m.replace("*", "C") for m in rxn.split(">>")[1].split(".") if m not in SKIP_MOL]
    missing = [m for m in subs + prods if m not in MOL[ctx_now]]
    if missing: return None, missing
    return {"substrates_total_nodes": sum(MOL[ctx_now][m] for m in subs),
            "products_total_nodes": sum(MOL[ctx_now][m] for m in prods),
            "substrate_molecules": len(subs), "product_molecules": len(prods)}, None

def caps(rows, esm_dim, rxn):
    prot = max(r["pocket_shape_dtype"][0][0] for r in rows)
    mt, miss = mol_totals(rxn)
    if mt is None: return {"error": "MOL_GRAPH_MISSING", "missing": miss[:6]}
    return {"protein_max_nodes": prot, **mt, "esm_feature_dim": esm_dim,
            "reaction_feature_dim": 2048,
            "semantics": "values the frozen-padding contract pinned per step (step_caps); substrates/products are the reaction's merged graph totals (constant across rows)"}

stats = {"c_ok": 0, "c_err": 0, "ws_ok": 0}
for f in sorted(os.listdir(R1 + "/C_manifests")):
    fp = R1 + "/C_manifests/" + f
    d = json.load(open(fp))
    arm = d["arm"]; ctx = d["ctx"]; ctx_now = ctx
    sid = d["step_id"]
    s = {x["step_id"]: x for x in json.load(open(B + f"/runtime/pool/UNIFIED_STEP_TABLE_{ctx}.json"))}[sid]
    esm = 2048
    d["shapes"] = caps(d["rows"], esm, s["model_reaction"])
    half = len(d["rows"]) // 2
    d["split_shapes"] = {"half1": caps(d["rows"][:half], esm, s["model_reaction"]),
                         "half2": caps(d["rows"][half:], esm, s["model_reaction"]),
                         "note": "counterfactual sub-batches used THEIR OWN maxima (natural whole-sub-batch padding); not a production batching permission"}
    d["shapes_status"] = "RECONSTRUCTED_FROM_STORED_ROWS_AND_MOL_GRAPHS (RECONSTRUCTED_AFTER_RUN)"
    json.dump(d, open(fp, "w"), indent=1, sort_keys=True)
    stats["c_ok" if "error" not in d["shapes"] else "c_err"] += 1

for f in sorted(os.listdir(R1 + "/WS_manifests")):
    fp = R1 + "/WS_manifests/" + f
    d = json.load(open(fp))
    ctx = d["ctx"]; ctx_now = ctx
    s = {x["step_id"]: x for x in json.load(open(B + f"/runtime/pool/UNIFIED_STEP_TABLE_{ctx}.json"))}[d["step_id"]]
    pocket_rows = [r for r in d["rows"] if r.get("substituted")]
    # WS rows may lack pocket shapes (only substituted entries have them): fall back to C-style bound
    if pocket_rows:
        d["caps_note"] = "protein max from substituted pocket rows only; non-substituted pocket row counts NOT_RETAINED in this manifest"
    else:
        d["caps_note"] = "NOT_RETAINED: no substituted pocket component rows in this step's WS manifest"
    d["ws_shapes"] = {"reaction": (lambda: (mol_totals(s["model_reaction"])[0] or {"error": "MOL_GRAPH_MISSING"}))(),
                      "esm_feature_dim": 1152, "reaction_feature_dim": 2048,
                      "provenance": "RECONSTRUCTED_FROM_STORED_ROWS_AND_MOL_GRAPHS"}
    stats["ws_ok"] += 1
    json.dump(d, open(fp, "w"), indent=1, sort_keys=True)

# refresh jsonl manifest shas (content changed)
lines = []
for fp in sorted(os.listdir(R1 + "/ACTUAL_INPUT_IDENTITIES_C.jsonl")) if False else []: pass
jl = [json.loads(x) for x in open(R1 + "/ACTUAL_INPUT_IDENTITIES_C.jsonl")]
for l in jl:
    p = l["new_manifest_file"]
    l["new_manifest_sha256"] = hashlib.sha256(open(p, "rb").read()).hexdigest()
with open(R1 + "/ACTUAL_INPUT_IDENTITIES_C.jsonl", "w") as f:
    for l in jl: f.write(json.dumps(l) + "\n")
json.dump({"stats": stats, "elapsed_s": round(time.time() - t0, 1)}, open(R1 + "/C_SHAPES_FIX_STATS.json", "w"), indent=1)
print(json.dumps(stats))
