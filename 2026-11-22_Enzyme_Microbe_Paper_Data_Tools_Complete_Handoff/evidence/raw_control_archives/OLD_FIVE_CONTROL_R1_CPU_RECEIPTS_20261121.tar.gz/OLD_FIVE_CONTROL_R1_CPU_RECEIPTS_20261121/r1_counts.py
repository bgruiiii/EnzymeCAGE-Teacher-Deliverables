#!/usr/bin/env python3
"""R1 §4: counts by UNIT — never mixing logical whole-step scoring counts,
underlying bounded16 model.forward batches, wrapper API attempts, successful
requests, model.evaluate calls, and GPU occupancy. Runtime counters that were
not instrumented are labeled SOURCE_DERIVED_EXPECTATION, not measured. Also
documents the GPU lock reality: each stage acquired/released OUT/gpu.lock
separately (four acquisitions), and the lock-source amendment timeline."""
import json, os, re, time

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
PLAN = json.load(open(O + "/CONTROL_EXECUTION_PLAN.json"))
REG = json.load(open(O + "/input/CONTROL_REQUESTS.json"))

def pool_sizes(ctx):
    return {s["step_id"]: len(s["pool_uids"]) for s in json.load(open(f"{O}/../five_model_complete_20261103/runtime/pool/UNIFIED_STEP_TABLE_{ctx}.json"))}
sizes = {}
for ctx in ("main", "delta15"): sizes.update(pool_sizes(ctx))

# B underlying forward batches: helper slices a step of n into ceil(n/16) batches per pass
b_fwd_expect = sum(((sizes[t["step_id"]] + 15) // 16) * 2 * 5 for t in PLAN["stageB_nc2_steps"])
b_logic = len(PLAN["stageB_nc2_steps"]) * 5 * 2  # 2190 logical whole-step-equivalent seed×condition scorings
b_ws_logic = 6 * 5 * 2
b_ws_fwd = 6 * 5 * 2  # whole-step = 1 batch each

C_stats = json.load(open(O + "/stageC/COVERAGE.json"))
vec_files = len([f for f in os.listdir(O + "/stageC/vectors") if f.endswith(".json")])
c_units = {"vector_files": vec_files, "seed_step_arm_records": vec_files * 5,
           "conditions_per_record": 4, "logical_fwd_calls_saved_in_stageC_COVERAGE": C_stats["forward_calls"],
           "underlying_batches_each_fwd_is_whole_step_batch1": True}

# A
A = json.load(open(O + "/stageA/STAGE_A_SUMMARY.json"))

# D
d1 = json.load(open(O + "/stageD/D1_real_calls_S02_S03.json"))
d2 = json.load(open(O + "/stageD/D2_chain_S02.json"))
d3 = json.load(open(O + "/stageD/D3_positive_control.json"))
api_attempts = len(d1) + 1 + 1
successful_requests = sum(1 for v in d1.values() if v["scoring_status"] == "OK") + (1 if d2["scoring_status"] == "OK" else 0) + (1 if d3["scoring_status"] == "OK" else 0)
# wrapper rt.forward_call_count counts SUCCESSFUL rt.predict REQUESTS (each internally runs
# 5 models x evaluate). D3 executed 5 model.evaluate calls inside its 1 successful request.
model_evaluates = sum(5 for x in (list(d1.values()) + [d2, d3]) if x.get("scoring_status") == "OK")

# GPU occupancy windows from log timestamps (UTC, from file mtimes + log stamps)
def span(logf):
    txt = open(logf, errors="ignore").read()
    m = re.findall(r"\[\s*(\d+\.\d)s\]", txt)
    st = os.stat(logf)
    return {"wall_seconds_observed_in_log_last_stamp": float(m[-1]) if m else None}
occ = {"stageA": span(O + "/logs/stage_a.log"), "stageB": span(O + "/logs/stage_b.log"),
       "stageC": span(O + "/logs/stage_c.log"), "stageD": span(O + "/logs/stage_d.log"),
       "stageD3": span(O + "/logs/stage_d3.log"),
       "note": "per-stage process wall windows (GPU-locked sections); not summed into a fake physical-second total because stages do not overlap"}

out = {
    "kind": "R1_COUNTS_BY_UNIT", "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "stageA_legacy600m": {"logical_whole_step_forwards": A["forward_calls"], "underlying_model_forward_batches": A["forward_calls"],
                          "unit": "whole-step pure batch = 1 batch per logical forward", "measured": "worker loop counter"},
    "stageB_new600m": {"logical_seed_condition_scorings": b_logic + b_ws_logic, "logical_matches_first_package": b_logic + b_ws_logic == 2250,
                       "underlying_model_forward_batches_bounded": b_fwd_expect,
                       "underlying_plus_wholestep60": b_fwd_expect + 60,
                       "reconciliation_to_reviewer_7600": "reviewer's 7600 = this card's 7540 (bounded) + 60 whole-step batches; unit-aligned, both SOURCE_DERIVED_EXPECTATION, not runtime counters",
                       "expectation": "SOURCE_DERIVED_EXPECTATION: ceil(n/16) micro-batches per logical pass at max_candidates=16 with frozen padding (helper c95_bounded_forward.forward_dataset); NOT a runtime counter",
                       "ws_layer_logical": b_ws_logic, "ws_layer_underlying": b_ws_fwd,
                       "warning": "2250 in first-package COVERAGE is a logical whole-step counter (2190 bounded passes + 60 whole-step); it must NOT be read as 2250 physical model.forward calls"},
    "stageC_enzgfm": c_units,
    "stageD_tool": {"wrapper_api_attempts": api_attempts, "successful_requests": successful_requests,
                    "model_evaluate_calls_under_successful_requests": model_evaluates,
                    "note": "first-package forward_call_count=1 counts the successful rt.predict REQUEST; each request loops the 5 seed models via model.evaluate",
                    "d1_two_typed_reactions": True, "d2_chain_scoring_missing_assets": True},
    "do_not_sum_across_units": True,
    "gpu_occupancy_windows": occ,
    "gpu_lock_reality": {
        "acquisitions": "OUT/gpu.lock was acquired and released SEPARATELY by each stage process (stageA, stageB, stageC, stageD, stageD3) — four/five independent acquisitions, not one lock held continuously across A..D",
        "first_package_claim_retracted": "the first-package plan/ledger wording 'one exclusive lock across all stages' was inaccurate; corrected here without modifying the original files",
        "lock_source_amendment_timeline": "worker/gpu_lock.py was amended after the START freeze (refuse-if-busy -> wait-until-release) and recorded in receipts/START_ENV_SOURCES.json amendments; the original time-narrative mismatch is kept as-is"},
}
json.dump(out, open(R1 + "/COUNTS_BY_UNIT.json", "w"), indent=1)
print("b under fwd expectation:", b_fwd_expect, "| b logical:", b_logic)
print(json.dumps(out["stageD_tool"], indent=1)[:400])
