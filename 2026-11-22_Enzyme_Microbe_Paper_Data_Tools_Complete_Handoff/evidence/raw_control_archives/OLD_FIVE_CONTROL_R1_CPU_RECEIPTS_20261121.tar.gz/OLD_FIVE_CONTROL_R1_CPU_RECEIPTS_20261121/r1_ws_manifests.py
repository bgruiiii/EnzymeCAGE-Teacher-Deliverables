#!/usr/bin/env python3
"""R1 §3 (WS layer): the first-package 6 whole-step A/B files hashed only
ctx/sid/sub-mask (descriptive). Rebuild explicit manifest bodies from the SAME
substitution material the bounded16 control used (identical arrays: global=
mean(0) + pocket=registered indices), record REAL byte SHAs, and keep the
first-package descriptive hash listed separately. RECONSTRUCTED_AFTER_RUN;
not claimed as runtime-saved."""
import hashlib, json, os, sys, time
import numpy as np

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
B = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
PKG = B + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, PKG + "/sources")
import r3_paths as P
sha_b = lambda bs: hashlib.sha256(bs).hexdigest()
arr_sha = lambda a: sha_b(np.ascontiguousarray(np.asarray(a)).tobytes())
PLAN = json.load(open(O + "/CONTROL_EXECUTION_PLAN.json"))
WS = PLAN["stageB_whole_step_layer_from_NC2B_goldshift"]
CACHE = B + "/runtime/extraction/cache_nodes"
receipts = {}
with open(B + "/runtime/extraction/NODE_RECEIPTS.jsonl") as f:
    for line in f:
        if line.strip():
            j = json.loads(line); receipts[j["seq_sha256"]] = j
corr_idx = {}
with open(P.CORR_JSONL) as f:
    for line in f:
        if line.strip():
            j = json.loads(line); corr_idx[j["UniprotID"]] = [int(x) for x in j["corrected_untrimmed_indices"]]
import pandas as pd
carrier_idx = {}
cdf = pd.read_parquet(P.CARRIER_PARQUET)
for r in cdf.itertuples(index=False):
    carrier_idx.setdefault(str(r.UniprotID), [int(x) for x in str(r.pocket_indices_1based).split(",") if x != ""])
lines = []
for t in WS:
    ctx, sid = t["ctx"], t["step_id"]
    s = {x["step_id"]: x for x in json.load(open(B + f"/runtime/pool/UNIFIED_STEP_TABLE_{ctx}.json"))}[sid]
    wf = O + f"/stageB/vectors_wholestep/{ctx}_{sid}.json"
    wrec = json.load(open(wf))
    bf = O + f"/stageB/inputs/{ctx}_{sid}.json"
    bman = json.load(open(bf))
    sub = {int(x[0]): x for x in bman["manifest_B"]["substituted"]}
    rows = []
    for i, (u, sh, au, sq) in enumerate(zip(s["pool_uids"], s["pool_shas"], s["asset_uids_new"], s["pool_seqs"])):
        e = {"i": i, "uid": u, "asset_uid": au, "seq_sha": sh, "substituted": i in sub}
        if i in sub:
            arr = np.load(f"{CACHE}/{sh}.npy")
            rc = receipts.get(sh)
            e["node_value_sha256"] = arr_sha(arr)
            e["receipt_value_match"] = bool(rc and e["node_value_sha256"] == rc["node_value_sha256"])
            e["sub_global"] = bool(sub[i][2]); e["sub_pocket"] = bool(sub[i][3])
            if sub[i][2]:
                g = np.ascontiguousarray(arr.mean(0), dtype=np.float32); e["global_component_sha256"] = arr_sha(g)
            if sub[i][3]:
                idxs = corr_idx.get(au) or carrier_idx.get(au)
                e["pocket_indices_source"] = "CORRECTED_JULY" if au in corr_idx else "CARRIER"
                if idxs:
                    pk = np.ascontiguousarray(arr[list(idxs)], dtype=np.float32)
                    e["pocket_component_sha256"] = arr_sha(pk); e["pocket_indices_n"] = len(idxs)
        rows.append(e)
    body = {"scope": "B_WS_layer", "ctx": ctx, "step_id": sid,
            "protocol": "WHOLE_STEP_PURE_BATCH (independent historical-control reproduction layer)",
            "model_reaction_sha256": hashlib.sha256(s["model_reaction"].encode()).hexdigest(),
            "model_key_sha256": s["model_key_sha256"], "rows": rows,
            "provenance": "RECONSTRUCTED_AFTER_RUN; same substitution material as the bounded16 records; NOT runtime-saved by the first package",
            "first_package_descriptive_identity_sha256": wrec["condition_metadata"]["A"]["input_identity_sha256"]}
    mf = f"{R1}/WS_manifests/{ctx}_{sid}.json"
    os.makedirs(f"{R1}/WS_manifests", exist_ok=True)
    json.dump(body, open(mf, "w"), indent=1, sort_keys=True)
    lines.append({"step": sid, "ctx": ctx, "manifest_file": mf, "manifest_sha256": sha_b(open(mf, "rb").read()),
                  "descriptive_hash_separate": body["first_package_descriptive_identity_sha256"],
                  "receipt_matches": sum(1 for r in rows if r.get("receipt_value_match"))})
json.dump(lines, open(R1 + "/WS_MANIFEST_RECORDS.json", "w"), indent=1)
print(json.dumps(lines, indent=1)[:700])
