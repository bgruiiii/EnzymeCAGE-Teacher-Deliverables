# 原输入/执行收据的边界（R1 收口，2026-11-21）

本页只陈述"哪些证据已闭合、哪些只有后验重建、哪些历史缺失且不可补造"。
一切以本卡实际文件为准；原始首包文件（首包 SHA `c346f622…`）逐字节保留，不回填、不改写。

## 1. 启动前收据缺失（保留，不倒写）

- 首包 `receipts/START_ENV_SOURCES.json` 自身 UTC = **11:03:27Z**，而首包日志显示
  stage A 于 **10:41:45Z**、stage B 于 **10:43:26Z** 已启动。因此 START 收据中的
  worker 源哈希与"冻结输入"登记对 A/B 的启动而言是**事后收据**，不是开工前冻结。
- `CHECKPOINT_REVERIFY_20261121.json`（25/25 checkpoint 完整 SHA 复验）由本卡在 ~10:15Z
  启动、约 10:2x 完成，时间上先于 A/B 阶段，但其身份仍是**复审窗口的复验**，
  R1 不把它表述为"11:03 前的原始 freeze"。
- `gpu_lock.py` 在 START 收据后被修订（refuse→wait 语义），当时已登记 amendment；
  修订时间叙述与本条并列留档，不追求"自洽的完美时间线"。

## 2. C 条件身份：原包是描述性哈希，真实身份=R1 后验重建

- 首包 C 记录 `condition_metadata.input_identity_sha256` 只哈希 `arm/ctx/step_id/n`
  （6 步 whole-step 层只哈希 `ctx/sid/sub-mask`）——**不能当作实际张量身份**。
- R1 用同一消费者链代码路径（R1Chains + E0 lane / NewArmIndexV3 override 材料）重建
  每条件清单正文（UID→route、序列 SHA、global/pocket/gvp 值摘要、dataset 实际
  padding/最大图/张量形状、split 子批形状），写入 `C_manifests/`、`WS_manifests/`，
  全部标 **RECONSTRUCTED_AFTER_RUN**。原描述哈希在清单中单列保留。
  - 重建不能证明当时 GPU 进程加载的字节与此完全相同——它证明的是同一代码路径、
    同一冻结池登记下这些值可确定性重现；运行时快照未留存即为 NOT_RETAINED。
- 首包 `stageC/COVERAGE.json` 的 `completed=0` 是写盘时序缺陷（赋值后未再写盘），
  采用版从 62 个完整向量体生成（310 个 seed×step×arm 记录）。

## 3. B 替换材料：本卡重核值全通过

- 991 条替换行的 node 数组**实际重读**：`sha256(ascontiguousarray(arr).tobytes())`
  与 `NODE_RECEIPTS.jsonl` 的 `node_value_sha256` **991/991 一致**（0 不匹配）。
- 991 条 global 分量（mean(0)→float32）与 640 条 pocket 分量（按登记有序索引切片，
  CORRECTED_JULY 261 / CARRIER 379）值摘要全部重算；219 个首包 manifest 哈希 100% 可复算。
- recipe 正文登记两种（esmc600m_verbatim_R1_esmc_bulk2 及 logits 变体）；
  索引来源文件（corrected jsonl / carrier parquet）SHA 写入 ORDERED_MAPPING_EVIDENCE.tsv。
- 未静默修正任何索引/科学特征；无节点数组缺失（node_missing=0）。

## 4. A 序列身份：35/35 全等

4 冻结案例池的每 UID 序列 SHA 用同一 p291 索引（CPU 只读）重算，与首包向量记录的
pool_shas 35/35 一致；池顺序与 reference 文件一致；参考文件/池源/config SHA 均已登记。

## 5. D 语义与 S03 范围

- 真实 predictor（SHA `b9877649…`，两节点拷贝同哈希）→ `model.evaluate()` →
  实际 base.py（SHA `abdfe787…`）L36-37 `pred=torch.sigmoid(pred)`（sigmoid_readout=False）。
  **trace=每seed概率；wrapper 聚合=五概率均值。** 首包把该 trace 命名 logit 并二次 sigmoid
  的错误已撤回（`D3_CORRECTED_PROBABILITY_APPENDIX.json/tsv`，60 UID 与主审表 0 不匹配）。
- v1 交付内 `scripts/frozen_test_replay.py` 只读冻结 pred 重放排序，**不证明原评估 forward 的
  batch 上下文**；config `batch_size=256` 仅是配置。原实际 batch/输入身份保持 **NOT_VERIFIED**，
  同 seed 最大差 0.1991 未归因（不新跑模型、不逆 logit 伪造）。
- 合同 S03=`BIOPATH150_013__S03__BSY-r00201`（31 候选）；首包 9 候选步降为附录。
  本卡对主审边界表 44/44 行对冻结登记独立验证通过；正确 S03 采用主审 attempt2 真实调用
  （18 评分/13 缺资产，10 项独立核对全 True，**不是完整 31 排名**）；attempt1 序列化失败保留。
  S02 反应资产缺失（DRFP+分子图）是真实边界，不补造、不换目标。
- D2 表述固定为：检索/构池/来源/C8 读取完成，**评分因资产缺失未完成**；
  SCNET 未配置 ≠ 生物学缺性状（分开记录）。

## 6. 计数单位（详见 COUNTS_BY_UNIT.json）

逻辑整步评分、底层 model.forward 批次数、wrapper API 尝试、成功请求、模型 evaluate、
GPU 占用窗口分别记账；B 物理批次 7540（bounded）+60（whole-step）=7600 与主审口径对齐，
均为 SOURCE_DERIVED_EXPECTATION，无运行时计数器即不称实测。GPU 锁为各阶段独立取得/释放。

## 7. 不可闭合项（保留）

- 原 8 COMMON 的旧准入正文：NOT_RETAINED_SUPERSEDED_IN_PLACE（任何实验无法补出）。
- 首包运行时的 GPU 侧 tensor 快照、真实 forward 计数器、wrapper 原响应 CI 正文：NOT_RETAINED。
- 首包 A/B 启动早于 START 收据：作为收据缺口保留，不重跑、不倒写。
