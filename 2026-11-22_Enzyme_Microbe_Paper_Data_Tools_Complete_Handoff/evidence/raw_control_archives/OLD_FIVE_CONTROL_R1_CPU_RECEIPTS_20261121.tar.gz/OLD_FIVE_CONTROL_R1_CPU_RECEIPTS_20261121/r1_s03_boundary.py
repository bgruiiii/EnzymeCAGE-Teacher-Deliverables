#!/usr/bin/env python3
"""R1 §2: contract S02/S03 CPU asset boundary adoption + attempt ledger.
Adopts the reviewer's CORRECT_D_TARGET_ASSET_BOUNDARY.tsv after THIS card
independently verifies every row against the frozen registry/step-table
(order, candidate SHA, model key); records node attempt2 files and the retained
attempt1 failure. No GPU, no ranker load."""
import csv, hashlib, json, time
from collections import Counter

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
R1E = R1 + "/evidence/OLD_FIVE_CONTROL_R1_REVIEW_EVIDENCE_20261121"
B = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()

REG = json.load(open(O + "/input/CONTROL_REQUESTS.json"))
pool = {s["step_id"]: s for s in json.load(open(B + "/runtime/pool/UNIFIED_STEP_TABLE_main.json"))}
tg = {t["step_id"]: t for t in REG["targets"]}
rows = list(csv.DictReader(open(R1E + "/CORRECT_D_TARGET_ASSET_BOUNDARY.tsv"), delimiter="\t"))
ver = []
for r in rows:
    p = pool[r["step_id"]]; t = tg[r["step_id"]]
    i = p["pool_uids"].index(r["uid"])
    ver.append(p["pool_shas"][i] == r["candidate_sha256"] and t["model_key_sha256"] == p["model_key_sha256"])
print("card-verified rows:", sum(ver), "/", len(rows))
cols = list(rows[0])
with open(R1 + "/D_TARGET_ASSET_BOUNDARY.tsv", "w") as f:
    f.write("\t".join(cols + ["card_verified_against_frozen_registry"]) + "\n")
    for r, v in zip(rows, ver):
        f.write("\t".join(r[k] for k in cols) + ("\tTrue" if v else "\tFalse") + "\n")

s02 = [r for r in rows if r["step_id"] == "BIOPATH150_001__S02__BSY-r00595"]
s03 = [r for r in rows if r["step_id"] == "BIOPATH150_013__S03__BSY-r00201"]
led = {"kind": "R1_S02_S03_ASSET_AND_ATTEMPT_LEDGER",
       "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
       "contract_steps": {
           "S02": {"step": "BIOPATH150_001__S02__BSY-r00595", "n": 13,
                   "enzyme_status_counts": dict(Counter(r["enzyme_status"] for r in s02)),
                   "reaction_assets": "MISSING (DRFP reaction fingerprint + molecule-conformation graph) — real 3B scoring for S02 cannot complete; boundary retained"},
           "S03": {"step": "BIOPATH150_013__S03__BSY-r00201", "n": 31,
                   "enzyme_status_counts": dict(Counter(r["enzyme_status"] for r in s03)),
                   "reaction_assets": "PRESENT"}},
       "cross_step_distinct_uids": len({r["uid"] for r in rows}),
       "cross_step_duplicates": sorted({r["uid"] for r in rows
                                        if len([x for x in rows if x["uid"] == r["uid"]]) > 1}),
       "overlap_rule": "reaction-level and enzyme-level reasons co-occur per row; 11+8=19 is a cross-step ASSOCIATION count, not a distinct-UID count; 44 distinct UIDs total",
       "reviewer_boundary_source": {"path": R1E + "/CORRECT_D_TARGET_ASSET_BOUNDARY.tsv", "sha256": sha(R1E + "/CORRECT_D_TARGET_ASSET_BOUNDARY.tsv"),
                                    "card_independent_verification": "44/44 rows: uid order, candidate_sha256, model_key vs frozen UNIFIED_STEP_TABLE_main.json + CONTROL_REQUESTS.json all match"},
       "correct_s03_real_call_adoption": {
           "attempt2_node_dir": O + "/review_correct_s03_20261121_attempt2",
           "attempt2_node_files": {f: sha(O + "/review_correct_s03_20261121_attempt2/" + f)
                                   for f in ["START.json", "RAW_CALL_RECEIPT.json", "CORRECT_S03_REAL_CALL.json"]},
           "packaged_real_call_sha256": sha(R1E + "/CORRECT_S03_REAL_CALL.json"),
           "node_vs_packaged": "semantic diff 0 fields; byte SHA differs only by serialization (node 573c9d94…, packaged 69af86b5…); disclosed, not backfilled",
           "outcome": "status OK; 18 scored; 13 ENZYME_ASSET_MISSING retained per UID; complete_all_candidates=False; 10/10 reviewer independent checks True; NEVER presented as full-31 ranking",
           "attempt1_failure_retained": {"dir": O + "/review_correct_s03_20261121",
                                         "START_json_sha256": sha(O + "/review_correct_s03_20261121/START.json"),
                                         "evidence_logs": ["CORRECT_S03_ATTEMPT1.stdout.txt", "CORRECT_S03_ATTEMPT1.stderr.txt"],
                                         "note": "asdict serialization error saved results incomplete; failure kept; both calls counted in the ledger"}},
       "misselected_first_package_step": {
           "step": "BIOPATH150_001__S03__BSY-r00596 (9 candidates)",
           "role": "appendix only; NOT contract S03; first-package records unmodified",
           "note": "registry fixes S03 = BIOPATH150_013__S03__BSY-r00201; correction completed CPU-only with reviewer's appended real call; no GPU rerun"},
       "no_gpu_no_ranker": True}
json.dump(led, open(R1 + "/S02_S03_ASSET_LEDGER.json", "w"), indent=1)
print("ledger written:", led["cross_step_distinct_uids"], "distinct;", json.dumps(led["contract_steps"]["S03"]["enzyme_status_counts"]))
