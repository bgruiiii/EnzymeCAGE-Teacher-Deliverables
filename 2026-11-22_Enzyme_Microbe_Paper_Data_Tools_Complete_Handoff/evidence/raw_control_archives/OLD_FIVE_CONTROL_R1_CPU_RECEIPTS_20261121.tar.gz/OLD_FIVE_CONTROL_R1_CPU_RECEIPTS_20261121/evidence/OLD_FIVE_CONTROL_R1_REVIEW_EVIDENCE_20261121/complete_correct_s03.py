#!/usr/bin/env python3
"""One already-authorized Stage D correction, original immutable 31-UID target.
No training, feature generation, source patch, target replacement or score reuse.
One idle existing GPU, existing task lock, native R3 + real v1 wrapper only.
"""
import hashlib
import json
import subprocess
from pathlib import Path

A = Path(__file__).resolve().parent
REMOTE = r'''
import os,sys,json,hashlib,time,fcntl,subprocess,math
from pathlib import Path
from dataclasses import asdict
O=Path('/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121')
R=O/'review_correct_s03_20261121_attempt2';R.mkdir(exist_ok=True)
out=R/'CORRECT_S03_REAL_CALL.json'
if out.exists():
 print('AUDIT_RESULT='+out.read_text());sys.exit(0)
fd=os.open(O/'gpu.lock',os.O_RDWR)
fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
def query(args):
 p=subprocess.run(['nvidia-smi']+args,capture_output=True,text=True,check=True);return p.stdout.strip()
gpu=query(['--query-gpu=index,uuid,memory.used,utilization.gpu','--format=csv,noheader'])
procs=query(['--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader'])
assert not procs,'foreign GPU compute process present; stop without model load'
assert '0, GPU-9d62b8ed-5672-c816-5d5c-6cf0186b192c' in gpu
repo=Path('/usrdata/EnzymeCAGE_data/EnzymeCAGE-master')
wrap=Path('/usrdata/EnzymeCAGE_data/workspaces/path_enzyme_microbe_code_review_20261110/review_payload/src_snapshot')
v1=repo/'HPC_Returned_Result_Summaries/enzymecage_v1_20260714'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for block in iter(lambda:f.read(8<<20),b''):h.update(block)
 return h.hexdigest()
registry=json.loads((O/'input/CONTROL_REQUESTS.json').read_text())
source_paths=[wrap/'wrapper/predictor.py',wrap/'wrapper/utils.py',wrap/'wrapper/asset_index.py',repo/'enzymecage/model.py',repo/'enzymecage/base.py',O/'input/standalone_tool/enzyme_host_tool/scoring_backends.py']
sources={str(p):sha(p) for p in source_paths}
checks={str(p):sha(p) for p in [v1/f'3b_ensemble/seed_{s}/best_model.pth' for s in range(40,45)]}
for s in range(40,45):assert checks[str(v1/f'3b_ensemble/seed_{s}/best_model.pth')]==registry['models']['legacy_esm2_3b'][str(s)]['sha256']
pool=O.parent/'five_model_complete_20261103/runtime/pool/UNIFIED_STEP_TABLE_main.json'
s=next(x for x in json.loads(pool.read_text()) if x['step_id']=='BIOPATH150_013__S03__BSY-r00201')
target=next(x for x in registry['targets'] if x['step_id']==s['step_id'])
assert len(s['pool_uids'])==31
assert s['model_key_sha256']==target['model_key_sha256'] and s['model_reaction']==target['model_reaction']
assert set(zip(s['pool_uids'],s['pool_shas']))=={(m['uid'],m['sha256']) for m in target['membership']}
start={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'gpu':gpu,'compute_apps_before':procs,'source_shas':sources,'checkpoint_shas':checks,'pool_sha256':sha(pool),'target':s['step_id'],'model_reaction':s['model_reaction'],'model_key_sha256':s['model_key_sha256'],'pool_uids':s['pool_uids'],'pool_shas':s['pool_shas'],'operation':'one missing Stage D target call; same original reviewed R3 and v1; no A/B/C rerun'}
(R/'START.json').write_text(json.dumps(start,indent=2))
sys.path.insert(0,str(O/'input/standalone_tool'))
from enzyme_host_tool.config import ScoringCfg
from enzyme_host_tool.scoring_backends import EnzymeCAGEWrapperBackend
cfg=ScoringCfg(backend='enzyme_cage_wrapper',wrapper_code_root=str(wrap),enzymecage_source_root=str(repo),weights_package_root=str(v1),top_k=10,return_ci=True)
backend=EnzymeCAGEWrapperBackend(cfg)
result=backend.score(s['model_reaction'],list(zip(s['pool_uids'],s['pool_shas'])))
rt=backend._rt;trace=rt.last_trace or {};valid=trace.get('valid_uids',[]);vs=trace.get('per_seed_scores',[])
# Persist actual returned objects before any assertion/report construction.
(R/'RAW_CALL_RECEIPT.json').write_text(json.dumps({'score_outcome':vars(result),'last_trace':trace,'start':start},default=vars,indent=2,allow_nan=False))
assert result.status=='OK' and len(vs)==5 and len(valid)==18 and len(result.not_evaluated)==13
assert all(len(v)==18 and all(math.isfinite(x) and 0<=x<=1 for x in v) for v in vs)
mean={u:sum(v[i] for v in vs)/5 for i,u in enumerate(valid)}
order=sorted(valid,key=lambda u:(-mean[u],u))
assert order==[x.uid for x in result.all_scored]
assert all(abs(mean[x.uid]-x.score)<1e-15 for x in result.all_scored)
assert trace['returned_uids']==order[:10]
assert set(valid)|{x.uid for x in result.not_evaluated}==set(s['pool_uids'])
assert not (set(valid)&{x.uid for x in result.not_evaluated})
record={'kind':'CORRECT_REGISTRY_S03_REAL_NATIVE_CALL_PARTIAL_ASSETS','start_receipt':start,'end_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'step_id':s['step_id'],'query_sent':s['model_reaction'],'model_key_sha256':s['model_key_sha256'],'pool_uids_original_order':s['pool_uids'],'pool_shas_original_order':s['pool_shas'],'requested':31,'scored':18,'not_evaluated':13,'status':result.status,'complete_all_candidates':False,'score_outcome':vars(result),'last_trace':trace,'trace_semantics':'PER_SEED_PROBABILITY_FROM_MODEL_EVALUATE; already sigmoid, do not apply again','seeds':[40,41,42,43,44],'mean_probability_by_uid':mean,'checks':{'original_target_and_registry_membership':True,'all31_accounted_no_overlap':True,'mean_probabilities_match_all_scores':True,'ranking_matches_minus_score_uid':True,'top10_matches_native_response':True},'api_successful_request_count':rt.forward_call_count,'model_evaluate_calls_source_derived':5,'physical_forward_counter':'not instrumented; source expects one batch per model','source_shas_end':{str(p):sha(p) for p in source_paths},'checkpoint_shas_end':{p:sha(p) for p in checks},'pool_sha256_end':sha(pool),'no_training_or_asset_generation':True,'engineering_repeat_note':'attempt1 completed forward but failed serialization at asdict(ScoreOutcome); no trace retained; failure log preserved, this is fixed-input engineering repeat, not numerical pass selection'}
assert record['source_shas_end']==sources and record['checkpoint_shas_end']==checks and record['pool_sha256_end']==start['pool_sha256']
out.write_text(json.dumps(record,default=vars,indent=2,allow_nan=False))
print('AUDIT_RESULT='+json.dumps(record,default=vars,allow_nan=False))
'''


def main():
    # Keep failed first attempt logs; never overwrite them with a successful run.
    for suffix in ['stderr.txt','stdout.txt']:
        previous=A/('CORRECT_S03_REAL_CALL.'+suffix)
        preserved=A/('CORRECT_S03_ATTEMPT1.'+suffix)
        if previous.exists() and not preserved.exists():
            preserved.write_bytes(previous.read_bytes())
    cmd = ['ssh','-i','/home/a/.ssh/chenyu_melo_ed25519','-o','IdentitiesOnly=yes',
           '-o','BatchMode=yes','-o','StrictHostKeyChecking=yes',
           '-o','UserKnownHostsFile=/mnt/c/Users/Melo/.ssh/known_hosts','-o','ConnectTimeout=15',
           '-p','21551','root@479dc4b9d7e548e59dad75fff43f7e9d71.gz14.chenyu.cn',
           'PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1 /usrdata/EnzymeCAGE_envs/enzymecage_py312/bin/python -B -']
    (A/'CORRECT_S03_REMOTE_WORKER.py').write_text(REMOTE)
    p=subprocess.run(cmd,input=REMOTE,text=True,capture_output=True,timeout=540)
    (A/'CORRECT_S03_REAL_CALL.stderr.txt').write_text(p.stderr)
    (A/'CORRECT_S03_REAL_CALL.stdout.txt').write_text(p.stdout)
    assert p.returncode==0,p.stderr[-2000:]
    row=next(x[len('AUDIT_RESULT='):] for x in p.stdout.splitlines() if x.startswith('AUDIT_RESULT='))
    record=json.loads(row)
    (A/'CORRECT_S03_REAL_CALL.json').write_text(json.dumps(record,indent=2)+'\n')
    print('correct_S03_requested',record['requested'],'scored',record['scored'],'missing',record['not_evaluated'],'checks',record['checks'])


if __name__=='__main__':
    main()
