# 原五组补测R1：仅CPU收据、D语义与指定步骤范围收口

主审证据包会放入原workspace的 `incoming/OLD_FIVE_CONTROL_R1_REVIEW_EVIDENCE_20261121.tar.gz`，旁置`.sha256`。核外SHA、安全解包至本卡独立OUT并核内部`SHA256SUMS`；先读包内`REVIEW_REPORT.md`和`CPU_CLOSEOUT_TASK.md`。这是补证包准备入口，不代表R1已经执行。

> **派发前主审已经补完的事项，不再重跑**：真实完整v1 CPU索引已核正确S03（31酶中18可用、13缺资产），且已补原生R3真实调用、完整5seed概率trace和10项独立核对。节点追加结果在 `old_five_numeric_control_20261121/review_correct_s03_20261121_attempt2/{START.json,RAW_CALL_RECEIPT.json,CORRECT_S03_REAL_CALL.json}`；第1次保存类型错误的失败记录保留于同根 `review_correct_s03_20261121/START.json`及主审日志。两次调用都计入账本，不能隐藏。下一步仍**仅CPU**，本卡第2节改为采用/核这份追加实物与主审完整CPU资产表，不能再次加载ranker或重复S03。D3正确概率表、C覆盖与B次数单位也已有主审CPU采用件。

2026-11-21。读主审报告后逐项执行。**不重新跑A/B/C、不启GPU、不加载ranker、不重训、不改旧成绩/阈值/资产/depending。** 首包留原样，新增OUT=`old_five_numeric_control_20261121/revision1_cpu_receipts_20261121`。

## 先读实物

原任务 `input/EXECUTE_CONTROL_TASK.md`、`input/CONTROL_REQUESTS.json`、本次首包 `worker/stage_a.py`至`stage_d3.py`、`receipts/{START_ENV_SOURCES,END_ENV_SOURCES,SCRIPTS_RAN}.json`、A至D日志。首包SHA：`c346f6221e61fcc33df92fac835f5c9fcbf481da938c9988e3e0a4751002234d`。

本地主审报告位于同一run根的 `04_Local_Review_Audits/OLD_FIVE_NUMERIC_CONTROL_AND_TOOL_FORWARD_REVIEW_20261121/REVIEW_REPORT.md`。关键发现已完整写在本卡，不要求节点凭空访问本机路径。只在已登记原工作区查证，不全盘搜、不读凭据；零SCNET提交。

## 1. 纠正D公式，不改原trace

真实wrapper predictor SHA=`b9877649deea4f929778331453a0f1f4eb73d72529e3f1c4b95d0a56c4ab82d3`调用`model.evaluate()`；实际EnzymeCAGE-master/enzymecage/base.py SHA=`abdfe7875a2b0c49032031dbc54915c435ed0bda895e0cce14c92be0be7421de`已sigmoid。**trace是每seed概率，聚合是五概率均值。** 不能再做sigmoid，也不能把wrapper叫mean(logit)。

从原D3 trace只用CPU生成修正附录，原字段可建立别名但保留旧包不改。逐UID核60候选均值/排序/TopK；CI可按原utils线性分位数重算，但原响应CI未保存，标“CPU重建，无法对原响应独立比较”。单独列“本次seed40 vs 原seed40 pred”和“本次5seed均值 vs 原seed40 pred”。主审复算中位差分别1.5990644054412237e-5和2.4004936781429158e-5；最大分别0.19909606173225403和0.49952836885182617。错误二次sigmoid的约0.5中位差撤回。不能只以单seed/ensemble解释同seed最大0.199差。

查原test_result的实际评估脚本/留存命令/batch输入上下文：config batch_size=256只证明配置，不自动证明实际batch。仅有配置则保持原因NOT_VERIFIED；不新跑模型、不逆logit伪造原始forward。

## 2. 正确固定S03的CPU资产边界

原registry已明确：
- S02=`BIOPATH150_001__S02__BSY-r00595`，13候选；
- S03=`BIOPATH150_013__S03__BSY-r00201`，31候选。

首包D测的`BIOPATH150_001__S03__BSY-r00596`（9候选）是其它步；保留为附录，不冒充合同S03，不再问用户是哪步。只用v1资产索引/原始文件读取进行**CPU preflight**，不initialize_runtime加载5模型：核目标原文/key、原池顺序和UID序列SHA；逐UID列REACTION_ASSET_MISSING、ENZYME_ASSET_MISSING、SEQUENCE_IDENTITY_CONFLICT、AVAILABLE。各原因可重叠，分别报关联条数、每步UID去重数和跨步去重数；不得把11+8直接叫19个不同UID。

D2保持“检索/构池/来源/性状读取完成，评分因资产缺失未完成”。SCNET未配置与生物学缺性状分开。D3是独立范围内正控，不能替代目标S02/S03。正确S03已由主审完成18可用酶真实调用，其余13保留缺资产，采用追加实物即可，不擅自启GPU。

## 3. 原输入证据：能回源多少写多少，不能补造历史

对实际消费者逐项登记源文件SHA、原config、25checkpoint当前完整SHA；明确这是复审时复验，不是11:03前新造的freeze。首包START=11:03:27Z，A日志10:41:45Z、B10:43:26Z，启动前收据缺失必须保留。

逐步重建实际条件输入清单，至少含：科学UID/sequence SHA、asset UID、目标query/key、route、实际PLM global/pocket与GVP tensor值摘要（含dtype/shape/字节序）、反应tensor/分子ID映射及中心身份、ordered residue/切片索引正文及来源。只对这组有界控制实际消费材料读证据，不全盘hash、不新提特征。能复用先前已审有序映射时给原文件+原SHA；不以UID/形状相同替代科学对应。

- B已有清单可沿用，但对实际load的node数组重新核值摘要，与receipt摘要算法对齐；核recipe及index来源，记录global/pocket分别替换。不要静默修正任何索引/科学特征。
- C原input_identity仅哈`arm/ctx/sid/n`，6步whole-step只哈ctx/sid/mask，不能作为实际tensor证明。新增清单正文和真实SHA，与原描述性hash分列；不冒充原运行时已保存的条件manifest。
- C补每条件dataset实际padding/最大图/shape。若由CPU重建而非原运行时保存，明确RECONSTRUCTED_AFTER_RUN；无法证实历史形状就NOT_RETAINED。
- 已经不在或无来源的文件/有序映射，按UID/step/condition记录具体缺口；不能拿现在正确值倒推当时正确。发现科学错配时停受影响项交主审，不改原共享资产。

## 4. 计数和收据

C向量62文件、310个seed×step×arm、4条件；原COVERAGE.json因最后赋值后未写盘而completed=0，采用版从实物生成。B10309关联=991替换至少一分量+3224未替换rescue+6094其它未替换；其中13条替换行pocket是RESCUE_R3D、global是FORMAL_JULY，说明“3237都完全不可替换”错误，按分量披露。

逻辑评分次数、wrapper API尝试、成功请求、模型evaluate、实际model.forward、GPU占用时长各列。B2250是逻辑整步计数，不能冒充底层forward；依原helper与原池重建预计7600，须核helper。D是4次API尝试、1成功请求、5模型evaluate。无运行时计数器则只报SOURCE_DERIVED_EXPECTATION，不伪实测。gpu锁实际按stage分别取得，不叫一把锁贯穿四阶段；原锁版本修订的时间叙述不一致如实留档。

START/END/脚本旧SHA正文不可改，cpu_reduce后改已有披露；R1自有开工/收工manifest独立登记。数据源若变化立即报差异，不回填“从头到尾没变”。原缺admission正文仍NOT_RETAINED。

## 交付与验收

`D3_CORRECTED_PROBABILITY_APPENDIX.json/tsv`、`D_TARGET_ASSET_BOUNDARY.tsv`、`ACTUAL_INPUT_IDENTITIES.jsonl`、`ORDERED_MAPPING_EVIDENCE.tsv`、`SOURCE_AND_RECEIPT_LIMITS.md`、`COUNTS_BY_UNIT.json`、`RESULTS_PLAIN_LANG.md`、脚本、输入/输出manifest与checks。checks将“复算正确”“真实输入身份已证”“历史收据缺失”“仅后验重建”分开，不能一盏全绿掩盖NOT_VERIFIED。

先解释重要发现及影响再给文件；不发师姐/黄老师、不push、不解禁原数值限制。没有新科学规则要用户裁决；真遇到序列/残基/recipe不一致，给原件并停该项，不为完成任务自改。
