#!/usr/bin/env python3
"""Read immutable returns; independently reduce vectors without worker imports/GPU."""
import csv
import hashlib
import json
import math
import statistics
import tarfile
from collections import Counter
from pathlib import Path

A = Path(__file__).resolve().parent
R = A.parent.parent
P = A / 'returned/OLD_FIVE_NUMERIC_CONTROL_AND_TOOL_FORWARD_20261121'
SEEDS = ['40', '41', '42', '43', '44']
REG = json.loads((P / 'input/CONTROL_REQUESTS.json').read_text())
PLAN = json.loads((P / 'CONTROL_EXECUTION_PLAN.json').read_text())
CHECKS = {}


def read(p):
    return json.loads(p.read_text())


def save(name, x):
    (A / name).write_text(json.dumps(x, indent=2, ensure_ascii=False, allow_nan=False) + '\n')


def check(name, ok):
    CHECKS[name] = bool(ok)
    assert ok, name


def sig(x):
    return 1 / (1 + math.exp(-x)) if x >= 0 else math.exp(x) / (1 + math.exp(x))


def evaluate(r, condition):
    n = len(r['pool_uids'])
    vs = r['conditions'][condition]
    check('five_seeds_lengths_finite', set(vs) == set(SEEDS) and all(
        len(v) == n and all(isinstance(x, (int, float)) and math.isfinite(x) for x in v)
        for v in vs.values()))
    ps = [sum(sig(vs[s][i]) for s in SEEDS) / 5 for i in range(n)]
    order = sorted(range(n), key=lambda i: (-ps[i], hashlib.sha256(r['pool_uids'][i].encode()).hexdigest()))
    ranks = {i: j + 1 for j, i in enumerate(order)}
    gold = [ranks[i] for i, g in enumerate(r['gold_flags']) if g]
    best = min(gold) if gold else None
    return {'p': ps, 'order': order, 'ranks': ranks, 'best_gold_rank': best,
            'mrr': 0 if best is None else 1 / best,
            'hits': {str(k): False if best is None else best <= k for k in [1, 3, 5, 10]}}


def compare(r, base, variant, mask=None):
    a, b = evaluate(r, base), evaluate(r, variant)
    n = len(r['pool_uids'])
    d = {'arm': r['arm'], 'ctx': r['ctx'], 'step_id': r['step_id'],
         'base': base, 'variant': variant, 'n': n,
         'max_logit': max(abs(r['conditions'][base][s][i] - r['conditions'][variant][s][i]) for s in SEEDS for i in range(n)),
         'max_prob': max(abs(x-y) for x, y in zip(a['p'], b['p'])),
         'changed_candidate_ranks': sum(a['ranks'][i] != b['ranks'][i] for i in range(n)),
         'changed_gold_ranks': sum(a['ranks'][i] != b['ranks'][i] for i, g in enumerate(r['gold_flags']) if g),
         'top1_changed': a['order'][0] != b['order'][0],
         'gold_rank_base': a['best_gold_rank'], 'gold_rank_variant': b['best_gold_rank'],
         'mrr_base': a['mrr'], 'mrr_variant': b['mrr'],
         'hit_changes': {k: a['hits'][k] != b['hits'][k] for k in a['hits']}}
    if mask:
        d['max_substituted_logit'] = max(abs(r['conditions'][base][s][i] - r['conditions'][variant][s][i]) for s in SEEDS for i in mask)
    return d


def aggregate(ds):
    return {'steps': len(ds), 'candidate_links': sum(d['n'] for d in ds),
            'max_logit': max(d['max_logit'] for d in ds), 'max_prob': max(d['max_prob'] for d in ds),
            'steps_any_rank_change': sum(d['changed_candidate_ranks'] > 0 for d in ds),
            'changed_candidate_ranks': sum(d['changed_candidate_ranks'] for d in ds),
            'changed_gold_ranks': sum(d['changed_gold_ranks'] for d in ds),
            'top1_changed_steps': sum(d['top1_changed'] for d in ds),
            'steps_best_gold_changed': sum(d['gold_rank_base'] != d['gold_rank_variant'] for d in ds),
            'mean_mrr_base': sum(d['mrr_base'] for d in ds) / len(ds),
            'mean_mrr_variant': sum(d['mrr_variant'] for d in ds) / len(ds),
            'hit_changed_steps': {k: sum(d['hit_changes'][k] for d in ds) for k in ['1','3','5','10']}}


def main():
    # Inputs and candidates are bound to pre-existing archive bodies, not score order.
    with tarfile.open(R / '03_HPC_Returned_Result_Summaries/RETURN_RESULTS_CURRENT95_FIVE_MODEL_COMPLETE_20261103.tar.gz') as t:
        pools = {}
        for ctx in ['main', 'delta15']:
            pools.update({(ctx, s['step_id']): s for s in json.load(t.extractfile(f'./POOL/UNIFIED_STEP_TABLE_{ctx}.json'))})
    targets = {(t['ctx'], t['step_id']): t for t in REG['targets']}
    records = {}
    for stage, folder in [('A','stageA/vectors'), ('B','stageB/vectors'), ('BW','stageB/vectors_wholestep'), ('C','stageC/vectors')]:
        records[stage] = [read(f) for f in sorted((P/folder).glob('*.json'))]
        for rec in records[stage]:
            check('reaction_key_hash', hashlib.sha256(rec['model_reaction'].encode()).hexdigest() == rec['model_key_sha256'])
            check('checkpoint_expected_hashes', rec['checkpoint_shas'] == {s: REG['models'][rec['arm']][s]['sha256'] for s in SEEDS})
            check('uid_unique', len(set(rec['pool_uids'])) == len(rec['pool_uids']))
            if stage != 'A':
                key = rec['ctx'], rec['step_id']
                old = pools[key]
                for field in ['pool_uids','pool_shas','gold_flags','model_key_sha256','model_reaction']:
                    check('frozen_pool_order_gold_query_' + field, old[field] == rec[field])
                check('registry_membership', set(zip(rec['pool_uids'],rec['pool_shas'])) == {(m['uid'],m['sha256']) for m in targets[key]['membership']})
            for c in rec['conditions']:
                evaluate(rec, c)
    check('coverage_A_4', len(records['A']) == 4)
    check('coverage_B_219', {(r['ctx'],r['step_id']) for r in records['B']} == {(r['ctx'],r['step_id']) for r in PLAN['stageB_nc2_steps']})
    check('coverage_BW_6', len(records['BW']) == 6)
    check('coverage_C_62', {(r['arm'],r['ctx'],r['step_id']) for r in records['C']} == {(arm,t['ctx'],t['step_id']) for arm in ['current_e0_enzgfm650m','new_enzgfm650m'] for t in PLAN['stageC_nc6_steps']})
    # Independently compare every retained reduction probability and rank.
    for stage, dest in [('A','stageA'),('B','stageB_bounded16'),('BW','stageB_wholestep'),('C','stageC')]:
        for rec in records[stage]:
            stem = ('stageA_' + rec['step_id'] if stage == 'A' else
                    rec['arm'] + '_' + rec['ctx'] + '_' + rec['step_id'] if stage == 'C' else rec['ctx'] + '_' + rec['step_id'])
            reduced = read(P/'reduced'/dest/(stem+'.json'))
            for c in rec['conditions']:
                v = evaluate(rec,c)
                check('retained_reductions_probabilities', max(abs(x-y) for x,y in zip(v['p'],reduced['conditions'][c]['probabilities'])) < 1e-15)
                check('retained_reductions_ranks', [rec['pool_uids'][i] for i in v['order']] == reduced['conditions'][c]['rank_uids'])
    arows=[]
    for rec in records['A']:
        for seed in SEEDS:
            for c in ['A','A_repeat1','A_repeat2','A_repeat3','A_repeat4']:
                arows.append({'case': rec['step_id'],'seed':seed,'repeat':c,
                              'vs_ref': max(abs(x-y) for x,y in zip(rec['conditions'][c][seed],rec['conditions']['REF_FROZEN'][seed])),
                              'vs_first':max(abs(x-y) for x,y in zip(rec['conditions'][c][seed],rec['conditions']['A'][seed]))})
    b=[]; classes=Counter(); row_sub_count=0
    identity_issues=[]
    for rec in records['B']:
        inp=read(P/'stageB/inputs'/(rec['ctx']+'_'+rec['step_id']+'.json'))
        mask=[row[0] for row in inp['manifest_B']['substituted']]
        row_sub_count += len(mask)
        classes.update(row['class'] for row in inp['manifest_A']['rows'])
        for c in ['A','B']:
            h=hashlib.sha256(json.dumps(inp['manifest_'+c],sort_keys=True).encode()).hexdigest()
            check('B_input_manifest_hashes', h == rec['condition_metadata'][c]['input_identity_sha256'])
        b.append(compare(rec,'A','B',mask))
    bw=[compare(rec,'A','B') for rec in records['BW']]
    cs={}
    for rec in records['C']:
        for condition in ['A_repeat','REVERSE','SPLIT']:
            ds=cs.setdefault(rec['arm']+'/'+condition,[]);ds.append(compare(rec,'A',condition))
    # Baseline-A comparison directly against the old independently retained raw.
    origraw={}
    with tarfile.open(R/'03_HPC_Returned_Result_Summaries/CURRENT95_FIVE_MODEL_AUDIT_EVIDENCE_20261104_032142.tar.gz') as t:
        for m in t:
            if m.isfile() and '/raw_logits_' in m.name and m.name.endswith('.json'):
                d=json.load(t.extractfile(m));origraw[d['arm'],d['ctx'],d['step_id']]=d
    baseline=[];baseline_ensembles=[]
    for rec in records['B']+records['C']:
        old=origraw[rec['arm'],rec['ctx'],rec['step_id']]
        check('original_raw_order',old['pool_uids']==rec['pool_uids'] and old['pool_shas']==rec['pool_shas'])
        for s in SEEDS:
            baseline.append({'arm':rec['arm'],'ctx':rec['ctx'],'step_id':rec['step_id'],'seed':s,
                             'max_delta':max(abs(a-b) for a,b in zip(rec['conditions']['A'][s],old['raw_logits'][s]))})
        tmp=dict(rec);tmp['conditions']={'A':old['raw_logits'],'REPLAY':rec['conditions']['A']}
        baseline_ensembles.append(compare(tmp,'A','REPLAY'))
    # D3 trace is evaluate() probability, not raw forward logits.
    live=read(A/'LIVE_WRAPPER_SOURCE_EVIDENCE.json')
    predictor=next(v['text'] for k,v in live['sources'].items() if k.endswith('/wrapper/predictor.py'))
    base=next(v['text'] for k,v in live['sources'].items() if k.endswith('/enzymecage/base.py'))
    check('wrapper_calls_evaluate', 'model.evaluate(loader' in predictor)
    check('evaluate_already_sigmoids', 'if not self.sigmoid_readout:' in base and 'pred = torch.sigmoid(pred)' in base)
    d3=read(P/'stageD/D3_positive_control.json')
    trace=d3['five_seed_full_vectors_logit']; uids=d3['pool_uids_order'];correct={u:sum(trace[u])/5 for u in uids}
    check('D3_probabilities_0_1',all(0 <= x <= 1 for v in trace.values() for x in v))
    check('D3_all60_formula',all(abs(v['score']-correct[v['uid']])<1e-15 for v in d3['full_scores']))
    order=sorted(uids,key=lambda u:(-correct[u],u))
    check('D3_order',order==[v['uid'] for v in d3['full_scores']])
    check('D3_top10',order[:10]==[v['uid'] for v in d3['response_topk']])
    rows=live['test_result']['rhea18369_rows'];old={r['UniprotID']:float(r['pred']) for r in rows}
    check('D3_original_rows_identity',set(old)==set(uids) and all(r['CANO_RXN_SMILES']==d3['reaction'] for r in rows))
    corrected=[]
    for u in uids:
        corrected.append({'uid':u,'seed40_probability':trace[u][0],'ensemble_probability':correct[u],
                          'original_seed40_pred':old[u],
                          'abs_seed40_delta':abs(trace[u][0]-old[u]),
                          'abs_ensemble_vs_seed40':abs(correct[u]-old[u]),
                          'incorrect_double_sigmoid':sum(sig(x) for x in trace[u])/5})
    # Duplicate typed failures are multi-cause records, not additional missing UIDs.
    d1=read(P/'stageD/D1_real_calls_S02_S03.json')
    d_summary={}
    for sid, d in d1.items():
        states=Counter(v['reason'] for v in d['not_evaluated'])
        d_summary[sid]={'pool':len(d['pool_uids']),'status':d['scoring_status'],'records_by_state':dict(states),
                        'unique_uids_by_state':{state:len({v['uid'] for v in d['not_evaluated'] if v['reason']==state}) for state in states}}
    result={'A':{'repeat_records':len(arows),'max_vs_reference':max(d['vs_ref'] for d in arows),
                 'failed_1e-5':sum(d['vs_ref']>1e-5 for d in arows),'max_vs_first':max(d['vs_first'] for d in arows)},
            'B':aggregate(b)|{'substituted_links':row_sub_count,'row_classes':dict(classes),
                             'steps_logit_over_0.05':sum(d['max_substituted_logit']>0.05 for d in b),
                             'worst_substituted_logit':max(d['max_substituted_logit'] for d in b)},
            'B_wholestep_6':aggregate(bw),
            'C':{k:aggregate(v) for k,v in cs.items()},
            'baseline':{},'D1':d_summary,
            'D3':{'n':len(corrected),'trace_semantics':'PER_SEED_PROBABILITY_FROM_EVALUATE',
                  'correct_formula':'mean(per_seed_probabilities); do not sigmoid twice',
                  'median_abs_ensemble_vs_original_seed40':statistics.median(d['abs_ensemble_vs_seed40'] for d in corrected),
                  'max_abs_ensemble_vs_original_seed40':max(d['abs_ensemble_vs_seed40'] for d in corrected),
                  'median_abs_seed40_vs_original_seed40':statistics.median(d['abs_seed40_delta'] for d in corrected),
                  'max_abs_seed40_vs_original_seed40':max(d['abs_seed40_delta'] for d in corrected),
                  'note':'single-seed vs ensemble is a different comparison; same-seed differences remain unresolved, cannot ascribe solely to that semantic difference'},
            'checks':CHECKS}
    for arm in {d['arm'] for d in baseline}:
        ds=[d for d in baseline if d['arm']==arm]
        es=[d for d in baseline_ensembles if d['arm']==arm]
        result['baseline'][arm]={'seed_step_records':len(ds),'over_1e-5':sum(d['max_delta']>1e-5 for d in ds),
                                 'max_delta':max(d['max_delta'] for d in ds),'probability_rank_comparison':aggregate(es)}
    save('INDEPENDENT_RECOMPUTATION.json',result)
    for name, data in [('A_REPEAT_RECORDS.json',arows),('B_STEP_EFFECTS.json',b),('B_WHOLESTEP_EFFECTS.json',bw),
                       ('C_STEP_EFFECTS.json',cs),('BASELINE_SEED_RECORDS.json',baseline),('D3_CORRECTED_PROBABILITIES.json',corrected)]:
        save(name,data)
    print(json.dumps(result,indent=2,ensure_ascii=False))


if __name__ == '__main__':
    main()
