#!/usr/bin/env python3
"""R1 §3 (B): re-verify every node array ACTUALLY loaded by the first-package
stage B worker, with the receipt digest algorithm (sha256 of
np.ascontiguousarray(arr).tobytes(), r3_genimpact_phase1.py L48). Emit
identities: per step A/B condition input manifest body sha (recomputed from the
saved input manifest text, aliasing the first-package recorded hashes), per
substituted row: seq_sha, cache file byte sha vs receipt node_value_sha256,
recomputed global component digest (mean(0) float32) and pocket slice digest
over the registered ordered indices, recipe + index source. No silent fix of
any index/feature."""
import hashlib, json, os, sys, time
import numpy as np
import pandas as pd

O = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/old_five_numeric_control_20261121"
R1 = O + "/revision1_cpu_receipts_20261121"
B = "/usrdata/EnzymeCAGE_data/workspaces/current95_ngpu32g_20261031/five_model_complete_20261103"
PKG = B + "/current95_five_model_complete_prep_20261103"
sys.path.insert(0, PKG + "/sources")
import r3_paths as P

sha_b = lambda bs: hashlib.sha256(bs).hexdigest()
arr_sha = lambda a: sha_b(np.ascontiguousarray(a).tobytes())
t0 = time.time()
POOL = B + "/runtime/pool"
CACHE = B + "/runtime/extraction/cache_nodes"
receipts = {}
with open(B + "/runtime/extraction/NODE_RECEIPTS.jsonl") as f:
    for line in f:
        if line.strip():
            j = json.loads(line); receipts[j["seq_sha256"]] = j
corr_idx = {}
with open(P.CORR_JSONL) as f:
    for line in f:
        if line.strip():
            j = json.loads(line); corr_idx[j["UniprotID"]] = [int(x) for x in j["corrected_untrimmed_indices"]]
carrier_idx = {}
cdf = pd.read_parquet(P.CARRIER_PARQUET)
for r in cdf.itertuples(index=False):
    carrier_idx.setdefault(str(r.UniprotID), [int(x) for x in str(r.pocket_indices_1based).split(",") if x != ""])

out = open(R1 + "/ACTUAL_INPUT_IDENTITIES_B.jsonl", "w")
stat = {"steps": 0, "sub_rows": 0, "cache_byte_sha_ok": 0, "cache_byte_sha_mismatch": 0,
        "receipt_value_sha_ok": 0, "receipt_value_sha_mismatch": 0, "manifest_sha_recomputed_ok": 0,
        "manifest_sha_mismatch": 0, "global_comp_ok": 0, "pocket_comp_ok": 0, "node_missing": 0,
        "recipe_distinct": set(), "index_sources": {}}
for ctx in ("main", "delta15"):
    steps = {s["step_id"]: s for s in json.load(open(f"{POOL}/UNIFIED_STEP_TABLE_{ctx}.json"))}
    for fp in sorted(os.listdir(R1 and O + "/stageB/inputs")):
        if not fp.startswith(ctx + "_"): continue
        sid = fp[len(ctx) + 1:-5]
        if sid not in steps: continue
        s = steps[sid]
        body = open(O + "/stageB/inputs/" + fp, "rb").read()
        man = json.loads(body)
        rec_fp = O + "/stageB/vectors/" + fp
        rec = json.load(open(rec_fp))
        manifest_sha_now = sha_b(body)
        recorded_A = rec["condition_metadata"]["A"]["input_identity_sha256"]
        recorded_B = rec["condition_metadata"]["B"]["input_identity_sha256"]
        # first package hashed canonical json dumps of the dicts, not the saved file body: recompute
        exp_A = hashlib.sha256(json.dumps(man["manifest_A"], sort_keys=True).encode()).hexdigest()
        exp_B = hashlib.sha256(json.dumps(man["manifest_B"], sort_keys=True).encode()).hexdigest()
        okA = exp_A == recorded_A; okB = exp_B == recorded_B
        stat["manifest_sha_recomputed_ok"] += int(okA and okB); stat["manifest_sha_mismatch"] += int(not (okA and okB))
        sub = {x[0]: x for x in man["manifest_B"].get("substituted", [])}
        rows_out = []
        for i_str, (_i, uid, sg, sp, nvs) in sorted(((k, v) for k, v in sub.items())):
            i = int(i_str); stat["sub_rows"] += 1
            sq = s["pool_seqs"][i]; sh = s["pool_shas"][i]; au = s["asset_uids_new"][i]
            cp = f"{CACHE}/{sh}.npy"
            e = {"step": sid, "ctx": ctx, "i": i, "uid": uid, "asset_uid": au, "seq_sha": sh}
            rc = receipts.get(sh)
            if rc:
                e["receipt_value_sha256"] = rc["node_value_sha256"]
                e["receipt_recipe"] = rc.get("recipe"); stat["recipe_distinct"].add(rc.get("recipe"))
                e["receipt_seqlen"] = rc.get("seqlen")
            if not os.path.exists(cp):
                e["node_cache_file_present"] = False; stat["node_missing"] += 1
            else:
                raw = open(cp, "rb").read()
                e["cache_file_byte_sha256"] = sha_b(raw)
                arr = np.load(cp)
                e["arr_byte_sha256"] = arr_sha(arr)
                e["arr_dtype_shape_order"] = [str(arr.dtype), list(arr.shape),
                                              "byteorder=" + arr.dtype.byteorder,
                                              "C_contig=" + str(arr.flags["C_CONTIGUOUS"])]
                if rc:
                    match = arr_sha(arr) == rc["node_value_sha256"]
                    e["receipt_arr_value_match"] = match
                    stat["receipt_value_sha_ok" if match else "receipt_value_sha_mismatch"] += 1
                if sg:
                    g = np.ascontiguousarray(arr.mean(0), dtype=np.float32)
                    e["global_component_sha256"] = arr_sha(g)
                    e["global_component_shape"] = list(g.shape); stat["global_comp_ok"] += 1
                if sp:
                    src = "CORRECTED_JULY_idx" if rc and True else ""
                    idxs = corr_idx.get(au) or carrier_idx.get(au)
                    e["pocket_indices_source"] = "CORRECTED_JULY" if au in corr_idx else "CARRIER"
                    stat["index_sources"][e["pocket_indices_source"]] = stat["index_sources"].get(e["pocket_indices_source"], 0) + 1
                    if idxs:
                        pk = np.ascontiguousarray(arr[list(idxs)], dtype=np.float32)
                        e["pocket_component_sha256"] = arr_sha(pk)
                        e["pocket_indices_n"] = len(idxs); e["pocket_component_shape"] = list(pk.shape)
                        stat["pocket_comp_ok"] += 1
                e["seqlen_check"] = (arr.shape[0] == len(sq) + 2)
            rows_out.append(e)
        line = {"scope": "B_bounded16", "ctx": ctx, "step_id": sid,
                "model_reaction_sha256": hashlib.sha256(s["model_reaction"].encode()).hexdigest(),
                "model_key_sha256": s["model_key_sha256"],
                "pool_order_sha256": hashlib.sha256(("|".join(s["pool_uids"]) + "|" + "|".join(s["pool_shas"])).encode()).hexdigest(),
                "input_manifest_file_sha256": manifest_sha_now,
                "first_package_A_hash_recomputable": okA, "first_package_B_hash_recomputable": okB,
                "provenance": "RECONSTRUCTED_AFTER_RUN (R1 CPU) — manifest text was saved by the run; array value digests recomputed now",
                "rows": rows_out}
        out.write(json.dumps(line) + "\n"); stat["steps"] += 1
out.close()
stat["recipe_distinct"] = sorted(stat["recipe_distinct"])
json.dump(stat, open(R1 + "/B_NODE_REVERIFY_STATS.json", "w"), indent=1)
print(json.dumps(stat, indent=1)[:900], f"({time.time()-t0:.0f}s)")
