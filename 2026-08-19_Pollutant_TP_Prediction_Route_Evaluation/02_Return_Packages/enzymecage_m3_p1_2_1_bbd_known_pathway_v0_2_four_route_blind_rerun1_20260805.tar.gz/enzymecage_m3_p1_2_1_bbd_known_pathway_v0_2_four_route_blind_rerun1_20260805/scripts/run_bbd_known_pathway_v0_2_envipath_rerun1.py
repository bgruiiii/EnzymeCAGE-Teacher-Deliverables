#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import time
from collections import Counter
from pathlib import Path

import requests
from rdkit import Chem, rdBase


TASK_ID = "enzymecage_m3_p1_2_1_bbd_known_pathway_v0_2_envipath_rerun1_20260805"
PAYLOAD_NAME = "enzymecage_m3_p1_2_1_bbd_known_pathway_v0_2_blind_payload_20260805.tar.gz"
PAYLOAD_SHA256 = "6224b2d9934acae3a8a39cadb39b3ab490ddbcb065d7d36e1805c2c2e7d5252c"
BLIND_REL = "enzymecage_m3_p1_2_1_bbd_known_pathway_v0_2_blind_payload_20260805/blind/KNOWN_PATHWAY_POLLUTANT_BLIND_PARENT_INPUTS_V0_2.csv"
BLIND_NAME = "KNOWN_PATHWAY_POLLUTANT_BLIND_PARENT_INPUTS_V0_2.csv"
BLIND_SHA256 = "6f811d4b40cfa8ee8c82af40178d85c6770959698e29e6ae202bc7cda21c769a"
EXPECTED_ROWS = 83
EXPECTED_COLUMNS = [
    "benchmark_case_id",
    "pollutant_name",
    "pollutant_category",
    "source_database",
    "source_family_public",
    "parent_comp_id",
    "parent_url",
    "parent_smiles",
    "input_note",
]

ENVIPATH_PRED_TOOL = "envipath_prediction"
ENVIPATH_LOOKUP_TOOL = "envipath_database_lookup"
ENVIPATH_BASE = "https://envipath.org/api/legacy/"
ENVIPATH_PACKAGE = "https://envipath.org/package/32de3cf4-e3e6-4168-956e-32fa5ddb0ce1"
ENVIPATH_SEARCH = "https://envipath.org/api/legacy/search"
ENVIPATH_UTIL = "https://envipath.org/api/legacy/util"
ENVIPATH_SETTING = "https://envipath.org/setting/a0fbc3d8-ca45-44f1-9c3c-80d8531ffe25"
ENVIPATH_SETTING_NAME = "Global Setting - BBD Rules"


def utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_path(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_text(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def write_json(path: Path, obj):
    write_text(path, json.dumps(obj, sort_keys=True, indent=2) + "\n")


def write_jsonl(path: Path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")


def safe_error(text, limit=1200):
    if text is None:
        return None
    sanitized = str(text)
    password = os.environ.get("ENVIPATH_PASSWORD")
    username = os.environ.get("ENVIPATH_USERNAME")
    if password:
        sanitized = sanitized.replace(password, "[REDACTED_PASSWORD]")
    if username:
        sanitized = sanitized.replace(username, "[REDACTED_USERNAME]")
    return sanitized[:limit]


def file_identity(path: Path):
    return {
        "path": str(path),
        "present": path.exists(),
        "sha256": sha256_path(path) if path.exists() else None,
        "bytes": path.stat().st_size if path.exists() else None,
    }


def canonical_and_key(smiles: str):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"RDKit could not parse SMILES: {smiles}")
    return Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True), Chem.MolToInchiKey(mol)


def load_blind(blind_csv: Path):
    if sha256_path(blind_csv) != BLIND_SHA256:
        raise RuntimeError("blind CSV sha256 mismatch")
    with blind_csv.open(newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != EXPECTED_COLUMNS:
            raise RuntimeError(f"blind CSV columns mismatch: {reader.fieldnames}")
        rows = list(reader)
    if len(rows) != EXPECTED_ROWS:
        raise RuntimeError(f"blind CSV row count {len(rows)} != {EXPECTED_ROWS}")
    return rows


def make_prediction_row(row, rank, raw_smiles, can, inchikey, raw_ref, raw):
    return {
        "benchmark_case_id": row["benchmark_case_id"],
        "tool_id": ENVIPATH_PRED_TOOL,
        "tool_version": f"enviPath legacy API setting:{ENVIPATH_SETTING}",
        "run_id": TASK_ID,
        "prediction_rank": rank,
        "parent_smiles": row["parent_smiles"],
        "predicted_product_smiles_original": raw_smiles,
        "predicted_product_smiles_canonical": can,
        "predicted_product_inchikey": inchikey,
        "raw_output_ref": raw_ref,
        "normalization_status": "ok",
        "raw_confidence": raw.get("probability"),
        "multi_generation_probability": raw.get("multiGenProbability"),
        "rule_name": raw.get("rule_name"),
        "rule_url": raw.get("rule_url"),
        "known_pathway_lookup_layer_separate": True,
    }


def extract_first_gen_predictions(api_json):
    nodes = {node.get("id"): node for node in api_json.get("nodes", []) if isinstance(node, dict)}
    products = []
    for edge in api_json.get("edges", []) or []:
        if edge.get("from") != 0:
            continue
        rule = edge.get("rule") if isinstance(edge.get("rule"), dict) else {}
        for to_id in edge.get("to", []) or []:
            node = nodes.get(to_id, {})
            smiles = node.get("smiles")
            if smiles:
                products.append({
                    "smiles": smiles,
                    "probability": edge.get("probability"),
                    "multiGenProbability": edge.get("multiGenProbability"),
                    "rule_name": rule.get("name"),
                    "rule_url": rule.get("url"),
                })
    return products


def make_dirs(return_root: Path):
    if return_root.exists():
        raise FileExistsError("M3_P1_2_1_BBD_V0_2_ENVIPATH_RERUN1_BLOCKED_OUTPUT_PATH_EXISTS")
    for rel in [
        "input",
        "predictions/envipath_prediction/raw/one_step_prediction",
        "predictions/envipath_prediction/logs",
        "envipath_database_lookup/raw/database_search",
        "envipath_database_lookup/logs",
        "metadata",
        "logs",
        "reports",
        "scripts",
    ]:
        (return_root / rel).mkdir(parents=True, exist_ok=False)


def get_envipath_python_identity():
    identity = {"importable": False, "version": None, "path": None}
    candidate = Path("/tmp/envipath_direct_pilot_20260805_venv/lib/python3.12/site-packages")
    if candidate.exists():
        sys.path.insert(0, str(candidate))
    try:
        import enviPath_python
        identity["importable"] = True
        identity["path"] = getattr(enviPath_python, "__file__", None)
        try:
            from enviPath_python.__version__ import __version__
            identity["version"] = __version__
        except Exception:
            identity["version"] = getattr(enviPath_python, "__version__", "unknown")
    except Exception as exc:
        identity["error_type"] = type(exc).__name__
    return identity


def login_session():
    username = os.environ.get("ENVIPATH_USERNAME")
    password = os.environ.get("ENVIPATH_PASSWORD")
    if not username or not password:
        raise RuntimeError("ENVIPATH_USERNAME/ENVIPATH_PASSWORD missing")
    session = requests.Session()
    payload = {
        "hiddenMethod": "login",
        "loginusername": username,
        "loginpassword": password,
    }
    response = session.post(ENVIPATH_BASE, data=payload, headers={"Accept": "application/json"}, timeout=60)
    if response.status_code >= 400:
        raise RuntimeError(f"login failed with HTTP {response.status_code}: {safe_error(response.text)}")
    return session, response.status_code


def write_summary(path: Path, rows):
    fields = ["benchmark_case_id", "pollutant_name", "parent_comp_id", "route", "case_status", "raw_count", "normalized_count", "raw_output_ref", "error_message_sanitized"]
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def run_envipath(return_root: Path, rows, delay: float):
    started = utc_now()
    session, login_status = login_session()
    request_count = 1
    pred_root = return_root / "predictions" / ENVIPATH_PRED_TOOL
    lookup_root = return_root / "envipath_database_lookup"

    whoami_status = None
    try:
        who = session.get(ENVIPATH_BASE + "user", params={"whoami": "true"}, headers={"Accept": "application/json"}, timeout=30)
        request_count += 1
        whoami_status = who.status_code
        write_json(return_root / "metadata" / "WHOAMI_STATUS.json", {"http_status": who.status_code, "success": who.status_code == 200, "secret_fields_written": False})
    except Exception as exc:
        write_json(return_root / "metadata" / "WHOAMI_STATUS.json", {"success": False, "error_message_sanitized": safe_error(exc), "secret_fields_written": False})

    pred_records = []
    lookup_records = []
    pred_summaries = []
    lookup_summaries = []
    pred_logs = []
    lookup_logs = []

    for index, row in enumerate(rows, start=1):
        case_id = row["benchmark_case_id"]
        params = {"method": "defaultSmiles", "packages[]": [ENVIPATH_PACKAGE], "search": row["parent_smiles"]}
        search_dir = lookup_root / "raw" / "database_search" / case_id
        search_dir.mkdir(parents=True, exist_ok=True)
        try:
            resp = session.get(ENVIPATH_SEARCH, params=params, headers={"Accept": "application/json"}, timeout=60)
            request_count += 1
            try:
                data = resp.json()
            except Exception:
                data = None
            raw_payload = {
                "case_id": case_id,
                "pollutant_name": row["pollutant_name"],
                "request": {"method": "GET", "url": ENVIPATH_SEARCH, "params": params},
                "http_status": resp.status_code,
                "response_kind": "json" if data is not None else "text",
                "json": data,
                "text_prefix": resp.text[:1000] if data is None else "",
                "error_message_sanitized": "" if resp.status_code == 200 else safe_error(resp.text),
            }
            write_json(search_dir / "raw_response.json", raw_payload)
            status = "ok" if resp.status_code == 200 else ("login_required" if resp.status_code in {401, 403} else "server_error")
            data_dict = data if isinstance(data, dict) else {}
            lookup_record = {
                "benchmark_case_id": case_id,
                "tool_id": ENVIPATH_LOOKUP_TOOL,
                "run_id": TASK_ID,
                "layer": "database_lookup",
                "parent_smiles": row["parent_smiles"],
                "lookup_status": status,
                "matched_compound_count": len(data_dict.get("compound", [])),
                "matched_pathway_count": len(data_dict.get("pathway", [])),
                "matched_reaction_count": len(data_dict.get("reaction", [])),
                "packages_seen": [ENVIPATH_PACKAGE] if status == "ok" else [],
                "raw_output_ref": f"envipath_database_lookup/raw/database_search/{case_id}/raw_response.json",
                "error_message_sanitized": raw_payload["error_message_sanitized"],
            }
        except Exception as exc:
            status = "client_error"
            lookup_record = {
                "benchmark_case_id": case_id,
                "tool_id": ENVIPATH_LOOKUP_TOOL,
                "run_id": TASK_ID,
                "layer": "database_lookup",
                "parent_smiles": row["parent_smiles"],
                "lookup_status": status,
                "matched_compound_count": 0,
                "matched_pathway_count": 0,
                "matched_reaction_count": 0,
                "packages_seen": [],
                "raw_output_ref": f"envipath_database_lookup/raw/database_search/{case_id}/raw_response.json",
                "error_message_sanitized": safe_error(exc),
            }
            write_json(search_dir / "raw_response.json", {"case_id": case_id, "error_message_sanitized": safe_error(exc)})
        lookup_records.append(lookup_record)
        lookup_summaries.append({
            "benchmark_case_id": case_id,
            "pollutant_name": row["pollutant_name"],
            "parent_comp_id": row["parent_comp_id"],
            "route": ENVIPATH_LOOKUP_TOOL,
            "case_status": status,
            "raw_count": lookup_record["matched_compound_count"] + lookup_record["matched_pathway_count"] + lookup_record["matched_reaction_count"],
            "normalized_count": 1,
            "raw_output_ref": lookup_record["raw_output_ref"],
            "error_message_sanitized": lookup_record["error_message_sanitized"],
        })
        lookup_logs.append(json.dumps({"route": ENVIPATH_LOOKUP_TOOL, "index": index, "case_id": case_id, "status": status}))
        time.sleep(delay)

        pred_dir = pred_root / "raw" / "one_step_prediction" / case_id
        pred_dir.mkdir(parents=True, exist_ok=True)
        form = {"hiddenMethod": "predict", "smiles": row["parent_smiles"], "settingUri": ENVIPATH_SETTING}
        try:
            resp = session.post(ENVIPATH_UTIL, data=form, headers={"Accept": "application/json"}, timeout=90)
            request_count += 1
            try:
                data = resp.json()
            except Exception:
                data = None
            raw_payload = {
                "case_id": case_id,
                "pollutant_name": row["pollutant_name"],
                "request": {"method": "POST", "url": ENVIPATH_UTIL, "form_fields": list(form.keys()), "settingUri": ENVIPATH_SETTING},
                "http_status": resp.status_code,
                "response_kind": "json" if data is not None else "text",
                "json": data,
                "text_prefix": resp.text[:1000] if data is None else "",
                "error_message_sanitized": "" if resp.status_code == 200 else safe_error(resp.text),
            }
            write_json(pred_dir / "raw_response.json", raw_payload)
            raw_products = extract_first_gen_predictions(data or {}) if resp.status_code == 200 else []
            seen = set()
            case_preds = []
            for raw in raw_products:
                try:
                    can, key = canonical_and_key(raw["smiles"])
                except Exception:
                    continue
                if key in seen:
                    continue
                seen.add(key)
                case_preds.append(make_prediction_row(
                    row,
                    len(case_preds) + 1,
                    raw["smiles"],
                    can,
                    key,
                    f"predictions/{ENVIPATH_PRED_TOOL}/raw/one_step_prediction/{case_id}/raw_response.json",
                    raw,
                ))
                if len(case_preds) == 10:
                    break
            status = "ok" if case_preds else ("login_required" if resp.status_code in {401, 403} else ("tool_error" if resp.status_code != 200 else "no_prediction"))
            error_message = raw_payload["error_message_sanitized"]
        except Exception as exc:
            raw_products = []
            case_preds = []
            status = "client_error"
            error_message = safe_error(exc)
            write_json(pred_dir / "raw_response.json", {"case_id": case_id, "error_message_sanitized": error_message})
        pred_records.extend(case_preds)
        pred_summaries.append({
            "benchmark_case_id": case_id,
            "pollutant_name": row["pollutant_name"],
            "parent_comp_id": row["parent_comp_id"],
            "route": ENVIPATH_PRED_TOOL,
            "case_status": status,
            "raw_count": len(raw_products),
            "normalized_count": len(case_preds),
            "raw_output_ref": f"predictions/{ENVIPATH_PRED_TOOL}/raw/one_step_prediction/{case_id}/raw_response.json",
            "error_message_sanitized": error_message,
        })
        pred_logs.append(json.dumps({"route": ENVIPATH_PRED_TOOL, "index": index, "case_id": case_id, "status": status, "normalized": len(case_preds)}))
        print(json.dumps({"index": index, "case_id": case_id, "lookup_status": lookup_summaries[-1]["case_status"], "prediction_status": status, "prediction_rows": len(case_preds)}), flush=True)
        time.sleep(delay)

    pred_counts = Counter(row["case_status"] for row in pred_summaries)
    lookup_counts = Counter(row["case_status"] for row in lookup_summaries)
    pred_token = "M3_P1_2_1_BBD_V0_2_ENVIPATH_PREDICTION_RERUN1_PASS" if pred_counts and set(pred_counts) <= {"ok", "no_prediction"} else "M3_P1_2_1_BBD_V0_2_ENVIPATH_PREDICTION_RERUN1_PARTIAL_FAIL_CLOSED"
    lookup_token = "M3_P1_2_1_BBD_V0_2_ENVIPATH_LOOKUP_RERUN1_PASS" if lookup_counts and set(lookup_counts) <= {"ok", "no_result"} else "M3_P1_2_1_BBD_V0_2_ENVIPATH_LOOKUP_RERUN1_PARTIAL_FAIL_CLOSED"

    write_jsonl(pred_root / "PREDICTIONS_NORMALIZED.jsonl", pred_records)
    write_jsonl(lookup_root / "ENVIPATH_DATABASE_LOOKUP_RESULTS.jsonl", lookup_records)
    write_summary(pred_root / "CASE_RUN_SUMMARY.csv", pred_summaries)
    write_summary(lookup_root / "ENVIPATH_DATABASE_LOOKUP_SUMMARY.csv", lookup_summaries)
    write_text(pred_root / "logs" / "execution.log", "\n".join(pred_logs) + "\n")
    write_text(lookup_root / "logs" / "execution.log", "\n".join(lookup_logs) + "\n")

    common = {
        "task_id": TASK_ID,
        "case_count": len(rows),
        "blind_file_read": True,
        "restricted_answer_key_read": False,
        "account_envvars_present": True,
        "login_mode": "account_login_success",
        "login_http_status": login_status,
        "whoami_http_status": whoami_status,
        "secret_fields_written": False,
        "remote_request_count": request_count,
        "prediction_setting_id": ENVIPATH_SETTING,
        "prediction_setting_name": ENVIPATH_SETTING_NAME,
        "eawag_bbd_package": ENVIPATH_PACKAGE,
        "enviPath_python_identity": get_envipath_python_identity(),
        "runtime_environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "rdkit": rdBase.rdkitVersion,
            "requests": requests.__version__,
        },
        "start_time_utc": started,
        "end_time_utc": utc_now(),
    }
    pred_meta = {
        **common,
        "tool_id": ENVIPATH_PRED_TOOL,
        "tool_display_name": "enviPath Global Setting - BBD Rules one-step prediction",
        "status_token": pred_token,
        "failure_stage": None if "PASS" in pred_token else "per_case_remote_request_or_normalization",
        "normalized_prediction_rows": len(pred_records),
        "case_status_counts": dict(pred_counts),
    }
    lookup_meta = {
        **common,
        "tool_id": ENVIPATH_LOOKUP_TOOL,
        "tool_display_name": "enviPath database lookup / direct search",
        "status_token": lookup_token,
        "failure_stage": None if "PASS" in lookup_token else "per_case_remote_request_or_normalization",
        "lookup_result_rows": len(lookup_records),
        "case_status_counts": dict(lookup_counts),
        "known_pathway_lookup_coverage": {
            "case_count": len(rows),
            "ok_case_count": lookup_counts.get("ok", 0),
            "compound_hit_case_count": sum(1 for r in lookup_records if r["matched_compound_count"] > 0),
            "pathway_hit_case_count": sum(1 for r in lookup_records if r["matched_pathway_count"] > 0),
            "reaction_hit_case_count": sum(1 for r in lookup_records if r["matched_reaction_count"] > 0),
        },
    }
    write_json(pred_root / "TOOL_RUN_METADATA.json", pred_meta)
    write_json(lookup_root / "TOOL_RUN_METADATA.json", lookup_meta)
    return pred_meta, lookup_meta


def make_manifest(return_root: Path):
    manifest = return_root / "MANIFEST.sha256"
    rows = []
    for path in sorted(p for p in return_root.rglob("*") if p.is_file() and p != manifest):
        rows.append(f"{sha256_path(path)}  {path.relative_to(return_root)}")
    manifest.write_text("\n".join(rows) + "\n")


def make_archive_and_identity(return_root: Path, payload_identity, final_status: str):
    archive = return_root.with_suffix(".tar.gz")
    with tarfile.open(archive, "w:gz") as tar:
        tar.add(return_root, arcname=return_root.name)
    identity = {
        "return_dir": str(return_root),
        "archive_path": str(archive),
        "archive_sha256": sha256_path(archive),
        "archive_bytes": archive.stat().st_size,
        "created_utc": utc_now(),
        "task_id": TASK_ID,
        "input_payload_path": payload_identity["path"],
        "input_payload_sha256": payload_identity["sha256"],
        "expected_payload_sha256": PAYLOAD_SHA256,
        "blind_csv_sha256": BLIND_SHA256,
        "final_status": final_status,
        "restricted_answer_key_read": False,
        "secret_fields_written": False,
    }
    identity_path = archive.with_name(archive.name + ".identity.txt")
    identity_path.write_text("\n".join(f"{k}={v}" for k, v in identity.items()) + "\n")
    return archive, identity_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default="/root/projects/EnzymeCAGE-master")
    parser.add_argument("--payload", default="/root/projects/EnzymeCAGE-master/HPC_Inputs/" + PAYLOAD_NAME)
    parser.add_argument("--env-file", default="/root/projects/EnzymeCAGE-master/HPC_Inputs/envipath_account_env.local.sh")
    parser.add_argument("--delay", type=float, default=2.0)
    args = parser.parse_args()

    project_root = Path(args.project_root)
    payload = Path(args.payload)
    payload_identity = file_identity(payload)
    if payload_identity["sha256"] != PAYLOAD_SHA256:
        raise RuntimeError(f"payload sha256 mismatch: {payload_identity['sha256']}")

    payload_root = Path("/tmp") / f"{TASK_ID}_payload_{int(time.time())}"
    payload_root.mkdir(parents=True, exist_ok=False)
    subprocess.run(["tar", "-xzf", str(payload), "-C", str(payload_root)], check=True)
    blind_csv = payload_root / BLIND_REL
    rows = load_blind(blind_csv)

    return_root = project_root / "HPC_Returned_Result_Summaries" / TASK_ID
    make_dirs(return_root)
    shutil.copy2(blind_csv, return_root / "input" / BLIND_NAME)
    shutil.copy2(Path(__file__).resolve(), return_root / "scripts" / Path(__file__).name)
    write_json(return_root / "input" / "PAYLOAD_AND_BLIND_IDENTITY.json", {
        "payload": payload_identity,
        "blind_csv": file_identity(blind_csv),
        "allowed_blind_csv_read": str(blind_csv),
        "restricted_answer_key_read": False,
        "env_file_used": str(Path(args.env_file)),
        "env_file_copied_to_return_package": False,
    })
    write_text(return_root / "logs" / "forbidden_sources_audit.log", "restricted_answer_key_read=false\nscoring_performed=false\nonly_blind_parent_inputs_used_for_cases=true\nsecret_fields_written=false\n")

    pred_meta, lookup_meta = run_envipath(return_root, rows, args.delay)
    final_status = "M3_P1_2_1_BBD_V0_2_ENVIPATH_RERUN1_PASS" if "PASS" in pred_meta["status_token"] and "PASS" in lookup_meta["status_token"] else "M3_P1_2_1_BBD_V0_2_ENVIPATH_RERUN1_PARTIAL_FAIL_CLOSED"
    write_json(return_root / "reports" / "ENVIPATH_RERUN1_REPORT.json", {
        "task_id": TASK_ID,
        "final_status": final_status,
        "case_count": len(rows),
        "blind_file_read": True,
        "restricted_answer_key_read": False,
        "scoring_performed": False,
        "prediction_accuracy_includes_database_lookup": False,
        "secret_fields_written": False,
        "routes": [pred_meta, lookup_meta],
    })
    write_text(return_root / "RUN_STATUS.txt", final_status + "\n")
    write_text(return_root / "FINAL_STATUS.txt", final_status + "\n")
    make_manifest(return_root)
    archive, identity_path = make_archive_and_identity(return_root, payload_identity, final_status)
    print(json.dumps({"return_dir": str(return_root), "archive": str(archive), "identity": str(identity_path), "final_status": final_status}, sort_keys=True, indent=2))


if __name__ == "__main__":
    raise SystemExit(main())
