#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import time
from collections import Counter
from pathlib import Path
from types import SimpleNamespace

import requests
from rdkit import Chem, rdBase


TASK_ID = "enzymecage_m3_p1_2_1_bbd_known_pathway_v0_2_four_route_blind_20260805"
PAYLOAD_NAME = "enzymecage_m3_p1_2_1_bbd_known_pathway_v0_2_blind_payload_20260805.tar.gz"
PAYLOAD_SHA256 = "6224b2d9934acae3a8a39cadb39b3ab490ddbcb065d7d36e1805c2c2e7d5252c"
BLIND_REL = "enzymecage_m3_p1_2_1_bbd_known_pathway_v0_2_blind_payload_20260805/blind/KNOWN_PATHWAY_POLLUTANT_BLIND_PARENT_INPUTS_V0_2.csv"
BLIND_NAME = "KNOWN_PATHWAY_POLLUTANT_BLIND_PARENT_INPUTS_V0_2.csv"
BLIND_SHA256 = "6f811d4b40cfa8ee8c82af40178d85c6770959698e29e6ae202bc7cda21c769a"
EXPECTED_ROWS = 83
EXPECTED_COLUMNS = [
    "benchmark_case_id",
    "pollutant_name",
    "pollutant_category",
    "source_database",
    "source_family_public",
    "parent_comp_id",
    "parent_url",
    "parent_smiles",
    "input_note",
]

BIOTRANSFORMER_TOOL = "biotransformer_envmicro"
ENVIFORMER_TOOL = "enviformer_latest"
ENVIPATH_PRED_TOOL = "envipath_prediction"
ENVIPATH_LOOKUP_TOOL = "envipath_database_lookup"

BIOTRANSFORMER_COMMIT = "7149f7ec6b2f32f9f789bab53aa4a71db49e59e2"
ENVIFORMER_COMMIT = "45364ed14905cb72269d952acc84fdbf3a94d38b"
ENVIFORMER_CHECKPOINT_SHA256 = "a2faf5751ca5d6ce525976d2477390712a5abec5c4a41c5b765001d1b520fc7e"

ENVIPATH_PACKAGE = "https://envipath.org/package/32de3cf4-e3e6-4168-956e-32fa5ddb0ce1"
ENVIPATH_SEARCH = "https://envipath.org/api/legacy/search"
ENVIPATH_UTIL = "https://envipath.org/api/legacy/util"
ENVIPATH_SETTING = "https://envipath.org/setting/a0fbc3d8-ca45-44f1-9c3c-80d8531ffe25"
ENVIPATH_SETTING_NAME = "Global Setting - BBD Rules"


def utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_path(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def file_identity(path: Path):
    return {
        "path": str(path),
        "present": path.exists(),
        "sha256": sha256_path(path) if path.exists() else None,
        "bytes": path.stat().st_size if path.exists() else None,
    }


def write_text(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def write_json(path: Path, obj):
    write_text(path, json.dumps(obj, sort_keys=True, indent=2) + "\n")


def write_jsonl(path: Path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")


def canonical_and_key(smiles: str):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"RDKit could not parse SMILES: {smiles}")
    return Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True), Chem.MolToInchiKey(mol)


def safe_error(text, limit=1200):
    if not text:
        return None
    return str(text).replace(os.environ.get("ENVIPATH_PASSWORD", "__NO_PASSWORD__"), "[REDACTED]")[:limit]


def load_blind(blind_csv: Path):
    if not blind_csv.exists():
        raise RuntimeError(f"blind CSV missing: {blind_csv}")
    blind_sha = sha256_path(blind_csv)
    if blind_sha != BLIND_SHA256:
        raise RuntimeError(f"blind CSV sha256 mismatch: {blind_sha}")
    with blind_csv.open(newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != EXPECTED_COLUMNS:
            raise RuntimeError(f"blind CSV columns mismatch: {reader.fieldnames}")
        rows = list(reader)
    if len(rows) != EXPECTED_ROWS:
        raise RuntimeError(f"blind CSV row count {len(rows)} != {EXPECTED_ROWS}")
    return rows


def make_dirs(return_root: Path):
    if return_root.exists():
        raise FileExistsError("M3_P1_2_1_BBD_KNOWN_PATHWAY_V0_2_BLOCKED_OUTPUT_PATH_EXISTS")
    for rel in [
        "input",
        "predictions/biotransformer_envmicro/raw/cases",
        "predictions/biotransformer_envmicro/logs",
        "predictions/enviformer_latest/raw",
        "predictions/enviformer_latest/logs",
        "predictions/envipath_prediction/raw/one_step_prediction",
        "predictions/envipath_prediction/logs",
        "envipath_database_lookup/raw/database_search",
        "envipath_database_lookup/logs",
        "metadata",
        "logs",
        "scripts",
        "reports",
    ]:
        (return_root / rel).mkdir(parents=True, exist_ok=False)


def make_prediction_row(row, tool_id, tool_version, rank, original, canonical, inchikey, raw_ref, status, extra=None):
    record = {
        "benchmark_case_id": row["benchmark_case_id"],
        "tool_id": tool_id,
        "tool_version": tool_version,
        "run_id": TASK_ID,
        "prediction_rank": rank,
        "parent_smiles": row["parent_smiles"],
        "predicted_product_smiles_original": original or "",
        "predicted_product_smiles_canonical": canonical or "",
        "predicted_product_inchikey": inchikey or "",
        "raw_output_ref": raw_ref,
        "normalization_status": status,
    }
    if extra:
        record.update(extra)
    return record


def case_summary_writer(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("w", newline="")
    fields = [
        "benchmark_case_id",
        "pollutant_name",
        "parent_comp_id",
        "route",
        "case_status",
        "raw_count",
        "normalized_count",
        "raw_output_ref",
        "error_message_sanitized",
    ]
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    return handle, writer


def run_biotransformer(return_root: Path, rows, jar_path: Path, source_root: Path):
    route_root = return_root / "predictions" / BIOTRANSFORMER_TOOL
    start = utc_now()
    predictions = []
    summaries = []
    log_lines = []
    metadata = {
        "tool_id": BIOTRANSFORMER_TOOL,
        "tool_display_name": "BioTransformer ENVMICRO one-step prediction",
        "status_token": "M3_P1_2_1_BBD_V0_2_BIOTRANSFORMER_STARTED",
        "failure_stage": None,
        "blind_file_read": True,
        "restricted_answer_key_read": False,
        "command_template": "java -jar <biotransformer-3.0.0.jar> -k pred -b env -ismi <parent_smiles> -ocsv <case_output_csv> -s 1",
        "source_path": str(source_root),
        "jar_path": str(jar_path),
        "start_time_utc": start,
    }
    try:
        jar_sha = sha256_path(jar_path)
        metadata["jar_sha256"] = jar_sha
        metadata["actual_commit"] = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=str(source_root), text=True).strip()
        for index, row in enumerate(rows, start=1):
            case_id = row["benchmark_case_id"]
            case_dir = route_root / "raw" / "cases" / case_id
            case_dir.mkdir(parents=True, exist_ok=True)
            out_csv = case_dir / "vendor_output.csv"
            cmd = ["java", "-jar", str(jar_path), "-k", "pred", "-b", "env", "-ismi", row["parent_smiles"], "-ocsv", str(out_csv), "-s", "1"]
            write_text(case_dir / "command.txt", " ".join(cmd) + "\n")
            proc = subprocess.run(cmd, cwd=str(source_root), text=True, capture_output=True, timeout=300)
            write_text(case_dir / "stdout.txt", proc.stdout)
            write_text(case_dir / "stderr.txt", proc.stderr)
            write_text(case_dir / "exit_code.txt", str(proc.returncode) + "\n")
            raw_count = 0
            seen = set()
            case_preds = []
            error = None
            if out_csv.exists():
                with out_csv.open(newline="") as handle:
                    raw_rows = list(csv.DictReader(handle))
                raw_count = len(raw_rows)
                for raw_row in raw_rows:
                    raw_smiles = (raw_row.get("SMILES") or raw_row.get("smiles") or "").strip()
                    if not raw_smiles:
                        continue
                    try:
                        can, key = canonical_and_key(raw_smiles)
                    except Exception:
                        continue
                    if key in seen:
                        continue
                    seen.add(key)
                    case_preds.append(make_prediction_row(
                        row,
                        BIOTRANSFORMER_TOOL,
                        f"BioTransformer jar sha256:{jar_sha}",
                        len(case_preds) + 1,
                        raw_smiles,
                        can,
                        key,
                        f"predictions/{BIOTRANSFORMER_TOOL}/raw/cases/{case_id}/vendor_output.csv",
                        "ok",
                        {"rank_semantics": "vendor_csv_row_order_deduplicated_adapter_rank"},
                    ))
                    if len(case_preds) == 10:
                        break
            elif proc.returncode != 0:
                error = safe_error(proc.stderr or proc.stdout or f"exit {proc.returncode}")
            status = "ok" if case_preds else ("tool_error" if error else "no_prediction")
            predictions.extend(case_preds)
            summaries.append({
                "benchmark_case_id": case_id,
                "pollutant_name": row["pollutant_name"],
                "parent_comp_id": row["parent_comp_id"],
                "route": BIOTRANSFORMER_TOOL,
                "case_status": status,
                "raw_count": raw_count,
                "normalized_count": len(case_preds),
                "raw_output_ref": f"predictions/{BIOTRANSFORMER_TOOL}/raw/cases/{case_id}/vendor_output.csv",
                "error_message_sanitized": error or "",
            })
            log_lines.append(json.dumps({"route": BIOTRANSFORMER_TOOL, "index": index, "case_id": case_id, "status": status, "normalized": len(case_preds)}))
        status_token = "M3_P1_2_1_BBD_V0_2_BIOTRANSFORMER_PASS"
    except Exception as exc:
        status_token = "M3_P1_2_1_BBD_V0_2_BIOTRANSFORMER_FAIL_CLOSED"
        metadata["failure_stage"] = "execution_or_normalization"
        metadata["error_message_sanitized"] = safe_error(exc)
    write_jsonl(route_root / "PREDICTIONS_NORMALIZED.jsonl", predictions)
    with (route_root / "CASE_RUN_SUMMARY.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["benchmark_case_id", "pollutant_name", "parent_comp_id", "route", "case_status", "raw_count", "normalized_count", "raw_output_ref", "error_message_sanitized"])
        writer.writeheader()
        writer.writerows(summaries)
    metadata.update({
        "status_token": status_token,
        "end_time_utc": utc_now(),
        "case_count": len(rows),
        "normalized_prediction_rows": len(predictions),
        "case_status_counts": dict(Counter(s["case_status"] for s in summaries)),
        "runtime_environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "rdkit": rdBase.rdkitVersion,
            "java": subprocess.run(["java", "-version"], text=True, capture_output=True).stderr.splitlines()[0],
        },
    })
    write_json(route_root / "TOOL_RUN_METADATA.json", metadata)
    write_text(route_root / "logs" / "execution.log", "\n".join(log_lines) + ("\n" if log_lines else ""))
    return metadata


def load_enviformer_model(repo_root: Path, num_beams: int):
    import torch

    sys.path.insert(0, str(repo_root))
    os.chdir(repo_root)
    from models.EnviFormerModel import EnviFormerModel

    tokens_path = repo_root / "results" / "EnviFormerModel" / "uspto_regex" / "tokens.json"
    config_path = repo_root / "results" / "EnviFormerModel" / "uspto_regex" / "config.json"
    checkpoint_path = repo_root / "results" / "EnviFormerModel" / "uspto_regex" / "checkpoints" / "epoch=139-step=969640.ckpt"
    if sha256_path(checkpoint_path) != ENVIFORMER_CHECKPOINT_SHA256:
        raise RuntimeError("enviFormer checkpoint sha256 mismatch")
    with tokens_path.open() as handle:
        tokenizer = json.load(handle)
    tokenizer[1] = {int(key): value for key, value in tokenizer[1].items()}
    with config_path.open() as handle:
        config = json.load(handle)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    args = SimpleNamespace(
        model_name="EnviFormerModel",
        data_name="uspto",
        weights_dataset="uspto",
        preprocessor="rdkit",
        tokenizer="regex",
        max_len=256,
        min_len=0,
        batch_size=64,
        debug=False,
        gpus=1 if device == "cuda" else 0,
        epochs=200,
        augment_count=-1,
        test_mapping=False,
        score_all=False,
        run_clusters=False,
        device=device,
    )
    model = EnviFormerModel.load_from_checkpoint(str(checkpoint_path), map_location=device, config=config, vocab=tokenizer, p_args=args).to(device)
    probe, _ = model.smiles_to_smiles_inf(["CCO"], num_beams=num_beams)
    if not probe or not probe[0]:
        raise RuntimeError("enviFormer probe returned no predictions")
    return model, args, tokens_path, config_path, checkpoint_path


def run_enviformer(return_root: Path, rows, repo_root: Path, num_beams: int):
    import torch

    route_root = return_root / "predictions" / ENVIFORMER_TOOL
    start = utc_now()
    predictions = []
    native = []
    summaries = []
    log_lines = []
    metadata = {
        "tool_id": ENVIFORMER_TOOL,
        "tool_display_name": "enviFormer latest-current one-step prediction",
        "status_token": "M3_P1_2_1_BBD_V0_2_ENVIFORMER_STARTED",
        "failure_stage": None,
        "blind_file_read": True,
        "restricted_answer_key_read": False,
        "source_path": str(repo_root),
        "expected_commit": ENVIFORMER_COMMIT,
        "num_beams": num_beams,
        "top_k_contract": 10,
        "start_time_utc": start,
    }
    try:
        actual_commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=str(repo_root), text=True).strip()
        model, model_args, tokens_path, config_path, checkpoint_path = load_enviformer_model(repo_root, num_beams)
        metadata.update({
            "actual_commit": actual_commit,
            "checkpoint_path": str(checkpoint_path),
            "checkpoint_sha256": sha256_path(checkpoint_path),
            "tokens_json_path": str(tokens_path),
            "tokens_json_sha256": sha256_path(tokens_path),
            "config_json_path": str(config_path),
            "config_json_sha256": sha256_path(config_path),
            "device": model_args.device,
        })
        for index, row in enumerate(rows, start=1):
            case_id = row["benchmark_case_id"]
            error = None
            raw_preds = []
            case_preds = []
            try:
                got, _scores = model.smiles_to_smiles_inf([row["parent_smiles"]], num_beams=num_beams)
                raw_preds = got[0] if got else []
                seen = set()
                for native_rank, raw_smiles in enumerate(raw_preds, start=1):
                    raw_smiles = (raw_smiles or "").strip()
                    if not raw_smiles:
                        continue
                    try:
                        can, key = canonical_and_key(raw_smiles)
                    except Exception:
                        continue
                    if key in seen:
                        continue
                    seen.add(key)
                    case_preds.append(make_prediction_row(
                        row,
                        ENVIFORMER_TOOL,
                        f"enviFormer commit:{actual_commit} checkpoint_sha256:{sha256_path(checkpoint_path)}",
                        len(case_preds) + 1,
                        raw_smiles,
                        can,
                        key,
                        f"predictions/{ENVIFORMER_TOOL}/raw/ENVIFORMER_NATIVE_OUTPUT.jsonl",
                        "ok",
                        {"native_rank": native_rank, "rank_semantics": "beam_order_deduplicated_adapter_rank"},
                    ))
                    if len(case_preds) == 10:
                        break
            except Exception as exc:
                error = safe_error(exc)
            native.append({"benchmark_case_id": case_id, "parent_smiles": row["parent_smiles"], "raw_predictions": raw_preds, "error_message_sanitized": error})
            status = "ok" if case_preds else ("tool_error" if error else "no_prediction")
            predictions.extend(case_preds)
            summaries.append({
                "benchmark_case_id": case_id,
                "pollutant_name": row["pollutant_name"],
                "parent_comp_id": row["parent_comp_id"],
                "route": ENVIFORMER_TOOL,
                "case_status": status,
                "raw_count": len(raw_preds),
                "normalized_count": len(case_preds),
                "raw_output_ref": f"predictions/{ENVIFORMER_TOOL}/raw/ENVIFORMER_NATIVE_OUTPUT.jsonl",
                "error_message_sanitized": error or "",
            })
            log_lines.append(json.dumps({"route": ENVIFORMER_TOOL, "index": index, "case_id": case_id, "status": status, "normalized": len(case_preds)}))
        status_token = "M3_P1_2_1_BBD_V0_2_ENVIFORMER_PASS"
    except Exception as exc:
        status_token = "M3_P1_2_1_BBD_V0_2_ENVIFORMER_FAIL_CLOSED"
        metadata["failure_stage"] = "model_load_or_execution"
        metadata["error_message_sanitized"] = safe_error(exc)
    write_jsonl(route_root / "raw" / "ENVIFORMER_NATIVE_OUTPUT.jsonl", native)
    write_jsonl(route_root / "PREDICTIONS_NORMALIZED.jsonl", predictions)
    with (route_root / "CASE_RUN_SUMMARY.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["benchmark_case_id", "pollutant_name", "parent_comp_id", "route", "case_status", "raw_count", "normalized_count", "raw_output_ref", "error_message_sanitized"])
        writer.writeheader()
        writer.writerows(summaries)
    metadata.update({
        "status_token": status_token,
        "end_time_utc": utc_now(),
        "case_count": len(rows),
        "normalized_prediction_rows": len(predictions),
        "case_status_counts": dict(Counter(s["case_status"] for s in summaries)),
        "runtime_environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "rdkit": rdBase.rdkitVersion,
            "torch": torch.__version__,
            "torch_cuda_available": torch.cuda.is_available(),
        },
    })
    write_json(route_root / "TOOL_RUN_METADATA.json", metadata)
    write_text(route_root / "logs" / "execution.log", "\n".join(log_lines) + ("\n" if log_lines else ""))
    return metadata


def extract_first_gen_predictions(api_json):
    nodes = {node.get("id"): node for node in api_json.get("nodes", []) if isinstance(node, dict)}
    products = []
    for edge in api_json.get("edges", []):
        if edge.get("from") != 0:
            continue
        rule = edge.get("rule") if isinstance(edge.get("rule"), dict) else {}
        for to_id in edge.get("to", []) or []:
            node = nodes.get(to_id, {})
            smiles = node.get("smiles")
            if smiles:
                products.append({
                    "smiles": smiles,
                    "probability": edge.get("probability"),
                    "multiGenProbability": edge.get("multiGenProbability"),
                    "rule_name": rule.get("name"),
                    "rule_url": rule.get("url"),
                })
    return products


def run_envipath(return_root: Path, rows, delay: float):
    pred_root = return_root / "predictions" / ENVIPATH_PRED_TOOL
    lookup_root = return_root / "envipath_database_lookup"
    started = utc_now()
    username_present = bool(os.environ.get("ENVIPATH_USERNAME"))
    password_present = bool(os.environ.get("ENVIPATH_PASSWORD"))
    common = {
        "blind_file_read": True,
        "restricted_answer_key_read": False,
        "enviPath_python_version": None,
        "prediction_setting_id": ENVIPATH_SETTING,
        "prediction_setting_name": ENVIPATH_SETTING_NAME,
        "eawag_bbd_package": ENVIPATH_PACKAGE,
        "start_time_utc": started,
        "account_envvars_present": username_present and password_present,
        "login_mode": "account_envvars_present" if username_present and password_present else "account_envvars_missing",
    }
    try:
        import enviPath_python
        common["enviPath_python_version"] = getattr(enviPath_python, "__version__", "installed_unknown")
    except Exception as exc:
        common["enviPath_python_import_error"] = safe_error(exc)

    if not (username_present and password_present):
        token = "M3_P1_2_1_BBD_V0_2_ENVIPATH_BLOCKED_ACCOUNT_ENVVARS_MISSING"
        pred_meta = {
            **common,
            "tool_id": ENVIPATH_PRED_TOOL,
            "tool_display_name": "enviPath Global Setting - BBD Rules one-step prediction",
            "status_token": token,
            "failure_stage": "stage1_environment_login",
            "case_count": len(rows),
            "normalized_prediction_rows": 0,
            "end_time_utc": utc_now(),
        }
        lookup_meta = {
            **common,
            "tool_id": ENVIPATH_LOOKUP_TOOL,
            "tool_display_name": "enviPath database lookup / direct search",
            "status_token": token,
            "failure_stage": "stage1_environment_login",
            "case_count": len(rows),
            "lookup_result_rows": 0,
            "end_time_utc": utc_now(),
        }
        write_jsonl(pred_root / "PREDICTIONS_NORMALIZED.jsonl", [])
        write_jsonl(lookup_root / "ENVIPATH_DATABASE_LOOKUP_RESULTS.jsonl", [])
        for route_root, route, meta in [(pred_root, ENVIPATH_PRED_TOOL, pred_meta), (lookup_root, ENVIPATH_LOOKUP_TOOL, lookup_meta)]:
            with (route_root / ("CASE_RUN_SUMMARY.csv" if route == ENVIPATH_PRED_TOOL else "ENVIPATH_DATABASE_LOOKUP_SUMMARY.csv")).open("w", newline="") as handle:
                fields = ["benchmark_case_id", "pollutant_name", "parent_comp_id", "route", "case_status", "raw_count", "normalized_count", "raw_output_ref", "error_message_sanitized"]
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                for row in rows:
                    writer.writerow({
                        "benchmark_case_id": row["benchmark_case_id"],
                        "pollutant_name": row["pollutant_name"],
                        "parent_comp_id": row["parent_comp_id"],
                        "route": route,
                        "case_status": "blocked_account_envvars_missing",
                        "raw_count": 0,
                        "normalized_count": 0,
                        "raw_output_ref": "",
                        "error_message_sanitized": "ENVIPATH_USERNAME/ENVIPATH_PASSWORD not present; no remote per-case requests attempted",
                    })
            write_json(route_root / "TOOL_RUN_METADATA.json", meta)
            write_text(route_root / "logs" / "execution.log", token + "\n")
        return pred_meta, lookup_meta

    session = requests.Session()
    request_count = 0
    lookup_records = []
    pred_records = []
    lookup_summaries = []
    pred_summaries = []
    lookup_log = []
    pred_log = []
    # The v0.1 endpoint behavior worked with an authenticated session. The exact
    # client login API has changed before; direct login is intentionally conservative.
    try:
        for index, row in enumerate(rows, start=1):
            case_id = row["benchmark_case_id"]
            search_dir = lookup_root / "raw" / "database_search" / case_id
            search_dir.mkdir(parents=True, exist_ok=True)
            params = {"method": "defaultSmiles", "packages[]": [ENVIPATH_PACKAGE], "search": row["parent_smiles"]}
            resp = session.get(ENVIPATH_SEARCH, params=params, timeout=60)
            request_count += 1
            search_payload = {"case_id": case_id, "request": {"method": "GET", "url": ENVIPATH_SEARCH, "params": params}, "http_status": resp.status_code, "text_prefix": resp.text[:1000]}
            try:
                search_payload["json"] = resp.json()
            except Exception:
                search_payload["json"] = None
            write_json(search_dir / "raw_response.json", search_payload)
            js = search_payload.get("json") or {}
            search_status = "ok" if resp.status_code == 200 else ("login_required" if resp.status_code in {401, 403} else "server_error")
            lookup_record = {
                "benchmark_case_id": case_id,
                "tool_id": ENVIPATH_LOOKUP_TOOL,
                "run_id": TASK_ID,
                "layer": "database_lookup",
                "parent_smiles": row["parent_smiles"],
                "lookup_status": search_status,
                "matched_compound_count": len(js.get("compound", []) if isinstance(js, dict) else []),
                "matched_pathway_count": len(js.get("pathway", []) if isinstance(js, dict) else []),
                "matched_reaction_count": len(js.get("reaction", []) if isinstance(js, dict) else []),
                "packages_seen": [ENVIPATH_PACKAGE] if resp.status_code == 200 else [],
                "raw_output_ref": f"envipath_database_lookup/raw/database_search/{case_id}/raw_response.json",
                "error_message_sanitized": "" if resp.status_code == 200 else safe_error(resp.text),
            }
            lookup_records.append(lookup_record)
            lookup_summaries.append({
                "benchmark_case_id": case_id,
                "pollutant_name": row["pollutant_name"],
                "parent_comp_id": row["parent_comp_id"],
                "route": ENVIPATH_LOOKUP_TOOL,
                "case_status": search_status,
                "raw_count": sum(lookup_record[k] for k in ["matched_compound_count", "matched_pathway_count", "matched_reaction_count"]),
                "normalized_count": 1,
                "raw_output_ref": lookup_record["raw_output_ref"],
                "error_message_sanitized": lookup_record["error_message_sanitized"],
            })
            lookup_log.append(json.dumps({"route": ENVIPATH_LOOKUP_TOOL, "index": index, "case_id": case_id, "status": search_status}))
            time.sleep(delay)

            pred_dir = pred_root / "raw" / "one_step_prediction" / case_id
            pred_dir.mkdir(parents=True, exist_ok=True)
            form = {"hiddenMethod": "predict", "smiles": row["parent_smiles"], "settingUri": ENVIPATH_SETTING}
            resp = session.post(ENVIPATH_UTIL, data=form, timeout=90)
            request_count += 1
            pred_payload = {"case_id": case_id, "request": {"method": "POST", "url": ENVIPATH_UTIL, "form_fields": list(form.keys()), "settingUri": ENVIPATH_SETTING}, "http_status": resp.status_code, "text_prefix": resp.text[:1000]}
            try:
                pred_payload["json"] = resp.json()
            except Exception:
                pred_payload["json"] = None
            write_json(pred_dir / "raw_response.json", pred_payload)
            raw_products = extract_first_gen_predictions(pred_payload["json"] or {}) if resp.status_code == 200 else []
            seen = set()
            case_preds = []
            for raw in raw_products:
                try:
                    can, key = canonical_and_key(raw["smiles"])
                except Exception:
                    continue
                if key in seen:
                    continue
                seen.add(key)
                case_preds.append(make_prediction_row(
                    row,
                    ENVIPATH_PRED_TOOL,
                    f"enviPath legacy API setting:{ENVIPATH_SETTING}",
                    len(case_preds) + 1,
                    raw["smiles"],
                    can,
                    key,
                    f"predictions/{ENVIPATH_PRED_TOOL}/raw/one_step_prediction/{case_id}/raw_response.json",
                    "ok",
                    {"raw_confidence": raw.get("probability"), "rule_name": raw.get("rule_name"), "rule_url": raw.get("rule_url"), "known_pathway_lookup_layer_separate": True},
                ))
                if len(case_preds) == 10:
                    break
            pred_status = "ok" if case_preds else ("login_required" if resp.status_code in {401, 403} else ("tool_error" if resp.status_code != 200 else "no_prediction"))
            pred_records.extend(case_preds)
            pred_summaries.append({
                "benchmark_case_id": case_id,
                "pollutant_name": row["pollutant_name"],
                "parent_comp_id": row["parent_comp_id"],
                "route": ENVIPATH_PRED_TOOL,
                "case_status": pred_status,
                "raw_count": len(raw_products),
                "normalized_count": len(case_preds),
                "raw_output_ref": f"predictions/{ENVIPATH_PRED_TOOL}/raw/one_step_prediction/{case_id}/raw_response.json",
                "error_message_sanitized": "" if resp.status_code == 200 else safe_error(resp.text),
            })
            pred_log.append(json.dumps({"route": ENVIPATH_PRED_TOOL, "index": index, "case_id": case_id, "status": pred_status, "normalized": len(case_preds)}))
            time.sleep(delay)
        pred_token = "M3_P1_2_1_BBD_V0_2_ENVIPATH_PREDICTION_PASS"
        lookup_token = "M3_P1_2_1_BBD_V0_2_ENVIPATH_LOOKUP_PASS"
    except Exception as exc:
        pred_token = "M3_P1_2_1_BBD_V0_2_ENVIPATH_PREDICTION_FAIL_CLOSED"
        lookup_token = "M3_P1_2_1_BBD_V0_2_ENVIPATH_LOOKUP_FAIL_CLOSED"
        common["error_message_sanitized"] = safe_error(exc)

    write_jsonl(pred_root / "PREDICTIONS_NORMALIZED.jsonl", pred_records)
    write_jsonl(lookup_root / "ENVIPATH_DATABASE_LOOKUP_RESULTS.jsonl", lookup_records)
    for route_root, summaries, filename in [(pred_root, pred_summaries, "CASE_RUN_SUMMARY.csv"), (lookup_root, lookup_summaries, "ENVIPATH_DATABASE_LOOKUP_SUMMARY.csv")]:
        with (route_root / filename).open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=["benchmark_case_id", "pollutant_name", "parent_comp_id", "route", "case_status", "raw_count", "normalized_count", "raw_output_ref", "error_message_sanitized"])
            writer.writeheader()
            writer.writerows(summaries)
    pred_meta = {**common, "tool_id": ENVIPATH_PRED_TOOL, "status_token": pred_token, "failure_stage": common.get("error_message_sanitized") and "remote_request_or_normalization", "case_count": len(rows), "normalized_prediction_rows": len(pred_records), "request_count": request_count, "end_time_utc": utc_now()}
    lookup_meta = {**common, "tool_id": ENVIPATH_LOOKUP_TOOL, "status_token": lookup_token, "failure_stage": common.get("error_message_sanitized") and "remote_request_or_normalization", "case_count": len(rows), "lookup_result_rows": len(lookup_records), "request_count": request_count, "end_time_utc": utc_now()}
    write_json(pred_root / "TOOL_RUN_METADATA.json", pred_meta)
    write_json(lookup_root / "TOOL_RUN_METADATA.json", lookup_meta)
    write_text(pred_root / "logs" / "execution.log", "\n".join(pred_log) + ("\n" if pred_log else ""))
    write_text(lookup_root / "logs" / "execution.log", "\n".join(lookup_log) + ("\n" if lookup_log else ""))
    return pred_meta, lookup_meta


def make_manifest(return_root: Path):
    manifest = return_root / "MANIFEST.sha256"
    rows = []
    for path in sorted(p for p in return_root.rglob("*") if p.is_file() and p != manifest):
        rows.append(f"{sha256_path(path)}  {path.relative_to(return_root)}")
    manifest.write_text("\n".join(rows) + "\n")


def make_archive_and_identity(return_root: Path, payload_identity, final_status: str):
    archive = return_root.with_suffix(".tar.gz")
    with tarfile.open(archive, "w:gz") as tar:
        tar.add(return_root, arcname=return_root.name)
    identity_path = archive.with_name(archive.name + ".identity.txt")
    identity = {
        "return_dir": str(return_root),
        "archive_path": str(archive),
        "archive_sha256": sha256_path(archive),
        "archive_bytes": archive.stat().st_size,
        "created_utc": utc_now(),
        "task_id": TASK_ID,
        "input_payload_path": payload_identity["path"],
        "input_payload_sha256": payload_identity["sha256"],
        "expected_payload_sha256": PAYLOAD_SHA256,
        "blind_csv_sha256": BLIND_SHA256,
        "final_status": final_status,
        "restricted_answer_key_read": False,
    }
    identity_path.write_text("\n".join(f"{key}={value}" for key, value in identity.items()) + "\n")
    return archive, identity_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default="/root/projects/EnzymeCAGE-master")
    parser.add_argument("--payload", default="/root/projects/EnzymeCAGE-master/HPC_Inputs/" + PAYLOAD_NAME)
    parser.add_argument("--work-payload-root", default=None)
    parser.add_argument("--biotransformer-jar", default="/tmp/enzymecage_m3_p1_2_1_three_tool_valid_single_parent_biotransformer_envmicro_prediction_rerun4_20260728/Biotransformer/target/biotransformer-3.0.0.jar")
    parser.add_argument("--biotransformer-source", default="/tmp/enzymecage_m3_p1_2_1_three_tool_valid_single_parent_biotransformer_envmicro_prediction_rerun4_20260728/Biotransformer")
    parser.add_argument("--enviformer-repo", default="/tmp/enzymecage_m3_p1_2_1_three_tool_valid_single_parent_enviformer_latest_prediction_20260728/enviFormer")
    parser.add_argument("--num-beams", type=int, default=10)
    parser.add_argument("--envipath-delay", type=float, default=2.0)
    args = parser.parse_args()

    project_root = Path(args.project_root)
    payload = Path(args.payload)
    payload_identity = file_identity(payload)
    if payload_identity["sha256"] != PAYLOAD_SHA256:
        raise RuntimeError(f"payload sha256 mismatch: {payload_identity}")

    if args.work_payload_root:
        payload_root = Path(args.work_payload_root)
    else:
        payload_root = Path("/tmp") / f"{TASK_ID}_payload_{int(time.time())}"
        payload_root.mkdir(parents=True, exist_ok=False)
        subprocess.run(["tar", "-xzf", str(payload), "-C", str(payload_root)], check=True)
    blind_csv = payload_root / BLIND_REL
    rows = load_blind(blind_csv)

    return_root = project_root / "HPC_Returned_Result_Summaries" / TASK_ID
    make_dirs(return_root)
    shutil.copy2(blind_csv, return_root / "input" / BLIND_NAME)
    shutil.copy2(Path(__file__).resolve(), return_root / "scripts" / Path(__file__).name)
    write_json(return_root / "input" / "PAYLOAD_AND_BLIND_IDENTITY.json", {"payload": payload_identity, "blind_csv": file_identity(blind_csv), "allowed_blind_csv_read": str(blind_csv), "restricted_answer_key_read": False})
    write_text(return_root / "logs" / "forbidden_sources_audit.log", "restricted_answer_key_read=false\nscoring_performed=false\nonly_blind_parent_inputs_used_for_cases=true\n")

    metas = []
    metas.append(run_biotransformer(return_root, rows, Path(args.biotransformer_jar), Path(args.biotransformer_source)))
    metas.append(run_enviformer(return_root, rows, Path(args.enviformer_repo), args.num_beams))
    envipath_pred_meta, envipath_lookup_meta = run_envipath(return_root, rows, args.envipath_delay)
    metas.extend([envipath_pred_meta, envipath_lookup_meta])

    all_pass = all("PASS" in meta["status_token"] for meta in metas)
    final_status = "M3_P1_2_1_BBD_KNOWN_PATHWAY_V0_2_FOUR_ROUTE_PASS" if all_pass else "M3_P1_2_1_BBD_KNOWN_PATHWAY_V0_2_FOUR_ROUTE_PARTIAL_FAIL_CLOSED"
    report = {
        "task_id": TASK_ID,
        "final_status": final_status,
        "case_count": len(rows),
        "blind_file_read": True,
        "restricted_answer_key_read": False,
        "scoring_performed": False,
        "prediction_accuracy_includes_database_lookup": False,
        "routes": metas,
    }
    write_json(return_root / "reports" / "FOUR_ROUTE_RUN_REPORT.json", report)
    write_text(return_root / "RUN_STATUS.txt", final_status + "\n")
    write_text(return_root / "FINAL_STATUS.txt", final_status + "\n")
    make_manifest(return_root)
    archive, identity_path = make_archive_and_identity(return_root, payload_identity, final_status)
    print(json.dumps({"return_dir": str(return_root), "archive": str(archive), "identity": str(identity_path), "final_status": final_status}, sort_keys=True, indent=2))


if __name__ == "__main__":
    raise SystemExit(main())
