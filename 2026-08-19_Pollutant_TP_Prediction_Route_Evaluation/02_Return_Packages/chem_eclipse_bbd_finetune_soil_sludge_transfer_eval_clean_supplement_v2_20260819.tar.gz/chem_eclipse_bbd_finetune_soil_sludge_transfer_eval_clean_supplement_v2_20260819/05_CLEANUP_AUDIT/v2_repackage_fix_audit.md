# v2 Repackage Fix Audit

## Source Package
chem_eclipse_bbd_finetune_soil_sludge_transfer_eval_clean_supplement_20260819

## v2 Fixes
1. MANIFEST.sha256 and MANIFEST.files now cover manifest_check.txt
2. metrics_summary_v2.csv adds explicit valid-nonempty coverage columns

## Audit Flags
training_rerun=false
eclipse_prediction_rerun=false
biotransformer_full_rerun=false
envipath_api_rerun=false
prediction_outputs_changed=false
manifest_covers_manifest_check_txt=true
metrics_summary_v2_has_valid_nonempty_columns=true

## BioTransformer Coverage Summary
- Combined all_valid: 1679/1788 valid, 109 empty/error
- Combined bbd_parent_excluded: 1628/1731 valid, 103 empty/error
- Soil all_valid: 1414/1521 valid, 107 empty/error
- Soil bbd_parent_excluded: 1369/1470 valid, 101 empty/error
- Sludge all_valid: 273/276 valid, 3 empty/error
- Sludge bbd_parent_excluded: 267/270 valid, 3 empty/error
