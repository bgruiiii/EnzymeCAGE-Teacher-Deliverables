# Cleanup Methods

## 1. MANIFEST.sha256 fix
- Original: included MANIFEST.sha256 itself in the checksum list
- Fix: regenerate excluding MANIFEST.sha256 and MANIFEST.files from the list
- Verification: sha256sum -c MANIFEST.sha256 must pass

## 2. BioTransformer coverage correction
- Source: 03_PREDICTIONS/biotransformer_envmicro_top10_predictions.csv
- Method: count parents with at least 1 non-empty predicted_product_smiles_rdkit_canonical
- Result: 1679/1788 valid non-empty, 109 empty/error
- Original overstated as 1788/1788

## 3. Per-parent scoring table with BioTransformer
- Source: existing per_parent_scoring_table.csv (NoEC + PREDEC only)
- Method: load biotransformer_envmicro_top10_predictions.csv, compute hit@1/3/5/10, first_hit_rank, mrr per parent
- Output: per_parent_scoring_table_with_biotransformer.csv with 3 routes × 1788 parents = 5364 rows

## 4. OracleEC zero rows removed
- Source: metrics_summary.csv had 12 OracleEC rows with all-zero metrics
- Fix: filter to only include eclipse_noec, eclipse_predec, biotransformer_envmicro
- OracleEC moved to skipped_or_blocked_routes.csv

## 5. enviPath lookup not scored as prediction
- Confirmed: route_status_corrected.csv labels it as oracle_lookup_only_not_scored_as_prediction
