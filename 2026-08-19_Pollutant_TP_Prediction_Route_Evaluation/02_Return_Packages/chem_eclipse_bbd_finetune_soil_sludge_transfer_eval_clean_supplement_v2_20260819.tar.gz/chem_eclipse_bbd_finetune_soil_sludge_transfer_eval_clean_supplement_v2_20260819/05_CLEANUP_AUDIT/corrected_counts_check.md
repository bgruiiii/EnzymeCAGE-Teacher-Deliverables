# Corrected Counts Check

## BioTransformer Coverage
- Total parents: 1788
- Valid non-empty predictions: 1679
- Empty/error parents: 109
- Valid rate: 93.9%

## Per-Parent Scoring Table
- Routes: eclipse_noec (1788 rows), eclipse_predec (1788 rows), biotransformer_envmicro (1788 rows)
- Total rows: 5364

## Metrics Summary
- Original rows: 48
- Corrected rows: 36 (removed 12 OracleEC zero rows)
- Routes in corrected: ['eclipse_noec', 'eclipse_predec', 'biotransformer_envmicro']

## Route Status
                   route                                      status                                interpretation
            eclipse_noec                                   completed     BBD-only ECLIPSE NoEC transfer evaluation
          eclipse_predec                                   completed  BBD-only ECLIPSE with PREDEC EC conditioning
 biotransformer_envmicro       completed_with_empty_or_error_parents  1679/1788 valid non-empty parent predictions
       eclipse_oracle_ec                            skipped_optional                    not a real evaluated route
envipath_database_lookup oracle_lookup_only_not_scored_as_prediction known-pathway retrieval, not blind prediction
