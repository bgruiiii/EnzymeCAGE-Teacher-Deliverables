# Source Package Identity

## Source Package
- Name: chem_eclipse_bbd_finetune_soil_sludge_transfer_eval_20260818
- Path: /root/projects/EnzymeCAGE-master/HPC_Returned_Result_Summaries/chem_eclipse_bbd_finetune_soil_sludge_transfer_eval_20260818
- Final Status: SOIL_SLUDGE_TRANSFER_EVAL_COMPLETE_WITH_ROUTE_BLOCKERS
- Archive SHA256: see source package identity file

## Source Package Issues Found
1. MANIFEST.sha256 includes itself → self-check fails
2. BioTransformer coverage overstated as 1788/1788 (actual: 1679/1788 valid non-empty)
3. per_parent_scoring_table.csv missing BioTransformer rows
4. eclipse_oracle_ec zero-filled rows presented as real metrics
5. enviPath database lookup should not be scored as prediction
