# Soil/Sludge Transfer Evaluation Clean Supplement v2

This v2 package is a repackage/reporting-semantics fix only.
It does not rerun or change ECLIPSE, BioTransformer, or enviPath outputs.

## Headline (Corrected)

ECLIPSE NoEC and ECLIPSE PREDEC completed.
BioTransformer ENVMICRO has 1679/1788 valid non-empty parent predictions on the combined all-valid set, with 109 empty/error parent rows retained as misses in the full-denominator metrics.
enviPath database lookup is not counted as blind prediction accuracy.

## BBD-Parent-Excluded Denominator

For the BBD-parent-excluded denominator, BioTransformer has 1628/1731 valid non-empty parent predictions, with 103 empty/error parent rows retained as misses.

## Corrected Metrics (Combined, all_valid, raw)

| Route | Hit@1 | Hit@3 | Hit@5 | Hit@10 | MRR@10 | Valid Coverage |
|-------|-------|-------|-------|--------|--------|----------------|
| ECLIPSE NoEC | 8.33% | 17.11% | 21.25% | 23.15% | 0.136 | 1781/1788 |
| ECLIPSE PREDEC | 10.18% | 19.97% | 23.99% | 26.51% | 0.158 | 1785/1788 |
| BioTransformer ENVMICRO | 10.63% | 21.48% | 27.52% | 30.93% | 0.172 | 1679/1788 |

## Interpretation

BioTransformer ENVMICRO remains the strongest current blind-prediction baseline on Soil/Sludge Hit@3/5/10.
BBD-only ECLIPSE PREDEC improves over ECLIPSE NoEC but remains a complementary candidate generator rather than the leading standalone route.
enviPath known-pathway lookup should be reported separately as database retrieval, not prediction accuracy.

## v2 Fixes from v1

1. MANIFEST.sha256 and MANIFEST.files now cover every regular file including manifest_check.txt
2. metrics_summary_v2.csv adds explicit valid-nonempty coverage columns distinguishing placeholder coverage from actual prediction coverage
