# Blind Input Validation Report

**Input file:** `KNOWN_PATHWAY_POLLUTANT_BLIND_PARENT_INPUTS_V0_2.csv`

**Row count:** 83

**Unique benchmark_case_id:** 83

**Product columns present:** None (PASS)

**All parent_smiles non-empty:** True

**Empty SMILES cases:** None (PASS)

**Validation passed:** True

**Columns:** benchmark_case_id, pollutant_name, pollutant_category, source_database, source_family_public, parent_comp_id, parent_url, parent_smiles, input_note

## First 5 cases

- SPD-BBD2-PARENT-c0001 | 1,2-Dichloroethane | `ClCCCl`
- SPD-BBD2-PARENT-c0002 | Atrazine | `CCNc1nc(Cl)nc(NC(C)C)n1`
- SPD-BBD2-PARENT-c0006 | Gallate | `Oc1cc(cc(O)c1O)C([O-])=O`
- SPD-BBD2-PARENT-c0018 | 1,3-Dichloro-2-propanol | `OC(CCl)CCl`
- SPD-BBD2-PARENT-c0039 | Dibenzofuran | `c1ccc2c(c1)oc1ccccc21`

## Last 5 cases

- SPD-BBD2-PARENT-c1481 | Methamidophos | `COP(N)(=O)SC`
- SPD-BBD2-PARENT-c1524 | Diazepam | `CN1c2ccc(Cl)cc2C(=NCC1=O)c1ccccc1`
- SPD-BBD2-PARENT-c1531 | Acenaphthylene | `C1=Cc2cccc3cccc1c23`
- SPD-BBD2-PARENT-c1549 | 1,5-Anhydro-D-fructose | `OC[C@H]1OCC(=O)[C@@H](O)[C@@H]1O`
- SPD-BBD2-PARENT-c1586 | Atenolol | `CC(C)NCC(O)COc1ccc(CC(N)=O)cc1`
