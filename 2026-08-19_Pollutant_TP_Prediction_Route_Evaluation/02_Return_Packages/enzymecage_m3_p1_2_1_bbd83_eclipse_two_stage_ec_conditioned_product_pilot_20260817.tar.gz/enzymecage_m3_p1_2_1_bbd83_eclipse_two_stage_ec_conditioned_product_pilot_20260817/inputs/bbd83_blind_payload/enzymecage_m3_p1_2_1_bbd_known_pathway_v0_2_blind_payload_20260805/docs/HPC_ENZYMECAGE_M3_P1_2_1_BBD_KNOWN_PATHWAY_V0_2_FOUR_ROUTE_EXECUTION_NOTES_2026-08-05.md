# HPC execution notes: BBD known-pathway pollutant benchmark v0.2 four-route run

日期：2026-08-05  
状态：executor notes；复用 v0.1 / 18-case 已跑通入口，不重新定义工具路线  

## 1. 本轮输入

使用 blind-only payload：

```text
/root/projects/EnzymeCAGE-master/custom/docs/enzyme_feature_expansion/ENZYMECAGE_LUCAPCYCLE_MODEL_TRAINING_RUN_2026-07-01/07_HPC_Prompts/enzymecage_m3_p1_2_1_bbd_known_pathway_v0_2_blind_payload_20260805.tar.gz
```

只允许读取：

```text
blind/KNOWN_PATHWAY_POLLUTANT_BLIND_PARENT_INPUTS_V0_2.csv
```

不要读取 restricted answer key。答案表保留在本地，等预测输出冻结后本地评分。

## 2. 本轮四条路线

本轮是四条路线：

```text
1. BioTransformer ENVMICRO one-step prediction
2. enviFormer latest-current one-step prediction
3. enviPath Global Setting - BBD Rules one-step prediction
4. enviPath database lookup / direct search
```

其中前三条是预测路线；第 4 条是已知路径查询路线，不能和 prediction accuracy 混写。

## 3. BioTransformer ENVMICRO 入口

复用 v0.1 已跑通 prompt：

```text
07_HPC_Prompts/
HPC_ENZYMECAGE_M3_P1_2_1_SMALL_POLLUTANT_STRICT_V0_1_BIOTRANSFORMER_ENVMICRO_PREDICTION_EXECUTOR_ONLY_PROMPT_2026-07-28.md
```

该 prompt 记录的实际入口：

```text
java -jar <biotransformer-3.0.0.jar> -k pred -b env -ismi <parent_smiles> -ocsv <case_output_csv> -s 1
```

要求：

- 每个 parent SMILES 跑 one-step environmental microbial prediction；
- 最多保留 Top 10 scorer-ready products；
- no rows 时标记 `case_status=no_prediction`；
- 不评分、不读答案。

## 4. enviFormer latest-current 入口

复用 v0.1 已跑通 prompt：

```text
07_HPC_Prompts/
HPC_ENZYMECAGE_M3_P1_2_1_SMALL_POLLUTANT_STRICT_V0_1_ENVIFORMER_LATEST_PREDICTION_EXECUTOR_ONLY_PROMPT_2026-07-28.md
```

该 prompt 记录的固定信息：

```text
commit=45364ed14905cb72269d952acc84fdbf3a94d38b
checkpoint_sha256=a2faf5751ca5d6ce525976d2477390712a5abec5c4a41c5b765001d1b520fc7e
num_beams=10
```

要求：

- 只用 blind CSV 中的 parent SMILES；
- 可复用只读源码、venv、tokenizer、checkpoint；
- 不复用旧 raw predictions、normalized predictions、scores 或 answer-related files；
- 最多输出 Top 10；
- 无有效产物时标记 `case_status=no_prediction`。

## 5. enviPath prediction 与 database lookup 入口

复用 18-case 已跑通 prompt：

```text
07_HPC_Prompts/
HPC_ENZYMECAGE_M3_P1_2_1_ENVIPATH_DIRECT_18CASE_PREDICTION_EXECUTOR_ONLY_PROMPT_2026-08-05.md
```

该 prompt / 本地审计记录的实际 API 形状：

```text
enviPath-python version=0.2.4
legacy_api_host=https://envipath.org/api/legacy/
database_search=GET https://envipath.org/api/legacy/search
prediction=POST form https://envipath.org/api/legacy/util hiddenMethod=predict
prediction_setting_id=https://envipath.org/setting/a0fbc3d8-ca45-44f1-9c3c-80d8531ffe25
prediction_setting_name=Global Setting - BBD Rules
```

要求：

- database_search 对每个 parent 单独做，输出 known-pathway lookup 结果；
- one-step prediction 对每个 parent 单独做，输出 scorer-ready prediction JSONL；
- database_search hit 不是预测命中，必须单独报告；
- 本轮主比较使用 one-step prediction；bounded multistep 可作为 exploratory 附件，但不要混入主评分。

## 6. 统一输出格式

每条预测路线至少返回：

```text
predictions/<tool_id>/PREDICTIONS_NORMALIZED.jsonl
predictions/<tool_id>/CASE_RUN_SUMMARY.csv
predictions/<tool_id>/TOOL_RUN_METADATA.json
logs/
MANIFEST.sha256
RUN_STATUS.txt
```

`PREDICTIONS_NORMALIZED.jsonl` 每行一个 predicted product：

```json
{
  "benchmark_case_id": "SPD-BBD2-PARENT-c0288",
  "tool_id": "biotransformer_envmicro | enviformer_latest | envipath_prediction",
  "tool_version": "...",
  "run_id": "...",
  "prediction_rank": 1,
  "predicted_product_smiles_original": "...",
  "predicted_product_smiles_canonical": "",
  "predicted_product_inchikey": "",
  "raw_output_ref": "...",
  "normalization_status": "ok | invalid_smiles | no_prediction | tool_error"
}
```

enviPath database lookup 另存：

```text
envipath_database_lookup/ENVIPATH_DATABASE_LOOKUP_RESULTS.jsonl
envipath_database_lookup/ENVIPATH_DATABASE_LOOKUP_SUMMARY.csv
```

不要把 database lookup 写入 prediction scorer-ready JSONL。

## 7. 成功/阻断边界

PASS 条件：

```text
四条路线至少分别完成结构化输出；
或预测路线部分完成但明确记录 no_prediction/tool_error；
无 restricted answer key 读取；
所有输出打包并带 MANIFEST.sha256。
```

BLOCKED 条件：

```text
payload 缺失或 SHA256 不一致；
工具入口不可用且无法复用 v0.1 已跑通环境；
enviPath 登录/API 不可用导致无法产生结构化查询/预测结果；
任何执行端读取 restricted answer key。
```
