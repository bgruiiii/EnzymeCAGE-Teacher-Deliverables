# BBD known-pathway pollutant benchmark v0.2 blind payload

This payload is for Chenyu prediction execution only.

Use only:

```text
blind/KNOWN_PATHWAY_POLLUTANT_BLIND_PARENT_INPUTS_V0_2.csv
```

Do not use restricted answer files during prediction. The restricted answer key remains local in the local build package for scoring after outputs are frozen.

Current local build summary:

```text
source = EAWAG-BBD legacy pages
pathways processed = first 120 from all-pathways index
blind parent cases = 83
accepted product labels retained locally = 148
repeated parent compounds merged = 7
status = PASS_WITH_PROVISIONAL_AUDIT_BOUNDARY
```

Prediction routes requested downstream:

```text
BioTransformer ENVMICRO one-step
enviFormer latest-current one-step
enviPath prediction route one-step
```

enviPath database lookup should be reported separately as known-pathway lookup, not as prediction accuracy.
