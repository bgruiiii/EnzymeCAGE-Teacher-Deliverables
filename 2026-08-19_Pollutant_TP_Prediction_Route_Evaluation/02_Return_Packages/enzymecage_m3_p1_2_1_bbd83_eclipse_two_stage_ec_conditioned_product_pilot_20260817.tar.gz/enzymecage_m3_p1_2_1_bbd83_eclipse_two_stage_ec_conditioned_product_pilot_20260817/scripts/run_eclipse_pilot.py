#!/usr/bin/env python3
"""
ECLIPSE Two-Stage EC-Conditioned Product Prediction - BBD83 Pilot
Executor-only script: trains EC predictor, runs EC-only, No-EC, and PredEC predictions.
"""
import json, os, sys, csv, time, warnings, hashlib, math
import numpy as np
import pandas as pd
import torch
from argparse import Namespace
from rdkit import Chem, RDLogger
from rdkit.Chem import rdFingerprintGenerator
from tqdm import tqdm

warnings.filterwarnings("ignore")
RDLogger.DisableLog("rdApp.*")

# Paths
WORKSPACE = "/root/projects/EnzymeCAGE-master"
RETURN_DIR = os.path.join(WORKSPACE, "HPC_Returned_Result_Summaries",
    "enzymecage_m3_p1_2_1_bbd83_eclipse_two_stage_ec_conditioned_product_pilot_20260817")
INPUT_CSV = os.path.join(RETURN_DIR, "inputs/KNOWN_PATHWAY_POLLUTANT_BLIND_PARENT_INPUTS_V0_2.csv")
ECMAP_CSV = os.path.join(WORKSPACE, "data/ecmap.csv")
TRANSFORMER_DIR = os.path.join(WORKSPACE, "results/TransformerModel/uspto_rdkit")

os.chdir(WORKSPACE)
sys.path.insert(0, WORKSPACE)

# ─── Helpers ───
def canonicalize_smiles(smi):
    try:
        mol = Chem.MolFromSmiles(smi)
        return Chem.MolToSmiles(mol) if mol else ""
    except:
        return ""

def inchikey(smi):
    try:
        mol = Chem.MolFromSmiles(smi)
        return Chem.MolToInchiKey(mol) if mol else ""
    except:
        return ""

def load_blind_inputs():
    df = pd.read_csv(INPUT_CSV)
    return df

# ═════════════════════════════════════════════════════════════════════
# Stage 3: EC-only inference
# ═════════════════════════════════════════════════════════════════════
def train_ec_predictor():
    """Train ecmap H-ECLIPSE EC predictor from ecmap.csv."""
    from importlib import resources
    from chem_eclipse.models.ECLIPSEModel import ECLIPSEModel
    from chem_eclipse.ECLIPSEInference import train as eclipse_train
    from chem_eclipse.utils import get_dataset_eclipse, split_eclipse_inference

    # Load ecmap config and ec_to_i
    with resources.files("chem_eclipse.models.ecmap_heclipse").joinpath("config.json").open("r") as f:
        config = json.load(f)
    with resources.files("chem_eclipse.models.ecmap_heclipse").joinpath("ec_to_i.json").open("r") as f:
        ec_to_i = json.load(f)["ec_to_i"]

    args = Namespace(
        data_name="ecmap", eclipse_type="h", split_path="", max_len=380, min_len=0,
        debug=False, epochs=500, batch_size=128,
        weights_dataset="results/TransformerModel/uspto_rdkit",
        score_all=False, folds=10, enzymes=False, seed=0,
        test="", train_many=False, workers=8, gpu=False,
        scenario=False, pathway_train=False, augment_count=-1,
        preprocessor="rdkit", tokenizer="regex",
        test_mapping=False
    )

    model_path = str(resources.files("chem_eclipse.models").joinpath("ecmap_heclipse"))
    model_pkl = os.path.join(model_path, "model.pkl")

    if os.path.exists(model_pkl):
        print(f"[EC] model.pkl found at {model_path}, loading...")
        model = ECLIPSEModel(ec_to_i, config, args, device="cpu", save_path=model_path)
        model = model.load_model(model_path)
        model.tolerance = config.get("tolerance", 0.01)
        return model, ec_to_i, config

    # Train from scratch
    print("[EC] Training ecmap H-ECLIPSE from scratch (this may take several minutes)...")
    model, save_path = eclipse_train(args, config, final_train=True, save_path=model_path)
    model.tolerance = config.get("tolerance", 0.01)
    print(f"[EC] Training complete. Model saved to {save_path}")
    return model, ec_to_i, config

def run_ec_only_predictions(ec_model, ec_to_i, config):
    """Run EC prediction for all 83 blind parent SMILES."""
    df = load_blind_inputs()
    smiles_list = df["parent_smiles"].tolist()

    print(f"[EC-Only] Predicting EC for {len(smiles_list)} substrates...")
    tolerance = config.get("tolerance", 0.01)
    predictions = ec_model.predict(smiles_list, tolerance=tolerance)

    results = []
    for i, row in df.iterrows():
        preds = predictions[i] if i < len(predictions) else []
        for rank, ec in enumerate(preds):
            ec_level = len(ec.split(".")) if ec else 0
            results.append({
                "benchmark_case_id": row["benchmark_case_id"],
                "pollutant_name": row["pollutant_name"],
                "parent_comp_id": row["parent_comp_id"],
                "parent_smiles": row["parent_smiles"],
                "ec_model_name": "H-ECLIPSE-ecmap",
                "ec_model_source": "chem-eclipse v0.1.0, trained on ECMap (124K reactions)",
                "ec_rank": rank + 1,
                "predicted_ec": ec,
                "predicted_ec_score": 0.0,
                "predicted_ec_level": ec_level,
                "ec_prediction_status": "SUCCESS",
                "ec_prediction_error_sanitized": ""
            })
        if not preds:
            results.append({
                "benchmark_case_id": row["benchmark_case_id"],
                "pollutant_name": row["pollutant_name"],
                "parent_comp_id": row["parent_comp_id"],
                "parent_smiles": row["parent_smiles"],
                "ec_model_name": "H-ECLIPSE-ecmap",
                "ec_model_source": "chem-eclipse v0.1.0, trained on ECMap (124K reactions)",
                "ec_rank": 0,
                "predicted_ec": "",
                "predicted_ec_score": 0.0,
                "predicted_ec_level": 0,
                "ec_prediction_status": "NO_EC_PREDICTED",
                "ec_prediction_error_sanitized": ""
            })

    # Write JSONL
    jsonl_path = os.path.join(RETURN_DIR, "predictions/ec_only/ECLIPSE_EC_ONLY_PREDICTIONS.jsonl")
    with open(jsonl_path, "w") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    # Write CSV
    csv_path = os.path.join(RETURN_DIR, "predictions/ec_only/ECLIPSE_EC_ONLY_PREDICTIONS.csv")
    with open(csv_path, "w", newline="") as f:
        if results:
            writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
            writer.writeheader()
            writer.writerows(results)

    # Summary
    case_count = len(set(r["benchmark_case_id"] for r in results))
    success_count = len(set(r["benchmark_case_id"] for r in results if r["ec_prediction_status"] == "SUCCESS"))
    total_preds = len(results)
    avg_preds = total_preds / case_count if case_count > 0 else 0

    summary = {
        "total_cases": case_count,
        "cases_with_ec_prediction": success_count,
        "cases_with_no_ec": case_count - success_count,
        "total_ec_predictions": total_preds,
        "mean_ec_per_case": round(avg_preds, 2),
        "ec_model": "H-ECLIPSE-ecmap",
        "tolerance": tolerance
    }
    with open(os.path.join(RETURN_DIR, "reports/ECLIPSE_EC_ONLY_SUMMARY.json"), "w") as f:
        json.dump(summary, f, indent=2)
    with open(os.path.join(RETURN_DIR, "reports/ECLIPSE_EC_ONLY_SUMMARY.md"), "w") as f:
        f.write("# EC-Only Prediction Summary\n\n")
        for k, v in summary.items():
            f.write(f"- **{k}**: {v}\n")

    print(f"[EC-Only] {success_count}/{case_count} cases with EC predictions, {total_preds} total ECs")
    return predictions, df

# ═════════════════════════════════════════════════════════════════════
# Stage 4 & 5: Product prediction (No-EC and PredEC)
# ═════════════════════════════════════════════════════════════════════
def load_transformer_model():
    """Load the USPTO-pretrained TransformerModel from checkpoint."""
    from chem_eclipse.models.TransformerModel import TransformerModel

    with open(os.path.join(TRANSFORMER_DIR, "config.json")) as f:
        config = json.load(f)
    with open(os.path.join(TRANSFORMER_DIR, "tokens.json")) as f:
        tokens = json.load(f)

    char_to_i = tokens[0] if isinstance(tokens, list) else tokens["char_to_i"]
    i_to_char_raw = tokens[1] if isinstance(tokens, list) else tokens["i_to_char"]
    # Convert string keys to int keys for numpy array compatibility
    i_to_char = {int(k): v for k, v in i_to_char_raw.items()}
    vocab = (char_to_i, i_to_char)

    args = Namespace(
        data_name="uspto", seed=0, batch_size=128, max_len=380, min_len=0,
        weights_dataset="", enzymes=False, debug=False, scenario=False,
        pathway_train=False, augment_count=-1, preprocessor="rdkit",
        tokenizer="regex", split_path="", epochs=500, gpus=1,
        test_mapping=False, score_all=True, folds=10
    )

    model = TransformerModel(config, vocab, args, save_path=TRANSFORMER_DIR)

    # Load checkpoint weights
    ckpt_dir = os.path.join(TRANSFORMER_DIR, "checkpoints")
    ckpt_file = [f for f in os.listdir(ckpt_dir) if ".ckpt" in f][0]
    ckpt_path = os.path.join(ckpt_dir, ckpt_file)
    print(f"[Transformer] Loading checkpoint: {ckpt_path}")
    checkpoint = torch.load(ckpt_path, map_location="cuda", weights_only=False)
    state_dict = checkpoint.get("state_dict", checkpoint)
    model.load_state_dict(state_dict, strict=False)
    model.to("cuda")
    model.eval()
    print(f"[Transformer] Model loaded successfully on GPU")
    return model, char_to_i, i_to_char, config, args

def run_no_ec_product_prediction(transformer, char_to_i, i_to_char, config, args):
    """Stage 4: No-EC product prediction."""
    from chem_eclipse.utils import encode_mol, decode_mol, canon_smile_rdkit
    from torch.nn.utils.rnn import pad_sequence

    df = load_blind_inputs()
    smiles_list = df["parent_smiles"].tolist()
    num_beams = 3

    print(f"[No-EC] Predicting products for {len(smiles_list)} substrates (num_beams={num_beams})...")

    results = []
    batch_size = 32

    all_pred_smiles = []
    all_pred_scores = []

    with torch.no_grad():
        for batch_start in tqdm(range(0, len(smiles_list), batch_size), desc="No-EC batches"):
            batch_smiles = smiles_list[batch_start:batch_start + batch_size]
            enc_smiles = []
            bad_indices = []
            for j, s in enumerate(batch_smiles):
                enc = encode_mol(s, char_to_i, args, enclose=True)
                if enc is not None:
                    enc_smiles.append(enc)
                else:
                    bad_indices.append(j)
                    enc_smiles.append(torch.tensor([char_to_i["[nop]"]], dtype=torch.long))

            if not any(e is not None for e in enc_smiles):
                for j in range(len(batch_smiles)):
                    all_pred_smiles.append([""])
                    all_pred_scores.append([float("-inf")])
                continue

            valid_enc = [e for e in enc_smiles if e is not None and len(e) > 1]
            if not valid_enc:
                for j in range(len(batch_smiles)):
                    all_pred_smiles.append([""])
                    all_pred_scores.append([float("-inf")])
                continue

            padded = pad_sequence(enc_smiles, batch_first=True, padding_value=char_to_i["[nop]"])
            padded = padded.to("cuda")

            from chem_eclipse.utils import beam_decode
            sorted_mols, sorted_lls, _ = beam_decode(transformer, padded, num_beams=num_beams)
            # Convert tensors to numpy arrays for decode_mol compatibility
            sorted_mols_np = sorted_mols.cpu().numpy()
            sorted_lls_np = sorted_lls.cpu().numpy()

            for i in range(len(batch_smiles)):
                pred_smiles = []
                pred_probas = []
                if i < len(sorted_mols_np):
                    for j in range(len(sorted_mols_np[i])):
                        smi = decode_mol(sorted_mols_np[i, j], i_to_char, canon_smile_rdkit)
                        if len(smi) > 0:
                            pred_smiles.append(smi)
                            pred_probas.append(float(sorted_lls_np[i, j]))
                if not pred_smiles:
                    pred_smiles = [""]
                    pred_probas = [float("-inf")]
                all_pred_smiles.append(pred_smiles)
                all_pred_scores.append(pred_probas)

    # Build output rows
    ckpt_dir = os.path.join(TRANSFORMER_DIR, "checkpoints")
    ckpt_file = [f for f in os.listdir(ckpt_dir) if ".ckpt" in f][0]
    ckpt_sha = hashlib.sha256(open(os.path.join(ckpt_dir, ckpt_file), "rb").read()).hexdigest()

    for i, row in df.iterrows():
        preds = all_pred_smiles[i] if i < len(all_pred_smiles) else [""]
        scores = all_pred_scores[i] if i < len(all_pred_scores) else [float("-inf")]
        for rank, (smi, score) in enumerate(zip(preds, scores)):
            can = canonicalize_smiles(smi) if smi else ""
            ik = inchikey(smi) if smi else ""
            results.append({
                "benchmark_case_id": row["benchmark_case_id"],
                "pollutant_name": row["pollutant_name"],
                "parent_comp_id": row["parent_comp_id"],
                "parent_smiles": row["parent_smiles"],
                "route_id": "no_ec",
                "route_name": "No-EC Product Transformer (USPTO pretrained)",
                "model_dataset": "uspto_rdkit",
                "model_checkpoint_path": os.path.join(ckpt_dir, ckpt_file),
                "model_checkpoint_sha256": ckpt_sha,
                "prediction_rank": rank + 1,
                "predicted_product_smiles_raw": smi,
                "predicted_product_smiles_canonical": can,
                "predicted_product_inchikey": ik,
                "product_score": score,
                "product_score_name": "beam_log_likelihood",
                "score_semantics": "log-likelihood from beam search (higher = better)",
                "generation_status": "SUCCESS" if smi else "EMPTY",
                "generation_error_sanitized": ""
            })

    _write_product_results(results, "no_ec_product", "NO_EC_PRODUCT")

    case_count = len(set(r["benchmark_case_id"] for r in results))
    success_count = len(set(r["benchmark_case_id"] for r in results if r["generation_status"] == "SUCCESS"))
    cand_counts = [len([r2 for r2 in results if r2["benchmark_case_id"] == r["benchmark_case_id"]]) for r in df.to_dict("records")]
    cand_counts = [c for c in cand_counts if c > 0]

    summary = {
        "total_cases": case_count,
        "cases_with_predictions": success_count,
        "mean_candidate_count": round(np.mean(cand_counts), 2) if cand_counts else 0,
        "median_candidate_count": round(np.median(cand_counts), 2) if cand_counts else 0,
        "score_semantics": "beam_log_likelihood (log-likelihood, higher=better)",
        "num_beams": num_beams,
        "model_checkpoint": ckpt_file
    }
    _write_summary(summary, "NO_EC_PRODUCT_SUMMARY")
    print(f"[No-EC] {success_count}/{case_count} cases with predictions")
    return all_pred_smiles, all_pred_scores

def run_pred_ec_product_prediction(transformer, char_to_i, i_to_char, config, args, ec_predictions, df):
    """Stage 5: PredEC-conditioned product prediction."""
    from chem_eclipse.utils import encode_mol, decode_mol, canon_smile_rdkit, beam_decode
    from torch.nn.utils.rnn import pad_sequence

    smiles_list = df["parent_smiles"].tolist()
    topk_ec = 3
    num_beams = 3

    print(f"[PredEC] Predicting products for {len(smiles_list)} substrates (topk_ec={topk_ec}, num_beams={num_beams})...")

    ckpt_dir = os.path.join(TRANSFORMER_DIR, "checkpoints")
    ckpt_file = [f for f in os.listdir(ckpt_dir) if ".ckpt" in f][0]
    ckpt_sha = hashlib.sha256(open(os.path.join(ckpt_dir, ckpt_file), "rb").read()).hexdigest()

    use_enzyme = config.get("use_enzyme", True)
    all_results = []

    with torch.no_grad():
        for case_idx, row in tqdm(df.iterrows(), total=len(df), desc="PredEC cases"):
            smi = row["parent_smiles"]
            ec_preds = ec_predictions[case_idx] if case_idx < len(ec_predictions) else []
            ec_topk = ec_preds[:topk_ec] if ec_preds else []

            case_products = {}  # canonical_smiles -> (best_score, supporting_ecs, branch_scores)

            for ec_rank, ec_class in enumerate(ec_topk):
                if use_enzyme:
                    input_str = f"{smi}>{ec_class if ec_class != 'other' else ''}"
                else:
                    input_str = smi

                enc = encode_mol(input_str, char_to_i, args, enclose=True)
                if enc is None:
                    continue

                enc = enc.unsqueeze(0).to("cuda")
                try:
                    sorted_mols, sorted_lls, _ = beam_decode(transformer, enc, num_beams=num_beams)
                except Exception as e:
                    continue

                # Convert tensors to numpy arrays for decode_mol compatibility
                sorted_mols_np = sorted_mols.cpu().numpy()
                sorted_lls_np = sorted_lls.cpu().numpy()

                for j in range(len(sorted_mols_np[0])):
                    raw_smi = decode_mol(sorted_mols_np[0, j], i_to_char, canon_smile_rdkit)
                    if not raw_smi:
                        continue
                    can_smi = canonicalize_smiles(raw_smi)
                    score = float(sorted_lls_np[0, j])

                    if can_smi in case_products:
                        if score > case_products[can_smi]["best_score"]:
                            case_products[can_smi]["best_score"] = score
                            case_products[can_smi]["best_raw"] = raw_smi
                        case_products[can_smi]["supporting_ecs"].append(ec_class)
                        case_products[can_smi]["branch_scores"].append(score)
                    else:
                        case_products[can_smi] = {
                            "best_score": score,
                            "best_raw": raw_smi,
                            "supporting_ecs": [ec_class],
                            "branch_scores": [score],
                            "source_ec": ec_class,
                            "source_ec_rank": ec_rank + 1
                        }

            # Sort by best score descending
            sorted_products = sorted(case_products.items(), key=lambda x: x[1]["best_score"], reverse=True)

            for rank, (can_smi, info) in enumerate(sorted_products):
                all_results.append({
                    "benchmark_case_id": row["benchmark_case_id"],
                    "pollutant_name": row["pollutant_name"],
                    "parent_comp_id": row["parent_comp_id"],
                    "parent_smiles": row["parent_smiles"],
                    "route_id": "pred_ec",
                    "route_name": "PredEC-conditioned Product Transformer (ECMap H-ECLIPSE + USPTO pretrained)",
                    "ec_model_name": "H-ECLIPSE-ecmap",
                    "product_model_name": "TransformerModel-USPTO",
                    "product_model_dataset": "uspto_rdkit",
                    "product_model_checkpoint_path": os.path.join(ckpt_dir, ckpt_file),
                    "product_model_checkpoint_sha256": ckpt_sha,
                    "topk_ec": topk_ec,
                    "num_beams": num_beams,
                    "prediction_rank": rank + 1,
                    "predicted_product_smiles_raw": info["best_raw"],
                    "predicted_product_smiles_canonical": can_smi,
                    "predicted_product_inchikey": inchikey(info["best_raw"]),
                    "product_score": info["best_score"],
                    "product_score_name": "beam_log_likelihood",
                    "score_semantics": "log-likelihood from beam search (higher=better)",
                    "source_pred_ec": info["source_ec"],
                    "source_pred_ec_rank": info["source_ec_rank"],
                    "source_pred_ec_score": 0.0,
                    "all_supporting_pred_ecs": ";".join(info["supporting_ecs"]),
                    "all_branch_scores": ";".join(f"{s:.4f}" for s in info["branch_scores"]),
                    "deduplication_policy": "keep_best_score_merge_supporting_ecs",
                    "generation_status": "SUCCESS",
                    "generation_error_sanitized": ""
                })

            if not sorted_products:
                all_results.append({
                    "benchmark_case_id": row["benchmark_case_id"],
                    "pollutant_name": row["pollutant_name"],
                    "parent_comp_id": row["parent_comp_id"],
                    "parent_smiles": row["parent_smiles"],
                    "route_id": "pred_ec",
                    "route_name": "PredEC-conditioned Product Transformer (ECMap H-ECLIPSE + USPTO pretrained)",
                    "ec_model_name": "H-ECLIPSE-ecmap",
                    "product_model_name": "TransformerModel-USPTO",
                    "product_model_dataset": "uspto_rdkit",
                    "product_model_checkpoint_path": os.path.join(ckpt_dir, ckpt_file),
                    "product_model_checkpoint_sha256": ckpt_sha,
                    "topk_ec": topk_ec,
                    "num_beams": num_beams,
                    "prediction_rank": 0,
                    "predicted_product_smiles_raw": "",
                    "predicted_product_smiles_canonical": "",
                    "predicted_product_inchikey": "",
                    "product_score": float("-inf"),
                    "product_score_name": "beam_log_likelihood",
                    "score_semantics": "log-likelihood from beam search (higher=better)",
                    "source_pred_ec": "",
                    "source_pred_ec_rank": 0,
                    "source_pred_ec_score": 0.0,
                    "all_supporting_pred_ecs": "",
                    "all_branch_scores": "",
                    "deduplication_policy": "keep_best_score_merge_supporting_ecs",
                    "generation_status": "NO_PRODUCTS_GENERATED",
                    "generation_error_sanitized": ""
                })

    _write_product_results(all_results, "pred_ec_product", "PRED_EC_PRODUCT")

    case_count = len(set(r["benchmark_case_id"] for r in all_results))
    success_count = len(set(r["benchmark_case_id"] for r in all_results if r["generation_status"] == "SUCCESS"))
    cand_counts = []
    for _, row in df.iterrows():
        c = len([r for r in all_results if r["benchmark_case_id"] == row["benchmark_case_id"] and r["generation_status"] == "SUCCESS"])
        cand_counts.append(c)

    summary = {
        "total_cases": case_count,
        "cases_with_predictions": success_count,
        "mean_candidate_count": round(np.mean(cand_counts), 2) if cand_counts else 0,
        "median_candidate_count": round(np.median(cand_counts), 2) if cand_counts else 0,
        "score_semantics": "beam_log_likelihood (log-likelihood, higher=better)",
        "topk_ec": topk_ec,
        "num_beams": num_beams,
        "model_checkpoint": ckpt_file
    }
    _write_summary(summary, "PRED_EC_PRODUCT_SUMMARY")
    print(f"[PredEC] {success_count}/{case_count} cases with predictions")
    return all_results

# ═════════════════════════════════════════════════════════════════════
# Stage 7: Overlap diagnostics
# ═════════════════════════════════════════════════════════════════════
def run_overlap_diagnostics(df):
    """Check overlap between 83 blind parent SMILES and ECMap training data."""
    print("[Overlap] Checking training data overlap...")

    ecmap_df = pd.read_csv(ECMAP_CSV)
    ecmap_reactants = set(ecmap_df["rdkit_reactants"].apply(canonicalize_smiles).tolist())
    ecmap_products = set(ecmap_df["rdkit_products"].apply(canonicalize_smiles).tolist())

    blind_smiles = df["parent_smiles"].tolist()
    blind_canonical = [canonicalize_smiles(s) for s in blind_smiles]

    overlap_cases = []
    exact_substrate_overlaps = 0
    exact_product_overlaps = 0

    for i, (smi, can_smi) in enumerate(zip(blind_smiles, blind_canonical)):
        in_reactants = can_smi in ecmap_reactants if can_smi else False
        in_products = can_smi in ecmap_products if can_smi else False

        if in_reactants or in_products:
            exact_substrate_overlaps += 1 if in_reactants else 0
            exact_product_overlaps += 1 if in_products else 0

        overlap_cases.append({
            "benchmark_case_id": df.iloc[i]["benchmark_case_id"],
            "parent_smiles": smi,
            "canonical_smiles": can_smi,
            "in_ecmap_reactants": in_reactants,
            "in_ecmap_products": in_products,
            "overlap_status": "SEEN_IN_TRAINING" if (in_reactants or in_products) else "UNSEEN"
        })

    # Write CSV
    csv_path = os.path.join(RETURN_DIR, "overlap_diagnostics/overlap_by_case.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(overlap_cases[0].keys()))
        writer.writeheader()
        writer.writerows(overlap_cases)

    # Write JSON and MD
    report = {
        "overlap_status": "COMPLETED",
        "training_data_source": "Zenodo ecmap.csv (124,705 reactions)",
        "total_blind_cases": len(blind_smiles),
        "exact_substrate_overlap_count": exact_substrate_overlaps,
        "exact_product_overlap_count": exact_product_overlaps,
        "exact_substrate_overlap_pct": round(exact_substrate_overlaps / len(blind_smiles) * 100, 2),
        "interpretation": "SEEN_OR_LEAKAGE_RISK_BBD_VARIANT" if exact_substrate_overlaps > 0 else "STRICT_UNSEEN_SUBSET"
    }

    with open(os.path.join(RETURN_DIR, "overlap_diagnostics/TRAINING_OVERLAP_DIAGNOSTIC.json"), "w") as f:
        json.dump(report, f, indent=2)

    with open(os.path.join(RETURN_DIR, "overlap_diagnostics/TRAINING_OVERLAP_DIAGNOSTIC.md"), "w") as f:
        f.write("# Training Overlap Diagnostic\n\n")
        f.write(f"- **Training data source**: Zenodo ecmap.csv (124,705 reactions)\n")
        f.write(f"- **Total blind cases**: {report['total_blind_cases']}\n")
        f.write(f"- **Exact substrate overlap**: {report['exact_substrate_overlap_count']} ({report['exact_substrate_overlap_pct']}%)\n")
        f.write(f"- **Exact product overlap**: {report['exact_product_overlap_count']}\n")
        f.write(f"- **Interpretation**: {report['interpretation']}\n")

    print(f"[Overlap] Substrate overlap: {exact_substrate_overlaps}/{len(blind_smiles)} ({report['exact_substrate_overlap_pct']}%)")
    return report

# ─── Utility writers ───
def _write_product_results(results, subdir, prefix):
    jsonl_path = os.path.join(RETURN_DIR, f"predictions/{subdir}/PREDICTIONS_NORMALIZED.jsonl")
    csv_path = os.path.join(RETURN_DIR, f"predictions/{subdir}/PREDICTIONS_NORMALIZED.csv")
    with open(jsonl_path, "w") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    if results:
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
            writer.writeheader()
            writer.writerows(results)

def _write_summary(summary, name):
    with open(os.path.join(RETURN_DIR, f"reports/{name}.json"), "w") as f:
        json.dump(summary, f, indent=2)
    with open(os.path.join(RETURN_DIR, f"reports/{name}.md"), "w") as f:
        f.write(f"# {name.replace('_', ' ').title()}\n\n")
        for k, v in summary.items():
            f.write(f"- **{k}**: {v}\n")

# ═════════════════════════════════════════════════════════════════════
# Main
# ═════════════════════════════════════════════════════════════════════
def main():
    t0 = time.time()
    log_path = os.path.join(RETURN_DIR, "logs/run_log.txt")
    os.makedirs(os.path.dirname(log_path), exist_ok=True)

    with open(log_path, "w") as log:
        log.write(f"ECLIPSE BBD83 Pilot Run Log\nStarted: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}\n\n")

    # Stage 3: EC-only
    print("=" * 60)
    print("Stage 3: EC-only inference")
    print("=" * 60)
    ec_model, ec_to_i, ec_config = train_ec_predictor()
    ec_predictions, df = run_ec_only_predictions(ec_model, ec_to_i, ec_config)

    # Stage 4: No-EC product prediction
    print("\n" + "=" * 60)
    print("Stage 4: No-EC product prediction")
    print("=" * 60)
    transformer, char_to_i, i_to_char, t_config, t_args = load_transformer_model()
    no_ec_smiles, no_ec_scores = run_no_ec_product_prediction(transformer, char_to_i, i_to_char, t_config, t_args)

    # Stage 5: PredEC product prediction
    print("\n" + "=" * 60)
    print("Stage 5: PredEC-conditioned product prediction")
    print("=" * 60)
    pred_ec_results = run_pred_ec_product_prediction(
        transformer, char_to_i, i_to_char, t_config, t_args, ec_predictions, df)

    # Stage 6: TrueEC oracle - skip
    print("\n" + "=" * 60)
    print("Stage 6: TrueEC oracle (skipped)")
    print("=" * 60)
    with open(os.path.join(RETURN_DIR, "reports/TRUE_EC_ORACLE_NOT_RUN.md"), "w") as f:
        f.write("# TrueEC Oracle Not Run\n\n")
        f.write('reason = "No answer-independent true EC table was available under the blind-boundary policy."\n')

    # Stage 7: Overlap diagnostics
    print("\n" + "=" * 60)
    print("Stage 7: Overlap diagnostics")
    print("=" * 60)
    overlap_report = run_overlap_diagnostics(df)

    elapsed = time.time() - t0
    print(f"\n{'=' * 60}")
    print(f"All stages complete in {elapsed:.1f}s ({elapsed/60:.1f} min)")
    print(f"{'=' * 60}")

    with open(log_path, "a") as log:
        log.write(f"\nCompleted: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}\n")
        log.write(f"Elapsed: {elapsed:.1f}s\n")

if __name__ == "__main__":
    main()
