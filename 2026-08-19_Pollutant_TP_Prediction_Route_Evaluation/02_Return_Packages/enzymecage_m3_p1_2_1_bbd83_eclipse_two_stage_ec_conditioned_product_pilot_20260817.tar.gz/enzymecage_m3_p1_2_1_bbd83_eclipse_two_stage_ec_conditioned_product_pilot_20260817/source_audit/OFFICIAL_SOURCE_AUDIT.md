# Official Source Audit

## Package
- **Name:** chem-eclipse
- **Version:** 0.1.0
- **Source:** PyPI (`pip install "chem-eclipse[cpu]"`)
- **GitHub:** https://github.com/MyCreativityOutlet/chem-eclipse

## Paper
- **DOI:** https://doi.org/10.1186/s13321-026-01190-w
- **Title:** "Predicting Enzyme-Compound Interactions for Enzyme-Catalysed Reactions"

## Zenodo Reproduction Data
- **DOI:** https://doi.org/10.5281/zenodo.17489235 (redirects to record 17489236)
- **Record URL:** https://zenodo.org/records/17489236
- **Files downloaded:**
  - `results.zip` (161,465,604 bytes) — USPTO-pretrained TransformerModel checkpoint
    - SHA256: c146c8df69bc4599855bce054266aca1fcfcd198e7457300f124cdf04d0e7025
  - `ecmap.csv` (58,255,702 bytes) — ECMap training dataset (124,705 reactions)
    - SHA256: 6f8c403bbba51c77e442416eb2b7683f1702547ad5c7d8d1d8e7decc7805f9bb
  - `bec_pred_models.zip` (6,222,424,695 bytes) — BEC-Pred models (NOT downloaded, not ECLIPSE)

## Package Contents Inspected
- `chem_eclipse/models/ECLIPSEModel.py` (315 lines) — EC prediction (H-ECLIPSE)
- `chem_eclipse/models/ECLIPSEProdModel.py` (107 lines) — Two-stage product prediction
- `chem_eclipse/models/TransformerModel.py` (292 lines) — SMILES-to-SMILES transformer
- `chem_eclipse/models/BaseModel.py` (78 lines) — Lightning base class
- `chem_eclipse/ECLIPSEInference.py` (111 lines) — Training and inference entry points
- `chem_eclipse/utils.py` (1197 lines) — Utilities, data loading, beam decode
- `chem_eclipse/models/bbd_heclipse/config.json` — 16 EC classes, tolerance=0.01
- `chem_eclipse/models/ecmap_heclipse/config.json` — 152 EC classes, tolerance=0.01
- `chem_eclipse/models/ECLIPSEProdModel_config.json` — topk_ec=2, d_model=256, n_layers=4
- `chem_eclipse/models/TransformerModel_config.json` — d_model=256, warm_up=4000

## Model Weights Status
- **In package:** None (no .pkl, .ckpt, .pt, .safetensors files)
- **Trained during run:** ecmap H-ECLIPSE model.pkl (trained from ecmap.csv, ~138s)
- **From Zenodo:** USPTO TransformerModel checkpoint (epoch=124-step=880875.ckpt)
