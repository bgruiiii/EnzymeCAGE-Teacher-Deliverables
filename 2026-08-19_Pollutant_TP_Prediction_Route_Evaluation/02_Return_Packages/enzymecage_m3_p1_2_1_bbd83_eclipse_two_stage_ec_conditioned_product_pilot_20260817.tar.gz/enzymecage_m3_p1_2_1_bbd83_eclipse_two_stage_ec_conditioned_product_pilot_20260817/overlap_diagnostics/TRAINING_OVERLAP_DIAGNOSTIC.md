# Training Overlap Diagnostic

- **Training data source**: Zenodo ecmap.csv (124,705 reactions)
- **Total blind cases**: 83
- **Exact substrate overlap**: 7 (8.43%)
- **Exact product overlap**: 21
- **Interpretation**: SEEN_OR_LEAKAGE_RISK_BBD_VARIANT
