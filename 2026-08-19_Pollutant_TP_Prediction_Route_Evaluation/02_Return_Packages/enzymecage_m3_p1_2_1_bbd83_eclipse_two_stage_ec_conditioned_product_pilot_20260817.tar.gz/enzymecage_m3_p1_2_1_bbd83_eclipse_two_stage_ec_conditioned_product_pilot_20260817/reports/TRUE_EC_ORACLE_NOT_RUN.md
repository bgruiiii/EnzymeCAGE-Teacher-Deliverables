# TrueEC Oracle Not Run

reason = "No answer-independent true EC table was available under the blind-boundary policy."
