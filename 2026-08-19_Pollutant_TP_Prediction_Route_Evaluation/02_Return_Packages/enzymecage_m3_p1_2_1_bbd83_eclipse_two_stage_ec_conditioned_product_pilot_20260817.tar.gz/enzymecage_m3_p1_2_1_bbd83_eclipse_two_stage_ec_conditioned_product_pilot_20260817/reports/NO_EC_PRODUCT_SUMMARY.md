# No Ec Product Summary

- **total_cases**: 83
- **cases_with_predictions**: 80
- **mean_candidate_count**: 2.77
- **median_candidate_count**: 3.0
- **score_semantics**: beam_log_likelihood (log-likelihood, higher=better)
- **num_beams**: 3
- **model_checkpoint**: epoch=124-step=880875.ckpt
