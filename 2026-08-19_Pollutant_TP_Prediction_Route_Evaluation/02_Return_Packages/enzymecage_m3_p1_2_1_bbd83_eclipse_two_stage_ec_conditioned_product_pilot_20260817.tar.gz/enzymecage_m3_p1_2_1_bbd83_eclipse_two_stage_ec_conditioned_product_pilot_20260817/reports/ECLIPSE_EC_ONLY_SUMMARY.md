# EC-Only Prediction Summary

- **total_cases**: 83
- **cases_with_ec_prediction**: 83
- **cases_with_no_ec**: 0
- **total_ec_predictions**: 94
- **mean_ec_per_case**: 1.13
- **ec_model**: H-ECLIPSE-ecmap
- **tolerance**: 0.01
