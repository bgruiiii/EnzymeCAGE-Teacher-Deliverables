# ECLIPSE Code and Asset Preflight Report

## Summary

The `chem-eclipse` v0.1.0 package was installed from PyPI. All source code modules imported successfully. No pretrained model weights were bundled in the package — only configuration files and EC-to-index mappings. Trained model weights were obtained from the official Zenodo reproduction data (record 17489236).

## Required Questions

### 1. Which class/function performs EC-only inference from substrate SMILES?

**Answer:** `ECLIPSEModel.predict(smiles, tolerance)` in `chem_eclipse/models/ECLIPSEModel.py`.

The `ECLIPSEModel` class uses a hierarchical multi-label classifier (`MultiLabelLocalClassifierPerNode`) with XGBoost estimators. It computes Morgan fingerprints (radius=2, n_bits=2048) from input SMILES and predicts EC class labels at 3-level hierarchy.

### 2. Does `oob_inference` exist and run on custom SMILES?

**Answer:** Yes. `oob_inference()` exists in `chem_eclipse/ECLIPSEInference.py` (line 86). It loads (or trains if absent) the H-ECLIPSE model from `{data_name}_heclipse` package directory and runs `model.predict()` on input data. However, it uses `get_arguments()` which parses command-line args and expects data in a specific CSV format. For this pilot, we called the model's `predict()` method directly.

### 3. Does `ECLIPSEProdModel.py` exist?

**Answer:** Yes. `chem_eclipse/models/ECLIPSEProdModel.py` (107 lines). It combines an `ECLIPSEModel` (EC predictor) and a `TransformerModel` (product predictor) for two-stage prediction.

### 4. Does `ECLIPSEProdModel.smiles_to_smiles_inf()` or equivalent exist?

**Answer:** Yes. `ECLIPSEProdModel.smiles_to_smiles_inf(smiles, ec_classes=None)` (line 53). When `ec_classes=None`, it first predicts ECs using `self.eclipse.predict()`, then conditions the TransformerModel on each EC class using the format `smiles>ec_class`, runs beam search, and returns deduplicated ranked products.

### 5. Can the current code perform `substrate SMILES -> predicted EC -> product SMILES` without modifying the algorithm?

**Answer:** Yes, but with caveats. The code supports the two-stage path, but requires:
- A trained `model.pkl` for the ECLIPSE EC predictor (not bundled in package)
- A trained `.ckpt` checkpoint for the TransformerModel (not bundled in package)

Both were obtained from Zenodo. The EC predictor was trained from `ecmap.csv` (124K reactions) using the package's built-in training function. The TransformerModel was loaded from the USPTO-pretrained checkpoint (`epoch=124-step=880875.ckpt`).

### 6. Does the product inference path expose product scores, probabilities, beam scores, or another ranking signal?

**Answer:** Yes. The `beam_decode()` function returns `sorted_mols` and `sorted_lls` (log-likelihoods). These are negative log-likelihood values from the beam search; higher (less negative) = better.

### 7. Default values for key parameters:

| Parameter | Default Value | Source |
|-----------|--------------|--------|
| `topk_ec` | 2 (config) / 3 (pilot requirement) | `ECLIPSEProdModel_config.json` |
| `num_beams` | 3 (hardcoded in `smiles_to_smiles_inf`) | `ECLIPSEProdModel.py` line 84 |
| `max_length` | 380 | Config / args |
| `canonicalization` | `canon_smile_rdkit` (RDKit canonicalization) | `TransformerModel.py` line 31 |

### 8. Pretrained/refined model checkpoints available:

| Model | Available? | Source |
|-------|-----------|--------|
| ECMap No-EC product model | No (requires training) | — |
| ECMap PredEC product model | No (requires training) | — |
| BBD No-EC product model | No | — |
| BBD PredEC product model | No | — |
| H-ECLIPSE EC predictor (ECMap) | Trained from ecmap.csv | This run |
| USPTO pretrained Transformer | Yes | Zenodo `results.zip` |

### 9. Is there an official released BBD-refined product model checkpoint?

**Answer:** No. The Zenodo reproduction data does not include BBD-refined product model checkpoints. The `bec_pred_models.zip` (6.2GB) contains BEC-Pred models (a different model), not ECLIPSE product models. The only product model checkpoint available is the USPTO-pretrained Transformer.

### 10. If local training/refinement would be required, estimate feasibility:

**Answer:** Training the H-ECLIPSE EC predictor from ecmap.csv took ~138 seconds on CPU (8 workers, 82K samples after dedup). This is feasible. Training the product Transformer from scratch on USPTO data would require significant GPU time (the pretrained checkpoint has 125 epochs). BBD-specific fine-tuning is not feasible without BBD reaction training data in the expected format.
