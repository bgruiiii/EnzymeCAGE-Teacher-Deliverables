# Pred Ec Product Summary

- **total_cases**: 83
- **cases_with_predictions**: 83
- **mean_candidate_count**: 2.84
- **median_candidate_count**: 3.0
- **score_semantics**: beam_log_likelihood (log-likelihood, higher=better)
- **topk_ec**: 3
- **num_beams**: 3
- **model_checkpoint**: epoch=124-step=880875.ckpt
