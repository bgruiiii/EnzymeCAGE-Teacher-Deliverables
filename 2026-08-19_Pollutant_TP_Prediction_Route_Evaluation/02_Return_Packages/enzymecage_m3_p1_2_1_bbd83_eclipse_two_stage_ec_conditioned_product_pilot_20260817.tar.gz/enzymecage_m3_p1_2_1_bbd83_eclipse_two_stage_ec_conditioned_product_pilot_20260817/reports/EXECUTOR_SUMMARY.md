# ECLIPSE BBD83 Two-Stage EC-Conditioned Product Pilot — Executor Summary

## Final Status

**ECLIPSE_BBD83_TWO_STAGE_PRODUCT_PILOT_COMPLETE**

All 8 stages completed successfully. Full PredEC-conditioned product predictions produced for all 83 blind cases.

## Key Results

| Stage | Status | Count |
|-------|--------|-------|
| EC-only prediction | COMPLETE | 83/83 cases, 94 EC predictions |
| No-EC product prediction | COMPLETE | 80/83 cases (3 encoding failures) |
| PredEC product prediction | COMPLETE | 83/83 cases |
| TrueEC oracle | NOT RUN | No answer-independent true EC source |
| Overlap diagnostics | COMPLETED | 7/83 substrate overlap (8.43%) |

## Model Assets Used

- **EC Predictor:** H-ECLIPSE (ecmap), trained from Zenodo ecmap.csv (124K reactions, ~138s CPU)
- **Product Transformer:** USPTO-pretrained TransformerModel (epoch=124-step=880875.ckpt)
- **Checkpoint SHA256:** a7b1d6d592078268f421d53d3a0710be5452b6ee42a3f040cee0c8ce7ae3e305

## Prediction Parameters

- `topk_ec = 3` (per pilot requirement)
- `num_beams = 3`
- `tolerance = 0.01` (from ecmap config)
- `max_len = 380`
- Canonicalization: RDKit `canon_smile_rdkit`

## Candidate Statistics

| Route | Mean candidates | Median candidates |
|-------|----------------|------------------|
| No-EC | 2.77 | 3.0 |
| PredEC | 2.84 | 3.0 |

## Score Semantics

Both routes use **beam_log_likelihood** (negative log-likelihood from beam search). Higher (less negative) = better.

## Training Overlap

- **Substrate overlap:** 7/83 (8.43%) blind parent SMILES found in ECMap training data
- **Product overlap:** 21/83 blind parent SMILES found as products in ECMap training data
- **Interpretation:** SEEN_OR_LEAKAGE_RISK_BBD_VARIANT

## Prohibited Actions Verified

- restricted_answer_key_read = false
- No answer-derived scoring
- No threshold/beam tuning using answers
- No model selection using answers
