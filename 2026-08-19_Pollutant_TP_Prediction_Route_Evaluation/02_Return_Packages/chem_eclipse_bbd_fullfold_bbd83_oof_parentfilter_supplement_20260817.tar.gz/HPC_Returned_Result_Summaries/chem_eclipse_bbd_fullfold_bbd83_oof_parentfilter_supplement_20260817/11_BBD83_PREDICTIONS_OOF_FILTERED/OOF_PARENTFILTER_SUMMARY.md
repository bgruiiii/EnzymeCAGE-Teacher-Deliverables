# BBD83 OOF-only + Parent-filter Supplementary Predictions

## Overview

This supplementary package provides filtered BBD83 blind prediction candidate tables:
- **ALL**: All-fold predictions (baseline, for comparison)
- **PARENT_FILTERED**: All-fold predictions with unchanged-parent predictions removed
- **OOF_ONLY**: Only predictions from folds where substrate was in the test set (out-of-fold)
- **OOF_PARENT_FILTERED**: OOF-only + parent-filtered (most conservative)

**No restricted answer key was read. No Hit@K / accuracy / MRR was computed.**

## Filter Definitions

- **OOF-only**: For each BBD83 case, only predictions from folds where the substrate appeared in the test set (not training) are retained. This prevents data leakage from training-set exposure.
- **Parent-filter**: Predictions where `predicted_product_smiles_rdkit_canonical == parent_smiles_rdkit_canonical` are removed. These represent 'unchanged parent' predictions where the model failed to predict any transformation.

## Statistics

| Variant | Route | Foldwise Input | After Filter | Aggregated Rows | Unique Cases | Removed (OOF) | Removed (Parent) |
|---------|-------|----------------|-------------|-----------------|--------------|---------------|------------------|
| NO_EC_ALL | NO_EC | 2424 | 2424 | 643 | 83 | 0 | 0 |
| NO_EC_PARENT_FILTERED | NO_EC | 2424 | 1876 | 575 | 83 | 0 | 548 |
| NO_EC_OOF_ONLY | NO_EC | 2424 | 239 | 235 | 81 | 2185 | 0 |
| NO_EC_OOF_PARENT_FILTERED | NO_EC | 2424 | 190 | 189 | 81 | 2185 | 49 |
| PREDEC_ALL | PREDEC | 2452 | 2452 | 718 | 83 | 0 | 0 |
| PREDEC_PARENT_FILTERED | PREDEC | 2452 | 2201 | 670 | 83 | 0 | 251 |
| PREDEC_OOF_ONLY | PREDEC | 2452 | 238 | 230 | 81 | 2214 | 0 |
| PREDEC_OOF_PARENT_FILTERED | PREDEC | 2452 | 211 | 205 | 81 | 2214 | 27 |

## Files Generated

For each variant × route combination:
- `{VARIANT}_AGGREGATED.csv`: Aggregated candidate table (deduplicated by canonical product SMILES, ranked by beam_log_likelihood)
- `{VARIANT}_FOLDWISE.jsonl`: Per-fold filtered predictions

## Required Columns (in all CSVs)

```
benchmark_case_id
pollutant_name
parent_smiles
parent_smiles_rdkit_canonical
route
prediction_policy
predicted_product_smiles_rdkit_canonical
best_beam_log_likelihood
contributing_folds
rank_aggregated
predicted_ec
model_checkpoint_sha256
status
blocker_reason
```

## OOF Coverage
- Cases with OOF folds available: 81/83
- Cases without OOF folds (SUBSTRATE_UNSEEN_BY_BBD): 2/83
- For SUBSTRATE_UNSEEN_BY_BBD cases, OOF-only tables will have no predictions.