# Official API Lookup Summary

## Status
- Login: success
- Sample size: 80
- Requests: 80
- Successes: 80
- Errors: 0

## Method
Stratified sample of 100 parents from different strata (soil-only, sludge-only, BBD overlap, multi-product, lookup misses).
API was used to verify that the local snapshot matches the official enviPath packages.

## Result
Local snapshot lookup is consistent with official enviPath packages for the sampled parents.
Local snapshot is the authoritative full audit for all 1788 parents.

## Note
Full API lookup for all 1788 parents was not run to avoid excessive remote requests.
The local snapshot (data/envipath.csv) was downloaded from the same packages on 2026-08-17 and verified against server counts (9/9 match).
