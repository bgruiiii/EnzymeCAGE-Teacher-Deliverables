# Input Manifest

- **prior_eval_dir**: /root/projects/EnzymeCAGE-master/HPC_Returned_Result_Summaries/chem_eclipse_bbd_finetune_soil_sludge_transfer_eval_20260818
- **envipath_csv**: {
  "path": "data/envipath.csv",
  "rows": 4630
}
- **soil_json**: {
  "path": "data/envipath/soil.json",
  "compounds": 2608,
  "reactions": 2445,
  "pathways": 317
}
- **sludge_json**: {
  "path": "data/envipath/sludge.json",
  "compounds": 1067,
  "reactions": 494,
  "pathways": 183
}
- **bbd_json**: {
  "path": "data/envipath/bbd.json",
  "compounds": 1399,
  "reactions": 1480,
  "pathways": 219
}
- **blind_inputs**: {
  "rows": 1788
}
- **answer_key**: {
  "rows": 2924
}
- **dedup_pairs**: {
  "rows": 2924
}
