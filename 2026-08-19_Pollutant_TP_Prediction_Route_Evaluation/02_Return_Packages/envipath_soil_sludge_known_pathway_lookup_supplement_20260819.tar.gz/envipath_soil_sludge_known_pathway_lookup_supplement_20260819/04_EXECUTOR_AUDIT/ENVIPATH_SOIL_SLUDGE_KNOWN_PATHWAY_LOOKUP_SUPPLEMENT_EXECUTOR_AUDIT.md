# Executor Audit: enviPath Soil/Sludge Known-Pathway Lookup Supplement

## Task
Audit the known-pathway lookup route for the 1788 Soil/Sludge parent compounds.

## Process
1. Loaded eval set from prior transfer eval (1788 parents, 2924 answer key entries)
2. Built local lookup index from data/envipath.csv Soil/Sludge rows
3. Queried each parent by canonical SMILES
4. Compared lookup products with answer key
5. Bounded API verification on stratified sample of 100 parents

## Results
- Parent found rate: 100.0% (combined)
- Accepted product label recall: 100.0% (combined)
- Parents with all products recovered: 1788 (100.0%)
- Lookup extra products: 0

## API Lookup
- Status: completed_bounded_sample
- Stratified sample verified against local snapshot

## Caveat
This is a known-pathway retrieval / data integrity audit, not a prediction accuracy test.
enviPath lookup results should not be mixed with ECLIPSE/BioTransformer prediction metrics.
