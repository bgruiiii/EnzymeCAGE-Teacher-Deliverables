# Local Snapshot Lookup Summary

| Label | Parents | Found | Found Rate | All Recovered | Product Recall | Extra Products |
|-------|---------|-------|-----------|---------------|---------------|----------------|
| combined | 1788 | 1788 | 100.0% | 1788 (100.0%) | 100.0% | 0 |
| soil | 1521 | 1521 | 100.0% | 1521 (100.0%) | 100.0% | 0 |
| sludge | 276 | 276 | 100.0% | 276 (100.0%) | 100.0% | 0 |
| bbd_parent_excluded | 1731 | 1731 | 100.0% | 1731 (100.0%) | 100.0% | 0 |
| bbd_parent_overlap_only | 57 | 57 | 100.0% | 57 (100.0%) | 100.0% | 0 |

## Failure Categories


## Interpretation

enviPath lookup can recover known Soil/Sludge records when the parent already exists in the enviPath package.
This supports using enviPath as a known-pathway retrieval layer, not as a fair blind predictor on the same Soil/Sludge-derived evaluation set.
