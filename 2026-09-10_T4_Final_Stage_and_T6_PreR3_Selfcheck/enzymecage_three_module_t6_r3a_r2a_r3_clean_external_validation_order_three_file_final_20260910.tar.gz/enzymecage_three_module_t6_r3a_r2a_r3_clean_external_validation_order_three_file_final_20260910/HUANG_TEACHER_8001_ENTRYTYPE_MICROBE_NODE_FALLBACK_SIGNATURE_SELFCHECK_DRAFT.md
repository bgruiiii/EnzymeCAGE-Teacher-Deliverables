# DRAFT / NOT SENT

4 UID / 8 records = UNIPROT_REVIEWED. 8001 active=0; direct REST plus frozen reviewed map fallback. Microbe candidates use the teacher NCBI TaxID key. Host signature remains in per-enzyme provenance and separate from record identity. Frozen row hashes cover complete CRLF bytes. Q7X2D3 names remain different; only TaxID matches and no synonym equivalence was adjudicated. Graph/state were not changed. C8-to-T5, T6-R3 and G7 are incomplete. This draft was not sent and awaits independent local audit.
