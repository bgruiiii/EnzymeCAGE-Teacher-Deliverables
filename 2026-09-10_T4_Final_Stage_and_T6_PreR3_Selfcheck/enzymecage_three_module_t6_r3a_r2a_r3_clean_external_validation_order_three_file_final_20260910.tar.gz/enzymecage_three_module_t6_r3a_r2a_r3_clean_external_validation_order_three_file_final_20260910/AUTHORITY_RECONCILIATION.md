# Authority reconciliation

> 生产主键：NCBI taxon ID

> 仅按reviewed宿主的ncbi_taxon_id分组

Current microbe aggregation uses positive TaxID. Per-enzyme signature/resolution and evidence-record identity remain separate. T5 route-step tuple aggregation is a different component and was not run.
