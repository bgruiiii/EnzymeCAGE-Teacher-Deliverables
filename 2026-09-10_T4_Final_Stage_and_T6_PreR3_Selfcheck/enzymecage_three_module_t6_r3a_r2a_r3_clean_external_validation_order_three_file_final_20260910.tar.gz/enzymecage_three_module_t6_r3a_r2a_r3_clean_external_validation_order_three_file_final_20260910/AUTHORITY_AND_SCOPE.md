# Authority and scope

Authority is the fixed two-member `t6_r3a_r2a_r3_teacher_authority_and_r2_local_audit_payload_20260910.tar.gz` (8697 bytes; SHA256 `05b9cbfc48001b602e88d522ec8b575b26dcae3abd11c58646e82212394955d9`) together with the fixed audited R2 result archive (128142 bytes; SHA256 `d765f930796cbcda3caf1678617838480347000274f659d19018392ecce679cc`).

Scope is delivery-only: preserve R2 scientific evidence and production/test content, correct external validation ordering, run real mutation checks, and return archive/identity/validation together. No model, network query, GPU, T6-R3, G7, C8-to-T5, service restart, production/database change, commit, push, or teacher message occurred.
