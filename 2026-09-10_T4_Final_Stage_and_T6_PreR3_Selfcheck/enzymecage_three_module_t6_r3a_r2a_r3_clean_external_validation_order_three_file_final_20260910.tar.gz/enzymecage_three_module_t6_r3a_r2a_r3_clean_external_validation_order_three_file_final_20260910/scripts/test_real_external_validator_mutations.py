#!/usr/bin/env python3
import csv,hashlib,json,os,shutil,subprocess,sys,tarfile,tempfile
from pathlib import Path
TASK="enzymecage_three_module_t6_r3a_r2a_r2_zero_model_compute_evidence_repackage_real_validator_closure_20260910";ROOT=Path("/usrdata/EnzymeCAGE_data/EnzymeCAGE-master");WS=Path("/usrdata/EnzymeCAGE_data/workspaces")/TASK;SRC=ROOT/"HPC_Returned_Result_Summaries"/TASK;VAL=WS/"real_external_validator.py";AUTH=ROOT/"HPC_Inputs/t6_r3a_r2a_r2_teacher_authority_and_r1_delivery_audit_payload_20260910.tar.gz";R1=ROOT/"HPC_Returned_Result_Summaries/enzymecage_three_module_t6_r3a_r2a_r1_teacher_taxid_grouping_raw_row_bytes_delivery_closure_20260910.tar.gz";R2A=ROOT/"HPC_Returned_Result_Summaries/enzymecage_three_module_t6_r3a_r2a_microbe_node_output_uid_map_fallback_host_signature_correction_20260909.tar.gz";RAW=ROOT/"HPC_Returned_Result_Summaries/enzymecage_three_module_t6_r3a_r1_uniprot_host_provenance_runtime_wiring_delivery_correction_20260909.tar.gz";MAP=ROOT/"HPC_Returned_Result_Summaries/enzymecage_m4b_c8_1_lookup_index_delta_review_dependency_payload_rerun1_20260820/_input_payload/enzymecage_m4b_c8_1_dependency_payload_20260820/inputs/uid_to_source/uid_to_source_keep_bacteria_fungi_archaea.csv";REPO=WS/"depending_exact_teacher_base"
def sha(p):
 h=hashlib.sha256()
 with open(p,"rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return h.hexdigest()
def refresh(d):
 for n in ("MANIFEST.files","MANIFEST.sha256"):(d/n).write_text("")
 names=sorted(p.relative_to(d).as_posix() for p in d.rglob('*') if p.is_file())
 (d/"MANIFEST.files").write_text("\n".join(names)+"\n")
 (d/"MANIFEST.sha256").write_text("\n".join(f"{sha(d/n)}  {n}" for n in names if n!="MANIFEST.sha256")+"\n")
def jmut(d,n,fn):p=d/n;x=json.loads(p.read_text());fn(x);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n")
def repack(src,out,skip=None):
 with tarfile.open(out,"w:gz") as w:
  for p in src.rglob('*'):
   rel=p.relative_to(src); 
   if skip and str(rel)==skip:continue
   w.add(p,arcname=src.name+"/"+str(rel),recursive=False)
cases=[]
mutations=[
("N01","remove authority member",{"V01"},"authority"),
("N02","repack R2A-R1 changing archive SHA",{"V02"},"r1"),
("N03","modify SOURCE_PATCH one byte",{"V04"},lambda d:(d/"SOURCE_PATCH.diff").write_bytes((d/"SOURCE_PATCH.diff").read_bytes()+b"\n")),
("N04","set M2 aggregate_count=2",{"V15"},lambda d:jmut(d,"TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json",lambda x:x["M2"].update(observed_aggregate_count=2))),
("N05","delete one M3 provenance count",{"V15"},lambda d:jmut(d,"TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json",lambda x:x["M3"].update(observed_per_enzyme_provenance_count=[1]))),
("N06","merge different-TaxID M4",{"V16"},lambda d:jmut(d,"TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json",lambda x:x["M4"].update(observed_aggregate_count=1,observed_organism_uids=["101"]))),
("N07","replace M4 with covered-by-test placeholder",{"V17"},lambda d:jmut(d,"TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json",lambda x:x.update(M4="covered by test"))),
("N08","restore stripped fallback hash",{"V10","V12"},lambda d:jmut(d,"MICROBE_NODE_PATH_F_UID_MAP_FALLBACK_OUTPUT.json",lambda x:x["host_evidence_records"][3].update(evidence_hash="76d8240ab704dc49deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef"))),
("N09","claim Q7X2D3 normalized_equal",{"V20"},lambda d:jmut(d,"Q7X2D3_LIVE_MAP_NAME_DIFFERENCE_REGRESSION.json",lambda x:x.update(normalized_equal=True))),
("N10","make recorded schema-positive invalid",{"V21"},lambda d:jmut(d,"GSCHEMA_HOST_EVIDENCE_VALIDATION.json",lambda x:x["records"][0].update(field_count=10,errors=[{"path":[],"message":"additional property"}]))),
("N11","change one matrix outcome to SKIP",{"V22"},lambda d:(lambda p:p.write_text(p.read_text().replace(",PASS,",",SKIP,",1)))(d/"FINAL_STAGED_TREE_TEST_MATRIX.csv")),
("N12","remove identity sidecar",{"V28"},"identity")]
for cid,desc,expected,action in mutations:
 with tempfile.TemporaryDirectory() as td:
  td=Path(td);pkg=td/TASK;shutil.copytree(SRC,pkg);auth=AUTH;r1=R1
  if action=="authority":
   unpack=td/"auth";unpack.mkdir();tarfile.open(AUTH,"r:gz").extractall(unpack);root=next(unpack.iterdir());victim=next(root.iterdir());victim.unlink();auth=td/"authority.tar.gz";repack(root,auth)
  elif action=="r1":
   unpack=td/"r1";unpack.mkdir();tarfile.open(R1,"r:gz").extractall(unpack);r1=td/"r1.tar.gz";repack(next(unpack.iterdir()),r1)
  elif callable(action):action(pkg)
  refresh(pkg);archive=td/(TASK+".tar.gz");repack(pkg,archive);identity=Path(str(archive)+".identity.txt");identity.write_text(json.dumps({"bytes":archive.stat().st_size,"sha256":sha(archive),"regular_files":sum(p.is_file() for p in pkg.rglob('*'))}))
  output=Path(str(archive)+".validation.txt");output.touch()
  if action=="identity":identity.unlink()
  cmd=[sys.executable,"-B",str(VAL),"--archive",str(archive),"--identity",str(identity),"--output",str(output),"--authority",str(auth),"--r2a-r1",str(r1),"--r2a-upstream",str(R2A),"--r3a-r1-raw-source",str(RAW),"--uid-map",str(MAP),"--staged-repo",str(REPO)];r=subprocess.run(cmd,text=True,capture_output=True);failed=set()
  if output.exists():
   for line in output.read_text().splitlines():
    x=json.loads(line)
    if x.get("status")=="FAIL":failed.add(x["gate_id"])
  ok=expected<=failed and r.returncode!=0;cases.append({"case_id":cid,"mutation":desc,"expected_failed_gates":sorted(expected),"actual_failed_gates":sorted(failed),"validator_exit":r.returncode,"stdout_sha256":hashlib.sha256(r.stdout.encode()).hexdigest(),"stderr_sha256":hashlib.sha256(r.stderr.encode()).hexdigest(),"pass":ok})
out={"cases":cases,"passed":sum(x["pass"] for x in cases),"total":len(cases),"all_pass":all(x["pass"] for x in cases)}; (SRC/"REAL_EXTERNAL_VALIDATOR_MUTATION_TEST.json").write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n");(SRC/"scripts/test_real_external_validator_mutations.py").write_bytes(Path(__file__).read_bytes());(SRC/"scripts/real_external_validator.py").write_bytes(VAL.read_bytes());print(json.dumps(out))
sys.exit(0 if out["all_pass"] else 1)
