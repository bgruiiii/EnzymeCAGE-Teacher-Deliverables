#!/usr/bin/env python3
import argparse,csv,hashlib,json,os,subprocess,sys,tarfile,tempfile
from pathlib import Path

TASK="enzymecage_three_module_t6_r3a_r2a_r2_zero_model_compute_evidence_repackage_real_validator_closure_20260910"
AUTH_SHA="7c49ead946d06e7ab7891f77504bef67ea99975fcddf150229a6d8cd3eae3c00"
R1_SHA="952038134e1edb55104bf114f4283783924cc0e5b7c7739be60f4987fd33e069"
R2A_SHA="2b9dcb66926a61e968906d8115fb4d21fe2cbaf90e2fe20d81f968a50b7bdea3"
RAW_SHA="e71545dd7b453b037066e6636156d8cbb947874b00b772c1f28bfdb7f3e03991"
MAP_SHA="7b92e8e625cb73f070c8e902687ea5bbdbf749f04a19828e550e3fe205684fe6"
PATCH_SHA="40dd1f16d64d941e747d7f96360bc3d4051eb8d3452d0d088ed37fe4620e8563"
INC_SHA="771e898220c81e21dde8e5530d2492bb9158fbb8e8b92455da5af890c0ebb5ac"
FULL_HASHES={"Q7X2D3":"c505737eb22edd299279254135e2573d37d48eb5e5153451efa04d7c7551b394","A0A075BSX9":"f4957c6d292336080f64c3efcdf76ce1c2e39d004127d2853c2fc29a46842a0e","A0A017SP50":"23e0607cbf4511c73e0d4121fc5cf28eeef05b26f3ad1efcbee485fd5ab5ab17","A0A011QK89":"8771b2ce46952500e255de1f1e9178d521421cbd0e96672f27db489f646246c7"}
OLD=["11aa85ae45a5f597","f62e59981012b95b","2db70c842c54d0f3","76d8240ab704dc49"]

def sha(p):
 h=hashlib.sha256()
 with open(p,"rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return h.hexdigest()
def safe_tar(p,expect_root=None):
 with tarfile.open(p,"r:gz") as t:
  roots=set(); regs=[]
  for m in t.getmembers():
   if m.name.startswith('/') or '..' in m.name.split('/') or m.issym() or m.islnk() or m.isdev() or m.isfifo():raise ValueError("unsafe member "+m.name)
   roots.add(m.name.split('/')[0]); regs += [m] if m.isfile() else []
  if len(roots)!=1 or (expect_root and roots!={expect_root}):raise ValueError("root mismatch")
  return next(iter(roots)),regs
def readj(p):return json.loads(Path(p).read_text())
def main():
 ap=argparse.ArgumentParser()
 for x in ("archive","identity","output","authority","r2a_r1","r2a_upstream","r3a_r1_raw_source","uid_map","staged_repo"):ap.add_argument("--"+x.replace('_','-'),dest=x,required=True)
 a=ap.parse_args(); rows=[]
 def gate(i,fn,measured,expected,evidence,field,msg):
  try: ok=bool(fn()); err=""
  except Exception as e:ok=False;err=f"{type(e).__name__}: {e}"
  try: obs=measured() if callable(measured) else measured
  except Exception as e:obs={"measurement_error":f"{type(e).__name__}: {e}"}
  rows.append({"gate_id":f"V{i:02d}","status":"PASS" if ok else "FAIL","measured":obs,"expected":expected,"evidence_file":evidence,"evidence_field_or_line":field,"message":msg+("" if not err else "; "+err)})
 with tempfile.TemporaryDirectory() as td:
  root,regs=safe_tar(a.archive,TASK); tarfile.open(a.archive,"r:gz").extractall(td); d=Path(td)/TASK
  gate(1,lambda:safe_tar(a.authority)[1] and Path(a.authority).stat().st_size==23337 and sha(a.authority)==AUTH_SHA and readj(d/"INPUT_IDENTITY_DETAILS.json")["authority_members_verified"],lambda:{"bytes":Path(a.authority).stat().st_size,"sha256":sha(a.authority)},"23337 bytes, fixed SHA, 4 fixed members","INPUT_IDENTITY_DETAILS.json","authority_members_verified","authority safety and identities")
  gate(2,lambda:len(safe_tar(a.r2a_r1)[1])==39 and sha(a.r2a_r1)==R1_SHA and readj(d/"INPUT_IDENTITY_DETAILS.json")["r2a_r1_manifest_verified"],lambda:{"files":len(safe_tar(a.r2a_r1)[1]),"sha256":sha(a.r2a_r1)},"39 files, 38/38 manifest, fixed SHA","INPUT_IDENTITY_DETAILS.json","r2a_r1_manifest_verified","R2A-R1 upstream archive")
  replay=readj(d/"FINAL_CODE_TREE_REBUILD_AND_NONMUTATION.json")
  gate(3,lambda:replay["base_commit_match"] and replay["base_tree_match"] and replay["source_patch_clean_apply"],replay,"base commit/tree and clean apply","FINAL_CODE_TREE_REBUILD_AND_NONMUTATION.json","base_*","teacher base replay")
  gate(4,lambda:sha(d/"SOURCE_PATCH.diff")==PATCH_SHA and sha(d/"R2A_R1_INCREMENTAL_PATCH.diff")==INC_SHA and replay["final_tree_file_equivalence"],lambda:{"source":sha(d/"SOURCE_PATCH.diff"),"incremental":sha(d/"R2A_R1_INCREMENTAL_PATCH.diff")},"fixed patch SHA and equivalent final files","PATCH_REAPPLICATION_AND_SCOPE_GATES.json","patch_sha/final_equivalence","fixed patches")
  gate(5,lambda:readj(d/"PERSISTENT_SOURCE_NONMUTATION.json")["code_content_preserved_from_r2a_r1"] and replay["source_test_edits_this_round"]==[],lambda:replay["source_test_edits_this_round"],"[]","PERSISTENT_SOURCE_NONMUTATION.json","code_content_preserved_from_r2a_r1","no R2 source/test edits")
  g1=list(csv.DictReader((d/"TEACHER_G1_FILES_PRE_POST_IDENTITY.csv").open()))
  gate(6,lambda:g1 and all(x["equal"]=="true" for x in g1),lambda:{x["path"]:x["equal"] for x in g1},"all true","TEACHER_G1_FILES_PRE_POST_IDENTITY.csv","equal","graph/state/router/edge/G1 identities")
  preserved=list(csv.DictReader((d/"R2A_PRESERVED_SOURCE_IDENTITIES.csv").open()))
  gate(7,lambda:{x["path"] for x in preserved}>={"src/nodes/microbe_selection_node.py","src/schemas/evidence.py"} and all(x["equal"]=="true" for x in preserved),lambda:preserved,"independent R2A vs final equal","R2A_PRESERVED_SOURCE_IDENTITIES.csv","equal","node/schema preservation")
  inc=list(csv.DictReader((d/"R2A_TO_R2A_R1_INCREMENTAL_CHANGED_FILES.csv").open())); cum=list(csv.DictReader((d/"TEACHER_BASE_TO_FINAL_CUMULATIVE_CHANGED_FILES.csv").open()))
  gate(8,lambda:len(inc)==7 and len(cum)==28,lambda:{"incremental":len(inc),"cumulative":len(cum)},"7 and 28","R2A_TO_R2A_R1_INCREMENTAL_CHANGED_FILES.csv","row counts","changed sets separated")
  banned={"R3A_R1_BASELINE_REBUILD_AND_APPLY.json","_internal_phase01_input_identity.json"}; top={p.name for p in d.iterdir() if p.is_file()}; text="\n".join(p.read_text(errors="ignore") for p in d.iterdir() if p.is_file() and p.suffix not in (".diff",))
  gate(9,lambda:not(top&banned) and "分组合并主键=宿主 identity source_signature" not in text,lambda:sorted(top&banned),"none","MANIFEST.files","top-level files","no stale current reports/semantics")
  gate(10,lambda:not any(x in text for x in OLD),lambda:[x for x in OLD if x in text],"none in current top level","RAW_CSV_LINE_BYTES_HASH_INDEPENDENT_RECOMPUTATION.json","rows","no stripped hashes")
  L,F,U=map(readj,[d/"MICROBE_NODE_PATH_L_LIVE_REVIEWED_OUTPUT.json",d/"MICROBE_NODE_PATH_F_UID_MAP_FALLBACK_OUTPUT.json",d/"MICROBE_NODE_PATH_U_UNRESOLVED_OUTPUT.json"])
  gate(11,lambda:len(L["organism_candidates"])==4 and len(L["node_evidence_data"]["unresolved_host_ledger"])==0 and set(L["route_by_uid_in_records"].values())=={"LIVE_UNIPROT_REVIEWED"},lambda:{"candidates":len(L["organism_candidates"]),"routes":L["route_by_uid_in_records"]},"4 live, 0 unresolved","MICROBE_NODE_PATH_L_LIVE_REVIEWED_OUTPUT.json","route_by_uid_in_records","Path L")
  fh={r["enzyme_uid"]:r["evidence_hash"] for r in F["host_evidence_records"]}
  gate(12,lambda:len(F["organism_candidates"])==4 and fh==FULL_HASHES and all(not x["carries_live_reviewed_evidence"] for o in F["organism_candidates"] for x in o["per_enzyme_identity"]),lambda:{"candidates":len(F["organism_candidates"]),"hashes":fh},FULL_HASHES,"MICROBE_NODE_PATH_F_UID_MAP_FALLBACK_OUTPUT.json","host_evidence_records","Path F")
  tp=readj(d/"THREE_PATH_CURRENT_MEASUREMENTS.json")
  gate(13,lambda:len(U["organism_candidates"])==0 and len(U["node_evidence_data"]["unresolved_host_ledger"])==4 and U["cache_stats_after_node"]["scan_count"]==0 and tp["ABSENT"]["pass"],lambda:{"U_candidates":len(U["organism_candidates"]),"U_ledger":len(U["node_evidence_data"]["unresolved_host_ledger"]),"ABSENT":tp["ABSENT"]},"0/4/no scan and ABSENT exact","THREE_PATH_CURRENT_MEASUREMENTS.json","U/ABSENT","Path U/ABSENT")
  gate(14,lambda:all(all(v==0 for v in x["conversion_mapper_call_delta"].values()) for x in (L,F,U)),lambda:[x["conversion_mapper_call_delta"] for x in (L,F,U)],"all zero","MICROBE_NODE_THREE_PATH_TEST_OUTPUT.txt","conversion deltas","node-output-only conversion")
  M=readj(d/"TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json")
  gate(15,lambda:all(M[k]["pass"] and M[k]["observed_aggregate_count"]==1 and M[k]["observed_per_enzyme_provenance_count"]==[2] and M[k]["observed_aggregate_signatures"]==[None] for k in ("M2","M3")),lambda:{k:{x:M[k][x] for x in ("observed_aggregate_count","observed_per_enzyme_provenance_count","observed_aggregate_signatures")} for k in ("M2","M3")},"one each, null signature, two provenance","TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json","M2/M3","TaxID grouping and conflicts")
  gate(16,lambda:M["M4"]["pass"] and M["M4"]["observed_aggregate_count"]==2 and len(set(M["M4"]["observed_organism_uids"]))==2 and M["M5"]["pass"] and len(set(M["M5"]["observed_organism_uids"]))==len(M["M5"]["observed_organism_uids"]),lambda:{k:M[k] for k in ("M4","M5")},"two distinct TaxIDs and unique UIDs","TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json","M4/M5","different TaxID and UID invariants")
  gate(17,lambda:set(M)=={f"M{i}" for i in range(1,9)} and all(isinstance(v,dict) and v.get("pass") is True and "covered by test" not in json.dumps(v) for v in M.values()),lambda:{k:v.get("pass") for k,v in M.items()},"8 measured objects pass","TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json","M1-M8","all measured")
  fm=readj(d/"FROZEN_UID_MAP_IDENTITY_AND_CACHE_TEST.json")
  gate(18,lambda:sha(a.uid_map)==MAP_SHA and Path(a.uid_map).stat().st_size==104025134 and fm["all_pass"],lambda:{"bytes":Path(a.uid_map).stat().st_size,"sha":sha(a.uid_map),"report":fm["all_pass"]},"fixed identity and all gates","FROZEN_UID_MAP_IDENTITY_AND_CACHE_TEST.json","all_pass","UID map")
  raw=readj(d/"RAW_CSV_LINE_BYTES_HASH_INDEPENDENT_RECOMPUTATION.json")
  gate(19,lambda:all(x["pass"] for x in raw["real_rows"].values()) and all(x["pass"] for x in raw["production_reader_fixtures"].values()),lambda:{"real":{k:v["pass"] for k,v in raw["real_rows"].items()},"fixtures":{k:v["pass"] for k,v in raw["production_reader_fixtures"].items()}},"all true","RAW_CSV_LINE_BYTES_HASH_INDEPENDENT_RECOMPUTATION.json","real_rows/production_reader_fixtures","raw bytes")
  q=readj(d/"Q7X2D3_LIVE_MAP_NAME_DIFFERENCE_REGRESSION.json")
  gate(20,lambda:q["pass"] and q["normalized_equal"] is False and "normalized_equal" not in q["actual_warning"],lambda:q,"false/match/required warning","Q7X2D3_LIVE_MAP_NAME_DIFFERENCE_REGRESSION.json","pass","name disclosure")
  gs=readj(d/"GSCHEMA_HOST_EVIDENCE_VALIDATION.json")
  gate(21,lambda:gs["positive_pass_count"]==8 and gs["negative_rejected_count"]==12 and all(x["pass"] and x["field_count"]==9 and x["errors"]==[] for x in gs["records"]) and all(x["pass"] and x["validation_error_message"] for x in gs["negative_cases"]),lambda:{"positive":gs["positive_pass_count"],"negative":gs["negative_rejected_count"],"validator":gs["validator_class"]},"8 and 12 via Draft202012","GSCHEMA_HOST_EVIDENCE_VALIDATION.json","records/negative_cases","real schema validation")
  matrix=list(csv.DictReader((d/"FINAL_STAGED_TREE_TEST_MATRIX.csv").open())); summary=readj(d/"TEST_MATRIX_SUMMARY.json")
  gate(22,lambda:len(matrix)==155 and all(x["outcome"]=="PASS" for x in matrix) and summary=={"suites":13,"tests":155,"pass":155,"fail":0,"error":0,"skip":0,"count_layers_closed":True},lambda:summary,"13/155/155/0/0/0 closed","TEST_MATRIX_SUMMARY.json","all fields","test matrix")
  ids=list(csv.DictReader((d/"INPUT_IDENTITIES.csv").open()))
  gate(23,lambda:len(ids)>=16 and all(x["status"]=="VERIFIED_MATCH" for x in ids),lambda:{"rows":len(ids),"statuses":sorted(set(x["status"] for x in ids))},">=16 all VERIFIED_MATCH","INPUT_IDENTITIES.csv","status","input coverage")
  logs=[json.loads(x) for x in (d/"COMMAND_LOG.txt").read_text().splitlines() if x.strip()]
  gate(24,lambda:len(logs)>=17 and all(set(x)>={"utc_start","utc_end","cwd","argv","exit_code","output_sha256","purpose"} for x in logs),lambda:{"rows":len(logs)},">=17 structured rows","COMMAND_LOG.txt","JSONL fields","command log")
  status=(d/"FINAL_STATUS.txt").read_text(); draft=(d/"HUANG_TEACHER_8001_ENTRYTYPE_MICROBE_NODE_FALLBACK_SIGNATURE_SELFCHECK_DRAFT.md").read_text(); readme=(d/"README.md").read_text()
  gate(25,lambda:"DRAFT / NOT SENT" in draft and "T6_R3_EXECUTED=false" in status and "T6_OVERALL_READY=false" in status and "28" in readme,lambda:{"draft":draft.splitlines()[0],"status_tail":status.splitlines()[-5:]},"consistent not-sent/not-run","FINAL_STATUS.txt","status constants","docs consistency")
  pn=readj(d/"PERSISTENT_SOURCE_NONMUTATION.json")
  gate(26,lambda:all(v is False for k,v in pn.items() if k!="code_content_preserved_from_r2a_r1") and pn["code_content_preserved_from_r2a_r1"],lambda:pn,"all prohibited actions false","PERSISTENT_SOURCE_NONMUTATION.json","all fields","prohibited actions absent")
  listed=(d/"MANIFEST.files").read_text().splitlines(); actual=sorted(p.relative_to(d).as_posix() for p in d.rglob('*') if p.is_file()); hashes=[]
  for line in (d/"MANIFEST.sha256").read_text().splitlines():h,n=line.split("  ",1);hashes.append(sha(d/n)==h)
  try: ident=readj(a.identity)
  except Exception: ident={}
  gate(27,lambda:listed==actual and all(hashes) and len(hashes)==len(actual)-1 and ident.get("sha256")==sha(a.archive) and ident.get("bytes")==Path(a.archive).stat().st_size and ident.get("regular_files")==len(actual),lambda:{"files":len(actual),"sha_entries":len(hashes),"identity":ident},"manifest and actual archive identity","MANIFEST.files","coverage","archive integrity")
  sidecars=[Path(a.archive),Path(a.identity),Path(a.output)]
  gate(28,lambda:all(p.exists() and p.is_file() and not p.is_symlink() for p in sidecars) and all(str(p).startswith(str(Path(a.archive))) for p in sidecars),lambda:[str(p) for p in sidecars if p.exists()],"three same-basename regular files; fresh extraction",str(a.output),"closure","three-file closure")
 overall=all(x["status"]=="PASS" for x in rows); out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True)
 with out.open("w") as f:
  for x in rows:f.write(json.dumps(x,ensure_ascii=False,separators=(",",":"))+"\n")
  f.write(json.dumps({"summary":"formal_external_validation","pass":sum(x["status"]=="PASS" for x in rows),"fail":sum(x["status"]=="FAIL" for x in rows),"overall":"PASS" if overall else "FAIL"},separators=(",",":"))+"\n")
 return 0 if overall else 1
if __name__=="__main__":sys.exit(main())
