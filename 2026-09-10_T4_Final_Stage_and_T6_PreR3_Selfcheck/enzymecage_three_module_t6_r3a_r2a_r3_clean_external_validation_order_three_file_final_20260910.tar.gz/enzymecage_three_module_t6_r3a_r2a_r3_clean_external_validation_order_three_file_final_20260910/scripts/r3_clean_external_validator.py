#!/usr/bin/env python3
"""Independent two-phase validator for the R3 clean three-file closure."""
import argparse
import csv
import hashlib
import json
import os
import sys
import tarfile
import tempfile
from pathlib import Path

TASK = "enzymecage_three_module_t6_r3a_r2a_r3_clean_external_validation_order_three_file_final_20260910"
AUTH_BYTES = 8697
AUTH_SHA = "05b9cbfc48001b602e88d522ec8b575b26dcae3abd11c58646e82212394955d9"
R2_BYTES = 128142
R2_SHA = "d765f930796cbcda3caf1678617838480347000274f659d19018392ecce679cc"
PATCH_SHA = "40dd1f16d64d941e747d7f96360bc3d4051eb8d3452d0d088ed37fe4620e8563"
INC_SHA = "771e898220c81e21dde8e5530d2492bb9158fbb8e8b92455da5af890c0ebb5ac"
FULL_HASHES = {
    "Q7X2D3": "c505737eb22edd299279254135e2573d37d48eb5e5153451efa04d7c7551b394",
    "A0A075BSX9": "f4957c6d292336080f64c3efcdf76ce1c2e39d004127d2853c2fc29a46842a0e",
    "A0A017SP50": "23e0607cbf4511c73e0d4121fc5cf28eeef05b26f3ad1efcbee485fd5ab5ab17",
    "A0A011QK89": "8771b2ce46952500e255de1f1e9178d521421cbd0e96672f27db489f646246c7",
}
WHITELIST = {
    "README.md", "AUTHORITY_AND_SCOPE.md", "COMMAND_LOG.txt", "FINAL_STATUS.txt",
    "MANIFEST.files", "MANIFEST.sha256", "REAL_EXTERNAL_VALIDATOR_MUTATION_TEST.json",
    "scripts/real_external_validator.py", "scripts/test_real_external_validator_mutations.py",
    "scripts/delivery_builder.py",
}


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def safe_tar(path, expected_root=None):
    with tarfile.open(path, "r:gz") as tf:
        members = tf.getmembers()
        roots = set()
        regular = []
        for member in members:
            parts = member.name.split("/")
            if (not member.name or member.name.startswith("/") or ".." in parts or
                    not (member.isfile() or member.isdir())):
                raise ValueError("unsafe archive member: " + member.name)
            roots.add(parts[0])
            if member.isfile():
                regular.append(member)
        if len(roots) != 1:
            raise ValueError("archive does not have exactly one root")
        root = next(iter(roots))
        if expected_root and root != expected_root:
            raise ValueError(f"root mismatch: {root!r}")
        return root, regular


def extract_safe(path, destination, expected_root=None):
    root, regular = safe_tar(path, expected_root)
    with tarfile.open(path, "r:gz") as tf:
        tf.extractall(destination, filter="data")
    return Path(destination) / root, regular


def manifest_measure(package):
    listed = (package / "MANIFEST.files").read_text(encoding="utf-8").splitlines()
    actual = sorted(p.relative_to(package).as_posix() for p in package.rglob("*") if p.is_file())
    hash_rows = []
    for line in (package / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        hash_rows.append((name, digest, sha(package / name)))
    expected_hash_names = [name for name in actual if name != "MANIFEST.sha256"]
    ok = listed == actual and [x[0] for x in hash_rows] == expected_hash_names and all(a == b for _, a, b in hash_rows)
    return ok, {"listed": len(listed), "actual": len(actual), "sha_entries": len(hash_rows),
                "hash_mismatches": [name for name, expected, observed in hash_rows if expected != observed]}


def load_identity(path):
    try:
        return read_json(path)
    except Exception:
        return {}


def gate(rows, gate_id, check, measured, expected, evidence):
    error = None
    try:
        observed = measured() if callable(measured) else measured
        passed = bool(check(observed) if callable(check) else check)
    except Exception as exc:
        observed = {"measurement_error": f"{type(exc).__name__}: {exc}"}
        passed = False
        error = observed["measurement_error"]
    row = {"gate_id": gate_id, "status": "PASS" if passed else "FAIL", "measured": observed,
           "expected": expected, "evidence": evidence}
    if error:
        row["error"] = error
    rows.append(row)


def baseline_measure(package):
    rows = list(csv.DictReader((package / "R2_BASELINE_FILE_IDENTITIES.csv").open(encoding="utf-8")))
    mismatches = []
    checked = 0
    for row in rows:
        name = row["path"]
        if name in WHITELIST:
            continue
        checked += 1
        path = package / name
        if not path.is_file() or path.is_symlink() or str(path.stat().st_size) != row["bytes"] or sha(path) != row["sha256"]:
            mismatches.append(name)
    return {"baseline_rows": len(rows), "nonwhitelist_checked": checked, "mismatches": mismatches}


def evidence_measure(package):
    paths = read_json(package / "THREE_PATH_CURRENT_MEASUREMENTS.json")
    m = read_json(package / "TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json")
    return {
        "L_candidates": paths["L"]["candidate_count"], "L_unresolved": paths["L"]["unresolved"],
        "L_routes": sorted(set(paths["L"]["routes"].values())),
        "F_candidates": paths["F"]["candidate_count"], "F_unresolved": paths["F"]["unresolved"],
        "F_routes": sorted(set(paths["F"]["routes"].values())),
        "U_candidates": paths["U"]["candidate_count"], "U_unresolved": paths["U"]["unresolved"],
        "U_scan_count": paths["U"]["scan_count"], "ABSENT_pass": paths["ABSENT"]["pass"],
        "M_keys": sorted(m), "M_pass": {k: v.get("pass") for k, v in m.items()},
        "M2_aggregate_count": m["M2"].get("observed_aggregate_count"),
    }


def raw_measure(package):
    raw = read_json(package / "RAW_CSV_LINE_BYTES_HASH_INDEPENDENT_RECOMPUTATION.json")
    q = read_json(package / "Q7X2D3_LIVE_MAP_NAME_DIFFERENCE_REGRESSION.json")
    return {
        "real_hashes": {k: v.get("sha256") for k, v in raw["real_rows"].items()},
        "real_pass": sum(v.get("pass") is True for v in raw["real_rows"].values()),
        "fixture_pass": sum(v.get("pass") is True for v in raw["production_reader_fixtures"].values()),
        "normalized_equal": q.get("normalized_equal"), "q_pass": q.get("pass"),
    }


def schema_measure(package):
    data = read_json(package / "GSCHEMA_HOST_EVIDENCE_VALIDATION.json")
    return {"positive": data.get("positive_pass_count"), "negative": data.get("negative_rejected_count"),
            "records_valid": all(x.get("pass") is True and x.get("field_count") == 9 and x.get("errors") == [] for x in data.get("records", [])),
            "negatives_valid": all(x.get("pass") is True and x.get("validation_error_message") for x in data.get("negative_cases", []))}


def matrix_measure(package):
    matrix = list(csv.DictReader((package / "FINAL_STAGED_TREE_TEST_MATRIX.csv").open(encoding="utf-8")))
    summary = read_json(package / "TEST_MATRIX_SUMMARY.json")
    identities = list(csv.DictReader((package / "INPUT_IDENTITIES.csv").open(encoding="utf-8")))
    return {"matrix_rows": len(matrix), "matrix_pass": sum(x.get("outcome") == "PASS" for x in matrix),
            "summary": summary, "identity_rows": len(identities),
            "identity_verified": sum(x.get("status") == "VERIFIED_MATCH" for x in identities)}


def compute_pre(args, package, archive_regular, include_p12=True):
    rows = []
    gate(rows, "P01", lambda x: x == {"bytes": AUTH_BYTES, "sha256": AUTH_SHA, "regular_files": 2, "root": "t6_r3a_r2a_r3_teacher_authority_and_r2_local_audit_payload_20260910"},
         lambda: {"bytes": Path(args.authority).stat().st_size, "sha256": sha(args.authority),
                  "regular_files": len(safe_tar(args.authority)[1]), "root": safe_tar(args.authority)[0]},
         "fixed authority bytes/SHA, single root, 2 regular files", args.authority)
    gate(rows, "P02", lambda x: x == {"bytes": R2_BYTES, "sha256": R2_SHA, "regular_files": 44,
                                      "root": "enzymecage_three_module_t6_r3a_r2a_r2_zero_model_compute_evidence_repackage_real_validator_closure_20260910"},
         lambda: {"bytes": Path(args.r2_archive).stat().st_size, "sha256": sha(args.r2_archive),
                  "regular_files": len(safe_tar(args.r2_archive)[1]), "root": safe_tar(args.r2_archive)[0]},
         "fixed R2 bytes/SHA, single root, 44 regular files", args.r2_archive)
    gate(rows, "P03", lambda x: x["root"] == TASK and x["regular_files"] >= 48,
         {"root": package.name, "regular_files": len(archive_regular)}, "safe single root and expected R3 root", args.archive)
    gate(rows, "P04", lambda x: x[0], lambda: manifest_measure(package), "manifest exact coverage and all hashes match", "MANIFEST.files/MANIFEST.sha256")
    gate(rows, "P05", lambda x: x["baseline_rows"] == 44 and x["nonwhitelist_checked"] == 34 and not x["mismatches"],
         lambda: baseline_measure(package), "44 R2 baselines; 34 nonwhitelist byte-identical", "R2_BASELINE_FILE_IDENTITIES.csv")
    gate(rows, "P06", lambda x: x["L_candidates"] == 4 and x["L_unresolved"] == 0 and x["L_routes"] == ["LIVE_UNIPROT_REVIEWED"] and
                              x["F_candidates"] == 4 and x["F_unresolved"] == 0 and x["F_routes"] == ["FROZEN_REVIEWED_UID_MAP_FALLBACK"] and
                              x["U_candidates"] == 0 and x["U_unresolved"] == 4 and x["U_scan_count"] == 0 and x["ABSENT_pass"] is True,
         lambda: evidence_measure(package), "Path L=4, F=4, U=0/4/no scan, ABSENT pass", "THREE_PATH_CURRENT_MEASUREMENTS.json")
    gate(rows, "P07", lambda x: x["M_keys"] == [f"M{i}" for i in range(1, 9)] and all(x["M_pass"].values()) and x["M2_aggregate_count"] == 1,
         lambda: evidence_measure(package), "M1-M8 measured objects pass; M2 aggregate_count=1", "TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json")
    gate(rows, "P08", lambda x: x["real_hashes"] == FULL_HASHES and x["real_pass"] == 4 and x["fixture_pass"] == 5 and x["normalized_equal"] is False and x["q_pass"] is True,
         lambda: raw_measure(package), "4/4 fixed raw hashes, 5/5 fixtures, Q7X2D3 normalized_equal=false", "RAW_CSV.../Q7X2D3...")
    gate(rows, "P09", lambda x: x == {"positive": 8, "negative": 12, "records_valid": True, "negatives_valid": True},
         lambda: schema_measure(package), "G-SCHEMA positives 8/8 and negatives 12/12", "GSCHEMA_HOST_EVIDENCE_VALIDATION.json")
    gate(rows, "P10", lambda x: x["matrix_rows"] == 155 and x["matrix_pass"] == 155 and
                              x["summary"] == {"suites": 13, "tests": 155, "pass": 155, "fail": 0, "error": 0, "skip": 0, "count_layers_closed": True} and
                              x["identity_rows"] == 20 and x["identity_verified"] == 20 and
                              sha(package / "SOURCE_PATCH.diff") == PATCH_SHA and sha(package / "R2A_R1_INCREMENTAL_PATCH.diff") == INC_SHA,
         lambda: matrix_measure(package), "155/155, 13 suites, 20/20 identities, fixed patch SHAs", "matrix/input identities/patches")
    ident = load_identity(args.identity)
    gate(rows, "P11", lambda x: x.get("archive") == str(Path(args.archive).resolve()) and x.get("bytes") == Path(args.archive).stat().st_size and
                              x.get("sha256") == sha(args.archive) and x.get("root") == TASK and x.get("regular_files") == len(archive_regular) and
                              isinstance(x.get("run_id"), str) and isinstance(x.get("nonce"), str),
         ident, "identity agrees with on-disk archive bytes/SHA/root/files and contains run-id/nonce", args.identity)
    if include_p12:
        validation = Path(args.validation)
        candidates = [validation] + [Path(str(validation) + suffix) for suffix in (".tmp", ".partial", ".failed", ".bak")]
        gate(rows, "P12", lambda x: not any(x.values()), lambda: {str(p): (p.exists() or p.is_symlink()) for p in candidates},
             "validation and same-basename temp paths absent before first write", args.validation)
    return rows


def parse_validation(path):
    records = []
    values = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line:
            continue
        if line.startswith("{"):
            records.append(json.loads(line))
        elif "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    return records, values


def compute_post(args, package, archive_regular):
    rows = []
    archive, identity, validation = map(Path, (args.archive, args.identity, args.validation))
    gate(rows, "Q01", lambda x: all(x.values()), lambda: {str(p): p.exists() for p in (archive, identity, validation)}, "all three files exist", "external three files")
    gate(rows, "Q02", lambda x: all(v["regular"] and not v["symlink"] and v["bytes"] > 0 for v in x.values()) and
                              str(identity) == str(archive) + ".identity.txt" and str(validation) == str(archive) + ".validation.txt",
         lambda: {str(p): {"regular": p.is_file(), "symlink": p.is_symlink(), "bytes": p.stat().st_size if p.exists() else 0} for p in (archive, identity, validation)},
         "regular non-symlink, nonempty, same basename", "external three files")
    ident = load_identity(identity)
    gate(rows, "Q03", lambda x: x.get("bytes") == archive.stat().st_size and x.get("sha256") == sha(archive), ident,
         "archive bytes/SHA equal identity", args.identity)
    gate(rows, "Q04", lambda x: x[0], lambda: manifest_measure(package), "fresh extraction safe single-root and manifest passes", "U2 archive extraction")
    pre11 = compute_pre(args, package, archive_regular, include_p12=False)
    gate(rows, "Q05", lambda x: x["pass"] == 11 and x["fail"] == 0,
         {"pass": sum(r["status"] == "PASS" for r in pre11), "fail": sum(r["status"] == "FAIL" for r in pre11),
          "failed_gates": [r["gate_id"] for r in pre11 if r["status"] != "PASS"]}, "P01-P11 recompute PASS", "fresh U2 recomputation")
    try:
        records, values = parse_validation(validation)
    except Exception:
        records, values = [], {}
    p_records = [r for r in records if str(r.get("gate_id", "")).startswith("P")]
    gate(rows, "Q06", lambda x: x["ids"] == [f"P{i:02d}" for i in range(1, 13)] and x["all_pass"],
         {"ids": [r.get("gate_id") for r in p_records], "all_pass": len(p_records) == 12 and all(r.get("status") == "PASS" for r in p_records)},
         "exactly P01-P12, ordered, all PASS", args.validation)
    p12 = next((r for r in p_records if r.get("gate_id") == "P12"), {})
    gate(rows, "Q07", lambda x: x.get("status") == "PASS" and x.get("measured") and not any(x["measured"].values()), p12,
         "P12 explicitly proves validation/temp paths absent before write", args.validation)
    meta = next((r for r in records if r.get("record_type") == "prewrite_meta"), {})
    gate(rows, "Q08", lambda x: x.get("run_id") == ident.get("run_id") and x.get("nonce") == ident.get("nonce") and
                              x.get("archive_sha256") == ident.get("sha256") and x.get("identity_sha256") == sha(identity), meta,
         "validation run-id/nonce/archive/identity match this run", args.validation)
    gate(rows, "Q09", lambda x: x == {"current_archive": str(archive.resolve()), "current_identity": str(identity.resolve()),
                                      "current_validation": str(validation.resolve()), "current_validation_source": str(validation.resolve())},
         {k: meta.get(k) for k in ("current_archive", "current_identity", "current_validation", "current_validation_source")},
         "current validation references only current same-basename sidecars", args.validation)
    status = (package / "FINAL_STATUS.txt").read_text(encoding="utf-8")
    gate(rows, "Q10", lambda x: x.startswith("T6_R3A_R2A_R3_CONTENT_READY_FOR_EXTERNAL_VALIDATION\n") and
                              "EXTERNAL_VALIDATION=PENDING_AT_ARCHIVE_TIME" in x and "EXTERNAL_THREE_FILE_DELIVERY=PENDING_AT_ARCHIVE_TIME" in x and
                              "PASS_28_OF_28" not in x and "EXTERNAL_THREE_FILE_DELIVERY=PASS" not in x,
         status, "archive-internal status is CONTENT_READY/PENDING and does not forge external PASS", "FINAL_STATUS.txt")
    return rows


def summarize(phase, rows):
    return {"phase": phase, "gates": rows, "pass": sum(r["status"] == "PASS" for r in rows),
            "fail": sum(r["status"] == "FAIL" for r in rows),
            "failed_gates": [r["gate_id"] for r in rows if r["status"] != "PASS"],
            "overall": "PASS" if all(r["status"] == "PASS" for r in rows) else "FAIL"}


def final_readonly(args, package, archive_regular):
    records, values = parse_validation(args.validation)
    p = [r for r in records if str(r.get("gate_id", "")).startswith("P")]
    q = [r for r in records if str(r.get("gate_id", "")).startswith("Q")]
    manifest_ok, manifest = manifest_measure(package)
    ident = load_identity(args.identity)
    checks = {
        "archive_safe_root": package.name == TASK,
        "archive_identity": ident.get("bytes") == Path(args.archive).stat().st_size and ident.get("sha256") == sha(args.archive) and ident.get("regular_files") == len(archive_regular),
        "manifest": manifest_ok,
        "p_12_of_12": len(p) == 12 and all(r.get("status") == "PASS" for r in p),
        "q_10_of_10": len(q) == 10 and all(r.get("status") == "PASS" for r in q),
        "postwrite": values.get("POSTWRITE") == "PASS_10_OF_10",
        "overall": values.get("OVERALL") == "PASS",
        "external_status": values.get("EXTERNAL_STATUS") == "T6_R3A_R2A_R3_CLEAN_EXTERNAL_CLOSURE_READY_FOR_LOCAL_AUDIT",
        "three_file_delivery": values.get("EXTERNAL_THREE_FILE_DELIVERY") == "PASS",
    }
    return {"phase": "final-readonly", "checks": checks, "manifest": manifest,
            "overall": "PASS" if all(checks.values()) else "FAIL"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", required=True, choices=("pre-write", "post-write", "final-readonly"))
    for name in ("archive", "identity", "validation", "authority", "r2_archive"):
        parser.add_argument("--" + name.replace("_", "-"), dest=name, required=True)
    args = parser.parse_args()
    try:
        with tempfile.TemporaryDirectory(prefix="r3-clean-validator-") as temp:
            package, regular = extract_safe(args.archive, temp, TASK)
            if args.phase == "pre-write":
                result = summarize(args.phase, compute_pre(args, package, regular, include_p12=True))
            elif args.phase == "post-write":
                result = summarize(args.phase, compute_post(args, package, regular))
            else:
                result = final_readonly(args, package, regular)
    except Exception as exc:
        result = {"phase": args.phase, "overall": "FAIL", "fatal": f"{type(exc).__name__}: {exc}"}
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result.get("overall") == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
