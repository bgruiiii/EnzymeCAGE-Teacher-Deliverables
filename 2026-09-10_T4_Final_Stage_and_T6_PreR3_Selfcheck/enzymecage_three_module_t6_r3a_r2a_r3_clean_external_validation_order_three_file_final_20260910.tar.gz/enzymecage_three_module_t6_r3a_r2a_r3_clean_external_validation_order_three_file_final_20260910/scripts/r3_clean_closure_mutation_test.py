#!/usr/bin/env python3
"""Twelve fresh-directory negative tests plus a clean no-precreated-validation chain."""
import argparse
import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import uuid
from pathlib import Path


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def safe_extract(archive, destination):
    with tarfile.open(archive, "r:gz") as tf:
        members = tf.getmembers()
        for member in members:
            if member.name.startswith("/") or ".." in member.name.split("/") or not (member.isfile() or member.isdir()):
                raise ValueError(member.name)
        tf.extractall(destination, filter="data")
    roots = [p for p in Path(destination).iterdir() if p.is_dir()]
    if len(roots) != 1:
        raise ValueError("single root required")
    return roots[0]


def manifest(package):
    files = sorted(p.relative_to(package).as_posix() for p in package.rglob("*") if p.is_file())
    (package / "MANIFEST.files").write_text("".join(x + "\n" for x in files), encoding="utf-8")
    files = sorted(p.relative_to(package).as_posix() for p in package.rglob("*") if p.is_file())
    lines = [f"{sha(package / name)}  {name}\n" for name in files if name != "MANIFEST.sha256"]
    (package / "MANIFEST.sha256").write_text("".join(lines), encoding="utf-8")


def pack(package, archive):
    with tarfile.open(archive, "w:gz") as tf:
        tf.add(package, arcname=package.name)


def identity(archive, package, path, bad=False):
    regular = sum(p.is_file() for p in package.rglob("*"))
    data = {"archive": str(archive.resolve()), "bytes": archive.stat().st_size,
            "sha256": "0" * 64 if bad else sha(archive), "root": package.name,
            "regular_files": regular, "run_id": "mutation-" + uuid.uuid4().hex,
            "nonce": uuid.uuid4().hex}
    path.write_text(json.dumps(data, sort_keys=True) + "\n", encoding="utf-8")


def command(args, phase, archive, ident, validation):
    return [sys.executable, "-B", args.validator, "--phase", phase, "--archive", str(archive),
            "--identity", str(ident), "--validation", str(validation), "--authority", args.authority,
            "--r2-archive", args.r2_archive]


def invoke(cmd):
    cp = subprocess.run(cmd, text=True, capture_output=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    try:
        result = json.loads(cp.stdout)
    except Exception:
        result = {"failed_gates": [], "overall": "FAIL", "unparsed": True}
    return cp, result


def mutate_json(path, callback):
    data = json.loads(path.read_text(encoding="utf-8"))
    callback(data)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def alter_validation(path, case):
    lines = path.read_text(encoding="utf-8").splitlines()
    if case == "N10":
        removed = False
        output = []
        for line in lines:
            if not removed and line.startswith("{") and json.loads(line).get("gate_id") == "P06":
                removed = True
                continue
            output.append(line)
        lines = output
    elif case == "N11":
        output = []
        for line in lines:
            if line.startswith("{"):
                row = json.loads(line)
                if row.get("gate_id") == "P12":
                    first = next(iter(row["measured"]))
                    row["measured"][first] = True
                    line = json.dumps(row, ensure_ascii=False, sort_keys=True)
            output.append(line)
        lines = output
    elif case == "N12":
        output = []
        for line in lines:
            if line.startswith("{"):
                row = json.loads(line)
                if row.get("record_type") == "prewrite_meta":
                    row["current_validation_source"] = "/failed_round/old_r2_archive.validation.txt"
                    line = json.dumps(row, ensure_ascii=False, sort_keys=True)
            output.append(line)
        lines = output
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    for name in ("base_archive", "authority", "r2_archive", "validator", "closure", "output"):
        parser.add_argument("--" + name.replace("_", "-"), dest=name, required=True)
    args = parser.parse_args()
    definitions = {
        "N01": ("prewrite empty validation", ["P12"]), "N02": ("missing identity", ["P11"]),
        "N03": ("identity SHA mismatch", ["P11"]), "N04": ("tampered archive member", ["P04", "P05"]),
        "N05": ("M2 aggregate_count=2", ["P07"]), "N06": ("fallback raw hash restored to old value", ["P08"]),
        "N07": ("G-SCHEMA positive invalid", ["P09"]), "N08": ("matrix row SKIP", ["P10"]),
        "N09": ("postwrite validation deleted", ["Q01", "Q02"]), "N10": ("validation missing P gate", ["Q06"]),
        "N11": ("P12 forged as pre-existing", ["Q07"]), "N12": ("old failed-round sidecar referenced", ["Q09"]),
    }
    cases = []
    with tempfile.TemporaryDirectory(prefix="r3-mutations-") as temp_root:
        temp_root = Path(temp_root)
        for case_id, (description, expected) in definitions.items():
            case_dir = temp_root / case_id
            case_dir.mkdir()
            package = safe_extract(args.base_archive, case_dir / "extract")
            archive = case_dir / (package.name + ".tar.gz")
            ident = Path(str(archive) + ".identity.txt")
            validation = Path(str(archive) + ".validation.txt")
            post_case = case_id >= "N09"
            if case_id == "N04":
                p = package / "THREE_PATH_CURRENT_MEASUREMENTS.json"
                p.write_bytes(p.read_bytes() + b" ")
            elif case_id == "N05":
                mutate_json(package / "TEACHER_NCBI_TAXID_MICROBE_AGGREGATION_REGRESSION.json", lambda x: x["M2"].update(observed_aggregate_count=2))
                manifest(package)
            elif case_id == "N06":
                mutate_json(package / "RAW_CSV_LINE_BYTES_HASH_INDEPENDENT_RECOMPUTATION.json", lambda x: x["real_rows"]["Q7X2D3"].update(sha256="11aa85ae45a5f597"))
                manifest(package)
            elif case_id == "N07":
                mutate_json(package / "GSCHEMA_HOST_EVIDENCE_VALIDATION.json", lambda x: x.update(positive_pass_count=7))
                manifest(package)
            elif case_id == "N08":
                rows = list(csv.DictReader((package / "FINAL_STAGED_TREE_TEST_MATRIX.csv").open(encoding="utf-8")))
                rows[0]["outcome"] = "SKIP"
                with (package / "FINAL_STAGED_TREE_TEST_MATRIX.csv").open("w", encoding="utf-8", newline="") as f:
                    writer = csv.DictWriter(f, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
                manifest(package)
            pack(package, archive)
            if case_id != "N02":
                identity(archive, package, ident, bad=(case_id == "N03"))
            if case_id == "N01":
                validation.touch(exist_ok=False)
            if post_case:
                clean_cmd = [sys.executable, "-B", args.closure, "--archive", str(archive), "--identity", str(ident),
                             "--validation", str(validation), "--authority", args.authority, "--r2-archive", args.r2_archive,
                             "--validator", args.validator, "--readonly-log", str(case_dir / "clean.readonly.json")]
                clean = subprocess.run(clean_cmd, text=True, capture_output=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
                if clean.returncode != 0:
                    raise RuntimeError(f"clean setup failed for {case_id}: {clean.stdout} {clean.stderr}")
                if case_id == "N09":
                    validation.unlink()
                else:
                    alter_validation(validation, case_id)
                phase = "post-write"
            else:
                phase = "pre-write"
            cp, result = invoke(command(args, phase, archive, ident, validation))
            failed = result.get("failed_gates", [])
            passed = cp.returncode != 0 and all(gate in failed for gate in expected)
            cases.append({"case_id": case_id, "mutation": description, "validation_preexisted_at_case_start": case_id == "N01",
                          "expected_failed_gates": expected, "actual_failed_gates": failed, "validator_exit": cp.returncode,
                          "stdout_sha256": hashlib.sha256(cp.stdout.encode()).hexdigest(),
                          "stderr_sha256": hashlib.sha256(cp.stderr.encode()).hexdigest(), "pass": passed})
        clean_dir = temp_root / "CLEAN"
        clean_dir.mkdir()
        package = safe_extract(args.base_archive, clean_dir / "extract")
        archive = clean_dir / (package.name + ".tar.gz")
        pack(package, archive)
        ident = Path(str(archive) + ".identity.txt")
        validation = Path(str(archive) + ".validation.txt")
        identity(archive, package, ident)
        absent_at_start = not validation.exists()
        clean_cmd = [sys.executable, "-B", args.closure, "--archive", str(archive), "--identity", str(ident),
                     "--validation", str(validation), "--authority", args.authority, "--r2-archive", args.r2_archive,
                     "--validator", args.validator, "--readonly-log", str(clean_dir / "readonly.json")]
        clean = subprocess.run(clean_cmd, text=True, capture_output=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        clean_payload = json.loads(clean.stdout) if clean.stdout.strip().startswith("{") else {}
        clean_chain = {"validation_absent_at_start": absent_at_start, "validation_not_touched_before_prewrite": True,
                       "exit": clean.returncode, "pre_pass": clean_payload.get("pre"), "post_pass": clean_payload.get("post"),
                       "readonly_exit": clean_payload.get("readonly_exit"), "readonly": clean_payload.get("readonly"),
                       "stdout_sha256": hashlib.sha256(clean.stdout.encode()).hexdigest(),
                       "stderr_sha256": hashlib.sha256(clean.stderr.encode()).hexdigest(),
                       "pass": absent_at_start and clean.returncode == 0 and clean_payload.get("pre") == 12 and clean_payload.get("post") == 10 and clean_payload.get("readonly") == "PASS"}
    output = {"cases": cases, "mutations_pass": sum(x["pass"] for x in cases), "mutations_total": 12,
              "clean_chain": clean_chain, "overall": "PASS" if all(x["pass"] for x in cases) and clean_chain["pass"] else "FAIL"}
    Path(args.output).write_text(json.dumps(output, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"mutations": f"{output['mutations_pass']}/12", "clean_chain": clean_chain["pass"], "overall": output["overall"]}, sort_keys=True))
    return 0 if output["overall"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
