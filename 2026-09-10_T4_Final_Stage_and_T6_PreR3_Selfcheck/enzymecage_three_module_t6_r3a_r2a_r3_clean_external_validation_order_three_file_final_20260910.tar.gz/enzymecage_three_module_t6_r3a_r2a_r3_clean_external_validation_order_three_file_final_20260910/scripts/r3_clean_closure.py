#!/usr/bin/env python3
"""Run pre-write validation, exclusively create validation, then post-write and seal."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run_validator(args, phase):
    command = [sys.executable, "-B", args.validator, "--phase", phase,
               "--archive", args.archive, "--identity", args.identity,
               "--validation", args.validation, "--authority", args.authority,
               "--r2-archive", args.r2_archive]
    completed = subprocess.run(command, text=True, capture_output=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    try:
        payload = json.loads(completed.stdout)
    except Exception:
        payload = {"overall": "FAIL", "parse_error": True, "stdout": completed.stdout, "stderr": completed.stderr}
    return command, completed, payload


def main():
    parser = argparse.ArgumentParser()
    for name in ("archive", "identity", "validation", "authority", "r2_archive", "validator", "readonly_log"):
        parser.add_argument("--" + name.replace("_", "-"), dest=name, required=True)
    args = parser.parse_args()
    validation = Path(args.validation)
    if validation.exists() or validation.is_symlink():
        print("refusing to overwrite pre-existing validation", file=sys.stderr)
        return 1
    command, completed, pre = run_validator(args, "pre-write")
    if completed.returncode or pre.get("overall") != "PASS":
        print(json.dumps({"stage": "pre-write", "exit": completed.returncode, "result": pre}, ensure_ascii=False))
        return 1
    identity = json.loads(Path(args.identity).read_text(encoding="utf-8"))
    meta = {"record_type": "prewrite_meta", "run_id": identity["run_id"], "nonce": identity["nonce"],
            "archive_sha256": identity["sha256"], "identity_sha256": sha(args.identity),
            "current_archive": str(Path(args.archive).resolve()), "current_identity": str(Path(args.identity).resolve()),
            "current_validation": str(validation.resolve()), "validator_sha256": sha(args.validator),
            "validator_argv": command, "validator_exit": completed.returncode,
            "current_validation_source": str(validation.resolve())}
    with validation.open("x", encoding="utf-8") as output:
        for row in pre["gates"]:
            output.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        output.write(json.dumps(meta, ensure_ascii=False, sort_keys=True) + "\n")
        output.write("POSTWRITE=PENDING\nOVERALL=PENDING_POSTWRITE\n")
    command, completed, post = run_validator(args, "post-write")
    if completed.returncode or post.get("overall") != "PASS":
        print(json.dumps({"stage": "post-write", "exit": completed.returncode, "result": post}, ensure_ascii=False))
        return 1
    content = validation.read_text(encoding="utf-8")
    content = content.replace("POSTWRITE=PENDING\nOVERALL=PENDING_POSTWRITE\n", "")
    content += "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in post["gates"])
    content += ("POSTWRITE=PASS_10_OF_10\nOVERALL=PASS\n"
                "EXTERNAL_STATUS=T6_R3A_R2A_R3_CLEAN_EXTERNAL_CLOSURE_READY_FOR_LOCAL_AUDIT\n"
                "EXTERNAL_THREE_FILE_DELIVERY=PASS\n")
    fd, temp_name = tempfile.mkstemp(prefix=validation.name + ".atomic-", dir=validation.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            output.write(content)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp_name, validation)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
    command, completed, final = run_validator(args, "final-readonly")
    Path(args.readonly_log).write_text(json.dumps({"argv": command, "exit": completed.returncode, "result": final}, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"pre": pre["pass"], "post": post["pass"], "readonly_exit": completed.returncode,
                      "readonly": final.get("overall"), "validation_sha256": sha(validation)}, ensure_ascii=False, sort_keys=True))
    return 0 if completed.returncode == 0 and final.get("overall") == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
