# Patch scope

`SOURCE_PATCH.diff` and `R2A_R1_INCREMENTAL_PATCH.diff` are byte-preserved from the fixed R2A-R1 upstream. This R2 round makes no source or test changes; only evidence and delivery files are newly generated.
