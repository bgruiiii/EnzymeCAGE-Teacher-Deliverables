# Current frozen reviewed UID-map fallback

Final frozen code uses one identity-gated map scan and `os.pread`; SHA256 covers the untouched complete raw row including its observed CRLF terminator. Fallback never fabricates live fields and exact UID absence is unresolved.
