# T4-R4 clean external closure order and three-file final delivery
TASK_ID=enzymecage_three_module_t4_r4_clean_external_closure_order_three_file_final_20260910
CURRENT_PACKAGE_STAGE=T4-R4
CURRENT_DELIVERY_DATE_UTC=2026-09-10T06:28:51Z

R2/R3内容是继承背景，不是当前包身份：当前包是 T4-R4。本轮唯一变化是 clean closure 顺序、当前
README/AUTHORITY/FINAL_STATUS/COMMAND_LOG 与外置三文件（archive / .identity.txt / .validation.txt，
同一目录、同一 basename）。两个老师材料、V23 逻辑、预测、指标、重合、ECLIPSE 均逐字节冻结，见
`R3_BASELINE_FILE_IDENTITIES.csv`、`R3_TO_R4_CHANGED_FILES.csv` 与 `R3_CONTENT_NONMUTATION.json`。
T4 仍等待黄老师 A/B 裁定（草稿未发送、未上传）；T6 独立推进，不以本 T4 裁定为前置门。

## The three questions this round answers (prompt section 0)

A. **closure order fixed**. The R3 local audit showed a cycle: `scripts/r3_closure.py` asked the
   validator for `--require-validation-record` *before* the validation record could be written, so
   a genuinely fresh run could never pass and a resumed run could have leant on a leftover sidecar.
   `scripts/r4_clean_closure.py` removes the cycle: the pre-write gates may only require the
   archive and the identity, gate **P07 requires the record to be ABSENT**, the record is then
   written once with two pending markers, the post-write gates **Q01-Q08** run against a second
   fresh unpack, and only after all eight pass is the record rewritten once. A
   `--require-validation-record` flag does not exist anywhere in the R4 code.
B. **current identity in the README**. The header above is T4-R4. The R2 report below is demoted to
   an inherited-background section and the R3 section is relabelled HISTORICAL_SUPERSEDED, so this
   package can no longer read as R2 or R3 at the top.
C. **three physical files under a new TASK_ID** are produced for
   `enzymecage_three_module_t4_r4_clean_external_closure_order_three_file_final_20260910.tar.gz`, with the identity and the validation record both generated after the archive
   landed, from real `stat`/`sha256` of that landed archive and of fresh re-extractions of it.

## The order, as executed (prompt section 8)

```text
 1. six fresh-path gate                       logs/r4_freshgate.json   (nothing existed, nothing reused)
 2. copy the 64 R3 files byte-for-byte        R3_BASELINE_FILE_IDENTITIES.csv
 3. rerun V23 + its 8 mutations here          R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json
 4. rewrite README / AUTHORITY, this round    scripts/r4_p5_docs.py
 5. change table + nonmutation proof          R3_TO_R4_CHANGED_FILES.csv, R3_CONTENT_NONMUTATION.json
 6. closure order mutation test, 10 cases     R4_CLEAN_CLOSURE_ORDER_MUTATION_TEST.json
 7. MANIFEST.files + MANIFEST.sha256          scripts/r4_clean_closure.py --stage manifest
 8. content gates C01-C20 (+SUP21) run #1     scripts/r4_content_and_archive_validator.py --stage content
 9. in-archive FINAL_STATUS (11 lines, the external trio still pending)   --stage status
10. manifests regenerated, C01-C20 run #2     both must be all-PASS before any archive is created
11. ARCHIVE                                  tar, single root = TASK_ID, regular files only
12. fresh unpack U1 -> identity from the landed bytes
13. U1 gates C01-C20 + P01-P09 while NO record exists -> first atomic write (pending markers)
14. fresh unpack U2 -> Q01-Q08 over the three physical files -> one atomic rewrite (PASS_8_OF_8)
15. third independent read-only process (its command was pre-declared inside the record, so its
    exit code cannot be self-referential); stdout/stderr/exit land in logs/r4_final_readonly.log
```

## What was relocated instead of deleted (prompt section 4)

`scripts/r3_closure.py` and `scripts/r3_validator.py` are **HISTORICAL_SUPERSEDED**: they are the
defective closure order this round replaces. They were moved to `inherited_r3_closure_historical/`
unchanged (same SHA before and after the move, recorded in `R3_TO_R4_CHANGED_FILES.csv`), not
deleted, and they are not entry points of this package. The R4 entry points are

```text
scripts/r4_content_and_archive_validator.py   C01-C20 + SUP21, P01-P09, Q01-Q08, final read-only
scripts/r4_clean_closure.py                   manifest / status / identity / pack / chain / verify
scripts/r4_closure_mutation_test.py           the ten negative cases and the clean control
scripts/r4_v23_recheck.py                     section 6: V23 re-run + N1-N8 on the copied tree
```

## Reproduce it yourself

```text
python3 -B scripts/r4_content_and_archive_validator.py --stage content --root <unpacked TASK_ID>
python3 -B scripts/r4_clean_closure.py --stage verify --archive <path>.tar.gz
python3 -B scripts/r4_closure_mutation_test.py --tree <unpacked TASK_ID>
```

Every gate recomputes from live bytes, hashes or the AST; nothing reads a packaged claim, and no
gate is recorded with a constant. Boundary: no model, inference, training, GPU, normalisation,
scoring, overlap recompute, OOF, large corpus/template/raw-split read, network, pip, conda or git
operation; T6-named directories were skipped by name and never opened or stat-ed.

## INHERITED BACKGROUND (T4-R2, kept verbatim, no longer the identity of this package)

## T4-R2 asset-local overlap semantics / report / validator / three-file delivery final correction

> Everything in this section describes what T4-R2 delivered. T4-R3 and T4-R4 build on it without changing it.


- TASK_ID: enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909
- Date: 2026-09-09
- Nature: small CPU evidence-only correction on top of T4-R1. NO model inference, NO rescoring,
  NO large-asset rescan. All R2 tables are deterministic re-derivations from R1-frozen matrices
  whose identities were re-verified (R1 archive MANIFEST.sha256 52/52 PASS, MANIFEST.files 53/53
  coverage PASS) before any derivation ran.
- Authority: AUTHORITY_AND_SCOPE.md (teacher reply + R1 local audit + T4-R1 archive, all
  byte-verified against prompt §1; see INPUT_IDENTITIES.csv).

## What R2 fixes (R1 local audit verdict: REJECTED_REQUIRES_SMALL_EVIDENCE_CORRECTION)

1. `primary_status` in the two R1 BY_ASSET matrices was computed across ALL assets and copied onto
   every asset row (R1 p8 defect). R2 re-derives `asset_local_primary_status` from each row's own
   asset-local flags and keeps the R1 value side-by-side (`r1_original_primary_status`,
   `r1_original_primary_status_valid_for_asset`, `correction_note`). Nothing is silently replaced.
2. Cross-asset conclusions move to dedicated 39-row `GLOBAL_LAYERED_STATUS` tables, never mixed
   into asset-local columns.
3. envipath runtime semantics corrected: engine-B envipath rules load LOCAL frozen SHA-gated
   template files; `runtime_external_envipath_http_query=false`. The R1 "external KB at runtime"
   sentence is retracted (`DEPENDING_ENVIPATH_RUNTIME_AND_RANKER_BOUNDARY_CORRECTED.md`).
4. Opaque ranker semantics separated: `ranker_training_overlap=UNKNOWN_FOR_ALL_18` vs
   `cases_without_any_auditable_parent_or_template_locator=[]` (two distinct statements; the R1 q6
   conflation is retired in
   `DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY_CORRECTED.json`).
5. README pending markers eliminated (this file lists every delivered artifact as DONE), the base
   manifest layers are stated separately: base T4 `MANIFEST.sha256` = **89/89** verified, base raw
   freeze manifest = **54/54** verified (the R1
   `BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json` field `raw_freeze.manifest_sha256.verified_ok=54`
   belongs to the raw-freeze layer only and must not be read as the base-package count; the R1
   file is inherited byte-identical and not rewritten here).
6. fold6/fold8 note corrected: the T4-R1 prompt transcribed one hex character wrongly for each
   fold; the actual frozen split identities are
   `fold6 split_bbd.json sha256=b17ba7ae787c832faa3bfb0d452a46a24213bdd1a3203cca033628392d18d09f`
   and
   `fold8 split_bbd.json sha256=ecdd54c591cb0ff415db22e5791493356ef195cc5e0b96b4e0d6977fb90fe918`
   (from the first-package frozen `RUNTIME_MODEL_AND_SCRIPT_IDENTITIES.csv`). The previously
   quoted `0065...`/`56d8...` values were `eclipse/config.json` SHAs, not split SHAs, and are not
   used as split identity anywhere in R2. This is a prompt/narration error only; the R1 390/180
   fold matrices are unchanged (re-verified byte-identical under `inherited_r1/`).

## Asset-local distribution anchors reproduced live (see
## DEPENDING_REACTION_ASSET_LOCAL_STATUS_DISTRIBUTION.csv / DEPENDING_PRODUCT_ASSET_LOCAL_STATUS_DISTRIBUTION.csv)

```text
reaction: corpus P2=13 P3=3 P4=16 P6=7 | donor P4=31 P6=8 |
          templates.json P5=29 P6=10 | templates.tsv.gz P5=8 P6=31 | templates_implicitH P5=26 P6=13 |
          each ranker OPAQUE=39 (P1=0 kept as supplementary strict definition)
product:  corpus P3=16 P6=23 | donor P6=39 | each template P5=39 | each ranker OPAQUE=39
```

## Delivered artifacts (prompt §13; all DONE)

```text
[DONE] README.md                                        this file
[DONE] AUTHORITY_AND_SCOPE.md                           authority chain + boundaries
[DONE] INPUT_IDENTITIES.csv                             every input identity vs prompt §1/§4 values
[DONE] R1_INHERITED_ARTIFACT_IDENTITIES.csv             16 inherited R1 files with live+R1-manifest SHAs
[DONE] DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv       312 rows, 7 new asset-local fields
[DONE] DEPENDING_REACTION_ASSET_LOCAL_STATUS_DISTRIBUTION.csv
[DONE] DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv        312 rows, 7 new asset-local fields
[DONE] DEPENDING_PRODUCT_ASSET_LOCAL_STATUS_DISTRIBUTION.csv
[DONE] DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv            39 rows, separate global layer
[DONE] DEPENDING_39_GOLD_PRODUCT_GLOBAL_LAYERED_STATUS.csv             39 rows, separate global layer
[DONE] DEPENDING_ENVIPATH_RUNTIME_AND_RANKER_BOUNDARY_CORRECTED.md
[DONE] DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY_CORRECTED.json
[DONE] DEPENDING_OPAQUE_RANKER_LIMITATION_CORRECTED.md
[DONE] DEPENDING_NORMALIZED_PREDICTIONS_CORRECTED.jsonl                byte-identical reuse (R1)
[DONE] NORMALIZATION_CORRECTION_METRIC_INVARIANCE.json                 byte-identical reuse (R1)
[DONE] FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv                     byte-identical reuse (R1)
[DONE] ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv            byte-identical reuse (R1)
[DONE] ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv                        byte-identical reuse (R1)
[DONE] ECLIPSE_CASE_FOLD_EXPOSURE_SUMMARY.csv                          byte-identical reuse (R1)
[DONE] ECLIPSE_GOLD_REACTION_FOLD_EXPOSURE_SUMMARY.csv                 byte-identical reuse (R1)
[DONE] ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv             byte-identical reuse (R1)
[DONE] T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv         16 boundary rows updated to R2 evidence
[DONE] CORRECTED_ACCESS_AND_ARTIFACT_TIMELINE.csv                      byte-identical reuse (R1)
[DONE] ACCESS_AUDIT_SEMANTIC_CORRECTION.md                             byte-identical reuse (R1)
[DONE] HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_DECISION_REQUEST_CORRECTED_DRAFT.md
[DONE] PERSISTENT_SOURCE_NONMUTATION.json
[DONE] COMMAND_LOG.txt
[DONE] FINAL_STATUS.txt                                                written only after V01-V33 all pass
[DONE] MANIFEST.files / MANIFEST.sha256
[DONE] scripts/                                                        p1_p3_derive.py, p5 docs, p6_validator.py, p6_closure.py
[DONE] inherited_r1/                                                   16 R1 baseline files, byte-identical (§4)
```

## Hard boundaries (prompt §3)

No model entry, checkpoint loader, `single_smiles_v32` or ECLIPSE import/execution; no prediction,
fold, aggregation, scoring or OOF rerun; no re-read of large corpus/donor/templates/split assets
to regenerate overlap indexes; R1 archive/matrices, raw freeze, corrected normalized, metrics and
teacher originals unmodified; no gold-driven deletion/re-ranking; template applicability never
written as "full answer seen"; opaque rankers never written as zero overlap; envipath
source_tag never auto-adjudicated; no model role choice; nothing pushed or uploaded; no
credentials in any file.

## Closure rule

Fresh-run gate passed at start (WORK_ROOT/RETURN_DIR/ARCHIVE/IDENTITY/VALIDATION all absent).
Archive is created only after the independent validator passes V01-V33 on the unpacked directory;
`.identity.txt` and `.validation.txt` are produced after the archive lands, and the closure step
re-extracts the archive into a NEW temp dir and recomputes everything outside-in. After that the
executor STOPS.


## HISTORICAL_SUPERSEDED (T4-R3 closure order, replaced by T4-R4)

## T4-R3 tiny report / validator / sidecar closure (2026-09-10)

> The closure order described in this section is superseded: its `scripts/r3_closure.py`
> demanded a validation record before one could exist. Both scripts now live in
> `inherited_r3_closure_historical/` byte-identical. The scientific content of R3 stands
> unchanged and is still frozen byte-for-byte by T4-R4.


R3 changes no scientific result. It closes exactly the four items left open by the T4-R2 return
local audit, on top of the byte-identical R2 baseline recorded in
`R2_BASELINE_FILE_IDENTITIES.csv`, `R2_TO_R3_CHANGED_FILES.csv` and
`R2_CONTENT_NONMUTATION.json`.

- parent four-column label corrected: the boundary matrix now lists the parent CSV columns as
  `case_id, parent_name, parent_smiles, parent_smiles_rdkit_canonical`; the fourth column is the
  RDKit-canonical parent SMILES, not a task identifier. Exactly one cell of the matrix changed
  (`PARENT_FOUR_COLUMN_DESCRIPTION_CORRECTION.json`).
- T4 does not block the independent T6: the teacher draft closing line now says this T4 task does
  not enter T6 and does not pick the T6 model role, and that T6 keeps running under its own teacher
  contract without this T4 A/B decision as a precondition
  (`T4_T6_INDEPENDENCE_WORDING_CORRECTION.json`). The first 92 draft lines are byte-identical.
- validator V23 hardened: `scripts/p6_validator.py` no longer contains the always-true short-circuit
  the audit flagged. V23 is now a conjunction of 25 explicit sub-checks over the input identity
  table, this README and the teacher draft, backed by an independent recomputation in
  `scripts/r3_validator.py` (V13/V14) and a regex+AST source scan (V12). All eight negative cases
  N1-N8 are detected and the unmodified artefact passes
  (`V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json`).
- R2 data and metrics untouched: no model run, no inference, no rescoring, no corpus/template scan,
  no overlap or ECLIPSE recompute, no OOF. Raw predictions, both 312-row BY_ASSET matrices, both
  39-row GLOBAL tables, the ECLIPSE tables, the four-tool metric table and the normalized
  predictions are byte-identical to the R2 archive, and the R2 accepted anchors were re-checked
  read-only before any edit.
- three-file closure required: this package must be received together with the archive,
  `<archive>.identity.txt` and `<archive>.validation.txt`, all three regular non-symlink files in
  the same return root. The validation record is produced only from a fresh re-extraction of the
  landed archive, never from the pre-packing directory.
