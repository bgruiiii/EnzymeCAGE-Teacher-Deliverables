# DEPENDING envipath runtime and ranker boundary (T4-R2 corrected)

Supersedes the R1 statement "The `envipath*` engines query an external enviPath knowledge base at
runtime" (found in R1 `DEPENDING_OPAQUE_RANKER_LIMITATION.md` §3). That statement is factually
wrong for this run and is removed here. Basis: the T2B-R4 frozen runtime-asset records
(`ASSET_RUNTIME_IDENTITY_GATE.json`, assets section) and the depending engine-B source facts
already attested in the inherited evidence chain. No model was re-run to establish this.

## 1. Engine-B envipath rules load from LOCAL frozen files

The depending engine-B "envipath" path reads two local template rule files:

```text
data/hfix/templates_implicitH.jsonl
    bytes=138383
    sha256=3c3db55c385cfbe6d0553f155edec2189bf92247d314baf2fad97afdf5fb1948
reaction_v3/data/lib_envipath/templates.tsv.gz
    bytes=31059
    sha256=19ac04ca4d6c516f7dce0f7536959847bec91ba81a68384c58551ead18ebe4f1
```

Both SHAs/bytes match the T2B-R4 `ASSET_RUNTIME_IDENTITY_GATE.json` frozen records, and both live
files were re-hashed read-only during this R2 session at their recorded runtime paths
(`/usrdata/EnzymeCAGE_data/enzymecage_crew/data/hfix/templates_implicitH.jsonl` and
`.../workspaces/enzymecage_three_module_t2b_r4_.../r4_replay/reaction_v3/data/lib_envipath/templates.tsv.gz`)
with identical values. These two files are listed in the runtime asset gate, i.e. they are part of
the frozen, SHA-gated runtime inputs.

## 2. Runtime boundary

```text
runtime_external_envipath_http_query = false
envipath_ranker training rows        = OPAQUE_NOT_AUDITABLE
template applicability               = generic rule evidence, NOT a concrete answer record
```

- `source_tag=envipath` in this depending run therefore denotes output of the LOCAL frozen envipath
  rule engine, not a live external knowledge-base lookup.
- A prediction tagged `envipath` is NOT automatically labeled leakage; it is classified only by the
  preregistered locator rules (concrete corpus pair locator -> P1/P2/P3/P4 evidence; template-only
  match -> P5; otherwise no exact match). Likewise `source_tag=retrieval` is not automatically
  leak-free.
- The unknown boundary is NOT "what the external KB contained"; it is:
  1. `envipath_ranker.txt` (and the other two rankers) carry no recoverable training-row identities,
     so ranker training overlap is `UNKNOWN_FOR_ALL_18` (see
     `DEPENDING_OPAQUE_RANKER_LIMITATION_CORRECTED.md`);
  2. template applicability proves rule generality, never that the full answer was seen.

## 3. Effect on inherited evidence

- The R1 hit-provenance classification results (7/6/2/3 split of the 18 cases) are unchanged by
  this correction: they were already locator-driven, not tag-driven.
- `DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY_CORRECTED.json` replaces the conflated R1 q6 field;
  the external-KB clause in its note is removed.
- No overlap index was regenerated; no model, corpus scan or rescoring was performed here.
