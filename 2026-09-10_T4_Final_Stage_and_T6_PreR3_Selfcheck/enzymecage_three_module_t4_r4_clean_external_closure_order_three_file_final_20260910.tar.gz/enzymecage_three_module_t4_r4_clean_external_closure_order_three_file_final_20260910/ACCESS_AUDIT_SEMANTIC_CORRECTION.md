# ACCESS_AUDIT_SEMANTIC_CORRECTION (T4-R1, 2026-09-09)

## 1. Original file identity (untouched)

The first-package audit file `/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t4_r1_runtime_blindness_training_overlap_normalization_metric_delivery_evidence_correction_20260909/immutable_base_t4/enzymecage_three_module_t4_teacher_countersigned_18_depending_v32_eclipse_blind_evaluation_20260909/ACCESS_AUDIT.jsonl` is kept byte-unmodified:

- sha256: `2cbd3b910dba0822892022270c223686358348f586819391b63491fbfa17acfd` (re-verified live in this R1 session)
- size: 3433 bytes, mtime `2026-09-09T06:17:41.000Z`
- 10 events, every event carries `utc=2026-09-09T06:17:41Z`, actor `executor_agent`

No byte of the original was changed. This document corrects the *interpretation*, not the file.

## 2. What the original timestamps actually mean

All 10 events share one timestamp `2026-09-09T06:17:41Z`, which equals the audit file's own
mtime (write time). Therefore the original timestamps are **not** per-event real-time
occurrence times. Their correct semantics is:

> `RECONSTRUCTED_AFTER_RUN` — the audit was written once, after the run, and each event row
> was stamped with the write time of that audit file.

This is consistent with the base-package marker `OPEN_TRACE_UNAVAILABLE` (mtime
`2026-09-09T04:56:13Z`): **no live open trace exists**. The first-package narration that
could be read as a live trace is hereby corrected. No open trace is fabricated anywhere in
this correction.

## 3. Corrected event semantics (segment A of the CSV)

| # | Event | Corrected time (UTC) | Basis |
|---|-------|----------------------|-------|
| 1 | payload_unpack | 2026-09-09T02:12:25.000Z | FILE_MTIME |
| 2 | teacher_countersign_identity_verify | UNKNOWN_NOT_RECOVERABLE | NONE |
| 3 | parent_only_csv_canonical_verification | 2026-09-09T03:24:12.833Z | FILE_MTIME_AND_BODY_UTC |
| 4 | prediction_plan_and_disclosure_freeze | 2026-09-09T03:26:00Z | BODY_UTC |
| 5 | depending_v32_prediction_run | 2026-09-09T04:05:08.634Z | FILE_MTIME |
| 6 | eclipse_predec_10fold_prediction_run | 2026-09-09T04:05:01.222Z | FILE_MTIME |
| 7 | phase_p_raw_freeze_and_hard_gate | 2026-09-09T04:36:13Z | FILE_MTIME_AND_BODY_UTC |
| 8 | gold_freeze_archive_open_and_extraction | 2026-09-09T05:01:12.663Z | EXTRACTION_TARGET_DIR_MTIME |
| 9 | frozen_scoring_execution | 2026-09-09T05:03:12.901Z | FILE_MTIME |
| 10 | four_tool_metrics_and_package_build | 2026-09-09T05:09:12.855Z | FILE_MTIME |

Event 2 (teacher_countersign_identity_verify) has **no recoverable time**: the countersign
file (5995 bytes, sha256 `953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4`) was searched in HPC_Inputs, the base package and
the original workspace and was not located. It is marked `UNKNOWN_NOT_RECOVERABLE` instead of
being assigned a guessed time.

## 4. Recoverable real-time chain (segment B of the CSV, measured mtimes, ms precision UTC)

```text
02:12:25.000  parent-only input unpacked from executor payload tar      (event 1)
03:24:12.833  input disclosure written   (body 03:24:12.745851Z)       (event 3)
03:26:12.703  plan file written           (body frozen_utc 03:26:00)   (event 4)
04:05:01.222  eclipse per-fold raw predictions                          (event 6)
04:05:08.634  depending raw predictions                                (event 5)
04:24:13.946  depending normalized; 04:24:14.110 eclipse normalized
04:36:13      raw freeze identity + manifest (gate body 04:36:13)      (event 7)
04:38:12.927  freeze re-verify; T4_PREDICTION_RAW_FREEZE.tar.gz 04:38:12
05:01:12.663  gold_standard dir created under scoring_assets           (event 8)
05:03:12.901  depending scoring out; 05:03:13.037 eclipse scoring out  (event 9)
05:09:12.855  FOUR_TOOL_METRICS_WITH_FROZEN_BASELINES.csv              (event 10)
06:15:51-06:16:49  package build scripts
06:17:41      ACCESS_AUDIT.jsonl written (all 10 events stamped now)
06:28:30      formal report; 06:40:16 FINAL_STATUS.txt; 07:06:07 MANIFEST
```

Gold zero-contact ordering evidence (all measured):

```text
model outputs 04:05:0x  <  raw freeze archive 04:38:12
              <  gold extraction into scoring_assets 05:01:12
              <  frozen scoring outputs 05:03:12-13  <  four-tool metrics 05:09:12
```

The runtime phase (Phase P) had no gold content: prediction assets and the raw freeze predate
the first gold extraction, and the gold freeze tar original (mtime 2026-08-04T08:14:12.273Z,
sha256 `58feccb30056847acee41d2436263d770eea35a44d5d2d5a78e0ad20a06a3d3e`) matches the sha recorded inside event 8. Runtime gold zero contact
therefore holds, with the stated limitation that only a reconstructed audit exists.

## 5. Prohibitions honored

- Original `ACCESS_AUDIT.jsonl` not modified (SHA asserted before and after output writing).
- Missing open trace **not** fabricated; per-event real times given only where a real
  filesystem or in-file source exists; otherwise `UNKNOWN_NOT_RECOVERABLE`.
- Extracted gold files carry 1970-01-01 zero mtimes from inside the gold tar; these are
  reported as archive-internal timestamps, never as extraction times.
- The R1 audit unpack directory `/tmp/t4r1_goldfreeze/...` (mtime
  2026-09-09T08:29:51.206Z) belongs to this evidence-correction session and is labeled as such,
  so it can never be mistaken for a first-package runtime event.

Companion data: `CORRECTED_ACCESS_AND_ARTIFACT_TIMELINE.csv` (segments A/B/C).
