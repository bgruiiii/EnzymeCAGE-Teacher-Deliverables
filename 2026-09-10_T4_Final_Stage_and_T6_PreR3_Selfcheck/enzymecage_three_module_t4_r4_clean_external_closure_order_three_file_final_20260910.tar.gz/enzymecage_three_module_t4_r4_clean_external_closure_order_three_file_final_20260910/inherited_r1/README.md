# T4-R1 Runtime-blindness / training-overlap / normalization / metric delivery evidence correction

- TASK_ID: enzymecage_three_module_t4_r1_runtime_blindness_training_overlap_normalization_metric_delivery_evidence_correction_20260909
- Date: 2026-09-09
- Nature: evidence-only correction of the T4 first package. NO model inference was run. NO frozen
  file was modified. All computation is read / re-normalize / set-compare / replay-frozen-scoring.
- Authority: see AUTHORITY_AND_SCOPE.md (teacher reply + independent local audit, both byte-verified).

## What happened to the first package (context)

The T4 first package (18-case depending v3.2 + ECLIPSE blind predictions, raw freeze, frozen-script
scoring) executed the models genuinely but was audited
`REJECTED_REQUIRES_EVIDENCE_ONLY_CORRECTION_BEFORE_TEACHER_DELIVERY` for: (1) 3 depending rows with
no InChIKey mislabeled `ok`; (2) macro/micro product-recall narration mixed; (3) no
training/reference overlap audit while ECLIPSE fold0 already shows 20/39 gold reactions in TRAIN;
(4) ACCESS log reconstructed after the run; (5) three-file delivery closure missing.

## This package (in progress; per prompt §13)

```text
[done p1-p2] INPUT_IDENTITIES.csv                          36 rows, bad=0 (incl. fold6/fold8 adjudicated)
[done p1-p2] INHERITED_T4_ARTIFACT_IDENTITIES.csv          73 rows (base package 20 + raw freeze 53 members traversed)
[done p1-p2] ORIGINAL_PHASE_TIMELINE_EVIDENCE.csv          8 rows (disclosure 03:24Z -> ACCESS reconstruct 06:17:41Z)
[done p1-p2] BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json   verdict=BASE_PACKAGE_AND_RAW_FREEZE_IMMUTABLE_RECHECK_PASS
[done p1-p2] AUTHORITY_AND_SCOPE.md / README.md / COMMAND_LOG.txt
[pending]    depending 3-row normalization correction + original/corrected dual replay + metric invariance
[pending]    FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv (macro vs micro separated)
[pending]    OVERLAP_ANALYSIS_PREREGISTRATION.md (frozen BEFORE gold comparison)
[pending]    depending 5-asset schema inventory + 18-parent exposure + 39 gold reaction/product overlap + hit provenance
[pending]    ECLIPSE 10-fold split verification + 390-row long matrix + 180-row parent exposure + fold0 anchor 20/3/2/14
[pending]    T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX.csv (runtime-blind vs training-disjointness separated)
[pending]    ACCESS timeline correction (CORRECTED_TIMELINE.csv + SEMANTIC_CORRECTION.md)
[pending]    Huang-teacher adjudication request draft (A/B options, no preference implied)
[pending]    PERSISTENT_SOURCE_NONMUTATION.json + COMMAND_LOG closure + FINAL_STATUS + MANIFEST x2 + validator V01-V33
```

## Hard boundaries (prompt §3, restated)

No model entry imported; no fold re-run; no candidate re-ranked; raw freeze immutable; OOF not
computed; template applicability never reported as "full answer seen"; opaque rankers marked
OPAQUE_NOT_AUDITABLE (never "zero overlap"); model role decision left to Huang teacher; nothing
pushed to production or GitHub; nothing uploaded publicly.

## Run gating

Fresh-run gate passed: WORK_ROOT / RETURN_DIR / ARCHIVE / IDENTITY / VALIDATION all absent at
start; nothing was overwritten, resumed, or renamed. Final closure (three-file delivery) happens
only after validator V01-V33 all pass, then the executor STOPS.
