# DEPENDING opaque ranker limitation (T4-R1 evidence-only correction)

## 1. Scope and identity

The three depending_v32 ranker assets are `.txt` LightGBM model parameter files. Their bytes/SHA256
were re-verified against `RUNTIME_AND_ASSET_IDENTITIES.csv` in p6 (all MATCH):

```text
uspto_ranker.txt      1263228 B  e493fc031f217e18543d27081168ff6851414f8f080622cf3dd54bc9484e0944
envipath_ranker.txt    645960 B  e0920695c9d8e2609c64da18975d39275b8be581a5657b0cf45ed8da264141c1
retrieval_ranker.txt   659831 B  bdcb575e9685d47dbfa83b96f71dd05e326dc21cb7f4c0b224b1fffb49c65f65
```

Header metadata recovered (first lines, text-parseable only):

```text
tree/version=v4
num_class=1
num_tree_per_iteration=1
(+ objective/sigmoid hyperparameter lines; no feature names, no row identities)
```

## 2. Why these assets are OPAQUE_NOT_AUDITABLE

- The files contain model parameters only. No training-row identifiers, no SMILES, no InChIKey, no
  record IDs are recoverable from them (checked by header/metadata inspection; no semantic string
  search was performed over float payloads, and none could establish row identity anyway).
- Per the preregistered rule, absence of textual hits in an opaque binary must NOT be narrated as
  "zero overlap".
- Therefore these three assets contribute NO rows to exact-match denominators. In
  `DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv`, `DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET.csv`
  and `DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET.csv` their rows are marked
  `OPAQUE_EXCLUDED_FROM_DENOMINATOR` (explicit rows kept for completeness).
- The per-prediction `evidence_hash` in `RAW_PREDICTIONS.jsonl` is an engine-side hash of the
  generation; it is not invertible to a training row and cannot connect a prediction to a specific
  corpus/donor/template training example by itself.

## 3. External enviPath knowledge source

The `envipath*` engines query an external enviPath knowledge base at runtime. Even where a
prediction is tag-correct, the exact KB content consulted at run time is not part of the frozen
local assets; provenance through that path is UNKNOWN unless a concrete locator exists in one of
the 5 auditable text assets. `source_tag=envipath` is therefore NOT automatically labeled leakage.

## 4. Effect on the first-hit provenance results (p9)

Of the 15 re-derived first gold-product hits:

- 7 have their exact (parent,product) canonical pair present as concrete corpus_v1.jsonl records
  (re-checkable locators) -> CORPUS_EXACT_PAIR_SEEN_IN_AUDITABLE_ASSET;
- 6 have parent-side-only evidence in auditable assets (corpus reactant side and/or donor_index),
  no exact pair -> PARENT_SIDE_ONLY_SEEN_NO_EXACT_PAIR;
- 2 (SPD-BBD-pha, SPD-BBD-tbp2) have only generic template-applicability evidence (P5; preregistered
  rule: template applicability is NEVER reported as "the full answer was seen") ->
  TEMPLATE_ONLY_MATCH_NO_CONCRETE_RECORD;
- 0 first-hit cases fall into NO_AUDITABLE_MATCH_PROVENANCE_UNKNOWN: every first-hit case has at
  least parent-side or template-level evidence in the 5 auditable text assets. The UNKNOWN label
  still applies to the *ranking provenance* itself (which engine/ranker produced which score), which
  is not recoverable from the opaque rankers for ANY prediction, including the 7 pair-connected ones.

`source_tag=retrieval` is NOT automatically labeled leak-free either; retrieval hits are classified
by the same locator-based rules above.

## 5. Consequence for the blindness boundary matrix

Rows in `T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX.csv` for ranker training identity auditable
ability are recorded as `OPAQUE_NOT_AUDITABLE / UNKNOWN`, never as `0 overlap`.
