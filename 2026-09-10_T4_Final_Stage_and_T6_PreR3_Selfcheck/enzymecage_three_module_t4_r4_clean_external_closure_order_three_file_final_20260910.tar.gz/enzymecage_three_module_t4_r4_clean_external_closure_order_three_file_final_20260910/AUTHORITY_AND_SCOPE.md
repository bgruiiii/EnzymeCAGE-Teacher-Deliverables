# T4-R4 Authority and Scope

## Authority chain (verified read-only before any write)

```text
t4_r4_teacher_authority_and_r3_local_audit_payload_20260910.tar.gz
  bytes=9900 sha256=b82543960b6504bd7caf752ddd10e1da33e33d3b1dcbc7c167ba1bc70dc10769
  single root, 3 regular members, 0 unsafe entries, verified inside the R4 workspace
  -> TEACHER_REPLY_T4_INPUT_IDENTITY_AND_ORCHESTRATION_BOUNDARY_2026-09-08.md
       3627 / ca270af0419d7954ff8ddcb1b4304a04428ad893eeedfee604402f11004fdd34
  -> TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md
       5995 / 953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4
  -> ENZYMECAGE_THREE_MODULE_T4_R3_TINY_REPORT_VALIDATOR_SIDECAR_CLOSURE_RETURN_LOCAL_AUDIT_2026-09-10.md
       9097 / 1fbf4c5926041d795183638e9b919a703fdae2545b97cee45f2a1c6151a53126
       verdict: PASS_CONTENT_REQUIRES_TINY_R4_CLEAN_EXTERNAL_CLOSURE_ORDER_AND_THREE_FILE_DELIVERY
enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910.tar.gz
  bytes=228792 sha256=e21127343f31c8e678e271ca8e7241a7a515c11d0ea9043c57b2535008d6611f
  64 regular files, 0 unsafe members, single root, 63/63 hashes and 64/64 coverage verified
  after extraction; it is the ONLY result input of this round
```

The teacher replies are the authority for the T4 questions; the R3 local audit is the authority for
what this round has to fix; the R3 archive is the only source of the returned content.

## What this round is allowed to change

R4 changes **the delivery layer only**. Scientific content, evidence tables, the validator logic and
the teacher materials are frozen byte-for-byte:

```text
permitted rewrites (6)    README.md, AUTHORITY_AND_SCOPE.md, COMMAND_LOG.txt, FINAL_STATUS.txt,
                          MANIFEST.files, MANIFEST.sha256
permitted additions       R3_BASELINE_FILE_IDENTITIES.csv, R3_TO_R4_CHANGED_FILES.csv,
                          R3_CONTENT_NONMUTATION.json,
                          R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json,
                          R4_CLEAN_CLOSURE_ORDER_MUTATION_TEST.json,
                          scripts/r4_content_and_archive_validator.py, scripts/r4_clean_closure.py,
                          scripts/r4_closure_mutation_test.py, scripts/r4_v23_recheck.py,
                          scripts/r4_p1_copy.py, scripts/r4_p5_docs.py,
                          scripts/r4_p5b_changed_sets.py
permitted relocation      scripts/r3_closure.py, scripts/r3_validator.py
                          -> inherited_r3_closure_historical/ (byte-identical, HISTORICAL_SUPERSEDED)
everything else           untouched; gate C04 proves 58 non-whitelist R3 files still hash exactly as
                          recorded in R3_BASELINE_FILE_IDENTITIES.csv
```

The three external files (`<archive>`, `<archive>.identity.txt`, `<archive>.validation.txt`) are the
subject of this round; they carry a new TASK_ID and are produced only after the archive landed.

## Hard boundaries honoured

No model entry, checkpoint loader, `single_smiles_v32` or ECLIPSE import/execution; no prediction,
fold, aggregation, scoring or OOF rerun; no re-read of large corpus/donor/templates/split assets to
regenerate overlap indexes; the two corrected teacher materials, `scripts/p6_validator.py` and the
R1/R2/R3 archives unmodified; no gold-driven deletion or re-ranking; no model role choice; the
teacher draft stays local, neutral on options A/B, unsent; nothing pushed or uploaded; no
credentials in any file; T6-named entries skipped by name, never opened or stat-ed; every Python
process ran with `PYTHONDONTWRITEBYTECODE=1` and `-B`; writes were limited to this task's workspace,
this return directory and the three same-basename files.

## One deviation inside this round, disclosed in full

At 06:56Z a pack command was started from a shell in which the TASK_ID variable had not been
exported, so its archive argument resolved to the return root plus `.tar.gz` with an empty name.
Two stray files came into existence under that wrong name and were removed again shortly after;
both the failed attempt and the cleanup are recorded in `COMMAND_LOG.txt` with their own exit codes
and output hashes. None of the three real delivery paths was ever written by that attempt, no gate
was ever run against the mis-named archive, and the section 8.3 refusal towards a pre-existing
validation record was never bypassed. Two defences were added afterwards and ship inside this
package: the pack stage refuses a non-canonical archive name and any delivery path that already
exists, and the final read-only command is declared in the validation record as the literal argv
that the checked process then compares with its own.

## Declared limits that R4 does not remove

R4 does not establish strict unseen blind evaluation. The current metrics remain
`VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY`; 13/39 pair, 15/18 parent and 16/39 product hits against
`corpus_v1.jsonl` keep the asset-local meaning fixed in T4-R2. Whether the model role is decided
from runtime blind performance or from a strict unseen blind benchmark is teacher question A/B and
remains `AWAITING_HUANG_TEACHER_REVIEW`. T4-R4 cannot make that decision, cannot send the draft, and
does not gate T6. The delivered package is only as trustworthy as the three files that must arrive
with it: an archive without its `.identity.txt` and `.validation.txt` is an incomplete return.
