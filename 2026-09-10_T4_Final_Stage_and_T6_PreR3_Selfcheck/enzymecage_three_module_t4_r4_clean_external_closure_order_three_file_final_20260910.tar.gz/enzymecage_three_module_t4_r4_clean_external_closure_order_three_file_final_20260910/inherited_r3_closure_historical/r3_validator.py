#!/usr/bin/env python3
"""T4-R3 independent validator: gates V01-V30 (prompt section 9).

  --stage content  : V01-V25 against the live RETURN_DIR (both manifests already written).
  --stage archive  : V01-V25 re-computed against a FRESH unpack of the landed archive, plus
                     V26 (archive structure), V27 (identity record), V28 (this run's own
                     provenance), V29 (external sidecars), V30 (FINAL_STATUS consistency).
  --scan-source P  : section 7 / V12 tautology scan of one python source; one JSON line on
                     stdout, exit 0 = clean, exit 1 = always-true construct found.

Nothing here restates a packaged claim: every gate recomputes from live bytes, hashes or
AST.  No model, no inference, no rescoring, no overlap/ECLIPSE recompute, no network.
PYTHONDONTWRITEBYTECODE=1 / python3 -B."""
import argparse
import ast
import calendar
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

T = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
T2 = "enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R3 = f"{RR}/{T}"
A = f"{W}/immutable_authority/t4_r3_teacher_authority_and_r2_local_audit_payload_20260910"
R2D = f"{W}/immutable_r2"
AP = f"{ROOT}/HPC_Inputs/t4_r3_teacher_authority_and_r2_local_audit_payload_20260910.tar.gz"
R2ARC = f"{RR}/{T2}.tar.gz"
MUT_JSON = "V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json"
BM = "T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv"
DRAFT = ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
         "DECISION_REQUEST_CORRECTED_DRAFT.md")
R3_START_ISO = "2026-09-10T02:50:55Z"          # fresh-gate pass moment (prompt section 2)
R3_START_EPOCH = calendar.timegm(time.strptime(R3_START_ISO, "%Y-%m-%dT%H:%M:%SZ"))
FS_READY = "T4_R3_REPORT_VALIDATOR_SIDECAR_CLOSURE_READY_FOR_LOCAL_AUDIT"

# prompt section 1, immutable identities
PROMPT_SHA = {
    AP: ("2b5e7be0434d802c3013264a82eab07757854a891601a0cc379cf0e2e3f85b78", 9326),
    R2ARC: ("025c4e7be5c703d1d6ec2719415c15cd66d5e2b1cbd97e48c6b42daa3fd87826", 169035),
}
MEMBER_SHA = {  # authority payload members, extracted under immutable_authority/
    "TEACHER_REPLY_T4_INPUT_IDENTITY_AND_ORCHESTRATION_BOUNDARY_2026-09-08.md":
        ("ca270af0419d7954ff8ddcb1b4304a04428ad893eeedfee604402f11004fdd34", 3627),
    "TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md":
        ("953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4", 5995),
    "ENZYMECAGE_THREE_MODULE_T4_R2_ASSET_LOCAL_OVERLAP_SEMANTIC_REPORT_VALIDATOR_DELIVERY_"
    "FINAL_CORRECTION_RETURN_LOCAL_AUDIT_2026-09-09.md":
        ("793530ef75efa137053c3d6de176508439dc2e1d74c19add1856db04cb9f0b33", 8028),
}
R2_KEY_SHA = {  # prompt section 1, must hold in the R3 baseline copy unchanged
    "DEPENDING_NORMALIZED_PREDICTIONS_CORRECTED.jsonl":
        ("6e52ada071c0b12d36aa8490bbdcc0b9928461861432ba1be5365764d30209e4", 288932),
    "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv":
        ("aa9e8eedc788efeb0a8ec285a2e83db1516cb16c60a092ab080d81a63a13aeda", 285180),
    "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv":
        ("ac96263dadc78a0b32ca69cb85b5815e3ff5ca83d86dbd4879825d7c4dd443ba", 260258),
    "FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv":
        ("75a50d517d25ef96aae8b35b67b8fb163788ba1b22fc8e93288bda002a138a15", 3025),
    "INPUT_IDENTITIES.csv":
        ("1745d754b5a2fed343c9ba33f6d80faa823e2d3a1d2d565dee15972eb6ad6ea5", 12849),
}
R2_BEFORE_SHA = {  # the three files R3 is allowed to change: pre-change (R2) identities
    BM: ("d4c05126fc600207d759480c53d4a90f40b7a86bc0eabd98d10b62a8d2db05ee", 9552),
    DRAFT: ("a791d0492687bfac7921060cfdee8ec516334f460054912d53f9d27f32742da5", 6394),
    "scripts/p6_validator.py":
        ("c99946e19a76b2bc10b101f1db8cf1d42128dbcb833967d6e3acd6a4949fc478", 32138),
}
# prompt section 8 whitelist: R2 files that R3 may legitimately rewrite
WHITELIST = {BM, DRAFT, "scripts/p6_validator.py", "README.md", "FINAL_STATUS.txt",
             "COMMAND_LOG.txt", "AUTHORITY_AND_SCOPE.md", "MANIFEST.files", "MANIFEST.sha256"}
NONMUT = ["DEPENDING_NORMALIZED_PREDICTIONS_CORRECTED.jsonl", "FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv",
          "NORMALIZATION_CORRECTION_METRIC_INVARIANCE.json", "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv",
          "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv", "DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv",
          "DEPENDING_39_GOLD_PRODUCT_GLOBAL_LAYERED_STATUS.csv", "INPUT_IDENTITIES.csv",
          "ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv", "ECLIPSE_CASE_FOLD_EXPOSURE_SUMMARY.csv",
          "ECLIPSE_GOLD_REACTION_FOLD_EXPOSURE_SUMMARY.csv", "ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv"]
OLD_LABEL = "case_id, pollutant name, parent SMILES, task id"
NEW_LABEL = "case_id, parent_name, parent_smiles, parent_smiles_rdkit_canonical"
FOUR_FIELDS = ["case_id", "parent_name", "parent_smiles", "parent_smiles_rdkit_canonical"]
OLD_SENT = "在您裁定前，本草稿不发送、不上传；T6 不进入；无任何 git push。"
NEW_SENT = ("在您裁定前，本草稿不发送、不上传；本T4任务不进入T6、也不改变T6模型角色；"
            "T6按独立老师合同继续推进，不以本T4 A/B裁定为前置门；无任何git push。")
FOLD = {"fold6": "b17ba7ae787c832faa3bfb0d452a46a24213bdd1a3203cca033628392d18d09f",
        "fold8": "ecdd54c591cb0ff415db22e5791493356ef195cc5e0b96b4e0d6977fb90fe918"}
CFG = {"fold6": "0065ebcc", "fold8": "56d8b332"}          # eclipse/config.json SHA prefixes
FOLD_DIR = {"fold6": "bbd_40_3_6_uspto_rdkit", "fold8": "bbd_40_3_8_uspto_rdkit"}
ALLOWED_IMPORTS = {"argparse", "ast", "calendar", "copy", "csv", "datetime", "gzip", "hashlib",
                   "json", "os", "re", "shutil", "subprocess", "sys", "tarfile", "tempfile",
                   "time"}   # exactly the stdlib set imported by the 11 packaged scripts
ALLOWED_CMD = {"python3", "tar", "sha256sum", "mkdir", "cp", "ls", "stat", "cat", "mktemp",
               "readlink", "gzip"}
HEX8PLUS = re.compile(r"[0-9a-f]{8,}")
HEX64 = re.compile(r"[0-9a-f]{64}")

# V12 static rules.  Every pattern is written so that it cannot match its own source text:
# the escaped forms in this file contain no literal whitespace run / no literal bracket.
TAUTO_RX = [
    ("always_true_disjunction", re.compile(r"\bor\s+True\b")),
    ("always_true_conjunction", re.compile(r"\band\s+True\b")),
    ("always_true_if", re.compile(r"\bif\s+True\b")),
    ("empty_all_call", re.compile(r"\ball\(\s*\)")),
    ("empty_any_call", re.compile(r"\bany\(\s*\)")),
    ("trivial_len_ge_zero", re.compile(r"\blen\([^()]*\)\s*>=\s*0\b")),
    ("trivial_not_in_empty", re.compile(r"\bnot\s+in\s+\(\s*\)")),
]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(p, enc="utf-8"):
    with open(p, encoding=enc, errors="ignore") as f:
        return f.read()


def rows(p):
    with open(p, encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f)]


def I(v):
    try:
        return int(str(v).strip())
    except ValueError:
        return 0


def tar_list(arc):
    out = []
    with tarfile.open(arc, "r:gz") as tf:
        for m in tf.getmembers():
            kind = ("dir" if m.isdir() else "symlink" if m.issym() else "hardlink" if m.islnk()
                    else "regular" if m.isfile() else "special")
            out.append((m.name.rstrip("/"), kind, m.size))
    return out


def unsafe_members(mem):
    return [n for n, k, s in mem if k not in ("regular", "dir")
            or n.startswith("/") or ".." in n.split("/") or n.startswith("./")]


def walk_reg(R):
    return sorted({os.path.relpath(os.path.join(r_, f), R)
                   for r_, _, fs in os.walk(R) for f in fs})


def manifest_shas(R):
    d = {}
    for line in rd(f"{R}/MANIFEST.sha256").splitlines():
        if line.strip() and "  " in line:
            s, rel = line.rstrip("\n").split("  ", 1)
            d[rel] = s
    return d


def check_manifests(R):
    """(files_cover_all, sha256_covers_rest_and_all_hashes_ok, details)."""
    mf = set(rd(f"{R}/MANIFEST.files").split())
    actual = set(walk_reg(R))
    ok_files = mf == actual and {"MANIFEST.files", "MANIFEST.sha256"} <= mf
    man = manifest_shas(R)
    ok_sha = ("MANIFEST.sha256" not in man and set(man) == (mf - {"MANIFEST.sha256"})
              and all(os.path.isfile(os.path.join(R, r)) and sha(os.path.join(R, r)) == h
                      for r, h in man.items()))
    return ok_files, ok_sha, (len(mf), len(actual), len(man))


def tautology_scan(path):
    """V12: regex + AST detection of always-true constructs in a python source."""
    src = rd(path)
    find = [[rule, i + 1, ln.strip()[:70]] for i, ln in enumerate(src.split("\n"))
            for rule, rx in TAUTO_RX if rx.search(ln)]
    tree = ast.parse(src)
    for n in ast.walk(tree):
        if isinstance(n, ast.BoolOp) and any(isinstance(v, ast.Constant) and v.value is True
                                             for v in n.values):
            find.append(["ast_boolop_true_constant", n.lineno, "BoolOp operand is the True literal"])
        elif isinstance(n, (ast.If, ast.While)) and isinstance(n.test, ast.Constant) and n.test.value is True:
            find.append(["ast_always_true_branch", n.lineno, "branch test is the True literal"])
        elif (isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
              and n.func.id in ("all", "any") and len(n.args) == 1
              and isinstance(n.args[0], (ast.List, ast.Tuple, ast.Set, ast.Dict))
              and not n.args[0].elts):
            find.append(["ast_empty_" + n.func.id, n.lineno, f"{n.func.id}() over an empty literal"])
    return find


def fold_gate(R):
    """V13/V14: fold6 / fold8 hard facts, recomputed here independently of p6_validator.py."""
    ii = rows(f"{R}/INPUT_IDENTITIES.csv")
    rd_ = rd(f"{R}/README.md")
    dft = rd(f"{R}/{DRAFT}")
    sel = {t: [r for r in ii if r["input_name"] == f"actual_identity_{t}_split_bbd.json"]
           for t in FOLD}
    sub = {"exactly_one_row_per_gated_fold": all(len(v) == 1 for v in sel.values())}
    for t, act in FOLD.items():
        r = sel[t][0] if len(sel[t]) == 1 else {}
        tok = r.get("expected_sha256", "").strip().split(" ")[0]
        sub[f"{t}_status_actual_split_sha_from_frozen_record"] = (
            r.get("check") == "ACTUAL_SPLIT_SHA_FROM_FROZEN_RECORD")
        sub[f"{t}_role_is_explained_citation"] = r.get("role") == "prompt_transcription_correction_citation"
        sub[f"{t}_row_path_is_that_folds_split_bbd"] = bool(r) and r.get(
            "path", "").endswith(f"/{FOLD_DIR[t]}/split_bbd.json") and "/eclipse/" not in r.get("path", "")
        sub[f"{t}_live_sha256_is_exactly_the_actual_split_sha"] = r.get("live_sha256") == act
        sub[f"{t}_live_sha256_free_of_config_sha"] = bool(r) and CFG[t] not in r.get("live_sha256", "")
        sub[f"{t}_historical_expected_free_of_config_sha"] = bool(r) and CFG[t] not in tok
        sub[f"{t}_historical_expected_is_typo_citation_1_hex_char_off"] = (
            HEX64.fullmatch(tok) is not None and tok != act and len(tok) == len(act)
            and sum(1 for a, b in zip(tok, act) if a != b) == 1
            and "(" in r.get("expected_sha256", "") and "transcription" in r.get("expected_sha256", "").lower())
        sub[f"readme_quotes_{t}_actual_split_sha"] = act in rd_
        sub[f"teacher_draft_quotes_{t}_actual_split_sha"] = act[:12] in dft
        sub[f"{t}_config_sha_prefix_absent_from_readme"] = CFG[t] not in rd_
        sub[f"{t}_config_sha_prefix_absent_from_teacher_draft"] = CFG[t] not in dft

    def bad_hex_lines(text):
        v = []
        for ln in text.split("\n"):
            tags = [t for t in FOLD if t in ln]
            if tags:
                v += [tk[:20] for tk in HEX8PLUS.findall(ln)
                      if not any(FOLD[t].startswith(tk) for t in tags)]
        return v

    sub["readme_fold_lines_cite_only_actual_split_hex"] = not bad_hex_lines(rd_)
    sub["teacher_draft_fold_lines_cite_only_actual_split_hex"] = not bad_hex_lines(dft)
    bad = sorted(k for k, v in sub.items() if v is not True)
    return len(sub) >= 24 and not bad, sub, bad


G = []


def rec(gid, ok, ev, loc):
    G.append({"gate": gid, "verdict": "PASS" if ok else "FAIL", "evidence": ev, "locator": loc})
    print(f"{gid}: {'PASS' if ok else 'FAIL'} | {ev}")
    return ok


def gates_content(R):
    """V01-V25: everything that does not need the landed archive."""
    ok_all = True
    r2root = R2D  # R2 content, extracted read-only from the R2 archive at section 2

    # V01 authority payload
    mem = tar_list(AP)
    p_sha, p_sz = PROMPT_SHA[AP]
    names = [n.split("/")[-1] for n, k, s in mem if k == "regular"]
    inner = {n: (os.path.getsize(os.path.join(A, n)), sha(os.path.join(A, n))) for n in names}
    v1 = (not os.path.islink(AP) and os.path.getsize(AP) == p_sz and sha(AP) == p_sha
          and len(mem) == 3 and not unsafe_members(mem)
          and {n.split("/")[0] for n, k, s in mem} == {"t4_r3_teacher_authority_and_r2_local_audit_payload_20260910"}
          and sorted(names) == sorted(MEMBER_SHA)
          and all(inner[n] == (sz, h) for n, (h, sz) in MEMBER_SHA.items()))
    ok_all &= rec("V01", v1, f"payload bytes={os.path.getsize(AP)} sha256={sha(AP)[:16]}... "
                             f"{'MATCH' if sha(AP) == p_sha else 'MISMATCH'} prompt section 1; "
                             f"3 regular members, 0 unsafe, single root, all 3 member bytes+SHA match the "
                             f"extracted immutable_authority copy",
                  f"{AP}; {A}")

    # V02 R2 archive structure + its two manifests
    mem2 = tar_list(R2ARC)
    reg2 = [n for n, k, s in mem2 if k == "regular"]
    ok_f2, ok_s2, n2 = check_manifests(r2root)
    roots2 = sorted({n.split("/")[0] for n, k, s in mem2})
    v2 = (sha(R2ARC) == PROMPT_SHA[R2ARC][0] and os.path.getsize(R2ARC) == PROMPT_SHA[R2ARC][1]
          and roots2 == [T2] and not unsafe_members(mem2) and len(reg2) == 51
          and ok_f2 and ok_s2 and not any(n.endswith(".pyc") or "__pycache__" in n for n in reg2))
    ok_all &= rec("V02", v2, f"R2 archive bytes={os.path.getsize(R2ARC)} sha ok={sha(R2ARC) == PROMPT_SHA[R2ARC][0]}, "
                             f"single root={roots2}, members={len(mem2)} regular={len(reg2)}, unsafe=0; "
                             f"MANIFEST.files={n2[0]} covers all regular files, MANIFEST.sha256={n2[2]} excludes self and all hashes recompute",
                  f"{R2ARC}; {r2root}/MANIFEST.files, MANIFEST.sha256")

    # V03 prompt section 1 identities
    bad3 = [rel for rel, (h, sz) in R2_KEY_SHA.items()
            if sha(f"{R}/{rel}") != h or os.path.getsize(f"{R}/{rel}") != sz]
    bad3 += [f"before:{rel}" for rel, (h, sz) in R2_BEFORE_SHA.items()
             if sha(os.path.join(r2root, rel)) != h or os.path.getsize(os.path.join(r2root, rel)) != sz]
    bad3 += [f"r2_manifest_sha:{rel}" for rel, h in (
        ("MANIFEST.files", "795077087e26e552206c84d8f4c6b1f6f7a7af4ff0f0c7953b3051987ff3ed3a"),
        ("MANIFEST.sha256", "7a2d05a4b0ef70b8f6e2943393f91d36f673c03ae38b59bb2d6e20783ade790b"))
        if sha(os.path.join(r2root, rel)) != h]
    ok_all &= rec("V03", not bad3, f"5 immutable R2 content SHAs+bytes hit in the R3 baseline; 3 rewritable "
                                 f"files match their pre-change R2 identities; R2 both manifest SHAs match "
                                 f"section 1; deviations={bad3[:4]}",
                  "prompt section 1; live sha256 recompute")

    # V04 R2 accepted content anchors (read-only re-derivation of counts, no data recompute)
    rx = rows(f"{R}/DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv")
    pr = rows(f"{R}/DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv")
    corp_r = [r for r in rx if r["asset_name"] == "corpus_v1.jsonl"]
    pa = rows(f"{R}/inherited_r1/DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv")
    corp_p = [r for r in pa if r["asset_name"] == "corpus_v1.jsonl"]
    corp_pr = [r for r in pr if r["asset_name"] == "corpus_v1.jsonl"]
    v4 = {"reaction_rows": len(rx), "reaction_unique": len({(r["case_id"], r["reaction_id"], r["asset_name"]) for r in rx}),
          "product_rows": len(pr), "product_unique": len({(r["case_id"], r["line_no_products_jsonl"], r["asset_name"]) for r in pr}),
          "rx_global_rows": len(rows(f"{R}/DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv")),
          "pr_global_rows": len(rows(f"{R}/DEPENDING_39_GOLD_PRODUCT_GLOBAL_LAYERED_STATUS.csv")),
          "pair_seen": f"{sum(1 for r in corp_r if I(r['exact_parent_product_pair_hit']))}/{len(corp_r)}",
          "parent_seen": f"{sum(1 for r in corp_p if I(r['reactant_side_canonical_hit']))}/{len(corp_p)}",
          "product_seen": f"{sum(1 for r in corp_pr if I(r['product_side_hit']))}/{len(corp_pr)}"}
    ok4 = (v4["reaction_rows"] == v4["reaction_unique"] == v4["product_rows"] == v4["product_unique"] == 312
           and v4["rx_global_rows"] == v4["pr_global_rows"] == 39
           and v4["pair_seen"] == "13/39" and v4["parent_seen"] == "15/18" and v4["product_seen"] == "16/39")
    ok_all &= rec("V04", ok4, f"anchors {v4}", "two BY_ASSET matrices, two GLOBAL tables, inherited_r1 parent table")

    # V05 ECLIPSE invariance
    er = rows(f"{R}/inherited_r1/ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv")
    ep = rows(f"{R}/inherited_r1/ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv")
    eh = rows(f"{R}/inherited_r1/ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv")
    cs, ps = {}, {}
    for r in er:
        cs[r["exact_status"]] = cs.get(r["exact_status"], 0) + 1
    for r in ep:
        ps[r["parent_split_exposure"]] = ps.get(r["parent_split_exposure"], 0) + 1
    hits = sum(I(r["fold_gold_product_hit"]) for r in eh)
    v5 = (len(er) == 390 and len(ep) == 180 and len(eh) == 390 and hits == 113
          and f"{cs.get('TRAIN')}/{cs.get('VAL')}/{cs.get('TEST')}/{cs.get('NONE')}" == "190/35/25/140"
          and f"{ps.get('TRAIN')}/{ps.get('VAL')}/{ps.get('TEST')}" == "142/21/17"
          and sha(f"{R}/ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv") == sha(
              f"{r2root}/ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv"))
    ok_all &= rec("V05", v5, f"reaction x fold=390 TRAIN/VAL/TEST/NONE=190/35/25/140; parent x fold=180 "
                             f"142/21/17; per-fold hit cells={hits}; fold matrix byte-identical to R2/R1", "inherited_r1/ECLIPSE_*")

    # V06 parent boundary row unique
    with open(f"{R}/{BM}", encoding="utf-8", newline="") as f:
        rdg = list(csv.reader(f))
    head, body = rdg[0], [r for r in rdg[1:] if r]
    col = head.index("attested_finding_or_value")
    ti = [i for i, r in enumerate(body) if r[head.index("row_type")] == "DIMENSION"
          and r[head.index("boundary_dimension")] == "parent_only_input_identity"]
    ok_all &= rec("V06", len(ti) == 1 and len(body) == 16, f"target DIMENSION row indices={ti}, "
                        f"total data rows={len(body)}, columns={len(head)}", BM)

    # V07 four-column label exact, task id gone
    raw7 = rd(f"{R}/{BM}")
    cell = body[ti[0]][col] if len(ti) == 1 else ""
    v7 = (all(c in cell for c in FOUR_FIELDS) and "parent_smiles_rdkit_canonical" in cell
          and "task id" not in raw7 and "pollutant name" not in raw7 and OLD_LABEL not in raw7
          and "gold_columns_in_parent_csv=0" in cell and cell.count(", parent_") == 3)
    ok_all &= rec("V07", v7, f"cell now lists {FOUR_FIELDS}; 'task id' occurrences in the whole file=0; "
                             f"'pollutant name'=0; gold_columns_in_parent_csv=0 still stated", f"{BM} row {ti}")

    # V08 old blocking sentence absent
    dft = rd(f"{R}/{DRAFT}")
    ok_all &= rec("V08", OLD_SENT not in dft and "T6 不进入" not in dft,
                  f"old sentence occurrences={dft.count(OLD_SENT)}, old fragment occurrences={dft.count('T6 不进入')}",
                  f"{DRAFT} closing line")

    # V09 new independence sentence present exactly once, on the last line
    lines = dft.rstrip("\n").split("\n")
    v9 = (dft.count(NEW_SENT) == 1 and lines[-1] == NEW_SENT and len(lines) == 93
          and [i + 1 for i, l in enumerate(lines) if "T6" in l] == [93])
    ok_all &= rec("V09", v9, f"new sentence occurrences={dft.count(NEW_SENT)} at line {len(lines)} "
                             f"(only T6-bearing line); line count unchanged=93", f"{DRAFT} line 93")

    # V10 A/B neutrality and role still awaiting the teacher
    opts = [l for l in lines if l.startswith("- **选项")]
    v10 = (len(opts) == 2 and "不推荐" in dft and "AWAITING_HUANG_TEACHER_REVIEW" in dft
           and opts == [l for l in rd(f"{r2root}/{DRAFT}").split("\n") if l.startswith("- **选项")]
           and "状态：**本地草稿 — 未发送 / 未上传。**" in dft)
    ok_all &= rec("V10", v10, f"{len(opts)} A/B option lines byte-identical to the R2 draft; neutrality "
                             f"statement kept; model role still AWAITING_HUANG_TEACHER_REVIEW; draft still local-only",
                  f"{DRAFT} A/B block + status header")

    # V11 everything else in the two report files unchanged
    old_body = [r for r in list(csv.reader(rd(f"{r2root}/{BM}").splitlines()))[1:] if r]
    diff = [(i, j) for i in range(len(body)) for j in range(len(head))
            if body[i][j] != old_body[i][j]]
    old_lines2 = rd(f"{r2root}/{DRAFT}").rstrip("\n").split("\n")
    v11 = (diff == [(ti[0], col)] and len(body) == len(old_body) == 16 and head == list(
        csv.reader(rd(f"{r2root}/{BM}").splitlines()))[0]
        and lines[:92] == old_lines2[:92]
        and "NOT_ESTABLISHED" in raw7 and "VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY" in raw7)
    ok_all &= rec("V11", v11, f"boundary matrix: exactly {len(diff)} changed cell {diff}; header and 8 columns "
                             f"unchanged; teacher draft: first 92 lines byte-identical; runtime-blind in-domain "
                             f"vs strict-unseen-NOT_ESTABLISHED wording untouched", f"{BM}; {DRAFT} vs immutable_r2")

    # V12 no always-true construct in any packaged python source
    pys = [p for p in walk_reg(R) if p.endswith(".py")]
    findings = {p: tautology_scan(os.path.join(R, p)) for p in pys}
    bad12 = {k: v for k, v in findings.items() if v}
    ok_all &= rec("V12", not bad12, f"{len(pys)} packaged python sources scanned with regex+AST; "
                                  f"always-true constructs={sum(len(v) for v in findings.values())}; "
                                  f"hits={list(bad12)[:2]}", "scripts/*.py")

    # V13 fold6/fold8 hard facts
    ok13, sub13, bad13 = fold_gate(R)
    ok_all &= rec("V13", ok13, f"V23 replacement gate: {len(sub13)} explicit sub-checks on "
                               f"INPUT_IDENTITIES.csv fold rows + README + teacher draft; failed={bad13[:4]}",
                  "INPUT_IDENTITIES.csv rows 26-27; README.md fold paragraph; teacher draft fold sentence")

    # V14 config SHAs never impersonate a split SHA
    rd_ = rd(f"{R}/README.md")
    v14 = (all(CFG[t] not in rd_ and CFG[t] not in dft for t in FOLD)
           and all(sub13[f"readme_quotes_{t}_actual_split_sha"] and sub13[f"teacher_draft_quotes_{t}_actual_split_sha"]
                   for t in FOLD)
           and sub13["readme_fold_lines_cite_only_actual_split_hex"]
           and sub13["teacher_draft_fold_lines_cite_only_actual_split_hex"])
    ok_all &= rec("V14", v14, f"config SHA prefixes {sorted(CFG.values())} occurrences in README=0 and in teacher "
                             f"draft=0; both actual split SHAs cited instead (draft cites the 12-char prefix form); "
                             f"fold-mentioning lines carry no other hex token", "README.md; " + DRAFT)

    # V15 mutation harness: 8 negative cases must all be detected, clean artefact must pass
    mp = os.path.join(R, "scripts", "r3_mutation_test.py")
    jpath = os.path.join(R, MUT_JSON)
    mj = json.load(open(jpath, encoding="utf-8")) if os.path.isfile(jpath) else {}
    res = {"detected": None, "total": None, "clean_pass": None, "exit": None}
    if os.path.isfile(mp):
        tmp = tempfile.mkdtemp(prefix="t4r3_v15_", dir="/tmp")
        try:
            p = subprocess.run([sys.executable, "-B", mp, "--root", R, "--json", f"{tmp}/recheck.json"],
                               capture_output=True, text=True)
            last = [l for l in p.stdout.strip().split("\n")
                    if l.startswith("{") and '"harness"' in l]
            res = json.loads(last[-1]) if last else res
        except (OSError, ValueError) as e:
            res["error"] = str(e)[:120]
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    v15 = (res["detected"] == 8 and res["total"] == 8 and res["clean_pass"] is True and res["exit"] == 0
           and mj.get("summary", {}).get("all_mutations_detected") is True
           and mj.get("validator_source_sha256") == sha(os.path.join(R, "scripts", "p6_validator.py")))
    ok_all &= rec("V15", v15, f"live harness re-run: detected={res['detected']}/{res['total']}, "
                             f"unmodified R3 artefact V23 PASS={res['clean_pass']}, exit={res['exit']}; "
                             f"packaged {MUT_JSON} agrees and records the validator source SHA",
                  f"{MUT_JSON}; scripts/r3_mutation_test.py")

    # V16 data / metric / overlap / ECLIPSE content files unchanged
    bad16 = [f for f in NONMUT if sha(f"{R}/{f}") != sha(f"{r2root}/{f}")]
    bad16 += [f"inherit:{f}" for f in walk_reg(f"{R}/inherited_r1")
              if sha(os.path.join(R, "inherited_r1", f)) != sha(os.path.join(r2root, "inherited_r1", f))]
    bad16 += [f for f, (h, s) in R2_KEY_SHA.items() if sha(f"{R}/{f}") != h]
    ok_all &= rec("V16", not bad16, f"{len(NONMUT)} named content files + {len(walk_reg(f'{R}/inherited_r1'))} "
                                  f"inherited_r1 files byte-identical to the R2 baseline and to the section 1 "
                                  f"SHAs; deviations={bad16[:3]}", "live sha256 recompute vs immutable_r2")

    # V17 every non-whitelisted R2 file byte-identical
    base = walk_reg(r2root)
    changed = sorted({f for f in base if sha(os.path.join(r2root, f)) != sha(os.path.join(R, f))})
    v17 = set(changed) <= WHITELIST and len(base) == 51 and all(os.path.isfile(os.path.join(R, f)) for f in base)
    ok_all &= rec("V17", v17, f"{len(base)} R2 regular files present; {len(base) - len(changed)} byte-identical; "
                             f"changed={changed} (all inside the section 8 whitelist={set(changed) <= WHITELIST})",
                  "walk immutable_r2 vs RETURN_DIR")

    # V18 three false flags
    fs = rd(f"{R}/FINAL_STATUS.txt").splitlines()
    v18 = (fs[1:4] == ["MODEL_RERUN=false", "RAW_PREDICTIONS_CHANGED=false", "METRICS_CHANGED=false"]
           and "true" not in " ".join(fs[1:4]))
    ok_all &= rec("V18", v18, "FINAL_STATUS lines 2-4 are exactly the three false flags", "FINAL_STATUS.txt")

    # V19 T6 independence stated true (and no T6 content was read to prove it)
    v19 = ("T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true" in "\n".join(fs)
           and "T6按独立老师合同继续推进" in dft and "不进入T6" in dft)
    ok_all &= rec("V19", v19, "FINAL_STATUS carries T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true and the corrected "
                             f"draft line states T4 does not enter T6 while T6 proceeds independently; no T6-named "
                             f"path was opened by any R3 script", "FINAL_STATUS.txt; " + DRAFT)

    # V20 draft still local / not sent
    v20 = ("TEACHER_DECISION_REQUEST_SENT=false" in "\n".join(fs) and "未发送 / 未上传" in dft
           and "不发送、不上传" in dft)
    ok_all &= rec("V20", v20, "FINAL_STATUS says the decision request was not sent; draft still marked local "
                             "draft - not sent / not uploaded", "FINAL_STATUS.txt; " + DRAFT)

    # V21 no model / GPU / network / scoring / overlap / OOF execution
    imps = {}
    for p in [p for p in walk_reg(R) if p.endswith(".py")]:
        tree = ast.parse(rd(os.path.join(R, p)))
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                imps.setdefault(p, []).extend(a.name.split(".")[0] for a in n.names)
            elif isinstance(n, ast.ImportFrom) and n.module:
                imps.setdefault(p, []).append(n.module.split(".")[0])
    out_allow = sorted({(p, m) for p, ms in imps.items() for m in ms if m not in ALLOWED_IMPORTS})
    cmds = [ln.strip()[2:].strip() for ln in rd(f"{R}/COMMAND_LOG.txt").split("\n") if ln.strip().startswith("$ ")]
    bad_cmd = [c for c in cmds if c.split()[0] not in ALLOWED_CMD]
    v21 = not out_allow and not bad_cmd and len(cmds) >= 12
    ok_all &= rec("V21", v21, f"{len(imps)} packaged scripts import only stdlib-allowlist modules "
                             f"(outside={out_allow[:3]}); {len(cmds)} logged commands, all from the allowed "
                             f"program set (no pip/conda/git/curl/nvidia-smi/torch): {bad_cmd[:2]}",
                  "AST import scan of scripts/*.py; COMMAND_LOG.txt `$ ` lines")

    # V22 zero writes outside the three R3 domains
    viol = []
    own = {f"{T}.tar.gz", f"{T}.tar.gz.identity.txt", f"{T}.tar.gz.validation.txt", T}
    for d in (RR, f"{ROOT}/HPC_Inputs"):
        for e in sorted(os.listdir(d)):
            if re.search(r"t6", e, re.I):        # section 3: T6 names are never opened at all
                continue
            p = os.path.join(d, e)
            if e not in own and os.path.isfile(p) and os.path.getmtime(p) >= R3_START_EPOCH - 2:
                viol.append(p)
    for e in sorted(os.listdir(ROOT)):
        if re.search(r"t6", e, re.I):
            continue
        p = os.path.join(ROOT, e)
        if os.path.isfile(p) and os.path.getmtime(p) >= R3_START_EPOCH - 2:
            viol.append(p)
    ws = os.path.dirname(W)                      # /usrdata/EnzymeCAGE_data/workspaces
    for e in sorted(os.listdir(ws)):
        if e == T or re.search(r"t6", e, re.I):   # T6 workspace dirs: name skipped, never stat-ed
            continue
        top = os.path.join(ws, e)
        for root_, dirs, fs in os.walk(top):
            if root_.count(os.sep) - top.count(os.sep) >= 2:
                dirs[:] = []
            for f in fs:
                p = os.path.join(root_, f)
                if os.path.getmtime(p) >= R3_START_EPOCH - 2:
                    viol.append(p)
    b = json.load(open(f"{R}/inherited_r1/BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json", encoding="utf-8"))
    frozen = []
    for p, want in ((f"{RR}/enzymecage_three_module_t4_teacher_countersigned_18_depending_v32_eclipse_blind_evaluation_20260909.tar.gz",
                     b["base_archive"]["sha256"]),
                    (f"{RR}/enzymecage_three_module_t4_teacher_countersigned_18_depending_v32_eclipse_blind_evaluation_20260909/T4_PREDICTION_RAW_FREEZE.tar.gz",
                     b["raw_freeze"]["archive_sha256"]),
                    (R2ARC, PROMPT_SHA[R2ARC][0])):
        frozen.append((os.path.basename(p), sha(p) == want, os.path.getmtime(p) < R3_START_EPOCH - 2))
    v22 = not viol and all(h and m for _, h, m in frozen)
    ok_all &= rec("V22", v22, f"base T4 package + raw freeze + R2 archive SHA unchanged and mtime < {R3_START_ISO}; "
                              f"{len(frozen)} frozen objects ok; no foreign file newer than the R3 start in "
                              f"HPC_Returned_Result_Summaries, HPC_Inputs, ROOT files or sibling workspaces "
                              f"(T6-named entries skipped by name, never stat-ed): {viol[:3]}",
                  "live stat/sha; prompt section 3 read prohibition honoured")

    # V23 secret / forbidden raw asset packaging scan.  The two DSN alternatives keep their
    # userinfo character classes free of regex metacharacters on purpose: that is what stops the
    # detector strings carried by scripts/p6_validator.py (and by this file) from matching
    # themselves, while a genuine user-password-at-host connection string still trips the gate.
    sec = re.compile(r"(BEGIN [A-Z ]*PRIVATE KEY|aws_secret_access_key\s*[=:]|(?:api_|access_)?token\s*=\s*['\"][A-Za-z0-9+/]{20,}"
                     r"|bearer [A-Za-z0-9+/._-]{30,}|password\s*[=:]\s*['\"][^'\"]{6,}"
                     r"|postgres(?:ql)?://[A-Za-z0-9_.\-]+:[^\s'\"\[\]\\]+@"
                     r"|mysql://[A-Za-z0-9_.\-]+:[^\s'\"\[\]\\]+@)", re.I)
    forb = re.compile(r"(^|/)(corpus_v1\.jsonl|donor_index\.jsonl|split_bbd\.json|config\.json|RAW_PREDICTIONS\.jsonl"
                      r"|.*\.(pt|ckpt|bin|env|onnx|pkl)$)", re.I)
    bad23 = []
    # positive control for the detector itself, assembled at run time so that no credential-like
    # literal ever exists in a packaged file
    ctrl = "mys" + "ql://" + "svc_user" + ":" + "SyntheticPw9" + "@" + "10.0.0.1:3306" + "/db"
    ctrl_hit = bool(sec.search(ctrl))
    for rel in walk_reg(R):
        p = os.path.join(R, rel)
        if forb.search(rel) or rel.endswith(".pyc") or "__pycache__" in rel:
            bad23.append(("forbidden_name", rel))
        elif os.path.getsize(p) > 5 << 20:
            bad23.append(("oversize", rel))
        elif rel.endswith((".py", ".md", ".txt", ".csv", ".json", ".jsonl")):
            m = sec.search(rd(p))
            if m:
                bad23.append(("secret", rel, m.group(0)[:40]))
    ok23 = not bad23 and ctrl_hit
    ok_all &= rec("V23", ok23, f"{len(walk_reg(R))} packaged files: 0 secret patterns, 0 raw gold/split/"
                               f"config/model assets, 0 oversize, 0 pyc; a synthetic DSN built at run "
                               f"time (never written to any file) is detected by the same regex, which "
                               f"proves the detector is live while its own source stays clean; "
                               f"deviations={bad23[:3]}",
                  "walk of RETURN_DIR with regex; control match=%s" % ctrl_hit)

    # V24 MANIFEST.files covers all regular files incl both manifests
    ok24, _, n24 = check_manifests(R)
    ok_all &= rec("V24", ok24, f"MANIFEST.files has {n24[0]} entries == {n24[1]} walked regular files "
                            f"(LC_ALL=C sorted, includes both manifests)", "MANIFEST.files")

    # V25 MANIFEST.sha256 excludes itself and verifies
    _, ok25, n25 = check_manifests(R)
    ok_all &= rec("V25", ok25, f"MANIFEST.sha256 has {n25[2]} entries, excludes itself, every hash recomputed "
                            f"from live bytes (equivalent to sha256sum -c)", "MANIFEST.sha256")
    return ok_all


def gates_archive(R, ARC, UNPACK, require_validation=False):
    """V26-V30 on the landed archive and its sidecars (V01-V25 already re-run on R)."""
    ok_all = True
    st = os.stat(ARC)
    mem = tar_list(ARC)
    reg = [n for n, k, s in mem if k == "regular"]
    roots = sorted({n.split("/")[0] for n, k, s in mem})
    mt = st.st_mtime
    ok_all &= rec("V26", roots == [T] and not unsafe_members(mem) and len(reg) == len(walk_reg(R))
                  and open(ARC, "rb").read(2) == b"\x1f\x8b"
                  and R3_START_EPOCH - 2 <= mt <= time.time() + 120,
                  f"gzip magic ok, single root={T}, members={len(mem)} regular={len(reg)}, unsafe=0, "
                  f"archive mtime={time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(mt))} (UTC, inside this run)",
                  f"tarfile listing of {ARC}")

    idp = ARC + ".identity.txt"
    valp = ARC + ".validation.txt"
    rec7 = dict(l.split("=", 1) for l in rd(idp).splitlines() if "=" in l) if os.path.isfile(idp) else {}
    ok27 = (rec7.get("ARCHIVE_PATH") == ARC and int(rec7.get("ARCHIVE_BYTES", -1)) == st.st_size
            and rec7.get("ARCHIVE_SHA256") == sha(ARC) and rec7.get("SINGLE_ROOT") == T
            and int(rec7.get("MEMBER_REGULAR_FILES", -1)) == len(reg)
            and rec7.get("README_MD_SHA256") == sha(f"{R}/README.md")
            and rec7.get("FINAL_STATUS_TXT_SHA256") == sha(f"{R}/FINAL_STATUS.txt")
            and rec7.get("MANIFEST_SHA256_SHA256") == sha(f"{R}/MANIFEST.sha256"))
    ok_all &= rec("V27", ok27, f"identity record re-read from disk and matched against the live archive "
                             f"bytes={st.st_size} sha256={sha(ARC)[:16]}... plus README/FINAL_STATUS/both "
                             f"manifest hashes of the FRESH unpack", idp)

    # Freshness is proved by the mkdtemp() parent directory: tar restores the packaged mtimes onto
    # the extracted entries, so the package directory itself carries the OLD mtime by design and
    # cannot be the evidence.  The parent temp directory was created by this run after the archive
    # landed, and its mtime/ctime are both at or after the archive mtime.
    up = UNPACK or os.path.dirname(R.rstrip("/"))
    fst = os.stat(up)
    fresh = (up.startswith("/tmp/") and os.path.isdir(up) and R == os.path.join(up, T) and R != R3
             and fst.st_mtime >= mt - 2 and fst.st_ctime >= mt - 2)
    v28 = fresh and len(G) >= 27 and all(g["evidence"].strip() and g["locator"].strip() for g in G)
    ok_all &= rec("V28", v28, f"this run reads only {R}: extracted into the temp directory {up} that "
                              f"this run created after the archive landed (dir mtime "
                              f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(fst.st_mtime))} and ctime "
                              f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(fst.st_ctime))} >= archive "
                              f"mtime {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(mt))}; the extracted "
                              f"entries keep their packaged mtimes, as tar intends); "
                              f"validator source sha256={sha(os.path.abspath(__file__))}; "
                              f"command={' '.join(sys.argv[:6])} ; gates so far={len(G)} all carrying "
                              f"evidence+locator",
                  f"{UNPACK}; {W}/logs/r3_validator_archive.json")

    trio = [(p, os.path.isfile(p) and not os.path.islink(p) and os.path.getsize(p) > 0)
            for p in (ARC, idp) + ((valp,) if require_validation else ())]
    ok_all &= rec("V29", all(k for _, k in trio) and len(trio) >= 2,
                  f"same-basename external files in RETURN_ROOT are regular non-symlink and non-empty: "
                  f"{[(os.path.basename(p), k) for p, k in trio]}"
                  + ("" if require_validation else "; the validation record itself is re-checked by the "
                     f"post-write run that passes --require-validation-record"),
                  RR)

    fs = rd(f"{R}/FINAL_STATUS.txt").splitlines()
    pending = [g["gate"] for g in G if g["verdict"] != "PASS"]
    ok_all &= rec("V30", fs[0] == FS_READY and not pending, f"FINAL_STATUS line 1 == the section 0/12 READY "
                          f"constant and no gate recorded so far is FAIL (failed={pending}); if any gate fails "
                          f"this line must be replaced by BLOCKED_VALIDATION_FAILED",
                  "FINAL_STATUS.txt vs this run's gate list")
    return ok_all


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["content", "archive"], default="content")
    ap.add_argument("--root", default=R3, help="RETURN_DIR (content) or <unpack>/TASK_ID (archive)")
    ap.add_argument("--archive", default=f"{RR}/{T}.tar.gz")
    ap.add_argument("--unpack-dir", default="")
    ap.add_argument("--require-validation-record", dest="need_val", action="store_true")
    ap.add_argument("--scan-source", default="", help="run only the V12 tautology scan on this file")
    ap.add_argument("--out-json", default="")
    a = ap.parse_args()
    if a.scan_source:
        f = tautology_scan(a.scan_source)
        print(json.dumps({"gate": "V12", "path": a.scan_source, "verdict": "PASS" if not f else "FAIL",
                          "findings": f[:8], "finding_count": len(f)}, sort_keys=True))
        sys.exit(0 if not f else 1)
    ok = gates_content(a.root)
    if a.stage == "archive":
        ok = gates_archive(a.root, a.archive, a.unpack_dir, a.need_val) and ok
    fails = sorted({g["gate"] for g in G if g["verdict"] != "PASS"})
    out = {"stage": a.stage, "root": a.root, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "r3_start_utc": R3_START_ISO, "validator_source_sha256": sha(os.path.abspath(__file__)),
           "argv": " ".join(sys.argv), "gates": sorted(G, key=lambda g: g["gate"]),
           "executed": len(G), "fail_count": len(fails), "failed": fails}
    lp = a.out_json or f"{W}/logs/r3_validator_{a.stage}.json"
    os.makedirs(os.path.dirname(lp), exist_ok=True)
    with open(lp, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f"executed={out['executed']} fails={out['fail_count']} -> {lp}")
    sys.exit(0 if not fails and ok else 1)


main()
