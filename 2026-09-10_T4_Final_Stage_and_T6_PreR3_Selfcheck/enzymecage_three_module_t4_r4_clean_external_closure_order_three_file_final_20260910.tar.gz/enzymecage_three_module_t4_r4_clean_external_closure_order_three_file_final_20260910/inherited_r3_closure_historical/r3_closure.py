#!/usr/bin/env python3
"""T4-R3 section 11: external three-file closure for the landed archive.

  --stage identity    write <archive>.identity.txt from the archive as it sits on disk
  --stage validation  unpack the LANDED archive into a NEW temp dir, run the packaged
                      r3_validator.py --stage archive against that fresh copy only, write
                      <archive>.validation.txt from its per-gate output, then confirm the
                      result from a second fresh unpack plus an independent subprocess;
                      if any gate or that confirmation fails, FINAL_STATUS.txt line 1 is replaced
                      by T4_R3_STATUS=BLOCKED_VALIDATION_FAILED and the archive must be resealed
  --stage verify      re-run only the post-write independent checks (prints one JSON line,
                      writes nothing) so the auditor can reproduce the closure

The executor never validates the pre-packing directory in place and calls it an external pass.
PYTHONDONTWRITEBYTECODE=1 / python3 -B."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from datetime import datetime, timezone

T = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R3 = f"{RR}/{T}"
AP = f"{ROOT}/HPC_Inputs/t4_r3_teacher_authority_and_r2_local_audit_payload_20260910.tar.gz"
T2 = "enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909"
R2ARC = f"{RR}/{T2}.tar.gz"
READY = "T4_R3_REPORT_VALIDATOR_SIDECAR_CLOSURE_READY_FOR_LOCAL_AUDIT"
BLOCKED = "T4_R3_STATUS=BLOCKED_VALIDATION_FAILED"
STATUS_KEYS = ["MODEL_RERUN=false", "RAW_PREDICTIONS_CHANGED=false", "METRICS_CHANGED=false",
               "STRICT_UNSEEN_BLIND_EVALUATION=NOT_ESTABLISHED",
               "CURRENT_METRICS=VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY",
               "MODEL_ROLE_DECISION=AWAITING_HUANG_TEACHER_REVIEW",
               "TEACHER_DECISION_REQUEST_SENT=false",
               "T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true", "EXTERNAL_THREE_FILE_DELIVERY=PASS"]
GATES = ["V%02d" % i for i in range(1, 31)]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def utc(ep):
    return datetime.fromtimestamp(ep, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def fresh_unpack(arc, prefix):
    """new temp dir created AFTER the archive landed, holding only the re-extracted copy"""
    assert os.path.getmtime(arc) <= time.time(), "archive must be on disk first"
    d = tempfile.mkdtemp(prefix=prefix, dir="/tmp")
    with tarfile.open(arc, "r:gz") as tf:
        tf.extractall(d)          # noqa: S202 - trusted, self-produced archive
    return d


def run_validator(unpack, arc, out_json, need_val):
    cmd = [sys.executable, "-B", f"{R3}/scripts/r3_validator.py", "--stage", "archive",
           "--root", f"{unpack}/{T}", "--archive", arc, "--unpack-dir", unpack,
           "--out-json", out_json] + (["--require-validation-record"] if need_val else [])
    p = subprocess.run(cmd, capture_output=True, text=True)
    return cmd, p


def manifest_stage():
    """section 8/9: regenerate the two manifests as the very last write before packing.

    MANIFEST.files lists every regular file in the return dir, including both manifests, in
    byte (LC_ALL=C) order; MANIFEST.sha256 carries '<hash><two spaces><path>' for every entry
    except itself, exactly like the sha256sum -c format.  Paths are relative to the return dir and
    keep their subdirectory prefix (scripts/, tables/, inherited_r1/)."""
    reg = sorted(os.path.relpath(os.path.join(r_, f), R3)
                 for r_, _, fs in os.walk(R3) for f in fs)
    with open(f"{R3}/MANIFEST.files", "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(reg) + "\n")
    lines = ["%s  %s" % (sha(os.path.join(R3, r)), r) for r in reg if r != "MANIFEST.sha256"]
    with open(f"{R3}/MANIFEST.sha256", "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print("MANIFEST.files: %d entries; MANIFEST.sha256: %d entries (excludes itself)"
          % (len(reg), len(lines)))
    print("MANIFEST.files sha256:", sha(f"{R3}/MANIFEST.files"))
    print("MANIFEST.sha256 sha256:", sha(f"{R3}/MANIFEST.sha256"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["manifest", "identity", "validation", "verify"],
                    default="validation")
    ap.add_argument("--archive", default=f"{RR}/{T}.tar.gz")
    ap.add_argument("--unpack-dir", default="")
    a = ap.parse_args()
    if a.stage == "manifest":
        manifest_stage()
        return
    ARC, IDP, VALP = a.archive, a.archive + ".identity.txt", a.archive + ".validation.txt"
    st = os.stat(ARC)
    now = utc(time.time())
    with tarfile.open(ARC, "r:gz") as tf:
        mem = tf.getmembers()
    reg = [m for m in mem if m.isfile()]
    roots = sorted({m.name.split("/")[0] for m in mem})
    arch_sha = sha(ARC)

    if a.stage == "identity":
        idl = ["TASK_ID=" + T, "ARCHIVE_PATH=" + ARC, "ARCHIVE_FILENAME=" + os.path.basename(ARC),
               "ARCHIVE_BYTES=%d" % st.st_size, "ARCHIVE_SHA256=" + arch_sha,
               "ARCHIVE_FORMAT=gzip tar, single root, safe members only",
               "SINGLE_ROOT=" + roots[0], "MEMBER_TOTAL=%d" % len(mem),
               "MEMBER_REGULAR_FILES=%d" % len(reg),
               "MEMBER_MTIME_MIN_UTC=" + utc(min(m.mtime for m in mem)),
               "MEMBER_MTIME_MAX_UTC=" + utc(max(m.mtime for m in mem)),
               "ARCHIVE_MTIME_UTC=" + utc(st.st_mtime), "IDENTITY_GENERATED_UTC=" + now,
               "README_MD_SHA256=" + sha(f"{R3}/README.md"),
               "FINAL_STATUS_TXT_SHA256=" + sha(f"{R3}/FINAL_STATUS.txt"),
               "MANIFEST_FILES_SHA256=" + sha(f"{R3}/MANIFEST.files"),
               "MANIFEST_SHA256_SHA256=" + sha(f"{R3}/MANIFEST.sha256"),
               "AUTHORITY_PAYLOAD_SHA256=" + sha(AP) + " (t4_r3_teacher_authority_and_r2_local_audit_payload_20260910.tar.gz, unmodified)",
               "R2_INPUT_ARCHIVE_SHA256=" + sha(R2ARC) + " (the only result input of this round, unmodified)",
               "VALIDATION_PATH=" + VALP,
               "NOTE=identity of the archive as it sits on disk; it is re-read and re-hashed by the "
                    "external validator run and by the post-write independent subprocess"]
        with open(IDP, "w", encoding="utf-8") as f:
            f.write("\n".join(idl) + "\n")
        print("IDENTITY written:", IDP, st.st_size, arch_sha)
        return

    # ---- fresh unpack of the landed archive, validator reads ONLY that copy ----
    U1 = a.unpack_dir or fresh_unpack(ARC, "t4r3_reverify_")
    cmd1, p1 = run_validator(U1, ARC, f"{W}/logs/r3_validator_archive.json", False)
    j1 = json.load(open(f"{W}/logs/r3_validator_archive.json", encoding="utf-8"))
    print("archive stage: exit=%d executed=%d fails=%d root=%s" % (p1.returncode, j1["executed"],
                                                                  j1["fail_count"], j1["root"]))
    if a.stage == "verify":
        trio = [q for q in (ARC, IDP, VALP) if os.path.islink(q) or not os.path.isfile(q)]
        print(json.dumps({"stage": "verify", "unpack": U1, "exit_code": p1.returncode,
                          "gates": j1["fail_count"], "missing_or_linky_sidecars": trio}, sort_keys=True))
        sys.exit(0 if p1.returncode == 0 and not trio else 1)

    gates = {g["gate"]: g for g in j1["gates"]}
    fails = [g for g in GATES if gates.get(g, {}).get("verdict") != "PASS"]
    # ---- second fresh unpack: the post-write confirmation run, which also demands the record ----
    U2 = fresh_unpack(ARC, "t4r3_postwrite_")
    cmd2, p2 = run_validator(U2, ARC, f"{W}/logs/r3_validator_archive_postwrite.json", True)
    j2 = json.load(open(f"{W}/logs/r3_validator_archive_postwrite.json", encoding="utf-8"))
    ind_pre = verify(U2, "pre")        # identity / tree / key hashes, before the record exists
    gate_ok = p1.returncode == 0 and p2.returncode == 0 and not fails and ind_pre["overall"] == "PASS"
    val = ["T4-R3 TINY REPORT / VALIDATOR / SIDECAR CLOSURE",
           "INDEPENDENT VALIDATION RECORD (prompt section 9, gates V01-V30)",
           "task_id=" + T, "archive=" + ARC, "archive_bytes=%d" % st.st_size,
           "archive_sha256=" + arch_sha, "identity=" + IDP, "validation=" + VALP,
           "validation_generated_utc=" + utc(time.time()),
           "validator_script=scripts/r3_validator.py shipped inside the archive; "
           "source sha256=%s" % j1["validator_source_sha256"],
           "content_stage_run=%s (V01-V25 against the live return dir, log logs/r3_validator_content.json)"
           % json.load(open(f"{W}/logs/r3_validator_content.json", encoding="utf-8"))["utc"],
           "archive_stage_command=%s" % " ".join(cmd1),
           "archive_stage_exit_code=%d (log logs/r3_validator_archive.json)" % p1.returncode,
           "post_write_command=%s" % " ".join(cmd2),
           "post_write_exit_code=%d (log logs/r3_validator_archive_postwrite.json)" % p2.returncode,
           "fresh_temp_mode=two NEW /tmp directories created after the archive landed: %s and %s; the "
           "validator never reads the pre-packing directory in archive stage" % (os.path.basename(U1),
                                                                                os.path.basename(U2)),
           "pre_record_independent_subprocess=%s" % ind_pre["overall"],
           "pre_record_independent_checks=%s (identity vs live archive, fresh tree vs MANIFEST.sha256, "
           "the four key hashes, fresh copy vs live return dir; the record itself did not exist yet, so "
           "its two self-referential checks are confirmed after the write below)"
           % json.dumps(ind_pre["checks"], sort_keys=True),
           "r3_start_utc=%s" % j1["r3_start_utc"], "",
           ]
    for g in GATES:
        e = gates.get(g, {"verdict": "MISSING", "evidence": "gate not executed", "locator": "-"})
        extra = ""
        if g == "V29":
            pv = {x["gate"]: x["verdict"] for x in j2["gates"]}
            extra = ("; post-write run with --require-validation-record over %s: V29=%s (all three "
                     "same-basename files must be regular, non-symlink and non-empty)"
                     % (os.path.basename(U2), pv.get("V29", "n/a")))
        val.append("%s: %s | %s | evidence: %s%s" % (g, e["verdict"], e["evidence"], e["locator"], extra))
    val += ["",
            "OVERALL: " + ("ALL 30 GATES PASS" if gate_ok else "FAILED: " + (",".join(fails) or "provenance recheck")),
            "T4_R3_STATUS: " + (READY if gate_ok else BLOCKED),
            "FINAL_STATUS_LINE1_OF_PACKAGE: " + open(f"{R3}/FINAL_STATUS.txt", encoding="utf-8").read().splitlines()[0],
            "STATUS_CONSTANTS: " + "  ".join(STATUS_KEYS),
            "boundary: no model/inference/rescoring/overlap/ECLIPSE recompute/OOF, no network or GPU, no "
            "write outside this task's workspace, return dir and three sidecars; T6-named entries were "
            "skipped by name and never opened; the teacher draft stays local and neutral on options A/B.",
            ]
    with open(VALP, "w", encoding="utf-8") as f:
        f.write("\n".join(val) + "\n")
    # ---- the record exists now: confirm all six independent checks over it, then append that ----
    # ---- outcome as one final line (appending cannot alter the 30 gate lines it just read)     ----
    ind = verify(U2, "post")
    ok_all = gate_ok and ind["overall"] == "PASS"
    with open(VALP, "a", encoding="utf-8") as f:
        f.write("POST_WRITE_INDEPENDENT_RECHECK: %s | %s | command=%s\n"
                % (ind["overall"], json.dumps(ind["checks"], sort_keys=True), ind["command"]))
    ind_final = verify(U2, "post")     # re-read once more with the finished record on disk
    if not ok_all or ind_final["overall"] != "PASS":
        # a READY claim may not survive a failed external gate
        ok_all = False
        lines = open(f"{R3}/FINAL_STATUS.txt", encoding="utf-8").read().splitlines()
        if lines and lines[0] != BLOCKED:
            with open(f"{R3}/FINAL_STATUS.txt", "w", encoding="utf-8", newline="\n") as f:
                f.write("\n".join([BLOCKED] + lines[1:]) + "\n")
        with open(VALP, "a", encoding="utf-8") as f:
            f.write("STATUS_DOWNGRADED: FINAL_STATUS.txt line 1 replaced by %s; re-pack required\n" % BLOCKED)
        print("FINAL_STATUS line 1 demoted to", BLOCKED)
    json.dump({"utc": utc(time.time()), "archive": ARC, "archive_bytes": st.st_size,
               "archive_sha256": arch_sha, "unpack_1": U1, "unpack_2": U2,
               "archive_stage_exit": p1.returncode, "post_write_exit": p2.returncode,
               "independent_pre_record": ind_pre, "independent_after_record": ind,
               "independent_final": ind_final, "gates_failed": fails,
               "status": "CLOSED" if ok_all else BLOCKED},
              open(f"{W}/logs/r3_closure.json", "w"), indent=2, ensure_ascii=False)
    shutil.rmtree(U1, ignore_errors=True)
    shutil.rmtree(U2, ignore_errors=True)
    print("VALIDATION written:", VALP)
    print("OVERALL:", "ALL30_PASS" if ok_all else "FAILED", "| fails:", fails or "none",
          "| independent: pre=%s post=%s final=%s" % (ind_pre["overall"], ind["overall"],
                                                      ind_final["overall"]))
    sys.exit(0 if ok_all else 1)


def verify(unpack, phase="post"):
    """independent subprocess: re-reads identity, re-hashes the live archive and the fresh tree.

    phase="pre"  only the four checks that do not involve the validation record (it may not exist
                 yet); phase="post" adds the sidecar-trio and 30-PASS-line checks on the record."""
    code = (
        "import hashlib, os\n"
        f"T={T!r}; R3={R3!r}; up={os.path.join(unpack, T)!r}\n"
        "RR=os.path.dirname(R3)\n"
        "ARC=os.path.join(RR, T + '.tar.gz'); IDP=ARC + '.identity.txt'; VALP=ARC + '.validation.txt'\n"
        "def sha(p):\n"
        "    h=hashlib.sha256()\n"
        "    with open(p,'rb') as f:\n"
        "        for c in iter(lambda: f.read(1<<20), b''): h.update(c)\n"
        "    return h.hexdigest()\n"
        "rec=dict(l.split('=',1) for l in open(IDP,encoding='utf-8').read().splitlines() if '=' in l)\n"
        "c1 = (rec['ARCHIVE_PATH']==ARC and int(rec['ARCHIVE_BYTES'])==os.path.getsize(ARC)\n"
        "      and rec['ARCHIVE_SHA256']==sha(ARC) and rec['SINGLE_ROOT']==T)\n"
        "mf=dict((l.split('  ',1)[1], l.split('  ',1)[0]) for l in open(os.path.join(up,'MANIFEST.sha256'),encoding='utf-8').read().splitlines() if '  ' in l)\n"
        "uw={os.path.relpath(os.path.join(r,f),up) for r,_,fs in os.walk(up) for f in fs}\n"
        "c2 = uw==set(mf)|{'MANIFEST.sha256'} and all(sha(os.path.join(up,p))==h for p,h in mf.items())\n"
        "c3 = all(rec[k]==sha(os.path.join(up,p)) for k,p in (('README_MD_SHA256','README.md'),\n"
        "      ('FINAL_STATUS_TXT_SHA256','FINAL_STATUS.txt'),('MANIFEST_FILES_SHA256','MANIFEST.files'),\n"
        "      ('MANIFEST_SHA256_SHA256','MANIFEST.sha256')))\n"
        "c4 = all(os.path.isfile(p) and not os.path.islink(p) and os.path.getsize(p)>0 for p in (ARC,IDP,VALP))\n"
        "c5 = all(sha(os.path.join(up,f))==sha(os.path.join(R3,f)) for f in sorted(uw))\n"
        "gs=[l for l in (open(VALP,encoding='utf-8').read().splitlines() if os.path.isfile(VALP) else []) if l[:3] in "
        + repr(["V%02d" % i for i in range(1, 31)]) + "]\n"
        "c6 = len(gs)==30 and all(l.split(':',1)[1].strip().startswith('PASS') for l in gs)\n"
        "print('POSTWRITE_%s' % ('OK' if all([c1,c2,c3,c4,c5,c6]) else 'FAIL'), c1,c2,c3,c4,c5,c6)\n"
    )
    p = subprocess.run([sys.executable, "-B", "-c", code], capture_output=True, text=True)
    words = p.stdout.split()
    checks = {"identity_matches_live_archive": len(words) > 1 and words[1] == "True",
              "fresh_tree_matches_manifest": len(words) > 2 and words[2] == "True",
              "identity_key_hashes_match_fresh_copy": len(words) > 3 and words[3] == "True",
              "three_sidecars_regular_non_symlink": len(words) > 4 and words[4] == "True",
              "fresh_copy_identical_to_live_return_dir": len(words) > 5 and words[5] == "True",
              "validation_record_has_30_pass_lines": len(words) > 6 and words[6] == "True"}
    considered = ([k for k in checks if k not in ("three_sidecars_regular_non_symlink",
                  "validation_record_has_30_pass_lines")] if phase == "pre" else list(checks))
    return {"phase": phase, "overall": "PASS" if all(checks[k] for k in considered) else "FAIL",
            "checks_considered": sorted(considered), "checks": checks,
            "stdout_sha256": hashlib.sha256(p.stdout.encode()).hexdigest(),
            "stderr_sha256": hashlib.sha256(p.stderr.encode()).hexdigest(),
            "command": "python3 -B -c <independent identity/tree/sidecar/validation recheck>"}


main()
