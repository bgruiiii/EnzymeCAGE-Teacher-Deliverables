#!/usr/bin/env python3
"""T4-R4 section 4: prove what this round changed relative to the returned R3 content.

Two reports are generated from the live tree and the 64 baseline hashes it already carries:

  R3_TO_R4_CHANGED_FILES.csv     one row per path R4 added, rewrote or relocated, with the R3 and
                                 R4 SHA side by side, so a reader can see that the two relocated
                                 closure scripts kept their bytes exactly
  R3_CONTENT_NONMUTATION.json    every non-whitelisted R3 file re-hashed at its R4 path; any
                                 deviation outside README / AUTHORITY / COMMAND_LOG / FINAL_STATUS /
                                 the two manifests is a failing check

The two reports are deliberately written so that gate C04 can re-derive every claim in them from
the tree that contains them: no counts that depend on the moment of writing are stored, only the
invariants (which files may be rewritten, which were added, which were relocated).

PYTHONDONTWRITEBYTECODE=1 / python3 -B; reads only, writes these two files."""
import csv
import hashlib
import json
import os
import time

T = "enzymecage_three_module_t4_r4_clean_external_closure_order_three_file_final_20260910"
T3 = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R4 = f"{RR}/{T}"
BASE_CSV = "R3_BASELINE_FILE_IDENTITIES.csv"
CHG_CSV = "R3_TO_R4_CHANGED_FILES.csv"
NONMUT_JSON = "R3_CONTENT_NONMUTATION.json"
R3ARC = f"{RR}/{T3}.tar.gz"
REWRITE = ["AUTHORITY_AND_SCOPE.md", "COMMAND_LOG.txt", "FINAL_STATUS.txt", "MANIFEST.files",
           "MANIFEST.sha256", "README.md"]
MOVE = {"scripts/r3_closure.py": "inherited_r3_closure_historical/r3_closure.py",
        "scripts/r3_validator.py": "inherited_r3_closure_historical/r3_validator.py"}
COLS = ["r4_path", "change_kind", "r3_path", "r3_bytes", "r3_sha256", "r4_bytes", "r4_sha256",
        "note"]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def walk():
    return sorted(os.path.relpath(os.path.join(r_, f), R4)
                  for r_, _, fs in os.walk(R4) for f in fs)


base = {r["relative_path"]: (int(r["bytes"]), r["sha256"])
        for r in csv.DictReader(open(f"{R4}/{BASE_CSV}", encoding="utf-8", newline=""))}
present = walk()
# the two relocation targets are new paths relative to the R3 baseline, but they are declared as
# relocated_same_sha, not as additions, so the validator and this report must count them the same way
added = [p for p in present if p not in base and p not in set(MOVE.values())]
protected = [p for p in sorted(base) if p not in REWRITE]
notes = {
    "README.md": "section 5: T4-R4 header added, R2 header demoted to inherited background, R3 "
                 "section relabelled HISTORICAL_SUPERSEDED; body text of both kept verbatim",
    "AUTHORITY_AND_SCOPE.md": "section 10: R4 authority chain; delivery layer only",
    "COMMAND_LOG.txt": "section 10: projected from logs/commands.jsonl of this run",
    "FINAL_STATUS.txt": "section 10: 11 lines, content ready / external delivery pending at pack time",
    "MANIFEST.files": "section 8.1 step 4 and step 7: regenerated twice",
    "MANIFEST.sha256": "section 8.1 step 4 and step 7: regenerated twice, self excluded",
}

rows, checks = [], []
for p in added:
    rows.append({"r4_path": p, "change_kind": "added_by_r4", "r3_path": "", "r3_bytes": "",
                 "r3_sha256": "", "r4_bytes": str(os.path.getsize(os.path.join(R4, p))),
                 "r4_sha256": sha(os.path.join(R4, p)),
                 "note": "new R4 report, script or evidence file; absent from the R3 baseline"})
for p in REWRITE:
    same = base[p][1] == sha(os.path.join(R4, p))
    rows.append({"r4_path": p, "change_kind": "rewritten_r4_report", "r3_path": p,
                 "r3_bytes": str(base[p][0]), "r3_sha256": base[p][1],
                 "r4_bytes": str(os.path.getsize(os.path.join(R4, p))),
                 "r4_sha256": sha(os.path.join(R4, p)),
                 "note": notes[p] + ("" if not same else "; bytes happen to be unchanged so far")})
for old, new in sorted(MOVE.items()):
    ok = (os.path.isfile(os.path.join(R4, new)) and not os.path.exists(os.path.join(R4, old))
          and sha(os.path.join(R4, new)) == base[old][1]
          and os.path.getsize(os.path.join(R4, new)) == base[old][0])
    checks.append({"name": f"relocated_byte_identical:{old}", "ok": ok,
                   "detail": f"{old} -> {new}, SHA {base[old][1][:16]}... equal on both sides, "
                             f"old path absent"})
    rows.append({"r4_path": new, "change_kind": "relocated_same_sha", "r3_path": old,
                 "r3_bytes": str(base[old][0]), "r3_sha256": base[old][1],
                 "r4_bytes": str(os.path.getsize(os.path.join(R4, new))),
                 "r4_sha256": sha(os.path.join(R4, new)),
                 "note": "HISTORICAL_SUPERSEDED closure order replaced by T4-R4; moved, never "
                         "deleted, bytes untouched"})

outside = []
for p in protected:
    if p in MOVE:
        continue                                   # already verified at its new path above
    q = os.path.join(R4, p)
    if not os.path.isfile(q) or sha(q) != base[p][1] or os.path.getsize(q) != base[p][0]:
        outside.append(p)
checks.append({"name": "no_change_outside_whitelist", "ok": not outside,
               "detail": f"{len(protected) - len(outside)}/{len(protected)} non-whitelist R3 files "
                         f"byte-identical at their R4 path; deviations={outside}"})
still = [p for p in MOVE if os.path.exists(os.path.join(R4, p))]
checks.append({"name": "old_relocation_paths_removed", "ok": not still,
               "detail": f"old paths still present={still}"})
ident = sum(1 for p in protected if p not in MOVE
            and os.path.isfile(os.path.join(R4, p))
            and sha(os.path.join(R4, p)) == base[p][1])
frozen = {}
for p, h in (("scripts/p6_validator.py", "e5fffaa25d114fd4a673f39d5a9bfce574e7267d50b9fa87f1124d9adf975fcb"),
             ("V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json",
              "a94f7adaa7d011cdb35172e84aeb02ea58dccb31e1e01401f9442a7fc8013cff"),
             ("R2_CONTENT_NONMUTATION.json",
              "48ae85c14860242e9eb9d9477f31ea2cd90778916cff1ca504abd72039dff891"),
             ("T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv",
              "e4eb988ffb274f1e1eb31c7c1a44fc2c0b6da3fd0e7a50adc3cc2d3bbd47aad2"),
             ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
              "DECISION_REQUEST_CORRECTED_DRAFT.md",
              "9465ee87d126764746b7b8fde87b1874b03feeecd8c4b34941ad3148ba1ca964")):
    frozen[p] = {"sha256": sha(os.path.join(R4, p)), "matches_prompt_section_1":
                 sha(os.path.join(R4, p)) == h}
checks.append({"name": "section_1_frozen_identities",
               "ok": all(v["matches_prompt_section_1"] for v in frozen.values()),
               "detail": json.dumps(frozen, sort_keys=True)[:400]})

with open(f"{R4}/{CHG_CSV}", "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=COLS)
    w.writeheader()
    w.writerows(sorted(rows, key=lambda r: r["r4_path"]))
print(f"{CHG_CSV}: {len(rows)} rows (added={len(added)} rewritten={len(REWRITE)} "
      f"relocated={len(MOVE)})")

out = {
    "task_id": T,
    "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "baseline_archive": {"path": R3ARC, "bytes": os.path.getsize(R3ARC), "sha256": sha(R3ARC)},
    "baseline_table": BASE_CSV,
    "method": "every one of the 64 baseline paths is re-hashed over the live R4 tree at the path it "
              "now occupies; the two relocated closure scripts are compared at their new path; the "
              "six whitelisted report/manifest files are the only paths R4 may rewrite",
    "summary": {
        "baseline_regular_files": len(base),
        "non_whitelist_files_verified": len(protected),
        "non_whitelist_files_byte_identical": ident + len(MOVE),
        "byte_identical_files": ident + len(MOVE),
        "whitelist_rewritable": sorted(REWRITE),
        "relocated_pairs": [f"{o} -> {n}" for o, n in sorted(MOVE.items())],
        "added_by_r4": sorted(added),
        "changed": sorted([p for p in REWRITE]),
        "changed_outside_whitelist": outside,
        "old_relocation_paths_still_present": still,
        "failing_checks": sorted(c["name"] for c in checks if not c["ok"])},
    "checks": sorted(checks, key=lambda c: c["name"]),
    "frozen_inputs_verified": frozen,
    "files": sorted(rows, key=lambda r: r["r4_path"]),
}
with open(f"{R4}/{NONMUT_JSON}", "w", encoding="utf-8", newline="") as f:
    json.dump(out, f, indent=2, ensure_ascii=False, sort_keys=True)
    f.write("\n")
print(f"{NONMUT_JSON}: baseline={len(base)} protected={len(protected)} "
      f"identical={ident + len(MOVE)} added={len(added)} failing={out['summary']['failing_checks']}")
