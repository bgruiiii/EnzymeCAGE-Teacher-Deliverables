#!/usr/bin/env python3
"""T4-R2 p1-p3: R1 baseline recheck + asset-local reaction/product status re-derivation
+ global layered status. Evidence-only; reads only immutable_r1 (R1 archive unpacked,
manifest-verified 52/52 + 53/53). No model, no large-asset rescan. PYTHONDONTWRITEBYTECODE=1."""
import csv
import hashlib
import json
import os
import sys

T = "enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R1D = f"{W}/immutable_r1"
OUT = f"{W}/work"
os.makedirs(OUT, exist_ok=True)

ASSETS = ["corpus_v1.jsonl", "donor_index.jsonl", "templates.json",
          "templates.tsv.gz", "templates_implicitH.jsonl",
          "uspto_ranker.txt", "envipath_ranker.txt", "retrieval_ranker.txt"]
RANKERS = {"uspto_ranker.txt", "envipath_ranker.txt", "retrieval_ranker.txt"}
TEMPLATES = {"templates.json", "templates.tsv.gz", "templates_implicitH.jsonl"}


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(name, sub=""):
    with open(os.path.join(R1D, sub, name), encoding="utf-8") as f:
        return list(csv.DictReader(f))


def I(v):
    s = (v or "").strip()
    try:
        return int(s)
    except ValueError:
        return 0


FAIL = []


def anchor(label, got, want):
    ok = str(got) == str(want)
    if not ok:
        FAIL.append(f"{label}: got={got} want={want}")
    print(f"{'OK ' if ok else 'FAIL'} {label}: {got}")


# ---------------------------------------------------------------- §4 inherit identities
INHERIT = [
    "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET.csv",
    "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET.csv",
    "DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv",
    "DEPENDING_EXACT_MATCH_EVIDENCE_LOCATORS.csv",
    "DEPENDING_T4_HIT_PROVENANCE_AND_EXPOSURE.csv",
    "DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY.json",
    "DEPENDING_OPAQUE_RANKER_LIMITATION.md",
    "DEPENDING_AUDITABLE_ASSET_SCHEMA_INVENTORY.csv",
    "ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv",
    "ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv",
    "ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv",
    "NORMALIZATION_CORRECTION_METRIC_INVARIANCE.json",
    "FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv",
    "BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json",
    "README.md",
    "FINAL_STATUS.txt",
]
ident_rows = []
for name in INHERIT:
    p = os.path.join(R1D, name)
    ident_rows.append({
        "r1_file": name,
        "bytes": os.path.getsize(p),
        "sha256": sha256_file(p),
        "r1_manifest_sha256_entry": "",
    })
man = {}
for line in open(os.path.join(R1D, "MANIFEST.sha256"), encoding="utf-8"):
    if line.strip():
        s, rel = line.rstrip("\n").split("  ", 1)
        man[rel] = s
for r in ident_rows:
    r["r1_manifest_sha256_entry"] = man.get(r["r1_file"], "ABSENT_FROM_R1_MANIFEST")
    if r["r1_file"] in man and man[r["r1_file"]] != r["sha256"]:
        FAIL.append(f"inherit sha mismatch vs R1 manifest: {r['r1_file']}")
with open(os.path.join(OUT, "R1_INHERITED_ARTIFACT_IDENTITIES.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(ident_rows[0].keys()))
    w.writeheader()
    w.writerows(ident_rows)
print(f"§4 identities written: {len(ident_rows)} files")

# ---------------------------------------------------------------- §5 reaction
rx = rd("DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET.csv")
anchor("rx rows", len(rx), 312)
keys = [(r["case_id"], r["reaction_id"], r["asset_name"]) for r in rx]
anchor("rx key uniqueness", len(set(keys)), 312)
anchor("rx distinct gold reactions", len({(r["case_id"], r["reaction_id"]) for r in rx}), 39)
anchor("rx assets", len({r["asset_name"] for r in rx}), 8)

rx_new = {}  # (case_id,reaction_id,asset) -> (status, basis)


def rx_asset_status(r):
    a = r["asset_name"]
    if a in RANKERS:
        return "OPAQUE_NOT_AUDITABLE", "ranker asset fixed OPAQUE; excluded from exact-match denominators"
    if I(r["parse_error"]):
        return "P0_PARSE_ERROR_RETAINED", "parse_error=1 on this row"
    if a == "corpus_v1.jsonl":
        if I(r["exact_full_pair_hit"]):
            return "P1_EXACT_REACTION_SEEN", "this corpus row exact_full_pair_hit=1"
        if I(r["exact_parent_product_pair_hit"]):
            return "P2_EXACT_PARENT_PRODUCT_PAIR_SEEN", "this corpus row exact_parent_product_pair_hit=1"
        if I(r["product_side_only_hit"]):
            return "P3_GOLD_PRODUCT_SEEN", "this corpus row product_side_only_hit=1"
        if I(r["parent_side_only_hit"]):
            return "P4_PARENT_SEEN", "this corpus row parent_side_only_hit=1"
        return "P6_NO_EXACT_MATCH", "all corpus exact-match flags 0 on this row"
    if a == "donor_index.jsonl":
        if I(r["parent_side_only_hit"]):
            return "P4_PARENT_SEEN", "this donor row parent_side_only_hit=1"
        return "P6_NO_EXACT_MATCH", "donor row parent_side_only_hit=0 (donor has no product side)"
    hv = I(r["template_applicability_hit"])
    if hv > 0:
        return "P5_TEMPLATE_ONLY", f"this template asset row template_applicability_hit={hv}"
    return "P6_NO_EXACT_MATCH", "this template asset row template_applicability_hit=0"


for r in rx:
    rx_new[(r["case_id"], r["reaction_id"], r["asset_name"])] = rx_asset_status(r)

for r in rx:
    a = r["asset_name"]
    st = rx_new[(r["case_id"], r["reaction_id"], a)][0]
    if a == "donor_index.jsonl":
        assert st in ("P4_PARENT_SEEN", "P6_NO_EXACT_MATCH"), (r["case_id"], st)
        assert I(r["exact_full_pair_hit"]) == 0 and I(r["exact_parent_product_pair_hit"]) == 0 and I(r["product_side_only_hit"]) == 0
    if a in TEMPLATES:
        assert st in ("P5_TEMPLATE_ONLY", "P6_NO_EXACT_MATCH"), (r["case_id"], st)

rx_dist = {}
for (c, rid, a), (st, _) in rx_new.items():
    rx_dist[(a, st)] = rx_dist.get((a, st), 0) + 1

print("== §5 distribution anchors")
anchor("corpus P2", rx_dist.get(("corpus_v1.jsonl", "P2_EXACT_PARENT_PRODUCT_PAIR_SEEN"), 0), 13)
anchor("corpus P3", rx_dist.get(("corpus_v1.jsonl", "P3_GOLD_PRODUCT_SEEN"), 0), 3)
anchor("corpus P4", rx_dist.get(("corpus_v1.jsonl", "P4_PARENT_SEEN"), 0), 16)
anchor("corpus P6", rx_dist.get(("corpus_v1.jsonl", "P6_NO_EXACT_MATCH"), 0), 7)
anchor("donor P4", rx_dist.get(("donor_index.jsonl", "P4_PARENT_SEEN"), 0), 31)
anchor("donor P6", rx_dist.get(("donor_index.jsonl", "P6_NO_EXACT_MATCH"), 0), 8)
anchor("templates.json P5/P6", f"{rx_dist.get(('templates.json','P5_TEMPLATE_ONLY'),0)}/{rx_dist.get(('templates.json','P6_NO_EXACT_MATCH'),0)}", "29/10")
anchor("templates.tsv.gz P5/P6", f"{rx_dist.get(('templates.tsv.gz','P5_TEMPLATE_ONLY'),0)}/{rx_dist.get(('templates.tsv.gz','P6_NO_EXACT_MATCH'),0)}", "8/31")
anchor("templates_implicitH P5/P6", f"{rx_dist.get(('templates_implicitH.jsonl','P5_TEMPLATE_ONLY'),0)}/{rx_dist.get(('templates_implicitH.jsonl','P6_NO_EXACT_MATCH'),0)}", "26/13")
for rk in sorted(RANKERS):
    anchor(f"{rk} OPAQUE", rx_dist.get((rk, "OPAQUE_NOT_AUDITABLE"), 0), 39)

# ---------------------------------------------------------------- §7 reaction global layered
rx_global = {}
rx_global_contrib = {}
for key in {(r["case_id"], r["reaction_id"]) for r in rx}:
    order = None
    for prio in ("P1_EXACT_REACTION_SEEN", "P2_EXACT_PARENT_PRODUCT_PAIR_SEEN", "P3_GOLD_PRODUCT_SEEN"):
        st = rx_new.get(key + ("corpus_v1.jsonl",), ("P6_NO_EXACT_MATCH",))[0]
        if st == prio:
            order = (prio, "corpus_v1.jsonl")
            break
    if order is None:
        p4a = [a for a in ("corpus_v1.jsonl", "donor_index.jsonl")
               if rx_new.get(key + (a,), ("",))[0] == "P4_PARENT_SEEN"]
        if p4a:
            order = ("P4_PARENT_SEEN", "+".join(p4a))
        else:
            p5a = [a for a in sorted(TEMPLATES)
                   if rx_new.get(key + (a,), ("",))[0] == "P5_TEMPLATE_ONLY"]
            if p5a:
                order = ("P5_TEMPLATE_ONLY", "+".join(p5a))
            else:
                order = ("P6_NO_EXACT_MATCH", "none")
    rx_global[key] = order[0]
    rx_global_contrib[key] = order[1]

NEWF = ["asset_local_primary_status", "asset_local_status_basis", "global_layered_status",
        "global_status_basis", "r1_original_primary_status",
        "r1_original_primary_status_valid_for_asset", "correction_note"]
with open(os.path.join(OUT, "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rx[0].keys()) + NEWF)
    w.writeheader()
    for r in rx:
        key = (r["case_id"], r["reaction_id"], r["asset_name"])
        st, basis = rx_new[key]
        g = rx_global[(r["case_id"], r["reaction_id"])]
        gbasis = (f"global priority over auditable assets; contributed by: {rx_global_contrib[(r['case_id'], r['reaction_id'])]}"
                  + (" (ranker assets excluded from exact-match denominators; see DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv)" if r["asset_name"] in RANKERS else ""))
        valid = "TRUE" if st == r["primary_status"] else "FALSE"
        note = "" if valid == "TRUE" else \
            "R1 p8 copied a globally-computed primary_status onto this asset row; corrected here from this row's own asset-local flags only"
        out = dict(r)
        out.update({"asset_local_primary_status": st, "asset_local_status_basis": basis,
                    "global_layered_status": g, "global_status_basis": gbasis,
                    "r1_original_primary_status": r["primary_status"],
                    "r1_original_primary_status_valid_for_asset": valid,
                    "correction_note": note})
        w.writerow(out)

rows = []
for a in ASSETS:
    for st in ["P1_EXACT_REACTION_SEEN", "P2_EXACT_PARENT_PRODUCT_PAIR_SEEN", "P3_GOLD_PRODUCT_SEEN",
               "P4_PARENT_SEEN", "P5_TEMPLATE_ONLY", "P6_NO_EXACT_MATCH", "P0_PARSE_ERROR_RETAINED",
               "OPAQUE_NOT_AUDITABLE"]:
        n = rx_dist.get((a, st), 0)
        if n:
            rows.append({"asset_name": a, "asset_local_primary_status": st, "count": n,
                         "expected_anchor": ""})
with open(os.path.join(OUT, "DEPENDING_REACTION_ASSET_LOCAL_STATUS_DISTRIBUTION.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["asset_name", "asset_local_primary_status", "count", "expected_anchor"])
    w.writeheader()
    w.writerows(rows)

rx_row = {(r["case_id"], r["reaction_id"], r["asset_name"]): r for r in rx}
rx_corp = {(r["case_id"], r["reaction_id"]): r for r in rx if r["asset_name"] == "corpus_v1.jsonl"}
grows = []
for key in sorted(rx_global, key=lambda k: (k[0], int(I(k[1]) or 0))):
    r0 = rx_corp[key]
    st = rx_global[key]
    contrib = rx_global_contrib[key]
    if st == "P6_NO_EXACT_MATCH":
        loc = ""
    elif st == "P5_TEMPLATE_ONLY":
        loc = "; ".join(rx_row[key + (a,)]["template_sample_locators"] for a in contrib.split("+")
                        if rx_row[key + (a,)]["template_sample_locators"])[:300]
    else:
        loc = "; ".join(rx_row[key + (a,)]["first_locator"] for a in contrib.split("+")
                        if rx_row[key + (a,)]["first_locator"])[:300]
    grows.append({
        "case_id": key[0], "reaction_id": key[1], "product_name": r0["product_name"],
        "global_layered_status": st,
        "contributing_assets": rx_global_contrib[key],
        "r1_locator_reference": loc or "NONE",
        "asset_local_statuses_json": json.dumps({a: rx_new[key + (a,)][0] for a in ASSETS}, sort_keys=True),
        "note": ("global layered summary only; NOT the status of any individual asset"
                 if st != "P5_TEMPLATE_ONLY" else
                 "template applicability = generic rule evidence, never concrete answer seen"),
    })
assert len(grows) == 39, len(grows)
with open(os.path.join(OUT, "DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(grows[0].keys()))
    w.writeheader()
    w.writerows(grows)
print("§5/§7 reaction outputs written")

# ---------------------------------------------------------------- §6 product
pr = rd("DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET.csv")
anchor("pr rows", len(pr), 312)
pkeys = [(r["case_id"], r["line_no_products_jsonl"], r["asset_name"]) for r in pr]
anchor("pr key uniqueness", len(set(pkeys)), 312)
anchor("pr distinct gold products", len({(r["case_id"], r["line_no_products_jsonl"]) for r in pr}), 39)

pr_new = {}


def pr_asset_status(r):
    a = r["asset_name"]
    if a in RANKERS:
        return "OPAQUE_NOT_AUDITABLE", "ranker asset fixed OPAQUE; excluded from exact-match denominators"
    if I(r["parse_error"]):
        return "P0_PARSE_ERROR_RETAINED", "parse_error=1 on this row"
    if a == "corpus_v1.jsonl":
        if I(r["product_side_hit"]):
            return "P3_GOLD_PRODUCT_SEEN", "this corpus row product_side_hit=1"
        return "P6_NO_EXACT_MATCH", "this corpus row product_side_hit=0"
    if a == "donor_index.jsonl":
        return "P6_NO_EXACT_MATCH", "donor_index.jsonl has no product side; always P6 on the product matrix"
    hv = I(r["template_product_side_applicability_hit"])
    if hv > 0:
        return "P5_TEMPLATE_ONLY", f"this template asset row template_product_side_applicability_hit={hv}"
    return "P6_NO_EXACT_MATCH", "this template asset row template_product_side_applicability_hit=0"


for r in pr:
    pr_new[(r["case_id"], r["line_no_products_jsonl"], r["asset_name"])] = pr_asset_status(r)

for r in pr:
    a = r["asset_name"]
    st = pr_new[(r["case_id"], r["line_no_products_jsonl"], a)][0]
    if a == "donor_index.jsonl":
        assert st == "P6_NO_EXACT_MATCH"
    if a in TEMPLATES:
        assert st in ("P5_TEMPLATE_ONLY", "P6_NO_EXACT_MATCH")

pr_dist = {}
for (c, ln, a), (st, _) in pr_new.items():
    pr_dist[(a, st)] = pr_dist.get((a, st), 0) + 1

print("== §6 distribution anchors")
anchor("pr corpus P3", pr_dist.get(("corpus_v1.jsonl", "P3_GOLD_PRODUCT_SEEN"), 0), 16)
anchor("pr corpus P6", pr_dist.get(("corpus_v1.jsonl", "P6_NO_EXACT_MATCH"), 0), 23)
anchor("pr donor P6", pr_dist.get(("donor_index.jsonl", "P6_NO_EXACT_MATCH"), 0), 39)
for t in sorted(TEMPLATES):
    anchor(f"pr {t} P5", pr_dist.get((t, "P5_TEMPLATE_ONLY"), 0), 39)
for rk in sorted(RANKERS):
    anchor(f"pr {rk} OPAQUE", pr_dist.get((rk, "OPAQUE_NOT_AUDITABLE"), 0), 39)

pr_global = {}
pr_global_contrib = {}
for key in {(r["case_id"], r["line_no_products_jsonl"]) for r in pr}:
    if pr_new.get(key + ("corpus_v1.jsonl",), ("",))[0] == "P3_GOLD_PRODUCT_SEEN":
        pr_global[key] = "P3_GOLD_PRODUCT_SEEN"
        pr_global_contrib[key] = "corpus_v1.jsonl"
    else:
        p5a = [a for a in sorted(TEMPLATES) if pr_new.get(key + (a,), ("",))[0] == "P5_TEMPLATE_ONLY"]
        if p5a:
            pr_global[key] = "P5_TEMPLATE_ONLY"
            pr_global_contrib[key] = "+".join(p5a)
        else:
            pr_global[key] = "P6_NO_EXACT_MATCH"
            pr_global_contrib[key] = "none"

pr_row = {(r["case_id"], r["line_no_products_jsonl"], r["asset_name"]): r for r in pr}
pr_corp = {(r["case_id"], r["line_no_products_jsonl"]): r for r in pr if r["asset_name"] == "corpus_v1.jsonl"}
with open(os.path.join(OUT, "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(pr[0].keys()) + NEWF)
    w.writeheader()
    for r in pr:
        key = (r["case_id"], r["line_no_products_jsonl"], r["asset_name"])
        st, basis = pr_new[key]
        g = pr_global[(r["case_id"], r["line_no_products_jsonl"])]
        gbasis = (f"global priority corpus P3 -> any template P5 -> P6; contributed by: {pr_global_contrib[(r['case_id'], r['line_no_products_jsonl'])]}"
                  + (" (ranker assets excluded from exact-match denominators)" if r["asset_name"] in RANKERS else ""))
        valid = "TRUE" if st == r["primary_status"] else "FALSE"
        note = "" if valid == "TRUE" else \
            "R1 p8 copied a globally-computed primary_status onto this asset row; corrected here from this row's own asset-local flags only"
        out = dict(r)
        out.update({"asset_local_primary_status": st, "asset_local_status_basis": basis,
                    "global_layered_status": g, "global_status_basis": gbasis,
                    "r1_original_primary_status": r["primary_status"],
                    "r1_original_primary_status_valid_for_asset": valid,
                    "correction_note": note})
        w.writerow(out)

rows = []
for a in ASSETS:
    for st in ["P3_GOLD_PRODUCT_SEEN", "P4_PARENT_SEEN", "P5_TEMPLATE_ONLY",
               "P6_NO_EXACT_MATCH", "P0_PARSE_ERROR_RETAINED", "OPAQUE_NOT_AUDITABLE"]:
        n = pr_dist.get((a, st), 0)
        if n:
            rows.append({"asset_name": a, "asset_local_primary_status": st, "count": n, "expected_anchor": ""})
with open(os.path.join(OUT, "DEPENDING_PRODUCT_ASSET_LOCAL_STATUS_DISTRIBUTION.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["asset_name", "asset_local_primary_status", "count", "expected_anchor"])
    w.writeheader()
    w.writerows(rows)

grows = []
for key in sorted(pr_global, key=lambda k: (k[0], int(k[1]))):
    r0 = pr_corp[key]
    st = pr_global[key]
    contrib = pr_global_contrib[key]
    if st == "P3_GOLD_PRODUCT_SEEN":
        loc = pr_row[key + ("corpus_v1.jsonl",)]["first_locator"]
    elif st == "P5_TEMPLATE_ONLY":
        loc = "; ".join(pr_row[key + (a,)]["template_sample_locators"] for a in contrib.split("+")
                        if pr_row[key + (a,)]["template_sample_locators"])[:300]
    else:
        loc = ""
    grows.append({
        "case_id": key[0], "line_no_products_jsonl": key[1], "product_name": r0["product_name"],
        "product_inchikey": r0["product_inchikey"],
        "global_layered_status": st,
        "contributing_assets": pr_global_contrib[key],
        "r1_locator_reference": loc or "NONE",
        "asset_local_statuses_json": json.dumps({a: pr_new[key + (a,)][0] for a in ASSETS}, sort_keys=True),
        "note": ("global layered summary only; NOT the status of any individual asset"
                 if st != "P5_TEMPLATE_ONLY" else
                 "template applicability = generic rule evidence, never concrete answer seen"),
    })
assert len(grows) == 39, len(grows)
with open(os.path.join(OUT, "DEPENDING_39_GOLD_PRODUCT_GLOBAL_LAYERED_STATUS.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(grows[0].keys()))
    w.writeheader()
    w.writerows(grows)
print("§6/§7 product outputs written")

# ---------------------------------------------------------------- §9 recompute split fields
pa = rd("DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv")
cases = sorted({r["case_id"] for r in pa})
anchor("parent matrix cases", len(cases), 18)
anchor("parent matrix rows", len(pa), 144)
no_locator_cases = []
for c in cases:
    rows_c = [r for r in pa if r["case_id"] == c]
    hit = any(I(r["reactant_side_canonical_hit"]) == 1 for r in rows_c
              if r["asset_name"] in ("corpus_v1.jsonl", "donor_index.jsonl"))
    tmpl = any(I(r["template_matched_template_count"]) > 0 for r in rows_c if r["asset_name"] in TEMPLATES)
    if not (hit or tmpl):
        no_locator_cases.append(c)
anchor("cases_without_any_auditable_parent_or_template_locator", len(no_locator_cases), 0)
corpus_parent = sum(1 for r in pa if r["asset_name"] == "corpus_v1.jsonl" and I(r["reactant_side_canonical_hit"]) == 1)
anchor("auditable corpus parent exposure", f"{corpus_parent}/18", "15/18")

prov = rd("DEPENDING_T4_HIT_PROVENANCE_AND_EXPOSURE.csv")
pair_connected = sum(1 for r in prov if r["exposure_evidence_class"].strip() == "CORPUS_EXACT_PAIR_SEEN_IN_AUDITABLE_ASSET")
hit_cases = sum(1 for r in prov if r["first_hit_found"].strip().lower() in ("true", "1", "yes"))
anchor("provenance rows", len(prov), 18)
anchor("provenance first-hit cases", hit_cases, 15)
anchor("first top10 hits with pair locator", pair_connected, 7)

summary = {
    "cases_without_any_auditable_parent_or_template_locator": no_locator_cases,
    "cases_with_opaque_ranker_training_identity": f"{len(cases)}/18",
    "ranker_training_overlap": "UNKNOWN_FOR_ALL_18",
    "runtime_external_envipath_dependency": False,
    "auditable_corpus_parent_exposure": f"{corpus_parent}/18",
    "auditable_corpus_answer_pair_exposure": f"{rx_dist.get(('corpus_v1.jsonl','P2_EXACT_PARENT_PRODUCT_PAIR_SEEN'),0)}/39",
    "auditable_corpus_product_exposure": f"{pr_dist.get(('corpus_v1.jsonl','P3_GOLD_PRODUCT_SEEN'),0)}/39",
    "first_top10_hit_connected_to_pair_locator": f"{pair_connected}/15",
    "separation_declaration": (
        "'no auditable locator' (0 cases) and 'opaque ranker training identity unknown' (18/18) are "
        "distinct statements; the R1 field q6_unknown_due_to_opaque_ranker_or_external_envipath with "
        "cases=[] conflated them and is superseded by this file."),
}
with open(os.path.join(OUT, "_r2_recompute_facts.json"), "w") as f:
    json.dump(summary, f, indent=2)
print("§9 recompute facts written")

if FAIL:
    print("\nANCHOR FAILURES:")
    for x in FAIL:
        print(" -", x)
    sys.exit(1)
print("\nALL ANCHORS PASS")
