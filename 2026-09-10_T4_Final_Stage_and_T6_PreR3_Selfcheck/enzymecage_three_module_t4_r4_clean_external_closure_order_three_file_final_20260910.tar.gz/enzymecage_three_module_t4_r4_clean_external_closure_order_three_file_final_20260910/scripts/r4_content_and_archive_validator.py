#!/usr/bin/env python3
"""T4-R4 validator: content gates C01-C20 (plus one supplementary gate SUP21), pre-write external
gates P01-P09, post-write gates Q01-Q08 and the final independent read-only check.

  --stage content        C01-C20 + SUP21 against --root (the live RETURN_DIR or a fresh unpack of the
                         archive)
  --stage pwrite         C01-C20 + SUP21 against the fresh unpack U1, then P01-P09.  P07 REQUIRES that
                         no validation sidecar (nor any same-basename .tmp/.partial/.failed/.bak)
                         exists; this stage never opens a validation file and has no
                         require-validation-record flag at all, because the record cannot exist yet
  --stage postwrite      C01-C20 + SUP21 against the second fresh unpack U2, then Q01-Q08, the gates
                         that DO require archive + identity + validation
  --stage final-readonly reopen the finished record and the three physical files, verify structure and
                         all-PASS, print one JSON line, exit 0/1; it never opens any path for writing
                         inside the return directory and never modifies a tree, so the exit code of
                         this third process cannot be fed back into the record it checks
  --stage scan-source    regex + AST always-true scan of one python file (one JSON line, no writes)

Nothing here restates a packaged claim: every gate recomputes from live bytes, hashes or AST.
PYTHONDONTWRITEBYTECODE=1 / python3 -B; no model, no inference, no rescoring, no overlap recompute,
no network, no GPU."""
import argparse
import ast
import calendar
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import tarfile
import tempfile
import time

T = "enzymecage_three_module_t4_r4_clean_external_closure_order_three_file_final_20260910"
T3 = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R4 = f"{RR}/{T}"
AP = f"{ROOT}/HPC_Inputs/t4_r4_teacher_authority_and_r3_local_audit_payload_20260910.tar.gz"
A = f"{W}/immutable_authority/t4_r4_teacher_authority_and_r3_local_audit_payload_20260910"
R3ARC = f"{RR}/{T3}.tar.gz"
BASE3 = f"{W}/immutable_r3/{T3}"
R4_START_ISO = "2026-09-10T05:46:28Z"     # WORK_ROOT creation right after the section 2 probe
R4_START_EPOCH = calendar.timegm(time.strptime(R4_START_ISO, "%Y-%m-%dT%H:%M:%SZ"))
PAYLOAD_ID = ("b82543960b6504bd7caf752ddd10e1da33e33d3b1dcbc7c167ba1bc70dc10769", 9900)
R3ARC_ID = ("e21127343f31c8e678e271ca8e7241a7a515c11d0ea9043c57b2535008d6611f", 228792)
MEMBER_SHA = {
    "TEACHER_REPLY_T4_INPUT_IDENTITY_AND_ORCHESTRATION_BOUNDARY_2026-09-08.md":
        ("ca270af0419d7954ff8ddcb1b4304a04428ad893eeedfee604402f11004fdd34", 3627),
    "TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md":
        ("953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4", 5995),
    "ENZYMECAGE_THREE_MODULE_T4_R3_TINY_REPORT_VALIDATOR_SIDECAR_CLOSURE_RETURN_"
    "LOCAL_AUDIT_2026-09-10.md":
        ("1fbf4c5926041d795183638e9b919a703fdae2545b97cee45f2a1c6151a53126", 9097),
}
BM = "T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv"
DRAFT = ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
         "DECISION_REQUEST_CORRECTED_DRAFT.md")
# prompt section 1: identities that R4 must carry through untouched
FROZEN = {
    BM: ("e4eb988ffb274f1e1eb31c7c1a44fc2c0b6da3fd0e7a50adc3cc2d3bbd47aad2", 9571),
    DRAFT: ("9465ee87d126764746b7b8fde87b1874b03feeecd8c4b34941ad3148ba1ca964", 6506),
    "scripts/p6_validator.py":
        ("e5fffaa25d114fd4a673f39d5a9bfce574e7267d50b9fa87f1124d9adf975fcb", 37680),
    "V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json":
        ("a94f7adaa7d011cdb35172e84aeb02ea58dccb31e1e01401f9442a7fc8013cff", 9848),
    "R2_CONTENT_NONMUTATION.json":
        ("48ae85c14860242e9eb9d9477f31ea2cd90778916cff1ca504abd72039dff891", 5108),
    "DEPENDING_NORMALIZED_PREDICTIONS_CORRECTED.jsonl":
        ("6e52ada071c0b12d36aa8490bbdcc0b9928461861432ba1be5365764d30209e4", None),
    "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv":
        ("aa9e8eedc788efeb0a8ec285a2e83db1516cb16c60a092ab080d81a63a13aeda", None),
    "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv":
        ("ac96263dadc78a0b32ca69cb85b5815e3ff5ca83d86dbd4879825d7c4dd443ba", None),
    "FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv":
        ("75a50d517d25ef96aae8b35b67b8fb163788ba1b22fc8e93288bda002a138a15", None),
    "ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv":
        ("f902c953ebe582bba941b4b88435475fd903291743dca39616edd5e58e8cf989", None),
    "ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv":
        ("b2a0e756f80030607977a02aea03ffb7d9dc8c99cfae2903a9852f52da977669", None),
}
BASE_CSV = "R3_BASELINE_FILE_IDENTITIES.csv"
CHG_CSV = "R3_TO_R4_CHANGED_FILES.csv"
NONMUT_JSON = "R3_CONTENT_NONMUTATION.json"
V23_JSON = "V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json"
R4_V23_JSON = "R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json"
HIST = "inherited_r3_closure_historical"
# prompt section 4: the only R3 files R4 may rewrite, plus the two relocated closure scripts
REWRITE = {"README.md", "AUTHORITY_AND_SCOPE.md", "COMMAND_LOG.txt", "FINAL_STATUS.txt",
           "MANIFEST.files", "MANIFEST.sha256"}
MOVE = {"scripts/r3_closure.py": f"{HIST}/r3_closure.py",
        "scripts/r3_validator.py": f"{HIST}/r3_validator.py"}
# prompt section 10: the in-archive status must stay honest about the not-yet-existing sidecars
FS_PENDING = ["T4_R4_CONTENT_READY_FOR_EXTERNAL_VALIDATION",
              "CONTENT_PRESERVED_FROM_T4_R3=true", "MODEL_RERUN=false",
              "RAW_PREDICTIONS_CHANGED=false", "METRICS_CHANGED=false",
              "STRICT_UNSEEN_BLIND_EVALUATION=NOT_ESTABLISHED",
              "CURRENT_METRICS=VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY",
              "MODEL_ROLE_DECISION=AWAITING_HUANG_TEACHER_REVIEW",
              "TEACHER_DECISION_REQUEST_SENT=false",
              "T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true",
              "EXTERNAL_THREE_FILE_DELIVERY=PENDING_AT_ARCHIVE_TIME"]
READY = "T4_R4_CLEAN_EXTERNAL_CLOSURE_READY_FOR_LOCAL_AUDIT"
NEW_SENT = ("在您裁定前，本草稿不发送、不上传；本T4任务不进入T6、也不改变T6模型角色；"
            "T6按独立老师合同继续推进，不以本T4 A/B裁定为前置门；无任何git push。")
OLD_SENT = "在您裁定前，本草稿不发送、不上传；T6 不进入；无任何 git push。"
README_TITLE = "# T4-R4 clean external closure order and three-file final delivery"
ALLOWED_IMPORTS = {"argparse", "ast", "calendar", "copy", "csv", "datetime", "gzip", "hashlib",
                   "json", "os", "re", "secrets", "shutil", "subprocess", "sys", "tarfile",
                   "tempfile", "time"}
ALLOWED_CMD = {"python3", "tar", "sha256sum", "chmod", "cp", "mkdir", "stat", "cat", "date"}
FORBIDDEN_TOKENS = ("pip install", "conda", "git push", "git clone", "curl", "wget", "nvidia-smi",
                    "import torch", "torchrun", "http://", "https://", "ssh ", "scp ", "nvcc")
V23CALL = "ok = len(sub) >= 24 and all(v is True for v in sub.values())"
# prompt section 7 lists C01-C20 verbatim, 8.3 lists P01-P09 and 8.4 lists Q01-Q08.  Section 8.4
# also asks that the record contain those gate series and nothing else, so the two checks that go
# BEYOND the required minimum (input freeze + out-of-scope-write sweep) are executed as SUP21 and
# are deliberately NOT written into the validation record, where only C01-C20 and P01-P09 may appear.
CGATES = ["C%02d" % i for i in range(1, 21)]
PGATES = ["P%02d" % i for i in range(1, 10)]
QGATES = ["Q%02d" % i for i in range(1, 9)]
SUPGATES = ["SUP21"]
TAUTO_RX = [
    ("always_true_disjunction", re.compile(r"\bor\s+True\b")),
    ("always_true_conjunction", re.compile(r"\band\s+True\b")),
    ("always_true_if", re.compile(r"\bif\s+True\b")),
    ("empty_all_call", re.compile(r"\ball\(\s*\)")),
    ("empty_any_call", re.compile(r"\bany\(\s*\)")),
    ("trivial_len_ge_zero", re.compile(r"\blen\([^()]*\)\s*>=\s*0\b")),
    ("trivial_not_in_empty", re.compile(r"\bnot\s+in\s+\(\s*\)")),
]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(p):
    with open(p, encoding="utf-8", errors="ignore") as f:
        return f.read()


def rows(p):
    with open(p, encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f)]


def I(v):
    try:
        return int(str(v).strip())
    except ValueError:
        return 0


def utc(ep):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ep))


def E(s):
    """parse a %Y-%m-%dT%H:%M:%SZ stamp into epoch seconds (0 when absent)."""
    try:
        return calendar.timegm(time.strptime(s, "%Y-%m-%dT%H:%M:%SZ"))
    except (TypeError, ValueError):
        return 0


def tar_list(arc):
    out = []
    with tarfile.open(arc, "r:gz") as tf:
        for m in tf.getmembers():
            kind = ("dir" if m.isdir() else "symlink" if m.issym() else "hardlink" if m.islnk()
                    else "regular" if m.isfile() else "special")
            out.append((m.name.rstrip("/"), kind, m.size))
    return out


def unsafe_members(mem):
    return [n for n, k, s in mem if k not in ("regular", "dir")
            or n.startswith("/") or ".." in n.split("/") or n.startswith("./")]


def walk_reg(R):
    return sorted({os.path.relpath(os.path.join(r_, f), R)
                   for r_, _, fs in os.walk(R) for f in fs})


def manifest_shas(R):
    d = {}
    for line in rd(f"{R}/MANIFEST.sha256").splitlines():
        if line.strip() and "  " in line:
            s, rel = line.rstrip("\n").split("  ", 1)
            d[rel] = s
    return d


def check_manifests(R):
    mf = set(rd(f"{R}/MANIFEST.files").split())
    actual = set(walk_reg(R))
    ok_files = mf == actual and {"MANIFEST.files", "MANIFEST.sha256"} <= mf
    man = manifest_shas(R)
    ok_sha = ("MANIFEST.sha256" not in man and set(man) == (mf - {"MANIFEST.sha256"})
              and all(os.path.isfile(os.path.join(R, r)) and sha(os.path.join(R, r)) == h
                      for r, h in man.items()))
    return ok_files, ok_sha, (len(mf), len(actual), len(man))


def tautology_scan(path):
    """C06/C17 static detection of always-true constructs in one python source."""
    src = rd(path)
    find = [[rule, i + 1, ln.strip()[:70]] for i, ln in enumerate(src.split("\n"))
            for rule, rx in TAUTO_RX if rx.search(ln)]
    for n in ast.walk(ast.parse(src)):
        if isinstance(n, ast.BoolOp) and any(isinstance(v, ast.Constant) and v.value is True
                                             for v in n.values):
            find.append(["ast_boolop_true_constant", n.lineno, "BoolOp operand is the True literal"])
        elif (isinstance(n, (ast.If, ast.While)) and isinstance(n.test, ast.Constant)
                and n.test.value is True):
            find.append(["ast_always_true_branch", n.lineno, "branch test is the True literal"])
        elif (isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
              and n.func.id in ("all", "any") and len(n.args) == 1
              and isinstance(n.args[0], (ast.List, ast.Tuple, ast.Set, ast.Dict))
              and not n.args[0].elts):
            find.append(["ast_empty_" + n.func.id, n.lineno, f"{n.func.id}() over an empty literal"])
        elif (isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
              and n.func.id == "rec" and n.args and isinstance(n.args[1], ast.Constant)
              and n.args[1].value is True):
            find.append(["ast_hardcoded_pass_gate", n.lineno, "a gate is recorded with the True literal"])
    return find


def baseline_rows(R):
    """R3_BASELINE_FILE_IDENTITIES.csv as {rel: (bytes, sha256)}."""
    return {r["relative_path"]: (I(r["bytes"]), r["sha256"]) for r in rows(f"{R}/{BASE_CSV}")}


def r4_path_of(R, rel):
    """where an R3 file now lives inside the R4 tree (the two closure scripts were relocated)."""
    return os.path.join(R, MOVE[rel]) if rel in MOVE else os.path.join(R, rel)


G = []


def rec(gid, ok, measured, expected, ev, loc):
    G.append({"gate": gid, "status": "PASS" if ok else "FAIL", "measured": str(measured),
              "expected": str(expected), "evidence": ev, "locator": loc})
    print(f"{gid}: {'PASS' if ok else 'FAIL'} | measured={measured} | expected={expected} "
          f"| evidence={ev} | {loc}")
    return bool(ok)


def glines(lines, prefixes):
    return [l for l in lines if any(l.startswith(g + ":") for g in prefixes)]


GATE_SHAPE = re.compile(r"^([A-Z]{1,3}\d{1,2}):\s+(\S+)")


def gate_shaped(lines):
    """(gate_id, status) of every line that looks like a gate row, so that a record cannot smuggle
    in an extra FAIL row or a gate id that was never executed."""
    return [(m.group(1), m.group(2)) for m in (GATE_SHAPE.match(l) for l in lines) if m]


# ------------------------------------------------------------------ content gates C01-C20 + SUP21
def gates_content(R):
    ok_all = True

    # C01 authority archive identity and its three members
    mem = tar_list(AP)
    names = sorted(os.path.basename(n) for n, k, s in mem if k == "regular")
    inner = {n: (os.path.getsize(os.path.join(A, n)), sha(os.path.join(A, n))) for n in names}
    v1 = (not os.path.islink(AP) and os.path.getsize(AP) == PAYLOAD_ID[1]
          and sha(AP) == PAYLOAD_ID[0] and len(mem) == 3 and not unsafe_members(mem)
          and names == sorted(MEMBER_SHA)
          and all(inner[n] == (sz, h) for n, (h, sz) in MEMBER_SHA.items()))
    ok_all &= rec("C01", v1,
                  f"bytes={os.path.getsize(AP)} sha={sha(AP)[:16]}... members={len(names)}",
                  "bytes=9900 sha=b82543960b6504bd... 3 safe regular members with exact bytes+SHA",
                  AP, "prompt section 1; live stat + sha256 of the payload and its extracted copy")

    # C02 R3 archive identity, safety, 64/64 files and 63/63 hashes
    r3mem = tar_list(R3ARC)
    r3reg = [n for n, k, s in r3mem if k == "regular"]
    ok_f3, ok_s3, n3 = check_manifests(BASE3)
    v2 = (os.path.getsize(R3ARC) == R3ARC_ID[1] and sha(R3ARC) == R3ARC_ID[0]
          and not os.path.islink(R3ARC) and not unsafe_members(r3mem)
          and sorted({n.split("/")[0] for n in r3reg}) == [T3] and len(r3reg) == 64
          and ok_f3 and ok_s3)
    ok_all &= rec("C02", v2,
                  f"bytes={os.path.getsize(R3ARC)} sha={sha(R3ARC)[:16]}... regular={len(r3reg)} "
                  f"files_manifest={n3[0]} sha_manifest={n3[2]}",
                  "bytes=228792 sha=e21127343f31c8e6... single root, 0 unsafe members, 64/64, 63/63",
                  f"{R3ARC}; read-only extraction under {BASE3}", "prompt sections 1-2")

    # C03 copy identity of every one of the 64 R3 files
    base = baseline_rows(R)
    miss = [r for r in sorted(base) if not os.path.isfile(r4_path_of(R, r))]
    # the source side: all 64 baseline hashes must be true in the read-only extraction of R3, which
    # is where the copy came from.  The tree side is only asserted for the 58 files R4 may not
    # rewrite; the six whitelisted reports are C04's job, since their bytes are meant to differ.
    badsrc = [r for r in sorted(base) if not os.path.isfile(os.path.join(BASE3, r))
              or sha(os.path.join(BASE3, r)) != base[r][1]]
    keep3 = [r for r in sorted(base) if r not in REWRITE]
    bad3 = [r for r in keep3 if r not in miss
            and (sha(r4_path_of(R, r)) != base[r][1]
                 or os.path.getsize(r4_path_of(R, r)) != base[r][0])]
    moved = sorted(r for r in base if r in MOVE and os.path.isfile(r4_path_of(R, r))
                   and not os.path.exists(os.path.join(R, r)))
    v3 = len(base) == 64 and not miss and not bad3 and not badsrc and moved == sorted(MOVE)
    ok_all &= rec("C03", v3, f"csv_rows={len(base)} missing={miss[:3]} hash_deviations={bad3[:3]} "
                             f"source_side_deviations_in_R3_extraction={badsrc[:3]} "
                             f"relocated={moved}",
                  "64 rows; each recorded bytes+SHA found at its R4 path (the two superseded closure "
                  f"scripts relocated under inherited_r3_closure_historical/)", f"{BASE_CSV}; {R}; {BASE3}",
                  "live sha256 of every copied file vs the baseline hash and the extracted R3 tree")

    # C04 nothing outside the whitelist changed, and the change table plus the nonmutation report
    # describe exactly the tree under test.  Every claim here is time-consistent on purpose: the
    # baseline hashes, the two reports inside the tree and the live walk are the only inputs, so a
    # later rewrite of one of the six whitelisted files cannot invalidate an earlier report.
    present = walk_reg(R)
    added = sorted(p for p in present if p not in base and p not in set(MOVE.values()))
    rewritten = sorted(p for p in present if p in base and sha(os.path.join(R, p)) != base[p][1])

    def identical(rel):
        p = r4_path_of(R, rel)
        return (os.path.isfile(p) and os.path.getsize(p) == base[rel][0]
                and sha(p) == base[rel][1])

    protected = sorted(p for p in base if p not in REWRITE)          # 58 files, moves included
    outside = [p for p in protected if not identical(p)]
    still_there = [p for p in MOVE if os.path.exists(os.path.join(R, p))]
    tbl = rows(f"{R}/{CHG_CSV}") if os.path.isfile(f"{R}/{CHG_CSV}") else []
    declared = {r["r4_path"]: r for r in tbl}
    mv = {new: (old, base[old][1]) for old, new in MOVE.items()}
    v4a = not outside and not still_there
    v4b = (set(declared) == set(added) | set(REWRITE) | set(MOVE.values())
           and all(declared[p]["change_kind"] == "added_by_r4" for p in added)
           and all(declared[p]["change_kind"] == "rewritten_r4_report" for p in REWRITE
                   if p in declared)
           and all(declared[new]["change_kind"] == "relocated_same_sha"
                   and declared[new]["r3_path"] == old
                   and declared[new]["r3_sha256"] == h == declared[new]["r4_sha256"]
                   and identical(old)
                   for new, (old, h) in mv.items()))
    nm = json.loads(rd(f"{R}/{NONMUT_JSON}")) if os.path.isfile(f"{R}/{NONMUT_JSON}") else {}
    s2 = nm.get("summary", {})
    v4c = (not s2.get("failing_checks") and s2.get("changed_outside_whitelist") == []
           and s2.get("baseline_regular_files") == len(base) == 64
           and s2.get("non_whitelist_files_verified") == len(protected)
           and s2.get("whitelist_rewritable") == sorted(REWRITE)
           and sorted(s2.get("added_by_r4", [])) == added
           and sorted(s2.get("relocated_pairs", [])) == sorted([f"{o} -> {n}"
                                                                for o, n in MOVE.items()]))
    v4 = v4a and v4b and v4c
    ok_all &= rec("C04", v4, f"{len(protected) - len(outside)}/{len(protected)} non-whitelist R3 files "
                             f"byte-identical at their R4 path; deviations={outside[:3]}; "
                             f"old_move_paths_still_present={still_there}; whitelisted rewrites="
                             f"{rewritten}; additions={len(added)}; table_rows={len(tbl)}; "
                             f"json_agrees={v4c}",
                  "zero changes outside README/AUTHORITY/COMMAND_LOG/FINAL_STATUS/two manifests; every "
                  f"addition, rewrite and relocation declared in {CHG_CSV} with matching SHAs, and "
                  f"{NONMUT_JSON} describing exactly this tree", f"{CHG_CSV}; {NONMUT_JSON}",
                  "walk of the tree against the 64 baseline hashes + both reports in the same tree")

    # C05 the two corrected teacher-facing materials keep their exact identities
    f5 = {k: (sha(os.path.join(R, k)) == FROZEN[k][0], os.path.getsize(os.path.join(R, k)) == FROZEN[k][1])
          for k in (BM, DRAFT)}
    v5 = all(all(x) for x in f5.values())
    ok_all &= rec("C05", v5, "; ".join(f"{k.split('_')[0]}_sha={f5[k][0]} "
                                       f"bytes={os.path.getsize(os.path.join(R, k))}" for k in (BM, DRAFT)),
                  "boundary matrix e4eb988f.../9571 and teacher draft 9465ee87.../6506",
                  f"{BM}; {DRAFT}", "live sha256 + stat of both preserved corrected materials")

    # C06 p6_validator untouched, and no packaged python file carries an always-true bypass.  The
    # scan covers EVERY .py in the tree, this checker included, so it cannot hide a hole in itself;
    # the two literal patterns below are therefore built by concatenation on purpose.
    pv = os.path.join(R, "scripts", "p6_validator.py")
    src = rd(pv)
    find6 = tautology_scan(pv)
    tree_scan = {rel: tautology_scan(os.path.join(R, rel)) for rel in walk_reg(R)
                 if rel.endswith(".py")}
    dirty6 = sorted(k for k, v in tree_scan.items() if v)
    v6 = (sha(pv) == FROZEN["scripts/p6_validator.py"][0]
          and os.path.getsize(pv) == FROZEN["scripts/p6_validator.py"][1]
          and V23CALL in src and not find6 and not dirty6
          and src.count("or" + " True") == 0 and src.count("if" + " True") == 0)
    ok_all &= rec("C06", v6, f"sha={sha(pv)[:16]}... bytes={os.path.getsize(pv)} "
                             f"p6_findings={len(find6)} conjunction_line_intact={V23CALL in src} "
                             f"py_files_scanned={len(tree_scan)} files_with_findings={dirty6[:3]}",
                  "scripts/p6_validator.py == e5fffaa2.../37680 carrying the 25-subcheck conjunction, "
                  "and zero always-true constructs in every packaged python file", pv,
                  "live sha256 + regex/AST scan of each .py in the tree + exact conjunction text")

    # C07 clean V23 run over the copied tree
    p7 = subprocess.run([sys.executable, "-B", pv, "--root", R, "--v23-only"],
                        capture_output=True, text=True)
    try:
        j7 = json.loads([l for l in p7.stdout.splitlines() if l.startswith("{")][-1])
    except IndexError:
        j7 = {}
    v7 = (p7.returncode == 0 and j7.get("verdict") == "PASS" and j7.get("subcheck_count") == 25
          and j7.get("failed_subchecks") == [])
    ok_all &= rec("C07", v7, f"exit={p7.returncode} verdict={j7.get('verdict')} "
                             f"subcheck_count={j7.get('subcheck_count')} "
                             f"failed={j7.get('failed_subchecks')}",
                  "verdict=PASS subcheck_count=25 failed_subchecks=[]", pv,
                  "--v23-only stdout is one JSON line; no file written")

    # C08 the eight V23 mutations still bite, using this tree's own harness
    tmp = tempfile.mkdtemp(prefix="t4r4_c08_", dir="/tmp")
    p8 = subprocess.run([sys.executable, "-B", f"{R}/scripts/r4_v23_recheck.py", "--root", R,
                         "--json", f"{tmp}/recheck.json"], capture_output=True, text=True)
    try:
        j8 = json.loads([l for l in p8.stdout.splitlines()
                         if l.startswith("{") and '"harness"' in l][-1])
    except IndexError:
        j8 = {}
    pack = json.loads(rd(f"{R}/{R4_V23_JSON}")) if os.path.isfile(f"{R}/{R4_V23_JSON}") else {}
    ps = pack.get("summary", {})
    v8 = (j8.get("detected") == 8 and j8.get("total") == 8 and j8.get("clean_pass") is True
          and j8.get("scan_pass") is True and p8.returncode == 0
          and ps.get("all_mutations_detected") is True and ps.get("total") == 8
          and pack.get("validator_source_sha256") == sha(pv)
          and sha(f"{R}/{V23_JSON}") == FROZEN[V23_JSON][0])
    ok_all &= rec("C08", v8, f"live harness detected={j8.get('detected')}/{j8.get('total')} "
                             f"clean={j8.get('clean_pass')} scan={j8.get('scan_pass')} "
                             f"exit={p8.returncode}; packaged evidence agrees="
                             f"{ps.get('all_mutations_detected')}; R3 V23 JSON sha frozen="
                             f"{sha(f'{R}/{V23_JSON}') == FROZEN[V23_JSON][0]}",
                  "8/8 detected, clean V23 PASS, clean source scan PASS, harness exit 0",
                  f"{R4_V23_JSON}; scripts/r4_v23_recheck.py",
                  "subprocess run of the shipped harness against this tree")

    # C09 frozen scientific content identities
    bad9 = [k for k, (h, sz) in FROZEN.items()
            if sha(os.path.join(R, k)) != h or (sz and os.path.getsize(os.path.join(R, k)) != sz)]
    inh9 = [f for f in ("ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv",
                        "ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv")
            if sha(f"{R}/inherited_r1/{f}") != FROZEN[f][0]]
    ok_all &= rec("C09", not bad9 and not inh9,
                  f"{len(FROZEN)} named files + 2 inherited_r1 copies, deviations={bad9 + inh9}",
                  "predictions, both 312-row matrices, metrics and both ECLIPSE tables hit the section 1 SHAs",
                  ", ".join(sorted(FROZEN)), "live sha256 of each frozen object")

    # C10 rows and unique keys of the two 312-row matrices
    rx = rows(f"{R}/DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv")
    pr = rows(f"{R}/DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv")
    m10 = {"reaction_rows": len(rx),
           "reaction_unique_keys": len({(r["case_id"], r["reaction_id"], r["asset_name"]) for r in rx}),
           "product_rows": len(pr),
           "product_unique_keys": len({(r["case_id"], r["line_no_products_jsonl"], r["asset_name"])
                                       for r in pr}),
           "reaction_global_rows": len(rows(f"{R}/DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv")),
           "product_global_rows": len(rows(f"{R}/DEPENDING_39_GOLD_PRODUCT_GLOBAL_LAYERED_STATUS.csv"))}
    v10 = (m10["reaction_rows"] == m10["reaction_unique_keys"] == m10["product_rows"]
           == m10["product_unique_keys"] == 312
           and m10["reaction_global_rows"] == m10["product_global_rows"] == 39)
    ok_all &= rec("C10", v10, json.dumps(m10, sort_keys=True),
                  "312/312 reaction and product rows/unique keys, 39/39 global rows",
                  "two BY_ASSET matrices; two GLOBAL tables", "csv.DictReader recount of the copied bytes")

    # C11 corpus anchors
    corp_r = [r for r in rx if r["asset_name"] == "corpus_v1.jsonl"]
    corp_p = [r for r in rows(f"{R}/inherited_r1/DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv")
              if r["asset_name"] == "corpus_v1.jsonl"]
    corp_pr = [r for r in pr if r["asset_name"] == "corpus_v1.jsonl"]
    m11 = {"pair": f"{sum(1 for r in corp_r if I(r['exact_parent_product_pair_hit']))}/{len(corp_r)}",
           "parent": f"{sum(1 for r in corp_p if I(r['reactant_side_canonical_hit']))}/{len(corp_p)}",
           "product": f"{sum(1 for r in corp_pr if I(r['product_side_hit']))}/{len(corp_pr)}"}
    ok_all &= rec("C11", m11 == {"pair": "13/39", "parent": "15/18", "product": "16/39"},
                  json.dumps(m11, sort_keys=True), "13/39 pair, 15/18 parent, 16/39 product",
                  "corpus_v1.jsonl rows of the three overlap tables", "recount over the preserved cells")

    # C12 ECLIPSE structure
    er = rows(f"{R}/inherited_r1/ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv")
    ep = rows(f"{R}/inherited_r1/ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv")
    eh = rows(f"{R}/inherited_r1/ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv")
    cs, ps2 = {}, {}
    for r in er:
        cs[r["exact_status"]] = cs.get(r["exact_status"], 0) + 1
    for r in ep:
        ps2[r["parent_split_exposure"]] = ps2.get(r["parent_split_exposure"], 0) + 1
    hits = sum(I(r["fold_gold_product_hit"]) for r in eh)
    m12 = {"reaction_fold_rows": len(er),
           "reaction_dist": "/".join(str(cs.get(k, 0)) for k in ("TRAIN", "VAL", "TEST", "NONE")),
           "parent_fold_rows": len(ep),
           "parent_dist": "/".join(str(ps2.get(k, 0)) for k in ("TRAIN", "VAL", "TEST")),
           "hit_cells": hits}
    v12 = (m12["reaction_fold_rows"] == 390 and m12["reaction_dist"] == "190/35/25/140"
           and m12["parent_fold_rows"] == 180 and m12["parent_dist"] == "142/21/17" and hits == 113)
    ok_all &= rec("C12", v12, json.dumps(m12, sort_keys=True),
                  "390 rows 190/35/25/140; 180 rows 142/21/17; 113 hit cells",
                  "inherited_r1/ECLIPSE_*.csv", "value recount over the frozen bytes")

    # C13 the teacher draft is still a neutral two-option request that was not sent
    dft = rd(f"{R}/{DRAFT}")
    opts = [l for l in dft.split("\n") if l.startswith("- **选项")]
    v13 = (len(opts) == 2 and re.match(r"^- \*\*选项 ?A\*\*", opts[0])
           and re.match(r"^- \*\*选项 ?B\*\*", opts[1])
           and "不推荐" in dft and "AWAITING_HUANG_TEACHER_REVIEW" in dft
           and "未发送 / 未上传" in dft and "不发送、不上传" in dft)
    ok_all &= rec("C13", v13, f"option_lines={len(opts)} heads={[o[:14] for o in opts]} "
                              f"neutral={('不推荐' in dft)} awaiting={('AWAITING_HUANG_TEACHER_REVIEW' in dft)} "
                              f"not_sent={('未发送 / 未上传' in dft)}",
                  "exactly the two neutral A/B options, no recommendation, AWAITING state, not sent",
                  DRAFT, "line-level scan of the preserved draft")

    # C14 the T4-does-not-gate-T6 wording survived
    lines = dft.rstrip("\n").split("\n")
    fs14 = rd(f"{R}/FINAL_STATUS.txt").splitlines()
    v14 = (dft.count(NEW_SENT) == 1 and lines[-1] == NEW_SENT and len(lines) == 93
           and OLD_SENT not in dft and "T6 不进入" not in dft
           and "T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true" in fs14)
    ok_all &= rec("C14", v14, f"draft_lines={len(lines)} new_sentence={dft.count(NEW_SENT)} "
                              f"old_sentence_present={OLD_SENT in dft} final_status_flag="
                              f"{'T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true' in fs14}",
                  "the corrected independence sentence is the last line and the only T6-bearing line; "
                  "FINAL_STATUS keeps T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true",
                  f"{DRAFT} line 93; FINAL_STATUS.txt", "exact string compare plus line index")

    # C15 the three no-rerun flags
    flags = [l for l in fs14 if l.split("=")[0] in ("MODEL_RERUN", "RAW_PREDICTIONS_CHANGED", "METRICS_CHANGED")]
    ok_all &= rec("C15", flags == ["MODEL_RERUN=false", "RAW_PREDICTIONS_CHANGED=false",
                                   "METRICS_CHANGED=false"],
                  flags, "the three flags present as exactly those false assignments",
                  "FINAL_STATUS.txt", "exact line compare")

    # C16 README carries the current T4-R4 identity
    rdm = rd(f"{R}/README.md").split("\n")
    head = "\n".join(rdm[:14])
    stage = [l for l in rdm[:14] if l.startswith("CURRENT_PACKAGE_STAGE")]
    v16 = (rdm[0] == README_TITLE and f"TASK_ID={T}" in head and stage == ["CURRENT_PACKAGE_STAGE=T4-R4"]
           and "R2/R3内容是继承背景" in head)
    ok_all &= rec("C16", v16, f"line1={rdm[0][:64]!r} stage_lines={stage}",
                  "title is the T4-R4 heading, TASK_ID is the R4 task, CURRENT_PACKAGE_STAGE=T4-R4 and "
                  "R2/R3 are declared inherited background", "README.md lines 1-14",
                  "exact first-line and header-field compare")

    # C17 no model / GPU / network / scoring / recompute command and no non-stdlib import
    imps = {}
    for p in [p for p in walk_reg(R) if p.endswith(".py")]:
        for n in ast.walk(ast.parse(rd(os.path.join(R, p)))):
            if isinstance(n, ast.Import):
                imps.setdefault(p, []).extend(a.name.split(".")[0] for a in n.names)
            elif isinstance(n, ast.ImportFrom) and n.module:
                imps.setdefault(p, []).append(n.module.split(".")[0])
    out_allow = sorted({(p, m) for p, ms in imps.items() for m in ms if m not in ALLOWED_IMPORTS})
    log = rd(f"{R}/COMMAND_LOG.txt")
    cmds = [ln.strip()[2:].strip() for ln in log.split("\n") if ln.strip().startswith("$ ")]
    bad_cmd = [c for c in cmds if not c.split() or c.split()[0] not in ALLOWED_CMD]
    tok_hit = sorted({t for t in FORBIDDEN_TOKENS for c in cmds if t in c})
    v17 = not out_allow and not bad_cmd and not tok_hit and len(cmds) >= 12
    ok_all &= rec("C17", v17, f"scripts_with_imports={len(imps)} outside_allowlist={out_allow[:3]}; "
                              f"logged_commands={len(cmds)} disallowed_program={bad_cmd[:2]} "
                              f"forbidden_token_hits={tok_hit[:3]}",
                  "no pip/conda/git/curl/wget/torch/GPU/network program or token in any logged command; "
                  "stdlib-allowlist imports only", "scripts/*.py; COMMAND_LOG.txt `$ ` lines",
                  "AST import scan + logged argv scan")

    # C18 secret / raw-asset / pyc sweep with a live positive control.  The two DSN alternatives keep
    # their userinfo classes free of [ ] \ on purpose so that the detector strings carried by packaged
    # files cannot match themselves, while a real user-password-at-host string still trips the gate.
    sec = re.compile(r"(BEGIN [A-Z ]*PRIVATE KEY|aws_secret_access_key\s*[=:]|(?:api_|access_)?token"
                     r"\s*=\s*['\"][A-Za-z0-9+/]{20,}|bearer [A-Za-z0-9+/._-]{30,}"
                     r"|password\s*[=:]\s*['\"][^'\"]{6,}"
                     r"|postgres(?:ql)?://[A-Za-z0-9_.\-]+:[^\s'\"\[\]\\]+@"
                     r"|mysql://[A-Za-z0-9_.\-]+:[^\s'\"\[\]\\]+@)", re.I)
    forb = re.compile(r"(^|/)(corpus_v1\.jsonl|donor_index\.jsonl|split_bbd\.json|config\.json"
                      r"|RAW_PREDICTIONS\.jsonl|.*\.(pt|ckpt|bin|env|onnx|pkl)$)", re.I)
    bad18 = []
    ctrl = "mys" + "ql://" + "svc_user" + ":" + "SyntheticPw9" + "@" + "10.0.0.1:3306" + "/db"
    ctrl_hit = bool(sec.search(ctrl))
    for rel in walk_reg(R):
        p = os.path.join(R, rel)
        if forb.search(rel) or rel.endswith(".pyc") or "__pycache__" in rel:
            bad18.append(("forbidden_name", rel))
        elif os.path.getsize(p) > 5 << 20:
            bad18.append(("oversize", rel))
        elif rel.endswith((".py", ".md", ".txt", ".csv", ".json", ".jsonl")):
            m = sec.search(rd(p))
            if m:
                bad18.append(("secret", rel, m.group(0)[:24]))
    ok_all &= rec("C18", not bad18 and ctrl_hit,
                  f"files={len(walk_reg(R))} deviations={bad18[:3]}; runtime-built synthetic control "
                  f"caught by the same regex (control_match={ctrl_hit})",
                  "0 secret patterns, 0 raw gold/split/config/model assets, 0 oversize, 0 pyc, and the "
                  "detector must match its own positive control", "walk of the tree under test",
                  "regex sweep + runtime positive control that never touches a file")

    # C19 / C20 the two manifests
    ok19, ok20, n19 = check_manifests(R)
    ok_all &= rec("C19", ok19, f"files_manifest_entries={n19[0]} walked_regular={n19[1]}",
                  "MANIFEST.files covers every regular file including both manifests",
                  "MANIFEST.files", "set equality against a live walk")
    ok_all &= rec("C20", ok20, f"sha_manifest_entries={n19[2]} (self excluded)",
                  "every other regular file hashed and every hash recomputed from live bytes",
                  "MANIFEST.sha256", "hash recompute equivalent to sha256sum -c")

    # SUP21 (beyond the C01-C20 minimum) inputs frozen and no foreign writes
    viol = []
    own = {os.path.basename(p) for p in (R3ARC, R3ARC + ".identity.txt", R3ARC + ".validation.txt",
                                         AP, AP + ".identity.txt")}
    for d in (RR, f"{ROOT}/HPC_Inputs"):
        for e in sorted(os.listdir(d)):
            if re.search(r"t6", e, re.I) or e in own or e == T or e.startswith(T + ".tar.gz"):
                continue                            # this round's own outputs are the point of it
            p = os.path.join(d, e)
            if os.path.isfile(p) and os.path.getmtime(p) >= R4_START_EPOCH - 2:
                viol.append(p)
    for e in sorted(os.listdir(ROOT)):
        if re.search(r"t6", e, re.I):
            continue
        p = os.path.join(ROOT, e)
        if os.path.isfile(p) and os.path.getmtime(p) >= R4_START_EPOCH - 2:
            viol.append(p)
    ws = os.path.dirname(W)
    for e in sorted(os.listdir(ws)):
        if e == T or re.search(r"t6", e, re.I):      # T6 dirs skipped by name, never stat-ed
            continue
        top = os.path.join(ws, e)
        for root_, dirs, fs in os.walk(top):
            if root_.count(os.sep) - top.count(os.sep) >= 2:
                dirs[:] = []
            for f in fs:
                if os.path.getmtime(os.path.join(root_, f)) >= R4_START_EPOCH - 2:
                    viol.append(os.path.join(root_, f))
    frozen21 = [(os.path.basename(p), sha(p) == h, os.path.getmtime(p) < R4_START_EPOCH - 2)
                for p, h in ((R3ARC, R3ARC_ID[0]), (AP, PAYLOAD_ID[0]))]
    v21 = not viol and all(h and m for _, h, m in frozen21)
    ok_all &= rec("SUP21", v21, f"frozen inputs {frozen21}; files newer than {R4_START_ISO} outside this "
                              f"round's own paths={viol[:3]}",
                  "R3 archive and authority payload unchanged and older than the round start; zero "
                  "writes anywhere else (T6-named entries skipped by name, never stat-ed)",
                  "stat/sha sweep of the return root, HPC_Inputs, project top-level files and sibling "
                  "workspaces", "prompt section 3 write prohibition")
    return ok_all


# ------------------------------------------------------------------ pre-write gates P01-P09
def gates_pwrite(R, ARC, UP, run_meta):
    """must never look at a validation record: it cannot exist yet (prompt section 8.3)."""
    ok_all = True
    idp, valp = ARC + ".identity.txt", ARC + ".validation.txt"
    st, fst = os.stat(ARC), os.stat(UP)

    v1 = (UP.startswith("/tmp/") and os.path.isdir(UP) and R == os.path.join(UP, T) and R != R4
          and fst.st_mtime >= st.st_mtime - 2 and fst.st_ctime >= st.st_mtime - 2
          and run_meta.get("unpack_1") == UP)
    ok_all &= rec("P01", v1,
                  f"temp parent {UP} mtime={utc(fst.st_mtime)} ctime={utc(fst.st_ctime)} vs archive "
                  f"mtime={utc(st.st_mtime)}; tar restores packaged mtimes onto the extracted entries, "
                  f"so this run's own temp directory is the freshness evidence",
                  "a /tmp directory created by this run after the archive landed, holding the tree "
                  "this gate reads", UP, "os.stat of the temp parent; run_meta.unpack_1")

    mem = tar_list(ARC)
    reg = [n for n, k, s in mem if k == "regular"]
    roots = sorted({n.split("/")[0] for n, k, s in mem})
    v2 = (roots == [T] and not unsafe_members(mem) and len(reg) == len(walk_reg(R))
          and open(ARC, "rb").read(2) == b"\x1f\x8b")
    ok_all &= rec("P02", v2, f"members={len(mem)} regular={len(reg)} roots={roots} "
                             f"unsafe={len(unsafe_members(mem))}",
                  "gzip, single root == TASK_ID, no absolute/'..'/symlink/hardlink/device/FIFO member",
                  ARC, "tarfile listing of the landed archive")

    ok_f, ok_s, n3 = check_manifests(R)
    ok_all &= rec("P03", ok_f and ok_s, f"files_manifest={n3[0]}/{n3[1]} sha_manifest={n3[2]} entries "
                                        f"recomputed inside U1",
                  "both manifests complete and every hash true over the extracted bytes",
                  f"{R}/MANIFEST.files; {R}/MANIFEST.sha256", "check_manifests on the fresh unpack")

    # P04 looks only at the content gate rows of this very run: the three P rows already recorded
    # above belong to the same process and must not make the content series look incomplete
    need = set(CGATES + SUPGATES)
    cexec = [g["gate"] for g in G if g["gate"] in need]
    cfail = sorted(g["gate"] for g in G if g["gate"] in need and g["status"] != "PASS")
    v4 = not cfail and len(cexec) == len(need)
    ok_all &= rec("P04",
                  v4,
                  f"content gates executed on U1={len(cexec)} of {len(need)} (C01-C20 + SUP21) "
                  f"failed={cfail}",
                  "C01-C20 plus SUP21 all PASS against the fresh unpack, nothing else executed",
                  "this run's gate list",
                  "gates_content run in the U1 tree while no record existed")

    rec7 = (dict(l.split("=", 1) for l in rd(idp).splitlines() if "=" in l)
            if os.path.isfile(idp) else {})
    v5 = (rec7.get("ARCHIVE_PATH") == ARC and rec7.get("ARCHIVE_FILENAME") == os.path.basename(ARC)
          and I(rec7.get("ARCHIVE_BYTES", -1)) == st.st_size and rec7.get("ARCHIVE_SHA256") == sha(ARC)
          and rec7.get("SINGLE_ROOT") == T and I(rec7.get("MEMBER_REGULAR_FILES", -1)) == len(reg))
    ok_all &= rec("P05", v5, f"identity: bytes={rec7.get('ARCHIVE_BYTES')} "
                             f"sha={str(rec7.get('ARCHIVE_SHA256'))[:16]}... root={rec7.get('SINGLE_ROOT')} "
                             f"regular={rec7.get('MEMBER_REGULAR_FILES')} | landed: bytes={st.st_size} "
                             f"sha={sha(ARC)[:16]}... regular={len(reg)}",
                  "identity re-read from disk equals the landed archive in path, filename, bytes, SHA, "
                  "root and regular-file count", idp, "field-by-field compare")

    keys = {"README_MD_SHA256": "README.md", "FINAL_STATUS_TXT_SHA256": "FINAL_STATUS.txt",
            "MANIFEST_FILES_SHA256": "MANIFEST.files", "MANIFEST_SHA256_SHA256": "MANIFEST.sha256"}
    m6 = {k: rec7.get(k) == sha(os.path.join(R, p)) for k, p in keys.items()}
    fz = [f for f, (h, _) in FROZEN.items() if sha(os.path.join(R, f)) != h]
    ok_all &= rec("P06", all(m6.values()) and not fz, f"identity key hashes {m6}; frozen-file "
                                                      f"deviations inside U1={fz}",
                  "the four identity key hashes and all 11 frozen R3 SHAs hit in the fresh unpack",
                  idp, "sha256 of U1 files vs the identity record and prompt section 1")

    strays = [valp + ext for ext in ("", ".tmp", ".partial", ".failed", ".bak")
              if os.path.lexists(valp + ext)]
    trio_any = [p for p in (ARC + ".identity.txt.validation.txt",) if os.path.lexists(p)]
    ok_all &= rec("P07", not strays and not trio_any,
                  f"probed {os.path.basename(valp)} plus .tmp/.partial/.failed/.bak; existing={strays}",
                  "NONE of them may exist before the first validation write", os.path.dirname(ARC),
                  "os.path.lexists probes only; nothing opened, deleted or reused")

    both = [(os.path.basename(p), oct(os.lstat(p).st_mode & 0o170000) if os.path.lexists(p) else "absent",
             os.lstat(p).st_size if os.path.lexists(p) else -1) for p in (ARC, idp)]
    ok_all &= rec("P08", all(k == "0o100000" and s > 0 for _, k, s in both)
                  and not any(os.path.islink(p) for p in (ARC, idp)), both,
                  "archive and identity regular (0o100000), non-symlink, non-empty",
                  os.path.dirname(ARC), "lstat")

    fs = rd(f"{R}/FINAL_STATUS.txt").splitlines()
    missing = [l for l in FS_PENDING if l not in fs]
    v9 = fs == FS_PENDING and not missing and "EXTERNAL_THREE_FILE_DELIVERY=PASS" not in "\n".join(fs)
    ok_all &= rec("P09", v9, f"lines={len(fs)} line1={fs[0]!r} extra_or_reordered="
                             f"{[l for l in fs if l not in FS_PENDING][:3]} "
                             f"missing_or_different={missing} "
                             f"premature_pass_claim={'EXTERNAL_THREE_FILE_DELIVERY=PASS' in chr(10).join(fs)}",
                  "the in-archive status is exactly the 11 section 10 lines, ending in "
                  "EXTERNAL_THREE_FILE_DELIVERY=PENDING_AT_ARCHIVE_TIME",
                  f"{R}/FINAL_STATUS.txt", "exact 11-line compare against the prompt section 10 block")
    return ok_all


# ------------------------------------------------------------------ post-write gates Q01-Q08
def gates_qwrite(R, ARC, UP, run_meta, c_ok, meta_path):
    ok_all = True
    idp, valp = ARC + ".identity.txt", ARC + ".validation.txt"
    trio = [ARC, idp, valp]
    present = {os.path.basename(p): os.path.lexists(p) for p in trio}
    ok_all &= rec("Q01", all(present.values()), present,
                  "archive, identity and validation with one basename all exist", RR, "lexists of the trio")

    kinds = [(os.path.basename(p),
              oct(os.lstat(p).st_mode & 0o170000) if os.path.lexists(p) else "absent",
              os.lstat(p).st_size if os.path.lexists(p) else -1) for p in trio]
    ok_all &= rec("Q02", all(k == "0o100000" and s > 0 for _, k, s in kinds)
                  and not any(os.path.islink(p) for p in trio), kinds,
                  "regular (0o100000), non-symlink, non-empty", RR, "lstat of the trio")

    rec7 = (dict(l.split("=", 1) for l in rd(idp).splitlines() if "=" in l)
            if os.path.isfile(idp) else {})
    ok_all &= rec("Q03", I(rec7.get("ARCHIVE_BYTES", -1)) == os.path.getsize(ARC)
                  and rec7.get("ARCHIVE_SHA256") == sha(ARC),
                  f"identity bytes={rec7.get('ARCHIVE_BYTES')} sha={str(rec7.get('ARCHIVE_SHA256'))[:16]}...; "
                  f"archive now bytes={os.path.getsize(ARC)} sha={sha(ARC)[:16]}...",
                  "archive bytes and SHA unchanged since the identity was written", idp, ARC)

    ran = {g["gate"]: g["status"] for g in G}
    v4q = (c_ok and all(k in ran for k in CGATES + SUPGATES)
           and all(v == "PASS" for k, v in ran.items() if k.startswith("C") or k in SUPGATES))
    ok_all &= rec("Q04", v4q,
                  f"C gates re-executed in the U2 tree: "
                  f"{len([k for k, v in ran.items() if k.startswith('C') and v == 'PASS'])} PASS of "
                  f"{len([k for k in ran if k.startswith('C')])}; SUP21={ran.get('SUP21')}",
                  "C01-C20 (plus SUP21) recomputed on the second fresh unpack, zero FAIL",
                  "this run's gate list", "gates_content(U2)")

    lines = (rd(valp) if os.path.isfile(valp) else "").split("\n")
    cl, pl = glines(lines, CGATES), glines(lines, PGATES)
    bad5 = sorted(l.split(":", 1)[0] for l in cl + pl
                  if not l.split(":", 1)[1].strip().startswith("PASS"))
    ids5 = [l.split(":", 1)[0] for l in cl + pl]
    dup5 = sorted({g for g in ids5 if ids5.count(g) > 1})
    shaped = {g for g, _ in gate_shaped(lines)}
    unexpected = sorted(shaped - set(CGATES) - set(PGATES))
    v5 = (len(cl) == len(CGATES) and len(pl) == len(PGATES) and not bad5 and not dup5
          and not unexpected)
    ok_all &= rec("Q05", v5, f"C lines={len(cl)} P lines={len(pl)} non-PASS={bad5} duplicates={dup5} "
                            f"gate-shaped ids outside C01-C20/P01-P09={unexpected}",
                  "contains and contains only the 20 C01-C20 lines and the 9 P01-P09 lines, every one "
                  "PASS, no FAIL/MISSING/duplicate and no other gate id (section 8.4 wording)",
                  valp, "line-level parse of the record as written")

    chain = [E(run_meta.get("archive_mtime_utc", "")), E(run_meta.get("identity_generated_utc", "")),
             E(run_meta.get("pre_write_gate_utc", "")), E(run_meta.get("first_validation_write_utc", ""))]
    vrec = {}
    for l in lines:
        if l.startswith(("RUN_ID=", "VALIDATION_NONCE=", "PRE_WRITE_GATE_UTC=",
                         "FIRST_VALIDATION_WRITE_UTC=")):
            k, vv = l.split("=", 1)
            vrec[k] = vv.strip()
    ct = os.stat(valp).st_ctime if os.path.lexists(valp) else 0
    fields = {"RUN_ID": "run_id", "VALIDATION_NONCE": "nonce",
              "PRE_WRITE_GATE_UTC": "pre_write_gate_utc",
              "FIRST_VALIDATION_WRITE_UTC": "first_validation_write_utc"}
    match = {k: vrec.get(k) == run_meta.get(v) for k, v in fields.items()}
    ok_all &= rec("Q06", chain == sorted(chain) and 0 not in chain and all(match.values())
                  and bool(ct) and abs(ct - chain[3]) <= 120,
                  f"chain archive={utc(chain[0])} -> identity={utc(chain[1])} -> pre-write gate where "
                  f"the record was still absent={utc(chain[2])} -> first write={utc(chain[3])}; "
                  f"record fields equal run_meta={[k for k, v in match.items() if v]}; "
                  f"mismatches={[k for k, v in match.items() if not v]}; "
                  f"validation ctime={utc(ct)} ({round(ct - chain[3], 3)}s after the declared moment)",
                  "monotone run-id/nonce/time chain from the P07 absence assertion to the first write",
                  f"{meta_path}; {valp}", "field compare + stat")

    ref = re.findall(r"[\w./-]*\.tar\.gz\.(?:identity|validation)\.txt", rd(valp) if os.path.isfile(valp) else "")
    foreign = sorted({r for r in ref if T not in r})
    ok_all &= rec("Q07", not foreign, f"sidecar paths cited inside the record="
                                      f"{sorted({os.path.basename(x) for x in ref})[:4]} foreign={foreign[:3]}",
                  "the record cites only this TASK_ID's own sidecars; no superseded R3 sidecar is used "
                  "as current evidence", valp, "regex over the record text")

    u1, u2 = run_meta.get("unpack_1", ""), run_meta.get("unpack_2", "")
    f2 = os.stat(u2) if u2 and os.path.isdir(u2) else None
    ok_all &= rec("Q08", bool(u2) and u2 != u1 and u2.startswith("/tmp/")
                  and R == os.path.join(u2, T) and f2 is not None and f2.st_ctime >= chain[3] - 2
                  and E(run_meta.get("postwrite_gate_utc", "")) >= chain[3],
                  f"this run reads {R} under temp parent {u2} created {utc(f2.st_ctime) if f2 else 'n/a'} "
                  f"(first write was at {utc(chain[3])}); U1={os.path.basename(u1)}; the three physical "
                  f"files hashed here are the ones the record names",
                  "the post-write checker runs on a second fresh unpack, distinct from U1, over the "
                  "current three physical files", u2, meta_path)
    return ok_all


def final_readonly(ARC):
    """the third independent process: reopen the finished record and the three physical files.

    Read-only towards the delivery: it opens the trio and the extracted tree for reading only and
    never writes to the return directory, so its own exit code cannot be self-referentially written
    back into the record it checks."""
    idp, valp = ARC + ".identity.txt", ARC + ".validation.txt"
    res, val, lines = {}, "", []
    res["three_same_basename_files_regular_non_symlink_non_empty"] = all(
        os.path.isfile(p) and not os.path.islink(p) and os.path.getsize(p) > 0
        for p in (ARC, idp, valp))
    res["no_same_basename_temp_or_backup_file"] = not any(
        os.path.lexists(valp + ext) for ext in (".tmp", ".partial", ".failed", ".bak"))
    idl = (dict(l.split("=", 1) for l in rd(idp).splitlines() if "=" in l) if os.path.isfile(idp)
           else {})
    res["archive_bytes_match_identity"] = I(idl.get("ARCHIVE_BYTES", -1)) == os.path.getsize(ARC)
    res["archive_sha256_match_identity"] = idl.get("ARCHIVE_SHA256") == sha(ARC)
    res["identity_names_the_archive_that_exists"] = idl.get("ARCHIVE_PATH") == ARC
    val = rd(valp) if os.path.isfile(valp) else ""
    lines = val.split("\n")
    cl, pl, ql = glines(lines, CGATES), glines(lines, PGATES), glines(lines, QGATES)
    shaped = gate_shaped(lines)
    ids = [g for g, _ in shaped]
    res["c_block_20_pass_lines"] = len(cl) == len(CGATES) and all(
        l.split(":", 1)[1].strip().startswith("PASS") for l in cl)
    res["p_block_9_pass_lines"] = len(pl) == len(PGATES) and all(
        l.split(":", 1)[1].strip().startswith("PASS") for l in pl)
    res["q_block_8_pass_lines"] = len(ql) == len(QGATES) and all(
        l.split(":", 1)[1].strip().startswith("PASS") for l in ql)
    res["record_has_no_supplementary_gate_line"] = not any(g in SUPGATES for g, _ in shaped)
    res["no_unexpected_or_duplicated_gate_id"] = (
        not set(ids) - set(CGATES + PGATES + QGATES)
        and len(ids) == len(set(ids)))
    res["no_gate_line_fail_missing_blocked"] = not any(
        g in set(CGATES + PGATES + QGATES) and (not s.startswith("PASS") or "MISSING" in s)
        for g, s in shaped)
    res["postwrite_status_pass_8_of_8"] = "POSTWRITE_STATUS=PASS_8_OF_8" in val
    res["overall_pass"] = any(l.startswith("OVERALL:") and l.split(":", 1)[1].strip() == "PASS"
                              for l in lines)
    res["pending_markers_replaced"] = ("POSTWRITE_STATUS=PENDING" not in val
                                       and "OVERALL=PENDING" not in val)
    res["ready_constant_declared"] = READY in val
    res["external_delivery_claim_pass"] = "EXTERNAL_THREE_FILE_DELIVERY=PASS" in val
    res["final_readonly_command_declared_before_this_run"] = "FINAL_READONLY_CHECK_COMMAND=" in val
    # the record declares the literal argv of this very process; if it declared anything else (a
    # placeholder, another directory, another tree) then this run is not the run that was promised.
    # The interpreter prefix is compared separately because an interpreter flag such as -B never
    # reaches sys.argv, whose first entry is always the script itself.
    declared = next((l.split("=", 1)[1].strip() for l in lines
                     if l.startswith("FINAL_READONLY_CHECK_COMMAND=")), "")
    prefix = "python3 -B "
    tail = declared.split(prefix, 1)[1] if declared.startswith(prefix) else ""
    res["declared_final_readonly_command_is_this_very_run"] = bool(tail) and tail == " ".join(sys.argv)
    res["validator_source_hash_recorded"] = bool(re.search(r"VALIDATOR_SOURCE_SHA256=[0-9a-f]{64}", val))
    res["run_id_and_nonce_chain_recorded"] = bool(re.search(r"RUN_ID=\S+", val)) and bool(
        re.search(r"VALIDATION_NONCE=[0-9a-f]{32}", val))
    res["no_superseded_r3_sidecar_cited"] = (T3 + ".tar.gz.identity.txt" not in val
                                             and T3 + ".tar.gz.validation.txt" not in val)
    res["argv_and_exit_of_each_gate_run_recorded"] = ("PWRITE_COMMAND=" in val and "PWRITE_EXIT=" in val
                                                      and "POSTWRITE_COMMAND=" in val
                                                      and "POSTWRITE_EXIT=" in val)
    print(json.dumps({"stage": "final-readonly", "archive": ARC, "checks": res,
                      "this_argv": sys.argv,
                      "declared_final_readonly_command": declared,
                      "failed_checks": sorted(k for k, v in res.items() if v is not True),
                      "archive_sha256": sha(ARC),
                      "identity_sha256": sha(idp) if os.path.isfile(idp) else "missing",
                      "validation_sha256": sha(valp) if os.path.isfile(valp) else "missing",
                      "return_dir_bytes_written": 0}, sort_keys=True))
    return all(res.values())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["content", "pwrite", "postwrite", "final-readonly",
                                        "scan-source"], default="content")
    ap.add_argument("--root", default=R4, help="tree under test: live RETURN_DIR or <unpack>/TASK_ID")
    ap.add_argument("--archive", default=f"{RR}/{T}.tar.gz")
    ap.add_argument("--unpack-dir", dest="up", default="")
    ap.add_argument("--run-meta", dest="rmeta", default=f"{W}/logs/r4_run_meta.json")
    ap.add_argument("--out-json", default="")
    ap.add_argument("--scan-source", default="")
    a = ap.parse_args()
    if a.stage == "scan-source":
        f = tautology_scan(a.scan_source)
        print(json.dumps({"gate": "C06/C17 always-true scan", "path": a.scan_source,
                          "status": "PASS" if not f else "FAIL", "findings": f[:8],
                          "finding_count": len(f)}, sort_keys=True))
        sys.exit(0 if not f else 1)
    R = os.path.abspath(a.root)
    run_meta = json.loads(rd(a.rmeta)) if os.path.isfile(a.rmeta) else {}
    if a.stage == "final-readonly":
        # the third process deliberately re-executes NO content gate: its own exit code may never
        # become part of what it verifies (prompt section 8.4), so it only reopens the three
        # physical files, checks the finished record structure and exits
        ro = final_readonly(a.archive)
        if a.out_json:
            os.makedirs(os.path.dirname(a.out_json), exist_ok=True)
            with open(a.out_json, "w", encoding="utf-8") as f:
                json.dump({"stage": a.stage, "root": R, "archive": a.archive,
                           "utc": utc(time.time()), "all_checks_pass": ro,
                           "content_gates_re_executed": False,
                           "validator_source_sha256": sha(os.path.abspath(__file__)),
                           "argv": sys.argv}, f, indent=2, sort_keys=True)
        sys.exit(0 if ro else 1)
    try:
        c_ok = gates_content(R)
    except Exception as exc:                              # noqa: BLE001 - reported as a FAIL gate
        c_ok = rec("GATE_CRASH", False, f"{type(exc).__name__}: {exc}",
                   "every gate must produce a verdict instead of raising", "content",
                   "exception captured by the runner")
    ok = c_ok
    # a gate that cannot be computed has to become a FAIL row, never a traceback: the negative cases
    # of section 9 delete or corrupt exactly the files a gate reads, and the refusal must be evidenced
    try:
        if a.stage == "pwrite":
            ok = gates_pwrite(R, a.archive, a.up or os.path.dirname(R), run_meta) and ok
        elif a.stage == "postwrite":
            ok = gates_qwrite(R, a.archive, a.up or os.path.dirname(R), run_meta, c_ok, a.rmeta) and ok
    except Exception as exc:                              # noqa: BLE001 - reported as a FAIL gate
        ok = rec("GATE_CRASH", False, f"{type(exc).__name__}: {exc}",
                 "every gate must produce a verdict instead of raising", a.stage,
                 "exception captured by the runner") and ok
    fails = sorted({g["gate"] for g in G if g["status"] != "PASS"})
    out = {"stage": a.stage, "root": R, "archive": a.archive, "unpack_dir": a.up,
           "utc": utc(time.time()), "r4_start_utc": R4_START_ISO,
           "validator_source_sha256": sha(os.path.abspath(__file__)), "argv": sys.argv,
           "gates": sorted(G, key=lambda g: (g["gate"], g["status"])), "executed": len(G),
           "fail_count": len(fails), "failed": fails,
           "run_id": run_meta.get("run_id"), "nonce": run_meta.get("nonce")}
    lp = a.out_json or f"{W}/logs/r4_validator_{a.stage}.json"
    os.makedirs(os.path.dirname(lp), exist_ok=True)
    with open(lp, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False, sort_keys=True)
    print(f"stage={a.stage} executed={out['executed']} fails={out['fail_count']} -> {lp}")
    sys.exit(0 if not fails and ok else 1)


main()
