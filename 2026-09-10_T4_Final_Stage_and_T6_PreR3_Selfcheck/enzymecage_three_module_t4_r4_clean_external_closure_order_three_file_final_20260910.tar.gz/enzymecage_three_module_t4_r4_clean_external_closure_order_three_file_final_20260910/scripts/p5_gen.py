#!/usr/bin/env python3
"""T4-R2 p5: INPUT_IDENTITIES.csv, boundary matrix CORRECTED,
PERSISTENT_SOURCE_NONMUTATION.json, inherited_r1/ + §10 byte-identical reuse copies.
Evidence-only. python -B / PYTHONDONTWRITEBYTECODE=1."""
import csv
import hashlib
import json
import os
import shutil
import time

T = "enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
R1D = f"{W}/immutable_r1"
WORK = f"{W}/work"
NOW = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def row(name, role, path, eb, es, lb=None, ls=None, check="", note=""):
    if path and os.path.isfile(path):
        lb = lb if lb is not None else os.path.getsize(path)
        ls = ls if ls is not None else sha(path)
        if not check:
            sha_ok = ls == es
            bytes_ok = (str(eb) == "") or (str(lb) == str(eb))
            check = "MATCH" if (sha_ok and bytes_ok) else "MISMATCH"
    else:
        check = check or "NOT_REHASHED_RECORD_CITATION"
    return {"input_name": name, "role": role, "path": path or "NA",
            "expected_bytes": eb, "expected_sha256": es,
            "live_bytes": lb if lb is not None else "NA",
            "live_sha256": ls if ls is not None else "NA",
            "check": check, "note": note}


AP = f"{ROOT}/HPC_Inputs/t4_r2_teacher_authority_and_r1_local_audit_payload_20260909.tar.gz"
A = f"{W}/immutable_authority/t4_r2_teacher_authority_and_r1_local_audit_payload_20260909"
R1ARC = f"{RR}/enzymecage_three_module_t4_r1_runtime_blindness_training_overlap_normalization_metric_delivery_evidence_correction_20260909.tar.gz"

rows = [
    row("t4_r2_authority_payload", "authority_payload", AP, 10189,
        "19744d4308eecf382002764820b551469d441ab9b5d113242c44db5c8255d54d",
        note="prompt §1"),
    row("teacher_reply_original", "teacher_authority",
        f"{A}/TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md",
        5995, "953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4",
        note="byte-identical to the teacher original received in the T4-R1 payload"),
    row("t4_r1_local_audit", "audit_authority",
        f"{A}/ENZYMECAGE_THREE_MODULE_T4_R1_RUNTIME_BLINDNESS_TRAINING_OVERLAP_NORMALIZATION_METRIC_DELIVERY_EVIDENCE_CORRECTION_RETURN_LOCAL_AUDIT_2026-09-09.md",
        12587, "88fadc15ccee8a8ecae689f3721f1ba2c946e113bb89de6f750ffbb7ad750b42",
        note="verdict REJECTED_REQUIRES_SMALL_EVIDENCE_CORRECTION defines R2 scope"),
    row("t4_r1_return_archive", "baseline_archive", R1ARC, 172378,
        "4a52c450c78591f765c2368bd716dfd2b5dc4ade40ad1e9789c4d92279c7bdae",
        note="unpacked to task-local immutable_r1/; single root; safe members"),
    {"input_name": "r1_manifest_sha256_verification", "role": "baseline_gate", "path": f"{R1D}/MANIFEST.sha256",
     "expected_bytes": "52 entries", "expected_sha256": "52/52 live rehash",
     "live_bytes": os.path.getsize(f"{R1D}/MANIFEST.sha256"),
     "live_sha256": sha(f"{R1D}/MANIFEST.sha256"),
     "check": "52_OF_52_PASS", "note": "prompt §2 gate; any failure => BLOCKED_INPUT_IDENTITY"},
    {"input_name": "r1_manifest_files_coverage", "role": "baseline_gate", "path": f"{R1D}/MANIFEST.files",
     "expected_bytes": "53 entries", "expected_sha256": "53/53 set equality vs walked files",
     "live_bytes": os.path.getsize(f"{R1D}/MANIFEST.files"),
     "live_sha256": sha(f"{R1D}/MANIFEST.files"),
     "check": "53_OF_53_PASS", "note": "both manifests listed; no missing/phantom"},
]

# 16 inherited files (§4): expected from R1 MANIFEST.sha256, live recomputed
man = {}
for line in open(f"{R1D}/MANIFEST.sha256", encoding="utf-8"):
    if line.strip():
        s, rel = line.rstrip("\n").split("  ", 1)
        man[rel] = s
INHERIT = [r["r1_file"] for r in csv.DictReader(open(f"{WORK}/R1_INHERITED_ARTIFACT_IDENTITIES.csv", encoding="utf-8"))]
for name in INHERIT:
    rows.append(row(f"inherited_r1/{name}", "r1_inherited_baseline", f"{R1D}/{name}",
                    "", man[name], note="expected=R1 MANIFEST.sha256 entry; live rehashed in R2 session"))

# envipath local frozen templates (T2B-R4 ASSET_RUNTIME_IDENTITY_GATE records)
CREW_IMPLICITH = "/usrdata/EnzymeCAGE_data/enzymecage_crew/data/hfix/templates_implicitH.jsonl"
TSV = "/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t2b_r4_evidence_only_access_instrument_external_three_file_closure_20260907/r4_replay/reaction_v3/data/lib_envipath/templates.tsv.gz"
rows.append(row("envipath_local_template_implicitH", "envipath_runtime_rule_asset_local_frozen",
                CREW_IMPLICITH, 138383,
                "3c3db55c385cfbe6d0553f155edec2189bf92247d314baf2fad97afdf5fb1948",
                note="T2B-R4 ASSET_RUNTIME_IDENTITY_GATE.json frozen record; re-hashed read-only in R2 (identity only, no content parsing)"))
rows.append(row("envipath_local_template_tsv_gz", "envipath_runtime_rule_asset_local_frozen",
                TSV, 31059,
                "19ac04ca4d6c516f7dce0f7536959847bec91ba81a68384c58551ead18ebe4f1",
                note="T2B-R4 ASSET_RUNTIME_IDENTITY_GATE.json frozen record; re-hashed read-only in R2 (identity only, no content parsing)"))

# fold6/8 actual split identities (citation of first-package frozen record; NOT re-read here)
r1ii = list(csv.DictReader(open(f"{R1D}/INPUT_IDENTITIES.csv", encoding="utf-8")))
for r in r1ii:
    if "fold6" in r["name"] or "fold8" in r["name"]:
        rows.append({"input_name": f"actual_identity_{r['name'].replace(' ', '_')}",
                     "role": "prompt_transcription_correction_citation",
                     "path": r["path"],
                     "expected_bytes": r["expected_bytes"],
                     "expected_sha256": r["expected_sha256"] + " (T4-R1 prompt value, 1 hex char transcription typo)",
                     "live_bytes": r["live_bytes"], "live_sha256": r["live_sha256"],
                     "check": "ACTUAL_SPLIT_SHA_FROM_FROZEN_RECORD",
                     "note": ("actual split SHA per first-package RUNTIME_MODEL_AND_SCRIPT_IDENTITIES.csv "
                              "and R1 live verification; eclipse/config.json SHAs (0065.../56d8...) are NOT "
                              "split identities and are not cited as such in R2; split files NOT re-read in R2")})

with open(f"{WORK}/INPUT_IDENTITIES.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
bad = [r["input_name"] for r in rows if r["check"] in ("MISMATCH",)]
print(f"INPUT_IDENTITIES.csv rows={len(rows)} bad={bad}")
assert not bad

# ---------------------------------------------------------------- boundary CORRECTED
bmc = list(csv.DictReader(open(f"{R1D}/T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX.csv", encoding="utf-8")))
assert len(bmc) == 16
NEWCOLS = ["r2_evidence_update", "r2_correction_note"]
for i, r in enumerate(bmc):
    r["r2_evidence_update"] = ""
    r["r2_correction_note"] = ""
    if i == 1:
        r["notes"] += (" | R2 clarification: the two manifest layers are separate - base T4 package "
                       "MANIFEST.sha256=89/89 verified, base raw freeze manifest=54/54 verified; the "
                       "BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json field raw_freeze...verified_ok=54 "
                       "describes the raw-freeze layer only and must not be read as the base count "
                       "(R1 file inherited byte-identical, count fixed in narration here and in README).")
    if i == 4:
        r["evidence_artifacts"] = ("DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv; "
                                   "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv; "
                                   "DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv; "
                                   "DEPENDING_EXACT_MATCH_EVIDENCE_LOCATORS.csv; "
                                   "DEPENDING_T4_HIT_PROVENANCE_AND_EXPOSURE.csv")
        r["r2_evidence_update"] = "pointers moved to asset-local corrected matrices + global layered table"
    if i == 5:
        r["evidence_artifacts"] = ("DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv; "
                                   "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv; "
                                   "DEPENDING_PRODUCT_ASSET_LOCAL_STATUS_DISTRIBUTION.csv; "
                                   "DEPENDING_AUDITABLE_ASSET_SCHEMA_INVENTORY.csv")
        r["r2_evidence_update"] = "template P5 counts now per-asset (29/8/26 reaction, 39/39/39 product), never sums"
    if i == 6:
        r["attested_finding_or_value"] = r["attested_finding_or_value"].replace(
            "ranker-dependent exposure recorded as UNKNOWN (never 0)",
            "ranker training overlap recorded as UNKNOWN_FOR_ALL_18 (never 0); this is DISTINCT from "
            "cases_without_any_auditable_parent_or_template_locator=[] (0/18)")
        r["evidence_artifacts"] = ("DEPENDING_AUDITABLE_ASSET_SCHEMA_INVENTORY.csv; "
                                   "DEPENDING_OPAQUE_RANKER_LIMITATION_CORRECTED.md; "
                                   "DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY_CORRECTED.json")
        r["r2_correction_note"] = ("R1 q6 conflated opaque-ranker UNKNOWN with empty locator list; "
                                   "external-envipath-KB wording removed")
    if i == 9:
        r["evidence_artifacts"] += "; DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY_CORRECTED.json"
        r["r2_evidence_update"] = "q6 conflation superseded by corrected summary"
    if i == 13:
        r["evidence_artifacts"] = r["evidence_artifacts"].replace(
            "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET.csv",
            "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv")
        r["r2_evidence_update"] = "overlap attestation now cites asset-local corrected matrices + global layered tables"

cols = list(bmc[0].keys())
with open(f"{WORK}/T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(bmc)
print("boundary CORRECTED written (16 rows + 2 R2 columns)")

# ---------------------------------------------------------------- copies
os.makedirs(f"{WORK}/inherited_r1", exist_ok=True)
for name in INHERIT:
    shutil.copy2(f"{R1D}/{name}", f"{WORK}/inherited_r1/{name}")
REUSE10 = ["DEPENDING_NORMALIZED_PREDICTIONS_CORRECTED.jsonl",
           "NORMALIZATION_CORRECTION_METRIC_INVARIANCE.json",
           "FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv",
           "ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv",
           "ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv",
           "ECLIPSE_CASE_FOLD_EXPOSURE_SUMMARY.csv",
           "ECLIPSE_GOLD_REACTION_FOLD_EXPOSURE_SUMMARY.csv",
           "ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv",
           "CORRECTED_ACCESS_AND_ARTIFACT_TIMELINE.csv",
           "ACCESS_AUDIT_SEMANTIC_CORRECTION.md"]
for name in REUSE10:
    shutil.copy2(f"{R1D}/{name}", f"{WORK}/{name}")
# byte-identity verification of every copy
for name in INHERIT:
    assert sha(f"{WORK}/inherited_r1/{name}") == sha(f"{R1D}/{name}") == man[name], name
for name in REUSE10:
    assert sha(f"{WORK}/{name}") == sha(f"{R1D}/{name}") == man[name], name
print(f"copies verified: inherited_r1 {len(INHERIT)} + reuse {len(REUSE10)} byte-identical vs R1 manifest SHAs")

# ---------------------------------------------------------------- PERSISTENT_SOURCE_NONMUTATION.json
persist = {
    "task_id": T,
    "declaration_utc": NOW,
    "nature": "T4-R2 evidence-only correction; read-only w.r.t. all persistent sources",
    "evidence_basis": [
        "teacher original re-verified byte-identical: sha256 953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4 (same bytes as first received in T4-R1 payload)",
        "R1 local audit re-verified byte-identical: sha256 88fadc15ccee8a8ecae689f3721f1ba2c946e113bb89de6f750ffbb7ad750b42",
        "T4-R1 archive re-verified: bytes=172378 sha256 4a52c450c78591f765c2368bd716dfd2b5dc4ade40ad1e9789c4d92279c7bdae; R1 MANIFEST.sha256 52/52 PASS, MANIFEST.files 53/53 PASS; immutable_r1/ copy never written after unpack",
        "16 R1 baseline files (§4) copied byte-identical to inherited_r1/ with per-file live SHA == R1 manifest SHA (R1_INHERITED_ARTIFACT_IDENTITIES.csv + INPUT_IDENTITIES.csv)",
        "10 §10 reuse files copied byte-identical (normalized corrected, metric invariance, four-tool metrics, 5 ECLIPSE matrices, access timeline + semantic correction); no rescoring, no fold recompute",
        "T4 base archive (d7459a7a...) and raw freeze archive (b07ac6e8...): not opened, not re-extracted, not modified in R2; their R1 recheck records (BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json) inherited byte-identical",
        "two LOCAL frozen envipath template files re-hashed READ-ONLY for identity (3c3db55c... / 19ac04ca..., both equal to T2B-R4 ASSET_RUNTIME_IDENTITY_GATE.json records); no content parsing into new overlap indexes",
        "large assets (corpus_v1.jsonl, donor_index.jsonl, templates.json, 10 eclipse split_bbd.json, ranker .txt) NOT read in this session; all R2 derivations consumed only R1-frozen small matrices",
        "production code, model files, checkpoints, databases, environments, old return packages, GitHub: zero writes",
    ],
    "write_domains": [
        f"{W}/ (this R2 task workspace only)",
        f"{RR}/{T}/ + {RR}/{T}.tar.gz + .identity.txt + .validation.txt (this R2 return objects only)",
        "/tmp new temp dirs created by R2 for re-extraction verification",
    ],
    "model_rerun": False,
    "raw_predictions_changed": False,
    "metrics_changed": False,
    "oof_computed": False,
    "git_push": False,
    "teacher_draft_sent": False,
    "t6_entered": False,
    "model_role_decision": "AWAITING_HUANG_TEACHER_REVIEW",
}
with open(f"{WORK}/PERSISTENT_SOURCE_NONMUTATION.json", "w") as f:
    json.dump(persist, f, indent=2)
print("PERSISTENT_SOURCE_NONMUTATION.json written")
