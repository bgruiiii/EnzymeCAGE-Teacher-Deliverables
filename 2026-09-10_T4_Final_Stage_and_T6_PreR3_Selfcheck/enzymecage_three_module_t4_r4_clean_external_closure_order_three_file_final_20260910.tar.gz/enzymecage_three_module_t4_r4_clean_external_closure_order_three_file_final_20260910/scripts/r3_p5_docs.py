#!/usr/bin/env python3
"""T4-R3 p5 (prompt section 8): write the four narrative/ status artefacts.

Idempotent: README.md, AUTHORITY_AND_SCOPE.md and COMMAND_LOG.txt are always rebuilt from the
pristine R2 copies in immutable_r2/ plus the fixed R3 block below, so a re-run never duplicates
text.  FINAL_STATUS.txt is rewritten from the section 0/12 status constants.  Nothing here
recomputes a scientific number; every factual claim points at a JSON/CSV produced by the
scripts that measured it.  PYTHONDONTWRITEBYTECODE=1 / python3 -B."""
import hashlib
import json
import os
import sys
import time

T = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R2D = f"{W}/immutable_r2"
R3 = f"{RR}/{T}"
A = f"{W}/immutable_authority/t4_r3_teacher_authority_and_r2_local_audit_payload_20260910"
AP = f"{ROOT}/HPC_Inputs/t4_r3_teacher_authority_and_r2_local_audit_payload_20260910.tar.gz"
T2 = "enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909"
R2ARC = f"{RR}/{T2}.tar.gz"

READY_LINES = [
    "T4_R3_REPORT_VALIDATOR_SIDECAR_CLOSURE_READY_FOR_LOCAL_AUDIT",
    "MODEL_RERUN=false",
    "RAW_PREDICTIONS_CHANGED=false",
    "METRICS_CHANGED=false",
    "STRICT_UNSEEN_BLIND_EVALUATION=NOT_ESTABLISHED",
    "CURRENT_METRICS=VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY",
    "MODEL_ROLE_DECISION=AWAITING_HUANG_TEACHER_REVIEW",
    "TEACHER_DECISION_REQUEST_SENT=false",
    "T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true",
    "EXTERNAL_THREE_FILE_DELIVERY=PASS",
]
BLOCKED_LINE0 = "T4_R3_STATUS=BLOCKED_VALIDATION_FAILED"

R3_README = """

## T4-R3 tiny report / validator / sidecar closure (2026-09-10)

R3 changes no scientific result. It closes exactly the four items left open by the T4-R2 return
local audit, on top of the byte-identical R2 baseline recorded in
`R2_BASELINE_FILE_IDENTITIES.csv`, `R2_TO_R3_CHANGED_FILES.csv` and
`R2_CONTENT_NONMUTATION.json`.

- parent four-column label corrected: the boundary matrix now lists the parent CSV columns as
  `case_id, parent_name, parent_smiles, parent_smiles_rdkit_canonical`; the fourth column is the
  RDKit-canonical parent SMILES, not a task identifier. Exactly one cell of the matrix changed
  (`PARENT_FOUR_COLUMN_DESCRIPTION_CORRECTION.json`).
- T4 does not block the independent T6: the teacher draft closing line now says this T4 task does
  not enter T6 and does not pick the T6 model role, and that T6 keeps running under its own teacher
  contract without this T4 A/B decision as a precondition
  (`T4_T6_INDEPENDENCE_WORDING_CORRECTION.json`). The first 92 draft lines are byte-identical.
- validator V23 hardened: `scripts/p6_validator.py` no longer contains the always-true short-circuit
  the audit flagged. V23 is now a conjunction of 25 explicit sub-checks over the input identity
  table, this README and the teacher draft, backed by an independent recomputation in
  `scripts/r3_validator.py` (V13/V14) and a regex+AST source scan (V12). All eight negative cases
  N1-N8 are detected and the unmodified artefact passes
  (`V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json`).
- R2 data and metrics untouched: no model run, no inference, no rescoring, no corpus/template scan,
  no overlap or ECLIPSE recompute, no OOF. Raw predictions, both 312-row BY_ASSET matrices, both
  39-row GLOBAL tables, the ECLIPSE tables, the four-tool metric table and the normalized
  predictions are byte-identical to the R2 archive, and the R2 accepted anchors were re-checked
  read-only before any edit.
- three-file closure required: this package must be received together with the archive,
  `<archive>.identity.txt` and `<archive>.validation.txt`, all three regular non-symlink files in
  the same return root. The validation record is produced only from a fresh re-extraction of the
  landed archive, never from the pre-packing directory.
"""

R3_AUTHORITY = """# T4-R3 Authority and Scope

## Authority chain (verified read-only before any write)

```text
t4_r3_teacher_authority_and_r2_local_audit_payload_20260910.tar.gz
  bytes=9326 sha256=2b5e7be0434d802c3013264a82eab07757854a891601a0cc379cf0e2e3f85b78
  single root, 3 regular members, 0 unsafe entries
  -> TEACHER_REPLY_T4_INPUT_IDENTITY_AND_ORCHESTRATION_BOUNDARY_2026-09-08.md 3627 / ca270af0...
  -> TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md 5995 / 953920df...
  -> ENZYMECAGE_..._T4_R2_..._RETURN_LOCAL_AUDIT_2026-09-09.md 8028 / 793530ef...
enzymecage_three_module_t4_r2_..._final_correction_20260909.tar.gz
  bytes=169035 sha256=025c4e7be5c703d1d6ec2719415c15cd66d5e2b1cbd97e48c6b42daa3fd87826
  51 regular files; MANIFEST.files 51/51; MANIFEST.sha256 50/50 (excludes itself)
executor prompt: docs/HPC_ENZYMECAGE_THREE_MODULE_T4_R3_TINY_REPORT_VALIDATOR_SIDECAR_CLOSURE_
                 EXECUTOR_ONLY_PROMPT_2026-09-10.md
```

The local audit verdict for R2 was `PASS_CONTENT_REQUIRES_TINY_REPORT_VALIDATOR_AND_SIDECAR_CLOSURE`
and it kept the four scientific result blocks of R2 unchanged. R3 therefore treats every R2 content
file as an immutable baseline and closes only the four listed items (audit sections 10.1, 10.2, 11
and the missing external sidecars of section 2).

## What this round is allowed to change

```text
T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv   (one cell, audit section 10.1)
HUANG_TEACHER_..._DECISION_REQUEST_CORRECTED_DRAFT.md     (one closing line, audit section 10.2)
scripts/p6_validator.py                                   (V23 hard gate, audit section 11)
README.md / FINAL_STATUS.txt / COMMAND_LOG.txt / AUTHORITY_AND_SCOPE.md / MANIFEST.files / MANIFEST.sha256
new R3 audit records and the R3 validator / mutation / closure scripts
```

Everything else in the R2 baseline stays byte-identical; the measured before/after identity of all
51 baseline files is in `R2_TO_R3_CHANGED_FILES.csv` and `R2_CONTENT_NONMUTATION.json`.

## Hard boundaries honoured

```text
no model inference, training, fold replay, normalization, rescoring, overlap or ECLIPSE recompute,
no OOF computation, no reading of raw splits / corpus / templates / gold originals
no network, no pip/conda, no GPU, no LLM/API call
no write outside this task's workspace, its return directory and its three same-basename files
no modification of production code, the crew, databases, models, environments, the T4-R1/R2
packages or GitHub; nothing committed, nothing pushed
no entry into, read of, or stat of any directory or file whose name carries the T6 task marker;
T6 independence is asserted from the teacher reply of 2026-09-08 and from the corrected draft line
no token, password, private key, DSN, .env content or sensitive header anywhere in the package
```

## Declared limits that R3 does not remove

```text
STRICT_UNSEEN_BLIND_EVALUATION = NOT_ESTABLISHED
CURRENT_METRICS = VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY
MODEL_ROLE_DECISION = AWAITING_HUANG_TEACHER_REVIEW (options A and B stay neutral)
fold1-9 raw split files were never packaged, so the ECLIPSE matrices stay inherited evidence
the teacher draft remains local: it is not sent and not uploaded
```
"""

R3_LOG = r"""
================================================================================
T4-R3 COMMAND LOG (report facts, validator hard gate, external three-file closure)
TASK_ID: enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910
Session 2026-09-10, local timezone = UTC. Every Python call ran with
PYTHONDONTWRITEBYTECODE=1 and python3 -B. Only commands actually executed are
listed; exit codes are the real ones, including the failed attempts.
================================================================================

[p0 prompt section 2 fresh gate] 02:50:55Z
  $ python3 -B -c "<section 2 fresh gate: stat the six R3 output paths>"
    -> all six R3 output paths absent, so the run may start; nothing deleted, renamed or reused
  $ stat -c '%s %n' HPC_Inputs/t4_r3_teacher_authority_and_r2_local_audit_payload_20260910.tar.gz
    -> regular non-symlink, bytes=9326
  $ sha256sum t4_r3_teacher_authority_and_r2_local_audit_payload_20260910.tar.gz
    -> 2b5e7be0434d802c3013264a82eab07757854a891601a0cc379cf0e2e3f85b78 MATCH section 1
  $ tar -tzf t4_r3_..._payload_20260910.tar.gz  (listed through python tarfile as well)
    -> single root, 3 regular members, 0 absolute / .. / symlink / hardlink / device / FIFO
  $ mkdir -p immutable_authority && tar -xzf payload into immutable_authority/
    -> members 3627/ca270af0..., 5995/953920df..., 8028/793530ef... all MATCH section 1
  $ sha256sum enzymecage_three_module_t4_r2_..._final_correction_20260909.tar.gz
    -> bytes=169035 sha256=025c4e7be5c703d1d6ec2719415c15cd66d5e2b1cbd97e48c6b42daa3fd87826 MATCH
  $ python3 -B -c "safe list R2 archive; extract to workspace immutable_r2/; check both manifests"
    -> 51 regular files, 0 unsafe; MANIFEST.files 51/51; MANIFEST.sha256 50 entries excluding
       itself, all 50 hashes recomputed OK; MANIFEST.files sha 795077087e... and
       MANIFEST.sha256 sha 7a2d05a4b0... match section 1
  $ python3 -B -c "re-hash the ten section 1 immutable/mutable identities"
    -> 10/10 MATCH, including scripts/p6_validator.py 32138 / c99946e19a76b2bc...

[p1 section 4 R2 baseline first, no re-derivation]
  $ python3 -B scripts/r3_p1_baseline.py
    -> copied 51 regular files into RETURN_DIR, recorded R2_BASELINE_FILE_IDENTITIES.csv
       (path/bytes/live sha/R2 manifest sha) BEFORE any modification, then re-checked the
       read-only R2 anchors: 312/312 twice, 39/39 twice, 13/39, 15/18, 16/39, 390 with
       190/35/25/140, 180 with 142/21/17, 113 hit cells, metrics and normalized SHAs
       -> 24/24 anchors ok, exit=0, status=R2_BASELINE_ACCEPTED (logs/r3_p1_baseline.json)

[p2 section 5 parent four-column label]
  $ python3 -B scripts/r3_p2_p3_fix.py
    -> first version of this script reported 4 failing checks and exit=1; the target files
       were already correct, so the failure was traced to the checker itself: two checks were
       named in the negative ("..._still_present") and were read as failures when False, the
       digit-preservation test counted the task names T4/T6 as numbers, a "DRAFT" literal never
       occurs in the draft (it uses a Chinese status line), and one informational non-boolean
       value stayed inside the check dict. All four defects were fixed in the checker, not in
       the evidence; the script was rewritten to rebuild both files from immutable_r2/ so it
       is idempotent, then re-run -> exit=0, PROBLEMS none (logs/r3_p2_p3_fixes.json)
    -> measured result: exactly 1 changed cell of 16x8, header/other cells/notes byte-identical,
       'task id' and the old pollutant-name label gone, gold_columns_in_parent_csv=0 kept,
       new SHA e4eb988f... (was d4c05126...), PARENT_FOUR_COLUMN_DESCRIPTION_CORRECTION.json
       checks all true

[p3 section 6 T4 must not read as blocking T6]
  -> same measured run: only line 93 replaced, first 92 lines byte-identical, both A/B option
     lines verbatim, 164 non-task-name numeric tokens preserved, line count 93, old
     "T6 is not entered" wording gone, new independence sentence unique, draft still marked
     local / not sent / not uploaded, no git push; new SHA 9465ee87... (was a791d049...);
     T4_T6_INDEPENDENCE_WORDING_CORRECTION.json checks all true and quotes the two 2026-09-08
     teacher facts verbatim

[p4 section 7 V23 hard gate]
  - measured first: the flagged construct sat on line 397 of the R2 script, inside an all(...)
    generator, and the two fold rows of INPUT_IDENTITIES.csv were read as-is (status
    ACTUAL_SPLIT_SHA_FROM_FROZEN_RECORD, expected value 1 hex character off from live, note
    saying the config SHAs are not split identities)
  - the R2 script was then edited in the executor scratch directory in three hunks - a new
    fold_checks()/fold_gate() helper pair, the V23 rewiring, and the --root/--v23-only CLI -
    and the result was copied back into RETURN_DIR/scripts and workspace/scripts; no other R2
    script was touched
  - re-checked the rewritten script: 0 occurrences of the flagged construct (a count on the
    scratch copy returned 0), and 25 explicit boolean sub-checks now replace the single old
    expression
  $ python3 -B scripts/p6_validator.py --root RETURN_DIR --v23-only
    -> {"gate": "V23", "verdict": "PASS", "subcheck_count": 25, "failed_subchecks": []} exit=0
  $ python3 -B scripts/r3_validator.py --scan-source scripts/<each packaged .py>
    -> 8/8 {"verdict": "PASS", "finding_count": 0} at that moment (regex and AST both clean); the
       final package holds 11 scripts and V12 scans all of them in one pass
  $ python3 -B scripts/r3_mutation_test.py --root RETURN_DIR
    -> first run exit=1 although 8/8 negative cases were detected: the N1 expected-check label
       did not match the sub-check key name; fixed in the harness (test code only) and re-run
    -> second run exit=0: N1-N7 detected by the V23 gate, N8 rejected by the V12 source scan,
       unmodified artefact V23 PASS, clean source scan PASS; the bypass demonstration shows a
       re-injected always-true term wrongly PASSing the broken copy, which is why V12 exists;
       recorded in V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json

[p5 section 8 documents and changed-set]
  $ python3 -B scripts/r3_p5_docs.py
    -> first two passes exited 1 with 6 and then 1 failing self-check. Both times the written files
       were correct and the faults were in the checker: three authority/log checks tested the
       substring against the path string returned by the writer instead of the file text, and one
       checked a phrase ("skipped by name") that lives in this log rather than in the authority
       file. Fixed in the checker, the artefacts were rebuilt from immutable_r2/ (the script is
       idempotent, so no text got duplicated) and the pass exited 0
    -> rebuilt README.md (R3 closure section), AUTHORITY_AND_SCOPE.md, FINAL_STATUS.txt (the ten
       section 12 lines) and this log from the pristine R2 copies
  $ python3 -B scripts/r3_p5b_changed_sets.py
    -> R2_TO_R3_CHANGED_FILES.csv (51 baseline rows + the R3 additions, before/after bytes+SHA) and
       R2_CONTENT_NONMUTATION.json (non-whitelist files byte-identical, named data files still at
       their section 1 SHAs). Two self-referential details are recorded instead of hidden: the
       manifest rows read FALSE_AT_WRITE_TIME because both manifests are regenerated after this
       table, and this table's own row plus this JSON's own bytes are not hashed inside themselves
       (MANIFEST.sha256 and <archive>.identity.txt carry those hashes)

[p6 sections 9-11 gates, packaging and external three-file closure]
  Every artefact that ends up in the archive is produced by one ordered pass: the four documents,
  then the mutation harness (it hashes the validator and scanner sources), then the changed-set
  table, then both manifests, then the content gates.  That pass was re-run from the start after
  each checker fix, so no record in the package predates the code it describes.
  Defects the gates caught during that loop, all fixed in the checker or generator and never by
  editing evidence: (1) the manifest generator flattened os.walk output, dropping the scripts/ and
  inherited_r1/ prefixes, which surfaced as a FileNotFoundError and would have failed V24; (2) V15
  parsed the harness summary line by a prefix that sort_keys() had reordered, so it read the harness
  as absent; (3) the V23 secret scan wrote its DSN alternatives as mysql://\S+:\S+@, which matched
  the detector string carried inside scripts/p6_validator.py itself - the userinfo classes were
  narrowed so a regex literal cannot match them, and a synthetic DSN assembled at run time (never
  written to any file) is now used as a positive control inside V23; (4) the import allowlist missed
  copy, which the inherited R2 validator imports; (5) the comment added while fixing (3) itself
  contained a DSN-shaped example and was caught by the same gate on the next pass, which is the
  clearest available evidence that V23 really runs over every packaged file. All five are recorded
  here rather than being silently repacked.
  The external closure also failed once on its first attempt: V28 compared the mtimes of the
  freshly extracted package directory against the archive mtime and, because tar deliberately
  restores the packaged mtimes, the directory looked older than the archive; V30 then failed by
  cascade and the validation record for that attempt carried BLOCKED_VALIDATION_FAILED. The gate
  evidence was wrong, not the artefact, so V28 now measures the mkdtemp() parent directory that the
  validation run creates after the archive landed (mtime and ctime both at or after the archive
  mtime) and requires it to be a /tmp path holding exactly <TASK_ID>/; the package was then rebuilt
  and resealed from scratch, so no archive validated by a broken gate is delivered.
  The commands below necessarily run after this text is packaged, so their exit codes are NOT
  written here; they are recorded per gate in ${ARCHIVE}.validation.txt and machine-readably in
  the executor workspace logs/r3_validator_content.json, logs/r3_validator_archive.json and
  logs/r3_closure.json, and each one is re-runnable by the local auditor:
    python3 -B scripts/r3_closure.py --stage manifest
    (MANIFEST.files over every regular file, then MANIFEST.sha256 for all but itself)
    python3 -B scripts/r3_validator.py --stage content         (V01-V25 on the live return dir)
    tar -czf ${ARCHIVE} -C ${RETURN_ROOT} ${TASK_ID}          (only after both manifests)
    python3 -B scripts/r3_closure.py --stage identity         (writes ${ARCHIVE}.identity.txt)
    mktemp -d /tmp/t4r3_reverify_XXXXXX and tar -xzf the landed archive into it
    python3 -B scripts/r3_validator.py --stage archive --unpack-dir <fresh temp>
    (V01-V25 recomputed on the FRESH copy only, then V26-V30 on archive/identity/sidecars/status)
    python3 -B scripts/r3_closure.py --stage validation       (writes ${ARCHIVE}.validation.txt,
     then re-runs the archive stage with --require-validation-record and an independent
     subprocess that re-hashes the live archive, the fresh tree and all three sidecars; a failed
     gate or a failed recheck replaces FINAL_STATUS line 1 with BLOCKED_VALIDATION_FAILED instead of
     keeping READY, and the record then demands a re-seal)

[Boundary honoured]
  No model, no inference, no fold replay, no normalization, no rescoring, no corpus/template or
  ECLIPSE overlap scan, no OOF, no raw split read; no network, pip, conda, GPU or LLM call; the
  T4-R1/R2 archives, the base package and the raw freeze were only hashed, never rewritten; every
  T6-named entry was skipped by name without stat or read; nothing sent to the teacher, nothing
  committed, nothing pushed. The task stops immediately after the three-file closure.
================================================================================
"""


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def wr(p, text):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    return p


problems = []
base_readme = open(f"{R2D}/README.md", encoding="utf-8").read()
base_log = open(f"{R2D}/COMMAND_LOG.txt", encoding="utf-8").read()

readme = wr(f"{R3}/README.md", base_readme.rstrip("\n") + "\n" + R3_README)
auth = wr(f"{R3}/AUTHORITY_AND_SCOPE.md", R3_AUTHORITY)
fs = wr(f"{R3}/FINAL_STATUS.txt", "\n".join(READY_LINES) + "\n")
log = wr(f"{R3}/COMMAND_LOG.txt", base_log.rstrip("\n") + "\n" + R3_LOG)

# self-checks: the new README keeps the fold facts and adds no forbidden citation
new_readme = open(readme, encoding="utf-8").read()
auth_txt = open(auth, encoding="utf-8").read()
log_txt = open(log, encoding="utf-8").read()
fs_txt = open(fs, encoding="utf-8").read()
checks = {
    "readme_r2_part_untouched": new_readme.startswith(base_readme.rstrip("\n")),
    "readme_r3_section_added": "T4-R3 tiny report / validator / sidecar closure" in new_readme,
    "readme_states_parent_label_fix": "parent_smiles_rdkit_canonical" in new_readme,
    "readme_states_t6_not_blocked": "T4 does not block the independent T6" in new_readme,
    "readme_states_v23_hardened": "validator V23 hardened" in new_readme,
    "readme_states_no_data_change": "R2 data and metrics untouched" in new_readme,
    "readme_states_three_files": "three-file closure required" in new_readme,
    "readme_config_sha_prefixes_absent": ("0065ebcc" not in new_readme and "56d8b332" not in new_readme),
    "readme_fold6_actual_sha_present": "b17ba7ae787c832faa3bfb0d452a46a24213bdd1a3203cca033628392d18d09f" in new_readme,
    "readme_fold8_actual_sha_present": "ecdd54c591cb0ff415db22e5791493356ef195cc5e0b96b4e0d6977fb90fe918" in new_readme,
    "readme_no_pending_marker": "[pending]" not in new_readme,
    "final_status_exact_ten_lines": len(fs_txt.rstrip("\n").split("\n")) == 10,
    "final_status_ready_constant": fs_txt.splitlines()[0] == READY_LINES[0],
    "final_status_all_twelve_values": fs_txt.rstrip("\n").split("\n") == READY_LINES,
    "authority_cites_payload_sha": ("2b5e7be0434d802c3013264a82eab07757854a891601a0cc379cf0e2e3f85b78"
                                    in auth_txt and sha(AP) == "2b5e7be0434d802c3013264a82eab07757854a891601a0cc379cf0e2e3f85b78"),
    "authority_cites_r2_archive_sha": sha(R2ARC) in auth_txt,
    "authority_declares_t6_read_prohibition": ("T6" in auth_txt
                                               and "name carries the T6 task marker" in auth_txt
                                               and "no write outside" in auth_txt),
    "command_log_r2_part_untouched": log_txt.startswith(base_log.rstrip("\n")),
    "command_log_records_failed_attempts": ("exit=1" in log_txt
                                            and "first version of this script reported" in log_txt),
    "command_log_deferred_steps_not_faked": "their exit codes are NOT\n  written here" in log_txt,
    "command_log_money_path_count": sum(1 for l in log_txt.splitlines()
                                        if l.strip().startswith("$ ")) >= 12,
    "all_files_utf8_and_nonempty": all(os.path.getsize(p) > 200 for p in (readme, auth, fs, log)),
}
for k, v in checks.items():
    if v is not True:
        problems.append(k)
res = {"stage": "r3_p5_docs", "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
       "written": [os.path.basename(p) for p in (readme, auth, fs, log)],
       "after_sha256": {os.path.basename(p): sha(p) for p in (readme, auth, fs, log)},
       "checks": checks, "failing": problems,
       "status": "OK" if not problems else "FAILED"}
json.dump(res, open(f"{W}/logs/r3_p5_docs.json", "w"), indent=2, ensure_ascii=False)
print("checks failing:", problems if problems else "none")
for p in (readme, auth, fs, log):
    print(f"{os.path.getsize(p):>7} {sha(p)[:16]}... {os.path.basename(p)}")
sys.exit(1 if problems else 0)
