#!/usr/bin/env python3
"""T4-R4 section 5 + 10: give the package its current identity and project the real command log.

  README.md              a T4-R4 header is placed on top, the R2 heading is demoted to an inherited
                         background section, the R3 section is relabelled HISTORICAL_SUPERSEDED, and
                         an R4 section documents the closure order and the relocated scripts.  The
                         R2/R3 body text below the headers is left untouched, so nothing that was
                         accepted earlier silently changes meaning.
  AUTHORITY_AND_SCOPE.md rewritten for R4: this round only touches the delivery layer.
  COMMAND_LOG.txt        projected from logs/commands.jsonl, which runlog wrote while each command
                         was really executed: UTC start, cwd, argv, exit, stdout/stderr bytes+SHA.

PYTHONDONTWRITEBYTECODE=1 / python3 -B."""
import hashlib
import json
import os
import time

T = "enzymecage_three_module_t4_r4_clean_external_closure_order_three_file_final_20260910"
T3 = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R4 = f"{RR}/{T}"
AP = "t4_r4_teacher_authority_and_r3_local_audit_payload_20260910.tar.gz"
A3 = "ENZYMECAGE_THREE_MODULE_T4_R3_TINY_REPORT_VALIDATOR_SIDECAR_CLOSURE_RETURN_LOCAL_AUDIT_" \
     "2026-09-10.md"
R2TITLE = "# T4-R2 asset-local overlap semantics / report / validator / three-file delivery final " \
          "correction"
R3TITLE = "## T4-R3 tiny report / validator / sidecar closure (2026-09-10)"
NOW = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def wr(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)
    print(f"written {os.path.relpath(p, R4)}: {os.path.getsize(p)} bytes sha256={sha(p)[:16]}...")


# -------------------------------------------------------------------------------------------------- README
HEAD = f"""# T4-R4 clean external closure order and three-file final delivery
TASK_ID={T}
CURRENT_PACKAGE_STAGE=T4-R4
CURRENT_DELIVERY_DATE_UTC={NOW}

R2/R3内容是继承背景，不是当前包身份：当前包是 T4-R4。本轮唯一变化是 clean closure 顺序、当前
README/AUTHORITY/FINAL_STATUS/COMMAND_LOG 与外置三文件（archive / .identity.txt / .validation.txt，
同一目录、同一 basename）。两个老师材料、V23 逻辑、预测、指标、重合、ECLIPSE 均逐字节冻结，见
`R3_BASELINE_FILE_IDENTITIES.csv`、`R3_TO_R4_CHANGED_FILES.csv` 与 `R3_CONTENT_NONMUTATION.json`。
T4 仍等待黄老师 A/B 裁定（草稿未发送、未上传）；T6 独立推进，不以本 T4 裁定为前置门。

## The three questions this round answers (prompt section 0)

A. **closure order fixed**. The R3 local audit showed a cycle: `scripts/r3_closure.py` asked the
   validator for `--require-validation-record` *before* the validation record could be written, so
   a genuinely fresh run could never pass and a resumed run could have leant on a leftover sidecar.
   `scripts/r4_clean_closure.py` removes the cycle: the pre-write gates may only require the
   archive and the identity, gate **P07 requires the record to be ABSENT**, the record is then
   written once with two pending markers, the post-write gates **Q01-Q08** run against a second
   fresh unpack, and only after all eight pass is the record rewritten once. A
   `--require-validation-record` flag does not exist anywhere in the R4 code.
B. **current identity in the README**. The header above is T4-R4. The R2 report below is demoted to
   an inherited-background section and the R3 section is relabelled HISTORICAL_SUPERSEDED, so this
   package can no longer read as R2 or R3 at the top.
C. **three physical files under a new TASK_ID** are produced for
   `{T}.tar.gz`, with the identity and the validation record both generated after the archive
   landed, from real `stat`/`sha256` of that landed archive and of fresh re-extractions of it.

## The order, as executed (prompt section 8)

```text
 1. six fresh-path gate                       logs/r4_freshgate.json   (nothing existed, nothing reused)
 2. copy the 64 R3 files byte-for-byte        R3_BASELINE_FILE_IDENTITIES.csv
 3. rerun V23 + its 8 mutations here          R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json
 4. rewrite README / AUTHORITY, this round    scripts/r4_p5_docs.py
 5. change table + nonmutation proof          R3_TO_R4_CHANGED_FILES.csv, R3_CONTENT_NONMUTATION.json
 6. closure order mutation test, 10 cases     R4_CLEAN_CLOSURE_ORDER_MUTATION_TEST.json
 7. MANIFEST.files + MANIFEST.sha256          scripts/r4_clean_closure.py --stage manifest
 8. content gates C01-C20 (+SUP21) run #1     scripts/r4_content_and_archive_validator.py --stage content
 9. in-archive FINAL_STATUS (11 lines, the external trio still pending)   --stage status
10. manifests regenerated, C01-C20 run #2     both must be all-PASS before any archive is created
11. ARCHIVE                                  tar, single root = TASK_ID, regular files only
12. fresh unpack U1 -> identity from the landed bytes
13. U1 gates C01-C20 + P01-P09 while NO record exists -> first atomic write (pending markers)
14. fresh unpack U2 -> Q01-Q08 over the three physical files -> one atomic rewrite (PASS_8_OF_8)
15. third independent read-only process (its command was pre-declared inside the record, so its
    exit code cannot be self-referential); stdout/stderr/exit land in logs/r4_final_readonly.log
```

## What was relocated instead of deleted (prompt section 4)

`scripts/r3_closure.py` and `scripts/r3_validator.py` are **HISTORICAL_SUPERSEDED**: they are the
defective closure order this round replaces. They were moved to `inherited_r3_closure_historical/`
unchanged (same SHA before and after the move, recorded in `R3_TO_R4_CHANGED_FILES.csv`), not
deleted, and they are not entry points of this package. The R4 entry points are

```text
scripts/r4_content_and_archive_validator.py   C01-C20 + SUP21, P01-P09, Q01-Q08, final read-only
scripts/r4_clean_closure.py                   manifest / status / identity / pack / chain / verify
scripts/r4_closure_mutation_test.py           the ten negative cases and the clean control
scripts/r4_v23_recheck.py                     section 6: V23 re-run + N1-N8 on the copied tree
```

## Reproduce it yourself

```text
python3 -B scripts/r4_content_and_archive_validator.py --stage content --root <unpacked TASK_ID>
python3 -B scripts/r4_clean_closure.py --stage verify --archive <path>.tar.gz
python3 -B scripts/r4_closure_mutation_test.py --tree <unpacked TASK_ID>
```

Every gate recomputes from live bytes, hashes or the AST; nothing reads a packaged claim, and no
gate is recorded with a constant. Boundary: no model, inference, training, GPU, normalisation,
scoring, overlap recompute, OOF, large corpus/template/raw-split read, network, pip, conda or git
operation; T6-named directories were skipped by name and never opened or stat-ed.

"""


def readme_stage():
    p = f"{R4}/README.md"
    body = rd(p)
    assert body.startswith(R2TITLE), "the inherited README no longer starts with the R2 heading"
    # the R2 header is demoted to an inherited-background section, its text kept verbatim below it
    body = body.replace(
        R2TITLE,
        "## INHERITED BACKGROUND (T4-R2, kept verbatim, no longer the identity of this package)\n"
        "\n" + R2TITLE.replace("# ", "## ", 1) + "\n"
        "\n> Everything in this section describes what T4-R2 delivered. T4-R3 and T4-R4 build on it "
        "without changing it.\n", 1)
    body = body.replace(
        R3TITLE,
        "## HISTORICAL_SUPERSEDED (T4-R3 closure order, replaced by T4-R4)\n"
        "\n" + R3TITLE + "\n"
        "\n> The closure order described in this section is superseded: its `scripts/r3_closure.py`\n"
        "> demanded a validation record before one could exist. Both scripts now live in\n"
        "> `inherited_r3_closure_historical/` byte-identical. The scientific content of R3 stands\n"
        "> unchanged and is still frozen byte-for-byte by T4-R4.\n", 1)
    wr(p, HEAD + body)


# ---------------------------------------------------------------------------- AUTHORITY_AND_SCOPE
AUTH = f"""# T4-R4 Authority and Scope

## Authority chain (verified read-only before any write)

```text
t4_r4_teacher_authority_and_r3_local_audit_payload_20260910.tar.gz
  bytes=9900 sha256=b82543960b6504bd7caf752ddd10e1da33e33d3b1dcbc7c167ba1bc70dc10769
  single root, 3 regular members, 0 unsafe entries, verified inside the R4 workspace
  -> TEACHER_REPLY_T4_INPUT_IDENTITY_AND_ORCHESTRATION_BOUNDARY_2026-09-08.md
       3627 / ca270af0419d7954ff8ddcb1b4304a04428ad893eeedfee604402f11004fdd34
  -> TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md
       5995 / 953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4
  -> {A3}
       9097 / 1fbf4c5926041d795183638e9b919a703fdae2545b97cee45f2a1c6151a53126
       verdict: PASS_CONTENT_REQUIRES_TINY_R4_CLEAN_EXTERNAL_CLOSURE_ORDER_AND_THREE_FILE_DELIVERY
enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910.tar.gz
  bytes=228792 sha256=e21127343f31c8e678e271ca8e7241a7a515c11d0ea9043c57b2535008d6611f
  64 regular files, 0 unsafe members, single root, 63/63 hashes and 64/64 coverage verified
  after extraction; it is the ONLY result input of this round
```

The teacher replies are the authority for the T4 questions; the R3 local audit is the authority for
what this round has to fix; the R3 archive is the only source of the returned content.

## What this round is allowed to change

R4 changes **the delivery layer only**. Scientific content, evidence tables, the validator logic and
the teacher materials are frozen byte-for-byte:

```text
permitted rewrites (6)    README.md, AUTHORITY_AND_SCOPE.md, COMMAND_LOG.txt, FINAL_STATUS.txt,
                          MANIFEST.files, MANIFEST.sha256
permitted additions       R3_BASELINE_FILE_IDENTITIES.csv, R3_TO_R4_CHANGED_FILES.csv,
                          R3_CONTENT_NONMUTATION.json,
                          R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json,
                          R4_CLEAN_CLOSURE_ORDER_MUTATION_TEST.json,
                          scripts/r4_content_and_archive_validator.py, scripts/r4_clean_closure.py,
                          scripts/r4_closure_mutation_test.py, scripts/r4_v23_recheck.py,
                          scripts/r4_p1_copy.py, scripts/r4_p5_docs.py,
                          scripts/r4_p5b_changed_sets.py
permitted relocation      scripts/r3_closure.py, scripts/r3_validator.py
                          -> inherited_r3_closure_historical/ (byte-identical, HISTORICAL_SUPERSEDED)
everything else           untouched; gate C04 proves 58 non-whitelist R3 files still hash exactly as
                          recorded in R3_BASELINE_FILE_IDENTITIES.csv
```

The three external files (`<archive>`, `<archive>.identity.txt`, `<archive>.validation.txt`) are the
subject of this round; they carry a new TASK_ID and are produced only after the archive landed.

## Hard boundaries honoured

No model entry, checkpoint loader, `single_smiles_v32` or ECLIPSE import/execution; no prediction,
fold, aggregation, scoring or OOF rerun; no re-read of large corpus/donor/templates/split assets to
regenerate overlap indexes; the two corrected teacher materials, `scripts/p6_validator.py` and the
R1/R2/R3 archives unmodified; no gold-driven deletion or re-ranking; no model role choice; the
teacher draft stays local, neutral on options A/B, unsent; nothing pushed or uploaded; no
credentials in any file; T6-named entries skipped by name, never opened or stat-ed; every Python
process ran with `PYTHONDONTWRITEBYTECODE=1` and `-B`; writes were limited to this task's workspace,
this return directory and the three same-basename files.

## One deviation inside this round, disclosed in full

At 06:56Z a pack command was started from a shell in which the TASK_ID variable had not been
exported, so its archive argument resolved to the return root plus `.tar.gz` with an empty name.
Two stray files came into existence under that wrong name and were removed again shortly after;
both the failed attempt and the cleanup are recorded in `COMMAND_LOG.txt` with their own exit codes
and output hashes. None of the three real delivery paths was ever written by that attempt, no gate
was ever run against the mis-named archive, and the section 8.3 refusal towards a pre-existing
validation record was never bypassed. Two defences were added afterwards and ship inside this
package: the pack stage refuses a non-canonical archive name and any delivery path that already
exists, and the final read-only command is declared in the validation record as the literal argv
that the checked process then compares with its own.

## Declared limits that R4 does not remove

R4 does not establish strict unseen blind evaluation. The current metrics remain
`VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY`; 13/39 pair, 15/18 parent and 16/39 product hits against
`corpus_v1.jsonl` keep the asset-local meaning fixed in T4-R2. Whether the model role is decided
from runtime blind performance or from a strict unseen blind benchmark is teacher question A/B and
remains `AWAITING_HUANG_TEACHER_REVIEW`. T4-R4 cannot make that decision, cannot send the draft, and
does not gate T6. The delivered package is only as trustworthy as the three files that must arrive
with it: an archive without its `.identity.txt` and `.validation.txt` is an incomplete return.
"""


def authority_stage():
    wr(f"{R4}/AUTHORITY_AND_SCOPE.md", AUTH)


# ------------------------------------------------------------------------------------- COMMAND_LOG
def command_log_stage():
    recs = [json.loads(l) for l in rd(f"{W}/logs/commands.jsonl").splitlines() if l.strip()]
    out = [f"# COMMAND_LOG - {T}",
           "",
           "Every line block below is a real execution recorded by logs/rc.sh (runlog) as it",
           "happened: UTC start, cwd, argv, exit code and the SHA256 of its own stdout and stderr.",
           "This is a projection of logs/commands.jsonl, not a narrative written afterwards.",
           "",
           f"records={len(recs)} generated_utc={NOW}",
           "coverage_note=the log is written into the package before the final manifest",
           "regeneration, the archive creation and the external closure; those later steps are",
           "recorded in the same workspace log and are cited field-by-field inside",
           "<archive>.validation.txt, which is the authoritative record of the closure itself.",
           ""]
    for i, r in enumerate(recs, 1):
        argv = r["argv"]
        out += [f"### [{i:04d}] phase={r.get('phase', 'n/a')}",
                f"utc_start={r['utc_start']}",
                f"cwd={r['cwd']}",
                "$ " + " ".join(argv),
                f"exit={r['exit']}",
                f"stdout_bytes={r['stdout_bytes']} stdout_sha256={r['stdout_sha256']}",
                f"stderr_bytes={r['stderr_bytes']} stderr_sha256={r['stderr_sha256']}",
                ""]
    root_cmds = sorted({r["argv"][0].split("/")[-1] for r in recs})
    out += ["## distinct programs used", "", "$ " + " ".join(root_cmds), "",
            "no model, no GPU, no network, no package manager, no git remote operation; the full",
            "argv of every single command is above.", "",
            "## limits of this log", "",
            "Only commands started through runlog appear above, and runlog records a command when it",
            "has already finished, so this file can never describe the steps that happen after it:",
            "the second manifest regeneration, the archive creation, the identity write, the",
            "pre-write gates, the first validation write, the post-write gates, the validation",
            "rewrite and the final read-only process.  Those are evidenced where they are produced -",
            "in the same workspace log (which keeps growing after this projection), in",
            "logs/validator_pwrite.json, logs/validator_postwrite.json, logs/r4_final_readonly.log",
            "and field-by-field inside <archive>.identity.txt and <archive>.validation.txt.",
            "A few read-only inspections and repeated script installations in an earlier window of",
            "this session were typed outside runlog; no SHA is invented for them, and their effect",
            "is verifiable from MANIFEST.sha256 and from the hashes carried by the two sidecars.", ""]
    wr(f"{R4}/COMMAND_LOG.txt", "\n".join(out) + "\n")
    print(f"commands recorded: {len(recs)}; programs: {root_cmds}")


if __name__ == "__main__":
    import sys
    todo = sys.argv[1:] or ["readme", "authority", "command_log"]
    if "readme" in todo:
        readme_stage()
    if "authority" in todo:
        authority_stage()
    if "command_log" in todo:
        command_log_stage()
