#!/usr/bin/env python3
"""T4-R3 p2/p4 (prompt sections 5 and 6): two surgical report-label fixes.

Idempotent: both target files are ALWAYS rebuilt from the pristine R2 copy in
immutable_r2/, then verified cell-by-cell / line-by-line, and the two required
correction records are emitted. No data table is recomputed.
PYTHONDONTWRITEBYTECODE=1 / python3 -B."""
import csv
import hashlib
import json
import os
import re
import sys
import time

T3 = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T3}"
R2D = f"{W}/immutable_r2"
R3 = f"/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries/{T3}"
BM = "T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv"
DRAFT = ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
         "DECISION_REQUEST_CORRECTED_DRAFT.md")
OLD_LABEL = "case_id, pollutant name, parent SMILES, task id"
NEW_LABEL = "case_id, parent_name, parent_smiles, parent_smiles_rdkit_canonical"
FOUR_FIELDS = ["case_id", "parent_name", "parent_smiles", "parent_smiles_rdkit_canonical"]
OLD_SENT = "在您裁定前，本草稿不发送、不上传；T6 不进入；无任何 git push。"
NEW_SENT = ("在您裁定前，本草稿不发送、不上传；本T4任务不进入T6、也不改变T6模型角色；"
            "T6按独立老师合同继续推进，不以本T4 A/B裁定为前置门；无任何git push。")


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


# digits that belong to task names (T4/T6) are not metrics: ignore digits after a letter
num_tokens = lambda s: sorted(re.findall(r"(?<![A-Za-z_])\d+(?:\.\d+)?", s))
problems = []

# =============================== section 5 ===============================
with open(f"{R2D}/{BM}", encoding="utf-8", newline="") as f:
    rd = csv.reader(f)
    head = next(rd)
    old_body = [r for r in rd if r]
col = head.index("attested_finding_or_value")
idx = [i for i, r in enumerate(old_body)
       if r[head.index("row_type")] == "DIMENSION"
       and r[head.index("boundary_dimension")] == "parent_only_input_identity"]
if len(idx) != 1:
    sys.exit(f"section5: target row not unique -> {idx}")
ti = idx[0]
before = old_body[ti][col]
if OLD_LABEL not in before:
    sys.exit("section5: erroneous label not present in the R2 original (unexpected)")
new_body = [list(r) for r in old_body]
after = before.replace(OLD_LABEL, NEW_LABEL)
new_body[ti][col] = after
with open(f"{R3}/{BM}", "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(head)
    w.writerows(new_body)
with open(f"{R3}/{BM}", encoding="utf-8", newline="") as f:
    rd = csv.reader(f)
    head2 = next(rd)
    got_body = [r for r in rd if r]
raw_new = open(f"{R3}/{BM}", encoding="utf-8").read()
diff_cells = [(i, j) for i in range(len(old_body)) for j in range(len(head))
              if old_body[i][j] != got_body[i][j]]
c5 = {
    "target_row_unique": len(idx) == 1,
    "corrected_cell_lists_all_four_expected_fields": all(c in got_body[ti][col] for c in FOUR_FIELDS),
    "fourth_field_is_parent_smiles_rdkit_canonical": "parent_smiles_rdkit_canonical" in got_body[ti][col],
    "literal_task_id_absent_from_whole_file": "task id" not in raw_new,
    "pollutant_name_label_absent_from_whole_file": "pollutant name" not in raw_new,
    "gold_columns_in_parent_csv_still_zero": "gold_columns_in_parent_csv=0" in got_body[ti][col],
    "exactly_one_cell_changed": len(diff_cells) == 1 and diff_cells[0] == (ti, col),
    "every_other_cell_identical_to_R2": all(
        got_body[i][j] == old_body[i][j] for i in range(len(old_body)) for j in range(len(head))
        if (i, j) != (ti, col)),
    "row_count_unchanged": len(got_body) == len(old_body) == 16,
    "column_names_unchanged": head2 == head,
    "other_columns_of_target_row_unchanged": all(
        got_body[ti][j] == old_body[ti][j] for j in range(len(head)) if j != col),
    "parent_csv_sha_note_unchanged": got_body[ti][head.index("notes")] == old_body[ti][head.index("notes")],
    "parent_csv_sha_still_quoted": "7b0e76d86c3bd33cc717c988e27c4f1aeba588be2c2ff48af665263382d67151" in raw_new,
}
bad5 = [k for k, v in c5.items() if v is not True]
if bad5:
    problems.append(("section5", bad5))
json.dump({
    "task": "T4-R3 section 5 - parent four-column factual label correction",
    "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "file": BM,
    "authority": "T4-R2 local audit section 10.1 (audit sha256=793530ef75efa137053c3d6de176508439dc2e1d74c19add1856db04cb9f0b33)",
    "target_selector": {"row_type": "DIMENSION", "boundary_dimension": "parent_only_input_identity",
                        "matched_rows": len(idx), "data_row_index": ti},
    "before": before,
    "after": after,
    "expected_four_fields": FOUR_FIELDS,
    "before_bytes": os.path.getsize(f"{R2D}/{BM}"),
    "before_sha256": sha(f"{R2D}/{BM}"),
    "prompt_section1_expected_before_sha256": "d4c05126fc600207d759480c53d4a90f40b7a86bc0eabd98d10b62a8d2db05ee",
    "after_bytes": os.path.getsize(f"{R3}/{BM}"),
    "after_sha256": sha(f"{R3}/{BM}"),
    "cells_changed": len(diff_cells),
    "checks": c5,
    "verified_by": "scripts/r3_validator.py V06/V07/V11/V17 recompute from live bytes",
    "scientific_result_changed": False,
}, open(f"{R3}/PARENT_FOUR_COLUMN_DESCRIPTION_CORRECTION.json", "w"), indent=2, ensure_ascii=False)

# =============================== section 6 ===============================
old_txt = open(f"{R2D}/{DRAFT}", encoding="utf-8").read()
old_lines = old_txt.split("\n")
trailing_nl = old_lines and old_lines[-1] == ""
if trailing_nl:
    old_lines = old_lines[:-1]
last_i = max(i for i, l in enumerate(old_lines) if l.strip())
if old_lines[last_i] != OLD_SENT:
    sys.exit(f"section6: R2 closing line mismatch -> {old_lines[last_i]!r}")
new_lines = list(old_lines)
new_lines[last_i] = NEW_SENT
open(f"{R3}/{DRAFT}", "w", encoding="utf-8").write("\n".join(new_lines) + ("\n" if trailing_nl else ""))

d = open(f"{R3}/{DRAFT}", encoding="utf-8").read()
c6 = {
    "all_lines_before_the_closing_line_byte_identical": "\n".join(new_lines[:last_i]) == "\n".join(old_lines[:last_i]),
    "old_blocking_sentence_absent": OLD_SENT not in d,
    "old_T6_not_entered_fragment_absent": "T6 不进入" not in d,
    "new_sentence_occurrences_exactly_one": d.count(NEW_SENT) == 1,
    "line_count_unchanged": len(d.rstrip("\n").split("\n")) == len(old_lines),
    "option_A_and_B_lines_verbatim": [l for l in d.split("\n") if l.startswith("- **选项")] == [l for l in old_lines if l.startswith("- **选项")],
    "option_lines_present": len([l for l in d.split("\n") if l.startswith("- **选项")]) == 2,
    "no_role_conclusion_line_verbatim": "本草稿**不作任何模型角色结论**，**不推荐选项 A 或选项 B**。" in d,
    "model_role_still_awaiting_teacher": "MODEL_ROLE_DECISION=AWAITING_HUANG_TEACHER_REVIEW" in d,
    "draft_status_marker_local_not_sent": "状态：**本地草稿 — 未发送 / 未上传。**" in d,
    "not_send_not_upload_kept": "本草稿不发送、不上传" in d,
    "no_git_push_kept": "无任何git push" in d,
    "t4_self_scope_stated": "本T4任务不进入T6、也不改变T6模型角色" in d,
    "t6_independence_stated": "T6按独立老师合同继续推进，不以本T4 A/B裁定为前置门" in d,
    "metric_number_tokens_outside_task_names_unchanged": num_tokens(d) == num_tokens(old_txt),
    "t6_only_appears_in_the_new_closing_sentence": [i + 1 for i, l in enumerate(d.split("\n")) if "T6" in l] == [last_i + 1],
}
bad6 = [k for k, v in c6.items() if v is not True]
if bad6:
    problems.append(("section6", bad6))
A = f"{W}/immutable_authority/t4_r3_teacher_authority_and_r2_local_audit_payload_20260910"
T0908 = f"{A}/TEACHER_REPLY_T4_INPUT_IDENTITY_AND_ORCHESTRATION_BOUNDARY_2026-09-08.md"
t0908 = open(T0908, encoding="utf-8").read().splitlines()
json.dump({
    "task": "T4-R3 section 6 - T4 must not be worded as blocking the independent T6",
    "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "file": DRAFT,
    "authority": "T4-R2 local audit section 10.2 + teacher reply 2026-09-08 (sha256=%s)" % sha(T0908),
    "before": OLD_SENT,
    "after": NEW_SENT,
    "before_bytes": os.path.getsize(f"{R2D}/{DRAFT}"),
    "before_sha256": sha(f"{R2D}/{DRAFT}"),
    "prompt_section1_expected_before_sha256": "a791d0492687bfac7921060cfdee8ec516334f460054912d53f9d27f32742da5",
    "after_bytes": os.path.getsize(f"{R3}/{DRAFT}"),
    "after_sha256": sha(f"{R3}/{DRAFT}"),
    "line_number_replaced_1based": last_i + 1,
    "teacher_0908_original_facts_quoted_verbatim": [l.strip() for l in t0908
                                                    if "T2C / T2D / T3 / T6" in l and ("不必等" in l or "阻塞" in l)],
    "consistency": "the replacement keeps T4's own scope (this task does not enter T6 and does not pick the T6 model "
                   "role) while stating that T6 proceeds under its own teacher contract; this matches the 2026-09-08 "
                   "reply, which lists T2C/T2D/T3/T6 as not waiting for T4 and not blocked by that reply",
    "checks": c6,
    "verified_by": "scripts/r3_validator.py V08/V09/V10/V11/V20/V17 recompute from live bytes",
    "scientific_result_changed": False,
}, open(f"{R3}/T4_T6_INDEPENDENCE_WORDING_CORRECTION.json", "w"), indent=2, ensure_ascii=False)

print("section5 cells changed:", len(diff_cells), "| failing checks:", bad5 if bad5 else "none")
print("section6 line", last_i + 1, "| failing checks:", bad6 if bad6 else "none")
print("numeric tokens preserved:", c6["metric_number_tokens_outside_task_names_unchanged"],
      f"({len(num_tokens(d))} tokens)")
json.dump({"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "problems": problems,
           "status": "OK" if not problems else "FAILED"},
          open(f"{W}/logs/r3_p2_p3_fixes.json", "w"), indent=2, ensure_ascii=False)
print("PROBLEMS:", problems if problems else "none")
sys.exit(1 if problems else 0)
