#!/usr/bin/env python3
"""T4-R3 section 7.1: prove that the corrected V23 fold6/fold8 gate really bites.

Each negative case N1-N8 is built in its OWN fresh /tmp copy of the return dir, executed as
a subprocess, and recorded with exit code + measured V23 verdict + failed sub-check names +
stdout/stderr SHA256.  Afterwards the unmodified artefact must PASS V23 and the source scan
must be clean.  Nothing here is hand-filled: a case counts as detected only if the child
process exits non-zero or reports verdict FAIL.

  --root DIR      return dir under test (live RETURN_DIR or a fresh unpack)
  --json OUT      write the evidence record (omit for a read-only re-check)
  --keep          do not delete the per-case temp dirs

PYTHONDONTWRITEBYTECODE=1 / python3 -B; no model, no network, no scoring, no writes to DIR."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

FOLD6 = "b17ba7ae787c832faa3bfb0d452a46a24213bdd1a3203cca033628392d18d09f"
FOLD8 = "ecdd54c591cb0ff415db22e5791493356ef195cc5e0b96b4e0d6977fb90fe918"
CFG6 = "0065ebcc324b0333e30437e64ffe66e8e5cb6edc8e2ac751d38f58cd4c1d8a9e"
CFG8 = "56d8b33211a5147a905577afc7da1e006d65b5ec845f2620fe43f72837ffe0ca"
II = "INPUT_IDENTITIES.csv"
DRAFT = ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
         "DECISION_REQUEST_CORRECTED_DRAFT.md")
# The always-true construct that section 11 of the R2 audit found, rebuilt by concatenation
# so that this harness source itself stays free of that literal text.
TAUTOLOGY = "or" + " True"


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def wr(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def sub_char(s, idx, to):
    return s[:idx] + to + s[idx + 1:]


def copy_root(src, dst):
    n = 0
    for root_, dirs, fs in os.walk(src):
        rel = os.path.relpath(root_, src)
        d = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(d, exist_ok=True)
        for fn in fs:
            shutil.copy2(os.path.join(root_, fn), os.path.join(d, fn))
            n += 1
    return n


# ---------------------------------------------------------------- mutations
def m_n1(R):
    p = f"{R}/{II}"
    keep = [l for l in rd(p).splitlines() if "actual_identity_fold6_split_bbd.json" not in l]
    wr(p, "\n".join(keep) + "\n")
    return ("fold6 citation row deleted from INPUT_IDENTITIES.csv",
            "exactly_one_citation_row_per_gated_fold")


def m_n2(R):
    p = f"{R}/{II}"
    txt = rd(p)
    assert FOLD6 in txt
    wr(p, txt.replace(FOLD6, sub_char(FOLD6, 40, "1"), 1))
    return ("fold6 live_sha256 changed by one hex character",
            "fold6_live_sha256_equals_actual_split_sha")


def m_n3(R):
    p = f"{R}/{II}"
    txt = rd(p)
    assert FOLD8 in txt
    wr(p, txt.replace(FOLD8, CFG8, 1))
    return ("fold8 live_sha256 replaced by the fold8 eclipse/config.json SHA (prefix %s)" % CFG8[:8],
            "fold8_live_sha256_equals_actual_split_sha")


def m_n4(R):
    p = f"{R}/{II}"
    txt = rd(p)
    line = [l for l in txt.splitlines() if "actual_identity_fold6_split_bbd.json" in l][0]
    assert "ACTUAL_SPLIT_SHA_FROM_FROZEN_RECORD" in line
    wr(p, txt.replace(line, line.replace("ACTUAL_SPLIT_SHA_FROM_FROZEN_RECORD", "VERIFIED"), 1))
    return ("fold6 row status downgraded to an ordinary VERIFIED",
            "fold6_row_status_is_actual_split_sha_from_frozen_record")


def m_n5(R):
    p = f"{R}/README.md"
    txt = rd(p)
    claim = f"fold6 split_bbd.json sha256={CFG6} is the fold6 split identity used by this delivery.\n"
    wr(p, txt + "\n" + claim)
    return ("README claims the fold6 config SHA as the fold6 split SHA",
            "fold6_config_sha_prefix_absent_from_readme")


def m_n6(R):
    p = f"{R}/{DRAFT}"
    txt = rd(p)
    claim = f"fold8 的实际 split SHA 为 {CFG8}。\n"
    wr(p, txt + "\n" + claim)
    return ("teacher draft claims the fold8 config SHA as the fold8 split SHA",
            "fold8_config_sha_prefix_absent_from_teacher_draft")


def m_n7(R):
    p = f"{R}/README.md"
    txt = rd(p)
    assert FOLD6 in txt
    wr(p, txt.replace(FOLD6, "", 1))
    return "one actual split SHA removed from README", "readme_quotes_fold6_actual_split_sha_verbatim"


V23CALL = "ok = len(sub) >= 24 and all(v is True for v in sub.values())"


def m_n8(R, tmp):
    src = f"{R}/scripts/p6_validator.py"
    txt = rd(src)
    assert V23CALL in txt, "V23 conjunction line not found"
    dst = f"{tmp}/scripts/p6_validator.py"
    assert os.path.isfile(dst), "fresh copy of the validator is missing"
    wr(dst, txt.replace(V23CALL, V23CALL + " " + TAUTOLOGY, 1))
    return ("an always-true disjunction re-injected into the V23 conjunction "
            "(the exact construct the R2 local audit reported)", "always_true_disjunction")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--json", default="")
    ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()
    R = os.path.abspath(a.root)
    val = f"{R}/scripts/p6_validator.py"
    scan = f"{R}/scripts/r3_validator.py"
    base = tempfile.mkdtemp(prefix="t4r3_mut_", dir="/tmp")
    cases, t0 = [], time.time()

    def run(cmd):
        p = subprocess.run(cmd, capture_output=True, text=True)
        payload = p.stdout + p.stderr
        j = [l for l in p.stdout.strip().split("\n") if l and l.startswith("{")]
        try:
            parsed = json.loads(j[-1]) if j else {}
        except ValueError:
            parsed = {"unparsed": payload[:200]}
        return p.returncode, parsed, hashlib.sha256(p.stdout.encode()).hexdigest(), \
            hashlib.sha256(p.stderr.encode()).hexdigest()

    def gate_case(tag, desc, expect, kind, root, extra=""):
        if kind == "v23":
            cmd = [sys.executable, "-B", f"{root}/scripts/p6_validator.py", "--root", root, "--v23-only"]
        else:
            cmd = [sys.executable, "-B", scan, "--scan-source", extra]
        code, parsed, so, se = run(cmd)
        verdict = parsed.get("verdict", "NO_VERDICT")
        failed = sorted(parsed.get("failed_subchecks", [])
                        or [f[0] for f in parsed.get("findings", [])])
        detected = code != 0 or verdict == "FAIL"
        cases.append({"id": tag, "description": desc, "expected_first_failing_check": expect,
                      "mechanism": "V23 fold gate" if kind == "v23" else "V12 source scan",
                      "command": re.sub(base + r"/[^ ]*", "<fresh_temp_copy>", " ".join(cmd)),
                      "exit_code": code, "verdict": verdict, "failing_checks_observed": failed,
                      "expected_check_observed": expect in failed,
                      "stdout_sha256": so, "stderr_sha256": se,
                      "subcheck_count_evaluated": parsed.get("subcheck_count",
                                                             parsed.get("finding_count")),
                      "isolated_temp_copy": (os.path.basename(root) if kind == "v23"
                                             else os.path.basename(os.path.dirname(extra))),
                      "detected": detected})
        print(f"{tag}: detected={detected} exit={code} verdict={verdict} failed={failed[:3]}")

    for tag, fn in (("N1", m_n1), ("N2", m_n2), ("N3", m_n3), ("N4", m_n4),
                    ("N5", m_n5), ("N6", m_n6), ("N7", m_n7)):
        tmp = tempfile.mkdtemp(prefix=f"t4r3_{tag}_", dir=base)
        copy_root(R, tmp)
        desc, expect = fn(tmp)
        gate_case(tag, desc, expect, "v23", tmp)
        if not a.keep:
            shutil.rmtree(tmp, ignore_errors=True)

    # N8: static scan must reject a re-injected always-true construct
    tmp = tempfile.mkdtemp(prefix="t4r3_N8_", dir=base)
    copy_root(R, tmp)
    desc, expect = m_n8(R, tmp)
    gate_case("N8", desc, expect, "scan", tmp, extra=f"{tmp}/scripts/p6_validator.py")
    # supplementary: the mutated gate would wrongly pass on the N2-broken root
    broken = tempfile.mkdtemp(prefix="t4r3_N8b_", dir=base)
    copy_root(R, broken)
    m_n2(broken)
    wr(f"{broken}/scripts/p6_validator.py", rd(val).replace(V23CALL, V23CALL + " " + TAUTOLOGY, 1))
    code_b, parsed_b, so_b, se_b = run([sys.executable, "-B", f"{broken}/scripts/p6_validator.py",
                                        "--root", broken, "--v23-only"])
    tautology_bypass = {"command": f"python3 -B <mutated>/scripts/p6_validator.py --root <broken N2 copy> --v23-only",
                        "exit_code": code_b, "verdict": parsed_b.get("verdict"),
                        "note": ("a V23 carrying the injected always-true term reports PASS even though the "
                                 "fold6 live SHA is wrong - this is why section 7 requires the V12 source scan "
                                 "in addition to the runtime gate"),
                        "stdout_sha256": so_b, "stderr_sha256": se_b}
    if not a.keep:
        shutil.rmtree(tmp, ignore_errors=True)
        shutil.rmtree(broken, ignore_errors=True)

    # clean artefact: live V23 gate + clean source scan
    code_c, parsed_c, so_c, se_c = run([sys.executable, "-B", val, "--root", R, "--v23-only"])
    code_s, parsed_s, so_s, se_s = run([sys.executable, "-B", scan, "--scan-source", val])
    clean = {"command": f"python3 -B scripts/p6_validator.py --root {os.path.basename(R)} --v23-only",
             "exit_code": code_c, "verdict": parsed_c.get("verdict"),
             "subcheck_count": parsed_c.get("subcheck_count"),
             "failed_subchecks": parsed_c.get("failed_subchecks"),
             "stdout_sha256": so_c, "stderr_sha256": se_c,
             "source_scan": {"command": f"python3 -B scripts/r3_validator.py --scan-source "
                                        f"{os.path.basename(val)}", "exit_code": code_s,
                             "verdict": parsed_s.get("verdict"), "findings": parsed_s.get("findings"),
                             "stdout_sha256": so_s, "stderr_sha256": se_s}}
    detected = [c for c in cases if c["detected"]]
    out = {
        "task": "T4-R3 section 7.1 - V23 fold6/fold8 hard gate mutation proof",
        "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "root_under_test": R,
        "validator_under_test": "scripts/p6_validator.py",
        "validator_source_sha256": sha(val),
        "scanner_source_sha256": sha(scan),
        "method": ("each case runs in its own fresh /tmp copy of the return dir; the V23 gate is invoked as "
                   "'python3 -B <copy>/scripts/p6_validator.py --root <copy> --v23-only' which prints one "
                   "JSON line and writes nothing; N8 instead runs the V12 scanner over a mutated validator "
                   "source; the unmodified artefact is executed last"),
        "red_lines": "no model, no inference, no rescoring, no overlap recompute, no network, no write to the "
                     "return dir under test",
        "cases": cases,
        "tautology_bypass_demonstration": tautology_bypass,
        "clean_unmodified_artefact": clean,
        "summary": {"total": len(cases), "detected": len(detected),
                    "all_mutations_detected": len(cases) == 8 and len(detected) == 8,
                    "expected_check_observed_in_every_case": all(c["expected_check_observed"] for c in cases),
                    "clean_v23_pass": code_c == 0 and parsed_c.get("verdict") == "PASS",
                    "clean_source_scan_pass": code_s == 0 and parsed_s.get("verdict") == "PASS",
                    "wall_seconds": round(time.time() - t0, 2)},
    }
    if a.json:
        wr(a.json, json.dumps(out, indent=2, ensure_ascii=False) + "\n")
    if not a.keep:
        shutil.rmtree(base, ignore_errors=True)
    s = out["summary"]
    ok = (s["all_mutations_detected"] and s["clean_v23_pass"] and s["clean_source_scan_pass"]
          and s["expected_check_observed_in_every_case"])
    print(json.dumps({"harness": "r3_mutation_test", "detected": s["detected"], "total": s["total"],
                      "clean_pass": s["clean_v23_pass"], "scan_pass": s["clean_source_scan_pass"],
                      "exit": 0 if ok else 1}, sort_keys=True))
    sys.exit(0 if ok else 1)


main()
