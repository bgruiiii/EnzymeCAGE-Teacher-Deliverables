#!/usr/bin/env python3
"""T4-R4 section 6: prove the frozen V23 hard gate still bites on the copied tree.

The eight negative cases N1-N8 keep exactly the semantics they had in T4-R3: same mutation, same
expected first-failing sub-check, same mechanism.  Each case is built in its OWN fresh /tmp copy of
the tree under test and executed as a subprocess; a case counts as detected only when the child
exits non-zero or reports verdict FAIL.  scripts/p6_validator.py itself is never modified: the
re-injected always-true construct of case N8 lives only in a throw-away copy.

  --root DIR   tree under test (live RETURN_DIR or a fresh unpack of the landed archive)
  --json OUT   write the R4 evidence record (omit for a read-only re-check)
  --keep       keep the per-case temp directories

PYTHONDONTWRITEBYTECODE=1 / python3 -B; no model, no network, no scoring, no write into DIR."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

FOLD6 = "b17ba7ae787c832faa3bfb0d452a46a24213bdd1a3203cca033628392d18d09f"
FOLD8 = "ecdd54c591cb0ff415db22e5791493356ef195cc5e0b96b4e0d6977fb90fe918"
CFG6 = "0065ebcc324b0333e30437e64ffe66e8e5cb6edc8e2ac751d38f58cd4c1d8a9e"
CFG8 = "56d8b33211a5147a905577afc7da1e006d65b5ec845f2620fe43f72837ffe0ca"
II = "INPUT_IDENTITIES.csv"
DRAFT = ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
         "DECISION_REQUEST_CORRECTED_DRAFT.md")
R3_JSON = "V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json"
OUT_JSON = "R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json"
SCANNER = "scripts/r4_content_and_archive_validator.py"
# the always-true construct reported by the R2 audit, rebuilt by concatenation so that this file
# contains no literal copy of it
TAUTOLOGY = "or" + " True"
V23CALL = "ok = len(sub) >= 24 and all(v is True for v in sub.values())"


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def wr(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def sub_char(s, idx, to):
    return s[:idx] + to + s[idx + 1:]


def copy_root(src, dst):
    n = 0
    for root_, dirs, fs in os.walk(src):
        rel = os.path.relpath(root_, src)
        d = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(d, exist_ok=True)
        for fn in fs:
            shutil.copy2(os.path.join(root_, fn), os.path.join(d, fn))
            n += 1
    return n


# ---------------------------------------------------------------- the eight mutations (unchanged semantics)
def m_n1(R):
    p = f"{R}/{II}"
    keep = [l for l in rd(p).splitlines() if "actual_identity_fold6_split_bbd.json" not in l]
    wr(p, "\n".join(keep) + "\n")
    return ("fold6 citation row deleted from INPUT_IDENTITIES.csv",
            "exactly_one_citation_row_per_gated_fold")


def m_n2(R):
    p = f"{R}/{II}"
    txt = rd(p)
    assert FOLD6 in txt
    wr(p, txt.replace(FOLD6, sub_char(FOLD6, 40, "1"), 1))
    return ("fold6 live_sha256 changed by one hex character",
            "fold6_live_sha256_equals_actual_split_sha")


def m_n3(R):
    p = f"{R}/{II}"
    txt = rd(p)
    assert FOLD8 in txt
    wr(p, txt.replace(FOLD8, CFG8, 1))
    return ("fold8 live_sha256 replaced by the fold8 eclipse/config.json SHA (prefix %s)" % CFG8[:8],
            "fold8_live_sha256_equals_actual_split_sha")


def m_n4(R):
    p = f"{R}/{II}"
    txt = rd(p)
    line = [l for l in txt.splitlines() if "actual_identity_fold6_split_bbd.json" in l][0]
    assert "ACTUAL_SPLIT_SHA_FROM_FROZEN_RECORD" in line
    wr(p, txt.replace(line, line.replace("ACTUAL_SPLIT_SHA_FROM_FROZEN_RECORD", "VERIFIED"), 1))
    return ("fold6 row status downgraded to an ordinary VERIFIED",
            "fold6_row_status_is_actual_split_sha_from_frozen_record")


def m_n5(R):
    p = f"{R}/README.md"
    txt = rd(p)
    claim = f"fold6 split_bbd.json sha256={CFG6} is the fold6 split identity used by this delivery.\n"
    wr(p, txt + "\n" + claim)
    return ("README claims the fold6 config SHA as the fold6 split SHA",
            "fold6_config_sha_prefix_absent_from_readme")


def m_n6(R):
    p = f"{R}/{DRAFT}"
    txt = rd(p)
    claim = f"fold8 的实际 split SHA 为 {CFG8}。\n"
    wr(p, txt + "\n" + claim)
    return ("teacher draft claims the fold8 config SHA as the fold8 split SHA",
            "fold8_config_sha_prefix_absent_from_teacher_draft")


def m_n7(R):
    p = f"{R}/README.md"
    txt = rd(p)
    assert FOLD6 in txt
    wr(p, txt.replace(FOLD6, "", 1))
    return "one actual split SHA removed from README", "readme_quotes_fold6_actual_split_sha_verbatim"


def m_n8(R, tmp):
    src = f"{R}/scripts/p6_validator.py"
    txt = rd(src)
    assert V23CALL in txt, "the V23 conjunction line is not present in the validator under test"
    dst = f"{tmp}/scripts/p6_validator.py"
    assert os.path.isfile(dst), "fresh copy of the validator is missing"
    wr(dst, txt.replace(V23CALL, V23CALL + " " + TAUTOLOGY, 1))
    return ("an always-true disjunction re-injected into the V23 conjunction "
            "(the exact construct the R2 local audit reported)", "always_true_disjunction")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--json", default="")
    ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()
    R = os.path.abspath(a.root)
    val = f"{R}/scripts/p6_validator.py"
    scan = f"{R}/{SCANNER}"
    base = tempfile.mkdtemp(prefix="t4r4_v23_", dir="/tmp")
    cases, t0 = [], time.time()

    def run(cmd):
        p = subprocess.run(cmd, capture_output=True, text=True)
        payload = p.stdout + p.stderr
        j = [l for l in p.stdout.strip().split("\n") if l and l.startswith("{")]
        try:
            parsed = json.loads(j[-1]) if j else {}
        except ValueError:
            parsed = {"unparsed": payload[:200]}
        return (p.returncode, parsed, hashlib.sha256(p.stdout.encode()).hexdigest(),
                hashlib.sha256(p.stderr.encode()).hexdigest())

    def gate_case(tag, desc, expect, kind, root, extra=""):
        if kind == "v23":
            cmd = [sys.executable, "-B", f"{root}/scripts/p6_validator.py", "--root", root, "--v23-only"]
        else:
            cmd = [sys.executable, "-B", scan, "--stage", "scan-source", "--scan-source", extra]
        code, parsed, so, se = run(cmd)
        verdict = parsed.get("verdict", parsed.get("status", "NO_VERDICT"))
        failed = sorted(parsed.get("failed_subchecks", [])
                        or [f[0] for f in parsed.get("findings", [])])
        detected = code != 0 or verdict == "FAIL"
        cases.append({"id": tag, "description": desc, "expected_first_failing_check": expect,
                      "mechanism": "V23 fold6/fold8 gate" if kind == "v23" else "always-true source scan",
                      "command": re.sub(base + r"/[^ ]*", "<fresh_temp_copy>", " ".join(cmd)),
                      "exit_code": code, "verdict": verdict, "failing_checks_observed": failed,
                      "expected_check_observed": expect in failed,
                      "stdout_sha256": so, "stderr_sha256": se,
                      "subcheck_count_evaluated": parsed.get("subcheck_count",
                                                             parsed.get("finding_count")),
                      "isolated_temp_copy": (os.path.basename(root) if kind == "v23"
                                             else os.path.basename(os.path.dirname(extra))),
                      "detected": detected})
        print(f"{tag}: detected={detected} exit={code} verdict={verdict} failed={failed[:3]}")

    for tag, fn in (("N1", m_n1), ("N2", m_n2), ("N3", m_n3), ("N4", m_n4),
                    ("N5", m_n5), ("N6", m_n6), ("N7", m_n7)):
        tmp = tempfile.mkdtemp(prefix=f"t4r4_{tag}_", dir=base)
        copy_root(R, tmp)
        desc, expect = fn(tmp)
        gate_case(tag, desc, expect, "v23", tmp)
        if not a.keep:
            shutil.rmtree(tmp, ignore_errors=True)

    # N8: the static scan must reject a re-injected always-true construct
    tmp = tempfile.mkdtemp(prefix="t4r4_N8_", dir=base)
    copy_root(R, tmp)
    desc, expect = m_n8(R, tmp)
    gate_case("N8", desc, expect, "scan", tmp, extra=f"{tmp}/scripts/p6_validator.py")

    # supplementary: show that the runtime gate alone would be fooled by that construct, which is
    # why the static scan is part of the same gate set
    broken = tempfile.mkdtemp(prefix="t4r4_N8b_", dir=base)
    copy_root(R, broken)
    m_n2(broken)
    wr(f"{broken}/scripts/p6_validator.py", rd(val).replace(V23CALL, V23CALL + " " + TAUTOLOGY, 1))
    code_b, parsed_b, so_b, se_b = run([sys.executable, "-B", f"{broken}/scripts/p6_validator.py",
                                        "--root", broken, "--v23-only"])
    tautology_bypass = {"command": "python3 -B <mutated copy>/scripts/p6_validator.py --root <broken N2 copy> --v23-only",
                        "exit_code": code_b, "verdict": parsed_b.get("verdict"),
                        "note": ("a V23 carrying the injected always-true term reports PASS even though "
                                 "the fold6 live SHA is wrong - this is why the static always-true scan "
                                 "exists next to the runtime gate"),
                        "stdout_sha256": so_b, "stderr_sha256": se_b}

    # clean artefact: live V23 gate over the unmodified tree + clean source scan of both checkers
    code_c, parsed_c, so_c, se_c = run([sys.executable, "-B", val, "--root", R, "--v23-only"])
    code_s, parsed_s, so_s, se_s = run([sys.executable, "-B", scan, "--stage", "scan-source",
                                        "--scan-source", val])
    clean = {"command": f"python3 -B scripts/p6_validator.py --root {os.path.basename(R)} --v23-only",
             "exit_code": code_c, "verdict": parsed_c.get("verdict"),
             "subcheck_count": parsed_c.get("subcheck_count"),
             "failed_subchecks": parsed_c.get("failed_subchecks"),
             "stdout_sha256": so_c, "stderr_sha256": se_c,
             "source_scan": {"command": f"python3 -B {SCANNER} --stage scan-source --scan-source "
                                        f"{os.path.basename(val)}", "exit_code": code_s,
                             "status": parsed_s.get("status"), "findings": parsed_s.get("findings"),
                             "stdout_sha256": so_s, "stderr_sha256": se_s}}

    # semantic equality with the R3 evidence, and the R3 artefact itself untouched
    r3p = f"{R}/{R3_JSON}"
    r3 = json.loads(rd(r3p)) if os.path.isfile(r3p) else {}
    key = lambda c: (c.get("id"), c.get("description"), c.get("expected_first_failing_check"))  # noqa: E731
    r3_cases = [key(c) for c in r3.get("cases", [])]
    r4_cases = [key(c) for c in cases]
    semantics = {"r3_evidence_file": R3_JSON,
                 "r3_evidence_sha256": sha(r3p) if os.path.isfile(r3p) else None,
                 "r3_evidence_byte_identical_to_r3_delivery":
                     r3.get("validator_source_sha256") == sha(val),
                 "case_ids_equal": [c[0] for c in r3_cases] == [c[0] for c in r4_cases],
                 "mutation_and_expected_check_equal": r3_cases == r4_cases,
                 "r3_subcheck_count": r3.get("clean_unmodified_artefact", {}).get("subcheck_count"),
                 "r4_subcheck_count": parsed_c.get("subcheck_count")}

    detected = [c for c in cases if c["detected"]]
    out = {"task": "T4-R4 section 6 - V23 preservation and 8-mutation recheck on the copied tree",
           "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "root_under_test": R,
           "validator_under_test": "scripts/p6_validator.py",
           "validator_source_sha256": sha(val),
           "scanner_source_sha256": sha(scan),
           "method": ("each case runs in its own fresh /tmp copy of the tree under test; the V23 gate is "
                      "invoked as 'python3 -B <copy>/scripts/p6_validator.py --root <copy> --v23-only', "
                      "which prints one JSON line and writes nothing; N8 runs the always-true scanner over "
                      "a mutated copy; the unmodified artefact is executed last"),
           "red_lines": "no model, no inference, no rescoring, no overlap recompute, no network, no write "
                        "into the tree under test; scripts/p6_validator.py is never edited",
           "cases": cases,
           "tautology_bypass_demonstration": tautology_bypass,
           "clean_unmodified_artefact": clean,
           "v23_semantics_vs_r3": semantics,
           "summary": {"total": len(cases), "detected": len(detected),
                       "all_mutations_detected": len(cases) == 8 and len(detected) == 8,
                       "expected_check_observed_in_every_case":
                           all(c["expected_check_observed"] for c in cases),
                       "clean_v23_pass": code_c == 0 and parsed_c.get("verdict") == "PASS"
                           and parsed_c.get("subcheck_count") == 25,
                       "clean_source_scan_pass": code_s == 0 and parsed_s.get("status") == "PASS",
                       "semantics_preserved_from_r3": bool(semantics["case_ids_equal"])
                           and bool(semantics["mutation_and_expected_check_equal"])
                           and semantics["r3_subcheck_count"] == semantics["r4_subcheck_count"] == 25,
                       "wall_seconds": round(time.time() - t0, 2)},
           "evidence_file_name": OUT_JSON}
    if a.json:
        os.makedirs(os.path.dirname(os.path.abspath(a.json)), exist_ok=True)
        wr(a.json, json.dumps(out, indent=2, ensure_ascii=False) + "\n")
    if not a.keep:
        shutil.rmtree(base, ignore_errors=True)
    s = out["summary"]
    ok = (s["all_mutations_detected"] and s["clean_v23_pass"] and s["clean_source_scan_pass"]
          and s["expected_check_observed_in_every_case"] and s["semantics_preserved_from_r3"])
    print(json.dumps({"harness": "r4_v23_recheck", "detected": s["detected"], "total": s["total"],
                      "clean_pass": s["clean_v23_pass"], "scan_pass": s["clean_source_scan_pass"],
                      "semantics_preserved": s["semantics_preserved_from_r3"],
                      "exit": 0 if ok else 1}, sort_keys=True))
    sys.exit(0 if ok else 1)


main()
