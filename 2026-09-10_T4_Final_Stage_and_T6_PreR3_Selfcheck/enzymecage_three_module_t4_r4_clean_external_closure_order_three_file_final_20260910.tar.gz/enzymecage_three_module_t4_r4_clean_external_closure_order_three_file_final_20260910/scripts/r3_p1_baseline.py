#!/usr/bin/env python3
"""T4-R3 p1 (prompt section 4): copy the R2 single-root content into the fresh R3
RETURN_DIR as an immutable baseline, record all 51 regular-file identities BEFORE any
modification, then read-only re-verify the R2-accepted anchors. No derivation is redone.
PYTHONDONTWRITEBYTECODE=1 / python3 -B."""
import csv
import hashlib
import json
import os
import shutil
import sys
import time

T3 = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T3}"
R2D = f"{W}/immutable_r2"
R3 = f"{RR}/{T3}"
LOG = f"{W}/logs"


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rows(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def I(v):
    try:
        return int(str(v).strip())
    except ValueError:
        return 0


fails = []


def anchor(name, got, want):
    ok = str(got) == str(want)
    if not ok:
        fails.append((name, got, want))
    print(f"{'ok ' if ok else 'FAIL'} {name}: {got} (want {want})")


# ---- copy R2 content (regular files only, same relative layout) ----
if os.path.exists(R3):
    sys.exit(f"STOP: {R3} already exists (section 2 fresh gate)")
os.makedirs(R3)
n = 0
for root_, _, fs in os.walk(R2D):
    rel = os.path.relpath(root_, R2D)
    dst_dir = R3 if rel == "." else os.path.join(R3, rel)
    os.makedirs(dst_dir, exist_ok=True)
    for fn in fs:
        shutil.copy2(os.path.join(root_, fn), os.path.join(dst_dir, fn))
        n += 1
print(f"copied {n} regular files from immutable_r2 -> RETURN_DIR")
assert n == 51, f"expected 51 R2 regular files, copied {n}"

# ---- record baseline identities BEFORE any modification ----
walk = sorted({os.path.relpath(os.path.join(r, f), R2D) for r, _, fs in os.walk(R2D) for f in fs})
r2man = {}
for line in open(f"{R2D}/MANIFEST.sha256", encoding="utf-8"):
    if line.strip():
        s, rel = line.rstrip("\n").split("  ", 1)
        r2man[rel] = s
with open(f"{R3}/R2_BASELINE_FILE_IDENTITIES.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["relative_path", "bytes", "live_sha256_after_copy", "r2_manifest_sha256",
                "copy_matches_r2_archive", "modified_by_r3_before_this_record"])
    for rel in walk:
        p = os.path.join(R2D, rel)
        q = os.path.join(R3, rel)
        w.writerow([rel, os.path.getsize(p), sha(p), r2man.get(rel, "NOT_IN_SHA_LIST(excluded self)"),
                    "TRUE" if sha(p) == sha(q) else "FALSE", "FALSE"])
same = [rel for rel in walk if sha(os.path.join(R2D, rel)) != sha(os.path.join(R3, rel))]
anchor("baseline copied files identical to R2", f"{len(walk) - len(same)}/51", "51/51")
anchor("baseline rows recorded", sum(1 for _ in open(f"{R3}/R2_BASELINE_FILE_IDENTITIES.csv")) - 1, 51)

# ---- read-only anchor recheck (section 4) ----
rx = rows(f"{R3}/DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv")
pr = rows(f"{R3}/DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv")
anchor("reaction BY_ASSET rows", len(rx), 312)
anchor("reaction BY_ASSET unique keys",
       len({(r["case_id"], r["reaction_id"], r["asset_name"]) for r in rx}), 312)
anchor("product BY_ASSET rows", len(pr), 312)
anchor("product BY_ASSET unique keys",
       len({(r["case_id"], r["line_no_products_jsonl"], r["asset_name"]) for r in pr}), 312)
anchor("reaction global rows", len(rows(f"{R3}/DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv")), 39)
anchor("product global rows", len(rows(f"{R3}/DEPENDING_39_GOLD_PRODUCT_GLOBAL_LAYERED_STATUS.csv")), 39)

corp = [r for r in rx if r["asset_name"] == "corpus_v1.jsonl"]
anchor("corpus exact pair seen", sum(1 for r in corp if I(r["exact_parent_product_pair_hit"])), 13)
anchor("corpus exact pair denominator", len(corp), 39)
pa = rows(f"{R3}/inherited_r1/DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv")
pcorp = [r for r in pa if r["asset_name"] == "corpus_v1.jsonl"]
anchor("parent seen", sum(1 for r in pcorp if I(r["reactant_side_canonical_hit"])), 15)
anchor("parent denominator", len(pcorp), 18)
prc = [r for r in pr if r["asset_name"] == "corpus_v1.jsonl"]
anchor("product seen", sum(1 for r in prc if I(r["product_side_hit"])), 16)
anchor("product denominator", len(prc), 39)

er = rows(f"{R3}/inherited_r1/ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv")
ep = rows(f"{R3}/inherited_r1/ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv")
eh = rows(f"{R3}/inherited_r1/ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv")
cs = {}
for r in er:
    cs[r["exact_status"]] = cs.get(r["exact_status"], 0) + 1
ps = {}
for r in ep:
    ps[r["parent_split_exposure"]] = ps.get(r["parent_split_exposure"], 0) + 1
anchor("eclipse reaction x fold", len(er), 390)
anchor("eclipse TRAIN/VAL/TEST/NONE",
       f"{cs.get('TRAIN')}/{cs.get('VAL')}/{cs.get('TEST')}/{cs.get('NONE')}", "190/35/25/140")
anchor("eclipse parent x fold", len(ep), 180)
anchor("eclipse parent TRAIN/VAL/TEST",
       f"{ps.get('TRAIN')}/{ps.get('VAL')}/{ps.get('TEST')}", "142/21/17")
anchor("eclipse hit cells", sum(I(r["fold_gold_product_hit"]) for r in eh), 113)
bm = "".join(json.dumps(r, ensure_ascii=False) for r in rows(f"{R3}/T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv"))
anchor("ECLIPSE_STRICT_OOF=false recorded", "ECLIPSE_STRICT_OOF=false" in bm or "OOF" in bm, True)
anchor("metrics file SHA unchanged", sha(f"{R3}/FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv"), sha(f"{R2D}/FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv"))
anchor("metrics file vs prompt section 1", sha(f"{R3}/FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv"),
       "75a50d517d25ef96aae8b35b67b8fb163788ba1b22fc8e93288bda002a138a15")
anchor("normalized SHA vs prompt section 1", sha(f"{R3}/DEPENDING_NORMALIZED_PREDICTIONS_CORRECTED.jsonl"),
       "6e52ada071c0b12d36aa8490bbdcc0b9928461861432ba1be5365764d30209e4")

res = {"stage": "r3_p1_baseline_and_anchor_recheck",
       "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
       "regular_files_copied": n,
       "baseline_identity_csv": "R2_BASELINE_FILE_IDENTITIES.csv",
       "failures": fails,
       "status": "R2_BASELINE_ACCEPTED" if not fails else "BLOCKED_R2_BASELINE_IDENTITY_OR_CONTENT_MISMATCH"}
json.dump(res, open(f"{LOG}/r3_p1_baseline.json", "w"), indent=2, ensure_ascii=False)
print("\nANCHOR FAILURES:", fails if fails else "none")
print("STATUS:", res["status"])
sys.exit(1 if fails else 0)
