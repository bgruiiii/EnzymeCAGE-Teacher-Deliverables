#!/usr/bin/env python3
"""T4-R4 section 9: ten corruptions of the external closure order, each really executed.

Every case gets its OWN isolated scenario directory under /tmp.  Inside it
scripts/r4_clean_closure.py runs the SAME chain() function that closes the real delivery: it copies
the tree, packs an archive, writes an identity, runs the pre-write gates, writes the validation
record, runs the post-write gates and (unless the order refuses earlier) rewrites the record.  The
only difference is one planted corruption, applied by a generated mutation script at a named step
of that very chain:

  N1 a validation record already exists before the first write   -> P07 FAIL, nothing written
  N2 the identity file is missing                               -> P05 + P08 FAIL
  N3 one hex character of the identity ARCHIVE_SHA256 is wrong  -> P05 FAIL
  N4 a frozen file is altered inside the archive                -> P03/P04/P05 + C-gate FAIL
  N5 the record is deleted after it was written                 -> Q01 + Q02 FAIL
  N6 one C gate line in the record is flipped to FAIL           -> Q05 FAIL
  N7 one P gate line is removed from the record                 -> Q05 FAIL
  N8 the record's RUN_ID is forged                              -> Q06 FAIL
  N9 the record cites the superseded R3 sidecar as evidence     -> Q07 FAIL
  N10 the post-write checker reuses a tree unpacked before the
      first write instead of a second fresh one                 -> Q08 FAIL

A case counts as detected only when the closure exits non-zero, the expected gate really reports
FAIL, and no PASS is claimed anywhere it should not be: cases that stop before the write leave no
record at all, and cases that stop after it keep the text that was written and get an appended
FAIL - never a rewritten PASS.  N1 additionally proves the pre-existing file is neither reused,
overwritten nor deleted, by comparing its SHA before and after.  The clean control (no corruption)
must start from "no validation record" and close completely.

PYTHONDONTWRITEBYTECODE=1 / python3 -B; no model, no network, no scoring; writes go only to the
scenario directories under /tmp plus the one --json evidence file.
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

T = "enzymecage_three_module_t4_r4_clean_external_closure_order_three_file_final_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R4 = f"{RR}/{T}"
CLOSURE = "scripts/r4_clean_closure.py"
OUT_JSON = "R4_CLEAN_CLOSURE_ORDER_MUTATION_TEST.json"
BM = "T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv"
R3SIDECAR = ("enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
             ".tar.gz.validation.txt")
PLANTED = "planted by mutation N1: a validation record left over from an earlier attempt\n"

MUT_HEAD = '''import hashlib, json, os, subprocess, sys
step, into = sys.argv[1], sys.argv[2]
T = "__TASK__"
arc = os.path.join(into, T + ".tar.gz")
IDP, VALP = arc + ".identity.txt", arc + ".validation.txt"
tree = os.path.join(into, "tree", T)
PLANTED = __PLANTED__


def rd(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def wr(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)


def repack():
    subprocess.run(["tar", "--numeric-owner", "--owner=0", "--group=0", "-czf", arc, "-C",
                    os.path.join(into, "tree"), T], check=True)


def note(k, v):
    p = os.path.join(into, "mutation_notes.json")
    d = json.loads(rd(p)) if os.path.isfile(p) else {}
    d[k] = v
    wr(p, json.dumps(d, sort_keys=True))


'''

CASES = [
    {"id": "N1", "step": "before_absence_check", "stale_u2": False,
     "description": "a validation record already exists before the first write",
     "expected": "P07 FAIL and BLOCKED_PREEXISTING_VALIDATION_SIDECAR; the existing record is kept "
                 "byte-identical and no new record is written",
     "expect_blocked": "BLOCKED_PREEXISTING_VALIDATION_SIDECAR", "expect_gates": ["P07"],
     "expect_any": [], "expect_record_written": False, "expect_record_state": "unmarked",
     "body": '''def apply():
    wr(VALP, PLANTED)
    note("planted_sha256", hashlib.sha256(PLANTED.encode()).hexdigest())


'''},
    {"id": "N2", "step": "before_absence_check", "stale_u2": False,
     "description": "the identity sidecar is missing when the pre-write gates run",
     "expected": "P05 and P08 FAIL, no record written",
     "expect_blocked": "BLOCKED_PREWRITE_GATES", "expect_gates": ["P05", "P08"],
     "expect_any": [], "expect_record_written": False, "expect_record_state": "absent",
     "body": '''def apply():
    os.remove(IDP)


'''},
    {"id": "N3", "step": "before_absence_check", "stale_u2": False,
     "description": "one hex character of the identity ARCHIVE_SHA256 is changed",
     "expected": "P05 FAIL, no record written",
     "expect_blocked": "BLOCKED_PREWRITE_GATES", "expect_gates": ["P05"],
     "expect_any": [], "expect_record_written": False, "expect_record_state": "absent",
     "body": '''def apply():
    txt = rd(IDP)
    line = [l for l in txt.splitlines() if l.startswith("ARCHIVE_SHA256=")][0]
    bad = line[:-1] + ("0" if line[-1] != "0" else "1")
    wr(IDP, txt.replace(line, bad, 1))
    note("identity_line_before", line)
    note("identity_line_after", bad)


'''},
    {"id": "N4", "step": "before_absence_check", "stale_u2": False,
     "description": "a frozen scientific file is altered inside the packed archive",
     "expected": "P02/P03/P04/P05 plus the content gate that pins that file FAIL",
     "expect_blocked": "BLOCKED_PREWRITE_GATES", "expect_gates": [],
     "expect_any": [["P02", "P03", "P04", "P05"], ["C05", "C19", "C20"]],
     "expect_record_written": False, "expect_record_state": "absent",
     "body": '''def apply():
    p = os.path.join(tree, "__BM__")
    lines = rd(p).split("\\n")
    lines[1] = lines[1].replace(",", ";", 1)
    wr(p, "\\n".join(lines))
    repack()


'''},
    {"id": "N5", "step": "after_first_write", "stale_u2": False,
     "description": "the record is deleted after it was written, before the post-write gates",
     "expected": "Q01 and Q02 FAIL; the record is re-created only as an explicit FAIL",
     "expect_blocked": "BLOCKED_POSTWRITE_GATES", "expect_gates": ["Q01", "Q02"],
     "expect_any": [], "expect_record_written": True, "expect_record_state": "fail",
     "body": '''def apply():
    os.remove(VALP)


'''},
    {"id": "N6", "step": "after_first_write", "stale_u2": False,
     "description": "one C gate line inside the record is flipped from PASS to FAIL",
     "expected": "Q05 FAIL", "expect_blocked": "BLOCKED_POSTWRITE_GATES",
     "expect_gates": ["Q05"], "expect_any": [], "expect_record_written": True,
     "expect_record_state": "fail",
     "body": '''def apply():
    txt = rd(VALP)
    wr(VALP, txt.replace("C01: PASS", "C01: FAIL", 1))


'''},
    {"id": "N7", "step": "after_first_write", "stale_u2": False,
     "description": "the P07 line is removed from the record",
     "expected": "Q05 FAIL (9 P lines required)", "expect_blocked": "BLOCKED_POSTWRITE_GATES",
     "expect_gates": ["Q05"], "expect_any": [], "expect_record_written": True,
     "expect_record_state": "fail",
     "body": '''def apply():
    keep = [l for l in rd(VALP).split("\\n") if not l.startswith("P07:")]
    wr(VALP, "\\n".join(keep))


'''},
    {"id": "N8", "step": "after_first_write", "stale_u2": False,
     "description": "the record's RUN_ID is forged so it no longer matches this run",
     "expected": "Q06 FAIL", "expect_blocked": "BLOCKED_POSTWRITE_GATES",
     "expect_gates": ["Q06"], "expect_any": [], "expect_record_written": True,
     "expect_record_state": "fail",
     "body": '''def apply():
    txt = rd(VALP)
    line = [l for l in txt.splitlines() if l.startswith("RUN_ID=")][0]
    wr(VALP, txt.replace(line, "RUN_ID=forged-run-id-not-this-run", 1))
    note("run_id_before", line)


'''},
    {"id": "N9", "step": "after_first_write", "stale_u2": False,
     "description": "the record cites the superseded R3 sidecar as current evidence",
     "expected": "Q07 FAIL", "expect_blocked": "BLOCKED_POSTWRITE_GATES",
     "expect_gates": ["Q07"], "expect_any": [], "expect_record_written": True,
     "expect_record_state": "fail",
     "body": '''def apply():
    with open(VALP, "a", encoding="utf-8") as f:
        f.write("PRIOR_ROUND_EVIDENCE=" + os.path.join("__RR__", "__R3SIDECAR__") + "\\n")


'''},
    {"id": "N10", "step": "", "stale_u2": True,
     "description": "the post-write checker runs on a tree unpacked BEFORE the first record write",
     "expected": "Q08 FAIL", "expect_blocked": "BLOCKED_POSTWRITE_GATES",
     "expect_gates": ["Q08"], "expect_any": [], "expect_record_written": True,
     "expect_record_state": "fail", "body": ""},
]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(p):
    with open(p, encoding="utf-8", errors="ignore") as f:
        return f.read()


def build_mutation(case):
    src = MUT_HEAD.replace("__TASK__", T).replace("__PLANTED__", repr(PLANTED))
    src += case["body"].replace("__BM__", BM).replace("__RR__", RR).replace("__R3SIDECAR__",
                                                                            R3SIDECAR)
    src += ("if step == %r:\n    apply()\n" % case["step"]) if case["step"] else ""
    return src


def record_state(valp):
    """what the record claims right now, read straight off the bytes on disk"""
    if not os.path.isfile(valp):
        return "absent"
    txt = rd(valp)
    if "POSTWRITE_STATUS=PASS_8_OF_8" in txt and "OVERALL: PASS" in txt:
        return "pass"
    if "OVERALL: FAIL" in txt:
        return "fail"
    if "POSTWRITE_STATUS=PENDING" in txt:
        return "pending"
    return "unmarked"


def run_case(case, tree_src, base, keep):
    into = os.path.join(base, case["id"])
    os.makedirs(into, exist_ok=True)
    valp = os.path.join(into, T + ".tar.gz.validation.txt")
    mpath = ""
    if case["body"]:
        # written beside, not inside, the scenario directory: simulate_stage wipes that directory and
        # rebuilds it, and copies this script in afterwards
        mpath = os.path.join(base, case["id"] + ".mutation.py")
        with open(mpath, "w", encoding="utf-8", newline="") as f:
            f.write(build_mutation(case))
    cmd = [sys.executable, "-B", f"{tree_src}/{CLOSURE}", "--stage", "simulate", "--into", into,
           "--tree-src", tree_src, "--until", "full"]
    cmd += ["--mutation", mpath] if mpath else []
    cmd += ["--stale-u2"] if case["stale_u2"] else []
    p = subprocess.run(cmd, capture_output=True, text=True, cwd=base)
    cj = os.path.join(into, "logs", "chain_result.json")
    res = json.loads(rd(cj)) if os.path.isfile(cj) else {}
    failed = list(res.get("gates_failed", []))
    obs = {
        "exit_code": p.returncode,
        "chain_status": res.get("status"),
        "blocked_reason": res.get("blocked"),
        "p07_verdict_when_sidecar_existed": res.get("p07_verdict"),
        "gates_failed_observed": failed,
        "validation_written_by_this_run": res.get("validation_written_by_this_run"),
        "record_state_on_disk": record_state(valp),
        "run_id": res.get("run_id"),
        "stdout_sha256": hashlib.sha256(p.stdout.encode()).hexdigest(),
        "stderr_sha256": hashlib.sha256(p.stderr.encode()).hexdigest(),
    }
    exp_gates_ok = all(g in failed for g in case["expect_gates"])
    exp_any_ok = all(any(g in failed for g in grp) for grp in case["expect_any"])
    blocked_ok = res.get("blocked") == case["expect_blocked"]
    written_ok = res.get("validation_written_by_this_run") is case["expect_record_written"]
    state_ok = record_state(valp) == case["expect_record_state"]
    if case["id"] == "N1":
        notes = os.path.join(into, "mutation_notes.json")
        planted = json.loads(rd(notes)).get("planted_sha256") if os.path.isfile(notes) else None
        obs["pre_existing_record_untouched"] = (planted is not None and os.path.isfile(valp)
                                                and sha(valp) == planted)
        untouched_ok = obs["pre_existing_record_untouched"]
    else:
        untouched_ok = True
    detected = (p.returncode != 0 and exp_gates_ok and exp_any_ok and blocked_ok and written_ok
                and state_ok and untouched_ok)
    obs.update({"expected_gates_observed": exp_gates_ok, "expected_any_observed": exp_any_ok,
                "expected_blocked_reason_observed": blocked_ok,
                "expected_write_outcome_observed": written_ok,
                "expected_record_state_observed": state_ok,
                "no_illegal_pass_claim": "POSTWRITE_STATUS=PASS_8_OF_8" not in rd(valp)
                                         if os.path.isfile(valp) else True,
                "detected": detected})
    obs["command"] = "python3 -B scripts/r4_clean_closure.py --stage simulate --into <%s> " \
                     "--tree-src <tree> --until full%s%s" % (
                         case["id"], " --mutation <case>.mutation.py" if mpath else "",
                         " --stale-u2" if case["stale_u2"] else "")
    obs["scenario_directory"] = into
    obs["mutation_script_sha256"] = sha(mpath) if mpath else "none"
    print("%s: detected=%s exit=%d blocked=%s failed=%s record=%s%s"
          % (case["id"], detected, p.returncode, res.get("blocked"), failed[:6],
             obs["record_state_on_disk"],
             "" if detected else "\n   " + (p.stdout + p.stderr)[-1500:]))
    if not keep:
        shutil.rmtree(into, ignore_errors=True)
    return {"id": case["id"], "description": case["description"],
            "mechanism": "clean closure chain scripts/r4_clean_closure.py",
            "expected_outcome": case["expected"], "observed": obs, "detected": detected}


def run_clean_control(tree_src, base, keep):
    into = os.path.join(base, "clean_chain")
    os.makedirs(into, exist_ok=True)
    cmd = [sys.executable, "-B", f"{tree_src}/{CLOSURE}", "--stage", "simulate", "--into", into,
           "--tree-src", tree_src, "--until", "full"]
    t0 = time.time()
    p = subprocess.run(cmd, capture_output=True, text=True, cwd=base)
    cj = os.path.join(into, "logs", "chain_result.json")
    res = json.loads(rd(cj)) if os.path.isfile(cj) else {}
    valp = os.path.join(into, T + ".tar.gz.validation.txt")
    txt = rd(valp) if os.path.isfile(valp) else ""
    checks = {
        "started_with_no_validation_record": not res.get("strays_seen"),
        "all_pre_and_post_gates_passed": not res.get("gates_failed") and res.get("status") == "PASS",
        "record_written_once_and_rewritten_once": res.get("validation_written_by_this_run") is True
                                                  and "REWRITE_NOTE=" in txt,
        "pending_markers_replaced": "POSTWRITE_STATUS=PENDING" not in txt and "OVERALL=PENDING" not in txt,
        "final_status_pass": "POSTWRITE_STATUS=PASS_8_OF_8" in txt and "OVERALL: PASS" in txt,
        "final_readonly_check_passed": res.get("final_readonly_exit") == 0,
        "external_three_file_delivery_pass": "EXTERNAL_THREE_FILE_DELIVERY=PASS" in txt,
        "exit_zero": p.returncode == 0,
    }
    ok = all(checks.values())
    print("clean_chain: pass=%s exit=%d in %.0fs | %s"
          % (ok, p.returncode, time.time() - t0,
             {k: v for k, v in checks.items() if not v}))
    if not ok:
        print((p.stdout + p.stderr)[-3000:])
    if not keep:
        shutil.rmtree(into, ignore_errors=True)
    return {"id": "clean_chain", "description": "the same chain with no corruption at all, starting "
            "from a directory in which no validation record exists",
            "expected_outcome": "C01-C20 + SUP21 + P01-P09 + Q01-Q08 all PASS, record rewritten once,"
                                " third read-only process exits 0",
            "observed": {"exit_code": p.returncode, "chain_status": res.get("status"),
                         "gates_failed_observed": res.get("gates_failed"),
                         "chain_utc": res.get("chain_utc"), "checks": checks,
                         "stdout_sha256": hashlib.sha256(p.stdout.encode()).hexdigest(),
                         "stderr_sha256": hashlib.sha256(p.stderr.encode()).hexdigest(),
                         "scenario_directory": into, "final_readonly_log":
                             os.path.join(into, "logs", "r4_final_readonly.log")},
            "detected": ok}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tree", default=R4, help="tree that is copied into every scenario")
    ap.add_argument("--json", default="", help="where to write the R4 evidence record")
    ap.add_argument("--only", default="", help="run a subset, e.g. N1,N5")
    ap.add_argument("--keep", action="store_true", help="keep the scenario directories")
    a = ap.parse_args()
    R = os.path.abspath(a.tree)
    base = tempfile.mkdtemp(prefix="t4r4_closure_mut_", dir="/tmp")
    want = [c for c in CASES if not a.only or c["id"] in a.only.split(",")]
    results = [run_case(c, R, base, a.keep) for c in want]
    if not a.only or "clean_chain" in a.only:
        results.append(run_clean_control(R, base, a.keep))
    det = [r for r in results if r["detected"]]
    # isolation is measured from the directories the runs actually reported, never asserted as a
    # constant: one scenario per case, all of them distinct, all of them under this run's temp base
    dirs = [str(r["observed"].get("scenario_directory", "")) for r in results]
    distinct = bool(all(dirs)) and len(set(dirs)) == len(results) and all(
        d.startswith(base + os.sep) for d in dirs)
    mut = [r for r in results if r["id"] != "clean_chain"]
    clean = [r for r in results if r["id"] == "clean_chain"]
    mut_det = [r for r in det if r["id"] != "clean_chain"]
    out = {
        "task_id": T,
        "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "purpose": "prompt section 9: each corruption of the clean external closure order is built "
                   "in its own isolated directory and executed for real against the same chain code "
                   "that closes the delivery",
        "chain_script": CLOSURE,
        "chain_script_sha256": sha(os.path.join(R, CLOSURE)),
        "validator_sha256": sha(os.path.join(R, "scripts/r4_content_and_archive_validator.py")),
        "tree_under_test": os.path.basename(R),
        "temp_base": base,
        "cases": results,
        "summary": {
            "total": len(mut), "detected": len(mut_det), "clean_chain_detected": bool(clean) and
            clean[0]["detected"],
            "all_expected_gates_observed": all(r["observed"].get("expected_gates_observed", True)
                                               and r["observed"].get("expected_any_observed", True)
                                               for r in mut),
            "no_record_written_before_the_pre_write_gates_pass": all(
                r["observed"]["validation_written_by_this_run"] is False
                for r in mut if r["id"] in ("N1", "N2", "N3", "N4")),
            "no_pass_claimed_for_a_corrupted_closure": all(
                r["observed"].get("no_illegal_pass_claim", False) for r in mut),
            "clean_chain_pass": bool(clean) and clean[0]["detected"],
            "pre_existing_sidecar_never_reused_or_deleted": bool(
                [r for r in mut if r["id"] == "N1"
                 and r["observed"].get("pre_existing_record_untouched")]),
            "every_case_in_its_own_directory": distinct,
            "scenario_directories": dirs,
            "all_detected": len(det) == len(results) == len(mut) + 1},
    }
    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=2, ensure_ascii=False, sort_keys=True)
        print("evidence written:", a.json)
    s = out["summary"]
    print(json.dumps({"harness": "r4_closure_mutation_test", "total": s["total"],
                      "detected": s["detected"], "clean_chain_pass": s["clean_chain_pass"],
                      "all_expected_gates_observed": s["all_expected_gates_observed"],
                      "no_pass_claimed_for_a_corrupted_closure":
                          s["no_pass_claimed_for_a_corrupted_closure"],
                      "all_detected": s["all_detected"]}, sort_keys=True))
    sys.exit(0 if s["all_detected"] else 1)


main()
