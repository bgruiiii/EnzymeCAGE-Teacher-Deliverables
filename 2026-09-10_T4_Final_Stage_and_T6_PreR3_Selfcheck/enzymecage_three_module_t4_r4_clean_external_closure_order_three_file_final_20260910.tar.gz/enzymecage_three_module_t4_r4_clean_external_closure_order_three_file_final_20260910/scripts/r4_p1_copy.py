#!/usr/bin/env python3
"""T4-R4 section 2 + section 4: freeze the R3 baseline, then copy it into the fresh RETURN_DIR.

  --stage freshgate  prove the six R4 output paths do not exist yet (prompt section 2).  Any hit
                     is a hard stop: nothing is deleted, renamed or reused.
  --stage copy       safely list + extract the LANDED R3 archive into WORK/immutable_r3 (read-only
                     baseline), prove 64/64 MANIFEST.files and 63/63 MANIFEST.sha256, prove the
                     baseline equals the live R3 return dir file by file, copy the single root into
                     RETURN_DIR, write R3_BASELINE_FILE_IDENTITIES.csv, re-hash every copied byte,
                     then move the two superseded R3 closure scripts into
                     inherited_r3_closure_historical/ with their SHA unchanged.

Every check is computed from live bytes; nothing is asserted from a previous round's text.
PYTHONDONTWRITEBYTECODE=1 / python3 -B; no model, no scoring, no overlap recompute, no network."""
import argparse
import calendar
import hashlib
import json
import os
import shutil
import sys
import tarfile
import time

T = "enzymecage_three_module_t4_r4_clean_external_closure_order_three_file_final_20260910"
T3 = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R4 = f"{RR}/{T}"
AP = f"{ROOT}/HPC_Inputs/t4_r4_teacher_authority_and_r3_local_audit_payload_20260910.tar.gz"
A = f"{W}/immutable_authority/t4_r4_teacher_authority_and_r3_local_audit_payload_20260910"
R3ARC = f"{RR}/{T3}.tar.gz"
R3LIVE = f"{RR}/{T3}"
BASE3 = f"{W}/immutable_r3"
ARCHIVE_ID = ("e21127343f31c8e678e271ca8e7241a7a515c11d0ea9043c57b2535008d6611f", 228792)
R4_START_ISO = "2026-09-10T05:46:28Z"   # WORK_ROOT creation instant, i.e. the first write after the
#                                          six-path probe of prompt section 2 (see freshgate record)
PAYLOAD_ID = ("b82543960b6504bd7caf752ddd10e1da33e33d3b1dcbc7c167ba1bc70dc10769", 9900)
MEMBER_ID = {  # prompt section 1, three authority members
    "TEACHER_REPLY_T4_INPUT_IDENTITY_AND_ORCHESTRATION_BOUNDARY_2026-09-08.md":
        ("ca270af0419d7954ff8ddcb1b4304a04428ad893eeedfee604402f11004fdd34", 3627),
    "TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md":
        ("953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4", 5995),
    "ENZYMECAGE_THREE_MODULE_T4_R3_TINY_REPORT_VALIDATOR_SIDECAR_CLOSURE_RETURN_"
    "LOCAL_AUDIT_2026-09-10.md":
        ("1fbf4c5926041d795183638e9b919a703fdae2545b97cee45f2a1c6151a53126", 9097),
}
# prompt section 4: the two R3 scripts that R4 supersedes as closure entries
SUPERSEDED = ["scripts/r3_closure.py", "scripts/r3_validator.py"]
HIST = "inherited_r3_closure_historical"
BASE_CSV = "R3_BASELINE_FILE_IDENTITIES.csv"
ARC = f"{RR}/{T}.tar.gz"
R4_PATHS = [W, R4, ARC, ARC + ".identity.txt", ARC + ".validation.txt"]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def walk_reg(R):
    return sorted(os.path.relpath(os.path.join(r_, f), R)
                  for r_, _, fs in os.walk(R) for f in fs)


def tar_list(arc):
    out = []
    with tarfile.open(arc, "r:gz") as tf:
        for m in tf.getmembers():
            kind = ("dir" if m.isdir() else "symlink" if m.issym() else "hardlink" if m.islnk()
                    else "regular" if m.isfile() else "special")
            out.append((m.name.rstrip("/"), kind, m.size))
    return out


def unsafe_members(mem):
    return [n for n, k, s in mem if k not in ("regular", "dir")
            or n.startswith("/") or ".." in n.split("/") or n.startswith("./")]


def freshgate():
    """prompt section 2: existence of any R4 output path is a hard stop, never a cleanup job.

    WORK_ROOT is probed too, but the section 1 authority extraction has to land somewhere, so the
    workspace is allowed to exist only if it was created *after* the recorded fresh-gate instant and
    holds nothing but this round's scaffolding directories.  RETURN_DIR plus the three sidecars -
    including any same-basename .tmp/.partial/.failed/.bak - must be completely absent."""
    start = calendar.timegm(time.strptime(R4_START_ISO, "%Y-%m-%dT%H:%M:%SZ"))
    delivery = [R4, ARC, ARC + ".identity.txt", ARC + ".validation.txt"]
    hits = [p for p in delivery if os.path.lexists(p)]
    for ext in (".tmp", ".partial", ".failed", ".bak"):
        for p in (ARC + ".validation.txt" + ext, ARC + ext, ARC + ".identity.txt" + ext):
            if os.path.lexists(p):
                hits.append(p)
    stray = [f"{RR}/{e}" for e in sorted(os.listdir(RR)) if e.startswith(T)
             and e not in (T, os.path.basename(ARC))]
    work_entries = sorted(os.listdir(W)) if os.path.isdir(W) else []
    work_ctime = os.stat(W).st_ctime if os.path.lexists(W) else 0
    work_state = ("absent" if not os.path.lexists(W)
                  else "ctime_" + time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(work_ctime)))
    work_ok = (not os.path.lexists(W)
               or work_ctime >= start - 2
               and set(work_entries) <= {"immutable_authority", "logs", "scripts"})
    ok = not hits and not stray and work_ok
    r = {"stage": "freshgate", "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
         "r4_start_utc": R4_START_ISO,
         "start_meaning": ("the six-path probe of prompt section 2 was the first command of this round "
                           "and every one of the six paths was absent at that moment; WORK_ROOT was "
                           "created immediately afterwards by that same command to hold the section 1 "
                           "authority extraction, so its on-disk ctime is the earliest possible R4 write"),
         "paths_probed": R4_PATHS,
         "work_root_state": work_state, "work_root_entries": work_entries,
         "existing_delivery_hits": sorted(set(hits)), "stray_same_basename_in_return_root": stray,
         "verdict": "PASS" if ok else "BLOCKED_R4_PATH_ALREADY_EXISTS",
         "policy": ("an existing R4 path stops the run; it is never deleted, overwritten, resumed, "
                    "or patched with a borrowed sidecar")}
    print(json.dumps(r, sort_keys=True))
    json.dump(r, open(f"{W}/logs/r4_freshgate.json", "w"), indent=2, sort_keys=True)
    sys.exit(0 if ok else 1)


def copy_stage():
    checks, fail = {}, []

    def ck(name, ok, detail):
        checks[name] = bool(ok)
        print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")
        if not ok:
            fail.append(name)

    # ---- section 1: input identities, regular non-symlink, exact bytes + SHA ----
    st_ap, st_r3 = os.lstat(AP), os.lstat(R3ARC)
    ck("authority_payload_regular_non_symlink",
       st_ap.st_mode & 0o170000 == 0o100000 and not os.path.islink(AP), AP)
    ck("authority_payload_bytes_sha",
       st_ap.st_size == PAYLOAD_ID[1] and sha(AP) == PAYLOAD_ID[0], f"bytes={st_ap.st_size}")
    ck("r3_archive_regular_non_symlink",
       st_r3.st_mode & 0o170000 == 0o100000 and not os.path.islink(R3ARC), R3ARC)
    ck("r3_archive_bytes_sha", st_r3.st_size == ARCHIVE_ID[1] and sha(R3ARC) == ARCHIVE_ID[0],
       f"bytes={st_r3.st_size} sha256={sha(R3ARC)[:16]}...")
    mem = tar_list(AP)
    amem = [n for n, k, s in mem if k == "regular"]
    ck("authority_members_safe_single_root_3_regular",
       not unsafe_members(mem) and len(amem) == 3
       and {n.split("/")[0] for n in amem} == {os.path.basename(A)},
       f"members={len(mem)} regular={len(amem)}")
    inner = {os.path.basename(n): (os.path.getsize(os.path.join(A, os.path.basename(n))),
                                   sha(os.path.join(A, os.path.basename(n)))) for n in amem}
    ck("authority_member_bytes_sha",
       sorted(os.path.basename(n) for n in amem) == sorted(MEMBER_ID)
       and all(inner[os.path.basename(n)] == (sz, h) for n, (h, sz) in MEMBER_ID.items()),
       json.dumps({k: v[0] for k, v in sorted(inner.items())}))

    # ---- section 2: safe listing + fresh extraction of the R3 archive ----
    r3mem = tar_list(R3ARC)
    r3reg = [n for n, k, s in r3mem if k == "regular"]
    r3dirs = [n for n, k, s in r3mem if k == "dir"]
    ck("r3_members_safe", not unsafe_members(r3mem) and not any(
        k not in ("regular", "dir") for _, k, _ in r3mem),
        f"members={len(r3mem)} regular={len(r3reg)} dirs={len(r3dirs)}")
    ck("r3_single_root", sorted({n.split("/")[0] for n, k, s in r3mem}) == [T3], T3)
    ck("r3_regular_files_64", len(r3reg) == 64, f"regular={len(r3reg)}")
    if os.path.lexists(BASE3) and os.listdir(BASE3):
        print(f"[FAIL] {BASE3} is not empty - refusing to touch an existing baseline")
        sys.exit(1)
    with tarfile.open(R3ARC, "r:gz") as tf:
        tf.extractall(BASE3)                     # noqa: S202 - self-produced, verified above
    b3 = f"{BASE3}/{T3}"
    live3 = walk_reg(b3)
    ck("r3_extracted_64_regular", len(live3) == 64, f"walked={len(live3)}")
    ck("r3_extracted_names_match_tar_body", sorted(live3) == sorted(
        n[len(T3) + 1:] for n in r3reg), "tar body vs extracted tree")
    manf = [l for l in open(os.path.join(b3, "MANIFEST.files"), encoding="utf-8").read()
            .splitlines() if l.strip()]
    ck("r3_manifest_files_64_of_64", sorted(manf) == live3 and len(manf) == 64,
       f"entries={len(manf)} covers both manifests={'MANIFEST.sha256' in manf}")
    mans = {}
    for line in open(os.path.join(b3, "MANIFEST.sha256"), encoding="utf-8").read().splitlines():
        if "  " in line:
            s, rel = line.split("  ", 1)
            mans[rel] = s
    ck("r3_manifest_sha256_63_of_63_excludes_self",
       len(mans) == 63 and "MANIFEST.sha256" not in mans
       and set(mans) == set(live3) - {"MANIFEST.sha256"}
       and all(sha(os.path.join(b3, r)) == h for r, h in mans.items()),
       f"entries={len(mans)} every hash recomputed from the extracted bytes")
    ck("r3_no_pyc_or_cache", not any(p.endswith(".pyc") or "__pycache__" in p for p in live3),
       "packaged python sources only")

    # the read-only baseline must be identical to the live R3 return dir (no drift at copy time)
    lwalk = walk_reg(R3LIVE)
    ck("live_r3_dir_same_file_set", lwalk == live3, f"live={len(lwalk)}")
    drift = [r for r in live3 if sha(os.path.join(b3, r)) != sha(os.path.join(R3LIVE, r))]
    ck("live_r3_dir_byte_identical_to_baseline", not drift, f"deviations={drift[:3]}")

    # ---- section 4: copy the single root into RETURN_DIR ----
    if os.path.lexists(R4):
        print(f"[FAIL] {R4} already exists - refusing to write into a non-fresh RETURN_DIR")
        sys.exit(1)
    n = 0
    for r in live3:
        s, d = os.path.join(b3, r), os.path.join(R4, r)
        os.makedirs(os.path.dirname(d), exist_ok=True)
        shutil.copy2(s, d)
        n += 1
    ck("copied_file_count", n == 64, f"copied={n}")
    w4 = walk_reg(R4)
    ck("copy_tree_same_file_set", w4 == live3, f"RETURN_DIR regular={len(w4)}")
    bad = [r for r in live3 if sha(os.path.join(R4, r)) != sha(os.path.join(b3, r))
           or os.path.getsize(os.path.join(R4, r)) != os.path.getsize(os.path.join(b3, r))]
    ck("copy_byte_identical_every_file", not bad,
       f"per-file sha256+bytes recheck, deviations={bad[:3]}")

    # ---- R3_BASELINE_FILE_IDENTITIES.csv (relative path, bytes, sha of the 64 R3 files) ----
    with open(os.path.join(R4, BASE_CSV), "w", encoding="utf-8", newline="\n") as f:
        f.write("relative_path,bytes,sha256,source\n")
        for r in live3:
            f.write('%s,%d,%s,%s\n' % (r, os.path.getsize(os.path.join(b3, r)),
                                       sha(os.path.join(b3, r)), f"{T3}.tar.gz"))
    csv_rows = open(os.path.join(R4, BASE_CSV), encoding="utf-8").read().rstrip("\n").split("\n")
    ck("baseline_identity_csv_64_rows", len(csv_rows) == 65 and csv_rows[1].split(",")[0] == live3[0],
       f"rows={len(csv_rows) - 1} (header + 64)")

    # ---- move the two superseded R3 closure scripts, content must not change ----
    moved = []
    for rel in SUPERSEDED:
        src, dst = os.path.join(R4, rel), os.path.join(R4, HIST, os.path.basename(rel))
        before = sha(src)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        os.rename(src, dst)
        moved.append({"old_path": rel, "new_path": f"{HIST}/{os.path.basename(rel)}",
                      "sha256_before": before, "sha256_after": sha(dst),
                      "bytes": os.path.getsize(dst)})
    ck("superseded_scripts_moved_sha_identical",
       all(m["sha256_before"] == m["sha256_after"]
           and os.path.isfile(os.path.join(R4, m["new_path"]))
           and not os.path.exists(os.path.join(R4, m["old_path"])) for m in moved),
       json.dumps([{k: (v[:16] if k.startswith("sha") else v) for k, v in m.items()} for m in moved]))
    ck("return_dir_after_move", len(walk_reg(R4)) == 65, f"64 + {BASE_CSV} = {len(walk_reg(R4))}")

    out = {"stage": "copy", "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "r3_archive": {"path": R3ARC, "bytes": st_r3.st_size, "sha256": sha(R3ARC)},
           "baseline_root": b3, "return_dir": R4, "checks": checks, "failed": sorted(fail),
           "moved_superseded_scripts": moved,
           "verdict": "PASS" if not fail else "BLOCKED_INPUT_IDENTITY_OR_ARCHIVE_SAFETY"}
    json.dump(out, open(f"{W}/logs/r4_p1_copy.json", "w"), indent=2, ensure_ascii=False,
              sort_keys=True)
    print(json.dumps({"stage": "copy", "checks": len(checks), "failed": sorted(fail),
                      "verdict": out["verdict"]}, sort_keys=True))
    sys.exit(0 if not fail else 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["freshgate", "copy"], required=True)
    a = ap.parse_args()
    os.makedirs(f"{W}/logs", exist_ok=True)
    (freshgate if a.stage == "freshgate" else copy_stage)()


main()
