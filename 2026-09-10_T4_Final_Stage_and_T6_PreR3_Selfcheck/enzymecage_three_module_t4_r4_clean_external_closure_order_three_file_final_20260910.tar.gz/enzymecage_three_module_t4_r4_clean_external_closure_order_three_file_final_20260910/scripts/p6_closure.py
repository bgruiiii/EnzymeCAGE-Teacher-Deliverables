#!/usr/bin/env python3
"""T4-R2 three-file closure: record archive identity (V32), verify it from an INDEPENDENT
subprocess that re-reads the identity, re-hashes the live archive and re-hashes the fresh
unpack tree, then write the per-gate validation record (V33).
Both external files live beside the archive (never inside it). PYTHONDONTWRITEBYTECODE=1."""
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
from datetime import datetime, timezone

T = "enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909"
RR = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master/HPC_Returned_Result_Summaries"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
R = f"{RR}/{T}"
ARCHIVE = f"{RR}/{T}.tar.gz"
IDP = ARCHIVE + ".identity.txt"
VALP = ARCHIVE + ".validation.txt"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R1ARC = (f"{RR}/enzymecage_three_module_t4_r1_runtime_blindness_training_overlap_"
         "normalization_metric_delivery_evidence_correction_20260909.tar.gz")
PAYLOAD = f"{ROOT}/HPC_Inputs/t4_r2_teacher_authority_and_r1_local_audit_payload_20260909.tar.gz"
ENV_TSV = ("/usrdata/EnzymeCAGE_data/workspaces/enzymecage_three_module_t2b_r4_evidence_only_access_"
           "instrument_external_three_file_closure_20260907/r4_replay/reaction_v3/data/lib_envipath/"
           "templates.tsv.gz")
ENV_H = "/usrdata/EnzymeCAGE_data/enzymecage_crew/data/hfix/templates_implicitH.jsonl"

UNPACK = sys.argv[1]
assert UNPACK.startswith("/tmp/t4r2_reverify_") and os.path.isdir(f"{UNPACK}/{T}"), f"bad unpack dir {UNPACK}"
FAIL_IF_NOT_OK = "--dry" not in sys.argv


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def utc(ep):
    return datetime.fromtimestamp(ep, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


now = utc(time.time())
st = os.stat(ARCHIVE)
arch_sha = sha(ARCHIVE)
with tarfile.open(ARCHIVE, "r:gz") as tf:
    mem = tf.getmembers()
files = [m for m in mem if m.isfile()]
roots = sorted({m.name.split("/")[0] for m in mem})
mt = [m.mtime for m in mem]

# ---------------- identity.txt (V32 subject) ----------------
idl = [
    "TASK_ID=" + T,
    "ARCHIVE_PATH=" + ARCHIVE,
    "ARCHIVE_BYTES=%d" % st.st_size,
    "ARCHIVE_SHA256=" + arch_sha,
    "ARCHIVE_FORMAT=gzip tar, single root, safe members only",
    "SINGLE_ROOT=" + roots[0],
    "MEMBER_TOTAL=%d" % len(mem),
    "MEMBER_REGULAR_FILES=%d" % len(files),
    "MEMBER_MTIME_MIN_UTC=" + utc(min(mt)),
    "MEMBER_MTIME_MAX_UTC=" + utc(max(mt)),
    "ARCHIVE_CREATED_UTC=" + utc(st.st_mtime),
    "IDENTITY_GENERATED_UTC=" + now,
    "ARCHIVE_STAGE_VALIDATION_RUN_UTC=" + json.load(open(f"{W}/logs/p6_validator_archive.json"))["utc"],
    "README_MD_SHA256=" + sha(f"{R}/README.md"),
    "FINAL_STATUS_TXT_SHA256=" + sha(f"{R}/FINAL_STATUS.txt"),
    "MANIFEST_FILES_SHA256=" + sha(f"{R}/MANIFEST.files"),
    "MANIFEST_SHA256_SHA256=" + sha(f"{R}/MANIFEST.sha256"),
    "INPUT_AUTHORITY_PAYLOAD_SHA256=" + sha(PAYLOAD)
        + " (t4_r2_teacher_authority_and_r1_local_audit_payload_20260909.tar.gz, unmodified V01)",
    "INHERITED_T4_R1_ARCHIVE_SHA256=" + sha(R1ARC)
        + " (read-only baseline of this R2, unmodified V01/V02/V26)",
    "LOCAL_ENVIPATH_TEMPLATE_TSV_GZ_SHA256=" + sha(ENV_TSV)
        + " bytes=%d (local frozen rule file, identity re-hash only, V17)" % os.path.getsize(ENV_TSV),
    "LOCAL_ENVIPATH_TEMPLATE_IMPLICITH_SHA256=" + sha(ENV_H)
        + " bytes=%d (local frozen rule file, identity re-hash only, V17)" % os.path.getsize(ENV_H),
    "FRESH_REVERIFY_UNPACK_DIR=" + UNPACK,
    "VALIDATION_PATH=" + VALP,
]
with open(IDP, "w") as f:
    f.write("\n".join(idl) + "\n")

# ---------------- independent subprocess re-verification ----------------
verify_code = '''
import hashlib, os
ID=%r; UNPACK=%r; T=%r
def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for c in iter(lambda: f.read(1<<20),b""): h.update(c)
    return h.hexdigest()
rec=dict(l.split("=",1) for l in open(ID,encoding="utf-8").read().splitlines() if "=" in l)
arch=rec["ARCHIVE_PATH"].split(" ",1)[0]
ok = sha(arch)==rec["ARCHIVE_SHA256"].split(" ",1)[0] and os.path.getsize(arch)==int(rec["ARCHIVE_BYTES"])
up=os.path.join(UNPACK,T)
mf=dict((l.split("  ",1)[1], l.split("  ",1)[0]) for l in open(os.path.join(up,"MANIFEST.sha256"),encoding="utf-8").read().splitlines() if "  " in l)
uw=set()
for root,_,fs in os.walk(up):
    for fn in fs: uw.add(os.path.relpath(os.path.join(root,fn),up))
ok = ok and uw == set(mf) | {"MANIFEST.sha256"} and all(sha(os.path.join(up,p))==h for p,h in mf.items())
for key,p in (("README_MD_SHA256","README.md"),("FINAL_STATUS_TXT_SHA256","FINAL_STATUS.txt"),
              ("MANIFEST_FILES_SHA256","MANIFEST.files"),("MANIFEST_SHA256_SHA256","MANIFEST.sha256")):
    ok = ok and sha(os.path.join(up,p))==rec[key].split(" ",1)[0]
print("IDENTITY_VERIFY_OK" if ok else "IDENTITY_VERIFY_FAIL")
''' % (IDP, UNPACK, T)
r_ = subprocess.run([sys.executable, "-B", "-c", verify_code], capture_output=True, text=True)
v32 = "IDENTITY_VERIFY_OK" in r_.stdout
print("V32 independent identity verification:", (r_.stdout or r_.stderr).strip())
if not v32 and FAIL_IF_NOT_OK:
    print("REFUSING TO WRITE VALIDATION RECORD: identity verification failed")
    sys.exit(1)

# ---------------- validation.txt (V33) ----------------
aj = json.load(open(f"{W}/logs/p6_validator_archive.json"))
cj = json.load(open(f"{W}/logs/p6_validator_content.json"))
gates = {g["gate"]: g for g in aj["gates"]}
gates["V32"] = {
    "verdict": "PASS" if v32 else "FAIL",
    "evidence": ("external identity %s records archive bytes=%d sha256=%s; a separate python "
                 "subprocess re-read that identity, re-hashed the live archive, re-hashed all %d "
                 "files of the fresh unpack %s against MANIFEST.sha256 and re-checked "
                 "README/FINAL_STATUS/both manifest hashes: %s"
                 % (os.path.basename(IDP), st.st_size, arch_sha, len(files), UNPACK,
                    "IDENTITY_VERIFY_OK" if v32 else "IDENTITY_VERIFY_FAIL")),
    "locator": IDP,
}
gates["V33"] = {
    "verdict": "PASS" if v32 else "FAIL",
    "evidence": ("this file is the external validation record listing every gate V01-V33 with "
                 "verdict, recomputed evidence and evidence locator; source gate logs: %s and %s"
                 % (f"{W}/logs/p6_validator_content.json", f"{W}/logs/p6_validator_archive.json")),
    "locator": VALP,
}
order = ["V%02d" % i for i in range(1, 34)]
fails = [k for k in order if gates.get(k, {}).get("verdict") != "PASS"]
out = [
    "T4_R2 ASSET-LOCAL OVERLAP SEMANTIC / REPORT / DELIVERY FINAL CORRECTION",
    "INDEPENDENT VALIDATION RECORD (prompt section 14, gates V01-V33)",
    "task_id=" + T,
    "archive=" + ARCHIVE,
    "archive_bytes=%d" % st.st_size,
    "archive_sha256=" + arch_sha,
    "identity=" + IDP,
    "validation_generated_utc=" + now,
    "content_stage_run_utc=%s (gates V01-V27 against the live return dir)" % cj["utc"],
    "archive_stage_run_utc=%s (gates V01-V27 re-run against the fresh unpack + V28-V31)" % aj["utc"],
    "fresh_unpacked_reverified_in=" + UNPACK,
    "validator_script=scripts/p6_validator.py (shipped inside the archive; all gates recompute "
    "from live bytes/hashes, none restate a packaged claim)",
    "",
]
for k in order:
    g = gates[k]
    out.append("%s: %s | %s | evidence: %s" % (k, g["verdict"], g["evidence"], g["locator"]))
out += [
    "",
    "OVERALL: " + ("ALL 33 GATES PASS" if not fails else "FAILED GATES: " + ",".join(fails)),
    "FINAL_STATUS_VALUE: " + open(f"{R}/FINAL_STATUS.txt", encoding="utf-8").read().splitlines()[0],
    "MODEL_RERUN=false  RAW_PREDICTIONS_CHANGED=false  METRICS_CHANGED=false  ECLIPSE_STRICT_OOF=false",
    "TEACHER_DECISION_REQUEST_SENT=false (corrected draft is local-only, not sent)",
]
with open(VALP, "w") as f:
    f.write("\n".join(out) + "\n")
print("VALIDATION written:", VALP)
print("OVERALL:", "ALL33_PASS" if not fails else fails)
