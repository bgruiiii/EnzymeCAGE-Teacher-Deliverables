#!/usr/bin/env python3
"""T4-R2 independent validator: gates V01-V33 (prompt §14).
--stage content : V01-V27 against the unpacked return dir ($R).
--stage archive : V01-V27 against the freshly re-extracted copy + V28-V31 on the archive.
V32/V33 are produced by p6_closure.py (identity/validation files) and verified externally.
Exit 0 = all executed gates PASS. Evidence-only recomputation, no models, no large assets.
T4-R3 correction: the V23 fold6/fold8 gate no longer contains an always-true term; it is
recomputed by fold_gate() from INPUT_IDENTITIES.csv, README.md and the teacher draft, and
can be exercised standalone with --root DIR --v23-only (one JSON line, exit 0/1, no writes)."""
import argparse
import ast
import csv
import gzip
import hashlib
import json
import os
import re
import sys
import time

T = "enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R1ARC = f"{RR}/enzymecage_three_module_t4_r1_runtime_blindness_training_overlap_normalization_metric_delivery_evidence_correction_20260909.tar.gz"
R1D = f"{W}/immutable_r1"
AP = f"{ROOT}/HPC_Inputs/t4_r2_teacher_authority_and_r1_local_audit_payload_20260909.tar.gz"
R2_START_ISO = "2026-09-09T12:24:15Z"  # fresh-gate pass moment (first command of this task)
R2_START_EPOCH = time.mktime(time.strptime(R2_START_ISO, "%Y-%m-%dT%H:%M:%SZ")) + 0  # local tz == UTC
ECLIPSE_ROOT = f"{ROOT}/results/ECLIPSEProdModel"

PROMPT_SHA = {
    AP: ("19744d4308eecf382002764820b551469d441ab9b5d113242c44db5c8255d54d", 10189),
    R1ARC: ("4a52c450c78591f765c2368bd716dfd2b5dc4ade40ad1e9789c4d92279c7bdae", 172378),
}
A = f"{W}/immutable_authority/t4_r2_teacher_authority_and_r1_local_audit_payload_20260909"
INNER_SHA = {
    f"{A}/TEACHER_REPLY_T4_COUNTERSIGN_G5_ADJUDICATION_AND_NEXT_ACTIONS_2026-09-09.md":
        ("953920dfe98106c763b5d726aa7de98105cc0a971adfa755e47fc8d417aeccb4", 5995),
    f"{A}/ENZYMECAGE_THREE_MODULE_T4_R1_RUNTIME_BLINDNESS_TRAINING_OVERLAP_NORMALIZATION_METRIC_DELIVERY_EVIDENCE_CORRECTION_RETURN_LOCAL_AUDIT_2026-09-09.md":
        ("88fadc15ccee8a8ecae689f3721f1ba2c946e113bb89de6f750ffbb7ad750b42", 12587),
}
ASSETS = ["corpus_v1.jsonl", "donor_index.jsonl", "templates.json", "templates.tsv.gz",
          "templates_implicitH.jsonl", "uspto_ranker.txt", "envipath_ranker.txt", "retrieval_ranker.txt"]
RANKERS = {"uspto_ranker.txt", "envipath_ranker.txt", "retrieval_ranker.txt"}
TEMPLATES = {"templates.json", "templates.tsv.gz", "templates_implicitH.jsonl"}
INHERIT = ["DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET.csv", "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET.csv",
           "DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv", "DEPENDING_EXACT_MATCH_EVIDENCE_LOCATORS.csv",
           "DEPENDING_T4_HIT_PROVENANCE_AND_EXPOSURE.csv", "DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY.json",
           "DEPENDING_OPAQUE_RANKER_LIMITATION.md", "DEPENDING_AUDITABLE_ASSET_SCHEMA_INVENTORY.csv",
           "ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv", "ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv",
           "ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv", "NORMALIZATION_CORRECTION_METRIC_INVARIANCE.json",
           "FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv", "BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json",
           "README.md", "FINAL_STATUS.txt"]
REUSE10 = ["DEPENDING_NORMALIZED_PREDICTIONS_CORRECTED.jsonl", "NORMALIZATION_CORRECTION_METRIC_INVARIANCE.json",
           "FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv", "ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv",
           "ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv", "ECLIPSE_CASE_FOLD_EXPOSURE_SUMMARY.csv",
           "ECLIPSE_GOLD_REACTION_FOLD_EXPOSURE_SUMMARY.csv", "ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv",
           "CORRECTED_ACCESS_AND_ARTIFACT_TIMELINE.csv", "ACCESS_AUDIT_SEMANTIC_CORRECTION.md"]

G = []


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rows(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def I(v):
    try:
        return int(str(v).strip())
    except ValueError:
        return 0


def rec(gid, ok, ev, loc):
    G.append({"gate": gid, "verdict": "PASS" if ok else "FAIL", "evidence": ev, "locator": loc})
    print(f"{gid}: {'PASS' if ok else 'FAIL'} | {ev}")
    return ok


# ---- T4-R3 section 7: V23 as a hard gate -------------------------------------------
# Actual fold split identities, copied from the first-package frozen record
# RUNTIME_MODEL_AND_SCRIPT_IDENTITIES.csv split rows.  No model directory is re-read
# here: these literals are the constants every report in the package must agree with.
FOLD_ACTUAL = {
    "fold6": "b17ba7ae787c832faa3bfb0d452a46a24213bdd1a3203cca033628392d18d09f",
    "fold8": "ecdd54c591cb0ff415db22e5791493356ef195cc5e0b96b4e0d6977fb90fe918",
}
FOLD_DIR = {"fold6": "bbd_40_3_6_uspto_rdkit", "fold8": "bbd_40_3_8_uspto_rdkit"}
# eclipse/config.json SHAs of the same two folds are training-asset configs, never split
# identities.  An 8-char prefix is enough to prove no report cites one as a split SHA.
FOLD_CONFIG_PREFIX = {"fold6": "0065ebcc", "fold8": "56d8b332"}
FOLD_ROW_CHECK = "ACTUAL_SPLIT_SHA_FROM_FROZEN_RECORD"
FOLD_ROW_ROLE = "prompt_transcription_correction_citation"
DRAFT_NAME = ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
              "DECISION_REQUEST_CORRECTED_DRAFT.md")
HEXWORD = re.compile(r"[0-9a-f]{8,}")
HEX64 = re.compile(r"[0-9a-f]{64}")


def hexdiff(a, b):
    """Hamming distance plus length difference; 1 means 'same object, one typo'."""
    return sum(1 for x, y in zip(a, b) if x != y) + abs(len(a) - len(b))


def fold_line_hex_violations(text):
    """Every >=8-hex token on a line that mentions a gated fold must be a prefix of
    that fold's actual split SHA.  Returns the violating tokens."""
    bad = []
    for ln in text.split("\n"):
        tags = [t for t in FOLD_ACTUAL if t in ln]
        if not tags:
            continue
        for tok in HEXWORD.findall(ln):
            if not any(FOLD_ACTUAL[t].startswith(tok) for t in tags):
                bad.append(tok[:20])
    return bad


def fold_checks(R):
    """T4-R3 prompt section 7, items 1-8.  Returns a dict of independently falsifiable
    booleans; every term is positive, so a missing/renamed row fails instead of passing."""
    ii = rows(f"{R}/INPUT_IDENTITIES.csv")
    rd_ = open(f"{R}/README.md", encoding="utf-8").read()
    dft = open(f"{R}/{DRAFT_NAME}", encoding="utf-8").read()
    sel = {t: [r for r in ii if t in r["input_name"]] for t in FOLD_ACTUAL}
    sub = {"exactly_one_citation_row_per_gated_fold": all(len(v) == 1 for v in sel.values())}
    for t, act in FOLD_ACTUAL.items():
        cfg = FOLD_CONFIG_PREFIX[t]
        r = sel[t][0] if len(sel[t]) == 1 else {}
        tok = r.get("expected_sha256", "").strip().split(" ")[0]
        # 1/4/7: the row is that fold's split asset, frozen-record status, config-free live
        sub[f"{t}_row_targets_split_bbd_not_eclipse_config"] = bool(r) and r[
            "path"].endswith(f"/{FOLD_DIR[t]}/split_bbd.json") and "/eclipse/" not in r["path"]
        sub[f"{t}_row_status_is_actual_split_sha_from_frozen_record"] = r.get("check") == FOLD_ROW_CHECK
        # 2/3: live_sha256 is exactly the actual split SHA
        sub[f"{t}_live_sha256_equals_actual_split_sha"] = r.get("live_sha256") == act
        sub[f"{t}_live_sha256_is_not_the_config_sha"] = bool(r) and cfg not in r.get("live_sha256", "")
        sub[f"{t}_live_bytes_equals_expected_bytes_and_nonzero"] = I(r.get("live_bytes")) == I(
            r.get("expected_bytes")) > 0
        # 5: README quotes the actual split SHA verbatim; the draft quotes >=12 hex chars
        sub[f"readme_quotes_{t}_actual_split_sha_verbatim"] = act in rd_
        sub[f"teacher_draft_quotes_{t}_actual_split_sha_prefix"] = act[:12] in dft
        # 6: a config SHA is never presented as a split SHA in either report
        sub[f"{t}_config_sha_prefix_absent_from_readme"] = cfg not in rd_
        sub[f"{t}_config_sha_prefix_absent_from_teacher_draft"] = cfg not in dft
        # 8: the historical prompt value stays an explained, non-authoritative citation
        sub[f"{t}_expected_is_explained_non_authoritative_citation"] = (
            r.get("role") == FOLD_ROW_ROLE and HEX64.fullmatch(tok) is not None
            and "(" in r.get("expected_sha256", "") and "transcription" in r["expected_sha256"].lower()
            and hexdiff(tok, act) == 1 and cfg not in tok and tok != act)
        sub[f"{t}_historical_expected_value_not_reused_in_reports"] = bool(
            tok) and tok not in rd_ and tok not in dft
    sub["readme_fold_lines_only_cite_actual_split_hex"] = not fold_line_hex_violations(rd_)
    sub["teacher_draft_fold_lines_only_cite_actual_split_hex"] = not fold_line_hex_violations(dft)
    return sub


def fold_gate(R):
    """V23 = conjunction of every fold_checks sub-check, with a floor on their count so
    that an empty or shrunk check set can never pass."""
    sub = fold_checks(R)
    ok = len(sub) >= 24 and all(v is True for v in sub.values())
    bad = sorted(k for k, v in sub.items() if v is not True)
    ev = (f"V23 hard gate: {len(sub)} explicit sub-checks, "
          + ("all true" if ok else "FAILED -> " + "; ".join(bad)))
    return ok, ev, sub


def rx_status(r):
    a = r["asset_name"]
    if a in RANKERS:
        return "OPAQUE_NOT_AUDITABLE"
    if I(r["parse_error"]):
        return "P0_PARSE_ERROR_RETAINED"
    if a == "corpus_v1.jsonl":
        for col, st in (("exact_full_pair_hit", "P1_EXACT_REACTION_SEEN"),
                        ("exact_parent_product_pair_hit", "P2_EXACT_PARENT_PRODUCT_PAIR_SEEN"),
                        ("product_side_only_hit", "P3_GOLD_PRODUCT_SEEN"),
                        ("parent_side_only_hit", "P4_PARENT_SEEN")):
            if I(r[col]):
                return st
        return "P6_NO_EXACT_MATCH"
    if a == "donor_index.jsonl":
        return "P4_PARENT_SEEN" if I(r["parent_side_only_hit"]) else "P6_NO_EXACT_MATCH"
    return "P5_TEMPLATE_ONLY" if I(r["template_applicability_hit"]) > 0 else "P6_NO_EXACT_MATCH"


def pr_status(r):
    a = r["asset_name"]
    if a in RANKERS:
        return "OPAQUE_NOT_AUDITABLE"
    if I(r["parse_error"]):
        return "P0_PARSE_ERROR_RETAINED"
    if a == "corpus_v1.jsonl":
        return "P3_GOLD_PRODUCT_SEEN" if I(r["product_side_hit"]) else "P6_NO_EXACT_MATCH"
    if a == "donor_index.jsonl":
        return "P6_NO_EXACT_MATCH"
    return "P5_TEMPLATE_ONLY" if I(r["template_product_side_applicability_hit"]) > 0 else "P6_NO_EXACT_MATCH"


def run_content(R):
    ok_all = True

    # V01 authority identities
    bad = []
    for p, (s, b) in {**PROMPT_SHA, **INNER_SHA}.items():
        if not (os.path.isfile(p) and os.path.getsize(p) == b and sha(p) == s):
            bad.append(p)
    ok_all &= rec("V01", not bad, f"payload/teacher/audit/R1-archive 4 identities byte-verified; bad={bad}",
                  "INPUT_IDENTITIES.csv rows 1-4")

    # V02 R1 manifest 52/52 + 53/53
    man = {}
    for line in open(f"{R1D}/MANIFEST.sha256", encoding="utf-8"):
        if line.strip():
            s, rel = line.rstrip("\n").split("  ", 1)
            man[rel] = s
    okc = sum(1 for rel, s in man.items() if os.path.isfile(f"{R1D}/{rel}") and sha(f"{R1D}/{rel}") == s)
    mf = set(open(f"{R1D}/MANIFEST.files", encoding="utf-8").read().split())
    actual = {os.path.relpath(os.path.join(r_, f), R1D) for r_, _, fs in os.walk(R1D) for f in fs}
    ok_all &= rec("V02", okc == 52 and len(man) == 52 and mf == actual and len(mf) == 53,
                  f"r1 manifest sha {okc}/52, files coverage {len(mf)}=={len(actual)} equal={mf == actual}",
                  "immutable_r1/MANIFEST.*; INPUT_IDENTITIES.csv gate rows")

    # V03 no model entry in returned scripts
    FORBID = {"single_smiles_v32", "ECLIPSEProdModel", "load_fold_model", "smiles_to_smiles_inf",
              "LightGBM", "lgb"}
    viol = []
    for root_, _, fs in os.walk(f"{R}/scripts"):
        for fn in fs:
            if not fn.endswith(".py"):
                continue
            tree = ast.parse(open(os.path.join(root_, fn), encoding="utf-8").read())
            for nd in ast.walk(tree):
                names = []
                if isinstance(nd, ast.Import):
                    names = [a.name for a in nd.names]
                elif isinstance(nd, ast.ImportFrom):
                    names = [nd.module or ""]
                elif isinstance(nd, ast.Call):
                    f_ = nd.func
                    names = [getattr(f_, "id", "") or getattr(f_, "attr", "")]
                    if isinstance(f_, ast.Attribute):
                        names.append(f_.attr)
                for n in names:
                    if n in FORBID or (n.startswith("import") and any(x in n for x in FORBID)):
                        viol.append((fn, n))
    persist = json.load(open(f"{R}/PERSISTENT_SOURCE_NONMUTATION.json"))
    declared = persist["model_rerun"] is False and persist["raw_predictions_changed"] is False
    ok_all &= rec("V03", not viol and declared,
                  f"AST scan of returned scripts; forbidden hits={viol}; PERSISTENT json declares model_rerun=false raw_predictions_changed=false",
                  "scripts/*.py AST; FINAL_STATUS.txt")

    # V04 inherited_r1 byte-identical
    bad4 = [n for n in INHERIT if not (sha(f"{R}/inherited_r1/{n}") == sha(f"{R1D}/{n}") == man[n])]
    ok_all &= rec("V04", not bad4, f"16 inherited files live SHA == R1 source == R1 manifest; bad={bad4}",
                  "R1_INHERITED_ARTIFACT_IDENTITIES.csv")

    # V05/V06 reaction matrices
    rx0 = rows(f"{R1D}/DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET.csv")
    rx = rows(f"{R}/DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv")
    key0 = lambda r: (r["case_id"], r["reaction_id"], r["asset_name"])
    ok5 = (len(rx0) == 312 and len({key0(r) for r in rx0}) == 312
           and len({(r["case_id"], r["reaction_id"]) for r in rx0}) == 39
           and len({r["asset_name"] for r in rx0}) == 8)
    ok_all &= rec("V05", ok5, "R1 original reaction matrix 312 rows / 39x8 unique (read-only baseline)",
                  "inherited_r1/DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET.csv")
    NEWF = ["asset_local_primary_status", "asset_local_status_basis", "global_layered_status",
            "global_status_basis", "r1_original_primary_status",
            "r1_original_primary_status_valid_for_asset", "correction_note"]
    ok6 = (len(rx) == 312 and len({key0(r) for r in rx}) == 312 and all(n in rx[0] for n in NEWF))
    ok_all &= rec("V06", ok6, "corrected reaction matrix 312 rows / 39x8 unique / 7 new fields present",
                  "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv")

    # V07 corpus asset-local + distribution
    d = {}
    bad7 = []
    for r in rx:
        if r["asset_name"] != "corpus_v1.jsonl":
            continue
        st = rx_status(r)
        if r["asset_local_primary_status"] != st:
            bad7.append(r["reaction_id"])
        d[st] = d.get(st, 0) + 1
    ok7 = (not bad7 and d.get("P2_EXACT_PARENT_PRODUCT_PAIR_SEEN") == 13 and d.get("P3_GOLD_PRODUCT_SEEN") == 3
           and d.get("P4_PARENT_SEEN") == 16 and d.get("P6_NO_EXACT_MATCH") == 7)
    # corpus status must ignore template fields: perturbation probe on the template column
    import copy as _cp
    probe = _cp.deepcopy([r for r in rx if r["asset_name"] == "corpus_v1.jsonl"])
    for r in probe:
        r["template_applicability_hit"] = "999"
    ok7 = ok7 and all(rx_status(r) == r["asset_local_primary_status"] for r in probe)
    ok_all &= rec("V07", ok7, f"corpus per-row independent recompute matches; P2=13 P3=3 P4=16 P6=7; template-column perturbation does not alter corpus status (P1={d.get('P1_EXACT_REACTION_SEEN', 0)} kept 0)",
                  "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv (asset_name=corpus_v1.jsonl)")

    # V08 donor
    bad8 = []
    dn = {"P4_PARENT_SEEN": 0, "P6_NO_EXACT_MATCH": 0}
    for r in rx:
        if r["asset_name"] != "donor_index.jsonl":
            continue
        if r["asset_local_primary_status"] != rx_status(r) or r["asset_local_primary_status"] not in dn:
            bad8.append(r["reaction_id"])
        else:
            dn[r["asset_local_primary_status"]] += 1
        if I(r["exact_full_pair_hit"]) or I(r["exact_parent_product_pair_hit"]) or I(r["product_side_only_hit"]):
            bad8.append(("flags", r["reaction_id"]))
    ok_all &= rec("V08", not bad8 and dn["P4_PARENT_SEEN"] == 31 and dn["P6_NO_EXACT_MATCH"] == 8,
                  f"donor rows only P4/P6 (P4=31 P6=8); forbidden flags zero; bad={bad8[:3]}",
                  "corrected reaction matrix (asset_name=donor_index.jsonl)")

    # V09 templates independently
    want9 = {"templates.json": (29, 10), "templates.tsv.gz": (8, 31), "templates_implicitH.jsonl": (26, 13)}
    ok9 = True
    det9 = {}
    for a, (w5, w6) in want9.items():
        rs = [r for r in rx if r["asset_name"] == a]
        c5 = sum(1 for r in rs if r["asset_local_primary_status"] == "P5_TEMPLATE_ONLY")
        c6 = sum(1 for r in rs if r["asset_local_primary_status"] == "P6_NO_EXACT_MATCH")
        badrows = [r for r in rs if r["asset_local_primary_status"] != rx_status(r)]
        # per-row basis is ONLY this row's own hit column (not the sum of the other libraries)
        mism = sum(1 for r in rs if (I(r["template_applicability_hit"]) > 0) != (r["asset_local_primary_status"] == "P5_TEMPLATE_ONLY"))
        det9[a] = f"{c5}/{c6}"
        ok9 = ok9 and c5 == w5 and c6 == w6 and not badrows and not mism
    ok_all &= rec("V09", ok9, f"per-template P5/P6 {det9}; each row decided solely by its own template_applicability_hit",
                  "DEPENDING_REACTION_ASSET_LOCAL_STATUS_DISTRIBUTION.csv")

    # V10 rankers reaction
    rk = {a: sum(1 for r in rx if r["asset_name"] == a and r["asset_local_primary_status"] == "OPAQUE_NOT_AUDITABLE")
          for a in RANKERS}
    ok_all &= rec("V10", all(v == 39 for v in rk.values()) and not any(
        r["asset_local_primary_status"] not in ("OPAQUE_NOT_AUDITABLE",) for r in rx if r["asset_name"] in RANKERS),
        f"each ranker 39 rows OPAQUE_NOT_AUDITABLE: {rk}", "corrected reaction matrix (ranker rows)")

    # V11 product matrices
    pr0 = rows(f"{R1D}/DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET.csv")
    pr = rows(f"{R}/DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv")
    pk0 = lambda r: (r["case_id"], r["line_no_products_jsonl"], r["asset_name"])
    ok11 = (len(pr0) == 312 and len({pk0(r) for r in pr0}) == 312
            and len(pr) == 312 and len({pk0(r) for r in pr}) == 312
            and all(n in pr[0] for n in NEWF))
    ok_all &= rec("V11", ok11, "product original+corrected matrices 312 rows / 39x8 unique",
                  "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv")

    # V12/V13 product statuses
    pc = {}
    for r in pr:
        if r["asset_name"] == "corpus_v1.jsonl":
            pc[r["asset_local_primary_status"]] = pc.get(r["asset_local_primary_status"], 0) + 1
    don_p = [r for r in pr if r["asset_name"] == "donor_index.jsonl"]
    ok12 = (pc.get("P3_GOLD_PRODUCT_SEEN") == 16 and pc.get("P6_NO_EXACT_MATCH") == 23
            and all(r["asset_local_primary_status"] == "P6_NO_EXACT_MATCH" for r in don_p))
    ok_all &= rec("V12", ok12, f"corpus product P3=16/P6=23 {pc}; donor product all P6 (no product side)",
                  "corrected product matrix")
    ok13 = True
    for a in TEMPLATES | RANKERS:
        rs = [r for r in pr if r["asset_name"] == a]
        exp = "P5_TEMPLATE_ONLY" if a in TEMPLATES else "OPAQUE_NOT_AUDITABLE"
        if not (len(rs) == 39 and all(r["asset_local_primary_status"] == exp == pr_status(r) for r in rs)):
            ok13 = False
    ok_all &= rec("V13", ok13, "each template product P5=39 (own row column only); each ranker product OPAQUE=39",
                  "DEPENDING_PRODUCT_ASSET_LOCAL_STATUS_DISTRIBUTION.csv")

    # V14 full independent recomputation of every asset-local status (both matrices, 624 rows)
    bad14 = [key0(r) for r in rx if r["asset_local_primary_status"] != rx_status(r)]
    bad14 += [pk0(r) for r in pr if r["asset_local_primary_status"] != pr_status(r)]
    ok_all &= rec("V14", not bad14, f"624/624 asset-local statuses recomputed from own-row fields only; bad={bad14[:3]}",
                  "both CORRECTED matrices")

    # V15 global layered tables 39 rows, separate columns, consistent with BY_ASSET cross-reference
    gr = rows(f"{R}/DEPENDING_39_GOLD_REACTION_GLOBAL_LAYERED_STATUS.csv")
    gp = rows(f"{R}/DEPENDING_39_GOLD_PRODUCT_GLOBAL_LAYERED_STATUS.csv")
    ok15 = len(gr) == 39 and len(gp) == 39
    gmap = {(r["case_id"], r["reaction_id"]): r["global_layered_status"] for r in gr}
    gmap2 = {(r["case_id"], r["line_no_products_jsonl"]): r["global_layered_status"] for r in gp}
    ok15 = ok15 and all(gmap[(r["case_id"], r["reaction_id"])] == r["global_layered_status"] for r in rx)
    ok15 = ok15 and all(gmap2[(r["case_id"], r["line_no_products_jsonl"])] == r["global_layered_status"] for r in pr)
    # global priority recomputation from asset-local values
    by_r = {}
    for r in rx:
        by_r.setdefault((r["case_id"], r["reaction_id"]), {})[r["asset_name"]] = r["asset_local_primary_status"]
    for k, m in by_r.items():
        cs = m["corpus_v1.jsonl"]
        if cs == "P1_EXACT_REACTION_SEEN":
            g = "P1_EXACT_REACTION_SEEN"
        elif cs == "P2_EXACT_PARENT_PRODUCT_PAIR_SEEN":
            g = "P2_EXACT_PARENT_PRODUCT_PAIR_SEEN"
        elif cs == "P3_GOLD_PRODUCT_SEEN":
            g = "P3_GOLD_PRODUCT_SEEN"
        elif cs == "P4_PARENT_SEEN" or m["donor_index.jsonl"] == "P4_PARENT_SEEN":
            g = "P4_PARENT_SEEN"
        elif any(m[a] == "P5_TEMPLATE_ONLY" for a in TEMPLATES):
            g = "P5_TEMPLATE_ONLY"
        else:
            g = "P6_NO_EXACT_MATCH"
        if gmap[k] != g:
            ok15 = False
    ok_all &= rec("V15", ok15, "both GLOBAL_LAYERED_STATUS tables exactly 39 rows; priority recomputed; stored in separate columns only",
                  "DEPENDING_39_GOLD_*_GLOBAL_LAYERED_STATUS.csv")

    # V16 template P5 never counted as concrete P1/P2
    bad16 = [r for r in rx if r["asset_name"] in TEMPLATES and r["asset_local_primary_status"].startswith(("P1", "P2"))]
    bad16 += [r for r in gr if r["global_layered_status"] == "P5_TEMPLATE_ONLY"
              and any(x in r["asset_local_statuses_json"] for x in ('"P1_EX', '"P2_EX'))]
    ok_all &= rec("V16", not bad16, "no template row carries P1/P2; no global-P5 row has corpus P1/P2 evidence",
                  "corrected matrices + global tables")

    # V17 envipath semantics
    env = open(f"{R}/DEPENDING_ENVIPATH_RUNTIME_AND_RANKER_BOUNDARY_CORRECTED.md").read()
    ok17 = ("runtime_external_envipath_http_query = false" in env and "templates_implicitH.jsonl" in env
            and "lib_envipath/templates.tsv.gz" in env and "LOCAL" in env)
    dft = open(f"{R}/HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_DECISION_REQUEST_CORRECTED_DRAFT.md").read()
    ok17 = ok17 and ("撤回" in dft)
    ok_all &= rec("V17", ok17, "envipath corrected md: local frozen rules + external HTTP false; draft marks old claim retracted",
                  "DEPENDING_ENVIPATH_RUNTIME_AND_RANKER_BOUNDARY_CORRECTED.md")

    # V18 opaque separation
    js = json.load(open(f"{R}/DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY_CORRECTED.json"))
    sep = js["q6_corrected_separation"]
    ok18 = (sep["ranker_training_overlap"] == "UNKNOWN_FOR_ALL_18"
            and sep["cases_without_any_auditable_parent_or_template_locator"] == []
            and sep["cases_with_opaque_ranker_training_identity"] == "18/18"
            and sep["runtime_external_envipath_dependency"] is False
            and js["q6_retired_conflated_field"]["status"].startswith("RETIRED"))
    ok_all &= rec("V18", ok18, "opaque UNKNOWN_FOR_ALL_18 separated from empty no-locator list; R1 q6 retired explicitly",
                  "DEPENDING_SEEN_QUESTION_AND_ANSWER_SUMMARY_CORRECTED.json")

    # V19 depending anchors recomputed from inherited matrices
    pa = rows(f"{R}/inherited_r1/DEPENDING_18_PARENT_EXPOSURE_BY_ASSET.csv")
    par18 = sum(1 for r in pa if r["asset_name"] == "corpus_v1.jsonl" and I(r["reactant_side_canonical_hit"]) == 1)
    prov = rows(f"{R}/inherited_r1/DEPENDING_T4_HIT_PROVENANCE_AND_EXPOSURE.csv")
    p7 = sum(1 for r in prov if r["exposure_evidence_class"].strip() == "CORPUS_EXACT_PAIR_SEEN_IN_AUDITABLE_ASSET")
    ok19 = (par18 == 15 and len(pa) == 144 and p7 == 7
            and js["auditable_exposure_anchors"]["auditable_corpus_answer_pair_exposure"] == "13/39"
            and js["auditable_exposure_anchors"]["auditable_corpus_product_exposure"] == "16/39")
    ok_all &= rec("V19", ok19, f"15/18 parent, 13/39 pair, 16/39 product, {p7}/15 locator anchors recomputed",
                  "inherited_r1 parent+provenance matrices")

    # V20 ECLIPSE identities unchanged
    er = rows(f"{R}/inherited_r1/ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv")
    ep = rows(f"{R}/inherited_r1/ECLIPSE_18_PARENT_FOLD_EXPOSURE_LONG.csv")
    eh = rows(f"{R}/inherited_r1/ECLIPSE_PER_FOLD_GOLD_HIT_AND_TRAINING_EXPOSURE.csv")
    cs = {}
    for r in er:
        cs[r["exact_status"]] = cs.get(r["exact_status"], 0) + 1
    ps = {}
    for r in ep:
        ps[r["parent_split_exposure"]] = ps.get(r["parent_split_exposure"], 0) + 1
    hits = sum(I(r["fold_gold_product_hit"]) for r in eh)
    ok20 = (len(er) == 390 and len(ep) == 180 and cs.get("TRAIN") == 190 and cs.get("VAL") == 35
            and cs.get("TEST") == 25 and cs.get("NONE") == 140
            and ps.get("TRAIN") == 142 and ps.get("VAL") == 21 and ps.get("TEST") == 17
            and len(eh) == 390 and hits == 113
            and sha(f"{R}/ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv") == man["ECLIPSE_39_GOLD_REACTION_FOLD_SPLIT_OVERLAP_LONG.csv"])
    ok_all &= rec("V20", ok20, f"ECLIPSE 390/180 rows; TRAIN190 VAL35 TEST25 NONE140; parent 142/21/17; hit cells={hits}; byte-identical to R1",
                  "ECLIPSE_* matrices")

    # V21 normalized/metrics byte-identical reuse
    bad21 = [n for n in REUSE10 if sha(f"{R}/{n}") != sha(f"{R1D}/{n}") or sha(f"{R}/{n}") != man[n]]
    ok_all &= rec("V21", not bad21, "10 §10 reuse files byte-identical vs R1 originals and R1 manifest",
                  "INPUT_IDENTITIES.csv + sha256 recompute")

    # V22 README
    rd_ = open(f"{R}/README.md").read()
    ok22 = ("[pending]" not in rd_ and "89/89" in rd_ and "54/54" in rd_
            and rd_.count("[DONE]") >= 31 and "DONE" in rd_)
    ok_all &= rec("V22", ok22, f"no [pending]; base 89/89 stated; raw freeze 54/54 stated separately; DONE rows={rd_.count('[DONE]')}",
                  "README.md")

    # V23 fold6/8 actual SHAs, no config-SHA misuse.  T4-R3 section 7 replaced the old
    # single-expression gate (which contained an always-true term) with fold_gate().
    ok23, ev23, _sub23 = fold_gate(R)
    ok_all &= rec("V23", ok23, ev23,
                  "INPUT_IDENTITIES.csv fold6/fold8 citation rows; README.md fold6/8 paragraph; "
                  + DRAFT_NAME + " fold6/8 sentence")

    # V24 teacher draft ordering/neutrality
    i1339 = dft.find("13/39")
    i039 = dft.find("0/39")
    ok24 = (0 <= i1339 and (i039 == -1 or i1339 < i039)
            and "选项 A" in dft and "选项 B" in dft and "不推荐" in dft
            and "UNKNOWN_FOR_ALL_18" in dft and "runtime" in dft)
    ok_all &= rec("V24", ok24, f"13/39 primary before P1=0/39 supplement (pos {i1339}<{i039}); A/B neutral; opaque+envipath corrected",
                  "HUANG_TEACHER_..._CORRECTED_DRAFT.md")

    # V25 boundary conclusions preserved
    bm = rows(f"{R}/T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv")
    bmap = {r["boundary_dimension"]: r for r in bm}
    ok25 = (len(bm) == 16 and "r2_evidence_update" in bm[0]
            and bmap["STRICT_UNSEEN_BLIND_EVALUATION"]["attested_finding_or_value"] == "NOT_ESTABLISHED"
            and bmap["CURRENT_METRICS"]["attested_finding_or_value"] == "VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY"
            and bmap["ECLIPSE_STRICT_OOF"]["attested_finding_or_value"] == "false"
            and "UNKNOWN_FOR_ALL_18" in bmap["depending_ranker_training_identity_auditability"]["attested_finding_or_value"]
            and "knowledge base at runtime" not in json.dumps(bm))
    ok_all &= rec("V25", ok25, "boundary keeps runtime-blind in-domain / strict-unseen NOT_ESTABLISHED / OOF false; ranker row corrected",
                  "T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv")

    # V26 zero writes to persistent sources
    viol = []
    b = json.load(open(f"{R}/inherited_r1/BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json"))
    BASE_TAR = f"{RR}/enzymecage_three_module_t4_teacher_countersigned_18_depending_v32_eclipse_blind_evaluation_20260909.tar.gz"
    FREEZE_TAR = f"{RR}/enzymecage_three_module_t4_teacher_countersigned_18_depending_v32_eclipse_blind_evaluation_20260909/T4_PREDICTION_RAW_FREEZE.tar.gz"
    for p, want in ((BASE_TAR, b["base_archive"]["sha256"]), (FREEZE_TAR, b["raw_freeze"]["archive_sha256"])):
        if os.path.isfile(p):
            if sha(p) != want:
                viol.append(("sha_drift", p))
            if os.path.getmtime(p) >= R2_START_EPOCH:
                viol.append(("mtime", p))
        else:
            viol.append(("missing", p))
    for root_, _, fs in os.walk(ECLIPSE_ROOT):
        for fn in fs:
            p = os.path.join(root_, fn)
            if os.path.getmtime(p) >= R2_START_EPOCH:
                viol.append(("eclipse_tree", p))
        if os.path.getmtime(root_) >= R2_START_EPOCH:
            viol.append(("eclipse_dir", root_))
    for e in os.listdir(RR):
        p = os.path.join(RR, e)
        # this task's own return objects are the deliverables, not violations
        if e.startswith(T):
            continue
        # R2-critical frozen objects must be untouched since R2 start; sibling task packages
        # (e.g. concurrent T6-R3A) are written by THEIR OWN tasks - same adjudication as R1 V26 -
        # so they are listed in evidence but gated only if they are R1/R2 frozen inputs.
        critical = e.startswith("enzymecage_three_module_t4_") and (e.endswith(".tar.gz") or e.endswith(".identity.txt") or e.endswith(".validation.txt"))
        if critical and os.path.isfile(p):
            if os.path.getmtime(p) >= R2_START_EPOCH:
                viol.append(("t4_frozen_object_touched", p))
    # sibling task dirs are managed by their own tasks (same adjudication as R1 V26); only
    # regular files relevant to R1/R2 freezes are gated. R1 archive itself:
    if sha(R1ARC) != "4a52c450c78591f765c2368bd716dfd2b5dc4ade40ad1e9789c4d92279c7bdae":
        viol.append(("r1_archive_sha", R1ARC))
    ok_all &= rec("V26", not viol, f"base+freeze tars SHA-recomputed unchanged, ECLIPSE tree mtime<R2start({R2_START_ISO}), R1 archive unchanged, no R2-owned drift; viol={viol[:3]}",
                  "BASE_T4_ARCHIVE_AND_RAW_FREEZE_RECHECK.json; live stat/sha")

    # V27 secrets + forbidden payload scan over return dir
    sec_pat = re.compile(r"(BEGIN [A-Z ]*PRIVATE KEY|aws_secret_access_key\s*[=:]|(?:api_|access_)?token\s*=\s*['\"][A-Za-z0-9+/]{20,}|bearer [A-Za-z0-9+/._-]{30,}|password\s*[=:]\s*['\"][^'\"]{6,}|postgres(ql)?://[^\s'\"]+:\[^\s'\"]+@|mysql://[^\s'\"]+:\[^\s'\"]+@)", re.I)
    fordb = re.compile(r"(^|/)(corpus_v1\.jsonl|donor_index\.jsonl|split_bbd\.json|RAW_PREDICTIONS\.jsonl|.*\.(pt|ckpt|bin|env)$)", re.I)
    viol27 = []
    for root_, _, fs in os.walk(R):
        for fn in fs:
            p = os.path.join(root_, fn)
            rel = os.path.relpath(p, R)
            if fn.endswith(".pyc") or fordb.search(rel):
                viol27.append(("forbidden_name", rel))
                continue
            if os.path.getsize(p) > 5 * 1024 * 1024:
                viol27.append(("oversize", rel))
                continue
            if fn.endswith((".py", ".md", ".txt", ".csv", ".json", ".jsonl")):
                try:
                    txt = open(p, encoding="utf-8", errors="ignore").read()
                except OSError:
                    continue
                m = sec_pat.search(txt)
                if m:
                    viol27.append(("secret", rel, m.group(0)[:40]))
    ok_all &= rec("V27", not viol27, f"no secret patterns / forbidden raw assets / oversized files / pyc; viol={viol27[:3]}",
                  "walk of return dir with regex")
    return ok_all


def run_archive(R, ARC, UNPACK):
    ok_all = True
    # V28 MANIFEST.files covers every regular file incl both manifests
    mf = set(open(f"{R}/MANIFEST.files", encoding="utf-8").read().split())
    actual = {os.path.relpath(os.path.join(r_, f), R) for r_, _, fs in os.walk(R) for f in fs}
    ok28 = mf == actual and "MANIFEST.files" in mf and "MANIFEST.sha256" in mf
    rec("V28", ok28, f"MANIFEST.files {len(mf)} entries == walked {len(actual)}, incl both manifests",
        "MANIFEST.files")
    # V29 sha256 excludes self, covers rest
    man = {}
    for line in open(f"{R}/MANIFEST.sha256", encoding="utf-8"):
        if line.strip():
            s, rel = line.rstrip("\n").split("  ", 1)
            man[rel] = s
    ok29 = ("MANIFEST.sha256" not in man and set(man) == (mf - {"MANIFEST.sha256"})
            and all(sha(os.path.join(R, rel)) == s for rel, s in man.items()))
    ok_all &= rec("V29", ok29, f"MANIFEST.sha256 {len(man)} entries, excludes self, all live hashes match",
                  "MANIFEST.sha256")
    # V30 archive safety
    with open(ARC, "rb") as f:
        magic = f.read(2)
    mem = os.popen(f"tar -tzf {ARC}").read().split()
    roots = {m.split("/")[0] for m in mem}
    bad30 = [m for m in mem if m.startswith("/") or ".." in m]
    vlt = os.popen(f"tar -tzvf {ARC}").read().splitlines()
    links = [l for l in vlt if l and l[0] in "lcbps"]           # symlink / char / block / fifo / socket
    dirs = [l for l in vlt if l and l[0] == "d"]                # directories are allowed
    mt = os.path.getmtime(ARC)
    ok30 = (magic == b"\x1f\x8b" and roots == {T} and not bad30 and not links
            and R2_START_EPOCH - 3600 <= mt <= time.time() + 120)
    ok_all &= rec("V30", ok30, f"gzip magic, single root={roots}, unsafe={len(bad30)} links/devices={len(links)} dirs={len(dirs)}, members={len(mem)}, mtime={time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(mt))}",
                  "tar -tzvf; stat archive")
    # V31 re-extract verification
    uf = {}
    for line in open(f"{UNPACK}/{T}/MANIFEST.sha256", encoding="utf-8"):
        if line.strip():
            s, rel = line.rstrip("\n").split("  ", 1)
            uf[rel] = s
    walked = {os.path.relpath(os.path.join(r_, f), f"{UNPACK}/{T}") for r_, _, fs in os.walk(f"{UNPACK}/{T}") for f in fs}
    hashok = all(os.path.isfile(f"{UNPACK}/{T}/{rel}") and sha(f"{UNPACK}/{T}/{rel}") == s for rel, s in uf.items())
    fshead = open(f"{UNPACK}/{T}/FINAL_STATUS.txt").read().splitlines()[0]
    ok31 = hashok and walked == set(uf) | {"MANIFEST.sha256"} and fshead == "T4_R2_ASSET_LOCAL_OVERLAP_SEMANTIC_AND_DELIVERY_CORRECTION_READY_FOR_LOCAL_AUDIT"
    ok_all &= rec("V31", ok31, f"fresh temp re-extract: {len(uf)} hashes recomputed OK, file set == manifest, FINAL_STATUS line1 correct",
                  f"{UNPACK}")
    return ok_all


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["content", "archive"], default="content")
    ap.add_argument("--archive", default=f"{RR}/{T}.tar.gz")
    ap.add_argument("--unpack-dir", default="")
    # T4-R3 section 7.1: run only the corrected V23 gate against an explicit return dir.
    ap.add_argument("--root", default="", help="explicit RETURN_DIR (required with --v23-only)")
    ap.add_argument("--v23-only", dest="v23_only", action="store_true",
                    help="print one JSON line for the V23 fold gate and exit (0=PASS, 1=FAIL); writes nothing")
    a = ap.parse_args()
    if a.v23_only:
        if not a.root:
            sys.exit("--v23-only requires --root RETURN_DIR")
        ok23, ev23, sub23 = fold_gate(a.root)
        print(json.dumps({"gate": "V23", "verdict": "PASS" if ok23 else "FAIL", "root": a.root,
                          "subcheck_count": len(sub23),
                          "failed_subchecks": sorted(k for k, v in sub23.items() if v is not True),
                          "evidence": ev23}, sort_keys=True))
        sys.exit(0 if ok23 else 1)
    R = f"{RR}/{T}" if a.stage == "content" else f"{a.unpack_dir}/{T}"
    print(f"stage={a.stage} root={R} R2_START={R2_START_ISO}")
    ok = run_content(R)
    if a.stage == "archive":
        ok = run_archive(f"{RR}/{T}", a.archive, a.unpack_dir) and ok
    fails = [g for g in G if g["verdict"] == "FAIL"]
    out = {"stage": a.stage, "root": R, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "gates": G, "fail_count": len(fails),
           "note": "V32/V33 are produced and verified by p6_closure.py after the archive lands"}
    lp = f"{W}/logs/p6_validator_{a.stage}.json"
    json.dump(out, open(lp, "w"), indent=2)
    print(f"executed={len(G)} fails={len(fails)} -> {lp}")
    sys.exit(0 if not fails and ok else 1)


main()
