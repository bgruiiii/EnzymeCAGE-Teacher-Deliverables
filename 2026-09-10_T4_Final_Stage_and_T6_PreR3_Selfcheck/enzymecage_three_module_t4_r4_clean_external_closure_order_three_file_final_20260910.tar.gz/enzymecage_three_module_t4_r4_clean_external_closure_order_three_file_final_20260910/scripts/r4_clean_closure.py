#!/usr/bin/env python3
"""T4-R4 section 8: the clean external closure order.

The R3 local audit showed that the previous closure asked for a validation record before writing
the validation record, so a truly fresh run could never finish and a resumed run could have leaned
on a leftover sidecar.  This script removes that cycle:

  manifest        regenerate MANIFEST.files + MANIFEST.sha256 as the last write before packing
  status          write the in-archive FINAL_STATUS block (content ready, external delivery pending)
  identity        write <archive>.identity.txt from the archive as it sits on disk
  chain           the single implementation of the section 8.3/8.4 order, used BOTH for the real
                  closure (--stage validation) and for every isolated negative case
                  (--stage simulate), so no second copy of the logic can drift:
                    1. STOP if a validation sidecar (or any same-basename .tmp/.partial/.failed/.bak)
                       already exists - it is never deleted, reused or patched over
                    2. unpack the LANDED archive into fresh temp U1 and run C01-C20 + SUP21 and
                       P01-P09 there; P07 asserts the record is still absent, and the validator is
                       given no flag whatsoever that would let it demand a record
                    3. only if every one of those gates passed, atomically write the record ONCE
                       with POSTWRITE_STATUS=PENDING and OVERALL=PENDING_POSTWRITE_CHECK
                    4. unpack again into a second fresh temp U2 and run Q01-Q08 over the three
                       physical files
                    5. when they all passed, atomically rewrite the record once, replacing the two
                       pending markers with the Q01-Q08 results, POSTWRITE_STATUS=PASS_8_OF_8 and
                       OVERALL=PASS; when they did not, the text already on disk is kept as it is
                       and the failing outcome is appended - a BLOCKED record is never patched into
                       a PASS one
                    6. run the pre-declared final read-only check as a third independent process;
                       its stdout/stderr/exit can therefore never be inside the record it verifies
  verify          reproduction path for an auditor: fresh unpack, C01-C20 on that copy, then the
                  final read-only check; nothing is written inside the return directory

Writes go only to the archive's own three sidecars, the workspace log and the temp unpacks.
PYTHONDONTWRITEBYTECODE=1 / python3 -B."""
import argparse
import hashlib
import json
import os
import secrets
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from datetime import datetime, timezone

T = "enzymecage_three_module_t4_r4_clean_external_closure_order_three_file_final_20260910"
T3 = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R4 = f"{RR}/{T}"
AP = f"{ROOT}/HPC_Inputs/t4_r4_teacher_authority_and_r3_local_audit_payload_20260910.tar.gz"
R3ARC = f"{RR}/{T3}.tar.gz"
VALIDATOR = "scripts/r4_content_and_archive_validator.py"
READY = "T4_R4_CLEAN_EXTERNAL_CLOSURE_READY_FOR_LOCAL_AUDIT"
CONTENT_READY = "T4_R4_CONTENT_READY_FOR_EXTERNAL_VALIDATION"
PENDING_MARKERS = ("POSTWRITE_STATUS=PENDING", "OVERALL=PENDING_POSTWRITE_CHECK")
STRAY_EXT = ("", ".tmp", ".partial", ".failed", ".bak")
# an operator error during this round, disclosed here because the record has to be honest about what
# happened before it was written; see the two exit=1 entries and the cleanup entry in COMMAND_LOG.txt
INCIDENT_NOTE = (
    "incident_note=at 06:56Z a pack command was started from a shell in which the TASK_ID variable was "
    "unset, so its target resolved to the return root plus '.tar.gz' with an empty name and two stray "
    "files were created there; the three real delivery paths stayed absent, nothing was ever written to "
    "them, no gate was run against them and the stray files were removed again (logged as "
    "cleanup_stray_archives); the refusal of section 8.3 towards a pre-existing record was never "
    "bypassed, and every command of this round, failed ones included, is in COMMAND_LOG.txt.  "
    "Follow-up fix: the pack stage now runs a delivery freshness guard that rejects a non-canonical "
    "archive name and any pre-existing delivery path, so that class of shell mistake cannot recur")
CGATES = ["C%02d" % i for i in range(1, 21)]
SUPGATES = ["SUP21"]        # executed by the validator but never recorded: Q05 allows only C and P
PGATES = ["P%02d" % i for i in range(1, 10)]
QGATES = ["Q%02d" % i for i in range(1, 9)]
# the identity of every object an auditor is expected to re-hash without unpacking the archive
FROZEN_KEYS = {
    "README_MD_SHA256": "README.md", "FINAL_STATUS_TXT_SHA256": "FINAL_STATUS.txt",
    "MANIFEST_FILES_SHA256": "MANIFEST.files", "MANIFEST_SHA256_SHA256": "MANIFEST.sha256",
    "BOUNDARY_MATRIX_SHA256": "T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv",
    "TEACHER_DRAFT_SHA256": "HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
                            "DECISION_REQUEST_CORRECTED_DRAFT.md",
    "P6_VALIDATOR_SHA256": "scripts/p6_validator.py",
    "V23_MUTATION_JSON_SHA256": "V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json",
    "R4_V23_RECHECK_SHA256": "R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json",
    "R4_CLOSURE_MUTATION_SHA256": "R4_CLEAN_CLOSURE_ORDER_MUTATION_TEST.json",
    "R3_BASELINE_CSV_SHA256": "R3_BASELINE_FILE_IDENTITIES.csv",
    "R3_CHANGED_CSV_SHA256": "R3_TO_R4_CHANGED_FILES.csv",
    "R3_NONMUTATION_SHA256": "R3_CONTENT_NONMUTATION.json",
    "R4_VALIDATOR_SHA256": VALIDATOR,
    "R4_CLOSURE_SHA256": "scripts/r4_clean_closure.py",
    "R4_MUTATION_HARNESS_SHA256": "scripts/r4_closure_mutation_test.py",
}
STATUS_CONSTANTS = [
    "CONTENT_PRESERVED_FROM_T4_R3=true", "MODEL_RERUN=false", "RAW_PREDICTIONS_CHANGED=false",
    "METRICS_CHANGED=false", "STRICT_UNSEEN_BLIND_EVALUATION=NOT_ESTABLISHED",
    "CURRENT_METRICS=VALID_RUNTIME_BLIND_IN_DOMAIN_RECOVERY",
    "MODEL_ROLE_DECISION=AWAITING_HUANG_TEACHER_REVIEW", "TEACHER_DECISION_REQUEST_SENT=false",
    "T6_INDEPENDENT_AND_NOT_BLOCKED_BY_T4=true"]
DRAFT = ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_DECISION_REQUEST_"
         "CORRECTED_DRAFT.md")
BM = "T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv"
MUT_JSON = "R4_CLEAN_CLOSURE_ORDER_MUTATION_TEST.json"
V23_JSON = "R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json"
# prompt section 11: what the top level of the delivery archive has to contain.  The closure-order
# mutation evidence is part of the delivery but cannot be required inside a simulated scenario copy,
# because those copies are made while that very evidence file is still being produced.
REQUIRED_11_BASE = [
    "README.md", "AUTHORITY_AND_SCOPE.md", "R3_BASELINE_FILE_IDENTITIES.csv",
    "R3_TO_R4_CHANGED_FILES.csv", "R3_CONTENT_NONMUTATION.json", V23_JSON, BM, DRAFT,
    "V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json", "scripts/p6_validator.py", VALIDATOR,
    "scripts/r4_clean_closure.py", "scripts/r4_closure_mutation_test.py", "INPUT_IDENTITIES.csv",
    "COMMAND_LOG.txt", "FINAL_STATUS.txt", "MANIFEST.files", "MANIFEST.sha256"]
REQUIRED_11 = REQUIRED_11_BASE + [MUT_JSON]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def rd(p):
    with open(p, encoding="utf-8", errors="ignore") as f:
        return f.read()


def utc(ep=None):
    return datetime.fromtimestamp(ep if ep is not None else time.time(),
                                  tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_unpack_dir(prefix):
    """reserve an EMPTY /tmp directory now and extract into it later.  Section 8.4 wants the final
    read-only command written into the record before that command runs, so the directory it names
    has to be known at declaration time while the bytes may only land after the rewrite."""
    return tempfile.mkdtemp(prefix=prefix, dir="/tmp")


def extract_into(arc, d):
    """fill a reserved directory from the archive; the archive must already be on disk"""
    assert os.path.getmtime(arc) <= time.time() + 2, "the archive must be on disk first"
    with tarfile.open(arc, "r:gz") as tf:
        tf.extractall(d)                         # noqa: S202 - trusted, self-produced archive


def fresh_unpack(arc, prefix):
    """a NEW /tmp directory created after the archive landed, holding only the extracted copy"""
    assert os.path.getmtime(arc) <= time.time() + 2, "the archive must be on disk first"
    d = tempfile.mkdtemp(prefix=prefix, dir="/tmp")
    with tarfile.open(arc, "r:gz") as tf:
        tf.extractall(d)                         # noqa: S202 - trusted, self-produced archive
    return d


def atomic_write(target, text, tmpdir):
    """write via a temporary file OUTSIDE the target directory, then rename onto the target:

    a same-basename sibling of the validation record must never exist, not even briefly, because
    section 8.3 forbids exactly those files.  The temp file lives in the log directory instead."""
    os.makedirs(tmpdir, exist_ok=True)
    tmp = os.path.join(tmpdir, "pending_%s.hex" % secrets.token_hex(8))
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, target)
    return target


def safe_cwd():
    try:
        return os.getcwd()
    except OSError:                                      # the working directory was replaced mid-run
        return "(unobtainable: the current working directory was removed while this run was active)"


def run_validator(stage, root, arc, unpack, rmeta, out_json):
    cmd = [sys.executable, "-B", f"{root}/{VALIDATOR}", "--stage", stage, "--root", root,
           "--archive", arc, "--unpack-dir", unpack, "--run-meta", rmeta, "--out-json", out_json]
    p = subprocess.run(cmd, capture_output=True, text=True)
    return cmd, p


def gate_lines(j, prefixes):
    gs = {g["gate"]: g for g in j["gates"]}
    return ["%s: %s | measured=%s | expected=%s | evidence=%s | %s"
            % (g, gs[g]["status"], gs[g]["measured"], gs[g]["expected"], gs[g]["evidence"],
               gs[g]["locator"])
            for g in prefixes if g in gs]


def parse_kv(p):
    return dict(l.split("=", 1) for l in rd(p).splitlines() if "=" in l)


# ------------------------------------------------------------------------------ section 8.1 / 8.2
def manifest_stage(tree):
    # both manifests are part of what they list, so they are named even when they do not exist yet
    # (otherwise a regeneration after a deletion would under-report by exactly two entries)
    reg = sorted({os.path.relpath(os.path.join(r_, f), tree)
                  for r_, _, fs in os.walk(tree) for f in fs}
                 | {"MANIFEST.files", "MANIFEST.sha256"})
    with open(os.path.join(tree, "MANIFEST.files"), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(reg) + "\n")
    lines = ["%s  %s" % (sha(os.path.join(tree, r)), r) for r in reg if r != "MANIFEST.sha256"]
    with open(os.path.join(tree, "MANIFEST.sha256"), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print("MANIFEST.files: %d entries; MANIFEST.sha256: %d entries (self excluded)"
          % (len(reg), len(lines)))
    print("MANIFEST.files sha256:", sha(os.path.join(tree, "MANIFEST.files")))
    print("MANIFEST.sha256 sha256:", sha(os.path.join(tree, "MANIFEST.sha256")))


def status_stage(tree):
    """section 10: the in-archive status is exactly the eleven required lines - the sidecars do not
    exist yet at packing time, so the package may only claim content readiness."""
    lines = [CONTENT_READY] + STATUS_CONSTANTS + ["EXTERNAL_THREE_FILE_DELIVERY=PENDING_AT_ARCHIVE_TIME"]
    with open(os.path.join(tree, "FINAL_STATUS.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print("FINAL_STATUS.txt written (%d lines, content-ready block only):" % len(lines))
    print(rd(os.path.join(tree, "FINAL_STATUS.txt")))


def identity_stage(tree, arc, tmpdir=None):
    st = os.stat(arc)
    with tarfile.open(arc, "r:gz") as tf:
        mem = tf.getmembers()
    reg = [m for m in mem if m.isfile()]
    roots = sorted({m.name.split("/")[0] for m in mem})
    idl = ["TASK_ID=" + T, "ARCHIVE_PATH=" + arc, "ARCHIVE_FILENAME=" + os.path.basename(arc),
           "ARCHIVE_BYTES=%d" % st.st_size, "ARCHIVE_SHA256=" + sha(arc),
           "ARCHIVE_FORMAT=gzip tar, single root, regular files and directories only",
           "SINGLE_ROOT=" + roots[0], "MEMBER_TOTAL=%d" % len(mem),
           "MEMBER_REGULAR_FILES=%d" % len(reg),
           "MEMBER_MTIME_MIN_UTC=" + utc(min(m.mtime for m in mem)),
           "MEMBER_MTIME_MAX_UTC=" + utc(max(m.mtime for m in mem)),
           "ARCHIVE_MTIME_UTC=" + utc(st.st_mtime), "IDENTITY_GENERATED_UTC=" + utc(),
           "IDENTITY_NONCE=" + secrets.token_hex(16),
           "VALIDATION_PATH=" + arc + ".validation.txt",
           "INPUT_R3_ARCHIVE_SHA256=" + sha(R3ARC) + " (unmodified; the single result input of R4)",
           "INPUT_AUTHORITY_PAYLOAD_SHA256=" + sha(AP) + " (unmodified)",
           "VALIDATOR_SOURCE_SHA256=" + sha(os.path.join(tree, VALIDATOR))]
    idl += ["%s=%s" % (k, sha(os.path.join(tree, p))) for k, p in sorted(FROZEN_KEYS.items())
            if os.path.isfile(os.path.join(tree, p))]
    idl.append("NOTE=every field above is stat or sha256 of the landed archive and of a FRESH unpack "
               "of it; nothing here is copied from a previous round's sidecar")
    atomic_write(arc + ".identity.txt", "\n".join(idl) + "\n", tmpdir or f"{W}/logs")
    print("IDENTITY written:", arc + ".identity.txt")
    print(rd(arc + ".identity.txt"))


def prepack_check(tree, delivery):
    """section 8.1 step 8 / section 11: refuse to create the delivery archive unless the package
    really carries every required entry and the two evidence files of this round say what they have
    to say.  This runs BEFORE any archive exists, so it cannot be self-referential."""
    miss = [p for p in (REQUIRED_11 if delivery else REQUIRED_11_BASE)
            if not os.path.isfile(os.path.join(tree, p))]
    r1 = os.listdir(os.path.join(tree, "inherited_r1")) if os.path.isdir(
        os.path.join(tree, "inherited_r1")) else []
    chk = {"section_11_entries_present": not miss,
           "inherited_r1_evidence_present": bool(r1)}
    detail = {"missing": miss, "inherited_r1_entries": len(r1)}
    if delivery:
        # the closure-order mutation evidence and the V23 recheck describe the round that is being
        # packed, so a simulated scenario copy is not expected to carry a finished version of them
        try:
            mj = json.loads(rd(os.path.join(tree, MUT_JSON)))
        except (OSError, ValueError):
            mj = {}
        try:
            vj = json.loads(rd(os.path.join(tree, V23_JSON)))["summary"]
        except (OSError, KeyError, ValueError):
            vj = {}
        cases = [c for c in mj.get("cases", []) if c.get("id") != "clean_chain"]
        chk.update({
            "closure_mutations_10_of_10": mj.get("summary", {}).get("total") == 10
            and mj.get("summary", {}).get("detected") == 10
            and mj.get("summary", {}).get("all_detected") is True,
            "closure_clean_chain_pass": mj.get("summary", {}).get("clean_chain_pass") is True,
            "closure_every_case_records_stdout_stderr_sha": len(cases) == 10 and all(
                c["observed"].get("stdout_sha256") and c["observed"].get("stderr_sha256")
                for c in cases),
            "v23_clean_pass": vj.get("clean_v23_pass") is True,
            "v23_mutations_8_of_8": vj.get("total") == 8 and vj.get("detected") == 8,
            "v23_semantics_preserved": vj.get("semantics_preserved_from_r3") is True})
        detail["closure_summary"] = {k: mj.get("summary", {}).get(k) for k in
                                     ("total", "detected", "all_detected", "clean_chain_pass")}
        detail["v23_summary"] = {k: vj.get(k) for k in ("total", "detected", "clean_v23_pass",
                                                        "semantics_preserved_from_r3")}
    bad = sorted(k for k, v in chk.items() if v is not True)
    print("prepack check (delivery=%s): %s%s" % (delivery, "PASS" if not bad else "FAIL " + str(bad),
                                                 "" if delivery else " - section 11 entries only"))
    if bad:
        print(json.dumps(detail, sort_keys=True)[:1200])
        sys.exit("BLOCKED_PREPACK_CHECK: " + ", ".join(bad))
    return chk


def delivery_freshness_guard(tree, arc):
    """section 8.3 red lines applied to the packing step itself: a delivery archive may only be
    created under the canonical TASK_ID name, and only while none of the three same-basename files
    exists yet.  This is what makes the 06:56Z incident unreproducible - a shell that lost its
    TASK_ID produces a name the guard refuses outright - and it also stops a second real closure
    from silently overwriting a record that is already on disk."""
    if os.path.dirname(arc) != RR:
        print("delivery freshness guard: not the return root, nothing to guard (simulated scenario)")
        return True
    bad = []
    if os.path.basename(arc) != T + ".tar.gz":
        bad.append("non-canonical archive name %r" % os.path.basename(arc))
    probed = [arc, arc + ".identity.txt", arc + ".validation.txt"]
    probed += [arc + ".validation.txt" + e for e in (".tmp", ".partial", ".failed", ".bak")]
    bad += ["already exists: " + os.path.basename(p) for p in probed if os.path.lexists(p)]
    if bad:
        sys.exit("BLOCKED_DELIVERY_FRESHNESS_GUARD: " + "; ".join(bad))
    print("delivery freshness guard: PASS (canonical name, %d target paths probed absent)"
          % len(probed))
    return True


def pack_stage(tree, arc, delivery=False):
    if delivery:
        delivery_freshness_guard(tree, arc)
    prepack_check(tree, delivery)
    p = subprocess.run(["tar", "--numeric-owner", "--owner=0", "--group=0", "-czf", arc,
                        "-C", os.path.dirname(tree), os.path.basename(tree)],
                       capture_output=True, text=True)
    if p.returncode != 0:
        print("tar failed:", p.stderr[-400:])
        sys.exit(1)
    print("ARCHIVE created:", arc, os.path.getsize(arc), "bytes", sha(arc))


# ------------------------------------------------------------------------------- section 8.4 record
def evidence_summaries(tree):
    """the two summaries section 8.4 asks for, recomputed from the evidence files in the tree."""
    v23 = {"error": "R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json not found in the tested tree"}
    nm = {"error": "R3_CONTENT_NONMUTATION.json not found in the tested tree"}
    p = os.path.join(tree, "R4_V23_PRESERVATION_AND_MUTATION_RECHECK.json")
    if os.path.isfile(p):
        j, s = json.loads(rd(p)), json.loads(rd(p))["summary"]
        v23 = {"detected": "%d/%d" % (s["detected"], s["total"]), "clean_v23_pass": s["clean_v23_pass"],
               "clean_source_scan_pass": s["clean_source_scan_pass"],
               "expected_check_in_every_case": s["expected_check_observed_in_every_case"],
               "semantics_preserved_from_r3": s["semantics_preserved_from_r3"],
               "validator_source_sha256": j["validator_source_sha256"]}
    p = os.path.join(tree, "R3_CONTENT_NONMUTATION.json")
    if os.path.isfile(p):
        s = json.loads(rd(p))["summary"]
        keep = ("baseline_regular_files", "non_whitelist_files_verified", "whitelist_rewritable",
                "relocated_pairs", "added_by_r4", "changed_outside_whitelist", "failing_checks")
        nm = {k: s[k] for k in keep if k in s}
    return v23, nm


def build_record(arc, j_pw, j_qw, meta, extra_q, tree, pending=False):
    """the validation text: C/SUP/P blocks, and for the final form the Q block plus the status lines"""
    st = os.stat(arc)
    v23, nm = evidence_summaries(tree)
    head = [
        "T4-R4 CLEAN EXTERNAL CLOSURE ORDER AND THREE-FILE FINAL DELIVERY",
        "INDEPENDENT VALIDATION RECORD (prompt section 8): the content gates C01-C20 (+SUP21) and the",
        "pre-write gates P01-P09 ran inside a fresh unpack of the landed archive while this record did",
        "not exist yet; the file carries exactly those 20 + 9 rows, plus the post-write rows Q01-Q08",
        "that replace the two pending markers once all eight of them pass",
        "task_id=" + T,
        "archive=" + arc,
        "archive_bytes=%d" % st.st_size,
        "archive_sha256=" + sha(arc),
        "identity=" + arc + ".identity.txt",
        "validation=" + arc + ".validation.txt",
        "RUN_ID=" + meta["run_id"],
        "VALIDATION_NONCE=" + meta["nonce"],
        "PRE_WRITE_GATE_UTC=" + meta["pre_write_gate_utc"],
        "FIRST_VALIDATION_WRITE_UTC=" + meta.get("first_validation_write_utc", "pending"),
        "archive_mtime_utc=" + meta["archive_mtime_utc"],
        "identity_generated_utc=" + meta["identity_generated_utc"],
        "postwrite_gate_utc=" + meta.get("postwrite_gate_utc", "not yet executed"),
        "record_generated_utc=" + utc(),
        "VALIDATOR_SOURCE_SHA256=" + j_pw["validator_source_sha256"],
        "PWRITE_COMMAND=" + " ".join(j_pw["argv"]),
        "PWRITE_EXIT=%d" % meta["pwrite_exit"],
        "POSTWRITE_COMMAND=" + (" ".join(j_qw["argv"]) if j_qw else "not yet executed"),
        "POSTWRITE_EXIT=%s" % meta.get("postwrite_exit", "not yet executed"),
        "FINAL_READONLY_CHECK_COMMAND=" + meta["final_readonly_command"],
        "FINAL_READONLY_COMMAND_NOTE=the line above is the literal argv of the third process, written "
        "into this record before that process ran; the process itself re-derives it from its own "
        "sys.argv behind the 'python3 -B ' interpreter prefix and exits non-zero if the two differ, "
        "so a declared command that was not the command run cannot pass unnoticed",
        "fresh_unpacks=U1=%s U2=%s U3=%s (three directories created by this run; the pre-write gates "
        "ran in U1 while no record existed, the post-write gates ran in U2 after the first write, and "
        "the read-only command above names U3, which was reserved empty before the first write and "
        "extracted into only after the rewrite)"
        % (os.path.basename(meta.get("unpack_1", "")), os.path.basename(meta.get("unpack_2", "")),
           os.path.basename(meta.get("final_readonly_unpack_dir", ""))),
        "closure_order_note=the pre-write run was executed while no validation record existed; P07 "
        "asserts its absence, and this record was written only after P01-P09 all passed",
        INCIDENT_NOTE,
        "tested_tree=" + tree,
        "",
    ]
    body = gate_lines(j_pw, CGATES) + [""] + gate_lines(j_pw, PGATES)
    if extra_q:
        body += [""] + extra_q
    tail = ["",
            "V23_MUTATION_SUMMARY=" + json.dumps(v23, sort_keys=True),
            "SCIENTIFIC_NONMUTATION_SUMMARY=" + json.dumps(nm, sort_keys=True),
            "PACKAGE_FINAL_STATUS_LINE1=" + (rd(os.path.join(tree, "FINAL_STATUS.txt")).splitlines()[0]
                                             if os.path.isfile(os.path.join(tree, "FINAL_STATUS.txt"))
                                             else "FINAL_STATUS.txt not found"),
            "STATUS_CONSTANT_CANDIDATE=" + READY,
            "boundary=no model, inference, training, GPU, network, scoring, overlap recompute or OOF; "
            "writes limited to this task's workspace, return dir and the three same-basename files; "
            "T6-named entries were skipped by name and never opened or stat-ed; the teacher draft "
            "stays local and neutral on options A/B.",
            ]
    if pending:
        tail += ["", PENDING_MARKERS[0], PENDING_MARKERS[1]]
    return head + body + tail


# ------------------------------------------------------------- the single clean closure chain
def chain(ARC, logs, meta_path, until="full", hook=None, stale_u2=False, keep=False):
    """section 8.3 + 8.4, used unchanged by the real closure and by --stage simulate"""
    IDP, VALP = ARC + ".identity.txt", ARC + ".validation.txt"
    res = {"archive": ARC, "validation_path": VALP, "until": until,
           "validation_written_by_this_run": False, "gates_failed": [], "blocked": None}

    def finish():
        json.dump(res, open(os.path.join(logs, "chain_result.json"), "w"), indent=2, sort_keys=True)
        return res

    if hook:
        hook("before_absence_check")
    strays = [p for p in (VALP + e for e in STRAY_EXT) if os.path.lexists(p)]
    if not os.path.isfile(ARC):
        # without the archive there is nothing to gate at all
        res["blocked"] = "BLOCKED_MISSING_ARCHIVE"
        print("BLOCKED: BLOCKED_MISSING_ARCHIVE", ARC)
        return finish()
    if strays:
        print("BLOCKED: BLOCKED_PREEXISTING_VALIDATION_SIDECAR", [os.path.basename(s) for s in strays],
              "- the existing file is neither opened, reused nor deleted")
    # a missing identity is NOT an early exit: P05 and P08 exist to report exactly that, so the
    # pre-write gates are still run and the record is still refused (prompt section 9, case N2)

    st = os.stat(ARC)
    idrec = parse_kv(IDP) if os.path.isfile(IDP) else {}
    meta = {"run_id": "r4-" + utc().replace(":", "").replace("-", "") + "-" + secrets.token_hex(4),
            "nonce": secrets.token_hex(16), "archive": ARC,
            "archive_mtime_utc": utc(st.st_mtime),
            "identity_generated_utc": idrec.get("IDENTITY_GENERATED_UTC", ""),
            "identity_nonce": idrec.get("IDENTITY_NONCE", "")}
    U3 = new_unpack_dir("t4r4_final_")            # empty here; extracted after the rewrite
    meta["final_readonly_unpack_dir"] = U3

    def readonly_cmd(up):
        return ["python3", "-B", f"{up}/{T}/{VALIDATOR}", "--stage", "final-readonly",
                "--archive", ARC, "--root", f"{up}/{T}", "--unpack-dir", up,
                "--out-json", os.path.join(logs, "r4_final_readonly.json")]

    meta["final_readonly_command"] = " ".join(readonly_cmd(U3))
    meta["final_readonly_note"] = ("the record names the literal argv of the third process; that "
                                   "process compares its own argv with this string and refuses the "
                                   "delivery if they differ (argv[0] is spelled python3 here and is "
                                   "resolved to the interpreter actually used when it runs)")

    # ---- step 10-11: fresh unpack U1, C01-C20 + SUP21 and P01-P09 while no record exists ----
    U1 = fresh_unpack(ARC, "t4r4_pre_")
    meta["unpack_1"] = U1
    T1 = os.path.join(U1, T)
    if stale_u2:
        # only the N10 negative case asks for this: a post-write tree that is NOT created after the
        # first record write, to prove that Q08 rejects it
        S = fresh_unpack(ARC, "t4r4_stale_")
        time.sleep(3)
    json.dump(meta, open(meta_path, "w"), indent=2, sort_keys=True)
    cmd1, p1 = run_validator("pwrite", T1, ARC, U1, meta_path,
                             os.path.join(logs, "validator_pwrite.json"))
    res["pwrite_command"], res["pwrite_exit"] = " ".join(cmd1), p1.returncode
    j_pw = json.loads(rd(os.path.join(logs, "validator_pwrite.json"))) if os.path.isfile(
        os.path.join(logs, "validator_pwrite.json")) else {"gates": [], "argv": cmd1,
                                                           "validator_source_sha256": "unreadable",
                                                           "utc": "unreadable"}
    res["gates_failed"] = sorted(g["gate"] for g in j_pw["gates"] if g["status"] != "PASS") or (
        ["PWRITE_EXIT_%d" % p1.returncode] if p1.returncode else [])
    res["strays_seen"] = [os.path.basename(s) for s in strays]
    res["p07_verdict"] = next((g["status"] for g in j_pw["gates"] if g["gate"] == "P07"),
                              "not executed")
    if strays or res["gates_failed"]:
        # a pre-existing sidecar is reported through P07 as well: the gates still run so that the
        # refusal has an evidenced reason, but nothing is written, reused or deleted either way
        res["blocked"] = ("BLOCKED_PREEXISTING_VALIDATION_SIDECAR" if strays
                          else "BLOCKED_PREWRITE_GATES")
        res["validation_written_by_this_run"] = False
        print("BLOCKED:", res["blocked"], "| pre-write gate failures:", res["gates_failed"])
        print((p1.stdout + p1.stderr)[-2500:])
        shutil.rmtree(U1, ignore_errors=True)
        shutil.rmtree(U3, ignore_errors=True)
        return finish()
    meta["pre_write_gate_utc"], meta["pwrite_exit"] = j_pw["utc"], p1.returncode
    meta["pre_write_record_absence_confirmed"] = True
    print("pre-write gates: %d executed, all PASS (C01-C20, SUP21, P01-P09)" % len(j_pw["gates"]))

    # ---- step 12: the second fresh unpack happens after the first write, never before it ----
    if stale_u2:
        U2, meta["unpack_2"] = S, S
    else:
        U2 = fresh_unpack(ARC, "t4r4_post_")
        meta["unpack_2"] = U2
    T2 = os.path.join(U2, T)
    meta["postwrite_gate_utc"] = utc()

    # ---- section 8.4 first atomic write, with the two pending markers ----
    # the declared moment has to be taken BEFORE the bytes land, because the record itself carries
    # it; Q06 then compares that declared moment with the ctime measured after the write
    meta["first_validation_write_utc"] = utc()
    json.dump(meta, open(meta_path, "w"), indent=2, sort_keys=True)
    text = build_record(ARC, j_pw, None, meta, None, T1, pending=True)
    atomic_write(VALP, "\n".join(text) + "\n", logs)
    meta["first_validation_write_ctime_utc"] = utc(os.stat(VALP).st_ctime)
    res["validation_written_by_this_run"] = True
    res["first_validation_write_utc"] = meta["first_validation_write_utc"]
    res["first_validation_write_ctime_utc"] = meta["first_validation_write_ctime_utc"]
    json.dump(meta, open(meta_path, "w"), indent=2, sort_keys=True)
    print("first write:", VALP, "| markers:", ", ".join(PENDING_MARKERS))

    if hook:
        hook("after_first_write")

    # ---- Q01-Q08 over the three physical files ----
    cmd2, p2 = run_validator("postwrite", T2, ARC, U2, meta_path,
                             os.path.join(logs, "validator_postwrite.json"))
    j_qw = json.loads(rd(os.path.join(logs, "validator_postwrite.json")))
    meta["postwrite_exit"] = p2.returncode
    json.dump(meta, open(meta_path, "w"), indent=2, sort_keys=True)
    qlines = gate_lines(j_qw, QGATES)
    qfails = sorted(g["gate"] for g in j_qw["gates"] if g["status"] != "PASS") or (
        ["POSTWRITE_EXIT_%d" % p2.returncode] if p2.returncode else [])
    res["postwrite_exit"], res["postwrite_gates_failed"] = p2.returncode, qfails
    q_ok = not qfails
    if q_ok:
        final = build_record(ARC, j_pw, j_qw, meta, qlines, T1) + [
            "", "POSTWRITE_STATUS=PASS_8_OF_8", "OVERALL: PASS", "T4_R4_STATUS: " + READY,
            "EXTERNAL_THREE_FILE_DELIVERY=PASS", "REWRITE_UTC=" + utc(),
            "REWRITE_NOTE=this file was written once while the post-write gates were still pending "
            "and rewritten exactly once afterwards, after Q01-Q08 all passed; the two pending "
            "markers were replaced by the Q01-Q08 block and the final status lines"]
        atomic_write(VALP, "\n".join(final) + "\n", logs)
        print("rewritten with the Q block: POSTWRITE_STATUS=PASS_8_OF_8, OVERALL: PASS")
    else:
        # the text on disk is kept exactly as written; the failing outcome is APPENDED, never
        # patched over the pending markers with a PASS
        held = (rd(VALP).rstrip("\n").split("\n") if os.path.isfile(VALP)
                else ["(no record was on disk when the post-write gates ran: nothing to preserve)"])
        final = held + ["", "POSTWRITE_STATUS=FAIL_%d_OF_%d" % (len(qfails), len(QGATES)),
                        "OVERALL: FAIL", "T4_R4_STATUS: BLOCKED_POSTWRITE_GATES",
                        "EXTERNAL_THREE_FILE_DELIVERY=FAIL", "FAILING_POSTWRITE_GATES="
                        + ",".join(qfails), "APPEND_UTC=" + utc(),
                        "NOTE=the post-write gates did not pass, so nothing was upgraded: the text "
                        "written before this append is preserved verbatim above, the in-archive "
                        "FINAL_STATUS still only claims content readiness, which remains true"]
        atomic_write(VALP, "\n".join(final) + "\n", logs)
        res["gates_failed"] = sorted(set(res["gates_failed"]) | set(qfails))
        res["blocked"] = "BLOCKED_POSTWRITE_GATES"
        print("post-write gates FAILED:", qfails, "- the record was appended as FAIL, never rewritten"
              " to PASS")

    if until == "postwrite":
        res["status"] = "PASS" if q_ok else "BLOCKED"
        res["chain_utc"] = {k: meta.get(k) for k in ("archive_mtime_utc", "identity_generated_utc",
                                                    "pre_write_gate_utc",
                                                    "first_validation_write_utc",
                                                    "first_validation_write_ctime_utc",
                                                    "postwrite_gate_utc")}
        res["run_id"], res["nonce"] = meta["run_id"], meta["nonce"]
        for d in ([] if keep else [U1, U2, U3]):
            shutil.rmtree(d, ignore_errors=True)
        return finish()

    # ---- section 8.4 last step: the third, independent, read-only process ----
    extract_into(ARC, U3)
    cmd3 = readonly_cmd(U3)
    cmd3[0] = sys.executable              # the declared string keeps the portable spelling
    declared_match = " ".join(["python3"] + cmd3[1:]) == meta["final_readonly_command"]
    p3 = subprocess.run(cmd3, capture_output=True, text=True)
    log = "\n".join(["# final independent read-only check (prompt section 8.4)",
                     "utc=" + utc(), "cwd=" + safe_cwd(), "argv=" + " ".join(cmd3),
                     "exit=%d" % p3.returncode,
                     "declared_command_matches_this_argv=" + str(declared_match),
                     "stdout_sha256=" + hashlib.sha256(p3.stdout.encode()).hexdigest(),
                     "stderr_sha256=" + hashlib.sha256(p3.stderr.encode()).hexdigest(), "",
                     "--- stdout ---", p3.stdout, "--- stderr ---", p3.stderr])
    with open(os.path.join(logs, "r4_final_readonly.log"), "w", encoding="utf-8") as f:
        f.write(log + "\n")
    print(p3.stdout.rstrip())
    print(p3.stderr.rstrip())
    res["final_readonly_exit"] = p3.returncode
    res["final_readonly_stdout_sha256"] = hashlib.sha256(p3.stdout.encode()).hexdigest()
    res["final_readonly_stderr_sha256"] = hashlib.sha256(p3.stderr.encode()).hexdigest()
    res["final_readonly_log"] = os.path.join(logs, "r4_final_readonly.log")
    res["final_readonly_command_matches_declaration"] = declared_match
    ok = q_ok and p3.returncode == 0 and declared_match
    res["status"] = "PASS" if ok else "BLOCKED"
    if not ok and not res["blocked"]:
        res["blocked"] = "BLOCKED_FINAL_READONLY"
    res["chain_utc"] = {k: meta.get(k) for k in ("archive_mtime_utc", "identity_generated_utc",
                                                 "pre_write_gate_utc", "first_validation_write_utc",
                                                 "first_validation_write_ctime_utc",
                                                 "postwrite_gate_utc")}
    res["run_id"], res["nonce"] = meta["run_id"], meta["nonce"]
    res["sidecar_sha256"] = {os.path.basename(p): sha(p) for p in (ARC, IDP, VALP)
                             if os.path.isfile(p)}
    for d in ([] if keep else [U1, U2, U3]):
        shutil.rmtree(d, ignore_errors=True)
    print("chain: pwrite_exit=%d postwrite_exit=%s final_readonly_exit=%s -> %s"
          % (p1.returncode, p2.returncode, p3.returncode, res["status"]))
    return finish()


# ------------------------------------------------------------------------------------------ stages
def validation_stage(keep):
    arc = f"{RR}/{T}.tar.gz"
    res = chain(arc, f"{W}/logs", f"{W}/logs/r4_run_meta.json", until="full", keep=keep)
    print("\n--- validation record as it now stands on disk ---")
    vp = res["validation_path"]
    print(rd(vp) if os.path.isfile(vp) else "(no record written by this run)")
    print(json.dumps({k: v for k, v in res.items() if k != "gates_failed"}, sort_keys=True))
    print("OVERALL:", "PASS" if res.get("status") == "PASS" else "BLOCKED", "| record:", vp)
    sys.exit(0 if res.get("status") == "PASS" else 1)


def verify_stage(arc):
    U = fresh_unpack(arc, "t4r4_verify_")
    cmd, p = run_validator("content", f"{U}/{T}", arc, U, f"{W}/logs/r4_run_meta.json",
                           f"{W}/logs/r4_validator_verify.json")
    print(p.stdout[-3000:], p.stderr[-800:])
    cmd2, p2 = run_validator("final-readonly", f"{U}/{T}", arc, U, f"{W}/logs/r4_run_meta.json",
                             f"{W}/logs/r4_validator_finalreadonly.json")
    print(p2.stdout[-2000:], p2.stderr[-800:])
    print("verify: content_exit=%d final_readonly_exit=%d unpack=%s"
          % (p.returncode, p2.returncode, U))
    shutil.rmtree(U, ignore_errors=True)
    sys.exit(0 if p.returncode == 0 and p2.returncode == 0 else 1)


def simulate_stage(into, tree_src, until, stale_u2, keep, mutation_script=""):
    """an isolated copy of the tree, packed, identified and closed by the very same chain()"""
    into = os.path.abspath(into)
    if os.path.lexists(into):
        shutil.rmtree(into)
    os.makedirs(into)
    # the scenario script lives OUTSIDE the directory that is wiped and rebuilt below, so it is
    # copied in here rather than expected to have survived
    if mutation_script:
        shutil.copyfile(mutation_script, os.path.join(into, "mutation.py"))
    tree = os.path.join(into, "tree", T)
    os.makedirs(os.path.join(into, "tree"))
    shutil.copytree(tree_src, tree)
    for f in ("MANIFEST.files", "MANIFEST.sha256"):
        if os.path.isfile(os.path.join(tree, f)):
            os.remove(os.path.join(tree, f))
    manifest_stage(tree)
    arc = os.path.join(into, T + ".tar.gz")
    pack_stage(tree, arc, delivery=os.path.dirname(os.path.abspath(arc)) == RR)
    identity_stage(tree, arc, os.path.join(into, "logs"))

    def hook(step):
        if mutation_script:
            subprocess.run([sys.executable, "-B", os.path.join(into, "mutation.py"), step, into],
                           check=False)
        if step == "after_first_write":
            print("scenario mutation applied at", step)

    res = chain(arc, os.path.join(into, "logs"), os.path.join(into, "run_meta.json"),
                until=until, hook=(hook if mutation_script else None), stale_u2=stale_u2, keep=keep)
    res["scenario"] = into
    res["mutation_script"] = bool(mutation_script)
    print(json.dumps({k: res[k] for k in sorted(res)}, sort_keys=True))
    sys.exit(0 if res.get("status") == "PASS" or (until == "postwrite" and not res["gates_failed"]
                                                  and not res["blocked"]) else 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["manifest", "status", "identity", "pack", "validation",
                                        "verify", "simulate"], default="validation")
    ap.add_argument("--archive", default=f"{RR}/{T}.tar.gz")
    ap.add_argument("--tree", default=R4, help="tree whose files the identity hashes are taken from")
    ap.add_argument("--into", default="", help="simulate: isolated scenario directory")
    ap.add_argument("--tree-src", default=R4, help="simulate: tree to copy into the scenario")
    ap.add_argument("--until", choices=["postwrite", "full"], default="full",
                    help="simulate: stop after the post-write gates instead of closing for real")
    ap.add_argument("--stale-u2", action="store_true",
                    help="simulate only: reuse a tree unpacked before the first write as U2")
    ap.add_argument("--mutation", default="", help="simulate: path of a scenario mutation script")
    ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()
    if a.stage == "manifest":
        manifest_stage(a.tree)
    elif a.stage == "status":
        status_stage(a.tree)
    elif a.stage == "pack":
        pack_stage(a.tree, a.archive, delivery=os.path.dirname(os.path.abspath(a.archive)) == RR)
    elif a.stage == "identity":
        identity_stage(a.tree, a.archive)
    elif a.stage == "validation":
        os.makedirs(f"{W}/logs", exist_ok=True)
        validation_stage(a.keep)
    elif a.stage == "verify":
        os.makedirs(f"{W}/logs", exist_ok=True)
        verify_stage(a.archive)
    else:
        if not a.into:
            sys.exit("simulate needs --into DIR")
        simulate_stage(a.into, a.tree_src, a.until, a.stale_u2, a.keep, a.mutation)


main()
