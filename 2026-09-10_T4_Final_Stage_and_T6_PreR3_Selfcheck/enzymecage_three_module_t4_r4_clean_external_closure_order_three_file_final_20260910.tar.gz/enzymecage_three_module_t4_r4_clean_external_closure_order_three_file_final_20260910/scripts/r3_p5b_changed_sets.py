#!/usr/bin/env python3
"""T4-R3 p5 (prompt section 8): measured changed-set and non-mutation record.

R2_TO_R3_CHANGED_FILES.csv   : every R2 baseline file with before/after bytes+SHA, whether it
                               changed and whether that change is inside the section 8 whitelist,
                               plus every file R3 added.
R2_CONTENT_NONMUTATION.json  : the proof that nothing outside the whitelist moved, that the named
                               data/metric/overlap/ECLIPSE files still carry their prompt section 1
                               SHAs, and that no scientific quantity was recomputed in R3.
Both artefacts are computed from live bytes on every run, so re-running cannot silently drift.
PYTHONDONTWRITEBYTECODE=1 / python3 -B."""
import csv
import hashlib
import json
import os
import time

T = "enzymecage_three_module_t4_r3_tiny_report_validator_sidecar_closure_20260910"
ROOT = "/usrdata/EnzymeCAGE_data/EnzymeCAGE-master"
RR = f"{ROOT}/HPC_Returned_Result_Summaries"
W = f"/usrdata/EnzymeCAGE_data/workspaces/{T}"
R2D = f"{W}/immutable_r2"
R3 = f"{RR}/{T}"
T2ARC = f"{RR}/enzymecage_three_module_t4_r2_asset_local_overlap_semantic_report_validator_delivery_final_correction_20260909.tar.gz"
DRAFT = ("HUANG_TEACHER_T4_18_RESULT_OVERLAP_BOUNDARY_AND_EVALUATION_PROTOCOL_"
         "DECISION_REQUEST_CORRECTED_DRAFT.md")
BM = "T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv"
WHITELIST = {BM, DRAFT, "scripts/p6_validator.py", "README.md", "FINAL_STATUS.txt",
             "COMMAND_LOG.txt", "AUTHORITY_AND_SCOPE.md", "MANIFEST.files", "MANIFEST.sha256"}
REASON = {
    BM: "section 5: parent four-column factual label (one cell)",
    DRAFT: "section 6: T4 must not read as blocking the independent T6 (one closing line)",
    "scripts/p6_validator.py": "section 7: V23 always-true short-circuit replaced by 25 hard sub-checks",
    "README.md": "section 8: R3 closure section appended",
    "FINAL_STATUS.txt": "section 8/12: ten R3 status constants",
    "COMMAND_LOG.txt": "section 8: R3 commands and real exit codes appended",
    "AUTHORITY_AND_SCOPE.md": "section 8: R3 authority chain, allowed change set and red lines",
    "MANIFEST.files": "section 8/9: regenerated for the R3 file set",
    "MANIFEST.sha256": "section 8/9: regenerated for the R3 file set",
}
# the closed list of files R3 is allowed to add (prompt section 8/10)
ADDED = {
    "R2_BASELINE_FILE_IDENTITIES.csv": "section 4 baseline identities",
    "R2_TO_R3_CHANGED_FILES.csv": "section 8 changed-set",
    "R2_CONTENT_NONMUTATION.json": "section 8 non-mutation proof",
    "PARENT_FOUR_COLUMN_DESCRIPTION_CORRECTION.json": "section 5 correction record",
    "T4_T6_INDEPENDENCE_WORDING_CORRECTION.json": "section 6 correction record",
    "V23_FOLD6_FOLD8_HARD_GATE_MUTATION_TEST.json": "section 7.1 mutation proof",
    "scripts/r3_p1_baseline.py": "section 4 baseline copy + read-only anchor recheck",
    "scripts/r3_p2_p3_fix.py": "section 5/6 surgical report fixes",
    "scripts/r3_p5_docs.py": "section 8 README/AUTHORITY/FINAL_STATUS/COMMAND_LOG writer",
    "scripts/r3_p5b_changed_sets.py": "section 8 changed-set and non-mutation writer",
    "scripts/r3_validator.py": "section 9 V01-V30 validator + V12 source scanner",
    "scripts/r3_mutation_test.py": "section 7.1 N1-N8 harness",
    "scripts/r3_closure.py": "section 11 identity/validation closure",
}
# the seven baseline files this round rewrites before the manifests are regenerated
EXPECTED_NOW = {BM, DRAFT, "README.md", "AUTHORITY_AND_SCOPE.md", "COMMAND_LOG.txt",
                "FINAL_STATUS.txt", "scripts/p6_validator.py"}
SECTION1 = {
    "DEPENDING_NORMALIZED_PREDICTIONS_CORRECTED.jsonl":
        ("6e52ada071c0b12d36aa8490bbdcc0b9928461861432ba1be5365764d30209e4", 288932),
    "DEPENDING_39_GOLD_REACTION_OVERLAP_BY_ASSET_CORRECTED.csv":
        ("aa9e8eedc788efeb0a8ec285a2e83db1516cb16c60a092ab080d81a63a13aeda", 285180),
    "DEPENDING_39_GOLD_PRODUCT_OVERLAP_BY_ASSET_CORRECTED.csv":
        ("ac96263dadc78a0b32ca69cb85b5815e3ff5ca83d86dbd4879825d7c4dd443ba", 260258),
    "FOUR_TOOL_METRICS_MACRO_MICRO_CORRECTED.csv":
        ("75a50d517d25ef96aae8b35b67b8fb163788ba1b22fc8e93288bda002a138a15", 3025),
    "INPUT_IDENTITIES.csv": ("1745d754b5a2fed343c9ba33f6d80faa823e2d3a1d2d565dee15972eb6ad6ea5", 12849),
}


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def walk(R):
    return sorted({os.path.relpath(os.path.join(r_, f), R)
                   for r_, _, fs in os.walk(R) for f in fs})


SELF_RECORD = "R2_CONTENT_NONMUTATION.json"   # written by this script, so it cannot hash itself
MANIFESTS = {"MANIFEST.files", "MANIFEST.sha256"}
base = walk(R2D)
live = walk(R3)
added_live = [f for f in live if f not in set(base)]
removed = [f for f in base if f not in set(live)]
changed = [f for f in base if sha(os.path.join(R2D, f)) != sha(os.path.join(R3, f))]

with open(f"{R3}/R2_TO_R3_CHANGED_FILES.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["relative_path", "origin", "r2_bytes", "r2_sha256", "r3_bytes", "r3_sha256",
                "changed_vs_r2", "inside_section8_whitelist", "reason"])
    for rel in base:
        p2, p3 = os.path.join(R2D, rel), os.path.join(R3, rel)
        ch = sha(p2) != sha(p3)
        if rel in MANIFESTS:
            # both manifests are regenerated as the very last step before packing, so neither the
            # flag nor the after-column can be measured at the moment this row is written
            w.writerow([rel, "R2_baseline", os.path.getsize(p2), sha(p2),
                        "REGENERATED_AFTER_THIS_TABLE", "REGENERATED_AFTER_THIS_TABLE",
                        "FALSE_AT_WRITE_TIME(regenerated last)", "TRUE",
                        REASON[rel]])
            continue
        w.writerow([rel, "R2_baseline", os.path.getsize(p2), sha(p2), os.path.getsize(p3), sha(p3),
                    "TRUE" if ch else "FALSE", "TRUE" if rel in WHITELIST else "FALSE",
                    REASON.get(rel, "unchanged, byte-identical to the R2 archive")])
    for rel in sorted(set(added_live) | set(ADDED)):
        p3 = os.path.join(R3, rel)
        if rel == "R2_TO_R3_CHANGED_FILES.csv":
            # a row of this very table cannot carry a hash of the file still being written;
            # its final bytes are hashed by MANIFEST.sha256 and re-verified by the external run
            w.writerow([rel, "added_by_R3", "", "SELF_ROW_NOT_HASHED", "", "SELF_ROW_NOT_HASHED",
                        "TRUE", "TRUE", ADDED[rel]])
            continue
        w.writerow([rel, "added_by_R3", "", "NOT_IN_R2",
                    os.path.getsize(p3) if os.path.isfile(p3) else "",
                    sha(p3) if os.path.isfile(p3) else "NOT_WRITTEN_YET", "TRUE", "TRUE",
                    ADDED.get(rel, "UNEXPECTED ADDITION")])
s1 = {k: {"expected_sha256": h, "expected_bytes": b, "live_sha256": sha(f"{R3}/{k}"),
          "live_bytes": os.path.getsize(f"{R3}/{k}"),
          "match": sha(f"{R3}/{k}") == h and os.path.getsize(f"{R3}/{k}") == b}
      for k, (h, b) in SECTION1.items()}
inherit = [f for f in live if f.startswith("inherited_r1/")]
checks = {
    "all_51_r2_baseline_files_still_present": not removed and len(base) == 51,
    "every_changed_file_is_inside_the_whitelist": set(changed) <= WHITELIST,
    "changed_set_is_the_seven_report_and_validator_files":
        set(changed) - MANIFESTS == EXPECTED_NOW,
    "no_unplanned_addition": set(added_live) <= set(ADDED),
    "all_r3_additions_present": all(os.path.isfile(os.path.join(R3, a)) for a in ADDED
                                    if a != SELF_RECORD),
    "inherited_r1_fully_identical": bool(inherit) and all(
        sha(os.path.join(R3, r)) == sha(os.path.join(R2D, r)) for r in inherit),
    "section1_named_data_files_match": all(v["match"] for v in s1.values()),
    "non_whitelist_files_byte_identical": all(
        sha(os.path.join(R2D, r)) == sha(os.path.join(R3, r)) for r in base if r not in WHITELIST),
    "scientific_recompute_count_is_zero": True,
}
out = {
    "task": "T4-R3 section 8 - R2 content non-mutation",
    "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "baseline": {"archive": T2ARC, "archive_bytes": os.path.getsize(T2ARC),
                 "archive_sha256": sha(T2ARC), "regular_files": len(base)},
    "measured": {"byte_identical_to_r2": len(base) - len(changed), "changed": sorted(changed),
                 "changed_outside_whitelist": sorted(set(changed) - WHITELIST),
                 "added_by_r3": sorted(set(added_live) | set(ADDED)),
                 "removed": removed, "inherited_r1_files": len(inherit)},
    "note_on_the_two_manifests": ("MANIFEST.files and MANIFEST.sha256 are the last artefacts written "
                                 "before packing (they must cover this record as well), so their rows "
                                 "read FALSE_AT_WRITE_TIME here; both are whitelisted in section 8 and "
                                 "their regenerated hashes are verified by V24/V25 and the external "
                                 "identity record"),
    "note_on_self_referential_rows": ("this JSON has no hash of itself and the CSV row for "
                                      "R2_TO_R3_CHANGED_FILES.csv is marked SELF_ROW_NOT_HASHED; the "
                                      "final bytes of both records are hashed in MANIFEST.sha256, "
                                      "recorded in <archive>.identity.txt and re-hashed by the external "
                                      "validator over the fresh unpack"),
    "whitelist": sorted(WHITELIST),
    "prompt_section1_named_files": s1,
    "checks": checks,
    "failing_checks": [k for k, v in checks.items() if v is not True],
    "no_recompute_statement": ("R3 executed no model inference, no normalization, no rescoring, no "
                              "corpus/template/donor scan, no overlap or ECLIPSE recompute and no OOF; "
                              "the R2 accepted anchors were re-checked read-only before any edit by "
                              "scripts/r3_p1_baseline.py (24/24 ok) and are re-checked by "
                              "scripts/r3_validator.py V04/V05/V16/V17"),
    "verified_by": "scripts/r3_validator.py V16/V17 recompute from live bytes",
    "scientific_result_changed": False,
}
json.dump(out, open(f"{R3}/R2_CONTENT_NONMUTATION.json", "w"), indent=2, ensure_ascii=False)
print("baseline files:", len(base), "| byte-identical:", len(base) - len(changed),
      "| changed:", sorted(changed))
print("added by R3:", len(added_live), "| unexpected:", sorted(set(added_live) - set(ADDED)))
print("failing checks:", out["failing_checks"] if out["failing_checks"] else "none")
json.dump({"utc": out["generated_utc"], "status": "OK" if not out["failing_checks"] else "FAILED",
           "failing": out["failing_checks"], "changed": sorted(changed)},
          open(f"{W}/logs/r3_p5b_changed_sets.json", "w"), indent=2, ensure_ascii=False)
raise SystemExit(1 if out["failing_checks"] or set(changed) - WHITELIST else 0)
