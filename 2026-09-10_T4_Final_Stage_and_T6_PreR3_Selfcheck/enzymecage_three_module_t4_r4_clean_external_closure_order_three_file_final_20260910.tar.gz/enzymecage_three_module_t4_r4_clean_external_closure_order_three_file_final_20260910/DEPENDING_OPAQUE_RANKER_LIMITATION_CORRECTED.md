# DEPENDING opaque ranker limitation (T4-R2 corrected)

Corrects R1 `DEPENDING_OPAQUE_RANKER_LIMITATION.md`. Sections 1, 2, 4 and 5 of the R1 file remain
valid and are inherited; ONLY the R1 §3 "external enviPath knowledge source" claim is retracted.
See `DEPENDING_ENVIPATH_RUNTIME_AND_RANKER_BOUNDARY_CORRECTED.md` for the local-frozen-rule
evidence. This file is report/semantics correction only; no matrix was recomputed here.

## 1. Scope and identity (inherited from R1 §1-§2, unchanged)

The three depending_v32 ranker assets are LightGBM `.txt` parameter files whose bytes/SHA256 match
the p6 `RUNTIME_AND_ASSET_IDENTITIES.csv` records:

```text
uspto_ranker.txt      1263228 B  e493fc031f217e18543d27081168ff6851414f8f080622cf3dd54bc9484e0944
envipath_ranker.txt    645960 B  e0920695c9d8e2609c64da18975d39275b8be581a5657b0cf45ed8da264141c1
retrieval_ranker.txt   659831 B  bdcb575e9685d47dbfa83b96f71dd05e326dc21cb7f4c0b224b1fffb49c65f65
```

No training-row identifiers, SMILES, InChIKeys or record IDs are recoverable from them. Absence of
textual hits in an opaque model must NOT be narrated as "zero overlap". The three ranker assets
contribute NO rows to exact-match denominators; their rows in all BY_ASSET/PARENT matrices are
`OPAQUE_NOT_AUDITABLE` / `OPAQUE_EXCLUDED_FROM_DENOMINATOR`.

## 2. Retracted R1 statement

RETRACTED (do not use): "The `envipath*` engines query an external enviPath knowledge base at
runtime ... the exact KB content consulted at run time is not part of the frozen local assets".

CORRECT: the depending engine-B envipath rules load from LOCAL frozen, SHA-gated template files
(`data/hfix/templates_implicitH.jsonl`, `reaction_v3/data/lib_envipath/templates.tsv.gz`);
`runtime_external_envipath_http_query=false` for this run.

## 3. Opaque ranker training identity: UNKNOWN, cleanly separated

Two distinct statements must not be conflated (R1 summary field
`q6_unknown_due_to_opaque_ranker_or_external_envipath` with `cases=[]` did conflate them):

```text
cases_without_any_auditable_parent_or_template_locator = []        (0/18; recomputed from the R1
                                                                    144-row parent exposure matrix)
cases_with_opaque_ranker_training_identity             = 18/18
ranker_training_overlap                                = UNKNOWN_FOR_ALL_18
runtime_external_envipath_dependency                   = false
```

Every one of the 18 cases HAS at least parent-side or template-level evidence in the 5 auditable
text assets, so the "no auditable locator at all" case list is legitimately empty. That emptiness
says NOTHING about the ranker training overlap, which remains UNKNOWN for all 18 cases because the
ranking provenance (which engine/ranker produced which score for which training row) is not
recoverable from the opaque rankers for ANY prediction - including the 7 pair-connected first hits.

## 4. First-hit provenance split (inherited from R1 §4, unchanged)

Of the 15 re-derived first gold-product hits: 7 `CORPUS_EXACT_PAIR_SEEN_IN_AUDITABLE_ASSET`,
6 `PARENT_SIDE_ONLY_SEEN_NO_EXACT_PAIR`, 2 `TEMPLATE_ONLY_MATCH_NO_CONCRETE_RECORD`,
0 first-hit cases with no auditable match provenance; 3 cases have no top10 hit.
`source_tag=envipath` is not automatically leakage and `source_tag=retrieval` is not automatically
leak-free; classification is locator-driven only.

## 5. Consequence for the boundary matrix

`T4_BLINDNESS_AND_EXPOSURE_BOUNDARY_MATRIX_CORRECTED.csv` records ranker training identity as
`OPAQUE_NOT_AUDITABLE / UNKNOWN_FOR_ALL_18`, never "0 overlap", and no boundary row may claim an
external enviPath KB runtime dependency.
